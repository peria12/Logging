﻿using Aurora.AdministrationService.API.Controllers.ImageMaintenance;
using Aurora.AdministrationService.API.Models.Dto.Logo;
using Aurora.AdministrationService.API.Models.RequestModels.Logos;
using Aurora.AdministrationService.API.Services.IService.Logos;
using Aurora.AdministrationService.CrossCutting.CommonModels;
using Aurora.AdministrationService.CrossCutting.Constants;
using FluentAssertions;
using Microsoft.AspNetCore.Mvc;
using Moq;

namespace Aurora.AdministrationService.Tests.API.Controllers.Logo
{
    public class LogoControllerTest
    {
        private readonly Mock<ILogoCommandService> _mockLogoCommandService;
        private readonly Mock<ILogoQueryService> _mockLogoQueryService;
        private readonly LogoController _controller;

        public LogoControllerTest()
        {
            _mockLogoCommandService = new Mock<ILogoCommandService>();
            _mockLogoQueryService = new Mock<ILogoQueryService>();
            _controller = new LogoController(_mockLogoQueryService.Object, _mockLogoCommandService.Object);
        }

        [Fact]
        public async Task CreateLogoImage_ShouldReturnSuccessResponse_WhenImageIsAdded()
        {
            // Arrange
            var logoImage = new AddLogoImageRequest()
            {
                ImageURL = string.Empty,
                OrganizationId = 1,
                Status = true,
            };

            _mockLogoCommandService.Setup(service => service.CreateLogoImageAsync(logoImage)).ReturnsAsync(true);

            // Act
            var result = await _controller.CreateLogoImage(logoImage) as OkObjectResult;
            var response = result?.Value as GenericResponse<string>;

            // Assert
            result.Should().NotBeNull();
            result?.StatusCode.Should().Be(200);
            response?.IsSuccess.Should().BeTrue();
            response?.StatusCode.Should().Be(ResponseStatusCode.STATUS_SUCCESS);
            response?.Message.Should().Be(ResponseMessage.STATUS_DATA_ADDED);
        }

        [Fact]
        public void GetLogoImageList_ShouldReturnLogoImageList()
        {
            // Arrange
            var logoImageList = new List<GetLogoImageListDto> { new GetLogoImageListDto() };
            _mockLogoQueryService.Setup(service => service.GetLogoImageList()).Returns(logoImageList);

            // Act
            var result = _controller.GetLogoImageList();
            var okresult = result?.Result as OkObjectResult;
            var response = okresult?.Value as GenericResponseList<GetLogoImageListDto>;

            // Assert
            result.Should().NotBeNull();
            response?.StatusCode.Should().Be("200");
            response?.IsSuccess.Should().BeTrue();
            response?.StatusCode.Should().Be(ResponseStatusCode.STATUS_SUCCESS);
            response?.Message.Should().Be(ResponseMessage.STATUS_DATA_FOUND);
            response?.TotalCount.Should().Be(logoImageList.Count);
        }

        [Fact]
        public async Task GetLogoImageById_ShouldReturnNull_WhenIdIsInvalid()
        {
            // Act
            var result = await _controller.GetLogoImageById(null);

            // Assert
            result.Should().NotBeNull();
            result.Value.Should().BeNull();
        }

        [Fact]
        public async Task GetLogoImageById_ShouldReturnNotFound_WhenImageDoesNotExist()
        {
            // Arrange
            int id = 1;
            _mockLogoQueryService
              .Setup(service => service.GetLogoImageById(id)).ReturnsAsync((GetLogoImageDetailDto)null!);

            // Act
            var result = await _controller.GetLogoImageById(id);
            var okobjectresult = result?.Result as OkObjectResult;
            var response = okobjectresult?.Value as GenericResponse<GetLogoImageDetailDto>;

            // Assert
            result.Should().NotBeNull();
            response?.IsSuccess.Should().BeTrue();
            response?.StatusCode.Should().Be(ResponseStatusCode.STATUS_NOTFOUND);
            response?.Message.Should().Be(ResponseMessage.STATUS_NODATA);
        }

        [Fact]
        public async Task UpdateLogoImageDetails_ShouldReturnBadRequest_WhenImageAlreadyExists()
        {
            // Arrange
            int id = 1;
            var logoImage = new UpdateLogoImageRequest()
            {
                ImageURL = string.Empty,
                OrganizationId = 1,
                Status = true,              
            };
            _mockLogoQueryService.Setup(service => service.IsLogoImageAlreadyExist(id)).ReturnsAsync((true, ResponseMessage.STATUS_NODATA));

            // Act
            var result = await _controller.UpdateLogoImageDetails(id, logoImage);

            // Assert
            result.Should().NotBeNull();           
        }

        [Fact]
        public async Task UpdateLogoImageDetails_LogoNotFound_ReturnsNotFound()
        {
            // Arrange
            int logoId = 1;
            var logoImageRequest = new UpdateLogoImageRequest()
            {
                ImageURL = string.Empty,
                OrganizationId = 1,
                Status = true,
            };

            _mockLogoQueryService
                .Setup(service => service.FindLogoImageById(logoId))
                .ReturnsAsync((Domain.Old.Entities.Logo)null!); 

            // Act
            var result = await _controller.UpdateLogoImageDetails(logoId, logoImageRequest);

            // Assert
            var actionResult = Assert.IsType<NotFoundObjectResult>(result);
            var response = Assert.IsType<GenericResponse<string>>(actionResult.Value);
            Assert.Equal(ResponseStatusCode.STATUS_NOTFOUND, response.StatusCode);
            Assert.Equal(ResponseMessage.STATUS_NODATA, response.Message);
        }

        [Fact]
        public async Task UpdateLogoImageDetails_UpdateSuccessful_ReturnsOk()
        {
            // Arrange
            int logoId = 1;
            var logoImageRequest = new UpdateLogoImageRequest()
            {
                ImageURL = string.Empty,
                OrganizationId = 1,
                Status = true,
            };
            var existingLogo = new Domain.Old.Entities.Logo { Id = logoId, CreatedBy="Admin", CreatedDate=DateTime.UtcNow, OrganizationId=1, IsDeleted=false};

            _mockLogoQueryService
                .Setup(service => service.FindLogoImageById(logoId))
                .ReturnsAsync(existingLogo); 

            _mockLogoCommandService
                .Setup(service => service.UpdateLogoImageAsync(existingLogo, logoImageRequest))
                .ReturnsAsync(true); 

            // Act
            var result = await _controller.UpdateLogoImageDetails(logoId, logoImageRequest);

            // Assert
            var actionResult = Assert.IsType<OkObjectResult>(result);
            var response = Assert.IsType<GenericResponse<string>>(actionResult.Value);
            Assert.Equal(ResponseStatusCode.STATUS_SUCCESS, response.StatusCode);
            Assert.Equal(ResponseMessage.STATUS_DATA_UPDATED, response.Message);
            Assert.Equal(CommonConstants.SUCCESS, response.MessageType);
        }

        [Fact]
        public async Task UpdateLogoImageDetails_UpdateFailed_ReturnsOkWithErrorMessage()
        {
            // Arrange
            int logoId = 1;
            var logoImageRequest = new UpdateLogoImageRequest()
            {
                ImageURL = string.Empty,
                OrganizationId = 1,
                Status = true,              
            };
            var existingLogo = new Domain.Old.Entities.Logo { Id = logoId, CreatedBy = "Admin", CreatedDate = DateTime.UtcNow, OrganizationId = 1, IsDeleted = false };

            _mockLogoQueryService
                .Setup(service => service.FindLogoImageById(logoId))
                .ReturnsAsync(existingLogo); // Simulate logo found

            _mockLogoCommandService
                .Setup(service => service.UpdateLogoImageAsync(existingLogo, logoImageRequest))
                .ReturnsAsync(false); // Simulate update failure

            // Act
            var result = await _controller.UpdateLogoImageDetails(logoId, logoImageRequest);

            // Assert
            var actionResult = Assert.IsType<OkObjectResult>(result);
            Assert.Equal(ResponseStatusCode.STATUS_SUCCESS, actionResult.StatusCode.ToString());
        }

        [Fact]
        public async Task GetLogoImageById_ReturnsOk_WhenLogoImageIsFound()
        {
            // Arrange
            int id = 1;
            var expectedLogoImage = new GetLogoImageDetailDto { Id = id, OrganizationId = 101, ImageUrl="logo.png", IsDeleted=false, Status=true, CreatedDate = DateTime.UtcNow, UpdatedDate= DateTime.UtcNow, UpdatedBy="Admin", RecordVersion = Array.Empty<byte>() };
            _mockLogoQueryService.Setup(s => s.GetLogoImageById(id)).ReturnsAsync(expectedLogoImage);

            // Act
            var result = await _controller.GetLogoImageById(id);

            // Assert
            var actionResult = Assert.IsType<ActionResult<GenericResponse<GetLogoImageDetailDto>>>(result);
            var okResult = Assert.IsType<OkObjectResult>(actionResult.Result);
            var response = Assert.IsType<GenericResponse<GetLogoImageDetailDto>>(okResult.Value);
            Assert.True(response.IsSuccess);
            Assert.Equal(ResponseStatusCode.STATUS_SUCCESS, response.StatusCode);
            Assert.Equal(ResponseMessage.STATUS_DATA_FOUND, response.Message);
            Assert.Equal(expectedLogoImage, response.Result);
        }

        #region DeleteLogoImageById Tests

        [Fact]
        public async Task DeleteLogoImageById_ShouldReturnSuccess_WhenDeletedSuccessfully()
        {
            // Arrange
            int logoId = 1;
            var logo = new Domain.Old.Entities.Logo { Id = logoId, OrganizationId = 1, CreatedBy ="test", CreatedDate = DateTime.UtcNow, IsDeleted = false };
            var request = new UpdateLogoImageRequest { RecordVersion = new byte[] { 0x01, 0x02, 0x03, 0x04 }, OrganizationId = 1, ImageURL =" test1.jpg", Status = true };

            _mockLogoQueryService.Setup(service => service.FindLogoImageById(logoId)).ReturnsAsync(logo);
            _mockLogoCommandService.Setup(service => service.DeleteLogoImageByIdAsync(request.RecordVersion, logo)).ReturnsAsync(true);

            // Act
            var result = await _controller.DeleteLogoImageById(logoId, request);

            // Assert
            var actionResult = Assert.IsType<OkObjectResult>(result);
            var response = Assert.IsType<GenericResponse<string>>(actionResult.Value);
            response.StatusCode.Should().Be(ResponseStatusCode.STATUS_SUCCESS);
            response.Message.Should().Be(ResponseMessage.STATUS_DATA_DELETED);
            response.MessageType.Should().Be(CommonConstants.SUCCESS);
        }

        [Fact]
        public async Task DeleteLogoImageById_ShouldReturnNotFound_WhenLogoDoesNotExist()
        {
            // Arrange
            int logoId = 999;
            var request = new UpdateLogoImageRequest { RecordVersion = new byte[] { 0x01, 0x02, 0x03, 0x04 }, OrganizationId = 1, ImageURL = " test1.jpg", Status = true };

            _mockLogoQueryService.Setup(service => service.FindLogoImageById(logoId)).ReturnsAsync((Domain.Old.Entities.Logo)null!);

            // Act
            var result = await _controller.DeleteLogoImageById(logoId, request);

            // Assert
            var actionResult = Assert.IsType<NotFoundObjectResult>(result);
            var response = Assert.IsType<GenericResponse<string>>(actionResult.Value);
            response.StatusCode.Should().Be(ResponseStatusCode.STATUS_NOTFOUND);
            response.Message.Should().Be(ResponseMessage.STATUS_NODATA);
            response.MessageType.Should().Be(CommonConstants.INFO);
        }

        [Fact]
        public async Task DeleteLogoImageById_ShouldReturnNotFound_WhenInvalidIdIsPassed()
        {
            // Arrange
            int invalidId = -1;
            var request = new UpdateLogoImageRequest
            {
                RecordVersion = new byte[] { 0x01, 0x02, 0x03, 0x04 },
                OrganizationId = 1,
                ImageURL = "test1.jpg",
                Status = true
            };

            // Act
            var result = await _controller.DeleteLogoImageById(invalidId, request);

            // Assert
            result.Should().BeOfType<NotFoundObjectResult>();

            var notFoundResult = result as NotFoundObjectResult;
            notFoundResult.Should().NotBeNull();

            var response = notFoundResult?.Value as GenericResponse<string>;
            response.Should().NotBeNull();
            response?.IsSuccess.Should().BeTrue(); // As per controller logic
            response?.StatusCode.Should().Be(ResponseStatusCode.STATUS_NOTFOUND);
            response?.Message.Should().Be(ResponseMessage.STATUS_NODATA);
        }

        #endregion

        #region SearchLogoImagesList Tests

        [Fact]
        public async Task SearchLogoImagesList_ShouldReturnLogoImageList_WhenDataExists()
        {
            // Arrange
            var logoImageList = new List<GetLogoImageListDto>
            {
                new GetLogoImageListDto { Id = 1, OrganizationId = 101, Status = true, ImageUrl = "https://example.com/logo1.png", CreatedDate = DateTime.UtcNow, UpdatedDate= DateTime.UtcNow, UpdatedBy="Admin", RecordVersion = Array.Empty<byte>(), IsDeleted = false },
                new GetLogoImageListDto { Id = 2, OrganizationId = 102, Status = false, ImageUrl = "https://example.com/logo2.png", CreatedDate = DateTime.UtcNow, UpdatedDate= DateTime.UtcNow, UpdatedBy="Admin", RecordVersion = Array.Empty<byte>(), IsDeleted = false }
            };

            _mockLogoQueryService
                .Setup(service => service.GetLogoImageListAsync(It.IsAny<int?>(), It.IsAny<int?>(), It.IsAny<string>(), It.IsAny<string>()))
                .ReturnsAsync(logoImageList);

            // Act
            var actionResult = await _controller.SearchLogoImagesList(1, 10, null, null);
            var okResult = actionResult.Result as OkObjectResult;
            var response = okResult?.Value as GenericResponseList<GetLogoImageListDto>;

            // Assert
            okResult.Should().NotBeNull();
            okResult?.StatusCode.Should().Be(200);
            response?.IsSuccess.Should().BeTrue();
            response?.StatusCode.Should().Be(ResponseStatusCode.STATUS_SUCCESS);
            response?.Message.Should().Be(ResponseMessage.STATUS_DATA_FOUND);
            response?.TotalCount.Should().Be(logoImageList.Count);
            response?.Results.Should().HaveCount(2);
        }


        [Fact]
        public async Task SearchLogoImagesList_ShouldReturnNoDataMessage_WhenListIsEmpty()
        {
            // Arrange
            var emptyList = new List<GetLogoImageListDto>();

            _mockLogoQueryService
                .Setup(service => service.GetLogoImageListAsync(It.IsAny<int?>(), It.IsAny<int?>(), It.IsAny<string>(), It.IsAny<string>()))
                .ReturnsAsync(emptyList);

            // Act
            var actionResult = await _controller.SearchLogoImagesList(1, 10, null, null);
            var okResult = actionResult.Result as OkObjectResult;
            var response = okResult?.Value as GenericResponseList<GetLogoImageListDto>;


            // Assert
            okResult.Should().NotBeNull();
            okResult?.StatusCode.Should().Be(200);
            response?.IsSuccess.Should().BeTrue();
            response?.StatusCode.Should().Be(ResponseStatusCode.STATUS_SUCCESS);
            response?.Message.Should().Be(ResponseMessage.STATUS_NODATA);
            response?.TotalCount.Should().Be(0);
            response?.Results.Should().BeEmpty();
        }

        [Fact]
        public async Task SearchLogoImagesList_ShouldCallQueryService_WithCorrectParameters()
        {
            // Arrange
            var logoImageList = new List<GetLogoImageListDto> { new GetLogoImageListDto { Id = 1, OrganizationId = 101, Status = true } };

            _mockLogoQueryService
                .Setup(service => service.GetLogoImageListAsync(1, 5, "101", "1"))
                .ReturnsAsync(logoImageList);

            // Act
            var actionResult = await _controller.SearchLogoImagesList(1, 5, "101", "1");
            var okResult = actionResult.Result as OkObjectResult;
            var response = okResult?.Value as GenericResponseList<GetLogoImageListDto>;

            // Assert
            _mockLogoQueryService.Verify(service => service.GetLogoImageListAsync(1, 5, "101", "1"), Times.Once);
            response?.Results.Should().HaveCount(1);
        }
        #endregion
    }
}
