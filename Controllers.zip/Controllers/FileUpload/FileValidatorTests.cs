﻿using Aurora.AdministrationService.API.Validations;
using Aurora.AdministrationService.CrossCutting.CommonModels;
using Microsoft.AspNetCore.Http;
using Microsoft.Extensions.Configuration;
using Moq;
using static Aurora.AdministrationService.CrossCutting.Constants.CommonConstants;

namespace Aurora.AdministrationService.Tests.API.Controllers.FileUpload
{
    public class FileValidatorTests
    {
        private readonly IConfiguration _configuration;
        private readonly FileValidator _fileValidator;

        public FileValidatorTests()
        {
            var inMemorySettings = new Dictionary<string, string> { { AllowImageTypes, "image/png,image/jpeg" }, 
                { AllowedImageExt, ".png,.jpg,.jpeg" }, {FileMaxSize, "5242880" } };
            _configuration = new ConfigurationBuilder()
                .AddInMemoryCollection(inMemorySettings)
                .Build();
            
            _fileValidator = new FileValidator(_configuration);
        }

        [Fact]
        public void IsValid_ShouldReturnFalse_WhenModuleNameIsInvalid()
        {
            // Arrange
            var file = CreateMockFile("test.png", "image/png", 1024);
            // Act
            var result = _fileValidator.IsValid(file, "InvalidModule", out string errorMessage);

            // Assert
            Assert.False(result);
            Assert.Equal(ResponseMessage.INVALID_MODULE_NAME + $" {string.Join(", ", new List<string> { ModuleTypes.Logos, ModuleTypes.Onboarding, ModuleTypes.SplashScreen })}.", errorMessage);
        }

        [Fact]
        public void IsValid_ShouldReturnFalse_WhenFileIsNull()
        {
         
            // Act
            var result = _fileValidator.IsValid(null, "Logos", out string errorMessage);

            // Assert
            Assert.False(result);
            Assert.Equal(ResponseMessage.FILE_REQUIRED, errorMessage);
        }

        [Fact]
        public void IsValid_ShouldReturnFalse_WhenFileSizeExceedsLimit()
        {
            // Arrange
            var file = CreateMockFile("test.png", "image/png", 6 * 1024 * 1024); // 6MB
            // Act
            var result = _fileValidator.IsValid(file, "Logos", out string errorMessage);

            // Assert
            Assert.False(result);
            Assert.Equal(ResponseMessage.FIE_LENGTH_EXCEEDED + "5MB", errorMessage);
        }

        [Fact]
        public void IsValid_ShouldReturnFalse_WhenFileTypeIsNotAllowed()
        {
            // Arrange
            var file = CreateMockFile("test.txt", "text/plain", 1024);

            // Act
            var result = _fileValidator.IsValid(file, "Logos", out string errorMessage);

            // Assert
            Assert.False(result);
            Assert.Equal(ResponseMessage.UNSUPPORTED_FILE_FORMAT, errorMessage);
        }

        [Fact]
        public void IsValid_ShouldReturnFalse_WhenFileExtensionIsNotAllowed()
        {
            // Arrange
            var file = CreateMockFile("test.gif", "image/png", 1024);

            // Act
            var result = _fileValidator.IsValid(file, "Logos", out string errorMessage);

            // Assert
            Assert.False(result);
            Assert.Equal(ResponseMessage.FILE_EXT_ISSUE, errorMessage);
        }

        [Fact]
        public void IsValid_ShouldReturnTrue_WhenFileIsValid()
        {
            // Arrange
            var file = CreateMockFile("test.png", "image/png", 1024);

            // Act
            var result = _fileValidator.IsValid(file, "Logos", out string errorMessage);

            // Assert
            Assert.True(result);
            Assert.Equal(string.Empty, errorMessage);
        }

        private static IFormFile CreateMockFile(string fileName, string contentType, long length)
        {
            var fileMock = new Mock<IFormFile>();
            fileMock.Setup(f => f.FileName).Returns(fileName);
            fileMock.Setup(f => f.ContentType).Returns(contentType);
            fileMock.Setup(f => f.Length).Returns(length);
            return fileMock.Object;
        }
    }
}
