﻿using Aurora.AdministrationService.API.Controllers.UploadFile;
using Aurora.AdministrationService.API.Helper;
using Aurora.AdministrationService.API.Models.ResponseModels.UploadFile;
using Aurora.AdministrationService.API.Services.IService.FileUpload;
using Aurora.AdministrationService.API.Validations;
using Aurora.AdministrationService.CrossCutting.CommonModels;
using FluentAssertions;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Moq;

namespace Aurora.AdministrationService.Tests.API.Controllers.FileUpload
{
    public class UploadFileControllerTests
    {
        private readonly Mock<IUploadFiles> _mockUploadFilesService;
        private readonly Mock<IRegionCodeValidationHelper> _mockRegionHelper;
        private readonly Mock<IFileValidator> _mockFileValidator;
        private readonly UploadFileController _controller;

        public UploadFileControllerTests()
        {
            _mockUploadFilesService = new Mock<IUploadFiles>();
            _mockRegionHelper = new Mock<IRegionCodeValidationHelper>();
            _mockFileValidator = new Mock<IFileValidator>();
            _controller = new UploadFileController(_mockUploadFilesService.Object, _mockRegionHelper.Object, _mockFileValidator.Object);
            _controller.ControllerContext = new ControllerContext
            {
                HttpContext = new DefaultHttpContext()
            };
        }

        private void SetRegionCodeHeader()
        {
            var headers = new HeaderDictionary { { "RegionCode", "MYS" } };
            _controller.ControllerContext.HttpContext = new DefaultHttpContext();
            foreach (var header in headers)
            {
                _controller.ControllerContext.HttpContext.Request.Headers.Append(header.Key, header.Value);
            }
        }

        [Fact]
        public async Task GetImage_ShouldReturnFileStream_WhenSuccessful()
        {
            // Arrange
            SetRegionCodeHeader();
            var moduleName = "Logos";
            var fileName = "test.png";
            var fileStream = new MemoryStream();
            var contentType = "image/png";

            var fileResponse = new FileResponse
            {
                Stream = fileStream,
                ContentType = contentType
            };

            _mockUploadFilesService.Setup(s => s.GetImageStreamForDownloadAsync(moduleName, fileName, "MYS"))
                .ReturnsAsync(new GenericResponse<FileResponse>
                {
                    IsSuccess = true,
                    Result = fileResponse
                });

            // Act
            var result = await _controller.GetImage("MYS", moduleName, fileName);

            // Assert
            var fileResult = result.Should().BeOfType<FileStreamResult>().Subject;
            fileResult.ContentType.Should().Be(contentType);
        }

        [Fact]
        public async Task UploadFile_ShouldReturnOk_WhenFileIsValid()
        {
            // Arrange
            SetRegionCodeHeader();
            var moduleName = "Logos";
            var fileMock = new Mock<IFormFile>();
            fileMock.Setup(f => f.FileName).Returns("test.png");
            fileMock.Setup(f => f.OpenReadStream()).Returns(new MemoryStream());

            _mockRegionHelper.Setup(r => r.VerifyRegionCodeHeader(It.IsAny<HttpRequest>()))
                .Returns(new GenericResponse<string> { IsSuccess = true });

            _mockFileValidator.Setup(v => v.IsValid(fileMock.Object, moduleName, out It.Ref<string>.IsAny))
                .Returns(true);

            _mockUploadFilesService.Setup(s => s.UploadFileToModuleAsync(moduleName, fileMock.Object.FileName, It.IsAny<Stream>(), "MYS"))
                .ReturnsAsync(new GenericResponse<string> { IsSuccess = true });

            // Act
            var result = await _controller.UploadFile("MYS", moduleName, fileMock.Object);

            // Assert
            result.Should().BeOfType<OkObjectResult>();
        }

        [Fact]
        public async Task UploadFile_ShouldReturnBadRequest_WhenRegionCodeIsInvalid()
        {
            // Arrange
            _mockRegionHelper.Setup(r => r.VerifyRegionCodeHeader(It.IsAny<HttpRequest>()))
                .Returns(new GenericResponse<string> { HasError = true });

            // Act
            var result = await _controller.UploadFile("MYS", "Logos", new Mock<IFormFile>().Object);

            // Assert
            result.Should().BeOfType<BadRequestObjectResult>();
        }

        [Fact]
        public async Task UploadFile_ShouldReturnBadRequest_WhenFileValidationFails()
        {
            // Arrange
            SetRegionCodeHeader();
            var moduleName = "Logos";
            var fileMock = new Mock<IFormFile>();
            string errorMessage = "Invalid file";

            _mockFileValidator.Setup(v => v.IsValid(fileMock.Object, moduleName, out errorMessage))
                .Returns(false);

            // Act
            var result = await _controller.UploadFile("MYS", moduleName, fileMock.Object);

            // Assert
            result.Should().BeOfType<BadRequestObjectResult>();
        }

        [Fact]
        public async Task RemoveFile_ShouldReturnBadRequest_WhenModuleNameIsInvalid()
        {
            // Arrange
            SetRegionCodeHeader();
            var moduleName = "InvalidModule";

            // Act
            var result = await _controller.RemoveFile("MYS", moduleName, "file.png");

            // Assert
            result.Should().BeOfType<BadRequestObjectResult>();
        }

        [Fact]
        public async Task RemoveFile_ShouldReturnBadRequest_WhenFileNameIsEmpty()
        {
            // Arrange
            SetRegionCodeHeader();
            var moduleName = "Logos";

            // Act
            var result = await _controller.RemoveFile("MYS", moduleName, "");

            // Assert
            result.Should().BeOfType<BadRequestObjectResult>();
        }

        [Fact]
        public async Task RemoveFile_ShouldReturnBadRequest_WhenFileNameHasInvalidCharacters()
        {
            // Arrange
            SetRegionCodeHeader();
            var moduleName = "Logos";
            var fileName = "invalid:file?.png";

            // Act
            var result = await _controller.RemoveFile("MYS", moduleName, fileName);

            // Assert
            result.Should().BeOfType<BadRequestObjectResult>();
        }

        [Fact]
        public async Task GetImage_ShouldReturnBadRequest_WhenServiceFails()
        {
            // Arrange
            SetRegionCodeHeader();
            var moduleName = "Logos";
            var fileName = "test.png";
            
            _mockUploadFilesService.Setup(s => s.GetImageStreamForDownloadAsync(moduleName, fileName, "MYS"))
                .ReturnsAsync(new GenericResponse<FileResponse> { IsSuccess = false });

            // Act
            var result = await _controller.GetImage("MYS", moduleName, fileName);

            // Assert
            result.Should().BeOfType<BadRequestObjectResult>();
        }
    }
}
