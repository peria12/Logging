﻿using Aurora.AdministrationService.API.Controllers.Content;
using Aurora.AdministrationService.API.Helper;
using Aurora.AdministrationService.API.Models.Dto.Content;
using Aurora.AdministrationService.API.Resources;
using Aurora.AdministrationService.API.Services.IService.Content;
using Aurora.AdministrationService.CrossCutting.CommonModels;
using Aurora.AdministrationService.CrossCutting.Constants;
using FluentAssertions;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Moq;

namespace Aurora.AdministrationService.Tests.API.Controllers.Content
{
    public class ReasonControllerTest
    {
        private readonly Mock<IReasonsCommandService> _mockReasonCommandService;
        private readonly ReasonController _controller;
        private readonly Mock<IReasonsQueryService> _mockReasonQueryService;
        private readonly Mock<IRegionCodeValidationHelper> _regionHelperMock;
        public ReasonControllerTest()
        {
            _regionHelperMock = new Mock<IRegionCodeValidationHelper>();
            _mockReasonCommandService = new Mock<IReasonsCommandService>();
            _mockReasonQueryService = new Mock<IReasonsQueryService>();
            _controller = new ReasonController(_mockReasonCommandService.Object, _mockReasonQueryService.Object, _regionHelperMock.Object);

        }

        [Fact]
        public async Task DeleteReason_ReturnsNotFound_WhenReasonIdNotFound()
        {
            // Arrange
             _ = new GenericResponse<string>
            {
                IsSuccess = false,
                HasError = true,
                StatusCode = ResponseStatus.STATUS_NotFound,
                Message = Resource.RecordNotFound,
                MessageType = CommonConstants.VALIDATION,
            };

            _regionHelperMock.Setup(x => x.VerifyRegionCodeHeader(It.IsAny<HttpRequest>()))
                .Returns(new GenericResponse<string> { IsSuccess = true });

            _mockReasonQueryService.Setup(x => x.FindReasonsById(It.IsAny<long>()))
                .ReturnsAsync((Domain.V1.Entities.Contents.Reasons)null);

            // Act
            var result = await _controller.DeleteReason(999); // ID 999 does not exist

          
            result.Should().BeOfType<NotFoundObjectResult>();
            var notFoundResult = result as NotFoundObjectResult;

            // Assert the Value of NotFoundObjectResult
            notFoundResult?.Value.Should().NotBeNull();
         
        }

        [Fact]
        public async Task DeleteReasons_ReturnsOk_WhenContentIsDeletedSuccessfully()
        {
            // Arrange
            byte[] concurrencyToken = new byte[8] { byte.MinValue, byte.MinValue, byte.MinValue, byte.MinValue, byte.MinValue, byte.MinValue, byte.MinValue, byte.MaxValue };

            var reasons = new Domain.V1.Entities.Contents.Reasons
            {
                Id = 1,
                RecordVersion = concurrencyToken,
                Status = false,
                ContentID = 1,
                ResonType = "Test Reasons",
                UpdatedBy = "Admin",
                CreatedBy = "testUser",
                CreatedDate = DateTime.UtcNow,
                IsDeleted = false,
                UpdatedDate = DateTime.UtcNow,
            };

            var mockResponse = new GenericResponse<string>
            {
                IsSuccess = true,
                HasError = false,
                StatusCode = ResponseStatus.STATUS_SUCCESS_Create,
                Result = ResponseMessage.STATUS_DATA_DELETED,
                Message = Resource.RecordUpdationMessage
            };

            _regionHelperMock.Setup(x => x.VerifyRegionCodeHeader(It.IsAny<HttpRequest>()))
                .Returns(new GenericResponse<string> { IsSuccess = true });

            _mockReasonQueryService.Setup(x => x.FindReasonsById(1))
                .ReturnsAsync(reasons);

            _mockReasonCommandService.Setup(x => x.DeleteReasonAsync(It.IsAny<byte[]>(), reasons))
                .ReturnsAsync(mockResponse); // Simulate successful deletion

            // Act
            var result = await _controller.DeleteReason(1);

            // Assert
            result.Should().BeOfType<OkObjectResult>();
            var okResult = result as OkObjectResult;
            okResult?.Value.Should().BeEquivalentTo(mockResponse);
        }

        [Fact]
        public async Task DeleteReason_ReturnsBadRequest_WhenRegionCodeIsInvalid()
        {
            // Arrange
            var mockedResponse = new GenericResponse<string>
            {
                IsSuccess = false,
                HasError = true,
                StatusCode = ResponseStatus.STATUS_BadRequest,
                Message = Resource.RegionCodeRequired
            };

            _regionHelperMock.Setup(x => x.VerifyRegionCodeHeader(It.IsAny<HttpRequest>()))
                .Returns(mockedResponse);

            // Act
            var result = await _controller.DeleteReason(1);

            // Assert
            result.Should().BeOfType<NotFoundObjectResult>();
        }

        [Fact]
        public async Task DeleteReason_ReturnsBadRequest_WhenModelStateIsInvalid()
        {
            // Arrange
            _controller.ModelState.AddModelError("RecordVersion", "The RecordVersion field is required.");

            _regionHelperMock.Setup(x => x.VerifyRegionCodeHeader(It.IsAny<HttpRequest>()))
                .Returns(new GenericResponse<string> { IsSuccess = true });

            // Act
            var result = await _controller.DeleteReason(1);

            // Assert
            result.Should().BeOfType<NotFoundObjectResult>();
        }
        [Fact]
        public async Task DeleteReason_ReturnsBadRequest_WhenDeletionFails()
        {
            // Arrange
            byte[] concurrencyToken = new byte[8] { 0, 0, 0, 0, 0, 0, 0, 1 };

            var reasons = new Domain.V1.Entities.Contents.Reasons
            {
                Id = 1,
                RecordVersion = concurrencyToken,
                Status = false,
                ContentID = 1,
                ResonType = "Reason test",
                UpdatedBy = "TestUser",
                CreatedBy = "Creator",
                CreatedDate = DateTime.UtcNow,
                IsDeleted = false,
                UpdatedDate = DateTime.UtcNow
            };

            var failedResponse = new GenericResponse<string>
            {
                IsSuccess = false,
                HasError = true,
                StatusCode = ResponseStatus.STATUS_InternalServerError,
                Message = "Failed to delete reason"
            };

            _regionHelperMock.Setup(x => x.VerifyRegionCodeHeader(It.IsAny<HttpRequest>()))
                .Returns(new GenericResponse<string> { IsSuccess = true });

            _mockReasonQueryService.Setup(x => x.FindReasonsById(1))
                .ReturnsAsync(reasons);

            _mockReasonCommandService.Setup(x => x.DeleteReasonAsync(It.IsAny<byte[]>(), reasons))
                .ReturnsAsync(failedResponse); // Simulate failure

            // Act
            var result = await _controller.DeleteReason(1);

            // Assert
            result.Should().BeOfType<BadRequestObjectResult>();
            var badRequestResult = result as BadRequestObjectResult;
            badRequestResult?.Value.Should().BeEquivalentTo(failedResponse);
        }
        [Fact]
        public async Task DeleteReason_ShouldStillDelete_WhenContentNavigationIsNull()
        {
            // Arrange
            byte[] concurrencyToken = new byte[8] { 0, 0, 0, 0, 0, 0, 0, 1 };

            var reasons = new Domain.V1.Entities.Contents.Reasons
            {
                Id = 2,
                ContentID = 100,
                ResonType = "Missing Content Navigation",
                Status = true,
                RecordVersion = concurrencyToken,
                IsDeleted = false,
                CreatedBy = "UnitTest",
                CreatedDate = DateTime.UtcNow,
                UpdatedBy = "UnitTest",
                UpdatedDate = DateTime.UtcNow,
                Content = null // Key part of this test
            };

            var mockDeleteResponse = new GenericResponse<string>
            {
                IsSuccess = true,
                Message = "Deleted successfully"
            };

            _regionHelperMock.Setup(x => x.VerifyRegionCodeHeader(It.IsAny<HttpRequest>()))
                .Returns(new GenericResponse<string> { IsSuccess = true });

            _mockReasonQueryService.Setup(x => x.FindReasonsById(2))
                .ReturnsAsync(reasons);

            _mockReasonCommandService.Setup(x => x.DeleteReasonAsync(It.IsAny<byte[]>(), reasons))
                .ReturnsAsync(mockDeleteResponse);

            // Act
            var result = await _controller.DeleteReason(2);

            // Assert
            result.Should().BeOfType<OkObjectResult>();
            var okResult = result as OkObjectResult;
            okResult?.Value.Should().BeEquivalentTo(mockDeleteResponse);
        }
        [Fact]
        public async Task GetReasonById_InvalidRegionCode_ReturnsBadRequest()
        {
            // Arrange
            _ = new Mock<IContentQueryService>();
            var regionHelperMock = new Mock<IRegionCodeValidationHelper>();
            var reasonCommandServiceMock = new Mock<IReasonsCommandService>();
            var controller = new ReasonController(reasonCommandServiceMock.Object, _mockReasonQueryService.Object, regionHelperMock.Object);

            regionHelperMock.Setup(x => x.VerifyRegionCodeHeader(It.IsAny<HttpRequest>()))
                .Returns(new GenericResponse<string> { HasError = true });

            // Act
            var result = await controller.GetReasonById(1);

            // Assert
            Assert.IsType<BadRequestObjectResult>(result.Result);
        }

        [Fact]
        public async Task GetReasonById_InvalidId_ReturnsBadRequest()
        {
            // Arrange

            var regionHelperMock = new Mock<IRegionCodeValidationHelper>();
            var reasonCommandServiceMock = new Mock<IReasonsCommandService>();
            var controller = new ReasonController(reasonCommandServiceMock.Object, _mockReasonQueryService.Object, regionHelperMock.Object);
            regionHelperMock.Setup(x => x.VerifyRegionCodeHeader(It.IsAny<HttpRequest>()))
                .Returns(new GenericResponse<string> { HasError = false });

            // Act
            var result = await controller.GetReasonById(null);
            var result2 = await controller.GetReasonById(0);
            var result3 = await controller.GetReasonById(-1);

            // Assert
            Assert.IsType<BadRequestObjectResult>(result.Result);
            Assert.IsType<BadRequestObjectResult>(result2.Result);
            Assert.IsType<BadRequestObjectResult>(result3.Result);
        }

        [Fact]
        public async Task GetReasonById_NotFound_ReturnsNotFound()
        {
            // Arrange
            var mockQueryService = new Mock<IReasonsQueryService>();
            var regionHelperMock = new Mock<IRegionCodeValidationHelper>();
            var reasonCommandServiceMock = new Mock<IReasonsCommandService>();
            var controller = new ReasonController(reasonCommandServiceMock.Object, _mockReasonQueryService.Object, regionHelperMock.Object);

            regionHelperMock.Setup(x => x.VerifyRegionCodeHeader(It.IsAny<HttpRequest>()))
                .Returns(new GenericResponse<string> { HasError = false });
            mockQueryService.Setup(x => x.GetReasonsById(1)).ReturnsAsync((GetReasonsDetailDto)null);

            // Act
            var result = await controller.GetReasonById(1);

            // Assert
            Assert.IsType<NotFoundObjectResult>(result.Result);
        }
        [Fact]
        public async Task GetReasonById_ReturnsOk_WhenContentExists()
        {
            // Arrange
            long Id = 1;

            var reasonData = new GetReasonsDetailDto
            {
                ContentID = 12,
                ResonType = "Not available",
                ReasonId = 1,
                RecordVersionReason = MockRecordVersion.Generate()
            };
            _mockReasonQueryService.Setup(x => x.GetReasonsById(Id))
                                    .ReturnsAsync(reasonData);

            // Act
            var result = await _controller.GetReasonById(Id);

            // Assert
            var okResult = Assert.IsType<OkObjectResult>(result.Result);
            var response = Assert.IsType<GenericResponse<GetReasonsDetailDto>>(okResult.Value);

            Assert.True(response.IsSuccess);
            Assert.Equal(ResponseStatusCode.STATUS_SUCCESS, response.StatusCode);
            Assert.Equal(ResponseMessage.STATUS_DATA_FOUND, response.Message);
            Assert.NotNull(response.Result);
            Assert.Equal(Id, response.Result.ReasonId);
        }

    }
}
