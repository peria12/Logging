﻿using Aurora.AdministrationService.API.Controllers.Content;
using Aurora.AdministrationService.API.Helper;
using Aurora.AdministrationService.API.Models.Dto.Content;
using Aurora.AdministrationService.API.Models.ResponseModels.Content;
using Aurora.AdministrationService.API.Resources;
using Aurora.AdministrationService.API.Services.IService.Content;
using Aurora.AdministrationService.CrossCutting.CommonModels;
using Aurora.AdministrationService.CrossCutting.Constants;
using Aurora.AdministrationService.CrossCutting.Extensions;
using Aurora.AdministrationService.Domain.V1.Entities.Contents;
using FluentAssertions;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Moq;
using ResponseStatus = Aurora.AdministrationService.CrossCutting.CommonModels.ResponseStatus;

namespace Aurora.AdministrationService.Tests.API.Controllers.Content
{
    public class ContentControllerTest
    {
        private readonly Mock<IContentCommandService> _mockContentCommandService;
        private readonly ContentController _controller;
        private readonly Mock<IContentQueryService> _mockContentQueryService;
        private readonly Mock<IRegionCodeValidationHelper> _regionHelperMock;
        public ContentControllerTest()
        {
            _regionHelperMock = new Mock<IRegionCodeValidationHelper>();
            _mockContentCommandService = new Mock<IContentCommandService>();
            _mockContentQueryService = new Mock<IContentQueryService>();
            _controller = new ContentController(_mockContentCommandService.Object, _mockContentQueryService.Object, _regionHelperMock.Object);
        }

        [Fact]
        public async Task CreateContentRecord_RegionHeaderVerificationFails_ReturnsBadRequest()
        {
            // Arrange
            var content = new AddContentDto()
            {
                Header = "test",
                PlatformsID = new List<ContentPlatformDto>
                {
                    new ContentPlatformDto
                    {
                        PlatformsID = "WEB"
                    }

                },
                Module = "appionment"
            };
            var regionHelperMock = new Mock<IRegionCodeValidationHelper>();
            var contentCommandServiceMock = new Mock<IContentCommandService>();
            var controller = new ContentController(contentCommandServiceMock.Object, _mockContentQueryService.Object, regionHelperMock.Object);
            var httpContext = new DefaultHttpContext();
            controller.ControllerContext = new ControllerContext() { HttpContext = httpContext };

            var errorResponse = new GenericResponse<string> { HasError = true, Message = "Region header error" };
            regionHelperMock.Setup(r => r.VerifyRegionCodeHeader(httpContext.Request)).Returns(errorResponse);

            // Act
            var result = await controller.CreateContentRecord(content);

            // Assert
            var badRequestResult = Assert.IsType<BadRequestObjectResult>(result);
            Assert.Equal(errorResponse, badRequestResult.Value);
        }


        [Fact]
        public async Task CreateContentRecord_ContentCreationSucceeds_ReturnsOkWithSuccessResponse()
        {
            // Arrange
            var request = new AddContentDto()
            {
                Header = "test",
                PlatformsID = new List<ContentPlatformDto>
                {
                    new ContentPlatformDto
                    {
                        PlatformsID = "WEB"
                    }

                },
                Module = "appionment",
                ReasonsDto = new List<AddReasonsDto>
            {
            new AddReasonsDto { ResonType = "Reason 1" }
            }
            };
            var mockResponse = new GenericResponse<AddContentDto>
            {
                IsSuccess = true,
                HasError = false,
                StatusCode = ResponseStatus.STATUS_SUCCESS,
                Message = "Content created successfully",
                Result = request
            };

            _regionHelperMock.Setup(x => x.VerifyRegionCodeHeader(It.IsAny<HttpRequest>()))
                .Returns(new GenericResponse<string>
                {
                    IsSuccess = true,
                    HasError = false,
                    StatusCode = ResponseStatus.STATUS_SUCCESS
                });

            _mockContentCommandService.Setup(x => x.CreateContentAsync(It.IsAny<AddContentDto>()))
                .ReturnsAsync(mockResponse);

            // Act
            var result = await _controller.CreateContentRecord(request);

            // Assert
            result.Should().BeOfType<OkObjectResult>();
        }


        //Get method unit service test

        [Fact]
        public async Task GetContentList_ValidRegionCode_ReturnsOkWithNoData()
        {
            // Arrange
            var query = new PaginationQuery(); // Define the missing 'query' parameter

            var regionHelperMock = new Mock<IRegionCodeValidationHelper>();
            var contentCommandServiceMock = new Mock<IContentCommandService>();
            var contentQueryServiceMock = new Mock<IContentQueryService>(); // define this locally

            var controller = new ContentController(contentCommandServiceMock.Object, contentQueryServiceMock.Object, regionHelperMock.Object);

            regionHelperMock.Setup(helper => helper.VerifyRegionCodeHeader(It.IsAny<HttpRequest>()))
                .Returns(new GenericResponse<string> { HasError = false });

            contentQueryServiceMock.Setup(x => x.GetAllContentAsync(It.IsAny<PaginationQuery>()))
                .ReturnsAsync(new List<GetContentDto>());

            // Act
            var result = await controller.GetContentList(query);

            // Assert
            var okResult = Assert.IsType<OkObjectResult>(result.Result);
            var response = Assert.IsType<GenericResponseList<GetContentDto>>(okResult.Value);
            Assert.Empty(response.Results);
            Assert.Equal(ResponseMessage.STATUS_NODATA, response.Message);
            Assert.Equal(CommonConstants.INFO, response.MessageType);
        }
        [Fact]
        public async Task GetContentList1_ValidRegionCode_ReturnsOkWithNoData()
        {
            // Arrange
            var query = new PaginationQuery(); // Define the missing 'query' parameter

            var regionHelperMock = new Mock<IRegionCodeValidationHelper>();
            var contentCommandServiceMock = new Mock<IContentCommandService>();
            var contentQueryServiceMock = new Mock<IContentQueryService>(); // define this locally

            var controller = new ContentController(contentCommandServiceMock.Object, contentQueryServiceMock.Object, regionHelperMock.Object);

            regionHelperMock.Setup(helper => helper.VerifyRegionCodeHeader(It.IsAny<HttpRequest>()))
                .Returns(new GenericResponse<string> { HasError = false });

            contentQueryServiceMock.Setup(x => x.GetAllContentAsync(It.IsAny<PaginationQuery>()))
                .ReturnsAsync(new List<GetContentDto>());

            // Act
            var result = await controller.GetContentList(query);

            // Assert
            var okResult = Assert.IsType<OkObjectResult>(result.Result);
            var response = Assert.IsType<GenericResponseList<GetContentDto>>(okResult.Value);
            Assert.Empty(response.Results);
            Assert.Equal(ResponseMessage.STATUS_NODATA, response.Message);
            Assert.Equal(CommonConstants.INFO, response.MessageType);
        }

        [Fact]
        public async Task GetContentless_InvalidRegionCode_ReturnsBadRequestlist()
        {
            // Arrange
            _ = new Mock<IContentQueryService>();
            var regionHelperMock = new Mock<IRegionCodeValidationHelper>();
            var contentCommandServiceMock = new Mock<IContentCommandService>();
            var controller = new ContentController(contentCommandServiceMock.Object, _mockContentQueryService.Object, regionHelperMock.Object);
            var contentQueryServiceMock = new Mock<IContentQueryService>(); // define this locally
            var query = new PaginationQuery(); // Define the missing 'query' parameter

            regionHelperMock.Setup(x => x.VerifyRegionCodeHeader(It.IsAny<HttpRequest>()))
                .Returns(new GenericResponse<string> { HasError = true });

            _mockContentQueryService.Setup(x => x.GetAllContentAsync(It.IsAny<PaginationQuery>()))
              .ReturnsAsync(new List<GetContentDto>());

            // Act
            var result = await controller.GetContentList(query);
            // Act



            // Assert
            Assert.IsType<BadRequestObjectResult>(result.Result);
        }

        [Fact]
        public async Task GetContentById_InvalidRegionCode_ReturnsBadRequest()
        {
            // Arrange
            _ = new Mock<IContentQueryService>();
            var regionHelperMock = new Mock<IRegionCodeValidationHelper>();
            var contentCommandServiceMock = new Mock<IContentCommandService>();
            var controller = new ContentController(contentCommandServiceMock.Object, _mockContentQueryService.Object, regionHelperMock.Object);

            regionHelperMock.Setup(x => x.VerifyRegionCodeHeader(It.IsAny<HttpRequest>()))
                .Returns(new GenericResponse<string> { HasError = true });

            // Act
            var result = await controller.GetContentById(1);

            // Assert
            Assert.IsType<BadRequestObjectResult>(result.Result);
        }

        [Fact]
        public async Task GetContentById_InvalidId_ReturnsBadRequest()
        {
            // Arrange
            _ = new Mock<IContentQueryService>();
            var regionHelperMock = new Mock<IRegionCodeValidationHelper>();
            var contentCommandServiceMock = new Mock<IContentCommandService>();
            var controller = new ContentController(contentCommandServiceMock.Object, _mockContentQueryService.Object, regionHelperMock.Object);
            regionHelperMock.Setup(x => x.VerifyRegionCodeHeader(It.IsAny<HttpRequest>()))
                .Returns(new GenericResponse<string> { HasError = false });

            // Act
            var result = await controller.GetContentById(null);
            var result2 = await controller.GetContentById(0);
            var result3 = await controller.GetContentById(-1);

            // Assert
            Assert.IsType<BadRequestObjectResult>(result.Result);
            Assert.IsType<BadRequestObjectResult>(result2.Result);
            Assert.IsType<BadRequestObjectResult>(result3.Result);
        }

        [Fact]
        public async Task GetContentById_NotFound_ReturnsNotFound()
        {
            // Arrange
            var mockQueryService = new Mock<IContentQueryService>();
            var regionHelperMock = new Mock<IRegionCodeValidationHelper>();
            var contentCommandServiceMock = new Mock<IContentCommandService>();
            var controller = new ContentController(contentCommandServiceMock.Object, _mockContentQueryService.Object, regionHelperMock.Object);

            regionHelperMock.Setup(x => x.VerifyRegionCodeHeader(It.IsAny<HttpRequest>()))
                .Returns(new GenericResponse<string> { HasError = false });
            mockQueryService.Setup(x => x.GetContentById(1)).ReturnsAsync((GetContentDetailDto)null);

            // Act
            var result = await controller.GetContentById(1);

            // Assert
            Assert.IsType<NotFoundObjectResult>(result.Result);
        }
        [Fact]
        public async Task GetContentById_ReturnsOk_WhenContentExists()
        {
            // Arrange
            long contentId = 12;
            var expectedContent = new GetContentDetailDto
            {
                Id = contentId,
                Module="m1",
                Header = "Header1",
                IsDeleted = false,
                RecordVersion = Array.Empty<byte>(),
                Status = true,
                reasonDtos = new List<GetReasonsDetailDto>
                {
                     new GetReasonsDetailDto
                     {
                         ContentID = 12,
                         ResonType = "Not available",
                         ReasonId = 1,
                         RecordVersionReason = MockRecordVersion.Generate()
                     }
                },
                contentPlatformDto= new List<GetContentPlatformDto>
            {
                new GetContentPlatformDto
                {
                    ID = 1,
                    ContentID = 112,
                    IsDeleted = false,
                    PlatformsID = "Patient App",
                    RecordVersion = new byte[] { 5, 6, 7, 8 }
                }
            }
            };
            _mockContentQueryService.Setup(x => x.GetContentById(contentId))
                                    .ReturnsAsync(expectedContent);

            // Act
            var result = await _controller.GetContentById(contentId);

            // Assert
            var okResult = Assert.IsType<OkObjectResult>(result.Result);
            var response = Assert.IsType<GenericResponse<GetContentDetailDto>>(okResult.Value);

            Assert.True(response.IsSuccess);
            Assert.Equal(ResponseStatusCode.STATUS_SUCCESS, response.StatusCode);
            Assert.Equal(ResponseMessage.STATUS_DATA_FOUND, response.Message);
            Assert.NotNull(response.Result);
            Assert.Equal(contentId, response.Result.Id);
        }

        [Fact]
        public void UpdateCountryMasterDetails_InvalidRegionCode_ReturnsBadRequest()
        {
            // Arrange
            byte[] concurrencyToken = new byte[8] { byte.MinValue, byte.MinValue, byte.MinValue, byte.MinValue, byte.MinValue, byte.MinValue, byte.MinValue, byte.MaxValue };

            var updateContentRecord = new UpdateContentRequestDto
            {
                Header = "test",
               
                Module = "appionment",
                RecordVersion = concurrencyToken,
                
                UpdateContentPlatformDto = new List<UpdateContentPlatformDto>
                {
                    new UpdateContentPlatformDto
                    {
                        ID = 2001,
                        PlatformsID = "WEB",
                        RecordVersion = concurrencyToken,
                        IsDeleted = false
                    }
                }
            };
            _regionHelperMock
                .Setup(helper => helper.VerifyRegionCodeHeader(It.IsAny<HttpRequest>()))
                .Returns(new GenericResponse<string> { HasError = true, Message = "Invalid RegionCode" });

            // Act
            var result = _controller.UpdateContentDetails(1, updateContentRecord);

            // Assert
            var badRequestResult = result?.Result as BadRequestObjectResult;
            badRequestResult.Should().NotBeNull();
            var response = badRequestResult?.Value as GenericResponse<string>;
            response.Should().NotBeNull();
            response?.HasError.Should().BeTrue();
            response?.Message.Should().Be("Invalid RegionCode");
        }

        [Fact]
        public async Task UpdateCountryMasterDetails_ShouldReturnBadRequest_WhenAlreadyExists()
        {
            // Arrange
            byte[] concurrencyToken = new byte[8] { byte.MinValue, byte.MinValue, byte.MinValue, byte.MinValue, byte.MinValue, byte.MinValue, byte.MinValue, byte.MaxValue };
            int id = 11;
            var contetdto = new UpdateContentRequestDto()
            {
                Header = "test",
               
                Module = "appionment",
                RecordVersion = concurrencyToken,
                UpdateContentPlatformDto = new List<UpdateContentPlatformDto>
                {
                    new UpdateContentPlatformDto
                    {
                        ID = 2001,
                        PlatformsID = "WEB",
                        RecordVersion = concurrencyToken,
                        IsDeleted = false
                    }
                }
            };

            // Act
            var result = await _controller.UpdateContentDetails(id, contetdto);

            // Assert
            result.Should().NotBeNull();
        }

        [Fact]
        public async Task UpdateContentMasterDetails_ContentMasterNotFound_ReturnsNotFound()
        {
            // Arrange
            byte[] concurrencyToken = new byte[8] { byte.MinValue, byte.MinValue, byte.MinValue, byte.MinValue, byte.MinValue, byte.MinValue, byte.MinValue, byte.MaxValue };
            int countryMasterId = 1;
            var contentRequest = new UpdateContentRequestDto()
            {
                Header = "test",
               
                Module = "appionment",

                RecordVersion = concurrencyToken,
                
                UpdateContentPlatformDto = new List<UpdateContentPlatformDto>
                {
                    new UpdateContentPlatformDto
                    {
                        ID = 2001,
                        PlatformsID = "WEB",
                        IsDeleted = false
                    }
                }
            };
            Domain.V1.Entities.Contents.Content countryMaster = null;
            _mockContentQueryService
                .Setup(service => service.FindContentById(countryMasterId))
                .ReturnsAsync(countryMaster);

            // Act
            var result = await _controller.UpdateContentDetails(countryMasterId, contentRequest);

            // Assert
            var actionResult = Assert.IsType<NotFoundObjectResult>(result);
            var response = Assert.IsType<GenericResponse<string>>(actionResult.Value);
            Assert.Equal(ResponseStatusCode.STATUS_NOTFOUND, response.StatusCode);
            Assert.Equal(ResponseMessage.STATUS_NODATA, response.Message);
        }

        [Fact]
        public async Task UpdateContentMasterDetails_UpdateSuccessful_ReturnsOk()
        {
            // Arrange
            byte[] concurrencyToken = new byte[8] { byte.MinValue, byte.MinValue, byte.MinValue, byte.MinValue, byte.MinValue, byte.MinValue, byte.MinValue, byte.MaxValue };
            int contentid = 12;
            var contentRequest = new UpdateContentRequestDto()
            {
                Header = "test",
                
                Module = "appionment",
                RecordVersion = concurrencyToken,
                
                UpdateContentPlatformDto = new List<UpdateContentPlatformDto>
                {
                    new UpdateContentPlatformDto
                    {
                        ID = 2001,
                        PlatformsID = "WEB",
                        IsDeleted = false
                    }
                }
            };
            var sourceReason = new List<Reasons>
            {
                new() {
                    ContentID = 12,
                    Status = true,
                    RecordVersion = concurrencyToken,
                    IsDeleted = false,
                    CreatedDate = DateTime.UtcNow,
                }

            };
            var existingContent = new Domain.V1.Entities.Contents.Content
            {
                Id = contentid,
                Status = true,
                Header = "Updated Header",
                CreatedBy = "Admin",
                CreatedDate = DateTime.UtcNow,
                IsDeleted = false,
                Module = "Updated Module",
                RecordVersion = concurrencyToken
            };
            var data = new GenericResponse<string>
            {
                HasError = false,
                IsSuccess = true,
                StatusCode = ResponseStatus.STATUS_SUCCESS_Create,
                Result = null,
                Message = ResponseMessage.WHATSHAPPENING_UPDATION_SUCCESS
            };

            _mockContentQueryService
                .Setup(service => service.FindContentById(contentid))
                .ReturnsAsync(existingContent);
            _mockContentQueryService
                .Setup(service => service.FindReasonsById(contentid))
                .ReturnsAsync(sourceReason);

            _mockContentCommandService
                .Setup(service => service.UpdateContentAsync(existingContent, contentRequest))
                .ReturnsAsync(data);

            // Act
            var result = await _controller.UpdateContentDetails(contentid, contentRequest);

            // Assert
            result.Should().NotBeNull();
            result.Should().BeOfType<OkObjectResult>();

            var okResult = result as OkObjectResult;
            okResult.Should().NotBeNull();
            okResult?.StatusCode.Should().Be(200);

            var response = okResult?.Value as GenericResponse<string>;
            response.Should().NotBeNull();
            response!.IsSuccess.Should().BeTrue();
            response.HasError.Should().BeFalse();
        }

        [Fact]
        public async Task UpdateContent_ReturnsBadRequest_WhenUpdatedFails()
        {
            // Arrange
            byte[] concurrencyToken = new byte[8] { byte.MinValue, byte.MinValue, byte.MinValue, byte.MinValue, byte.MinValue, byte.MinValue, byte.MinValue, byte.MaxValue };
            int cnontetId = 12;
            var contentRequest = new UpdateContentRequestDto()
            {
                Header = "test",
               Module = "appionment",
                RecordVersion = concurrencyToken,
                
                UpdateContentPlatformDto = new List<UpdateContentPlatformDto>
                {
                    new UpdateContentPlatformDto
                    {
                        ID = 2001,
                        PlatformsID = "WEB",
                        RecordVersion = concurrencyToken,
                        IsDeleted = false
                    }
                }
            };
            var sourceReason = new Reasons
            {
                ContentID = 12,
                Status = true,
                RecordVersion = concurrencyToken,
                IsDeleted = false,
                CreatedDate = DateTime.UtcNow,
            };
            var existingContent = new Domain.V1.Entities.Contents.Content
            {
                Id = cnontetId,
                Status = true,
                Header = "Updated Header",
                CreatedBy = "Admin",
                CreatedDate = DateTime.UtcNow,
                IsDeleted = false,
                Module = "Updated Module",
                RecordVersion = concurrencyToken
            };

            var mockResponse = new GenericResponse<string>
            {
                IsSuccess = false,
                HasError = true,
                StatusCode = ResponseStatus.STATUS_BadRequest,
                Message = "RecordVersion mismatch. Update failed."
            };

            _mockContentQueryService
                .Setup(service => service.FindContentById(cnontetId))
                .ReturnsAsync(existingContent);

            _mockContentCommandService
                .Setup(service => service.UpdateContentAsync(existingContent, contentRequest))
                .ReturnsAsync(mockResponse);

            // Act
            var result = await _controller.UpdateContentDetails(cnontetId, contentRequest);

            // Assert
            result.Should().BeOfType<BadRequestObjectResult>();
            var okResult = result as BadRequestObjectResult;
            okResult?.Value.Should().BeEquivalentTo(mockResponse);
        }

        [Fact]
        public async Task DeleteContent_ReturnsOk_WhenContentIsDeletedSuccessfully()
        {
            // Arrange
            byte[] concurrencyToken = new byte[8] { byte.MinValue, byte.MinValue, byte.MinValue, byte.MinValue, byte.MinValue, byte.MinValue, byte.MinValue, byte.MaxValue };

            var reasons = new List<Reasons>
            {
                new()
                {
                    Id = 12,
                    RecordVersion = concurrencyToken,
                    Status = false,
                    ContentID = 1,
                    ResonType = "Test Reasons",
                    UpdatedBy = "Admin",
                    CreatedBy = "testUser",
                    CreatedDate = DateTime.UtcNow,
                    IsDeleted = false,
                    UpdatedDate = DateTime.UtcNow,
                }

            };
            var content = new Domain.V1.Entities.Contents.Content
            {
                Id = 12,
                RecordVersion = concurrencyToken,
                Status = false,
                Header = "header",
                Module = "test module",
                UpdatedBy = "Admin",
                CreatedBy = "testUser",
                CreatedDate = DateTime.UtcNow,
                IsDeleted = false,
                UpdatedDate = DateTime.UtcNow,
            };
            var contentPlatform = new List<ContentPlatform>
            {
                new()
            {
                ID = 123,
                PlatformsID = "WEB",
                ContentID = 12,
                RecordVersion = concurrencyToken,
                UpdatedBy = "Admin",
                CreatedBy = "testUser",
                CreatedDate = DateTime.UtcNow,
                IsDeleted = false,
                UpdatedDate = DateTime.UtcNow,
            } };

            var mockResponse = new GenericResponse<string>
            {
                IsSuccess = true,
                HasError = false,
                StatusCode = ResponseStatus.STATUS_SUCCESS_Create,
                Result = ResponseMessage.STATUS_DATA_DELETED,
                Message = Resource.RecordUpdationMessage
            };

            _regionHelperMock.Setup(x => x.VerifyRegionCodeHeader(It.IsAny<HttpRequest>()))
                .Returns(new GenericResponse<string> { IsSuccess = true });
            _mockContentQueryService.Setup(x => x.FindContentById(12))
               .ReturnsAsync(content);

            _mockContentQueryService.Setup(x => x.FindReasonsById(12))
                .ReturnsAsync(reasons);
            _mockContentQueryService.Setup(x => x.FindContentPlatformById(12))
                .ReturnsAsync(contentPlatform);

            _mockContentCommandService.Setup(x => x.DeleteReasonAsync(It.IsAny<byte[]>(), It.IsAny<Reasons>()))
                .ReturnsAsync(mockResponse); // Simulate successful deletion

            _mockContentCommandService.Setup(x => x.DeleteContentAsync(It.IsAny<byte[]>(), content))
                .ReturnsAsync(mockResponse); // Simulate successful deletion

            // Act
            var result = await _controller.DeleteContent(12);

            // Assert
            result.Should().BeOfType<OkObjectResult>();
            var okResult = result as OkObjectResult;
            okResult?.Value.Should().BeEquivalentTo(mockResponse);
        }


        [Fact]
        public async Task DeleteContent_ReturnsNotFound_WhenContentIdNotFound()
        {
            // Arrange
            _ = new GenericResponse<string>
            {
                IsSuccess = false,
                HasError = true,
                StatusCode = ResponseStatus.STATUS_NotFound,
                Message = Resource.RecordNotFound,
                MessageType = CommonConstants.VALIDATION,
            };

            _regionHelperMock.Setup(x => x.VerifyRegionCodeHeader(It.IsAny<HttpRequest>()))
                .Returns(new GenericResponse<string> { IsSuccess = true });

            _mockContentQueryService.Setup(x => x.FindContentById(It.IsAny<long>()))
                .ReturnsAsync((Domain.V1.Entities.Contents.Content)null);

            // Act
            var result = await _controller.DeleteContent(999); // ID 999 does not exist

            // Assert
            result.Should().BeOfType<BadRequestObjectResult>();
            var notFoundResult = result as BadRequestObjectResult;
            notFoundResult?.Value.Should().NotBeNull();
        }

        [Fact]
        public async Task DeleteContent_ReturnsBadRequest_WhenRegionCodeIsInvalid()
        {
            // Arrange
            var mockedResponse = new GenericResponse<string>
            {
                IsSuccess = false,
                HasError = true,
                StatusCode = ResponseStatus.STATUS_BadRequest,
                Message = Resource.RegionCodeRequired
            };

            _regionHelperMock.Setup(x => x.VerifyRegionCodeHeader(It.IsAny<HttpRequest>()))
                .Returns(mockedResponse);

            // Act
            var result = await _controller.DeleteContent(1);

            // Assert
            result.Should().BeOfType<BadRequestObjectResult>();
        }

        [Fact]
        public async Task DeleteContent_ReturnsBadRequest_WhenModelStateIsInvalid()
        {
            // Arrange
            _controller.ModelState.AddModelError("RecordVersion", "The RecordVersion field is required.");

            _regionHelperMock.Setup(x => x.VerifyRegionCodeHeader(It.IsAny<HttpRequest>()))
                .Returns(new GenericResponse<string> { IsSuccess = true });

            // Act
            var result = await _controller.DeleteContent(1);

            // Assert
            result.Should().BeOfType<BadRequestObjectResult>();
        }

        [Fact]
        public void HandleResponse_ReturnsOk_WhenSuccessIsTrue()
        {
            // Arrange

            var response = new GenericResponse<string>
            {
                IsSuccess = true,
                Message = "All good"
            };

            // Act
            var result = _controller.HandleResponse(response);

            // Assert
            var okResult = Assert.IsType<OkObjectResult>(result);
            var value = Assert.IsType<GenericResponse<string>>(okResult.Value);
            Assert.True(value.IsSuccess);
        }
        [Fact]
        public void HandleResponse_ReturnsBadRequest_WhenSuccessIsFalse()
        {
            // Arrange            
            var response = new GenericResponse<string>
            {
                IsSuccess = false,
                Message = "Error"
            };

            // Act
            var result = _controller.HandleResponse(response);

            // Assert
            var badRequestResult = Assert.IsType<BadRequestObjectResult>(result);
            var value = Assert.IsType<GenericResponse<string>>(badRequestResult.Value);
            Assert.False(value.IsSuccess);
        }

        [Fact]
        public async Task GetContentBySearch_ShouldReturnBadRequest_WhenRegionCodeIsInvalid()
        {
            // Create a GenericResponse with the error information
            var invalidRegionCodeResponse = new GenericResponse<string>
            {
                HasError = true,
                StatusCode = ResponseStatusCode.STATUS_BADREQUEST,// Assuming 400 as BadRequest status code
                IsSuccess = false,
            };

            // Mock the region code validation to simulate an invalid region code
            _regionHelperMock
                .Setup(x => x.VerifyRegionCodeHeader(It.IsAny<HttpRequest>()))
                .Returns(invalidRegionCodeResponse);

            // Act
            var result = await _controller.GetContentSearch("Module1", "Platform1", 2, 5);

            // Assert
            result.Should().BeOfType<BadRequestObjectResult>()
                .Which.Value.Should().BeEquivalentTo(invalidRegionCodeResponse);
        }

        [Fact]
        public async Task GetContentBySearch_ShouldReturnOk_WhenContentFound()
        {
            // Arrange
            var data = new GenericResponse<PaginatedContentSearchResponseDto>
            {
                IsSuccess = true,
                HasError = false,
                Result = new PaginatedContentSearchResponseDto
                {
                    CurrentPage = 1,
                    PageSize = 10,
                    TotalRecords = 10,
                    Data = GetMockContentData()
                }
            };
            _regionHelperMock
                .Setup(helper => helper.VerifyRegionCodeHeader(It.IsAny<HttpRequest>()));

            //_mockContentQueryService
            //    .Setup(service => service.GetContentSearch(mockFilters))
            //    .ReturnsAsync(data);

            _mockContentQueryService
    .Setup(service => service.GetContentSearch(It.IsAny<ContentSearchRequest>()))
    .ReturnsAsync(data);

            // Act
            var result = await _controller.GetContentSearch("Module1", "platform1", 2, 5);

            // Assert
            result.Should().NotBeNull();
            result.Should().BeOfType<OkObjectResult>();

            var okResult = result as OkObjectResult;
            okResult.Should().NotBeNull();
            okResult!.StatusCode.Should().Be(200);

            var response = okResult.Value as GenericResponse<PaginatedContentSearchResponseDto>;
            response.Should().NotBeNull();
            response!.IsSuccess.Should().BeTrue();
            response.HasError.Should().BeFalse();
            response.Result.Should().NotBeNull();

            var paginatedData = response.Result;
            paginatedData!.Data.Should().NotBeNullOrEmpty();
            paginatedData.Data.Should().HaveCountGreaterThan(0);
        }

        private static List<ContentSearchResponse> GetMockContentData()
        {
            return new List<ContentSearchResponse>
            {
                new ContentSearchResponse
                {
                    Id = 1,
                    Module = "Module1",
                    Header = "Header1",
                    PlatformIDs = new List<string>{"platform1" },
                    UpdatedBy = "Seeder"
                },
                new ContentSearchResponse
                {

                    Id = 2,
                    Module = "Module2",
                    Header = "Header2",
                    PlatformIDs = new List<string>{"platform2" },
                    UpdatedBy = "Seeder"
                }
            };
        }

        [Fact]
        public async void GetContentMasters_InvalidRegionCode_ReturnsBadRequest()
        {
            // Arrange
            string selectedModule = "DeleteAccount";
            string selectedPlatformsID = "Patient App";

            _regionHelperMock
                .Setup(helper => helper.VerifyRegionCodeHeader(It.IsAny<HttpRequest>()))
                .Returns(new GenericResponse<string> { HasError = true, Message = "Invalid RegionCode" });

            // Act
            var result = await _controller.GetContentMasters(selectedModule, selectedPlatformsID);

            // Assert
            var badRequestResult = result.Result as BadRequestObjectResult;
            badRequestResult.Should().NotBeNull();
            var response = badRequestResult?.Value as GenericResponse<string>;
            response.Should().NotBeNull();
            response?.HasError.Should().BeTrue();
            response?.Message.Should().Be("Invalid RegionCode");
        }


        [Fact]
        public async void GetContentMasterList_ShouldReturnContentMasterList()
        {
            // Arrange
            string selectedModule = "DeleteAccount";
            string selectedPlatformsID = "Patient App";


            var contentMasterList = new List<GetContentMasterDto> { new GetContentMasterDto() { Id=1, Header="test" } };
            _mockContentQueryService.Setup(service => service.GetContentMasters(selectedModule, selectedPlatformsID)).ReturnsAsync(contentMasterList);

            // Act
            var result = await _controller.GetContentMasters(selectedModule, selectedPlatformsID);
            var okresult = result?.Result as OkObjectResult;
            var response = okresult?.Value as GenericResponseList<GetContentMasterDto>;

            // Assert
            result.Should().NotBeNull();
            response?.StatusCode.Should().Be("200");
            response?.IsSuccess.Should().BeTrue();
            response?.StatusCode.Should().Be(ResponseStatusCode.STATUS_SUCCESS);
            response?.Message.Should().Be(ResponseMessage.STATUS_DATA_FOUND);
            response?.TotalCount.Should().Be(contentMasterList.Count);

        }



    }
}