﻿using System.Text;
using Aurora.AdministrationService.API.Controllers.ServiceChargeMasters;
using Aurora.AdministrationService.API.Models.Dto.ServiceChargeMasters;
using Aurora.AdministrationService.API.Services.IService.ServiceChargeMasters;
using Aurora.AdministrationService.CrossCutting.CommonModels;
using Aurora.AdministrationService.CrossCutting.Constants;
using Aurora.AdministrationService.Domain.V1.Entities.ServiceChargeMasters;
using AutoMapper;
using FluentAssertions;
using Microsoft.AspNetCore.Mvc;
using Moq;

namespace Aurora.AdministrationService.Tests.API.Controllers.ServiceChargeMasters
{
    public class ServiceChargeMasterControllerTests
    {
        private readonly Mock<IServiceChargeMasterQueryService> _mockQueryService;
        private readonly Mock<IServiceChargeMasterCommandService> _mockCommandService;
        private readonly Mock<IMapper> _mockMapper;
        private readonly ServiceChargeMasterController _controller;

        public ServiceChargeMasterControllerTests()
        {
            _mockQueryService = new Mock<IServiceChargeMasterQueryService>();
            _mockCommandService = new Mock<IServiceChargeMasterCommandService>();
            _mockMapper = new Mock<IMapper>();

            _controller = new ServiceChargeMasterController
            (

                _mockCommandService.Object, _mockQueryService.Object,_mockMapper.Object
            );
        }

        [Theory]
        [InlineData(true, ResponseMessage.STATUS_DATA_UPDATED)]  // Update scenario
        [InlineData(false, ResponseMessage.STATUS_DATA_ADDED)]   // Add scenario
        public async Task AddOrUpdateServiceChargeMaster_ShouldReturnCorrectResponse(bool doesExist, string expectedMessage)
        {
            // Arrange
            var serviceChargeMasterDto = CommonMockData.GetMockServiceChargeMasterDto(); // Mock DTO

            var existingServiceEntity = doesExist ? new ServiceChargeMaster
            {
                ItemCode = serviceChargeMasterDto.ItemCode,
                TestCode = serviceChargeMasterDto.TestCode,
                ItemDescription = serviceChargeMasterDto.ItemDescription,
                RecordVersion = Array.Empty<byte>(),
                IsDeleted = false,
                CreatedDate = DateTime.UtcNow.AddDays(-1),
                CreatedBy = "TestUser"
            } : null;

            _mockQueryService.Setup(q => q.CheckExistingServiceChargeMasterAsync(serviceChargeMasterDto.ItemCode))
                .ReturnsAsync(existingServiceEntity!);

            if (doesExist)
            {
                var updateRequest = _mockMapper.Object.Map<UpdateServiceChargeMasterRequest>(serviceChargeMasterDto);
                _mockMapper.Setup(m => m.Map<UpdateServiceChargeMasterRequest>(serviceChargeMasterDto))
                    .Returns(updateRequest);

                _mockCommandService.Setup(c => c.UpdateServiceChargeMasterAsync(updateRequest, It.IsAny<ServiceChargeMaster>()))
                    .ReturnsAsync(new ServiceChargeMasterDto());
            }
            else
            {
                var newRequest = _mockMapper.Object.Map<CreateServiceChargeMasterRequest>(serviceChargeMasterDto);
                _mockMapper.Setup(m => m.Map<CreateServiceChargeMasterRequest>(serviceChargeMasterDto))
                    .Returns(newRequest);

                _mockCommandService.Setup(c => c.AddServiceChargeMasterAsync(newRequest))
                    .ReturnsAsync(new ServiceChargeMasterDto());
            }

            // Act
            var result = await _controller.AddOrUpdateServiceChargeMaster(serviceChargeMasterDto);

            // Assert
            var okResult = result.Should().BeOfType<OkObjectResult>().Subject;
            var response = okResult.Value.Should().BeOfType<GenericResponse<string>>().Subject;

            response.IsSuccess.Should().BeTrue();
            response.StatusCode.Should().Be(ResponseStatusCode.STATUS_SUCCESS);

            response.Message.Should().Be(expectedMessage);

            response.HasError.Should().BeFalse();
            response.MessageType.Should().Be(CommonConstants.SUCCESS);

            if (doesExist)
            {
                _mockCommandService.Verify(c => c.UpdateServiceChargeMasterAsync(It.IsAny<UpdateServiceChargeMasterRequest>(), It.IsAny<ServiceChargeMaster>()), Times.Once);
                _mockCommandService.Verify(c => c.AddServiceChargeMasterAsync(It.IsAny<CreateServiceChargeMasterRequest>()), Times.Never);
            }
            else
            {
                _mockCommandService.Verify(c => c.AddServiceChargeMasterAsync(It.IsAny<CreateServiceChargeMasterRequest>()), Times.Once);
                _mockCommandService.Verify(c => c.UpdateServiceChargeMasterAsync(It.IsAny<UpdateServiceChargeMasterRequest>(), It.IsAny<ServiceChargeMaster>()), Times.Never);
            }
        }


        [Fact]
        public async Task AddOrUpdateServiceChargeMaster_ShouldReturnBadRequest_WhenModelStateIsInvalid()
        {
            // Arrange
            _controller.ModelState.AddModelError("ItemCode", "ItemCode is required");

            var serviceChargeMasterDto = new ServiceChargeMasterDto
            {
                ItemCode = "SCM001",
                TestCode = "Test001",
                ItemDescription = "Sample Item"
            };

            // Act
            var result = await _controller.AddOrUpdateServiceChargeMaster(serviceChargeMasterDto);

            // Assert
            var badRequestResult = result.Should().BeOfType<BadRequestObjectResult>().Subject;
            var modelState = badRequestResult.Value.Should().BeOfType<SerializableError>().Subject;
            modelState.Should().ContainKey("ItemCode");
        }

        [Fact]
        public async Task DeleteServiceChargeMaster_ShouldReturnSuccess_WhenRecordExists()
        {
            // Arrange
            var itemCode = "SER123";
            var existingService = new ServiceChargeMaster
            {
                ItemCode = "SCM001",
                TestCode = "Test001",
                ItemDescription = "Sample Item", // Required property
                RecordVersion = Encoding.UTF8.GetBytes("1") ,
                IsDeleted = false,
                CreatedDate = DateTime.UtcNow,
                CreatedBy = "TestUser1"// Corrected for byte[] type
            };

            _mockQueryService.Setup(q => q.CheckExistingServiceChargeMasterAsync(itemCode))
                .ReturnsAsync(existingService);

            _mockCommandService.Setup(c => c.DeleteServiceChargeMasterAsync(existingService.RecordVersion, existingService))
                .ReturnsAsync(true);

            // Act
            var result = await _controller.DeleteServiceChargeMaster(itemCode);

            // Assert
            var okResult = result.Should().BeOfType<OkObjectResult>().Subject;
            var response = okResult.Value.Should().BeOfType<GenericResponse<string>>().Subject;

            response.IsSuccess.Should().BeTrue();
            response.StatusCode.Should().Be(ResponseStatusCode.STATUS_SUCCESS);
            response.Message.Should().Be(ResponseMessage.STATUS_DATA_DELETED);
            response.HasError.Should().BeFalse();
            response.MessageType.Should().Be(CommonConstants.SUCCESS);

            _mockQueryService.Verify(q => q.CheckExistingServiceChargeMasterAsync(itemCode), Times.Once);
            _mockCommandService.Verify(c => c.DeleteServiceChargeMasterAsync(existingService.RecordVersion, existingService), Times.Once);
        }

        [Fact]
        public async Task DeleteServiceChargeMaster_ShouldReturnNotFound_WhenRecordDoesNotExist()
        {
            // Arrange
            var itemCode = "INVALID_Service";

            _mockQueryService.Setup(q => q.CheckExistingServiceChargeMasterAsync(itemCode))
                .ReturnsAsync((ServiceChargeMaster)null!);

            // Act
            var result = await _controller.DeleteServiceChargeMaster(itemCode);

            // Assert
            var notFoundResult = result.Should().BeOfType<NotFoundObjectResult>().Subject;
            var response = notFoundResult.Value.Should().BeOfType<GenericResponse<string>>().Subject;

            response.IsSuccess.Should().BeFalse();
            response.StatusCode.Should().Be(ResponseStatusCode.STATUS_NOTFOUND);
            response.Message.Should().Be(ResponseMessage.STATUS_NODATA);
            response.HasError.Should().BeTrue();
            response.MessageType.Should().Be(CommonConstants.ERROR);

            _mockQueryService.Verify(q => q.CheckExistingServiceChargeMasterAsync(itemCode), Times.Once);
            _mockCommandService.Verify(c => c.DeleteServiceChargeMasterAsync(It.IsAny<byte[]>(), It.IsAny<ServiceChargeMaster>()), Times.Never);
        }

        [Fact]
        public async Task GetServiceChargeMasterById_ShouldReturnNotFound_WhenRecordDoesNotExist()
        {
            // Arrange
            var id = 999;  // Non-existent ID
            _mockQueryService.Setup(q => q.GetServiceChargeMasterById(id))
                .ReturnsAsync((GetServiceChargeMasterDto?)null!);

            // Act
            var result = await _controller.GetServiceChargeById(id);

            // Assert
            var notFoundResult = result.Should().BeOfType<NotFoundObjectResult>().Subject;
            var response = notFoundResult.Value.Should().BeOfType<GenericResponse<string>>().Subject;

            response.IsSuccess.Should().BeFalse();
            response.StatusCode.Should().Be(ResponseStatusCode.STATUS_NOTFOUND);
            response.Message.Should().Be(ResponseMessage.STATUS_NODATA);
            response.HasError.Should().BeTrue();
            response.MessageType.Should().Be(CommonConstants.ERROR);

            _mockQueryService.Verify(q => q.GetServiceChargeMasterById(id), Times.Once);
        }

        [Fact]
        public async Task GetServiceChargeMasterById_ShouldReturnOk_WhenRecordExists()
        {
            // Arrange
            var id = 123; // Existing ID
            var serviceChargeMasterDetail = new GetServiceChargeMasterDto
            {
                ItemCode = "Ser123",
                TestCode = "Test123",
                MasterType = "General",
                IsDeleted = false,
                CreatedDate = DateTime.UtcNow,
                CreatedBy = "TestUser"
            };

            _mockQueryService.Setup(q => q.GetServiceChargeMasterById(id))
                .ReturnsAsync(serviceChargeMasterDetail);

            // Act
            var result = await _controller.GetServiceChargeById(id);

            // Assert
            var okResult = result.Should().BeOfType<OkObjectResult>().Subject;
            var response = okResult.Value.Should().BeOfType<GenericResponse<GetServiceChargeMasterDto>>().Subject;

            response.IsSuccess.Should().BeTrue();
            response.StatusCode.Should().Be(ResponseStatusCode.STATUS_SUCCESS);
            response.Message.Should().Be(ResponseMessage.STATUS_DATA_FOUND);
            response.HasError.Should().BeFalse();
            response.MessageType.Should().Be(CommonConstants.SUCCESS);
            response.Result.Should().NotBeNull();
            response.Result?.ItemCode.Should().Be("Ser123");
            response.Result?.TestCode.Should().Be("Test123");

            _mockQueryService.Verify(q => q.GetServiceChargeMasterById(id), Times.Once);
        }

        [Fact]
        public async Task GetServiceChargeMasterList_ShouldReturnNotFound_WhenNoRecordsExist()
        {
   
            // Arrange
            _mockQueryService.Setup(q => q.GetServiceChargeMasterList())
                .ReturnsAsync((List<GetServiceChargeMasterDto>?)null!); // Explicitly mark as nullable

            // Act
            var result = await _controller.GetServiceChargeList();

            // Assert
            var notFoundResult = result.Should().BeOfType<NotFoundObjectResult>().Subject;
            var response = notFoundResult.Value.Should().BeOfType<GenericResponse<string>>().Subject;

            response.IsSuccess.Should().BeFalse();
            response.StatusCode.Should().Be(ResponseStatusCode.STATUS_NOTFOUND);
            response.Message.Should().Be(ResponseMessage.STATUS_NODATA);
            response.HasError.Should().BeTrue();
            response.MessageType.Should().Be(CommonConstants.ERROR);

            _mockQueryService.Verify(q => q.GetServiceChargeMasterList(), Times.Once);
        }

        [Fact]
        public async Task GetServiceChargeMasterList_ShouldReturnNotFound_WhenListIsEmpty()
        {
            // Arrange
            _mockQueryService.Setup(q => q.GetServiceChargeMasterList())
                .ReturnsAsync(new List<GetServiceChargeMasterDto>()); // Empty list

            // Act
            var result = await _controller.GetServiceChargeList();

            // Assert
            var notFoundResult = result.Should().BeOfType<NotFoundObjectResult>().Subject;
            var response = notFoundResult.Value.Should().BeOfType<GenericResponse<string>>().Subject;

            response.IsSuccess.Should().BeFalse();
            response.StatusCode.Should().Be(ResponseStatusCode.STATUS_NOTFOUND);
            response.Message.Should().Be(ResponseMessage.STATUS_NODATA);
            response.HasError.Should().BeTrue();
            response.MessageType.Should().Be(CommonConstants.ERROR);

            _mockQueryService.Verify(q => q.GetServiceChargeMasterList(), Times.Once);
        }

        [Fact]
        public async Task GetServiceChargeMasterList_ShouldReturnOk_WhenRecordsExist()
        {
            // Arrange
            var serviceChargeMasterList = new List<GetServiceChargeMasterDto>
            {
                new GetServiceChargeMasterDto
                {
                  ItemCode = "Ser123",
                    TestCode = "Test123",
                    MasterType = "General",
                    IsDeleted = false,
                    CreatedDate = DateTime.UtcNow,
                    CreatedBy = "TestUser"
                },
                new GetServiceChargeMasterDto
                {
                   ItemCode = "Ser123123",
                    TestCode = "Test11223",
                    MasterType = "General",
                    IsDeleted = false,
                    CreatedDate = DateTime.UtcNow,
                    CreatedBy = "TestUser"
                }
            };

            _mockQueryService.Setup(q => q.GetServiceChargeMasterList())
                .ReturnsAsync(serviceChargeMasterList);

            // Act
            var result = await _controller.GetServiceChargeList();

            // Assert
            var okResult = result.Should().BeOfType<OkObjectResult>().Subject;
            var response = okResult.Value.Should().BeOfType<GenericResponse<List<GetServiceChargeMasterDto>>>().Subject;
            response.IsSuccess.Should().BeTrue();
            response.StatusCode.Should().Be(ResponseStatusCode.STATUS_SUCCESS);
            response.Message.Should().Be(ResponseMessage.STATUS_DATA_FOUND);
            response.HasError.Should().BeFalse();
            response.MessageType.Should().Be(CommonConstants.SUCCESS);
            response.Result.Should().NotBeNullOrEmpty();
            response.Result.Should().HaveCount(2);
            response.Result?[0].ItemCode.Should().Be("Ser123");
            response.Result?[^1].ItemCode.Should().Be("Ser123123");
            _mockQueryService.Verify(q => q.GetServiceChargeMasterList(), Times.Once);
        }
    }
}