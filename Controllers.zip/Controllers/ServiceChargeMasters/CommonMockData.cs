﻿using Aurora.AdministrationService.API.Models.Dto.ServiceChargeMasters;
using Aurora.AdministrationService.Domain.V1.Entities.ServiceChargeMasters;

namespace Aurora.AdministrationService.Tests.API.Controllers.ServiceChargeMasters
{
    public static class CommonMockData
    {
        public static ServiceChargeMaster GetMockServiceChargeMaster()
        {
            return new ServiceChargeMaster
            {
                MasterType = "TypeA",
                ItemCode = "Item001",
                ItemDescription = "Service Charge Master Description",
                ItemTypeCode = "Type001",
                ItemTypeDescription = "Service Item Type Description",
                TestCode = "Test001",
                TestDescription = "Test Description",
                ServiceType = "Lab",
                Category = "Diagnostic",
                Department = "Pathology",
                TurnAroundTime = 24,
                Restricted = false,
                TestMethodAvailable = "PCR, Rapid Test",
                FacilityCode = "FAC123",
                CreatedBy = "Admin",
                UpdatedBy = "Admin",
                CreatedDate = DateTime.UtcNow,
                UpdatedDate = DateTime.UtcNow,
                IsDeleted = false,
                RecordVersion = new byte[] { 1, 2, 3, 4 }
            };
        }

        public static ServiceChargeMasterDto GetMockServiceChargeMasterDto()
        {
            return new ServiceChargeMasterDto
            {
                MasterType = "TypeA",
                ItemCode = "TestItem123",  // Ensure it's not null
                TestCode = "TestCode456",  // Ensure it's not null
                ItemDescription = "Service Charge Master Description",
                ItemTypeCode = "Type001",
                ItemTypeDescription = "Service Item Type Description",
                TestDescription = "Test Description",
                ServiceType = "Lab",
                Category = "Diagnostic",
                Department = "Pathology",
                TurnAroundTime = 24,
                Restricted = false,
                TestMethodAvailable = "PCR, Rapid Test",
                FacilityCode = "FAC123",
                SourceAppId = 1001,
                Title = "Service Charge Master",
                EventAction = "Create",
                RequestedDate = DateTime.UtcNow,
                RegionCode = "US",
                LanguageCode = "EN",
                LocationCode = "LOC123",
                AcknowledgementID = "ACK123"
            };
        }

        public static ServiceChargeMaster GetMockServiceChargeMaster2(long id = 2)
        {
            return new ServiceChargeMaster
            {
                ID = 2,
                MasterType = "TypeA",
                ItemCode = "Item002",
                ItemDescription = "Service Charge Master Description",
                ItemTypeCode = "Type001",
                ItemTypeDescription = "Service Item Type Description",
                TestCode = "Test002",
                TestDescription = "Test Description",
                ServiceType = "Lab",
                Category = "Diagnostic",
                Department = "Pathology",
                TurnAroundTime = 24,
                Restricted = false,
                TestMethodAvailable = "PCR, Rapid Test",
                FacilityCode = "FAC123",
                CreatedBy = "Admin",
                UpdatedBy = "Admin",
                CreatedDate = DateTime.UtcNow,
                UpdatedDate = DateTime.UtcNow,
                IsDeleted = false,
                RecordVersion = new byte[] { 1, 2, 3, 4 }
            };
        }

        public static CreateServiceChargeMasterRequest GetMockCreateServiceChargeMasterRequest()
        {
            var mockDto = GetMockServiceChargeMasterDto();
            return new CreateServiceChargeMasterRequest
            {
                MasterType = mockDto.MasterType,
                ItemCode = mockDto.ItemCode,
                ItemDescription = mockDto.ItemDescription,
                ItemTypeCode = mockDto.ItemTypeCode,
                ItemTypeDescription = mockDto.ItemTypeDescription,
                TestCode = mockDto.TestCode,
                TestDescription = mockDto.TestDescription,
                ServiceType = mockDto.ServiceType,
                Category = mockDto.Category,
                Department = mockDto.Department,

            };
        }

        public static ServiceChargeMaster GetMockServiceChargeMaster3(long id=5)
        {
            return new ServiceChargeMaster
            {
                ID = 5,
                MasterType = "TypeA",
                ItemCode = "Item005",
                ItemDescription = "Service Charge Master Description",
                ItemTypeCode = "Type001",
                ItemTypeDescription = "Service Item Type Description",
                TestCode = "Test005",
                TestDescription = "Test Description",
                ServiceType = "Lab",
                Category = "Diagnostic",
                Department = "Pathology",
                TurnAroundTime = 24,
                Restricted = false,
                TestMethodAvailable = "PCR, Rapid Test",
                FacilityCode = "FAC123",
                CreatedBy = "Admin",
                UpdatedBy = "Admin",
                CreatedDate = DateTime.UtcNow,
                UpdatedDate = DateTime.UtcNow,
                IsDeleted = false,
                RecordVersion = new byte[] { 1, 2, 3, 4 }
            };
        }

        public static UpdateServiceChargeMasterRequest GetMockUpdateServiceChargeMasterRequest(string itemCode, byte[]? recordVersion = null, string testCode = "UpdatedTestCode")
        {
            var mockDto = GetMockServiceChargeMasterDto();
            return new UpdateServiceChargeMasterRequest
            {
                MasterType = mockDto.MasterType,
                ItemCode = itemCode,
                ItemDescription = mockDto.ItemDescription,
                ItemTypeCode = mockDto.ItemTypeCode,
                ItemTypeDescription = mockDto.ItemTypeDescription,
                TestCode = testCode,
                TestDescription = mockDto.TestDescription,
                ServiceType = mockDto.ServiceType,
                Category = mockDto.Category,
                Department = mockDto.Department,
                TurnAroundTime = mockDto.TurnAroundTime,
                Restricted = mockDto.Restricted,
                TestMethodAvailable = mockDto.TestMethodAvailable,
                FacilityCode = mockDto.FacilityCode,
                RecordVersion = recordVersion ?? new byte[] { 1, 2, 3, 4 } // Use provided recordVersion or default
            };
        }
    }
}
