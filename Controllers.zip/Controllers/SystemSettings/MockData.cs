﻿using Aurora.AdministrationService.Domain.Old.Entities;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Aurora.AdministrationService.Tests.API.Controllers.SystemSettings
{
    public class MockData
    {
        public static IEnumerable<SystemSettingsDto> GetModules()
        {
            return new List<SystemSettingsDto>
        {
            new SystemSettingsDto
            {
                ModuleName = "BannerClickReports",
                IsNewlyUpdated = true
            },
            new SystemSettingsDto
            {
                ModuleName = "AdminDoctorProfiles",
                IsNewlyUpdated = false
            },
            new SystemSettingsDto
            {
                ModuleName = "Agreements",
                IsNewlyUpdated = true
            },
            new SystemSettingsDto
            {
                ModuleName = "WhatsHappenings",
                IsNewlyUpdated = false
            }
        };
        }
    }
}
