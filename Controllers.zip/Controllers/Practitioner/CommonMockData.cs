﻿using Aurora.AdministrationService.API.Models.Dto.Practitioners;
using Aurora.AdministrationService.Domain.V1.Entities.Practitioners;

namespace Aurora.AdministrationService.Tests.API.Controllers.Practitioner
{
    public class CommonMockData
    {
        public static UpdatePractitionerDetailDto GetMockPractitionerDetailAsync()
        {
            
            byte[] concurrencyToken = new byte[8] { byte.MinValue, byte.MinValue, byte.MinValue, byte.MinValue, byte.MinValue, byte.MinValue, byte.MinValue, byte.MaxValue };
            var practitioner = new Domain.V1.Entities.Practitioners.Practitioner
            {
                Id = 1,
                ResourceID = "123",
                Status = true,
                BirthDate = DateTime.UtcNow,
                Gender = "Male",
                Source = "test",
                IsDeleted = false,
                CreatedBy = "Admin",
                CreatedDate = DateTime.UtcNow,
                UpdatedBy = "Admin",  // Adding the missing property
                UpdatedDate = DateTime.UtcNow,// Assuming UpdatedDate is required as well
                RecordVersion = concurrencyToken
            };

            var practitionerAddress = new PractitionerAddresses()
            {
                PractitionerID = 1,
                City = "test",
                Country = "test",
                District = "test",
                Id = 1,
                Line1 = "test",
                Line2 = "test",
                Line3 = "test",
                Line4 = "test",
                State = "test",
                Type = "test",
                PeriodEnd = DateTime.UtcNow,
                PeriodStart = DateTime.UtcNow,
                PostalCode = "test",
                Status = true,
                Use = "test",
                IsDeleted = false,
                CreatedBy = "Admin",
                CreatedDate = DateTime.UtcNow,
                UpdatedBy = "Admin",  // Adding the missing property
                UpdatedDate = DateTime.UtcNow,// Assuming UpdatedDate is required as well
                RecordVersion = concurrencyToken
            };

            var practitionerName = new PractitionerNames()
            {
                PractitionerID = 1,
                Status = true,
                Use = "test",
                Id = 1,
                PeriodStart = DateTime.UtcNow,
                PeriodEnd = DateTime.UtcNow,
                FamilyName = "test",
                GivenName = "test",
                Language = "test",
                MiddleName = "test",
                Prefix = "test",
                Suffix = "test",
                IsDeleted = false,
                CreatedBy = "Admin",
                CreatedDate = DateTime.UtcNow,
                UpdatedBy = "Admin",  // Adding the missing property
                UpdatedDate = DateTime.UtcNow,// Assuming UpdatedDate is required as well
                RecordVersion = concurrencyToken
            };
            var practitionerIdentifiers = new PractitionerIdentifier()
            {
                PractitionerID = 1,
                Status = true,
                IdentifierUse = "test",
                System = "test",
                Value = "test",
                Id = 1,
                IdentifierType = "test",
                PeriodEnd = DateTime.UtcNow,
                PeriodStart = DateTime.UtcNow,
                IsDeleted = false,
                CreatedBy = "Admin",
                CreatedDate = DateTime.UtcNow,
                UpdatedBy = "Admin",  // Adding the missing property
                UpdatedDate = DateTime.UtcNow,// Assuming UpdatedDate is required as well
                RecordVersion = concurrencyToken
            };
            var practitionerTelecom = new PractitionerTelecom()
            {
                PractitionerID = 1,
                Status = true,
                System = "test",
                Use = "test",
                Value = "test",
                Id = 1,
                PeriodStart = DateTime.UtcNow,
                PeriodEnd = DateTime.UtcNow,
                Rank = 1,
                IsDeleted = false,
                CreatedBy = "Admin",
                CreatedDate = DateTime.UtcNow,
                UpdatedBy = "Admin",  // Adding the missing property
                UpdatedDate = DateTime.UtcNow,// Assuming UpdatedDate is required as well
                RecordVersion = concurrencyToken
            };
            return new UpdatePractitionerDetailDto()
            {
                PractitionerDetail = practitioner,
                PractitionerAddressDetail = practitionerAddress,
                PractitionerIdentifiers = new List<PractitionerIdentifier>() { practitionerIdentifiers },
                PractitionerNamesDetail = practitionerName,
                PractitionerTelecomDetails = new List<PractitionerTelecom>() { practitionerTelecom },
            };

        }
        public static PractitionerDetailDto GetMockPractitionerDetailDto()
        {
            PractitionerAddressDetailDto practitionerAddressDetailDto = new PractitionerAddressDetailDto()
            {
                Use = "test",
                City = "test",
                Country = "test",
                District = "test",
                Line1 = "test",
                Line2 = "test",
                Line3 = "test",
                Line4 = "test",
                PeriodEnd = DateTime.UtcNow,
                PeriodStart = DateTime.UtcNow,
                PostalCode = "test",
                State = "test",
                Type = "test",
            };
            List<PractitionerTelecomDetailDto> practitionerTelecomDetails = new List<PractitionerTelecomDetailDto>()
            {
                new PractitionerTelecomDetailDto ()
                {
                   PhoneCountryCode = "test",
                   System="Phone",
                   Use="test",
                   Value="test",
                   PeriodEnd= DateTime.UtcNow,
                   PeriodStart= DateTime.UtcNow,
                   Rank=1

                }
            };
            List<PractitionerIdentifierDto> practitionerIdentifiers = new List<PractitionerIdentifierDto>() 
            { 
                 new PractitionerIdentifierDto ()
                 {
                   System="test",
                   IdentifierUse="test",
                   PeriodStart=DateTime.UtcNow,
                   PeriodEnd=DateTime.UtcNow,
                   IdentifierType="test",
                   Value="test",
                 }
            
            };
            PractitionerNamesDetailDto practitionerNamesDetail = new PractitionerNamesDetailDto()
            {
                Use = "test",
                PeriodEnd = DateTime.UtcNow,
                PeriodStart = DateTime.UtcNow,
                FamilyName = "test",
                GivenName = "test",
                Language = "test",
                MiddleName = "test",
                Prefix = "test",
                Suffix = "test"

            };
            PractitionerDetailDto practitionerDetailDto = new PractitionerDetailDto()
            {
                Email = "test",
                Qualification = "test",
                ResourceID = "111",
                Status = true,
                Source = "test",
                BirthDate = DateTime.UtcNow,
                Gender = "test",
                TelecomDetails = practitionerTelecomDetails,
                Identifiers = practitionerIdentifiers,
                AddressDetail = practitionerAddressDetailDto,
                PractitionerNamesDetail = practitionerNamesDetail
            };
            return practitionerDetailDto;
        }
    }
}
