﻿using Aurora.AdministrationService.API.Controllers.Practitioner;
using Aurora.AdministrationService.API.Helper;
using Aurora.AdministrationService.API.Models.Dto.Practitioners;
using Aurora.AdministrationService.API.Models.ResponseModels.Practitioners;
using Aurora.AdministrationService.API.Services.IService.Practitioners;
using Aurora.AdministrationService.CrossCutting.CommonModels;
using Aurora.AdministrationService.CrossCutting.Constants;
using AutoMapper;
using FluentAssertions;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Graph;
using Moq;

namespace Aurora.AdministrationService.Tests.API.Controllers.Practitioner
{
   public class PractitionerControllerTests
    {
        private readonly Mock<IMapper> _mapperMock;
        private readonly PractitionerController _controller;
        private readonly Mock<IRegionCodeValidationHelper> _regionCodeHelperMock;
        private readonly Mock<IPractitionerQueryService> _mockPractitionerQueryService;
        private readonly Mock<IPractitionerCommandService> _mockPractitionerCommandService;
        public PractitionerControllerTests()
        {
            _regionCodeHelperMock = new Mock<IRegionCodeValidationHelper>();
            _mockPractitionerQueryService = new Mock<IPractitionerQueryService>();
            _mockPractitionerCommandService = new Mock<IPractitionerCommandService>();

            _mapperMock = new Mock<IMapper>();

            // Set up the controller with mocked service
            _controller = new PractitionerController(_mockPractitionerQueryService.Object, _regionCodeHelperMock.Object, _mockPractitionerCommandService.Object, _mapperMock.Object)
            {
                ControllerContext = new ControllerContext
                {
                    HttpContext = new DefaultHttpContext()
                }
            };
        }
        [Fact]
        public async Task GetPractitionerDetails_ReturnsOkResult_WhenPractitionerExists()
        {
            // Arrange
            string resourceId = "PRAC001";

            var expectedResponse = new List<PractitionerDetailsFhirDto>
        {
            new PractitionerDetailsFhirDto { ResourceType = "Practitioner" }
        };

            _regionCodeHelperMock
                 .Setup(x => x.VerifyRegionCodeHeader(It.IsAny<HttpRequest>()))
                 .Returns(new GenericResponse<string> { HasError = false });

            _mockPractitionerQueryService
                .Setup(s => s.GetPractitionerDetailsFhir(resourceId))
                .ReturnsAsync(expectedResponse);

            // Act
            var result = await _controller.GetPractitionerDetails(resourceId);

            // Assert
            var okResult = Assert.IsType<OkObjectResult>(result);
            var response = Assert.IsType<GenericResponse<List<PractitionerDetailsFhirDto>>>(okResult.Value);
            Assert.True(response.IsSuccess);
            Assert.NotEmpty(response.Result);
        }
        [Fact]
        public async Task GetPractitionerDetails_ReturnsBadRequest_WhenRegionCodeInvalid()
        {
            //Arrange
            string resourceId = "PRAC001";
            _regionCodeHelperMock
                 .Setup(x => x.VerifyRegionCodeHeader(It.IsAny<HttpRequest>()))
                 .Returns(new GenericResponse<string> { HasError = true });

            // Act
            var result = await _controller.GetPractitionerDetails(resourceId);

            // Assert
            var badRequestResult = Assert.IsType<BadRequestObjectResult>(result);
            Assert.Equal(400, badRequestResult.StatusCode);
        }
        [Fact]
        public async Task GetPractitionerDetails_ReturnsNotFound_WhenPractitionerNotFound()
        {
            // Arrange
            string resourceId = "PRAC001";
            _regionCodeHelperMock
                  .Setup(x => x.VerifyRegionCodeHeader(It.IsAny<HttpRequest>()))
                  .Returns(new GenericResponse<string> { HasError = false });

            _mockPractitionerQueryService
                .Setup(s => s.GetPractitionerDetailsFhir(It.IsAny<string>()))
                .ReturnsAsync((List<PractitionerDetailsFhirDto>)null); // No data found

            // Act
            var result = await _controller.GetPractitionerDetails(resourceId);

            // Assert
            var notFound = Assert.IsType<NotFoundObjectResult>(result);
            var response = Assert.IsType<GenericResponse<PractitionerDetailsFhirDto>>(notFound.Value);
            Assert.True(response.HasError);
            Assert.False(response.IsSuccess);
        }

        [Theory]
        [InlineData(true, ResponseMessage.STATUS_DATA_UPDATED)]  // Update scenario
        [InlineData(false, ResponseMessage.STATUS_DATA_ADDED)]   // Add scenario
        public async Task AddOrUpdatePractitioner_ShouldReturnCorrectResponse(bool doesExist, string expectedMessage)
        {
            // Arrange
            var practitionerDetailDto = CommonMockData.GetMockPractitionerDetailDto(); // Mock DTO
            UpdatePractitionerDetailDto updatePractitionerDetailDto = new UpdatePractitionerDetailDto();
            var existingServiceEntity = doesExist ? new Domain.V1.Entities.Practitioners.Practitioner
            {
                ResourceID = "111",
                Status = true,
                RecordVersion = Array.Empty<byte>(),
                IsDeleted = false,
                CreatedDate = DateTime.UtcNow.AddDays(-1),
                CreatedBy = "TestUser"
            } : null;

            _mockPractitionerQueryService.Setup(q => q.CheckExistingPractitionerAsync(practitionerDetailDto.ResourceID ))
                .ReturnsAsync(existingServiceEntity!);

            if (doesExist)
            {
                var updateRequest = _mapperMock.Object.Map<UpdatePractitionerRequest>(practitionerDetailDto);
                _mapperMock.Setup(m => m.Map<UpdatePractitionerRequest>(practitionerDetailDto))
                    .Returns(updateRequest);

                _mockPractitionerCommandService.Setup(c => c.UpdatePractitionerDetailAsync(practitionerDetailDto, It.IsAny<UpdatePractitionerDetailDto>()))
                    .ReturnsAsync(true);

                _mockPractitionerQueryService.Setup(q => q.GetPractitionerDetailAsync(practitionerDetailDto.ResourceID))
                .ReturnsAsync((true,updatePractitionerDetailDto));
            }
            else
            {
                var newRequest = _mapperMock.Object.Map<PractitionerDto>(practitionerDetailDto);
                _mapperMock.Setup(m => m.Map<PractitionerDto>(practitionerDetailDto))
                    .Returns(newRequest);

                _mockPractitionerCommandService.Setup(c => c.CreateNewPractitionerAsync(practitionerDetailDto))
                    .ReturnsAsync(true);
            }

            // Act
            var result = await _controller.AddOrUpdatePractitioner(practitionerDetailDto);

            // Assert
            var okResult = result.Should().BeOfType<OkObjectResult>().Subject;
            var response = okResult.Value.Should().BeOfType<GenericResponse<string>>().Subject;

            response.IsSuccess.Should().BeTrue();
            response.StatusCode.Should().Be(ResponseStatusCode.STATUS_SUCCESS);

            response.Message.Should().Be(expectedMessage);

            response.HasError.Should().BeFalse();
            response.MessageType.Should().Be(CommonConstants.SUCCESS);

            if (doesExist)
            {
                _mockPractitionerCommandService.Verify(c => c.CreateNewPractitionerAsync(It.IsAny<PractitionerDetailDto>()), Times.Never);
            }
            else
            {
                _mockPractitionerCommandService.Verify(c => c.CreateNewPractitionerAsync(It.IsAny<PractitionerDetailDto>()), Times.Once);
            }
        }
        [Fact]
        public async Task AddOrUpdatePractitioner_ShouldReturnBadrequest()
        {
            // Arrange
            var practitionerDetailDto = CommonMockData.GetMockPractitionerDetailDto(); // Mock DTO
            bool doesExist = false;
            var existingServiceEntity = doesExist ? new Domain.V1.Entities.Practitioners.Practitioner
            {
                ResourceID = "111",
                Status = true,
                RecordVersion = Array.Empty<byte>(),
                IsDeleted = false,
                CreatedDate = DateTime.UtcNow.AddDays(-1),
                CreatedBy = "TestUser"
            } : null;

            _mockPractitionerQueryService.Setup(q => q.CheckExistingPractitionerAsync(practitionerDetailDto.ResourceID))
                .ReturnsAsync(existingServiceEntity!);

             
                var newRequest = _mapperMock.Object.Map<PractitionerDto>(practitionerDetailDto);
                _mapperMock.Setup(m => m.Map<PractitionerDto>(practitionerDetailDto))
                    .Returns(newRequest);

                _mockPractitionerCommandService.Setup(c => c.CreateNewPractitionerAsync(practitionerDetailDto))
                    .ReturnsAsync(false);
             

            // Act
            var result = await _controller.AddOrUpdatePractitioner(practitionerDetailDto);

            // Assert
            var badRequestResult = result.Should().BeOfType<BadRequestObjectResult>().Subject;
            var response = badRequestResult.Value.Should().BeOfType<GenericResponse<string>>().Subject;

            response.IsSuccess.Should().BeFalse();
            response.StatusCode.Should().Be(ResponseStatusCode.STATUS_BADREQUEST);

            response.HasError.Should().BeTrue();
            response.MessageType.Should().Be(CommonConstants.INFO);
        }
        [Fact]
        public async Task AddOrUpdatePractitioner_ShouldReturnBadrequest_WhenPractitionerDetailInvalid()
        {
            // Arrange
            UpdatePractitionerDetailDto updatePractitionerDetailDto = new UpdatePractitionerDetailDto();
            var practitionerDetailDto = CommonMockData.GetMockPractitionerDetailDto(); // Mock DTO
            bool doesExist = true;
            var existingServiceEntity = doesExist ? new Domain.V1.Entities.Practitioners.Practitioner
            {
                ResourceID = "111",
                Status = true,
                RecordVersion = Array.Empty<byte>(),
                IsDeleted = false,
                CreatedDate = DateTime.UtcNow.AddDays(-1),
                CreatedBy = "TestUser"
            } : null;

            _mockPractitionerQueryService.Setup(q => q.CheckExistingPractitionerAsync(practitionerDetailDto.ResourceID))
                .ReturnsAsync(existingServiceEntity);


            var newRequest = _mapperMock.Object.Map<PractitionerDto>(practitionerDetailDto);
            _mapperMock.Setup(m => m.Map<PractitionerDto>(practitionerDetailDto))
                .Returns(newRequest);

            _mockPractitionerQueryService.Setup(q => q.GetPractitionerDetailAsync(practitionerDetailDto.ResourceID))
               .ReturnsAsync((false, updatePractitionerDetailDto));

            _mockPractitionerCommandService.Setup(c => c.CreateNewPractitionerAsync(practitionerDetailDto))
                .ReturnsAsync(false);


            // Act
            var result = await _controller.AddOrUpdatePractitioner(practitionerDetailDto);

            // Assert
            var badRequestResult = result.Should().BeOfType<BadRequestObjectResult>().Subject;
            var response = badRequestResult.Value.Should().BeOfType<GenericResponse<string>>().Subject;

            response.IsSuccess.Should().BeFalse();
            response.StatusCode.Should().Be(ResponseStatusCode.STATUS_BADREQUEST);

            response.HasError.Should().BeTrue();
            response.MessageType.Should().Be(CommonConstants.INFO);
        }
        [Fact]
        public async Task AddOrUpdatePractitioner_ShouldReturnBadRequest_WhenModelStateIsInvalid()
        {
            // Arrange
            _controller.ModelState.AddModelError("ItemCode", "ItemCode is required");

            var practitionerDto = new PractitionerDetailDto
            {
                Email = "test",
                Qualification = "test",
                ResourceID = "111",
                Status = true,
            };

            // Act
            var result = await _controller.AddOrUpdatePractitioner(practitionerDto);

            // Assert
            var badRequestResult = result.Should().BeOfType<BadRequestObjectResult>().Subject;
            var modelState = badRequestResult.Value.Should().BeOfType<SerializableError>().Subject;
            modelState.Should().ContainKey("ItemCode");
        }
        [Fact]
        public async Task GetDoctorApppointmentByDoctorIdAndLocationId_Should_Return_BadRequest_If_RegionHeader_Invalid()
        {
            // Arrange
            _regionCodeHelperMock
                 .Setup(x => x.VerifyRegionCodeHeader(It.IsAny<HttpRequest>()))
                 .Returns(new GenericResponse<string> { HasError = true });

            // Act
            var result = await _controller.GetDoctorApppointmentByDoctorIdAndLocationId("doc123", "1");

            // Assert
            result.Should().BeOfType<BadRequestObjectResult>();
            var badRequest = result as BadRequestObjectResult;
            badRequest!.StatusCode.Should().Be(400);
        }
        [Fact]
        public async Task Should_Return_Ok_With_Data_When_ValidRequest_And_DataExists()
        {
            // Arrange
            var expectedDto = new PractitionerAppoinmentDetailsDto
            {
                ResourceID = "doc123",
                GivenName = "John"
            };

            var response = new GenericResponse<PractitionerAppoinmentDetailsDto>
            {
                Result = expectedDto,
                IsSuccess = true,
                HasError = false,
                Message = "Success",
                StatusCode = ResponseStatusCode.STATUS_SUCCESS
            };

            _regionCodeHelperMock
                .Setup(h => h.VerifyRegionCodeHeader(It.IsAny<HttpRequest>()))
                .Returns(new GenericResponse<string> { HasError = false });

            _mockPractitionerQueryService
                .Setup(s => s.GetDoctorApppointmentByDoctorIdAndLocationId("doc123", "1"))
                .ReturnsAsync(response);

            // Act
            var result = await _controller.GetDoctorApppointmentByDoctorIdAndLocationId("doc123", "1");

            // Assert
            result.Should().BeOfType<OkObjectResult>();
            var okResult = result as OkObjectResult;
            okResult!.Value.Should().BeEquivalentTo(response);
        }
        [Fact]
        public async Task AddOrUpdatePractitioner_ShouldReturnBadrequest_WhenUpdatePractitionerDetailInvalid()
        {
            // Arrange
            UpdatePractitionerDetailDto updatePractitionerDetailDto = new UpdatePractitionerDetailDto();
            var practitionerDetailDto = CommonMockData.GetMockPractitionerDetailDto(); // Mock DTO
            bool doesExist = true;
            var existingServiceEntity = doesExist ? new Domain.V1.Entities.Practitioners.Practitioner
            {
                ResourceID = "111",
                Status = true,
                RecordVersion = Array.Empty<byte>(),
                IsDeleted = false,
                CreatedDate = DateTime.UtcNow.AddDays(-1),
                CreatedBy = "TestUser"
            } : null;

            _mockPractitionerQueryService.Setup(q => q.CheckExistingPractitionerAsync(practitionerDetailDto.ResourceID))
                .ReturnsAsync(existingServiceEntity);


            var newRequest = _mapperMock.Object.Map<PractitionerDto>(practitionerDetailDto);
            _mapperMock.Setup(m => m.Map<PractitionerDto>(practitionerDetailDto))
                .Returns(newRequest);

            _mockPractitionerQueryService.Setup(q => q.GetPractitionerDetailAsync(practitionerDetailDto.ResourceID))
               .ReturnsAsync((true, updatePractitionerDetailDto));

            _mockPractitionerCommandService.Setup(c => c.UpdatePractitionerDetailAsync(practitionerDetailDto,It.IsAny<UpdatePractitionerDetailDto>()))
                .ReturnsAsync(false);


            // Act
            var result = await _controller.AddOrUpdatePractitioner(practitionerDetailDto);

            // Assert
            var badRequestResult = result.Should().BeOfType<BadRequestObjectResult>().Subject;
            var response = badRequestResult.Value.Should().BeOfType<GenericResponse<string>>().Subject;

            response.IsSuccess.Should().BeFalse();
            response.StatusCode.Should().Be(ResponseStatusCode.STATUS_BADREQUEST);

            response.HasError.Should().BeTrue();
            response.MessageType.Should().Be(CommonConstants.INFO);
        }

    }
}
