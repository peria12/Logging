﻿using Aurora.AdministrationService.API.Controllers.Holiday;
using Aurora.AdministrationService.API.Helper;
using Aurora.AdministrationService.API.Models.Dto.Holiday;
using Aurora.AdministrationService.API.Services.IService.Holiday;
using Aurora.AdministrationService.CrossCutting.CommonModels;
using Aurora.AdministrationService.CrossCutting.Constants;
using Aurora.AdministrationService.CrossCutting.Extensions;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Moq;

namespace Aurora.AdministrationService.Tests.API.Controllers.Holiday
{
    public class HolidayControllerTests
    {
        private readonly byte[] concurrencyToken = [byte.MinValue, byte.MinValue, byte.MinValue, byte.MinValue, byte.MinValue, byte.MinValue, byte.MinValue, byte.MaxValue];
        private readonly Mock<IHolidayCommandService> _mockHolidayCommandService;
        private readonly Mock<IRegionCodeValidationHelper> _mockRegionHelper;
        private readonly HolidayController _controller;
        private readonly Mock<IHolidayQueryService> _holidayQueryService;

        public HolidayControllerTests()
        {
            _holidayQueryService = new Mock<IHolidayQueryService>();
            _mockHolidayCommandService = new Mock<IHolidayCommandService>();
            _mockRegionHelper = new Mock<IRegionCodeValidationHelper>();
            _controller = new HolidayController(_mockHolidayCommandService.Object, _mockRegionHelper.Object, _holidayQueryService.Object);
        }
        [Fact]
        public async Task UpdateHoliday_ValidRequest_ReturnsOkResult()
        {
            // Arrange
            var id = 1;
            var updateHolidayDto = new UpdateHolidayDto()
            {
                Id = 1,
                Date = DateTime.UtcNow,
                HolidayType = "National",
                HolidayDetails = "NewYear",
                LocationIds = new List<string> { "1" },
                Status = true,
                HolidayName = "NewYear",
                RecordVersion = concurrencyToken,
            };

            var updateResponse = new GenericResponse<string> { IsSuccess = true, Message = "Holiday updated successfully" };

            _mockRegionHelper.Setup(r => r.VerifyRegionCodeHeader(It.IsAny<Microsoft.AspNetCore.Http.HttpRequest>()))
                             .Returns((GenericResponse<string>)null);

            _mockHolidayCommandService.Setup(h => h.UpdateHoliday(It.IsAny<UpdateHolidayDto>(), It.IsAny<int>()))
                                      .ReturnsAsync(updateResponse);

            // Act
            var result = await _controller.UpdateHoliday(id, updateHolidayDto);

            // Assert
            var okResult = Assert.IsType<OkObjectResult>(result);
            var dataResponse = Assert.IsType<GenericResponse<string>>(okResult.Value);
            Assert.True(dataResponse.IsSuccess);
            Assert.Equal("Holiday updated successfully", dataResponse.Message);
            Assert.Equal(ResponseStatusCode.STATUS_SUCCESS, dataResponse.StatusCode);
            Assert.Equal(CommonConstants.SUCCESS, dataResponse.MessageType);
        }

        [Fact]
        public async Task UpdateHoliday_InvalidRequest_BadRequest()
        {
            // Arrange
            var id = 1;
            var updateHolidayRequest = (UpdateHolidayDto)null;

            _mockRegionHelper.Setup(r => r.VerifyRegionCodeHeader(It.IsAny<Microsoft.AspNetCore.Http.HttpRequest>()))
                             .Returns((GenericResponse<string>)null);

            // Act
            var result = await _controller.UpdateHoliday(id, updateHolidayRequest);

            // Assert
            var notFoundResult = Assert.IsType<NotFoundObjectResult>(result);
            var dataResponse = Assert.IsType<GenericResponse<string>>(notFoundResult.Value);
            Assert.False(dataResponse.IsSuccess);
            Assert.Equal(ResponseStatusCode.STATUS_NOTFOUND, dataResponse.StatusCode);
            Assert.Equal(ResponseMessage.STATUS_NODATA, dataResponse.Message);
            Assert.Equal(CommonConstants.ERROR, dataResponse.MessageType);
        }

        [Fact]
        public async Task UpdateHoliday_InvalidRegionCode_ReturnsBadRequest()
        {
            // Arrange
            var id = 1;
            var updateHolidayDto = new UpdateHolidayDto()
            {
                Id = 1,
                Date = DateTime.UtcNow,
                HolidayType = "National",
                HolidayDetails = "NewYear",
                LocationIds = new List<string> { "1" },
                Status = true,
                HolidayName = "NewYear",
                RecordVersion = concurrencyToken,
            };
            var errorResponse = new GenericResponse<string> { HasError = true, Message = "Invalid RegionCode" };

            _mockRegionHelper.Setup(r => r.VerifyRegionCodeHeader(It.IsAny<Microsoft.AspNetCore.Http.HttpRequest>()))
                             .Returns(errorResponse);

            // Act
            var result = await _controller.UpdateHoliday(id, updateHolidayDto);

            // Assert
            var badRequestResult = Assert.IsType<BadRequestObjectResult>(result);
            var badRequestResponse = Assert.IsType<GenericResponse<string>>(badRequestResult.Value);
            Assert.False(badRequestResponse.IsSuccess);
            Assert.Equal("Invalid RegionCode", badRequestResponse.Message);
        }

        [Fact]
        public async Task UpdateHoliday_UpdateFails_ReturnsNotFound()
        {
            // Arrange
            var id = 1;
            var updateHolidayDto = new UpdateHolidayDto()
            {
                Id = 1,
                Date = DateTime.UtcNow,
                HolidayType = "National",
                HolidayDetails = "NewYear",
                LocationIds = new List<string> { "1" },
                Status = true,
                HolidayName = "NewYear",
                RecordVersion = concurrencyToken,
            };
            var updateResponse = new GenericResponse<string> { IsSuccess = false, Message = "Failed to update holiday", StatusCode = ResponseStatusCode.STATUS_NOTFOUND };

            _mockRegionHelper.Setup(r => r.VerifyRegionCodeHeader(It.IsAny<Microsoft.AspNetCore.Http.HttpRequest>()))
                             .Returns((GenericResponse<string>)null);

            _mockHolidayCommandService.Setup(h => h.UpdateHoliday(It.IsAny<UpdateHolidayDto>(), It.IsAny<int>()))
                                      .ReturnsAsync(updateResponse);

            // Act
            var result = await _controller.UpdateHoliday(id, updateHolidayDto);

            // Assert
            var notFoundResult = Assert.IsType<OkObjectResult>(result);
            var dataResponse = Assert.IsType<GenericResponse<string>>(notFoundResult.Value);
            Assert.Equal("Failed to update holiday", dataResponse.Message);
            Assert.Equal(ResponseStatusCode.STATUS_NOTFOUND, dataResponse.StatusCode);
            Assert.Equal(CommonConstants.ERROR, dataResponse.MessageType);
        }
        [Fact]
        public async Task HolidaySearch_ReturnsOkResult_WhenHolidaysFound()
        {
            // Arrange
            var pagination = new PaginationQuery { PageNumber = 1, PageSize = 10 };
            var selectedLocationId = "NYC";

            var holidayResponse = new GenericResponsePagedList<GetHolidaySearchResponse>
            {
                IsSuccess = true,
                StatusCode = ResponseStatusCode.STATUS_SUCCESS,
                Results = new List<GetHolidaySearchResponse>
                 {
                    new GetHolidaySearchResponse
                    {
                        Id = 1,
                        Date = DateTime.UtcNow,
                        HolidayName = "Christmas",
                        HolidayType = "Public",
                        HolidayDetails = "Celebration of Christmas",
                        Locations = new List<AdministrationService.API.Models.Dto.Holiday.LocationDto>
                                         {
                                             new AdministrationService.API.Models.Dto.Holiday.LocationDto { LocationID = "1" },
                                             new AdministrationService.API.Models.Dto.Holiday.LocationDto { LocationID = "2" }
                                         },
                        Status = true
                    },
                  
                 }.AsQueryable(), 
                Count = 1
            };
            _mockRegionHelper
               .Setup(x => x.VerifyRegionCodeHeader(It.IsAny<HttpRequest>()))
               .Returns(new GenericResponse<string>
               {
                  
                   HasError = false,
                  
               });

            _holidayQueryService
                .Setup(h => h.GetHolidaySearch(pagination, selectedLocationId))
                .ReturnsAsync(holidayResponse);

            // Act
            var result = await _controller.HolidaySearch(pagination, selectedLocationId);

            // Assert
            var okResult = Assert.IsType<OkObjectResult>(result.Result);
            var returnValue = Assert.IsType<GenericResponsePagedList<GetHolidaySearchResponse>>(okResult.Value);
            Assert.True(returnValue.IsSuccess);
            Assert.Equal(ResponseStatusCode.STATUS_SUCCESS, returnValue.StatusCode);
            Assert.Single(returnValue.Results);
        }

        [Fact]
        public async Task HolidaySearch_ReturnsNotFound_WhenNoHolidaysFound()
        {
            // Arrange
            var pagination = new PaginationQuery { PageNumber = 1, PageSize = 10 };
            var selectedLocationId = "LA";

            _mockRegionHelper
                .Setup(r => r.VerifyRegionCodeHeader(It.IsAny<HttpRequest>()))
                .Returns(new GenericResponse<string> { HasError = false });

            _holidayQueryService
                .Setup(h => h.GetHolidaySearch(pagination, selectedLocationId))
                .ReturnsAsync(new GenericResponsePagedList<GetHolidaySearchResponse>
                {
                    IsSuccess = false,
                    StatusCode= ResponseStatusCode.STATUS_NOTFOUND,
                    Results = null
                });

            // Act
            var result = await _controller.HolidaySearch(pagination, selectedLocationId);

            // Assert
            var notFoundResult = Assert.IsType<NotFoundObjectResult>(result.Result);
            var returnValue = Assert.IsType<GenericResponsePagedList<GetHolidaySearchResponse>>(notFoundResult.Value);
            Assert.False(returnValue.IsSuccess);
            Assert.Equal(ResponseStatusCode.STATUS_NOTFOUND, returnValue.StatusCode);
        }

        [Fact]
        public async Task HolidaySearch_ReturnsBadRequest_WhenRegionCodeInvalid()
        {
            // Arrange
            var pagination = new PaginationQuery { PageNumber = 1, PageSize = 10 };
            _mockRegionHelper
                .Setup(r => r.VerifyRegionCodeHeader(It.IsAny<HttpRequest>()))
                .Returns(new GenericResponse<string>
                {
                    HasError = false,
                    Message = "Invalid Region Code"
                });
           

            // Act
            var result = await _controller.HolidaySearch(pagination, null) ;

            // Assert
            var badRequestResult = Assert.IsType<NotFoundObjectResult>(result.Result);
            var returnValue = Assert.IsType<GenericResponsePagedList<GetHolidaySearchResponse>>(badRequestResult.Value);
            Assert.True(returnValue.HasError);
            Assert.Equal(ResponseStatusCode.STATUS_NOTFOUND, returnValue.StatusCode);
        }
        [Fact]
        public async Task CreateHoliday_ShouldReturnOk_WhenHolidayIsCreatedSuccessfully()
        {
            // Arrange
            var createHolidayRequest = new CreateHolidayRequest { HolidayName = "New Year", Date = DateTime.UtcNow,HolidayType="Test",LocationIds = new List<string> { "Test"},Status=true };

            _mockRegionHelper
                .Setup(x => x.VerifyRegionCodeHeader(It.IsAny<HttpRequest>()))
                .Returns((GenericResponse<string>)null);  // No error

            _mockHolidayCommandService
                .Setup(x => x.CreateHolidayAsync(createHolidayRequest))
                .ReturnsAsync(new GenericResponse<string> { IsSuccess = true });

            // Act
            var result = await _controller.CreateHoliday(createHolidayRequest);

            // Assert
            var okResult = Assert.IsType<OkObjectResult>(result);
            var response = Assert.IsType<GenericResponse<string>>(okResult.Value);
            Assert.True(response.IsSuccess);
            Assert.Equal(ResponseStatusCode.STATUS_SUCCESS, response.StatusCode);
        }

        [Fact]
        public async Task CreateHoliday_ShouldReturnBadRequest_WhenRegionCodeIsInvalid()
        {
            // Arrange
            var createHolidayRequest = new CreateHolidayRequest { HolidayName = "New Year", Date = DateTime.UtcNow, HolidayType = "Test", LocationIds = new List<string> { "Test" }, Status = true };

            _mockRegionHelper
                .Setup(x => x.VerifyRegionCodeHeader(It.IsAny<HttpRequest>()))
                .Returns(new GenericResponse<string>
                {
                    HasError = true,
                    Message = "Invalid Region Code",
                    StatusCode= ResponseStatusCode.STATUS_BADREQUEST
                });

            // Act
            var result = await _controller.CreateHoliday(createHolidayRequest);

            // Assert
            var badRequestResult = Assert.IsType<BadRequestObjectResult>(result);
            var response = Assert.IsType<GenericResponse<string>>(badRequestResult.Value);
            Assert.False(response.IsSuccess);
            Assert.Equal(ResponseStatusCode.STATUS_BADREQUEST, response.StatusCode);
            Assert.Equal("Invalid Region Code", response.Message);
        }

        [Fact]
        public async Task CreateHoliday_ShouldReturnBadRequest_WhenHolidayCreationFails()
        {
            // Arrange
            var createHolidayRequest = new CreateHolidayRequest { HolidayName = "New Year", Date = DateTime.UtcNow, HolidayType = "Test", LocationIds = new List<string> { "Test" }, Status = true };

            _mockRegionHelper
                .Setup(x => x.VerifyRegionCodeHeader(It.IsAny<HttpRequest>()))
                .Returns((GenericResponse<string>)null); // No error

            _mockHolidayCommandService
                .Setup(x => x.CreateHolidayAsync(createHolidayRequest))
                .ReturnsAsync(new GenericResponse<string> { IsSuccess = false, Message = "Holiday creation failed" });

            // Act
            var result = await _controller.CreateHoliday(createHolidayRequest);

            // Assert
            var badRequestResult = Assert.IsType<BadRequestObjectResult>(result);
            var response = Assert.IsType<GenericResponse<string>>(badRequestResult.Value);
            Assert.False(response.IsSuccess);
            Assert.Equal(ResponseStatusCode.STATUS_BADREQUEST, response.StatusCode);
            Assert.Equal("Holiday creation failed", response.Message);
        }

        [Fact]
        public async Task DeleteHoliday_ShouldReturnOk_WhenHolidayIsDeletedSuccessfully()
        {
            // Arrange
            int holidayId = 1;

            _mockRegionHelper
                .Setup(x => x.VerifyRegionCodeHeader(It.IsAny<HttpRequest>()))
                .Returns((GenericResponse<string>)null); // No error

            _holidayQueryService
                .Setup(x => x.GetHolidayById(holidayId))
                .ReturnsAsync(new GenericResponse<GetHolidayDetailDto>
                {
                    IsSuccess = true,
                    Result = new GetHolidayDetailDto
                    {
                        Id = holidayId,
                        Date = DateTime.UtcNow,
                        HolidayType = "GOA",
                        LocationIds = new List<string> { "Test" },
                        Status = true
                    },
                    StatusCode = "200",
                    Message = "Success",
                    HasError = false
                });

            _mockHolidayCommandService
                .Setup(x => x.DeleteHolidayByIdAsync(holidayId))
                .ReturnsAsync(new GenericResponse<string> { IsSuccess = true, Message = "Holiday deleted successfully" });

            // Act
            var result = await _controller.DeleteHoliday(holidayId);

            // Assert
            var okResult = Assert.IsType<OkObjectResult>(result);
            var response = Assert.IsType<GenericResponse<string>>(okResult.Value);
            Assert.True(response.IsSuccess);
            Assert.Equal(ResponseStatusCode.STATUS_SUCCESS, response.StatusCode);
            Assert.Equal("Holiday deleted successfully", response.Message);
        }

        [Fact]
        public async Task DeleteHoliday_ShouldReturnBadRequest_WhenRegionCodeIsInvalid()
        {
            // Arrange
            int holidayId = 1;
 
            _mockRegionHelper
                .Setup(x => x.VerifyRegionCodeHeader(It.IsAny<HttpRequest>()))
                .Returns(new GenericResponse<string>{IsSuccess=false,StatusCode= ResponseStatusCode.STATUS_BADREQUEST, HasError = true, Message = "Invalid Region Code" });

            // Act
            var result = await _controller.DeleteHoliday(holidayId);

            // Assert
            var badRequestResult = Assert.IsType<BadRequestObjectResult>(result);
            var response = Assert.IsType<GenericResponse<string>>(badRequestResult.Value);
            Assert.False(response.IsSuccess);
            Assert.Equal(ResponseStatusCode.STATUS_BADREQUEST, response.StatusCode);
            Assert.Equal("Invalid Region Code", response.Message);
        }

        [Fact]
        public async Task DeleteHoliday_ShouldReturnNotFound_WhenHolidayDoesNotExist()
        {
            // Arrange
            int holidayId = 999;

            _mockRegionHelper
                .Setup(x => x.VerifyRegionCodeHeader(It.IsAny<HttpRequest>()))
                .Returns((GenericResponse<string>)null); // No error

            _holidayQueryService
                .Setup(x => x.GetHolidayById(holidayId))
                .ReturnsAsync((GenericResponse<GetHolidayDetailDto>)null); // Holiday not found

            // Act
            var result = await _controller.DeleteHoliday(holidayId);

            // Assert
            var notFoundResult = Assert.IsType<NotFoundObjectResult>(result);
            var response = Assert.IsType<GenericResponse<string>>(notFoundResult.Value);
            Assert.False(response.IsSuccess);
            Assert.Equal(ResponseStatusCode.STATUS_NOTFOUND, response.StatusCode);
            Assert.Equal(ResponseMessage.STATUS_NODATA, response.Message);
        }

        [Fact]
        public async Task DeleteHoliday_ShouldReturnBadRequest_WhenHolidayDeletionFails()
        {
            // Arrange
            int holidayId = 1;

            _mockRegionHelper
                .Setup(x => x.VerifyRegionCodeHeader(It.IsAny<HttpRequest>()))
                .Returns((GenericResponse<string>)null); // No error

            _holidayQueryService
                .Setup(x => x.GetHolidayById(holidayId))
                .ReturnsAsync(new GenericResponse<GetHolidayDetailDto>
                {
                    IsSuccess = true,
                    Result = new GetHolidayDetailDto
                    {
                        Id = holidayId,
                        Date = DateTime.UtcNow,
                        HolidayType = "GOA",
                        LocationIds = new List<string> { "Test" },
                        Status = true
                    },
                    StatusCode = "200",
                    Message = "Success",
                    HasError = false
                });

            _mockHolidayCommandService
                .Setup(x => x.DeleteHolidayByIdAsync(holidayId))
                .ReturnsAsync(new GenericResponse<string> { IsSuccess = false,StatusCode= ResponseStatusCode.STATUS_BADREQUEST, Message = "Deletion failed" });

            // Act
            var result = await _controller.DeleteHoliday(holidayId);

            // Assert
            var okResult = Assert.IsType<OkObjectResult>(result);
            var response = Assert.IsType<GenericResponse<string>>(okResult.Value);
   
            Assert.Equal(ResponseStatusCode.STATUS_BADREQUEST, response.StatusCode);
            Assert.Equal("Deletion failed", response.Message);
            Assert.Equal("ERROR", response.MessageType);
        }

        [Fact]
        public async Task GetHolidayById_ValidId_ReturnsOkResult()
        {
            // Arrange
            int holidayId = 1;
            var holidayDetail = new GenericResponse<GetHolidayDetailDto>
            {
                IsSuccess = true,
                Result = new GetHolidayDetailDto
                {
                    Id = holidayId,
                    Date = DateTime.UtcNow,
                    HolidayType = "GOA",
                    LocationIds = new List<string> { "Test" },
                    Status = true
                },
                StatusCode = "200",
                Message = "Success",
                HasError = false
            };

            _mockRegionHelper.Setup(r => r.VerifyRegionCodeHeader(It.IsAny<HttpRequest>()))
                             .Returns(new GenericResponse<string> { HasError = false });

            _holidayQueryService.Setup(s => s.GetHolidayById(holidayId))
                                    .ReturnsAsync(holidayDetail);

            // Act
            var result = await _controller.GetHolidayById(holidayId);

            // Assert
            var okResult = Assert.IsType<OkObjectResult>(result.Result);
            var response = Assert.IsType<GenericResponse<GetHolidayDetailDto>>(okResult.Value);

            Assert.True(response.IsSuccess);
            Assert.Equal(ResponseStatusCode.STATUS_SUCCESS, response.StatusCode);
            Assert.Equal(holidayDetail.Result, response.Result);
        }

        [Fact]
        public async Task GetHolidayById_InvalidRegionCodeHeader_ReturnsBadRequest()
        {
            // Arrange
            _mockRegionHelper.Setup(r => r.VerifyRegionCodeHeader(It.IsAny<HttpRequest>()))
                             .Returns(new GenericResponse<string> { HasError = true, Message = "Invalid Region Code" });

            // Act
            var result = await _controller.GetHolidayById(1);

            // Assert
            var badRequestResult = Assert.IsType<BadRequestObjectResult>(result.Result);
            var response = Assert.IsType<GenericResponse<string>>(badRequestResult.Value);

            Assert.True(response.HasError);
            Assert.Equal("Invalid Region Code", response.Message);
        }

        [Fact]
        public async Task GetHolidayById_HolidayNotFound_ReturnsNotFound()
        {
            // Arrange
            int holidayId = 999;
            _mockRegionHelper.Setup(r => r.VerifyRegionCodeHeader(It.IsAny<HttpRequest>()))
                             .Returns(new GenericResponse<string> { HasError = false });

            _holidayQueryService.Setup(s => s.GetHolidayById(holidayId))
                                    .ReturnsAsync((GenericResponse<GetHolidayDetailDto>)null);

            // Act
            var result = await _controller.GetHolidayById(holidayId);

            // Assert
            var notFoundResult = Assert.IsType<NotFoundObjectResult>(result.Result);
            var response = Assert.IsType<GenericResponse<GetHolidayDetailDto>>(notFoundResult.Value);

            Assert.False(response.IsSuccess);
            Assert.True(response.HasError);
            Assert.Equal(ResponseStatusCode.STATUS_NOTFOUND, response.StatusCode);
        }

        [Fact]
        public async Task GetHolidayById_ExceptionThrown_ReturnsInternalServerError()
        {
            // Arrange
            _mockRegionHelper.Setup(r => r.VerifyRegionCodeHeader(It.IsAny<HttpRequest>()))
                             .Returns(new GenericResponse<string> { HasError = false });

            _holidayQueryService.Setup(s => s.GetHolidayById(It.IsAny<int>()))
                                    .ThrowsAsync(new System.Exception("Database error"));
            // Act
            try
            {
              await _controller.GetHolidayById(1);
            }
            catch (Exception ex)
            {
                // Assert
                Assert.Equal("Database error", ex.Message);
            }
        }
    }
}
