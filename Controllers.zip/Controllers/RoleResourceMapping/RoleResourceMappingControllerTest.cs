﻿using Aurora.AdministrationService.API.Controllers.RoleResourceMapping;
using Aurora.AdministrationService.API.Helper;
using Aurora.AdministrationService.API.Models.Dto.UserGroups.RoleResourceMapping;
using Aurora.AdministrationService.API.Services.IService.UserGroups.RoleResourceMapping;
using Aurora.AdministrationService.CrossCutting.CommonModels;
using Aurora.AdministrationService.CrossCutting.Constants;
using FluentAssertions;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Moq;

namespace Aurora.AdministrationService.Tests.API.Controllers.RoleResourceMapping
{
    public class RoleResourceMappingControllerTest
    {
        private readonly Mock<IRoleResourceMappingCommandService> _mockRoleResourceMappingCommandService;
        private readonly Mock<IRoleResourceMappingQueryService> _mockRoleResourceMappingQueryService;
        private readonly RoleResourceMappingController _controller;
        private readonly Mock<IRegionCodeValidationHelper> _regionHelperMock;

        public RoleResourceMappingControllerTest()
        {
            _regionHelperMock = new Mock<IRegionCodeValidationHelper>();
            _mockRoleResourceMappingCommandService = new Mock<IRoleResourceMappingCommandService>();
            _mockRoleResourceMappingQueryService = new Mock<IRoleResourceMappingQueryService>();
            _controller = new RoleResourceMappingController(_mockRoleResourceMappingQueryService.Object, _mockRoleResourceMappingCommandService.Object, _regionHelperMock.Object);
        }
        [Fact]
        public void GetRoleResourceMappings_InvalidRegionCode_ReturnsBadRequest()
        {
            // Arrange
            _regionHelperMock
                .Setup(helper => helper.VerifyRegionCodeHeader(It.IsAny<HttpRequest>()))
                .Returns(new GenericResponse<string> { HasError = true, Message = "Invalid RegionCode" });

            // Act
            var result = _controller.GetRoleResourceMappingList();

            // Assert
            var badRequestResult = result.Result as BadRequestObjectResult;
            badRequestResult.Should().NotBeNull();
            var response = badRequestResult?.Value as GenericResponse<string>;
            response.Should().NotBeNull();
            response?.HasError.Should().BeTrue();
            response?.Message.Should().Be("Invalid RegionCode");
        }

        [Fact]
        public void CreateRoleResourceMapping_InvalidRegionCode_ReturnsBadRequest()
        {
            // Arrange
            var roleResourceMapping = new RoleResourceMappingDto()
            {
                Code = "test",
                ResourceID = 1,
                RoleID = 1,
                Definition = "test",
                Display = "test",
                IsEditAccess = true,
                Source = "test",
            };
            _regionHelperMock
                .Setup(helper => helper.VerifyRegionCodeHeader(It.IsAny<HttpRequest>()))
                .Returns(new GenericResponse<string> { HasError = true, Message = "Invalid RegionCode" });

            // Act
            var result = _controller.CreateRoleResourceMapping(roleResourceMapping);

            // Assert
            var badRequestResult = result?.Result as BadRequestObjectResult;
            badRequestResult.Should().NotBeNull();
            var response = badRequestResult?.Value as GenericResponse<string>;
            response.Should().NotBeNull();
            response?.HasError.Should().BeTrue();
            response?.Message.Should().Be("Invalid RegionCode");
        }

        [Fact]
        public async Task GetRoleResourceMappingById_InvalidRegionCode_ReturnsBadRequest()
        {
            // Arrange
            _regionHelperMock
                .Setup(helper => helper.VerifyRegionCodeHeader(It.IsAny<HttpRequest>()))
                .Returns(new GenericResponse<string> { HasError = true, Message = "Invalid RegionCode" });

            // Act
            var result = await _controller.GetRoleResourceMappingById(1);

            // Assert
            var badRequestResult = result.Result as BadRequestObjectResult;

            badRequestResult.Should().NotBeNull();
            var response = badRequestResult?.Value as GenericResponse<string>;
            response.Should().NotBeNull();
            response?.HasError.Should().BeTrue();
            response?.Message.Should().Be("Invalid RegionCode");
        }

        [Fact]
        public void UpdateRoleResourceMappingDetails_InvalidRegionCode_ReturnsBadRequest()
        {
            // Arrange
            int id = 1;
            var roleResourceMapping = new UpdateRoleResourceMappingRequest()
            {
                Id = 1,
                Code = "test",
                ResourceID = 1,
                RoleID = 1,
                Definition = "test",
                Display = "test",
                IsEditAccess = true,
                Source = "test",
            };
            _regionHelperMock
                .Setup(helper => helper.VerifyRegionCodeHeader(It.IsAny<HttpRequest>()))
                .Returns(new GenericResponse<string> { HasError = true, Message = "Invalid RegionCode" });

            // Act
            var result = _controller.UpdateRoleResourceMappingDetails(id, roleResourceMapping);

            // Assert
            var badRequestResult = result?.Result as BadRequestObjectResult;
            badRequestResult.Should().NotBeNull();
            var response = badRequestResult?.Value as GenericResponse<string>;
            response.Should().NotBeNull();
            response?.HasError.Should().BeTrue();
            response?.Message.Should().Be("Invalid RegionCode");
        }

        [Fact]
        public async Task CreateRoleResourceMapping_ShouldReturnSuccessResponse_WhenIsAdded()
        {
            // Arrange
            var roleResourceMapping = new RoleResourceMappingDto()
            {
                Code = "test",
                ResourceID = 1,
                RoleID = 1,
                Definition = "test",
                Display = "test",
                IsEditAccess = true,
                Source = "test",
            };
            _mockRoleResourceMappingCommandService.Setup(service => service.CreateRoleResourceMappingAsync(roleResourceMapping)).ReturnsAsync(true);

            // Act
            var result = await _controller.CreateRoleResourceMapping(roleResourceMapping) as OkObjectResult;
            var response = result?.Value as GenericResponse<string>;

            // Assert
            result.Should().NotBeNull();
            result?.StatusCode.Should().Be(200);
            response?.IsSuccess.Should().BeTrue();
            response?.StatusCode.Should().Be(ResponseStatusCode.STATUS_SUCCESS);
            response?.Message.Should().Be(ResponseMessage.STATUS_DATA_ADDED);
        }

        [Fact]
        public void GetRoleResourceMappingList_ShouldReturnRoleResourceMappingList()
        {
            // Arrange
            var roleResourceMappingList = new List<GetRoleResourceMappingDto> { new GetRoleResourceMappingDto() {
                Code = "test",
                ResourceID = 1,
                RoleID = 1,
                Definition = "test",
                Display = "test",
                IsEditAccess = true,
                Source = "test",
            } };
            _mockRoleResourceMappingQueryService.Setup(service => service.GetRoleResourceMappingList()).Returns(roleResourceMappingList);

            // Act
            var result = _controller.GetRoleResourceMappingList();
            var okresult = result?.Result as OkObjectResult;
            var response = okresult?.Value as GenericResponseList<GetRoleResourceMappingDto>;

            // Assert
            result.Should().NotBeNull();
            response?.StatusCode.Should().Be("200");
            response?.IsSuccess.Should().BeTrue();
            response?.StatusCode.Should().Be(ResponseStatusCode.STATUS_SUCCESS);
            response?.Message.Should().Be(ResponseMessage.STATUS_DATA_FOUND);
            response?.TotalCount.Should().Be(roleResourceMappingList.Count);

        }

        [Fact]
        public async Task GetRoleResourceMappingById_ShouldReturnNull_WhenIdIsInvalid()
        {
            // Act
            var result = await _controller.GetRoleResourceMappingById(null);
            var response = result.Value as GenericResponse<GetRoleResourceMappingDetailDto>;

            // Assert
            result.Should().NotBeNull();
            response.Should().BeNull();

        }

        [Fact]
        public async Task GetRoleResourceMappingById_ShouldReturnNotFound_WhenDoesNotExist()
        {
            // Arrange
            var id = 1;
            GetRoleResourceMappingDetailDto roleResourceMappingDetailDto = new GetRoleResourceMappingDetailDto()
            {
                Code = "test",
                ResourceID = 1,
                RoleID = 1,
                Definition = "test",
                Display = "test",
                IsEditAccess = true,
                Source = "test",
            };
            _mockRoleResourceMappingQueryService
              .Setup(service => service.GetRoleResourceMappingById(2)).ReturnsAsync(roleResourceMappingDetailDto);

            // Act
            var result = await _controller.GetRoleResourceMappingById(id);
            var okobjectresult = result?.Result as OkObjectResult;
            var response = okobjectresult?.Value as GenericResponse<GetRoleResourceMappingDetailDto>;

            // Assert
            result.Should().NotBeNull();
            response?.IsSuccess.Should().BeTrue();
            response?.StatusCode.Should().Be(ResponseStatusCode.STATUS_NOTFOUND);
            response?.Message.Should().Be(ResponseMessage.STATUS_NODATA);
        }

        [Fact]
        public async Task UpdateRoleResourceMappingDetails_ShouldReturnBadRequest_WhenAlreadyExists()
        {
            // Arrange
            int id = 1;
            var roleResourceMapping = new UpdateRoleResourceMappingRequest()
            {
                Id = 1,
                Code = "test",
                ResourceID = 1,
                RoleID = 1,
                Definition = "test",
                Display = "test",
                IsEditAccess = true,
                Source = "test",
            };
            _mockRoleResourceMappingQueryService.Setup(service => service.IsRoleResourceMappingAlreadyExist(id)).ReturnsAsync((true, ResponseMessage.STATUS_NODATA));

            // Act
            var result = await _controller.UpdateRoleResourceMappingDetails(id, roleResourceMapping);

            // Assert
            result.Should().NotBeNull();

        }

        [Fact]
        public async Task UpdateRoleResourceMappingDetails_RoleResourceMappingNotFound_ReturnsNotFound()
        {
            // Arrange
            int roleResourceMappingId = 1;
            var roleResourceMappingRequest = new UpdateRoleResourceMappingRequest()
            {
                Id = roleResourceMappingId,
                Code = "test",
                ResourceID = 1,
                RoleID = 1,
                Definition = "test",
                Display = "test",
                IsEditAccess = true,
                Source = "test",
            };
            Domain.V1.Entities.UserGroups.RoleResourceMapping roleResourceMapping = null;
            _mockRoleResourceMappingQueryService
                .Setup(service => service.FindRoleResourceMappingById(roleResourceMappingId))
                .ReturnsAsync(roleResourceMapping);

            // Act
            var result = await _controller.UpdateRoleResourceMappingDetails(roleResourceMappingId, roleResourceMappingRequest);

            // Assert
            var actionResult = Assert.IsType<NotFoundObjectResult>(result);
            var response = Assert.IsType<GenericResponse<string>>(actionResult.Value);
            Assert.Equal(ResponseStatusCode.STATUS_NOTFOUND, response.StatusCode);
            Assert.Equal(ResponseMessage.STATUS_NODATA, response.Message);
        }

        [Fact]
        public async Task UpdateRoleResourceMappingDetails_UpdateSuccessful_ReturnsOk()
        {
            // Arrange
            int roleResourceMappingId = 1;
            var roleResourceMappingRequest = new UpdateRoleResourceMappingRequest()
            {
                Id = 1,
                Code = "test",
                ResourceID = 1,
                RoleID = 1,
                Definition = "test",
                Display = "test",
                IsEditAccess = true,
                Source = "test",
            };
            var existingRoleResourceMapping = new Domain.V1.Entities.UserGroups.RoleResourceMapping
            {
                Id = roleResourceMappingId,
                Code = "test",
                ResourceID = 1,
                RoleID = 1,
                Definition = "test",
                Display = "test",
                IsEditAccess = true,
                Source = "test",
                CreatedBy = "Admin",
                CreatedDate = DateTime.UtcNow,
                IsDeleted = false
            };

            _mockRoleResourceMappingQueryService
                .Setup(service => service.FindRoleResourceMappingById(roleResourceMappingId))
                .ReturnsAsync(existingRoleResourceMapping);

            _mockRoleResourceMappingCommandService
                .Setup(service => service.UpdateRoleResourceMappingAsync(roleResourceMappingRequest, existingRoleResourceMapping))
                .ReturnsAsync(true);

            // Act
            var result = await _controller.UpdateRoleResourceMappingDetails(roleResourceMappingId, roleResourceMappingRequest);

            // Assert
            var actionResult = Assert.IsType<OkObjectResult>(result);
            var response = Assert.IsType<GenericResponse<string>>(actionResult.Value);
            Assert.Equal(ResponseStatusCode.STATUS_SUCCESS, response.StatusCode);
            Assert.Equal(ResponseMessage.STATUS_DATA_UPDATED, response.Message);
            Assert.Equal(CommonConstants.SUCCESS, response.MessageType);
        }

        [Fact]
        public async Task UpdateRoleResourceMappingDetails_UpdateFailed_ReturnsOkWithErrorMessage()
        {
            // Arrange
            int roleResourceMappingId = 1;
            var roleResourceMappingRequest = new UpdateRoleResourceMappingRequest()
            {
                Id = roleResourceMappingId,
                Code = "test",
                ResourceID = 1,
                RoleID = 1,
                Definition = "test",
                Display = "test",
                IsEditAccess = true,
                Source = "test",
            };
            var existingRoleResourceMapping = new Domain.V1.Entities.UserGroups.RoleResourceMapping
            {
                Id = roleResourceMappingId,
                Code = "test",
                ResourceID = 1,
                RoleID = 1,
                Definition = "test",
                Display = "test",
                IsEditAccess = true,
                Source = "test",
                CreatedBy = "Admin",
                CreatedDate = DateTime.UtcNow,
                IsDeleted = false
            };

            _mockRoleResourceMappingQueryService
                .Setup(service => service.FindRoleResourceMappingById(roleResourceMappingId))
                .ReturnsAsync(existingRoleResourceMapping); // Simulate roleResourceMapping found

            _mockRoleResourceMappingCommandService
                .Setup(service => service.UpdateRoleResourceMappingAsync(roleResourceMappingRequest, existingRoleResourceMapping))
                .ReturnsAsync(false); // Simulate update failure

            // Act
            var result = await _controller.UpdateRoleResourceMappingDetails(roleResourceMappingId, roleResourceMappingRequest);

            // Assert
            var actionResult = Assert.IsType<OkObjectResult>(result);
            Assert.Equal(ResponseStatusCode.STATUS_SUCCESS, actionResult.StatusCode.ToString());
        }

        [Fact]
        public async Task GetRoleResourceMappingById_ReturnsOk_WhenRoleResourceMappingIsFound()
        {
            // Arrange
            int roleResourceMappingId = 1;
            var expectedRoleResourceMapping = new GetRoleResourceMappingDetailDto
            {
                Id = roleResourceMappingId,
                Code = "test",
                ResourceID = 1,
                RoleID = 1,
                Definition = "test",
                Display = "test",
                IsEditAccess = true,
                Source = "test",
                IsDeleted = false,
            };
            _mockRoleResourceMappingQueryService.Setup(s => s.GetRoleResourceMappingById(roleResourceMappingId)).ReturnsAsync(expectedRoleResourceMapping);

            // Act
            var result = await _controller.GetRoleResourceMappingById(roleResourceMappingId);

            // Assert
            var actionResult = Assert.IsType<ActionResult<GenericResponse<GetRoleResourceMappingDetailDto>>>(result);
            var okResult = Assert.IsType<OkObjectResult>(actionResult.Result);
            var response = Assert.IsType<GenericResponse<GetRoleResourceMappingDetailDto>>(okResult.Value);
            Assert.True(response.IsSuccess);
            Assert.Equal(ResponseStatusCode.STATUS_SUCCESS, response.StatusCode);
            Assert.Equal(ResponseMessage.STATUS_DATA_FOUND, response.Message);
            Assert.Equal(expectedRoleResourceMapping, response.Result);
        }
    }
}
