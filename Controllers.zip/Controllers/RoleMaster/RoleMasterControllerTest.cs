﻿using Aurora.AdministrationService.API.Controllers.RoleMasters;
using Aurora.AdministrationService.API.Helper;
using Aurora.AdministrationService.API.Models.Dto.PractitionerRoles.RoleMasters;
using Aurora.AdministrationService.API.Services.IService.PractitionerRoles;
using Aurora.AdministrationService.CrossCutting.CommonModels;
using Aurora.AdministrationService.CrossCutting.Constants;
using FluentAssertions;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Moq;

namespace Aurora.AdministrationService.Tests.API.Controllers.RoleMaster
{
    public class RoleMasterControllerTest
    {
        private readonly Mock<IRoleMasterCommandService> _mockRoleMasterCommandService;
        private readonly Mock<IRoleMasterQueryService> _mockRoleMasterQueryService;
        private readonly RoleMasterController _controller;
        private readonly Mock<IRegionCodeValidationHelper> _regionHelperMock;

        public RoleMasterControllerTest()
        {
            _regionHelperMock = new Mock<IRegionCodeValidationHelper>();
            _mockRoleMasterCommandService = new Mock<IRoleMasterCommandService>();
            _mockRoleMasterQueryService = new Mock<IRoleMasterQueryService>();
            _controller = new RoleMasterController(_mockRoleMasterQueryService.Object, _mockRoleMasterCommandService.Object, _regionHelperMock.Object);
        }
        [Fact]
        public void GetRoleMasters_InvalidRegionCode_ReturnsBadRequest()
        {
            // Arrange
            _regionHelperMock
                .Setup(helper => helper.VerifyRegionCodeHeader(It.IsAny<HttpRequest>()))
                .Returns(new GenericResponse<string> { HasError = true, Message = "Invalid RegionCode" });

            // Act
            var result =  _controller.GetRoleMasterList();

            // Assert
            var badRequestResult = result.Result as BadRequestObjectResult;
            badRequestResult.Should().NotBeNull();
            var response = badRequestResult?.Value as GenericResponse<string>;
            response.Should().NotBeNull();
            response?.HasError.Should().BeTrue();
            response?.Message.Should().Be("Invalid RegionCode");
        }

        [Fact]
        public void CreateRoleMaster_InvalidRegionCode_ReturnsBadRequest()
        {
            // Arrange
            var roleMaster = new CreateRoleMasterRequest()
            {
                Id = 1,
                Code = "Test",
                Definition = "test",
                Source = "source",
            };
            _regionHelperMock
                .Setup(helper => helper.VerifyRegionCodeHeader(It.IsAny<HttpRequest>()))
                .Returns(new GenericResponse<string> { HasError = true, Message = "Invalid RegionCode" });

            // Act
            var result = _controller.CreateRoleMaster(roleMaster);

            // Assert
            var badRequestResult = result?.Result as BadRequestObjectResult;
            badRequestResult.Should().NotBeNull();
            var response = badRequestResult?.Value as GenericResponse<string>;
            response.Should().NotBeNull();
            response?.HasError.Should().BeTrue();
            response?.Message.Should().Be("Invalid RegionCode");
        }

        [Fact]
        public async Task GetRoleMasterById_InvalidRegionCode_ReturnsBadRequest()
        {
            // Arrange
            _regionHelperMock
                .Setup(helper => helper.VerifyRegionCodeHeader(It.IsAny<HttpRequest>()))
                .Returns(new GenericResponse<string> { HasError = true, Message = "Invalid RegionCode" });

            // Act
            var result = await _controller.GetRoleMasterById(1);

            // Assert
            var badRequestResult = result.Result as BadRequestObjectResult;
            
            badRequestResult.Should().NotBeNull();
            var response = badRequestResult?.Value as GenericResponse<string>;
            response.Should().NotBeNull();
            response?.HasError.Should().BeTrue();
            response?.Message.Should().Be("Invalid RegionCode");
        }

        [Fact]
        public void UpdateRoleMasterDetails_InvalidRegionCode_ReturnsBadRequest()
        {
            // Arrange
            byte[] concurrencyToken = new byte[8] { byte.MinValue, byte.MinValue, byte.MinValue, byte.MinValue, byte.MinValue, byte.MinValue, byte.MinValue, byte.MaxValue };
            int id = 1;
            var roleMaster = new UpdateRoleMasterRequest()
            {
                Id = 1,
                Code = "Test",
                Definition = "test",
                Source = "source",
                RecordVersion = concurrencyToken
            };
            _regionHelperMock
                .Setup(helper => helper.VerifyRegionCodeHeader(It.IsAny<HttpRequest>()))
                .Returns(new GenericResponse<string> { HasError = true, Message = "Invalid RegionCode" });

            // Act
            var result =  _controller.UpdateRoleMasterDetails(id, roleMaster);

            // Assert
            var badRequestResult = result?.Result as BadRequestObjectResult;
            badRequestResult.Should().NotBeNull();
            var response = badRequestResult?.Value as GenericResponse<string>;
            response.Should().NotBeNull();
            response?.HasError.Should().BeTrue();
            response?.Message.Should().Be("Invalid RegionCode");
        }

        [Fact]
        public async Task CreateRoleMaster_ShouldReturnSuccessResponse_WhenIsAdded()
        {
            // Arrange
            var roleMaster = new CreateRoleMasterRequest()
            {
                Id = 1,
                Code = "Test",
                Definition = "test",
                Source = "source",
            };
            _mockRoleMasterCommandService.Setup(service => service.CreateRoleMasterAsync(roleMaster)).ReturnsAsync(true);

            // Act
            var result = await _controller.CreateRoleMaster(roleMaster) as OkObjectResult;
            var response = result?.Value as GenericResponse<string>;

            // Assert
            result.Should().NotBeNull();
            result?.StatusCode.Should().Be(200);
            response?.IsSuccess.Should().BeTrue();
            response?.StatusCode.Should().Be(ResponseStatusCode.STATUS_SUCCESS);
            response?.Message.Should().Be(ResponseMessage.STATUS_DATA_ADDED);
        }

        [Fact]
        public void GetRoleMasterList_ShouldReturnRoleMasterList()
        {
            // Arrange
            var roleMasterList = new List<GetRoleMasterDto> { new GetRoleMasterDto() };
            _mockRoleMasterQueryService.Setup(service => service.GetRoleMasterList()).Returns(roleMasterList);

            // Act
            var result = _controller.GetRoleMasterList();
            var okresult = result?.Result as OkObjectResult;
            var response = okresult?.Value as GenericResponseList<GetRoleMasterDto>;

            // Assert
            result.Should().NotBeNull();
            response?.StatusCode.Should().Be("200");
            response?.IsSuccess.Should().BeTrue();
            response?.StatusCode.Should().Be(ResponseStatusCode.STATUS_SUCCESS);
            response?.Message.Should().Be(ResponseMessage.STATUS_DATA_FOUND);
            response?.TotalCount.Should().Be(roleMasterList.Count);

        }

        [Fact]
        public async Task GetRoleMasterById_ShouldReturnNull_WhenIdIsInvalid()
        {
            // Act
            var result = await _controller.GetRoleMasterById(null);
            var response = result.Value as GenericResponse<GetRoleMasterDetailDto>;

            // Assert
            result.Should().NotBeNull();
            response.Should().BeNull();

        }

        [Fact]
        public async Task GetRoleMasterById_ShouldReturnNotFound_WhenDoesNotExist()
        {
            // Arrange
            var id = 1L;
            GetRoleMasterDetailDto roleMasterDetailDto = new GetRoleMasterDetailDto ();
            _mockRoleMasterQueryService
              .Setup(service =>  service.GetRoleMasterById(2)).ReturnsAsync(roleMasterDetailDto);

            // Act
            var result = await _controller.GetRoleMasterById(id);
            var okobjectresult = result?.Result as OkObjectResult;
            var response = okobjectresult?.Value as GenericResponse<GetRoleMasterDetailDto>;

            // Assert
            result.Should().NotBeNull();
            response?.IsSuccess.Should().BeTrue();
            response?.StatusCode.Should().Be(ResponseStatusCode.STATUS_NOTFOUND);
            response?.Message.Should().Be(ResponseMessage.STATUS_NODATA);
        }

        [Fact]
        public async Task UpdateRoleMasterDetails_ShouldReturnBadRequest_WhenAlreadyExists()
        {
            // Arrange
            byte[] concurrencyToken = new byte[8] { byte.MinValue, byte.MinValue, byte.MinValue, byte.MinValue, byte.MinValue, byte.MinValue, byte.MinValue, byte.MaxValue };
            int id = 1;
            var roleMaster = new UpdateRoleMasterRequest()
            {
                Id = 1,
                Code = "Test",
                Definition = "test",
                Source = "source",
                RecordVersion = concurrencyToken,
            };
            _mockRoleMasterQueryService.Setup(service => service.IsRoleMasterAlreadyExist(id)).ReturnsAsync((true, ResponseMessage.STATUS_NODATA));

            // Act
            var result = await _controller.UpdateRoleMasterDetails(id, roleMaster);

            // Assert
            result.Should().NotBeNull();

        }

        [Fact]
        public async Task UpdateRoleMasterDetails_RoleMasterNotFound_ReturnsNotFound()
        {
            // Arrange
            byte[] concurrencyToken = new byte[8] { byte.MinValue, byte.MinValue, byte.MinValue, byte.MinValue, byte.MinValue, byte.MinValue, byte.MinValue, byte.MaxValue };
            int roleMasterId = 1;
            var roleMasterRequest = new UpdateRoleMasterRequest()
            {
                Id = roleMasterId,
                Code = "Test",
                Definition = "test",
                Source = "source",
                RecordVersion = concurrencyToken,
            };
            Domain.V1.Entities.PractitionerRoles.RoleMaster? roleMaster = null;
            _mockRoleMasterQueryService
                .Setup(service => service.FindRoleMasterById(roleMasterId))
                .ReturnsAsync(roleMaster);

            // Act
            var result = await _controller.UpdateRoleMasterDetails(roleMasterId, roleMasterRequest);

            // Assert
            var actionResult = Assert.IsType<NotFoundObjectResult>(result);
            var response = Assert.IsType<GenericResponse<string>>(actionResult.Value);
            Assert.Equal(ResponseStatusCode.STATUS_NOTFOUND, response.StatusCode);
            Assert.Equal(ResponseMessage.STATUS_NODATA, response.Message);
        }

        [Fact]
        public async Task UpdateRoleMasterDetails_UpdateSuccessful_ReturnsOk()
        {
            // Arrange
            byte[] concurrencyToken = new byte[8] { byte.MinValue, byte.MinValue, byte.MinValue, byte.MinValue, byte.MinValue, byte.MinValue, byte.MinValue, byte.MaxValue };
            int roleMasterId = 1;
            var roleMasterRequest = new UpdateRoleMasterRequest()
            {
                Id = 1,
                Code = "Test",
                Definition = "test",
                Source = "source",
                RecordVersion = concurrencyToken
            };
            var existingRoleMaster = new Domain.V1.Entities.PractitionerRoles.RoleMaster 
            { 
                Id = roleMasterId,
                Code = "Test",
                Definition = "test",
                Source = "source",
                CreatedBy = "Admin", 
                CreatedDate = DateTime.UtcNow, 
                IsDeleted = false 
            };

            _mockRoleMasterQueryService
                .Setup(service => service.FindRoleMasterById(roleMasterId))
                .ReturnsAsync(existingRoleMaster);

            _mockRoleMasterCommandService
                .Setup(service => service.UpdateRoleMasterAsync(roleMasterRequest, existingRoleMaster))
                .ReturnsAsync(true);

            // Act
            var result = await _controller.UpdateRoleMasterDetails(roleMasterId, roleMasterRequest);

            // Assert
            var actionResult = Assert.IsType<OkObjectResult>(result);
            var response = Assert.IsType<GenericResponse<string>>(actionResult.Value);
            Assert.Equal(ResponseStatusCode.STATUS_SUCCESS, response.StatusCode);
            Assert.Equal(ResponseMessage.STATUS_DATA_UPDATED, response.Message);
            Assert.Equal(CommonConstants.SUCCESS, response.MessageType);
        }

        [Fact]
        public async Task UpdateRoleMasterDetails_UpdateFailed_ReturnsOkWithErrorMessage()
        {
            // Arrange
            byte[] concurrencyToken = new byte[8] { byte.MinValue, byte.MinValue, byte.MinValue, byte.MinValue, byte.MinValue, byte.MinValue, byte.MinValue, byte.MaxValue };
            int roleMasterId = 1;
            var roleMasterRequest = new UpdateRoleMasterRequest()
            {
                Id = roleMasterId,
                Code = "Test",
                Definition = "test",
                Source = "source",
                RecordVersion = concurrencyToken
            };
            var existingRoleMaster = new Domain.V1.Entities.PractitionerRoles.RoleMaster 
            { 
                Id = roleMasterId,
                Code = "Test",
                Definition = "test",
                Source = "source",
                CreatedBy = "Admin", 
                CreatedDate = DateTime.UtcNow, 
                IsDeleted = false 
            };

            _mockRoleMasterQueryService
                .Setup(service => service.FindRoleMasterById(roleMasterId))
                .ReturnsAsync(existingRoleMaster); // Simulate roleMaster found

            _mockRoleMasterCommandService
                .Setup(service => service.UpdateRoleMasterAsync(roleMasterRequest, existingRoleMaster))
                .ReturnsAsync(false); // Simulate update failure

            // Act
            var result = await _controller.UpdateRoleMasterDetails(roleMasterId, roleMasterRequest);

            // Assert
            var actionResult = Assert.IsType<OkObjectResult>(result);
            Assert.Equal(ResponseStatusCode.STATUS_SUCCESS, actionResult.StatusCode.ToString());
        }

        [Fact]
        public async Task GetRoleMasterById_ReturnsOk_WhenRoleMasterIsFound()
        {
            // Arrange
            int roleMasterId = 1;
            byte[] concurrencyToken = new byte[8] { byte.MinValue, byte.MinValue, byte.MinValue, byte.MinValue, byte.MinValue, byte.MinValue, byte.MinValue, byte.MaxValue };
            var expectedRoleMaster = new GetRoleMasterDetailDto
            {
                Id = roleMasterId,
                Code = "Test"
            };
            _mockRoleMasterQueryService.Setup(s => s.GetRoleMasterById(roleMasterId)).ReturnsAsync(expectedRoleMaster);

            // Act
            var result = await _controller.GetRoleMasterById(roleMasterId);

            // Assert
            var actionResult = Assert.IsType<ActionResult<GenericResponse<GetRoleMasterDetailDto>>>(result);
            var okResult = Assert.IsType<OkObjectResult>(actionResult.Result);
            var response = Assert.IsType<GenericResponse<GetRoleMasterDetailDto>>(okResult.Value);
            Assert.True(response.IsSuccess);
            Assert.Equal(ResponseStatusCode.STATUS_SUCCESS, response.StatusCode);
            Assert.Equal(ResponseMessage.STATUS_DATA_FOUND, response.Message);
            Assert.Equal(expectedRoleMaster, response.Result);
        }
    }
}
