﻿using Aurora.AdministrationService.API.Controllers.Login;
using Aurora.AdministrationService.API.Helper;
using Aurora.AdministrationService.API.Models.Dto.Users;
using Aurora.AdministrationService.API.Models.RequestModels.AdminUser;
using Aurora.AdministrationService.API.Services.IService.OTP.Token;
using Aurora.AdministrationService.API.Services.IService.Users;
using Aurora.AdministrationService.API.Services.IService.Users.UserIdentifiers;
using Aurora.AdministrationService.API.Services.IService.Users.UserTelecoms;
using Aurora.AdministrationService.CrossCutting.CommonModels;
using AutoMapper;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Moq;

namespace Aurora.AdministrationService.API.Tests.Controllers.Login
{
    public class LoginControllerTests
    {
        private readonly Mock<IUserQueryService> _userMasterQueryServiceMock;
        private readonly Mock<IUserIdentifierQueryService> _userIdentifierQueryServiceMock;
        private readonly Mock<ITokenQueryService> _tokenServiceMock;
        private readonly Mock<IRegionCodeValidationHelper> _regionHelperMock;
        private readonly Mock<IUserTelecomQueryService> _userTelecomQueryServiceMock;
        private readonly Mock<IMapper> _mapperMock;
        private readonly LoginController _controller;

        public LoginControllerTests()
        {
            // Mock dependencies
            _userTelecomQueryServiceMock = new Mock<IUserTelecomQueryService>();
            _userMasterQueryServiceMock = new Mock<IUserQueryService>();
            _userIdentifierQueryServiceMock = new Mock<IUserIdentifierQueryService>();
            _tokenServiceMock = new Mock<ITokenQueryService>();
            _regionHelperMock = new Mock<IRegionCodeValidationHelper>();
            _mapperMock = new Mock<IMapper>();

            // Initialize controller
            _controller = new LoginController(
                _mapperMock.Object,
                _userMasterQueryServiceMock.Object,
                _userTelecomQueryServiceMock.Object,
                _userIdentifierQueryServiceMock.Object,
                _regionHelperMock.Object,
                _tokenServiceMock.Object
            );
        }

        #region Test: PatientLogin

        [Fact]
        public async Task PatientLogin_ReturnsBadRequest_WhenRegionCodeIsInvalid()
        {
            // Arrange
            var request = new RequestSignInUserDto { UserId = "testuser", Password = "password" };
            _regionHelperMock.Setup(r => r.VerifyRegionCodeHeader(It.IsAny<HttpRequest>()))
                .Returns(new GenericResponse<string> { IsSuccess = false, HasError = true, Message = "Invalid RegionCode" });

            // Act
            var result = await _controller.PatientLogin(request);

            // Assert
            var badRequestResult = Assert.IsType<BadRequestObjectResult>(result);
            var response = Assert.IsType<GenericResponse<string>>(badRequestResult.Value);
            Assert.False(response.IsSuccess);
            Assert.Equal("Invalid RegionCode", response.Message);
        }

        [Fact]
        public async Task PatientLogin_ReturnsBadRequest_WhenUsernameAndPasswordAreEmpty()
        {
            // Arrange
            var request = new RequestSignInUserDto { UserId = "", Password = "" };
            _regionHelperMock.Setup(r => r.VerifyRegionCodeHeader(It.IsAny<HttpRequest>()))
                .Returns(new GenericResponse<string> { IsSuccess = true, Result = "MYS" });

            // Act
            var result = await _controller.PatientLogin(request);

            // Assert
            var badRequestResult = Assert.IsType<BadRequestObjectResult>(result);
            var response = Assert.IsType<GenericResponse<string>>(badRequestResult.Value);
            Assert.False(response.IsSuccess);
            Assert.Equal(ResponseMessage.STATUS_INVALID_REQUEST, response.Message);
        }

        [Fact]
        public async Task PatientLogin_ReturnsNotFound_WhenUserIdentifierDoesNotExist()
        {
            // Arrange
            var request = new RequestSignInUserDto { UserId = "nonexistent", Password = "password" };
            _regionHelperMock.Setup(r => r.VerifyRegionCodeHeader(It.IsAny<HttpRequest>()))
                .Returns(new GenericResponse<string> { IsSuccess = true, Result = "MYS" });

            _userIdentifierQueryServiceMock.Setup(s => s.IsUserIdentifierAlreadyExist(It.IsAny<string>()))
                .Returns((false, 0));

            // Act
            var result = await _controller.PatientLogin(request);

            // Assert
            var notFoundResult = Assert.IsType<BadRequestObjectResult>(result);
            var response = Assert.IsType<GenericResponse<string>>(notFoundResult.Value);
            Assert.False(response.IsSuccess);
            Assert.Equal(ResponseMessage.INVALID_CREDENTIAL, response.Message);
        }

        [Fact]
        public async Task PatientLogin_ReturnsUnauthorized_WhenPasswordDoesNotMatch()
        {
            // Arrange
            var request = new RequestSignInUserDto { UserId = "testuser", Password = "wrongpassword" };
            _regionHelperMock.Setup(r => r.VerifyRegionCodeHeader(It.IsAny<HttpRequest>()))
                .Returns(new GenericResponse<string> { IsSuccess = true, Result = "MYS" });

            _userIdentifierQueryServiceMock.Setup(s => s.IsUserIdentifierAlreadyExist(It.IsAny<string>()))
                .Returns((true, 1));

            _userMasterQueryServiceMock.Setup(s => s.SignInAsync(It.IsAny<long>(), It.IsAny<string>()))
                .Returns((new UserSignInResponseDto { Password = "correctpassword", Id = 1, UserType = "Patient" }, false));

            // Act
            var result = await _controller.PatientLogin(request);

            // Assert
            var unauthorizedResult = Assert.IsType<NotFoundObjectResult>(result);
            var response = Assert.IsType<GenericResponse<string>>(unauthorizedResult.Value);
            Assert.False(response.IsSuccess);
            Assert.Equal(ResponseMessage.INCORRECT_PASSWORD, response.Message);
        }

        [Fact]
        public async Task PatientLogin_ReturnsOk_WhenValidCredentials()
        {
            // Arrange
            var request = new RequestSignInUserDto { UserId = "testuser", Password = "password" };
            _regionHelperMock.Setup(r => r.VerifyRegionCodeHeader(It.IsAny<HttpRequest>()))
                .Returns(new GenericResponse<string> { IsSuccess = true, Result = "MYS" });

            _userIdentifierQueryServiceMock.Setup(s => s.IsUserIdentifierAlreadyExist(It.IsAny<string>()))
                .Returns((true, 1));

            _userMasterQueryServiceMock.Setup(s => s.SignInAsync(It.IsAny<long>(), It.IsAny<string>()))
                .Returns((new UserSignInResponseDto { Password = "password", Id = 1, UserType = "Patient" }, true));

            _tokenServiceMock.Setup(t => t.GenerateToken(It.IsAny<string>(), It.IsAny<string>()))
                .ReturnsAsync("generated_token");
            _mapperMock.Setup(x => x.Map<LoginSuccessResponseDto>(It.IsAny<UserSignInResponseDto>()))
                .Returns(new LoginSuccessResponseDto()
                {

                });

            // Act
            var result = await _controller.PatientLogin(request);

            // Assert
            var okResult = Assert.IsType<OkObjectResult>(result);
            var response = Assert.IsType<GenericResponse<LoginSuccessResponseDto>>(okResult.Value);
            Assert.True(response.IsSuccess);
            Assert.Equal("generated_token", response?.Result?.Token);
        }

        #endregion

        #region Test: AdminLogin

        [Fact]
        public async Task AdminLogin_ReturnsBadRequest_WhenRegionCodeIsInvalid()
        {
            // Arrange
            var request = new AdminLoginRequest { Username = "adminuser", Password = "adminpassword" };
            _regionHelperMock.Setup(r => r.VerifyRegionCodeHeader(It.IsAny<HttpRequest>()))
                .Returns(new GenericResponse<string> { IsSuccess = false, HasError = true, Message = "Invalid RegionCode" });

            // Act
            var result = await _controller.AdminLogin(request);

            // Assert
            var badRequestResult = Assert.IsType<BadRequestObjectResult>(result);
            var response = Assert.IsType<GenericResponse<string>>(badRequestResult.Value);
            Assert.False(response.IsSuccess);
            Assert.Equal("Invalid RegionCode", response.Message);
        }

        [Fact]
        public async Task AdminLogin_ReturnsBadRequest_WhenUsernameAndPasswordAreEmpty()
        {
            // Arrange
            var request = new AdminLoginRequest { Username = "", Password = "" };
            _regionHelperMock.Setup(r => r.VerifyRegionCodeHeader(It.IsAny<HttpRequest>()))
                .Returns(new GenericResponse<string> { IsSuccess = true, Result = "MYS" });

            // Act
            var result = await _controller.AdminLogin(request);

            // Assert
            var badRequestResult = Assert.IsType<BadRequestObjectResult>(result);
            var response = Assert.IsType<GenericResponse<string>>(badRequestResult.Value);
            Assert.False(response.IsSuccess);
            Assert.Equal(ResponseMessage.STATUS_INVALID_REQUEST, response.Message);
        }

        [Fact]
        public async Task AdminLogin_ReturnsNotFound_WhenUserNotFound()
        {
            // Arrange
            var request = new AdminLoginRequest { Username = "nonexistentadmin", Password = "password" };
            _regionHelperMock.Setup(r => r.VerifyRegionCodeHeader(It.IsAny<HttpRequest>()))
                .Returns(new GenericResponse<string> { IsSuccess = true, Result = "MYS" });

            _userMasterQueryServiceMock.Setup(s => s.AdminSignInAsync(It.IsAny<string>(), It.IsAny<string>()))
                .Returns((new AdminSignInResponseDto { Password = "", Id = 0, UserType = "" }, false));

            // Act
            var result = await _controller.AdminLogin(request);

            // Assert
            var notFoundResult = Assert.IsType<NotFoundObjectResult>(result);
            var response = Assert.IsType<GenericResponse<string>>(notFoundResult.Value);
            Assert.False(response.IsSuccess);
            Assert.Equal(ResponseMessage.INVALID_CREDENTIAL, response.Message);
        }

        [Fact]
        public async Task AdminLogin_ReturnsUnauthorized_WhenPasswordDoesNotMatch()
        {
            // Arrange
            var request = new AdminLoginRequest { Username = "adminuser", Password = "wrongpassword" };
            _regionHelperMock.Setup(r => r.VerifyRegionCodeHeader(It.IsAny<HttpRequest>()))
                .Returns(new GenericResponse<string> { IsSuccess = true, Result = "MYS" });

            _userMasterQueryServiceMock.Setup(s => s.AdminSignInAsync(It.IsAny<string>(), It.IsAny<string>()))
                .Returns((new AdminSignInResponseDto { Password = "correctpassword", Id = 1, UserType = "Admin" }, false));

            // Act
            var result = await _controller.AdminLogin(request);

            // Assert
            var unauthorizedResult = Assert.IsType<NotFoundObjectResult>(result);
            var response = Assert.IsType<GenericResponse<string>>(unauthorizedResult.Value);
            Assert.False(response.IsSuccess);
            Assert.Equal(ResponseMessage.INCORRECT_PASSWORD, response.Message);
        }

        [Fact]
        public async Task AdminLogin_ReturnsOk_WhenValidCredentials()
        {
            // Arrange
            var request = new AdminLoginRequest { Username = "adminuser", Password = "adminpassword" };
            _regionHelperMock.Setup(r => r.VerifyRegionCodeHeader(It.IsAny<HttpRequest>()))
                .Returns(new GenericResponse<string> { IsSuccess = true, Result = "MYS" });

            _userMasterQueryServiceMock.Setup(s => s.AdminSignInAsync(It.IsAny<string>(), It.IsAny<string>()))
                .Returns((new AdminSignInResponseDto { Password = "adminpassword", Id = 1, UserType = "Admin" }, true));

            _tokenServiceMock.Setup(t => t.GenerateToken(It.IsAny<string>(), It.IsAny<string>()))
                .ReturnsAsync("generated_admin_token");

            // Act
            var result = await _controller.AdminLogin(request);

            // Assert
            var okResult = Assert.IsType<OkObjectResult>(result);
            var response = Assert.IsType<GenericResponse<AdminLoginSuccessResponseDto>>(okResult.Value);
            Assert.True(response.IsSuccess);
            Assert.Equal("generated_admin_token", response?.Result?.Token);
        }

        #endregion


        [Fact]
        public async Task PatientLogin_ShouldReturnSuccess_WhenMalaysiaRegionCode()
        {
            // Arrange
            var request = new RequestSignInUserDto
            {
                UserId = "testUsername",
                Password = "testPassword"
            };

            var userId = 1L;
            var userDetails = new UserSignInResponseDto
            {
                Id = userId,
                Password = "testPassword",
                UserType = "Patient"
            };

            // Simulate Malaysia region code
            _regionHelperMock.Setup(helper => helper.VerifyRegionCodeHeader(It.IsAny<Microsoft.AspNetCore.Http.HttpRequest>()))
                .Returns(new GenericResponse<string> { IsSuccess = true, HasError = false, Result = RegionCode.MALAYSIA_REGION_CODE.ToString() });

            _userIdentifierQueryServiceMock.Setup(service => service.IsUserIdentifierAlreadyExist(It.IsAny<string>()))
                .Returns((true, userId));  // Simulate identifier already existing

            _userMasterQueryServiceMock.Setup(service => service.SignInAsync(It.IsAny<long>(), It.IsAny<string>()))
                .Returns((userDetails, true));  // Simulate password match

            _tokenServiceMock.Setup(service => service.GenerateToken(It.IsAny<string>(), It.IsAny<string>()))
                .ReturnsAsync("testToken");  // Simulate token generation

            _mapperMock.Setup(mapper => mapper.Map<LoginSuccessResponseDto>(It.IsAny<UserSignInResponseDto>()))
                .Returns(new LoginSuccessResponseDto { Token = "testToken" });

            // Act
            var result = await _controller.PatientLogin(request);

            // Assert
            var okResult = Assert.IsType<OkObjectResult>(result);
            var response = Assert.IsType<GenericResponse<LoginSuccessResponseDto>>(okResult.Value);
            Assert.True(response.IsSuccess);
            Assert.Equal("testToken", response?.Result?.Token);
        }

        [Fact]
        public async Task PatientLogin_ShouldReturnSuccess_WhenIndonesiaRegionCode()
        {
            // Arrange
            var request = new RequestSignInUserDto
            {
                UserId = "testUsername",
                Password = "testPassword"
            };

            var userId = 1L;
            var userDetails = new UserSignInResponseDto
            {
                Id = userId,
                Password = "testPassword",
                UserType = "Patient"
            };

            // Simulate Indonesia region code
            _regionHelperMock.Setup(helper => helper.VerifyRegionCodeHeader(It.IsAny<Microsoft.AspNetCore.Http.HttpRequest>()))
                .Returns(new GenericResponse<string> { IsSuccess = true, HasError = false, Result = RegionCode.INDONESIA_REGION_CODE.ToString() });

            _userIdentifierQueryServiceMock.Setup(service => service.IsUserIdentifierAlreadyExist(It.IsAny<string>()))
                .Returns((true, userId));  // Simulate identifier already existing

            _userMasterQueryServiceMock.Setup(service => service.SignInAsync(It.IsAny<long>(), It.IsAny<string>()))
                .Returns((userDetails, true));  // Simulate password match

            _tokenServiceMock.Setup(service => service.GenerateToken(It.IsAny<string>(), It.IsAny<string>()))
                .ReturnsAsync("testToken");  // Simulate token generation

            _mapperMock.Setup(mapper => mapper.Map<LoginSuccessResponseDto>(It.IsAny<UserSignInResponseDto>()))
                .Returns(new LoginSuccessResponseDto { Token = "testToken" });

            // Act
            var result = await _controller.PatientLogin(request);

            // Assert
            var okResult = Assert.IsType<OkObjectResult>(result);
            var response = Assert.IsType<GenericResponse<LoginSuccessResponseDto>>(okResult.Value);
            Assert.True(response.IsSuccess);
            Assert.Equal("testToken", response?.Result?.Token);
        }

        [Fact]
        public async Task PatientLogin_ShouldReturnSuccess_WhenVietnamRegionCode()
        {
            // Arrange
            var request = new RequestSignInUserDto
            {
                UserId = "testUsername",
                Password = "testPassword"
            };

            var userId = 1L;
            var userDetails = new UserSignInResponseDto
            {
                Id = userId,
                Password = "testPassword",
                UserType = "Patient"
            };

            // Simulate Vietnam region code
            _regionHelperMock.Setup(helper => helper.VerifyRegionCodeHeader(It.IsAny<Microsoft.AspNetCore.Http.HttpRequest>()))
                .Returns(new GenericResponse<string> { IsSuccess = true, HasError = false, Result = RegionCode.VIETNAM_REGION_CODE.ToString() });

            _userIdentifierQueryServiceMock.Setup(service => service.IsUserIdentifierAlreadyExist(It.IsAny<string>()))
                .Returns((true, userId));  // Simulate identifier already existing

            _userMasterQueryServiceMock.Setup(service => service.SignInAsync(It.IsAny<long>(), It.IsAny<string>()))
                .Returns((userDetails, true));  // Simulate password match

            _tokenServiceMock.Setup(service => service.GenerateToken(It.IsAny<string>(), It.IsAny<string>()))
                .ReturnsAsync("testToken");  // Simulate token generation

            _mapperMock.Setup(mapper => mapper.Map<LoginSuccessResponseDto>(It.IsAny<UserSignInResponseDto>()))
                .Returns(new LoginSuccessResponseDto { Token = "testToken" });

            // Act
            var result = await _controller.PatientLogin(request);

            // Assert
            var okResult = Assert.IsType<OkObjectResult>(result);
            var response = Assert.IsType<GenericResponse<LoginSuccessResponseDto>>(okResult.Value);
            Assert.True(response.IsSuccess);
            Assert.Equal("testToken", response?.Result?.Token);
        }

      
    }

}
