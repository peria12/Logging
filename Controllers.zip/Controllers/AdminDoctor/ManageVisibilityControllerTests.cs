﻿using System.Collections.Generic;
using System.Threading.Tasks;
using Aurora.AdministrationService.API.Controllers.AdminDoctor;
using Aurora.AdministrationService.API.Enum;
using Aurora.AdministrationService.API.Helper;
using Aurora.AdministrationService.API.Models.Dto.ManageVisibility;
using Aurora.AdministrationService.API.Models.ResponseModels.Doctors;
using Aurora.AdministrationService.API.Models.ResponseModels.Schedules;
using Aurora.AdministrationService.API.Resources;
using Aurora.AdministrationService.API.Services.IService.AdminDoctor;
using Aurora.AdministrationService.CrossCutting.CommonModels;
using Aurora.AdministrationService.CrossCutting.Constants;
using FluentAssertions;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Http.HttpResults;
using Microsoft.AspNetCore.Mvc;
using Moq;
using Xunit;

namespace ManageVisibilityControllerTests
{
    public class ManageVisibilityControllerTests
    {
        private readonly Mock<IManageVisibilityCommandService> _mockManageVisibilityCommandService;
        private readonly Mock<IManageVisibilityQueryService> _mockManageVisibilityQueryService;
        private readonly Mock<IRegionCodeValidationHelper> _mockRegionHelper;
        private readonly ManageVisibilityController _controller;

        public ManageVisibilityControllerTests()
        {
            _mockManageVisibilityCommandService = new Mock<IManageVisibilityCommandService>();
            _mockManageVisibilityQueryService= new Mock<IManageVisibilityQueryService>();
            _mockRegionHelper = new Mock<IRegionCodeValidationHelper>();
            _controller = new ManageVisibilityController(_mockManageVisibilityCommandService.Object, _mockRegionHelper.Object, _mockManageVisibilityQueryService.Object);
        }

        [Fact]
        public async Task UpdateManageVisibility_Should_Return_Ok_When_Result_Is_Success()
        {
            // Arrange
            var doctorVisibilityRequest = new List<ManageVisibilityRequestDto>
            {
                new ManageVisibilityRequestDto
                {
                    ManageVisibilityId = 1,
                    LocationID = "Loc1",
                    PractitionerID = "Pract1",
                    UserGroups = new List<string> { "Group1" },
                    Action = "I"
                }
            };
            var serviceResult = new GenericResponse<string>()
            {
                HasError = false,
                IsSuccess = true,
                StatusCode = ResponseStatus.STATUS_SUCCESS,
                Result = null,
                Message = Resource.RecordUpdationMessage
            };
            _mockRegionHelper.Setup(helper => helper.VerifyRegionCodeHeader(It.IsAny<HttpRequest>())).Returns((serviceResult));
            _mockManageVisibilityCommandService.Setup(service => service.ManageDoctorsVisibility(doctorVisibilityRequest)).ReturnsAsync((true,ValidationMessage.RECORD_UPDATED_SUCESSFULLY));

            // Act
            var result = await _controller.UpdateManageVisibility(doctorVisibilityRequest);

            // Assert
            var actionResult = Assert.IsType<OkObjectResult>(result);
            var response = Assert.IsType<GenericResponse<string>>(actionResult.Value);
            Assert.Equal(ResponseStatusCode.STATUS_SUCCESS, response.StatusCode);
            Assert.Equal(Resource.RecordUpdationMessage, response.Message);        }

        [Fact]
        public async Task UpdateManageVisibility_Should_Return_BadRequest_When_Result_Has_Error()
        {
            // Arrange
            var doctorVisibilityRequest = new List<ManageVisibilityRequestDto>
            {
                new ManageVisibilityRequestDto
                {
                    ManageVisibilityId = 1,
                    LocationID = "Loc1",
                    PractitionerID = "Pract1",
                    UserGroups = new List<string> { "Group1" },
                    Action = "K"
                }
            };
            _mockRegionHelper.Setup(helper => helper.VerifyRegionCodeHeader(It.IsAny<HttpRequest>())).Returns(new GenericResponse<string> { IsSuccess=true,HasError=false});
           
            // Act
            var result = await _controller.UpdateManageVisibility(doctorVisibilityRequest);

            var actionResult = Assert.IsType<BadRequestObjectResult>(result);
            var response = Assert.IsType<GenericResponse<string>>(actionResult.Value);
            response.Should().NotBeNull();
            response?.HasError.Should().BeTrue();
        }

        [Fact]
        public async Task UpdateManageVisibility_Should_Return_BadRequest_When_RegionCode_Header_Is_Invalid()
        {
            // Arrange
            var doctorVisibilityRequest = new List<ManageVisibilityRequestDto>
            {
                new ManageVisibilityRequestDto
                {
                    ManageVisibilityId = 1,
                    LocationID = "Loc1",
                    PractitionerID = "Pract1",
                    UserGroups = new List<string> { "Group1" },
                    Action = "U"
                }
            };

            var verifyStatus = new GenericResponse<string>()
            {
                IsSuccess = false,
                HasError = true,
                StatusCode = ResponseStatus.STATUS_BadRequest,
                Message = Resource.RegionCodeRequired
            };
            _mockRegionHelper.Setup(helper => helper.VerifyRegionCodeHeader(It.IsAny<HttpRequest>())).Returns(verifyStatus);


            // Act
            var result = await _controller.UpdateManageVisibility(doctorVisibilityRequest);

            // Assert
            var badRequestResult = Assert.IsType<BadRequestObjectResult>(result);
            Assert.Equal(verifyStatus, badRequestResult.Value);
        }
        [Fact]
        public void GetUserGroupDropDownList_Should_Return_BadRequest_When_Region_Verification_Fails()
        {
            // Arrange
            var verifyStatus = new GenericResponse<string>()
            {
                IsSuccess = false,
                HasError = true,
                StatusCode = ResponseStatus.STATUS_BadRequest,
                Message = Resource.RegionCodeRequired
            };

            // Mock the region helper to return an error
            _mockRegionHelper.Setup(x => x.VerifyRegionCodeHeader(It.IsAny<HttpRequest>())).Returns(verifyStatus);

            // Act
            var result =  _controller.GetUserGroupDropDownList();

            // Assert
            var badRequestResult = Assert.IsType<BadRequestObjectResult>(result);
            Assert.Equal(verifyStatus, badRequestResult.Value);
        
        }

        [Fact]
        public void GetUserGroupDropDownList_Should_Return_NoData_Response_When_UserGroups_Are_Empty()
        {
            // Arrange
            var serviceResult = new GenericResponse<string>()
            {
                HasError = false,
                IsSuccess = true,
                StatusCode = ResponseStatus.STATUS_SUCCESS,
                Result = null,
                Message = Resource.RecordUpdationMessage
            };

            // Mock the region helper to return no error
            _mockRegionHelper.Setup(x => x.VerifyRegionCodeHeader(It.IsAny<HttpRequest>())).Returns(serviceResult);

            // Mock GetUserGroups to return null
            _mockManageVisibilityQueryService.Setup(x => x.GetUserGroups()).Returns((new List<GetAllUserGroupsResponse>()));

            // Act
            var result = _controller.GetUserGroupDropDownList();

            // Assert
            var actionResult = Assert.IsType<OkObjectResult>(result);
            var response = Assert.IsType<GenericResponseList<GetAllUserGroupsResponse>>(actionResult.Value);
            Assert.True(response.IsSuccess); // Verify success flag is true
            Assert.False(response.HasError); // Ensure there’s no error
            Assert.Equal(((int)ResponceStatusCode.RecordNotFound).ToString(), response.StatusCode);
            Assert.Equal(ResponseMessage.STATUS_NODATA, response.Message);
            Assert.Null(response.Results); // Result should be null if no user groups
        }

        [Fact]
        public void GetUserGroupDropDownList_Should_Return_Success_Response_When_UserGroups_Are_Found()
        {
            // Arrange
            var mockUserGroups = new List<GetAllUserGroupsResponse>
        {
            new() { Id = 1, GroupName = "Admin" },
            new() { Id = 2, GroupName = "User" }
        };
            var serviceResult = new GenericResponse<string>()
            {
                HasError = false,
                IsSuccess = true,
                StatusCode = ResponseStatus.STATUS_SUCCESS,
                Result = null,
                Message = Resource.RecordUpdationMessage
            };

            // Mock the region helper to return no error
            _mockRegionHelper.Setup(x => x.VerifyRegionCodeHeader(It.IsAny<HttpRequest>())).Returns(serviceResult);

            // Mock GetUserGroups to return a non-null list
            _mockManageVisibilityQueryService.Setup(x => x.GetUserGroups()).Returns(mockUserGroups);

            // Act
            var result =  _controller.GetUserGroupDropDownList();

            // Assert
            var actionResult = Assert.IsType<OkObjectResult>(result);
            var response = Assert.IsType<GenericResponseList<GetAllUserGroupsResponse>>(actionResult.Value);
            Assert.True(response.IsSuccess);
            Assert.False(response.HasError);
            Assert.Equal(((int)ResponceStatusCode.Success).ToString(), response.StatusCode);
            Assert.Equal(ResponseMessage.STATUS_SUCCESS, response.Message);
            Assert.Equal(2, response.Results.Count()); // Verify the correct number of user groups are returned
        }
        [Fact]
        public async Task GetPractitionerLocationDropDownList_Should_Return_BadRequest_When_Region_Verification_Fails()
        {
            // Arrange
            string partitionerId = "123";
            var verifyStatus = new GenericResponse<string> { HasError = true };

            // Mock the region helper to return an error
            _mockRegionHelper.Setup(x => x.VerifyRegionCodeHeader(It.IsAny<HttpRequest>())).Returns(verifyStatus);

            // Act
            var result = await _controller.GetPractitionerLocationDropDownList(partitionerId);

            // Assert
            var badRequestResult = Assert.IsType<BadRequestObjectResult>(result);
            Assert.Equal(400, badRequestResult.StatusCode); // Ensure the status code is 400 (Bad Request)
        }

        [Fact]
        public async Task GetPractitionerLocationDropDownList_Should_Return_NoData_Response_When_No_Locations_Are_Found()
        {
            // Arrange
            string partitionerId = "123";

            // Mock the region helper to return no error
            _mockRegionHelper.Setup(x => x.VerifyRegionCodeHeader(It.IsAny<HttpRequest>())).Returns(new GenericResponse<string> { HasError = false });

            // Mock GetPractitionerLocation to return an empty list (no locations found)
            _mockManageVisibilityQueryService.Setup(x => x.GetPractitionerLocation(partitionerId)).ReturnsAsync(new List<GetPractitionerLocationDropDownDto>());

            // Act
            var result = await _controller.GetPractitionerLocationDropDownList(partitionerId);

            // Assert
            var okResult = Assert.IsType<OkObjectResult>(result); // We expect OkResult because no error occurred
            var dataResponse = Assert.IsType<GenericResponseList<GetPractitionerLocationDropDownDto>>(okResult.Value);
            Assert.True(dataResponse.IsSuccess);  // Verify success flag
            Assert.False(dataResponse.HasError); // Ensure no error flag is set
            Assert.Equal(((int)ResponceStatusCode.RecordNotFound).ToString(), dataResponse.StatusCode);
            Assert.Equal(ResponseMessage.STATUS_NODATA, dataResponse.Message);
        }

        [Fact]
        public async Task GetPractitionerLocationDropDownList_Should_Return_Success_Response_When_Locations_Are_Found()
        {
            // Arrange
            string partitionerId = "123";
            var mockLocations = new List<GetPractitionerLocationDropDownDto>
        {
            new GetPractitionerLocationDropDownDto { Id = 1, ResourceID = "Loc1", Name = "Location1", Alias = "Loc1Alias" },
            new GetPractitionerLocationDropDownDto { Id = 2, ResourceID = "Loc2", Name = "Location2", Alias = "Loc2Alias" }
        };

            // Mock the region helper to return no error
            _mockRegionHelper.Setup(x => x.VerifyRegionCodeHeader(It.IsAny<HttpRequest>())).Returns(new GenericResponse<string> { HasError = false });

            // Mock GetPractitionerLocation to return a list of locations
            _mockManageVisibilityQueryService.Setup(x => x.GetPractitionerLocation(partitionerId)).ReturnsAsync(mockLocations);

            // Act
            var result = await _controller.GetPractitionerLocationDropDownList(partitionerId);

            // Assert
            var okResult = Assert.IsType<OkObjectResult>(result);
            var dataResponse = Assert.IsType<GenericResponseList<GetPractitionerLocationDropDownDto>>(okResult.Value);
            Assert.True(dataResponse.IsSuccess); // Verify success flag
            Assert.False(dataResponse.HasError); // Ensure no error flag is set
            Assert.Equal(((int)ResponceStatusCode.Success).ToString(), dataResponse.StatusCode);
            Assert.Equal(ResponseMessage.STATUS_SUCCESS, dataResponse.Message);
            Assert.Equal(2, dataResponse.Results.Count()); // Verify that two locations are returned
        }

        [Fact]
        public async Task GetPractitionerVisibilityDetails_Should_Return_BadRequest_When_Region_Verification_Fails()
        {
            // Arrange
            string partitionerId = "123";
            var verifyStatus = new GenericResponse<string> { HasError = true };

            // Mock the region helper to return an error
            _mockRegionHelper.Setup(x => x.VerifyRegionCodeHeader(It.IsAny<HttpRequest>())).Returns(verifyStatus);

            // Act
            var result = await _controller.GetPractitionerVisibilityDetails(partitionerId);

            // Assert
            var badRequestResult = Assert.IsType<BadRequestObjectResult>(result);
            Assert.Equal(400, badRequestResult.StatusCode); // Ensure the status code is 400 (Bad Request)
        }

        [Fact]
        public async Task GetPractitionerVisibilityDetails_Should_Return_NoData_Response_When_No_Visibility_Details_Are_Found()
        {
            // Arrange
            string partitionerId = "123";

            // Mock the region helper to return no error
            _mockRegionHelper.Setup(x => x.VerifyRegionCodeHeader(It.IsAny<HttpRequest>())).Returns(new GenericResponse<string> { HasError = false });

            // Mock GetPractitionerVisibilityDetails to return null (no data found)
            _mockManageVisibilityQueryService.Setup(x => x.GetPractitionerVisibilityDetails(partitionerId)).ReturnsAsync((PractitionerVisibilityResponseDto)null);

            // Act
            var result = await _controller.GetPractitionerVisibilityDetails(partitionerId);

            // Assert
            var okResult = Assert.IsType<OkObjectResult>(result);
            var dataResponse = Assert.IsType<GenericResponse<PractitionerVisibilityResponseDto>>(okResult.Value);
            Assert.True(dataResponse.IsSuccess); // Verify success flag
            Assert.False(dataResponse.HasError); // Ensure no error flag is set
            Assert.Equal(((int)ResponceStatusCode.RecordNotFound).ToString(), dataResponse.StatusCode);
            Assert.Equal(ResponseMessage.STATUS_NODATA, dataResponse.Message);
            Assert.Null(dataResponse.Result); // Result should be null if no data found
        }

        [Fact]
        public async Task GetPractitionerVisibilityDetails_Should_Return_Success_Response_When_Visibility_Details_Are_Found()
        {
            // Arrange
            string partitionerId = "123";
            var mockVisibilityDetails = new PractitionerVisibilityResponseDto
            {
                Id = "123",
                FamilyName = "Doe",
                GivenName = "John",
                MiddleName = "M",
                Prefix = "Dr."
            };

            // Mock the region helper to return no error
            _mockRegionHelper.Setup(x => x.VerifyRegionCodeHeader(It.IsAny<HttpRequest>())).Returns(new GenericResponse<string> { HasError = false });

            // Mock GetPractitionerVisibilityDetails to return a valid object
            _mockManageVisibilityQueryService.Setup(x => x.GetPractitionerVisibilityDetails(partitionerId)).ReturnsAsync(mockVisibilityDetails);

            // Act
            var result = await _controller.GetPractitionerVisibilityDetails(partitionerId);

            // Assert
            var okResult = Assert.IsType<OkObjectResult>(result);
            var dataResponse = Assert.IsType<GenericResponse<PractitionerVisibilityResponseDto>>(okResult.Value);
            Assert.True(dataResponse.IsSuccess); // Verify success flag
            Assert.False(dataResponse.HasError); // Ensure no error flag is set
            Assert.Equal(((int)ResponceStatusCode.Success).ToString(), dataResponse.StatusCode);
            Assert.Equal(ResponseMessage.STATUS_SUCCESS, dataResponse.Message);
            Assert.NotNull(dataResponse.Result); // Ensure result is not null
            Assert.Equal("123", dataResponse.Result.Id); // Verify the ID is correct
        }
                
    }
}
