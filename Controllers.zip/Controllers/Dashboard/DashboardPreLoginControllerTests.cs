﻿using Aurora.AdministrationService.API.Controllers.Dashboard;
using Aurora.AdministrationService.API.Helper;
using Aurora.AdministrationService.API.Models.Dto.Marketing.Banner;
using Aurora.AdministrationService.API.Models.Dto.WhatHappenings;
using Aurora.AdministrationService.API.Models.RequestModels.V1.AdminDoctor;
using Aurora.AdministrationService.API.Models.ResponseModels.FAQ;
using Aurora.AdministrationService.API.Models.ResponseModels.Practitioners;
using Aurora.AdministrationService.API.Models.ResponseModels.V1.AdminDoctor;
using Aurora.AdministrationService.API.Models.ResponseModels.V1.AdminDoctor.Practitioners;
using Aurora.AdministrationService.API.Models.ResponseModels.WhatsHappening;
using Aurora.AdministrationService.API.Services.IService.AdminDoctor;
using Aurora.AdministrationService.API.Services.IService.Faq;
using Aurora.AdministrationService.API.Services.IService.WhatsHappenings;
using Aurora.AdministrationService.API.Services.Service.Marketing.Banner;
using Aurora.AdministrationService.CrossCutting.CommonModels;
using Aurora.AdministrationService.CrossCutting.Constants;
using FluentAssertions;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Moq;

namespace Aurora.AdministrationService.Tests.API.Controllers.Dashboard
{
    public class DashboardPreLoginControllerTests
    {
        private readonly Mock<IWhatsHappeningQueryService> _whatsHappeningQueryServiceMock;
        private readonly Mock<IDoctorQueryService> _doctorQueryServiceMock;
        private readonly Mock<IBannerQueryService> _bannerQueryServiceMock;
        private readonly Mock<IFaqQueryService> _faqQueryServiceMock;
        private readonly Mock<IRegionCodeValidationHelper> _regionCodeValidationHelperMock;
        private readonly DashboardPreLoginController _controller;

        public DashboardPreLoginControllerTests()
        {
            _whatsHappeningQueryServiceMock = new Mock<IWhatsHappeningQueryService>();
            _doctorQueryServiceMock = new Mock<IDoctorQueryService>();
            _bannerQueryServiceMock = new Mock<IBannerQueryService>();
            _faqQueryServiceMock = new Mock<IFaqQueryService>();
            _regionCodeValidationHelperMock = new Mock<IRegionCodeValidationHelper>();

            _controller = new DashboardPreLoginController(
                _whatsHappeningQueryServiceMock.Object,
                _doctorQueryServiceMock.Object,
                _bannerQueryServiceMock.Object,
                _faqQueryServiceMock.Object,
                _regionCodeValidationHelperMock.Object)
            {
                ControllerContext = new ControllerContext
                {
                    HttpContext = new DefaultHttpContext()
                }
            };
        }

        [Fact]
        public async Task GetWhatsHappeningsByList_ShouldReturnOk()
        {
            var response = new GenericResponseList<GetWhatsHappeningDto>(); // Correct type
            _whatsHappeningQueryServiceMock.Setup(s => s.GetWhatsHappeningList())
                .ReturnsAsync(response); // This should now match

            var result = await _controller.GetWhatsHappeningsByList();
            result.Should().BeOfType<OkObjectResult>().Which.Value.Should().BeEquivalentTo(response);
        }

        [Fact]
        public async Task GetWhatsHappeningDetail_ShouldReturnOk()
        {
            var response = new GenericResponse<WhatsHappeningDetailDto>(); // Correct type
            _whatsHappeningQueryServiceMock.Setup(s => s.GetWhatsHappeningDetail(It.IsAny<long>()))
                .ReturnsAsync(response);

            var result = await _controller.GetWhatsHappeningDetail(1);
            result.Should().BeOfType<OkObjectResult>().Which.Value.Should().BeEquivalentTo(response);
        }

        [Fact]
        public async Task GetDoctorSearchByNameAndSpeciality_ShouldReturnOk()
        {
            var response = new GenericResponseList<AdminDoctorSearchResponse>(); // Correct type
            _doctorQueryServiceMock.Setup(s => s.SearchDoctorByNameAndSpeciality(It.IsAny<string>(), It.IsAny<string>()))
                .ReturnsAsync(response);

            var result = await _controller.GetDoctorSearchByNameAndSpeciality("test", "Doctor");
            result.Should().BeOfType<OkObjectResult>().Which.Value.Should().BeEquivalentTo(response);
        }

        [Fact]
        public async Task GetMarketingMainBanner_ShouldReturnOk()
        {
            var response = new GenericResponse<List<GetBannerDto>>(); // Correct type
            _bannerQueryServiceMock.Setup(s => s.GetMarketingMainBanners())
                .ReturnsAsync(response);

            var result = await _controller.GetMarketingMainBanner();
            result.Should().BeOfType<OkObjectResult>().Which.Value.Should().BeEquivalentTo(response);
        }

        [Fact]
        public async Task GetWhatsHappeningsByCategories_ShouldReturnBadRequest_WhenValidationFails()
        {
            _regionCodeValidationHelperMock.Setup(h => h.VerifyRegionCodeHeader(It.IsAny<HttpRequest>()))
                .Returns(new GenericResponse<string> { HasError = true });

            var result = await _controller.GetWhatsHappeningsByCategories("category1", "location1");
            result.Should().BeOfType<BadRequestObjectResult>();
        }

        [Fact]
        public async Task GetDoctors_ShouldReturnNotFound_WhenDoctorNotExists()
        {
            _doctorQueryServiceMock.Setup(s => s.GetDoctorProfile(It.IsAny<long>()))
                .ReturnsAsync((GenericResponse<PractitionerProfileResponseDto>)null!);

            var result = await _controller.GetDoctors(1);
            result.Should().BeOfType<NotFoundObjectResult>();
        }

        [Fact]
        public async Task ValidateRegionCode_ShouldReturnBadRequest_WhenValidationFails()
        {
            _regionCodeValidationHelperMock.Setup(h => h.VerifyRegionCodeHeader(It.IsAny<HttpRequest>()))
                .Returns(new GenericResponse<string> { HasError = true });

            var result = await _controller.GetWhatsHappeningsByList();
            result.Should().BeOfType<BadRequestObjectResult>();
        }

        [Fact]
        public async Task GetDoctors_ShouldReturnOk()
        {
            var fakeResponse = new GenericResponse<PractitionerProfileResponseDto>
            {
                IsSuccess = true,
                HasError = false,
                StatusCode = ResponseStatusCode.STATUS_SUCCESS, // Ensure this matches actual output
                Message = ResponseMessage.STATUS_SUCCESS, // Ensure this matches actual output
                Result = new PractitionerProfileResponseDto()
            };

            _doctorQueryServiceMock.Setup(s => s.GetDoctorProfile(It.IsAny<long>()))
                .ReturnsAsync(fakeResponse);

            var result = await _controller.GetDoctors(1);
            result.Should().BeOfType<OkObjectResult>().Which.Value.Should().BeEquivalentTo(fakeResponse);
        }

        [Fact]
        public async Task GetWhatsHappeningsByCategories_ShouldReturnOk()
        {
            var fakeResponse = new GenericResponseList<GetWhatsHappeningByCategoriesDto>(); // Ensure correct type

            _whatsHappeningQueryServiceMock
                .Setup(s => s.GetWhatsHappeningsByCategories(It.IsAny<string[]>(), It.IsAny<string[]>()))
                .ReturnsAsync(fakeResponse); // Ensure correct return type

            var result = await _controller.GetWhatsHappeningsByCategories("category1,category2", "location1,location2");

            result.Should().BeOfType<OkObjectResult>().Which.Value.Should().BeEquivalentTo(fakeResponse);
        }


        [Fact]
        public async Task GetDoctorSearch_ShouldReturnOk()
        {
            var Role = "Diet";
            var fakeResponse = new List<PractitionerSearchResponse>();
            _doctorQueryServiceMock.Setup(s => s.GetDoctorSearchByFilter(It.IsAny<DoctorSearchCriteriaRequest>(), It.IsAny<string>()))
                .ReturnsAsync(fakeResponse);

            var searchCriteria = new DoctorSearchCriteriaRequest();
            var result = await _controller.GetDoctorSearch(searchCriteria, Role);
            result.Should().BeOfType<OkObjectResult>().Which.Value.Should().BeEquivalentTo(new GenericResponseList<PractitionerSearchResponse>
            {
                Results = fakeResponse,
                IsSuccess = true,
                HasError = false,
                Message = ResponseMessage.STATUS_SUCCESS,
                StatusCode = ResponseStatusCode.STATUS_SUCCESS
            });
        }

        [Fact]
        public async Task GetDoctorSearch_ShouldReturnBadRequest_WhenNoDataFound()
        {
            var Role = "Diet";
            _doctorQueryServiceMock.Setup(s => s.GetDoctorSearchByFilter(It.IsAny<DoctorSearchCriteriaRequest>(), It.IsAny<string>()))
                .ReturnsAsync((List<PractitionerSearchResponse>)null!);

            var searchCriteria = new DoctorSearchCriteriaRequest();
            var result = await _controller.GetDoctorSearch(searchCriteria, Role);
            result.Should().BeOfType<BadRequestObjectResult>();
        }

        #region Pre Login Dashboard Banner Api test cases

        [Fact]
        public async Task LatestBanners_ShouldReturnUnauthorized_WhenRegionCodeValidationFails()
        {
            // Arrange
            _regionCodeValidationHelperMock.Setup(h => h.VerifyRegionCodeHeader(It.IsAny<HttpRequest>()))
                 .Returns(new GenericResponse<string> { HasError = true });

            // Act
            var result = await _controller.LatestBanners();

            // Assert
            result.Should().BeOfType<BadRequestObjectResult>();
        }

        [Fact]
        public async Task LatestBanners_ShouldReturnOk_WhenBannersExist()
        {
            // Arrange
            var bannerList = new List<GetLatestBannerDetailsDto>
            {
                new GetLatestBannerDetailsDto { BannerId = 1, Title = "Banner 1", ImageUrl = "img1.jpg", Status = true, URL = "www.xyz.com" },
                new GetLatestBannerDetailsDto { BannerId = 2, Title = "Banner 2", ImageUrl = "img2.jpg", Status = true, URL = "www.xyz.com" }
            };

            _regionCodeValidationHelperMock.Setup(h => h.VerifyRegionCodeHeader(It.IsAny<HttpRequest>()))
                 .Returns(new GenericResponse<string> { HasError = false });

            _bannerQueryServiceMock
                .Setup(x => x.GetLatestBannerDetails())
                .ReturnsAsync(bannerList);

            // Act
            var result = await _controller.LatestBanners();

            // Assert
            var okResult = result as OkObjectResult;
            okResult.Should().NotBeNull();
            okResult!.StatusCode.Should().Be((int)ResponseStatusCodes.Success);

            var response = okResult.Value as GenericResponseList<GetLatestBannerDetailsDto>;
            response.Should().NotBeNull();
            response!.IsSuccess.Should().BeTrue();
            response.Results.Should().HaveCount(2);
            response.StatusCode.Should().Be(ResponseStatusCode.STATUS_SUCCESS);
        }

        [Fact]
        public async Task LatestBanners_ShouldReturnBadRequest_WhenNoBannersFound()
        {
            // Arrange
            _regionCodeValidationHelperMock.Setup(h => h.VerifyRegionCodeHeader(It.IsAny<HttpRequest>()))
                 .Returns(new GenericResponse<string> { HasError = false });

            _bannerQueryServiceMock
                .Setup(x => x.GetLatestBannerDetails())
                .ReturnsAsync(new List<GetLatestBannerDetailsDto>());

            // Act
            var result = await _controller.LatestBanners();

            // Assert
            var badRequest = result as BadRequestObjectResult;
            badRequest.Should().NotBeNull();
            badRequest!.StatusCode.Should().Be((int)ResponseStatusCodes.BadRequest);

            var response = badRequest.Value as GenericResponseList<GetLatestBannerDetailsDto>;
            response.Should().NotBeNull();
            response!.IsSuccess.Should().BeFalse();
            response.Results.Should().BeNullOrEmpty();
            response.StatusCode.Should().Be(ResponseStatusCode.STATUS_BADREQUEST);
        }

        #endregion

        #region Dashboar FAQ for Patient App

        [Fact]
        public async Task DashBoardFAQs_ShouldReturnOk_WhenFaqsExist()
        {
            // Arrange
            _regionCodeValidationHelperMock.Setup(h => h.VerifyRegionCodeHeader(It.IsAny<HttpRequest>()))
                .Returns(new GenericResponse<string> { HasError = false });

            var testFaqs = new List<FaqDashboardDto>
            {
                new FaqDashboardDto { Title = "Test Title", Description = "Test Description" }
            };

            _faqQueryServiceMock
                .Setup(x => x.GetDashboardpreLoginFAQs())
                .ReturnsAsync(testFaqs);

            // Act
            var result = await _controller.DashBoardFAQs();

            // Assert
            var okResult = result as OkObjectResult;
            okResult.Should().NotBeNull();
            okResult!.StatusCode.Should().Be(200);

            var response = okResult.Value as GenericResponseList<FaqDashboardDto>;
            response.Should().NotBeNull();
            response!.IsSuccess.Should().BeTrue();
            response.HasError.Should().BeFalse();
            response.Results.Should().NotBeNull();
            response.Results.Should().HaveCount(1);
        }

        [Fact]
        public async Task DashBoardFAQs_ShouldReturnBadRequest_WhenNoFaqsExist()
        {
            // Arrange
            _regionCodeValidationHelperMock.Setup(h => h.VerifyRegionCodeHeader(It.IsAny<HttpRequest>()))
            .Returns(new GenericResponse<string> { HasError = false });

            _faqQueryServiceMock
                .Setup(x => x.GetDashboardpreLoginFAQs())
                .ReturnsAsync(new List<FaqDashboardDto>());

            // Act
            var result = await _controller.DashBoardFAQs();

            // Assert
            var badRequestResult = result as BadRequestObjectResult;
            badRequestResult.Should().NotBeNull();
            badRequestResult!.StatusCode.Should().Be(400);

            var response = badRequestResult.Value as GenericResponseList<FaqDashboardDto>;
            response.Should().NotBeNull();
            response!.IsSuccess.Should().BeFalse();
            response.HasError.Should().BeTrue();
            response.Results.Should().BeNull();
        }

        [Fact]
        public async Task DashBoardFAQs_ShouldReturnValidationResult_WhenRegionCodeInvalid()
        {
            // Arrange
            _regionCodeValidationHelperMock.Setup(h => h.VerifyRegionCodeHeader(It.IsAny<HttpRequest>()))
                .Returns(new GenericResponse<string> { HasError = true });

            // Act
            var result = await _controller.DashBoardFAQs();

            // Assert
            result.Should().BeOfType<BadRequestObjectResult>();
        }

        #endregion
    }
}
