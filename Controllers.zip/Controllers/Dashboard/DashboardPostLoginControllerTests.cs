﻿using Aurora.AdministrationService.API.Controllers.Dashboard;
using Aurora.AdministrationService.API.Helper;
using Aurora.AdministrationService.API.Models.Dto.GlobalDto;
using Aurora.AdministrationService.API.Models.RequestModels.BannerClickReport;
using Aurora.AdministrationService.API.Models.ResponseModels.AdminDoctor;
using Aurora.AdministrationService.API.Models.ResponseModels.V1.AdminDoctor.Practitioners;
using Aurora.AdministrationService.API.Models.ResponseModels.WhatsHappening;
using Aurora.AdministrationService.API.Services.IService.AdminDoctor;
using Aurora.AdministrationService.API.Services.IService.Dashboard;
using Aurora.AdministrationService.API.Services.IService.Old.BannerClickReports;
using Aurora.AdministrationService.API.Services.IService.WhatsHappenings;
using Aurora.AdministrationService.API.Services.Service.Marketing.Banner;
using Aurora.AdministrationService.CrossCutting.CommonModels;
using Aurora.AdministrationService.CrossCutting.Constants;
using FluentAssertions;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Moq;

namespace Aurora.AdministrationService.Tests
{
    public class DashboardPostLoginControllerTests
    {
        private readonly Mock<IRegionCodeValidationHelper> _regionCodeValidationHelperMock;
        private readonly Mock<IBannerQueryService> _bannerQueryServiceMock;
        private readonly Mock<IDoctorQueryService> _doctorQueryServiceMock;
        private readonly Mock<IDashboardPostLoginQueryService> _dashboardPostLoginQueryService;
        private readonly Mock<IWhatsHappeningQueryService> _whatsHappeningQueryServiceMock;
        private readonly Mock<IBannerClickReportService> _bannerClickReportServiceMock;
        private readonly DashboardPostLoginController _controller;

        public DashboardPostLoginControllerTests()
        {
            _regionCodeValidationHelperMock = new Mock<IRegionCodeValidationHelper>();
            _bannerQueryServiceMock = new Mock<IBannerQueryService>();
            _doctorQueryServiceMock = new Mock<IDoctorQueryService>();
            _whatsHappeningQueryServiceMock = new Mock<IWhatsHappeningQueryService>();
            _bannerClickReportServiceMock = new Mock<IBannerClickReportService>();
            _dashboardPostLoginQueryService = new Mock<IDashboardPostLoginQueryService>();

            _controller = new DashboardPostLoginController(
                _regionCodeValidationHelperMock.Object,
                _bannerQueryServiceMock.Object,
                _doctorQueryServiceMock.Object,
                _whatsHappeningQueryServiceMock.Object,
                _bannerClickReportServiceMock.Object,
                _dashboardPostLoginQueryService.Object
            );
        }

        #region Test: GetWhatsHappeningsByList
        [Fact]
        public async Task GetWhatsHappeningsByList_ReturnsOk_WhenValid()
        {
            // Arrange
            _regionCodeValidationHelperMock.Setup(r => r.VerifyRegionCodeHeader(It.IsAny<Microsoft.AspNetCore.Http.HttpRequest>()))
                .Returns(new GenericResponse<string> { IsSuccess = true });

            _whatsHappeningQueryServiceMock.Setup(s => s.GetWhatsHappeningList())
                .ReturnsAsync(new GenericResponseList<AdministrationService.API.Models.Dto.WhatHappenings.GetWhatsHappeningDto> { IsSuccess = true });

            // Act
            var result = await _controller.GetWhatsHappeningsByList();

            // Assert
            var okResult = Assert.IsType<OkObjectResult>(result);
            var response = Assert.IsType<GenericResponseList<AdministrationService.API.Models.Dto.WhatHappenings.GetWhatsHappeningDto>>(okResult.Value);
            Assert.True(response.IsSuccess);
        }

        [Fact]
        public async Task GetWhatsHappeningsByList_ReturnsBadRequest_WhenRegionCodeInvalid()
        {
            // Arrange
            _regionCodeValidationHelperMock.Setup(r => r.VerifyRegionCodeHeader(It.IsAny<Microsoft.AspNetCore.Http.HttpRequest>()))
                .Returns(new GenericResponse<string> { HasError = true, IsSuccess = false });

            // Act
            var result = await _controller.GetWhatsHappeningsByList();

            // Assert
            var badRequestResult = Assert.IsType<BadRequestObjectResult>(result);
            var response = Assert.IsType<GenericResponse<string>>(badRequestResult.Value);
            Assert.False(response.IsSuccess);
        }
        #endregion

        #region Test: GetWhatsHappeningsByCategories
        [Fact]
        public async Task GetWhatsHappeningsByCategories_ReturnsOk_WhenValid()
        {
            // Arrange
            var categories = "Category1,Category2";
            var locations = "Location1,Location2";
            _regionCodeValidationHelperMock.Setup(r => r.VerifyRegionCodeHeader(It.IsAny<Microsoft.AspNetCore.Http.HttpRequest>()))
                .Returns(new GenericResponse<string> { IsSuccess = true });

            _whatsHappeningQueryServiceMock.Setup(s => s.GetWhatsHappeningsByCategories(It.IsAny<string[]>(), It.IsAny<string[]>()))
                .ReturnsAsync(new GenericResponseList<AdministrationService.API.Models.Dto.WhatHappenings.GetWhatsHappeningByCategoriesDto> { IsSuccess = true });

            // Act
            var result = await _controller.GetWhatsHappeningsByCategories(categories, locations);

            // Assert
            var okResult = Assert.IsType<OkObjectResult>(result);
            var response = Assert.IsType<GenericResponseList<AdministrationService.API.Models.Dto.WhatHappenings.GetWhatsHappeningByCategoriesDto>>(okResult.Value);
            Assert.True(response.IsSuccess);
        }

        [Fact]
        public async Task GetWhatsHappeningsByCategories_ReturnsBadRequest_WhenRegionCodeInvalid()
        {
            // Arrange
            var categories = "Category1,Category2";
            var locations = "Location1,Location2";
            _regionCodeValidationHelperMock.Setup(r => r.VerifyRegionCodeHeader(It.IsAny<Microsoft.AspNetCore.Http.HttpRequest>()))
                .Returns(new GenericResponse<string> { HasError = true, IsSuccess = false });

            // Act
            var result = await _controller.GetWhatsHappeningsByCategories(categories, locations);

            // Assert
            var badRequestResult = Assert.IsType<BadRequestObjectResult>(result);
            var response = Assert.IsType<GenericResponse<string>>(badRequestResult.Value);
            Assert.False(response.IsSuccess);
        }
        #endregion

        #region Test: GetPractitionerSearchByNameAndRole
        [Fact]
        public async Task GetDoctorSearchByNameAndSpeciality_ShouldReturnOk_WhenDoctorsFound()
        {
            // Arrange
            var search = "Dr";
            var role = "Doctor";
            var doctors = new List<AdminDoctorSearchDto>
            {
                new() { PractitionerId = 1,Prefix = "Doctor", FirstName = "Louis", MiddleName = "Angelo", LastName = "Decosta", PractitionerResourceId =    "PRAC001" , Gender = "Male", ImageUrl = "www.testurl.com",  }
            };

            _regionCodeValidationHelperMock.Setup(r => r.VerifyRegionCodeHeader(It.IsAny<HttpRequest>()))
                .Returns(new GenericResponse<string> { IsSuccess = true });

            _dashboardPostLoginQueryService.Setup(x => x.SearchPractitionerByNameAndRole(search, role))
                .ReturnsAsync(doctors);

            // Act
            var result = await _controller.PractitionerSearchByNameAndRole(search, role);

            // Assert
            var okResult = result as OkObjectResult;
            okResult.Should().NotBeNull();
            okResult!.StatusCode.Should().Be((int)ResponseStatusCodes.Success);

            var response = okResult.Value as GenericResponseList<AdminDoctorSearchDto>;
            response.Should().NotBeNull();
            response!.Results.Should().HaveCount(1);
            response.IsSuccess.Should().BeTrue();
            response.HasError.Should().BeFalse();
            response.StatusCode.Should().Be(ResponseStatusCode.STATUS_SUCCESS);
        }

        [Fact]
        public async Task GetDoctorSearchByNameAndSpeciality_ShouldReturnBadRequest_WhenRegionHeaderInvalid()
        {
            // Arrange
            SetInvalidRegionCode();

            // Act
            var result = await _controller.PractitionerSearchByNameAndRole("Dr", "Doctor");

            // Assert
            var badRequestResult = result as BadRequestObjectResult;
            badRequestResult.Should().NotBeNull();
            badRequestResult!.StatusCode.Should().Be((int)ResponseStatusCodes.BadRequest);
        }

        [Fact]
        public async Task GetDoctorSearchByNameAndSpeciality_ShouldReturnBadRequest_WhenDoctorsNotFound()
        {
            // Arrange
            _regionCodeValidationHelperMock.Setup(r => r.VerifyRegionCodeHeader(It.IsAny<HttpRequest>()))
            .Returns(new GenericResponse<string> { IsSuccess = true });

            _dashboardPostLoginQueryService.Setup(x => x.SearchPractitionerByNameAndRole("Michale", "Doctor"))
                .ReturnsAsync(new List<AdminDoctorSearchDto>());

            // Act
            var result = await _controller.PractitionerSearchByNameAndRole("Michale", "Doctor");

            // Assert
            var badRequestResult = result as BadRequestObjectResult;
            badRequestResult.Should().NotBeNull();
            badRequestResult!.StatusCode.Should().Be((int)ResponseStatusCodes.BadRequest);

            var response = badRequestResult.Value as GenericResponseList<AdminDoctorSearchDto>;
            response.Should().NotBeNull();
            response!.Results.Should().BeNullOrEmpty();
            response.StatusCode.Should().Be(ResponseStatusCode.STATUS_BADREQUEST);
            response.IsSuccess.Should().BeFalse();
            response.HasError.Should().BeTrue();
        }
        #endregion

        #region Test: GetDoctors
        [Fact]
        public async Task GetDoctors_ReturnsOk_WhenValid()
        {
            // Arrange
            long doctorId = 1;
            _regionCodeValidationHelperMock.Setup(r => r.VerifyRegionCodeHeader(It.IsAny<Microsoft.AspNetCore.Http.HttpRequest>()))
                .Returns(new GenericResponse<string> { IsSuccess = true });

            _doctorQueryServiceMock.Setup(s => s.GetDoctorProfile(doctorId))
                .ReturnsAsync(new GenericResponse<PractitionerProfileResponseDto> { IsSuccess = true, Result = new PractitionerProfileResponseDto() });

            // Act
            var result = await _controller.GetDoctors(doctorId);

            // Assert
            var okResult = Assert.IsType<OkObjectResult>(result);
            var response = Assert.IsType<GenericResponse<PractitionerProfileResponseDto>>(okResult.Value);
            Assert.True(response.IsSuccess);
        }

        [Fact]
        public async Task GetDoctors_ReturnsNotFound_WhenProfileNotFound()
        {
            // Arrange
            long doctorId = 1;
            _regionCodeValidationHelperMock.Setup(r => r.VerifyRegionCodeHeader(It.IsAny<Microsoft.AspNetCore.Http.HttpRequest>()))
                .Returns(new GenericResponse<string> { IsSuccess = true });

            _doctorQueryServiceMock.Setup(s => s.GetDoctorProfile(doctorId))
                .ReturnsAsync(new GenericResponse<PractitionerProfileResponseDto> { IsSuccess = false });

            // Act
            var result = await _controller.GetDoctors(doctorId);

            // Assert
            var notFoundResult = Assert.IsType<NotFoundObjectResult>(result);
            var response = Assert.IsType<GenericResponse<PractitionerProfileResponseDto>>(notFoundResult.Value);
            Assert.False(response.IsSuccess);
        }
        #endregion

        #region Test: GetMarketingMainBanner
        [Fact]
        public async Task GetMarketingMainBanner_ReturnsOk_WhenValid()
        {
            // Arrange
            _regionCodeValidationHelperMock.Setup(r => r.VerifyRegionCodeHeader(It.IsAny<Microsoft.AspNetCore.Http.HttpRequest>()))
                .Returns(new GenericResponse<string> { IsSuccess = true });

            _bannerQueryServiceMock.Setup(s => s.GetMarketingMainBanners())
               .ReturnsAsync(new GenericResponse<List<AdministrationService.API.Models.Dto.Marketing.Banner.GetBannerDto>> { IsSuccess = true });

            // Act
            var result = await _controller.GetMarketingMainBanner();

            // Assert
            var okResult = Assert.IsType<OkObjectResult>(result);
            var response = Assert.IsType<GenericResponse<List<AdministrationService.API.Models.Dto.Marketing.Banner.GetBannerDto>>>(okResult.Value);
            Assert.True(response.IsSuccess);
        }

        [Fact]
        public async Task GetMarketingMainBanner_ReturnsBadRequest_WhenRegionCodeInvalid()
        {
            // Arrange
            _regionCodeValidationHelperMock.Setup(r => r.VerifyRegionCodeHeader(It.IsAny<Microsoft.AspNetCore.Http.HttpRequest>()))
                .Returns(new GenericResponse<string> { HasError = true, IsSuccess = false });

            // Act
            var result = await _controller.GetMarketingMainBanner();

            // Assert
            var badRequestResult = Assert.IsType<BadRequestObjectResult>(result);
            var response = Assert.IsType<GenericResponse<string>>(badRequestResult.Value);
            Assert.False(response.IsSuccess);
        }
        #endregion

        #region Test: AddBannerClickCountByPatientID
        [Fact]
        public async Task AddBannerClickCountByPatientID_ReturnsOk_WhenValid()
        {
            // Arrange
            var request = new CreateBannerClickReportRequest { PatientId = 1, BannerId = 2 };
            _regionCodeValidationHelperMock.Setup(r => r.VerifyRegionCodeHeader(It.IsAny<Microsoft.AspNetCore.Http.HttpRequest>()))
                .Returns(new GenericResponse<string> { IsSuccess = true });

            _bannerClickReportServiceMock.Setup(s => s.AddBannerClickReportAsync(It.IsAny<CreateBannerClickReportRequest>()))
                .ReturnsAsync(new GenericResponse<string> { IsSuccess = true, Result = "Test" });

            // Act
            var result = await _controller.AddBannerClickCountByPatientID(request);

            // Assert
            var okResult = Assert.IsType<OkObjectResult>(result);
            var response = Assert.IsType<GenericResponse<string>>(okResult.Value);
            Assert.True(response.IsSuccess);
        }

        [Fact]
        public async Task AddBannerClickCountByPatientID_ReturnsBadRequest_WhenRegionCodeInvalid()
        {
            // Arrange
            var request = new CreateBannerClickReportRequest { PatientId = 1, BannerId = 2 };
            _regionCodeValidationHelperMock.Setup(r => r.VerifyRegionCodeHeader(It.IsAny<Microsoft.AspNetCore.Http.HttpRequest>()))
                .Returns(new GenericResponse<string> { HasError = true, IsSuccess = false });

            // Act
            var result = await _controller.AddBannerClickCountByPatientID(request);

            // Assert
            var badRequestResult = Assert.IsType<BadRequestObjectResult>(result);
            var response = Assert.IsType<GenericResponse<string>>(badRequestResult.Value);
            Assert.False(response.IsSuccess);
        }
        #endregion

        [Fact]
        public void GetGenders_ReturnsOkResult_WithListOfGenders()
        {
            // Act
            var result = _controller.GetGenders();

            // Assert
            var okResult = Assert.IsType<OkObjectResult>(result);
            var response = Assert.IsType<GenericResponseList<GetGenderTypeDto>>(okResult.Value);
            Assert.False(response.HasError);
            Assert.True(response.IsSuccess);
            Assert.Equal("200", response.StatusCode);
            Assert.Equal(ResponseMessage.STATUS_RECORDS_LOADED, response.Message);
            Assert.Equal(CommonConstants.SUCCESS, response.MessageType);
            Assert.NotEmpty(response.Results);
        }

        // Test case for GetGenders method - Error handling scenario
        [Fact]
        public void GetGenders_ReturnsValidationError_WhenRegionCodeIsInvalid()
        {
            // Arrange
            this.SetInvalidRegionCode();

            // Act
            var result = _controller.GetGenders();

            // Assert
            var validationResult = Assert.IsType<BadRequestObjectResult>(result);
            Assert.Equal(StatusCodes.Status400BadRequest, validationResult.StatusCode);
        }

        // Test case for GetAgeSelectionTypes method - Normal scenario
        [Fact]
        public void GetAgeSelectionTypes_ReturnsOkResult_WithListOfAgeSelectionTypes()
        {
            // Act
            var result = _controller.GetAgeSelectionTypes();

            // Assert
            var okResult = Assert.IsType<OkObjectResult>(result);
            var response = Assert.IsType<GenericResponseList<GetAgeSelectionTypesDto>>(okResult.Value);
            Assert.False(response.HasError);
            Assert.True(response.IsSuccess);
            Assert.Equal("200", response.StatusCode);
            Assert.Equal(ResponseMessage.STATUS_RECORDS_LOADED, response.Message);
            Assert.Equal(CommonConstants.SUCCESS, response.MessageType);
            Assert.NotEmpty(response.Results);
        }

        // Test case for GetAgeSelectionTypes method - Error handling scenario
        [Fact]
        public void GetAgeSelectionTypes_ReturnsValidationError_WhenRegionCodeIsInvalid()
        {
            // Arrange
            this.SetInvalidRegionCode();

            // Act
            var result = _controller.GetAgeSelectionTypes();

            // Assert
            var validationResult = Assert.IsType<BadRequestObjectResult>(result);
            Assert.Equal(StatusCodes.Status400BadRequest, validationResult.StatusCode);
        }

        // Helper method to simulate invalid region code
        private void SetInvalidRegionCode()
        {
            _regionCodeValidationHelperMock.Setup(r => r.VerifyRegionCodeHeader(It.IsAny<Microsoft.AspNetCore.Http.HttpRequest>()))
                .Returns(new GenericResponse<string> { HasError = true });
        }
        [Fact]
        public async Task GetWhatsHappeningDetail_ReturnsOkResult_WhenDataExists()
        {
            // Arrange
            var id = 1L;

            var expectedDetail = new WhatsHappeningDetailDto
            {
                Id = 1,
                Title = "Health Camp",
                Description = "Health Camp in Bangalore",
                // Add other properties if needed
            };

            var expectedResponse = new GenericResponse<WhatsHappeningDetailDto>
            {

                Message = "Success",
                Result = expectedDetail
            };

            _whatsHappeningQueryServiceMock
                .Setup(service => service.GetWhatsHappeningDetail(id))
                .ReturnsAsync(expectedResponse);

            // Act
            var result = await _controller.GetWhatsHappeningDetail(id);

            // Assert
            var okResult = Assert.IsType<OkObjectResult>(result);
            var returnValue = Assert.IsType<GenericResponse<WhatsHappeningDetailDto>>(okResult.Value);

            Assert.Equal("Success", returnValue.Message);
            Assert.Equal(expectedDetail.Title, returnValue.Result.Title);
            Assert.Equal(expectedDetail.Description, returnValue.Result.Description);
        }
        [Fact]
        public void GetGenders_ReturnsOk_WhenValid()
        {
            // Act
            var result = _controller.GetGenders();

            // Assert
            var okResult = Assert.IsType<OkObjectResult>(result);
            var response = Assert.IsType<GenericResponseList<GetGenderTypeDto>>(okResult.Value);
            Assert.True(response.IsSuccess);
        }
        [Fact]
        public async Task AddBannerClickCountByPatientID_ReturnsBadRequest_WhenExceptionThrown()
        {
            // Arrange
            var request = new CreateBannerClickReportRequest { PatientId = 1, BannerId = 2 };

            // Setup region validation to return valid
            _regionCodeValidationHelperMock.Setup(r => r.VerifyRegionCodeHeader(It.IsAny<Microsoft.AspNetCore.Http.HttpRequest>()))
                .Returns(new GenericResponse<string> { IsSuccess = true });

            // Force service to throw an exception
            _bannerClickReportServiceMock.Setup(s => s.AddBannerClickReportAsync(It.IsAny<CreateBannerClickReportRequest>()))
                .ThrowsAsync(new Exception("Something went wrong"));

            // Act
            var result = await _controller.AddBannerClickCountByPatientID(request);

            // Assert
            Assert.IsType<BadRequestResult>(result);
        }
    }
}