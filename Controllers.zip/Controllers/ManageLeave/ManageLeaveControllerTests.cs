﻿using Aurora.AdministrationService.API.Controllers.ManageLeave;
using Aurora.AdministrationService.API.Helper;
using Aurora.AdministrationService.API.Models.RequestModels.Leaves;
using Aurora.AdministrationService.API.Models.RequestModels.ManageLeaveDto;
using Aurora.AdministrationService.API.Models.ResponseModels.Schedules;
using Aurora.AdministrationService.API.Services.IService.ManageLeaves;
using Aurora.AdministrationService.CrossCutting.CommonModels;
using Aurora.AdministrationService.CrossCutting.Constants;
using Microsoft.AspNetCore.Mvc;
using Moq;

namespace Aurora.AdministrationService.Tests.Controllers
{
    public class ManageLeaveControllerTests
    {
        private readonly Mock<IManageLeaveCommandService> _mockManageLeaveCommandService;
        private readonly Mock<IManageLeaveQueryService> _mockManageLeaveQueryService;
        private readonly Mock<IRegionCodeValidationHelper> _mockRegionCodeValidationHelper;
        private readonly ManageLeaveController _controller;

        public ManageLeaveControllerTests()
        {
            _mockManageLeaveCommandService = new Mock<IManageLeaveCommandService>();
            _mockManageLeaveQueryService = new Mock<IManageLeaveQueryService>();
            _mockRegionCodeValidationHelper = new Mock<IRegionCodeValidationHelper>();
            _controller = new ManageLeaveController(
                _mockManageLeaveCommandService.Object,
                _mockManageLeaveQueryService.Object,
                _mockRegionCodeValidationHelper.Object
            );
        }

        [Fact]
        public async Task CreateManageLeave_ShouldReturnOk_WhenValidRequest()
        {
            // Arrange
            var requestDto = new ManageLeavesRequestDto
            {
                Action = "Create",
                Type = "Leave",
                practitionerId = 12345,
                LocationResourceId = "Location1",
                newTimeOff = new List<TimeOffAddRequestDto>
                {
                    new TimeOffAddRequestDto
                    {
                        StartDateTime = DateTime.UtcNow,
                        EndDateTime =  DateTime.UtcNow,
                        Description = "Vacation"
                    }
                },
                removeTimeOff = new List<TimeOffUpdateRequestDto>(),
                NewOverrides = "",
                RemovedOverrides = "",
                PractitionerIdentifiers = new List<PractitionerIdentifierRequestDto>()
            };

            _mockRegionCodeValidationHelper.Setup(x => x.VerifyRegionCodeHeader(It.IsAny<Microsoft.AspNetCore.Http.HttpRequest>()))
                .Returns((GenericResponse<string>)null);

            _mockManageLeaveQueryService.Setup(x => x.IsDuplicateLeaveAsync(It.IsAny<ManageLeavesRequestDto>())).ReturnsAsync(false);
            _mockManageLeaveQueryService.Setup(x => x.HasValidPractitionerIdentifier(It.IsAny<ManageLeavesRequestDto>())).Returns(new List<PractitionerIdentifierRequestDto>());
            _mockManageLeaveCommandService.Setup(x => x.CreateManageLeaveAsync(It.IsAny<ManageLeavesRequestDto>())).ReturnsAsync((true, "Success"));

            // Act
            var result = await _controller.CreateManageLeave(requestDto);

            // Assert
            var okResult = Assert.IsType<OkObjectResult>(result);
            var response = Assert.IsType<GenericResponse<string>>(okResult.Value);
            Assert.True(response.IsSuccess);
            Assert.Equal(ResponseStatusCode.STATUS_SUCCESS, response.StatusCode);
        }

        [Fact]
        public async Task CreateManageLeave_ShouldReturnBadRequest_WhenDuplicateLeave()
        {
            // Arrange
            var requestDto = new ManageLeavesRequestDto { practitionerId=1};
            _mockManageLeaveQueryService.Setup(x => x.IsDuplicateLeaveAsync(It.IsAny<ManageLeavesRequestDto>())).ReturnsAsync(true);

            // Act
            var result = await _controller.CreateManageLeave(requestDto);

            // Assert
            var badRequestResult = Assert.IsType<BadRequestObjectResult>(result);
            var response = Assert.IsType<GenericResponse<string>>(badRequestResult.Value);
            Assert.False(response.IsSuccess);
            Assert.Equal(ResponseStatusCode.STATUS_BADREQUEST, response.StatusCode);
        }

        [Fact]
        public async Task UpdateManageLeave_ShouldReturnOk_WhenValidRequest()
        {
            // Arrange
            var requestDto = new ManageLeavesRequestDto
            {
                Action = "Update",
                Type = "Leave",
                practitionerId = 12345,
                LocationResourceId = "Location1",
                newTimeOff = new List<TimeOffAddRequestDto>(),
                removeTimeOff = new List<TimeOffUpdateRequestDto>
                {
                    new TimeOffUpdateRequestDto { StartDateTime =  DateTime.UtcNow, EndDateTime =  DateTime.UtcNow, Description = "Vacation", IsDelete = true }
                },
                NewOverrides = "",
                RemovedOverrides = "",
                PractitionerIdentifiers = new List<PractitionerIdentifierRequestDto>()
            };

            _mockRegionCodeValidationHelper.Setup(x => x.VerifyRegionCodeHeader(It.IsAny<Microsoft.AspNetCore.Http.HttpRequest>()))
                .Returns((GenericResponse<string>)null);

            _mockManageLeaveCommandService.Setup(x => x.UpdateManageLeaveAsync(It.IsAny<ManageLeavesRequestDto>())).ReturnsAsync((true, "Updated Successfully"));

            // Act
            var result = await _controller.UpdateManageLeave(requestDto);

            // Assert
            var okResult = Assert.IsType<OkObjectResult>(result);
            var response = Assert.IsType<GenericResponse<string>>(okResult.Value);
            Assert.True(response.IsSuccess);
            Assert.Equal(ResponseStatusCode.STATUS_SUCCESS, response.StatusCode);
        }

        [Fact]
        public Task GetManageLeave_ShouldReturnOk_WhenValidRequest()
        {
            // Arrange
            var practitionerId = 12345L;
            var locationResourceId = "Location1";
            var timeOffList = new List<TimeOffResponseDto>
            {
                new TimeOffResponseDto
                {
                    StartDateTime =  DateTime.UtcNow,
                    EndDateTime =  DateTime.UtcNow,
                    Description = "Vacation"
                }
            };

            _mockRegionCodeValidationHelper.Setup(x => x.VerifyRegionCodeHeader(It.IsAny<Microsoft.AspNetCore.Http.HttpRequest>()))
                .Returns((GenericResponse<string>)null);

            _mockManageLeaveQueryService.Setup(x => x.GetManageLeaveService(It.IsAny<long>(), It.IsAny<string>())).Returns(timeOffList);

            // Act
            var result = _controller.GetManageLeave(practitionerId, locationResourceId);

            // Assert
            var okResult = Assert.IsType<OkObjectResult>(result);
            var response = Assert.IsType<GenericResponseList<TimeOffResponseDto>>(okResult.Value);
            Assert.True(response.IsSuccess);
            Assert.Equal(ResponseStatusCode.STATUS_SUCCESS, response.StatusCode);
            Assert.Equal(1, response.TotalCount);
            return Task.CompletedTask;
        }

        [Fact]
        public async Task CreateManageLeave_ShouldReturnBadRequest_WhenInvalidRegionCodeHeader()
        {
            // Arrange
            var requestDto = new ManageLeavesRequestDto { practitionerId = 1 };
            _mockRegionCodeValidationHelper.Setup(x => x.VerifyRegionCodeHeader(It.IsAny<Microsoft.AspNetCore.Http.HttpRequest>()))
                .Returns(new GenericResponse<string> { HasError = true, Message = "Invalid Region Code" });

            // Act
            var result = await _controller.CreateManageLeave(requestDto);

            // Assert
            var badRequestResult = Assert.IsType<BadRequestObjectResult>(result);
            var response = Assert.IsType<GenericResponse<string>>(badRequestResult.Value);
            Assert.False(response.IsSuccess);
            Assert.Equal("Invalid Region Code", response.Message);
        }
        [Fact]
        public async Task CreateManageLeave_ShouldReturnInternalServerError_WhenCreateManageLeaveFails()
        {
            // Arrange
            var requestDto = new ManageLeavesRequestDto { practitionerId = 1 };
            _mockRegionCodeValidationHelper.Setup(x => x.VerifyRegionCodeHeader(It.IsAny<Microsoft.AspNetCore.Http.HttpRequest>()))
                .Returns((GenericResponse<string>)null);

            _mockManageLeaveQueryService.Setup(x => x.IsDuplicateLeaveAsync(It.IsAny<ManageLeavesRequestDto>())).ReturnsAsync(false);
            _mockManageLeaveCommandService.Setup(x => x.CreateManageLeaveAsync(It.IsAny<ManageLeavesRequestDto>())).ReturnsAsync((false, "Internal Server Error"));

            // Act
            var result = await _controller.CreateManageLeave(requestDto);

            // Assert
            var badRequestResult = Assert.IsType<BadRequestObjectResult>(result);
            var response = Assert.IsType<GenericResponse<string>>(badRequestResult.Value);
            Assert.False(response.IsSuccess);
            Assert.Equal(ResponseStatusCode.STATUS_INTERNAL_SERVER_ERROR, response.StatusCode);
            Assert.Equal("Internal Server Error", response.Message);
        }
        [Fact]
        public async Task UpdateManageLeave_ShouldReturnBadRequest_WhenInvalidRegionCodeHeader()
        {
            // Arrange
            var requestDto = new ManageLeavesRequestDto { practitionerId = 1 };
            _mockRegionCodeValidationHelper.Setup(x => x.VerifyRegionCodeHeader(It.IsAny<Microsoft.AspNetCore.Http.HttpRequest>()))
                .Returns(new GenericResponse<string> { HasError = true, Message = "Invalid Region Code" });

            // Act
            var result = await _controller.UpdateManageLeave(requestDto);

            // Assert
            var badRequestResult = Assert.IsType<BadRequestObjectResult>(result);
            var response = Assert.IsType<GenericResponse<string>>(badRequestResult.Value);
            Assert.False(response.IsSuccess);
            Assert.Equal("Invalid Region Code", response.Message);
        }
        [Fact]
        public async Task UpdateManageLeave_ShouldReturnInternalServerError_WhenUpdateManageLeaveFails()
        {
            // Arrange
            var requestDto = new ManageLeavesRequestDto { practitionerId = 1 };
            _mockRegionCodeValidationHelper.Setup(x => x.VerifyRegionCodeHeader(It.IsAny<Microsoft.AspNetCore.Http.HttpRequest>()))
                .Returns((GenericResponse<string>)null);

            _mockManageLeaveCommandService.Setup(x => x.UpdateManageLeaveAsync(It.IsAny<ManageLeavesRequestDto>())).ReturnsAsync((false, "Internal Server Error"));

            // Act
            var result = await _controller.UpdateManageLeave(requestDto);

            // Assert
            var badRequestResult = Assert.IsType<BadRequestObjectResult>(result);
            var response = Assert.IsType<GenericResponse<string>>(badRequestResult.Value);
            Assert.False(response.IsSuccess);
            Assert.Equal(ResponseStatusCode.STATUS_INTERNAL_SERVER_ERROR, response.StatusCode);
            Assert.Equal("Internal Server Error", response.Message);
        }
        [Fact]
        public Task GetManageLeave_ShouldReturnBadRequest_WhenInvalidRegionCodeHeader()
        {
            // Arrange
            var practitionerId = 12345L;
            var locationResourceId = "Location1";
            _mockRegionCodeValidationHelper.Setup(x => x.VerifyRegionCodeHeader(It.IsAny<Microsoft.AspNetCore.Http.HttpRequest>()))
                .Returns(new GenericResponse<string> { HasError = true, Message = "Invalid Region Code" });

            // Act
            var result =  _controller.GetManageLeave(practitionerId, locationResourceId); // Ensure it's awaited

            // Assert
            var badRequestResult = Assert.IsType<BadRequestObjectResult>(result);
            var response = Assert.IsType<GenericResponse<string>>(badRequestResult.Value); // Change to GenericResponse<string>
            Assert.False(response.IsSuccess);
            Assert.Equal("Invalid Region Code", response.Message);
            return Task.CompletedTask;
        }

        [Fact]
        public Task GetManageLeave_ShouldReturnNoData_WhenNoLeaveFound()
        {
            // Arrange
            var practitionerId = 12345L;
            var locationResourceId = "Location1";
            var timeOffList = new List<TimeOffResponseDto>();

            _mockRegionCodeValidationHelper.Setup(x => x.VerifyRegionCodeHeader(It.IsAny<Microsoft.AspNetCore.Http.HttpRequest>()))
                .Returns((GenericResponse<string>)null);

            _mockManageLeaveQueryService.Setup(x => x.GetManageLeaveService(It.IsAny<long>(), It.IsAny<string>())).Returns(timeOffList);

            // Act
            var result = _controller.GetManageLeave(practitionerId, locationResourceId);

            // Assert
            var okResult = Assert.IsType<OkObjectResult>(result);
            var response = Assert.IsType<GenericResponseList<TimeOffResponseDto>>(okResult.Value);
            Assert.True(response.IsSuccess);
            Assert.Equal(ResponseStatusCode.STATUS_SUCCESS, response.StatusCode);
            Assert.Equal(0, response.TotalCount);
            Assert.Equal(ResponseMessage.STATUS_NODATA, response.Message);
            return Task.CompletedTask;
        }

    }
}
