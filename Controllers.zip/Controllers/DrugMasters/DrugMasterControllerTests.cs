﻿using Aurora.AdministrationService.API.Controllers.DrugMasters;
using Aurora.AdministrationService.API.Models.Dto.DrugMasters;
using Aurora.AdministrationService.API.Services.IService.DrugMasters;
using Aurora.AdministrationService.CrossCutting.CommonModels;
using Aurora.AdministrationService.CrossCutting.Constants;
using Aurora.AdministrationService.Domain.V1.Entities.DrugMasters;
using Aurora.AdministrationService.Tests.API.Controllers.DrugMasters;
using AutoMapper;
using FluentAssertions;
using Microsoft.AspNetCore.Mvc;
using Moq;
using System.Text;

namespace Aurora.AdministrationService.Tests.API.Controllers.DrugMasters
{
    public class DrugMasterControllerTests
    {
        private readonly Mock<IDrugMasterCommandService> _mockCommandService;
        private readonly Mock<IDrugMasterQueryService> _mockQueryService;
        private readonly Mock<IMapper> _mockMapper;
        private readonly DrugMasterController _controller;

        public DrugMasterControllerTests()
        {
            _mockCommandService = new Mock<IDrugMasterCommandService>();
            _mockQueryService = new Mock<IDrugMasterQueryService>();
            _mockMapper = new Mock<IMapper>();

            _controller = new DrugMasterController(_mockCommandService.Object, _mockQueryService.Object, _mockMapper.Object);
        }

        [Theory]
        [InlineData(true, ResponseMessage.STATUS_DATA_UPDATED)]  // Update scenario
        [InlineData(false, ResponseMessage.STATUS_DATA_ADDED)]   // Add scenario
        public async Task AddOrUpdateDrugMaster_ShouldReturnCorrectResponse(bool doesExist, string expectedMessage)
        {
            // Arrange
            var drugMasterDto = CommonMockData.GetMockDrugMasterDto();

            var existingDrugEntity = doesExist ? new DrugMaster
            {
                ResourceID = drugMasterDto.ResourceID,
                ItemCode = drugMasterDto.ItemCode,
                MedicationCode = drugMasterDto.MedicationCode,
                IsDeleted = false,
                MasterType = drugMasterDto.MasterType,
                RecordVersion = Array.Empty<byte>(),
                CreatedDate = DateTime.UtcNow.AddDays(-1),
                CreatedBy = "TestUser"
            } : null;

            _mockQueryService.Setup(q => q.CheckExistingDrugMasterAsync(drugMasterDto.ItemCode))
                .ReturnsAsync(existingDrugEntity);

            if (doesExist)
            {
                var updateRequest = _mockMapper.Object.Map<UpdateDrugMasterRequest>(drugMasterDto);
                _mockMapper.Setup(m => m.Map<UpdateDrugMasterRequest>(drugMasterDto))
                    .Returns(updateRequest);

                _mockCommandService.Setup(c => c.UpdateDrugMasterAsync(It.IsAny<UpdateDrugMasterRequest>(), It.IsAny<DrugMaster>()))
                    .ReturnsAsync(drugMasterDto);
            }
            else
            {
                var newRequest = _mockMapper.Object.Map<CreateDrugMasterRequest>(drugMasterDto);
                _mockMapper.Setup(m => m.Map<CreateDrugMasterRequest>(drugMasterDto))
                    .Returns(newRequest);

                _mockCommandService.Setup(c => c.AddDrugMasterAsync(newRequest))
                    .ReturnsAsync(drugMasterDto);
            }

            // Act
            var result = await _controller.AddOrUpdateDrugMaster(drugMasterDto);

            // Assert
            var okResult = result.Should().BeOfType<OkObjectResult>().Subject;
            var response = okResult.Value.Should().BeOfType<GenericResponse<string>>().Subject;

            response.IsSuccess.Should().BeTrue();
            response.StatusCode.Should().Be(ResponseStatusCode.STATUS_SUCCESS);
            response.Message.Should().Be(expectedMessage);
            response.HasError.Should().BeFalse();
            response.MessageType.Should().Be(CommonConstants.SUCCESS);

            if (doesExist)
            {
                _mockCommandService.Verify(c => c.UpdateDrugMasterAsync(It.IsAny<UpdateDrugMasterRequest>(), It.IsAny<DrugMaster>()), Times.Once);
                _mockCommandService.Verify(c => c.AddDrugMasterAsync(It.IsAny<CreateDrugMasterRequest>()), Times.Never);
            }
            else
            {
                _mockCommandService.Verify(c => c.AddDrugMasterAsync(It.IsAny<CreateDrugMasterRequest>()), Times.Once);
                _mockCommandService.Verify(c => c.UpdateDrugMasterAsync(It.IsAny<UpdateDrugMasterRequest>(), It.IsAny<DrugMaster>()), Times.Never);
            }
        }

        [Fact]
        public async Task AddOrUpdateDrugMaster_WhenModelStateIsInvalid_ShouldReturnBadRequest()
        {
            // Arrange
            _controller.ModelState.AddModelError("ItemCode", "Required");
            var drugMasterDto = new DrugMasterDto
            {
                ResourceID = "Res345",
                MasterType = "DrugMaster",
                ItemCode = "ITE345",
                MedicationCode = "ME345"
            };

            // Act
            var result = await _controller.AddOrUpdateDrugMaster(drugMasterDto);

            // Assert
            result.Should().BeOfType<BadRequestObjectResult>();
        }

        [Fact]
        public async Task DeleteDrugMaster_ShouldReturnSuccess_WhenRecordExists()
        {
            // Arrange
            var itemCode = "DRUG123";
            var existingDrug = new DrugMaster
            {
                ItemCode = itemCode,
                CreatedDate = DateTime.UtcNow,
                IsDeleted = false,
                MasterType = "General",
                MedicationCode = "MED123",
                ResourceID = "RESOURCE001",
                RecordVersion = Encoding.UTF8.GetBytes("1")
            };

            _mockQueryService.Setup(q => q.CheckExistingDrugMasterAsync(itemCode))
                .ReturnsAsync(existingDrug);

            _mockCommandService.Setup(c => c.DeleteDrugMasterAsync(existingDrug.RecordVersion, existingDrug))
                .ReturnsAsync(true);

            // Act
            var result = await _controller.DeleteDrugMaster(itemCode);

            // Assert
            var okResult = result.Should().BeOfType<OkObjectResult>().Subject;
            var response = okResult.Value.Should().BeOfType<GenericResponse<string>>().Subject;
            response.IsSuccess.Should().BeTrue();
            response.StatusCode.Should().Be(ResponseStatusCode.STATUS_SUCCESS);
            response.Message.Should().Be(ResponseMessage.STATUS_DATA_DELETED);
            response.HasError.Should().BeFalse();
            response.MessageType.Should().Be(CommonConstants.SUCCESS);

            _mockQueryService.Verify(q => q.CheckExistingDrugMasterAsync(itemCode), Times.Once);
            _mockCommandService.Verify(c => c.DeleteDrugMasterAsync(existingDrug.RecordVersion, existingDrug), Times.Once);
        }

        [Fact]
        public async Task DeleteDrugMaster_ShouldReturnNotFound_WhenRecordDoesNotExist()
        {
            // Arrange
            var itemCode = "INVALID_DRUG";

            _mockQueryService.Setup(q => q.CheckExistingDrugMasterAsync(itemCode))
                .ReturnsAsync((DrugMaster)null);

            // Act
            var result = await _controller.DeleteDrugMaster(itemCode);

            // Assert
            var notFoundResult = result.Should().BeOfType<NotFoundObjectResult>().Subject;
            var response = notFoundResult.Value.Should().BeOfType<GenericResponse<string>>().Subject;

            response.IsSuccess.Should().BeFalse();
            response.StatusCode.Should().Be(ResponseStatusCode.STATUS_NOTFOUND);
            response.Message.Should().Be(ResponseMessage.STATUS_NODATA);
            response.HasError.Should().BeTrue();
            response.MessageType.Should().Be(CommonConstants.ERROR);

            _mockQueryService.Verify(q => q.CheckExistingDrugMasterAsync(itemCode), Times.Once);
            _mockCommandService.Verify(c => c.DeleteDrugMasterAsync(It.IsAny<byte[]>(), It.IsAny<DrugMaster>()), Times.Never);
        }

        [Fact]
        public async Task GetDrugMasterById_ShouldReturnNotFound_WhenRecordDoesNotExist()
        {
            // Arrange
            var id = 999;  // Non-existent ID
            _mockQueryService.Setup(q => q.GetDrugMasterById(id))
                .ReturnsAsync((GetDrugMasterDto)null);

            // Act
            var result = await _controller.GetDrugMasterById(id);

            // Assert
            var notFoundResult = result.Should().BeOfType<NotFoundObjectResult>().Subject;
            var response = notFoundResult.Value.Should().BeOfType<GenericResponse<string>>().Subject;
            response.IsSuccess.Should().BeFalse();
            response.StatusCode.Should().Be(ResponseStatusCode.STATUS_NOTFOUND);
            response.Message.Should().Be(ResponseMessage.STATUS_NODATA);
            response.HasError.Should().BeTrue();
            response.MessageType.Should().Be(CommonConstants.ERROR);
            _mockQueryService.Verify(q => q.GetDrugMasterById(id), Times.Once);
        }

        [Fact]
        public async Task GetDrugMasterById_ShouldReturnOk_WhenRecordExists()
        {
            // Arrange
            var id = 123; // Existing ID
            var drugMasterDetail = new GetDrugMasterDto
            {
                ItemCode = "DRUG123",
                MedicationCode = "MED123",
                MasterType = "General",
                ResourceID = "RESOURCE001"
            };

            _mockQueryService.Setup(q => q.GetDrugMasterById(id))
                .ReturnsAsync(drugMasterDetail);

            // Act
            var result = await _controller.GetDrugMasterById(id);

            // Assert
            var okResult = result.Should().BeOfType<OkObjectResult>().Subject;
            var response = okResult.Value.Should().BeOfType<GenericResponse<GetDrugMasterDto>>().Subject;
            response.IsSuccess.Should().BeTrue();
            response.StatusCode.Should().Be(ResponseStatusCode.STATUS_SUCCESS);
            response.Message.Should().Be(ResponseMessage.STATUS_DATA_FOUND);
            response.HasError.Should().BeFalse();
            response.MessageType.Should().Be(CommonConstants.SUCCESS);
            response.Result.Should().NotBeNull();
            response.Result?.ItemCode.Should().Be("DRUG123");
            response.Result?.MedicationCode.Should().Be("MED123");
            _mockQueryService.Verify(q => q.GetDrugMasterById(id), Times.Once);
        }

        [Fact]
        public async Task GetDrugMasterList_ShouldReturnNotFound_WhenNoRecordsExist()
        {
            // Arrange
            _mockQueryService.Setup(q => q.GetDrugMasterList()).ReturnsAsync((List<GetDrugMasterDto>)null);

            // Act
            var result = await _controller.GetDrugMasterList();

            // Assert
            var notFoundResult = result.Should().BeOfType<NotFoundObjectResult>().Subject;
            var response = notFoundResult.Value.Should().BeOfType<GenericResponse<string>>().Subject;
            response.IsSuccess.Should().BeFalse();
            response.StatusCode.Should().Be(ResponseStatusCode.STATUS_NOTFOUND);
            response.Message.Should().Be(ResponseMessage.STATUS_NODATA);
            response.HasError.Should().BeTrue();
            response.MessageType.Should().Be(CommonConstants.ERROR);
            _mockQueryService.Verify(q => q.GetDrugMasterList(), Times.Once);
        }

        [Fact]
        public async Task GetDrugMasterList_ShouldReturnNotFound_WhenListIsEmpty()
        {
            // Arrange
            _mockQueryService.Setup(q => q.GetDrugMasterList())
                .ReturnsAsync(new List<GetDrugMasterDto>());

            // Act
            var result = await _controller.GetDrugMasterList();

            // Assert
            var notFoundResult = result.Should().BeOfType<NotFoundObjectResult>().Subject;
            var response = notFoundResult.Value.Should().BeOfType<GenericResponse<string>>().Subject;
            response.IsSuccess.Should().BeFalse();
            response.StatusCode.Should().Be(ResponseStatusCode.STATUS_NOTFOUND);
            response.Message.Should().Be(ResponseMessage.STATUS_NODATA);
            response.HasError.Should().BeTrue();
            response.MessageType.Should().Be(CommonConstants.ERROR);
            _mockQueryService.Verify(q => q.GetDrugMasterList(), Times.Once);
        }

        [Fact]
        public async Task GetDrugMasterList_ShouldReturnOk_WhenRecordsExist()
        {
            // Arrange
            var drugMasterList = new List<GetDrugMasterDto>
            {
                new GetDrugMasterDto
                {
                    ItemCode = "DRUG123",
                    MedicationCode = "MED123",
                    MasterType = "General",
                    ResourceID = "RESOURCE001"
                },
                new GetDrugMasterDto
                {
                    ItemCode = "DRUG456",
                    MedicationCode = "MED456",
                    MasterType = "Special",
                    ResourceID = "RESOURCE002"
                }
            };

            _mockQueryService.Setup(q => q.GetDrugMasterList())
                .ReturnsAsync(drugMasterList);

            // Act
            var result = await _controller.GetDrugMasterList();

            // Assert
            var okResult = result.Should().BeOfType<OkObjectResult>().Subject;
            var response = okResult.Value.Should().BeOfType<GenericResponse<List<GetDrugMasterDto>>>().Subject;

            response.IsSuccess.Should().BeTrue();
            response.StatusCode.Should().Be(ResponseStatusCode.STATUS_SUCCESS);
            response.Message.Should().Be(ResponseMessage.STATUS_DATA_FOUND);
            response.HasError.Should().BeFalse();
            response.MessageType.Should().Be(CommonConstants.SUCCESS);
            response.Result.Should().NotBeNullOrEmpty();
            response.Result.Should().HaveCount(2);
            response.Result?[0].ItemCode.Should().Be("DRUG123");
            response.Result?[^1].ItemCode.Should().Be("DRUG456");
            _mockQueryService.Verify(q => q.GetDrugMasterList(), Times.Once);
        }
    }
}