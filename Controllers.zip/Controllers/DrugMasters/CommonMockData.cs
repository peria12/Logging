﻿using Aurora.AdministrationService.API.Models.Dto.DrugMasters;
using Aurora.AdministrationService.Domain.V1.Entities.DrugMasters;

namespace Aurora.AdministrationService.Tests.API.Controllers.DrugMasters
{
    public static class CommonMockData
    {
        public static DrugMaster GetMockDrugMaster()
        {
            return new DrugMaster
            {
                ResourceID = "12345",
                MasterType = "TypeA",
                ItemCode = "Item001",
                ItemDescription = "Description of Item",
                ItemTypeCode = "Type001",
                ItemTypeDescription = "Item Type Description",
                MedicationCode = "Med001",
                MedicationDescription = "Medication Description",
                MedicationCategory = "CategoryA",
                MedicationType = "Tablet",
                Strength = "10mg",
                DrugForm = "Tablet",
                Caution = "Handle with care",
                DosageUnit = "mg",
                DoseValue = 10.5,
                FrequencyDesc = "Once a day",
                FrequencyValue = 1.0,
                DurationUnit = "Days",
                DurationValue = 30,
                Route = "Oral",
                DrugFormGroup = "GroupA",
                Instructions = "Take as prescribed",
                IsSTATDrug = true,
                IsAlertRequired = false,
                IsPoisonDrug = false,
                IsPsychotropicDrug = false,
                IsDangerousDrug = false,
                IsAnesthesiaDrug = false,
                FacilityCode = "FAC001",
                BrandShare = "BrandA",
                CreatedBy = "Admin",
                UpdatedBy = "Admin",
                CreatedDate = DateTime.UtcNow,
                UpdatedDate = DateTime.UtcNow,
                IsDeleted = false,
                RecordVersion = new byte[] { 1, 2, 3, 4 }
            };
        }

        public static DrugMasterDto GetMockDrugMasterDto()
        {
            return new DrugMasterDto
            {
                ResourceID = "12345",
                MasterType = "TypeA",
                ItemCode = "Item001",
                ItemDescription = "Description of Item",
                ItemTypeCode = "Type001",
                ItemTypeDescription = "Item Type Description",
                MedicationCode = "Med001",
                MedicationDescription = "Medication Description",
                MedicationCategory = "CategoryA",
                MedicationType = "Tablet",
                Strength = "10mg",
                DrugForm = "Tablet",
                Caution = "Handle with care",
                DosageUnit = "mg",
                DoseValue = 10.5M,
                FrequencyDesc = "Once a day",
                FrequencyValue = 1.0M,
                DurationUnit = "Days",
                DurationValue = 30,
                Route = "Oral",
                DrugFormGroup = "GroupA",
                Instructions = "Take as prescribed",
                IsSTATDrug = true,
                IsAlertRequired = false,
                IsPoisonDrug = false,
                IsPsychotropicDrug = false,
                IsDangerousDrug = false,
                IsAnesthesiaDrug = false,
                FacilityCode = "FAC001",
                BrandShare = "BrandA",
                SourceAppId = 123456,
                Title = "Drug Title",
                EventAction = "Create",
                RequestedDate = DateTime.UtcNow,
                RegionCode = "MYS",
                LanguageCode = "EN",
                LocationCode = "LOC001",
                AcknowledgementID = "ACK001"
            };
        }

        public static DrugMaster GetMockDrugMaster2(long id = 4)
        {
            return new DrugMaster
            {
                ID = 4,
                ResourceID = "1652345",
                MasterType = "TypeA",
                ItemCode = "Item0011",
                ItemDescription = "Description of Item",
                ItemTypeCode = "Type001",
                ItemTypeDescription = "Item Type Description",
                MedicationCode = "Med001",
                MedicationDescription = "Medication Description",
                MedicationCategory = "CategoryA",
                MedicationType = "Tablet",
                Strength = "10mg",
                DrugForm = "Tablet",
                Caution = "Handle with care",
                DosageUnit = "mg",
                DoseValue = 10.5,
                FrequencyDesc = "Once a day",
                FrequencyValue = 1.0,
                DurationUnit = "Days",
                DurationValue = 30,
                Route = "Oral",
                DrugFormGroup = "GroupA",
                Instructions = "Take as prescribed",
                IsSTATDrug = true,
                IsAlertRequired = false,
                IsPoisonDrug = false,
                IsPsychotropicDrug = false,
                IsDangerousDrug = false,
                IsAnesthesiaDrug = false,
                FacilityCode = "FAC001",
                BrandShare = "BrandA",
                CreatedBy = "Admin",
                UpdatedBy = "Admin",
                RecordVersion = new byte[] { 1, 2, 3, 4 },
                IsDeleted = false,
                CreatedDate = DateTime.UtcNow,
                UpdatedDate = DateTime.UtcNow,
                IsActive = true,
            };
        }

        public static CreateDrugMasterRequest GetMockCreateDrugMasterRequest()
        {
            var mockDto = GetMockDrugMasterDto();
            return new CreateDrugMasterRequest
            {
                ResourceID = mockDto.ResourceID,
                MasterType = mockDto.MasterType,
                ItemCode = mockDto.ItemCode,
                ItemDescription = mockDto.ItemDescription,
                ItemTypeCode = mockDto.ItemTypeCode,
                ItemTypeDescription = mockDto.ItemTypeDescription,
                MedicationCode = mockDto.MedicationCode,
                MedicationDescription = mockDto.MedicationDescription,
                MedicationCategory = mockDto.MedicationCategory,
                MedicationType = mockDto.MedicationType,
                Strength = mockDto.Strength,
                DrugForm = mockDto.DrugForm,
                Caution = mockDto.Caution,
                DosageUnit = mockDto.DosageUnit,
                DoseValue = mockDto.DoseValue,
                FrequencyDesc = mockDto.FrequencyDesc,
                FrequencyValue = mockDto.FrequencyValue,
                DurationUnit = mockDto.DurationUnit,
                DurationValue = mockDto.DurationValue,
                Route = mockDto.Route,
                DrugFormGroup = mockDto.DrugFormGroup,
                Instructions = mockDto.Instructions,
                IsSTATDrug = mockDto.IsSTATDrug,
                IsAlertRequired = mockDto.IsAlertRequired,
                IsPoisonDrug = mockDto.IsPoisonDrug,
                IsPsychotropicDrug = mockDto.IsPsychotropicDrug,
                IsDangerousDrug = mockDto.IsDangerousDrug,
                IsAnesthesiaDrug = mockDto.IsAnesthesiaDrug,
                FacilityCode = mockDto.FacilityCode,
                BrandShare = mockDto.BrandShare
            };
        }

        public static UpdateDrugMasterRequest GetMockUpdateDrugMasterRequest(
            string itemCode,
            byte[]? recordVersion = null,
            string medicationCode = "UpdatedMedCode")
        {
            var mockDto = GetMockDrugMasterDto();
            return new UpdateDrugMasterRequest
            {
                ResourceID = mockDto.ResourceID,
                MasterType = mockDto.MasterType,
                ItemCode = itemCode,
                ItemDescription = mockDto.ItemDescription,
                ItemTypeCode = mockDto.ItemTypeCode,
                ItemTypeDescription = mockDto.ItemTypeDescription,
                MedicationCode = medicationCode,
                MedicationDescription = mockDto.MedicationDescription,
                MedicationCategory = mockDto.MedicationCategory,
                MedicationType = mockDto.MedicationType,
                Strength = mockDto.Strength,
                DrugForm = mockDto.DrugForm,
                Caution = mockDto.Caution,
                DosageUnit = mockDto.DosageUnit,
                DoseValue = mockDto.DoseValue,
                FrequencyDesc = mockDto.FrequencyDesc,
                FrequencyValue = mockDto.FrequencyValue,
                DurationUnit = mockDto.DurationUnit,
                DurationValue = mockDto.DurationValue,
                Route = mockDto.Route,
                DrugFormGroup = mockDto.DrugFormGroup,
                Instructions = mockDto.Instructions,
                IsSTATDrug = mockDto.IsSTATDrug,
                IsAlertRequired = mockDto.IsAlertRequired,
                IsPoisonDrug = mockDto.IsPoisonDrug,
                IsPsychotropicDrug = mockDto.IsPsychotropicDrug,
                IsDangerousDrug = mockDto.IsDangerousDrug,
                IsAnesthesiaDrug = mockDto.IsAnesthesiaDrug,
                FacilityCode = mockDto.FacilityCode,
                RecordVersion = recordVersion ?? new byte[] { 1, 2, 3, 4 }
            };
        }
    }
}