﻿using Aurora.AdministrationService.API.Controllers;
using Aurora.AdministrationService.API.Models.RequestModels.AdminUser;
using Aurora.AdministrationService.API.Models.ResponseModels.AdminUser;
using Aurora.AdministrationService.API.Services.IService.Old.User;
using Aurora.AdministrationService.CrossCutting.CommonModels;
using Microsoft.AspNetCore.Mvc;
using Moq;
using System.Threading.Tasks;
using Microsoft.EntityFrameworkCore;
using Xunit;
using Aurora.AdministrationService.Infrastructure;
using Microsoft.Extensions.Configuration;

namespace Aurora.AdministrationService.Tests.API.Controllers.AdminUser;

public class AdminUserControllerTests
{
    private readonly Mock<IUserService> _userServiceMock;
    private readonly DbContextOptions<ReadWriteDbContext> _dbContextOptions;
    private readonly Mock<IConfiguration> _configurationMock; 
    private readonly ReadWriteDbContext _context;
    private readonly AdminUserController _controller;

    public AdminUserControllerTests()
    {
        // Configure InMemory Database
        _dbContextOptions = new DbContextOptionsBuilder<ReadWriteDbContext>()
            .UseInMemoryDatabase(Guid.NewGuid().ToString())
            .Options;

        // Initialize the context and the controller
        _configurationMock =new Mock<IConfiguration> ();
        _context = new ReadWriteDbContext(_dbContextOptions);
        _userServiceMock = new Mock<IUserService>();
        _controller = new AdminUserController(_configurationMock.Object, _userServiceMock.Object, _context);
    }

    #region Test: Login
    [Fact]
    public async Task Login_ReturnsOk_WhenValid()
    {
        // Arrange
        var request = new AdminLoginRequest { Username = "test", Password = "password" };
        _userServiceMock.Setup(s => s.Login(It.IsAny<AdminLoginRequest>()))
            .ReturnsAsync(new GenericResponse<AdminLoginResponse> { IsSuccess = true });

        // Act
        var result = await _controller.Login(request);

        // Assert
        var okResult = Assert.IsType<OkObjectResult>(result);
        var response = Assert.IsType<GenericResponse<AdminLoginResponse>>(okResult.Value);
        Assert.True(response.IsSuccess);
    }

    [Fact]
    public async Task Login_ReturnsBadRequest_WhenServiceFails()
    {
        // Arrange
        var request = new AdminLoginRequest { Username = "test", Password = "password" };
        _userServiceMock.Setup(s => s.Login(It.IsAny<AdminLoginRequest>()))
            .ReturnsAsync(new GenericResponse<AdminLoginResponse> { IsSuccess = false });

        // Act
        var result = await _controller.Login(request);

        // Assert
        var okResult = Assert.IsType<OkObjectResult>(result);
        var response = Assert.IsType<GenericResponse<AdminLoginResponse>>(okResult.Value);
        Assert.False(response.IsSuccess);
    }
    #endregion

    #region Test: LoginWithCredentials
    [Fact]
    public async Task LoginWithCredentials_ReturnsOk_WhenValid()
    {
        // Arrange
        var request = new AdminLoginRequest { Username = "test", Password = "password" };
        _userServiceMock.Setup(s => s.LoginWithCredentials(It.IsAny<AdminLoginRequest>()))
            .ReturnsAsync(new GenericResponse<AdminLoginResponse> { IsSuccess = true });

        // Act
        var result = await _controller.LoginWithCredentials(request);

        // Assert
        var okResult = Assert.IsType<OkObjectResult>(result);
        var response = Assert.IsType<GenericResponse<AdminLoginResponse>>(okResult.Value);
        Assert.True(response.IsSuccess);
    }

    [Fact]
    public async Task LoginWithCredentials_ReturnsBadRequest_WhenServiceFails()
    {
        // Arrange
        var request = new AdminLoginRequest { Username = "test", Password = "password" };
        _userServiceMock.Setup(s => s.LoginWithCredentials(It.IsAny<AdminLoginRequest>()))
            .ReturnsAsync(new GenericResponse<AdminLoginResponse> { IsSuccess = false });

        // Act
        var result = await _controller.LoginWithCredentials(request);

        // Assert
        var okResult = Assert.IsType<OkObjectResult>(result);
        var response = Assert.IsType<GenericResponse<AdminLoginResponse>>(okResult.Value);
        Assert.False(response.IsSuccess);
    }
    #endregion

    #region Test: PatientLogin
    [Fact]
    public async Task PatientLogin_ReturnsBadRequest_WhenRegionCodeMissing()
    {
        // Arrange
        var request = new AdminLoginRequest { Username = "test", Password = "password" };
        var regionCode = string.Empty;  // Missing RegionCode header

        // Act
        var result = await _controller.PatientLogin(request, regionCode);

        // Assert
        var badRequestResult = Assert.IsType<BadRequestObjectResult>(result);
        var response = Assert.IsType<GenericResponse<string>>(badRequestResult.Value);
        Assert.False(response.IsSuccess);
        Assert.Equal("RegionCode header is required.", response.Message);
    }

    [Fact]
    public async Task PatientLogin_ReturnsBadRequest_WhenInvalidRegionCode()
    {
        // Arrange
        var request = new AdminLoginRequest { Username = "test", Password = "password" };
        var regionCode = "INVALID";  // Invalid region code

        // Act
        var result = await _controller.PatientLogin(request, regionCode);

        // Assert
        var badRequestResult = Assert.IsType<BadRequestObjectResult>(result);
        var response = Assert.IsType<GenericResponse<string>>(badRequestResult.Value);
        Assert.False(response.IsSuccess);
        Assert.Equal("Invalid RegionCode.", response.Message);
    }

    [Fact]
    public async Task PatientLogin_ReturnsOk_WhenValidRegionCodeAndPassport()
    {
        // Arrange
        var request = new AdminLoginRequest { Username = "passport123", Password = "password" };
        var regionCode = "MYS";  // Valid region code

        // Add a mock user to the in-memory database
        _context.Users.Add(new Domain.Old.Entities.User { UserId="test23",  NomorKtpNomorPassporNomorSimNomorSuratLahir = "passport123", PassportNumber = "passport123", Password = "password" });
        await _context.SaveChangesAsync();

        _userServiceMock.Setup(u => u.SignInPassportAsync(It.IsAny<string>(), It.IsAny<string>()))
            .ReturnsAsync(new GenericResponse<AdminLoginResponse> { IsSuccess = true });

        // Act
        var result = await _controller.PatientLogin(request, regionCode);

        // Assert
        var okResult = Assert.IsType<OkObjectResult>(result);
        var response = Assert.IsType<GenericResponse<AdminLoginResponse>>(okResult.Value);
        Assert.True(response.IsSuccess);
    }

    [Fact]
    public async Task PatientLogin_ReturnsOk_WhenValidRegionCode()
    {
        // Arrange
        var request = new AdminLoginRequest { Username = "testuser", Password = "password" };
        var regionCode = "MYS";  // Valid region code

        // Mock the user service call
        _userServiceMock.Setup(u => u.SignInAsync(It.IsAny<string>(), It.IsAny<string>(), It.IsAny<string>()))
            .ReturnsAsync(new GenericResponse<AdminLoginResponse> { IsSuccess = true });

        // Act
        var result = await _controller.PatientLogin(request, regionCode);

        // Assert
        var okResult = Assert.IsType<OkObjectResult>(result);
        var response = Assert.IsType<GenericResponse<AdminLoginResponse>>(okResult.Value);
        Assert.True(response.IsSuccess);
    }
    #endregion

    #region Test: Logout
    [Fact]
    public async Task Logout_ReturnsOk_WhenValid()
    {
        // Arrange
        var request = new AdminUserLogout { Token = "valid_token" };
        _userServiceMock.Setup(s => s.Logout(It.IsAny<string>()))
            .ReturnsAsync(new GenericResponse<string> { IsSuccess = true });

        // Act
        var result = await _controller.Logout(request);

        // Assert
        var okResult = Assert.IsType<OkObjectResult>(result);
        var response = Assert.IsType<GenericResponse<string>>(okResult.Value);
        Assert.True(response.IsSuccess);
    }

    [Fact]
    public async Task Logout_ReturnsBadRequest_WhenServiceFails()
    {
        // Arrange
        var request = new AdminUserLogout { Token = "invalid_token" };
        _userServiceMock.Setup(s => s.Logout(It.IsAny<string>()))
            .ReturnsAsync(new GenericResponse<string> { IsSuccess = false });

        // Act
        var result = await _controller.Logout(request);

        // Assert
        var okResult = Assert.IsType<OkObjectResult>(result);
        var response = Assert.IsType<GenericResponse<string>>(okResult.Value);
        Assert.False(response.IsSuccess);
    }
    #endregion
}

