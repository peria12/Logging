﻿using Aurora.AdministrationService.API.Controllers.ResourceType;
using Aurora.AdministrationService.API.Helper;
using Aurora.AdministrationService.API.Models.Dto.UserGroups.ResourceType;
using Aurora.AdministrationService.API.Services.IService.UserGroups.ResourceType;
using Aurora.AdministrationService.CrossCutting.CommonModels;
using Aurora.AdministrationService.CrossCutting.Constants;
using FluentAssertions;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Moq;

namespace Aurora.AdministrationService.Tests.API.Controllers.ResourceType
{
    public class ResourceTypeControllerTest
    {
        private readonly Mock<IResourceTypeCommandService> _mockResourceTypeCommandService;
        private readonly Mock<IResourceTypeQueryService> _mockResourceTypeQueryService;
        private readonly ResourceTypeController _controller;
        private readonly Mock<IRegionCodeValidationHelper> _regionHelperMock;

        public ResourceTypeControllerTest()
        {
            _regionHelperMock = new Mock<IRegionCodeValidationHelper>();
            _mockResourceTypeCommandService = new Mock<IResourceTypeCommandService>();
            _mockResourceTypeQueryService = new Mock<IResourceTypeQueryService>();
            _controller = new ResourceTypeController(_mockResourceTypeQueryService.Object, _mockResourceTypeCommandService.Object, _regionHelperMock.Object);
        }
        [Fact]
        public void GetResourceTypes_InvalidRegionCode_ReturnsBadRequest()
        {
            // Arrange
            _regionHelperMock
                .Setup(helper => helper.VerifyRegionCodeHeader(It.IsAny<HttpRequest>()))
                .Returns(new GenericResponse<string> { HasError = true, Message = "Invalid RegionCode" });

            // Act
            var result = _controller.GetResourceTypeList();

            // Assert
            var badRequestResult = result.Result as BadRequestObjectResult;
            badRequestResult.Should().NotBeNull();
            var response = badRequestResult?.Value as GenericResponse<string>;
            response.Should().NotBeNull();
            response?.HasError.Should().BeTrue();
            response?.Message.Should().Be("Invalid RegionCode");
        }

        [Fact]
        public void CreateResourceType_InvalidRegionCode_ReturnsBadRequest()
        {
            // Arrange
            var resourceType = new ResourceTypeDto()
            {
                Code = "test",
                ResourceTypeName = "test",
                Definition = "test",
                Display = "test",
                Source = "test",
            };
            _regionHelperMock
                .Setup(helper => helper.VerifyRegionCodeHeader(It.IsAny<HttpRequest>()))
                .Returns(new GenericResponse<string> { HasError = true, Message = "Invalid RegionCode" });

            // Act
            var result = _controller.CreateResourceType(resourceType);

            // Assert
            var badRequestResult = result?.Result as BadRequestObjectResult;
            badRequestResult.Should().NotBeNull();
            var response = badRequestResult?.Value as GenericResponse<string>;
            response.Should().NotBeNull();
            response?.HasError.Should().BeTrue();
            response?.Message.Should().Be("Invalid RegionCode");
        }

        [Fact]
        public async Task GetResourceTypeById_InvalidRegionCode_ReturnsBadRequest()
        {
            // Arrange
            _regionHelperMock
                .Setup(helper => helper.VerifyRegionCodeHeader(It.IsAny<HttpRequest>()))
                .Returns(new GenericResponse<string> { HasError = true, Message = "Invalid RegionCode" });

            // Act
            var result = await _controller.GetResourceTypeById(1);

            // Assert
            var badRequestResult = result.Result as BadRequestObjectResult;

            badRequestResult.Should().NotBeNull();
            var response = badRequestResult?.Value as GenericResponse<string>;
            response.Should().NotBeNull();
            response?.HasError.Should().BeTrue();
            response?.Message.Should().Be("Invalid RegionCode");
        }

        [Fact]
        public void UpdateResourceTypeDetails_InvalidRegionCode_ReturnsBadRequest()
        {
            // Arrange
            int id = 1;
            var resourceType = new UpdateResourceTypeRequest()
            {
                Id = 1,
                Code = "test",
                ResourceTypeName = "test",
                Definition = "test",
                Display = "test",
                Source = "test",
            };
            _regionHelperMock
                .Setup(helper => helper.VerifyRegionCodeHeader(It.IsAny<HttpRequest>()))
                .Returns(new GenericResponse<string> { HasError = true, Message = "Invalid RegionCode" });

            // Act
            var result = _controller.UpdateResourceTypeDetails(id, resourceType);

            // Assert
            var badRequestResult = result?.Result as BadRequestObjectResult;
            badRequestResult.Should().NotBeNull();
            var response = badRequestResult?.Value as GenericResponse<string>;
            response.Should().NotBeNull();
            response?.HasError.Should().BeTrue();
            response?.Message.Should().Be("Invalid RegionCode");
        }

        [Fact]
        public async Task CreateResourceType_ShouldReturnSuccessResponse_WhenIsAdded()
        {
            // Arrange
            var resourceType = new ResourceTypeDto()
            {
                Code = "test",
                ResourceTypeName = "test",
                Definition = "test",
                Display = "test",
                Source = "test",
            };
            _mockResourceTypeCommandService.Setup(service => service.CreateResourceTypeAsync(resourceType)).ReturnsAsync(true);

            // Act
            var result = await _controller.CreateResourceType(resourceType) as OkObjectResult;
            var response = result?.Value as GenericResponse<string>;

            // Assert
            result.Should().NotBeNull();
            result?.StatusCode.Should().Be(200);
            response?.IsSuccess.Should().BeTrue();
            response?.StatusCode.Should().Be(ResponseStatusCode.STATUS_SUCCESS);
            response?.Message.Should().Be(ResponseMessage.STATUS_DATA_ADDED);
        }

        [Fact]
        public void GetResourceTypeList_ShouldReturnResourceTypeList()
        {
            // Arrange
            var resourceTypeList = new List<GetResourceTypeDto> { new GetResourceTypeDto() {
                Code = "test",
                ResourceTypeName = "test",
                Definition = "test",
                Display = "test",
                Source = "test",
            } };
            _mockResourceTypeQueryService.Setup(service => service.GetResourceTypeList()).Returns(resourceTypeList);

            // Act
            var result = _controller.GetResourceTypeList();
            var okresult = result?.Result as OkObjectResult;
            var response = okresult?.Value as GenericResponseList<GetResourceTypeDto>;

            // Assert
            result.Should().NotBeNull();
            response?.StatusCode.Should().Be("200");
            response?.IsSuccess.Should().BeTrue();
            response?.StatusCode.Should().Be(ResponseStatusCode.STATUS_SUCCESS);
            response?.Message.Should().Be(ResponseMessage.STATUS_DATA_FOUND);
            response?.TotalCount.Should().Be(resourceTypeList.Count);

        }

        [Fact]
        public async Task GetResourceTypeById_ShouldReturnNull_WhenIdIsInvalid()
        {
            // Act
            var result = await _controller.GetResourceTypeById(null);
            var response = result.Value as GenericResponse<GetResourceTypeDetailDto>;

            // Assert
            result.Should().NotBeNull();
            response.Should().BeNull();

        }

        [Fact]
        public async Task GetResourceTypeById_ShouldReturnNotFound_WhenDoesNotExist()
        {
            // Arrange
            var id = 1;
            GetResourceTypeDetailDto resourceTypeDetailDto = new GetResourceTypeDetailDto()
            {
                Code = "test",
                ResourceTypeName = "test",
                Definition = "test",
                Display = "test",
                Source = "test",
            };
            _mockResourceTypeQueryService
              .Setup(service => service.GetResourceTypeById(2)).ReturnsAsync(resourceTypeDetailDto);

            // Act
            var result = await _controller.GetResourceTypeById(id);
            var okobjectresult = result?.Result as OkObjectResult;
            var response = okobjectresult?.Value as GenericResponse<GetResourceTypeDetailDto>;

            // Assert
            result.Should().NotBeNull();
            response?.IsSuccess.Should().BeTrue();
            response?.StatusCode.Should().Be(ResponseStatusCode.STATUS_NOTFOUND);
            response?.Message.Should().Be(ResponseMessage.STATUS_NODATA);
        }

        [Fact]
        public async Task UpdateResourceTypeDetails_ShouldReturnBadRequest_WhenAlreadyExists()
        {
            // Arrange
            int id = 1;
            var resourceType = new UpdateResourceTypeRequest()
            {
                Id = 1,
                Code = "test",
                ResourceTypeName = "test",
                Definition = "test",
                Display = "test",
                Source = "test",
            };
            _mockResourceTypeQueryService.Setup(service => service.IsResourceTypeAlreadyExist(id)).ReturnsAsync((true, ResponseMessage.STATUS_NODATA));

            // Act
            var result = await _controller.UpdateResourceTypeDetails(id, resourceType);

            // Assert
            result.Should().NotBeNull();

        }

        [Fact]
        public async Task UpdateResourceTypeDetails_ResourceTypeNotFound_ReturnsNotFound()
        {
            // Arrange
            int resourceTypeId = 1;
            var resourceTypeRequest = new UpdateResourceTypeRequest()
            {
                Id = resourceTypeId,
                Code = "test",
                ResourceTypeName = "test",
                Definition = "test",
                Display = "test",
                Source = "test",
            };
            Domain.V1.Entities.UserGroups.ResourceType resourceType = null;
            _mockResourceTypeQueryService
                .Setup(service => service.FindResourceTypeById(resourceTypeId))
                .ReturnsAsync(resourceType);

            // Act
            var result = await _controller.UpdateResourceTypeDetails(resourceTypeId, resourceTypeRequest);

            // Assert
            var actionResult = Assert.IsType<NotFoundObjectResult>(result);
            var response = Assert.IsType<GenericResponse<string>>(actionResult.Value);
            Assert.Equal(ResponseStatusCode.STATUS_NOTFOUND, response.StatusCode);
            Assert.Equal(ResponseMessage.STATUS_NODATA, response.Message);
        }

        [Fact]
        public async Task UpdateResourceTypeDetails_UpdateSuccessful_ReturnsOk()
        {
            // Arrange
            int resourceTypeId = 1;
            var resourceTypeRequest = new UpdateResourceTypeRequest()
            {
                Id = 1,
                Code = "test",
                ResourceTypeName = "test",
                Definition = "test",
                Display = "test",
                Source = "test",
            };
            var existingResourceType = new Domain.V1.Entities.UserGroups.ResourceType
            {
                Id = resourceTypeId,
                Code = "test",
                ResourceTypeName = "test",
                Definition = "test",
                Display = "test",
                Source = "test",
                CreatedBy = "Admin",
                CreatedDate = DateTime.UtcNow,
                IsDeleted = false
            };

            _mockResourceTypeQueryService
                .Setup(service => service.FindResourceTypeById(resourceTypeId))
                .ReturnsAsync(existingResourceType);

            _mockResourceTypeCommandService
                .Setup(service => service.UpdateResourceTypeAsync(resourceTypeRequest, existingResourceType))
                .ReturnsAsync(true);

            // Act
            var result = await _controller.UpdateResourceTypeDetails(resourceTypeId, resourceTypeRequest);

            // Assert
            var actionResult = Assert.IsType<OkObjectResult>(result);
            var response = Assert.IsType<GenericResponse<string>>(actionResult.Value);
            Assert.Equal(ResponseStatusCode.STATUS_SUCCESS, response.StatusCode);
            Assert.Equal(ResponseMessage.STATUS_DATA_UPDATED, response.Message);
            Assert.Equal(CommonConstants.SUCCESS, response.MessageType);
        }

        [Fact]
        public async Task UpdateResourceTypeDetails_UpdateFailed_ReturnsOkWithErrorMessage()
        {
            // Arrange
            int resourceTypeId = 1;
            var resourceTypeRequest = new UpdateResourceTypeRequest()
            {
                Id = resourceTypeId,
                Code = "test",
                ResourceTypeName = "test",
                Definition = "test",
                Display = "test",
                Source = "test",
            };
            var existingResourceType = new Domain.V1.Entities.UserGroups.ResourceType
            {
                Id = resourceTypeId,
                Code = "test",
                ResourceTypeName = "test",
                Definition = "test",
                Display = "test",
                Source = "test",
                CreatedBy = "Admin",
                CreatedDate = DateTime.UtcNow,
                IsDeleted = false
            };

            _mockResourceTypeQueryService
                .Setup(service => service.FindResourceTypeById(resourceTypeId))
                .ReturnsAsync(existingResourceType); // Simulate resourceType found

            _mockResourceTypeCommandService
                .Setup(service => service.UpdateResourceTypeAsync(resourceTypeRequest, existingResourceType))
                .ReturnsAsync(false); // Simulate update failure

            // Act
            var result = await _controller.UpdateResourceTypeDetails(resourceTypeId, resourceTypeRequest);

            // Assert
            var actionResult = Assert.IsType<OkObjectResult>(result);
            Assert.Equal(ResponseStatusCode.STATUS_SUCCESS, actionResult.StatusCode.ToString());
        }

        [Fact]
        public async Task GetResourceTypeById_ReturnsOk_WhenResourceTypeIsFound()
        {
            // Arrange
            int resourceTypeId = 1;
            var expectedResourceType = new GetResourceTypeDetailDto
            {
                Id = resourceTypeId,
                Code = "test",
                ResourceTypeName = "test",
                Definition = "test",
                Display = "test",
                Source = "test",
                IsDeleted = false,
            };
            _mockResourceTypeQueryService.Setup(s => s.GetResourceTypeById(resourceTypeId)).ReturnsAsync(expectedResourceType);

            // Act
            var result = await _controller.GetResourceTypeById(resourceTypeId);

            // Assert
            var actionResult = Assert.IsType<ActionResult<GenericResponse<GetResourceTypeDetailDto>>>(result);
            var okResult = Assert.IsType<OkObjectResult>(actionResult.Result);
            var response = Assert.IsType<GenericResponse<GetResourceTypeDetailDto>>(okResult.Value);
            Assert.True(response.IsSuccess);
            Assert.Equal(ResponseStatusCode.STATUS_SUCCESS, response.StatusCode);
            Assert.Equal(ResponseMessage.STATUS_DATA_FOUND, response.Message);
            Assert.Equal(expectedResourceType, response.Result);
        }
    }
}
