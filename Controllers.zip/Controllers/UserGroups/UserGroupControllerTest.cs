﻿using Aurora.AdministrationService.API.Controllers.Group;
using Aurora.AdministrationService.API.Enum;
using Aurora.AdministrationService.API.Helper;
using Aurora.AdministrationService.API.Models.Dto.UserGroups.Groups;
using Aurora.AdministrationService.API.Services.IService.UserGroups.Groups;
using Aurora.AdministrationService.CrossCutting.CommonModels;
using Aurora.AdministrationService.CrossCutting.Constants;
using FluentAssertions;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Moq;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Aurora.AdministrationService.Tests.API.Controllers.UserGroups
{
    public class UserGroupControllerTest
    {
        private readonly Mock<IGroupCommandService> _mockUserGroupCommandService;
        private readonly Mock<IGroupQueryService> _mockUserGroupQueryService;
        private readonly UserGroupMasterController _controller;
        private readonly Mock<IRegionCodeValidationHelper> _regionHelperMock;

        public UserGroupControllerTest()
        {
            _regionHelperMock = new Mock<IRegionCodeValidationHelper>();
            _mockUserGroupCommandService = new Mock<IGroupCommandService>();
            _mockUserGroupQueryService = new Mock<IGroupQueryService>();
            _controller = new UserGroupMasterController(_mockUserGroupQueryService.Object, _mockUserGroupCommandService.Object, _regionHelperMock.Object);
        }
        [Fact]
        public async void GetUserGroups_InvalidRegionCode_ReturnsBadRequest()
        {
            // Arrange
            _regionHelperMock
                .Setup(helper => helper.VerifyRegionCodeHeader(It.IsAny<HttpRequest>()))
                .Returns(new GenericResponse<string> { HasError = true, Message = "Invalid RegionCode" });

            // Act
            var result = await _controller.GetGroupMasters();

            // Assert
            var badRequestResult = result.Result as BadRequestObjectResult;
            badRequestResult.Should().NotBeNull();
            var response = badRequestResult?.Value as GenericResponse<string>;
            response.Should().NotBeNull();
            response?.HasError.Should().BeTrue();
            response?.Message.Should().Be("Invalid RegionCode");
        }

        [Fact]
        public void CreateUserGroup_InvalidRegionCode_ReturnsBadRequest()
        {
            // Arrange
            var userGroup = new GroupDto()
            {
                Code = "Test",
                Definition = "test",
                Source = "source",
                GroupName = "test",
                Display = "test",
                IsObsolete = true,
            };
            _regionHelperMock
                .Setup(helper => helper.VerifyRegionCodeHeader(It.IsAny<HttpRequest>()))
                .Returns(new GenericResponse<string> { HasError = true, Message = "Invalid RegionCode" });

            // Act
            var result = _controller.CreateGroup(userGroup);

            // Assert
            var badRequestResult = result?.Result as BadRequestObjectResult;
            badRequestResult.Should().NotBeNull();
            var response = badRequestResult?.Value as GenericResponse<string>;
            response.Should().NotBeNull();
            response?.HasError.Should().BeTrue();
            response?.Message.Should().Be("Invalid RegionCode");
        }

        [Fact]
        public async Task GetUserGroupById_InvalidRegionCode_ReturnsBadRequest()
        {
            // Arrange
            _regionHelperMock
                .Setup(helper => helper.VerifyRegionCodeHeader(It.IsAny<HttpRequest>()))
                .Returns(new GenericResponse<string> { HasError = true, Message = "Invalid RegionCode" });

            // Act
            var result = await _controller.GetGroupById(1);

            // Assert
            var badRequestResult = result.Result as BadRequestObjectResult;

            badRequestResult.Should().NotBeNull();
            var response = badRequestResult?.Value as GenericResponse<string>;
            response.Should().NotBeNull();
            response?.HasError.Should().BeTrue();
            response?.Message.Should().Be("Invalid RegionCode");
        }

        [Fact]
        public void UpdateUserGroupDetails_InvalidRegionCode_ReturnsBadRequest()
        {
            // Arrange
            int id = 1;
            var userGroup = new UpdateGroupRequest()
            {
                Id = 1,
                Code = "Test",
                Definition = "test",
                Source = "source",
                GroupName = "test",
                Display = "test",
                IsObsolete = true,
            };
            _regionHelperMock
                .Setup(helper => helper.VerifyRegionCodeHeader(It.IsAny<HttpRequest>()))
                .Returns(new GenericResponse<string> { HasError = true, Message = "Invalid RegionCode" });

            // Act
            var result = _controller.UpdateGroupDetails(id, userGroup);

            // Assert
            var badRequestResult = result?.Result as BadRequestObjectResult;
            badRequestResult.Should().NotBeNull();
            var response = badRequestResult?.Value as GenericResponse<string>;
            response.Should().NotBeNull();
            response?.HasError.Should().BeTrue();
            response?.Message.Should().Be("Invalid RegionCode");
        }

        [Fact]
        public async Task CreateUserGroup_ShouldReturnSuccessResponse_WhenIsAdded()
        {
            // Arrange
            var userGroup = new GroupDto()
            {
                Code = "Test",
                Definition = "test",
                Source = "source",
                GroupName = "test",
                Display = "test",
                IsObsolete = true,
            };
            _mockUserGroupCommandService.Setup(service => service.CreateGroupAsync(userGroup)).ReturnsAsync(true);

            // Act
            var result = await _controller.CreateGroup(userGroup) as OkObjectResult;
            var response = result?.Value as GenericResponse<string>;

            // Assert
            result.Should().NotBeNull();
            result?.StatusCode.Should().Be(200);
            response?.IsSuccess.Should().BeTrue();
            response?.StatusCode.Should().Be(ResponseStatusCode.STATUS_SUCCESS);
            response?.Message.Should().Be(ResponseMessage.STATUS_DATA_ADDED);
        }

        [Fact]
        public async void GetUserGroupList_ShouldReturnUserGroupList()
        {
            // Arrange
            var userGroupList = new List<GetGroupDto> { new GetGroupDto() { Code=string.Empty, GroupName=string.Empty } };
            _mockUserGroupQueryService.Setup(service => service.GetGroupList()).ReturnsAsync(userGroupList);

            // Act
            var result = await _controller.GetGroupList();
            var okresult = result?.Result as OkObjectResult;
            var response = okresult?.Value as GenericResponseList<GetGroupDto>;

            // Assert
            result.Should().NotBeNull();
            response?.StatusCode.Should().Be("200");
            response?.IsSuccess.Should().BeTrue();
            response?.StatusCode.Should().Be(ResponseStatusCode.STATUS_SUCCESS);
            response?.Message.Should().Be(ResponseMessage.STATUS_DATA_FOUND);
            response?.TotalCount.Should().Be(userGroupList.Count);

        }

        [Fact]
        public async Task GetUserGroupById_ShouldReturnNull_WhenIdIsInvalid()
        {
            // Act
            var result = await _controller.GetGroupById(null);
            var response = result.Value as GenericResponse<GetGroupDetailDto>;

            // Assert
            result.Should().NotBeNull();
            response.Should().BeNull();

        }
        [Fact]
        public async void GetUserGroupMaster_ShouldReturnUserGroupList()
        {
            // Arrange
            var userGroupList = new List<GetGroupMasterDto> { new GetGroupMasterDto() { Code = string.Empty, GroupName = string.Empty } };
               _mockUserGroupQueryService.Setup(service => service.GetGroupMasters()).ReturnsAsync(userGroupList);

            // Act
            var result = await _controller.GetGroupMasters();
            var okresult = result?.Result as OkObjectResult;
            var response = okresult?.Value as GenericResponseList<GetGroupMasterDto>;

            // Assert
            result.Should().NotBeNull();
            response?.StatusCode.Should().Be("200");
            response?.IsSuccess.Should().BeTrue();
            response?.StatusCode.Should().Be(ResponseStatusCode.STATUS_SUCCESS);
            response?.Message.Should().Be(ResponseMessage.STATUS_DATA_FOUND);
            response?.TotalCount.Should().Be(userGroupList.Count);

        }

        [Fact]
        public async Task GetUserGroupById_ShouldReturnNotFound_WhenDoesNotExist()
        {
            // Arrange
            var id = 1;
            GetGroupDetailDto userGroupDetailDto = new GetGroupDetailDto() { Code = string.Empty, GroupName = string.Empty };
            _mockUserGroupQueryService
              .Setup(service => service.GetGroupById(2)).ReturnsAsync(userGroupDetailDto);

            // Act
            var result = await _controller.GetGroupById(id);
            var okobjectresult = result?.Result as OkObjectResult;
            var response = okobjectresult?.Value as GenericResponse<GetGroupDetailDto>;

            // Assert
            result.Should().NotBeNull();
            response?.IsSuccess.Should().BeTrue();
            response?.StatusCode.Should().Be(ResponseStatusCode.STATUS_NOTFOUND);
            response?.Message.Should().Be(ResponseMessage.STATUS_NODATA);
        }

        [Fact]
        public async Task UpdateUserGroupDetails_ShouldReturnBadRequest_WhenAlreadyExists()
        {
            // Arrange
            int id = 1;
            var userGroup = new UpdateGroupRequest()
            {
                Id = 1,
                Code = "Test",
                Definition = "test",
                Source = "source",
                GroupName = "test",
                Display = "test",
                IsObsolete = true,
            };
            _mockUserGroupQueryService.Setup(service => service.IsGroupAlreadyExist(id)).ReturnsAsync((true, ResponseMessage.STATUS_NODATA));

            // Act
            var result = await _controller.UpdateGroupDetails(id, userGroup);

            // Assert
            result.Should().NotBeNull();

        }

        [Fact]
        public async Task UpdateUserGroupDetails_UserGroupNotFound_ReturnsNotFound()
        {
            // Arrange
            int userGroupId = 1;
            var userGroupRequest = new UpdateGroupRequest()
            {
                Id = userGroupId,
                Code = "Test",
                Definition = "test",
                Source = "source",
                GroupName = "test",
                Display = "test",
                IsObsolete = true,
            };
            Domain.V1.Entities.UserGroups.Group userGroup = null;
            _mockUserGroupQueryService
                .Setup(service => service.FindGroupById(userGroupId))
                .ReturnsAsync(userGroup);

            // Act
            var result = await _controller.UpdateGroupDetails(userGroupId, userGroupRequest);

            // Assert
            var actionResult = Assert.IsType<NotFoundObjectResult>(result);
            var response = Assert.IsType<GenericResponse<string>>(actionResult.Value);
            Assert.Equal(ResponseStatusCode.STATUS_NOTFOUND, response.StatusCode);
            Assert.Equal(ResponseMessage.STATUS_NODATA, response.Message);
        }

        [Fact]
        public async Task UpdateUserGroupDetails_UpdateSuccessful_ReturnsOk()
        {
            // Arrange
            int userGroupId = 1;
            var userGroupRequest = new UpdateGroupRequest()
            {
                Id = 1,
                Code = "Test",
                Definition = "test",
                Source = "source",
                GroupName = "test",
                Display = "test",
                IsObsolete = true,
            };
            var existingUserGroup = new Domain.V1.Entities.UserGroups.Group
            {
                Id = userGroupId,
                Code = "Test",
                Definition = "test",
                Source = "source",
                GroupName = "test",
                Display = "test",
                IsObsolete = true,
                CreatedBy = "Admin",
                CreatedDate = DateTime.UtcNow,
                IsDeleted = false
            };

            _mockUserGroupQueryService
                .Setup(service => service.FindGroupById(userGroupId))
                .ReturnsAsync(existingUserGroup);

            _mockUserGroupCommandService
                .Setup(service => service.UpdateGroupAsync(userGroupRequest, existingUserGroup))
                .ReturnsAsync(true);

            // Act
            var result = await _controller.UpdateGroupDetails(userGroupId, userGroupRequest);

            // Assert
            var actionResult = Assert.IsType<OkObjectResult>(result);
            var response = Assert.IsType<GenericResponse<string>>(actionResult.Value);
            Assert.Equal(ResponseStatusCode.STATUS_SUCCESS, response.StatusCode);
            Assert.Equal(ResponseMessage.STATUS_DATA_UPDATED, response.Message);
            Assert.Equal(CommonConstants.SUCCESS, response.MessageType);
        }

        [Fact]
        public async Task UpdateUserGroupDetails_UpdateFailed_ReturnsOkWithErrorMessage()
        {
            // Arrange
            byte[] concurrencyToken = new byte[8] { byte.MinValue, byte.MinValue, byte.MinValue, byte.MinValue, byte.MinValue, byte.MinValue, byte.MinValue, byte.MaxValue };
            int userGroupId = 1;
            var userGroupRequest = new UpdateGroupRequest()
            {
                Id = userGroupId,
                Code = "Test",
                Definition = "test",
                Source = "source",
                GroupName = "test",
                Display = "test",
                IsObsolete = true,
            };
            var existingUserGroup = new Domain.V1.Entities.UserGroups.Group
            {
                Id = userGroupId,
                Code = "Test",
                Definition = "test",
                Source = "source",
                GroupName = "test",
                Display = "test",
                IsObsolete = true,
                CreatedBy = "Admin",
                CreatedDate = DateTime.UtcNow,
                IsDeleted = false
            };

            _mockUserGroupQueryService
                .Setup(service => service.FindGroupById(userGroupId))
                .ReturnsAsync(existingUserGroup); // Simulate userGroup found

            _mockUserGroupCommandService
                .Setup(service => service.UpdateGroupAsync(userGroupRequest, existingUserGroup))
                .ReturnsAsync(false); // Simulate update failure

            // Act
            var result = await _controller.UpdateGroupDetails(userGroupId, userGroupRequest);

            // Assert
            var actionResult = Assert.IsType<OkObjectResult>(result);
            Assert.Equal(ResponseStatusCode.STATUS_SUCCESS, actionResult.StatusCode.ToString());
        }

        [Fact]
        public async Task GetUserGroupById_ReturnsOk_WhenUserGroupIsFound()
        {
            // Arrange
            int userGroupId = 1;
            var expectedUserGroup = new GetGroupDetailDto
            {
                Id = userGroupId,
                Code = "Test",
                Definition = "test",
                Source = "source",
                GroupName = "test",
                Display = "test",
                IsObsolete = true,
                IsDeleted = false,
            };
            _mockUserGroupQueryService.Setup(s => s.GetGroupById(userGroupId)).ReturnsAsync(expectedUserGroup);

            // Act
            var result = await _controller.GetGroupById(userGroupId);

            // Assert
            var actionResult = Assert.IsType<ActionResult<GenericResponse<GetGroupDetailDto>>>(result);
            var okResult = Assert.IsType<OkObjectResult>(actionResult.Result);
            var response = Assert.IsType<GenericResponse<GetGroupDetailDto>>(okResult.Value);
            Assert.True(response.IsSuccess);
            Assert.Equal(ResponseStatusCode.STATUS_SUCCESS, response.StatusCode);
            Assert.Equal(ResponseMessage.STATUS_DATA_FOUND, response.Message);
            Assert.Equal(expectedUserGroup, response.Result);
        }
        [Fact]
        public async void GetGroupMasters_NotAvailableHolidayList()
        {
            // Arrange
            var userGroupList = new List<GetGroupMasterDto> ();
            _mockUserGroupQueryService.Setup(service => service.GetGroupMasters()).ReturnsAsync(userGroupList);

            // Act
            var result = await _controller.GetGroupMasters();
            var notFoundResult = result?.Result as NotFoundObjectResult;
            var response = notFoundResult?.Value as GenericResponseList<GetGroupMasterDto>;

            // Assert
            result.Should().NotBeNull();
            response?.StatusCode.Should().Be(ResponseStatusCode.STATUS_NOTFOUND);
            response?.IsSuccess.Should().BeTrue();
            response?.Message.Should().Be(ResponseMessage.STATUS_NODATA);

        }
        [Fact]
        public async void GetGroupList_NotAvailableHolidayList()
        {
            // Arrange
            var userGroupList = new List<GetGroupDto>();
            _mockUserGroupQueryService.Setup(service => service.GetGroupList()).ReturnsAsync(userGroupList);

            // Act
            var result = await _controller.GetGroupList();
            var notFoundResult = result?.Result as NotFoundObjectResult;
            var response = notFoundResult?.Value as GenericResponseList<GetGroupMasterDto>;

            // Assert
            result.Should().NotBeNull();
            response?.StatusCode.Should().Be(ResponseStatusCode.STATUS_NOTFOUND);
            response?.IsSuccess.Should().BeTrue();
            response?.Message.Should().Be(ResponseMessage.STATUS_NODATA);

        }
        [Fact]
        public async void GetGroupList_InvalidRegionCode_ReturnsBadRequest()
        {
            // Arrange
            _regionHelperMock
                .Setup(helper => helper.VerifyRegionCodeHeader(It.IsAny<HttpRequest>()))
                .Returns(new GenericResponse<string> { HasError = true, Message = "Invalid RegionCode" });

            // Act
            var result = await _controller.GetGroupList();

            // Assert
            var badRequestResult = result.Result as BadRequestObjectResult;
            badRequestResult.Should().NotBeNull();
            var response = badRequestResult?.Value as GenericResponse<string>;
            response.Should().NotBeNull();
            response?.HasError.Should().BeTrue();
            response?.Message.Should().Be("Invalid RegionCode");
        }
    }
}
