﻿#nullable enable
using Aurora.AdministrationService.API.Controllers;
using Aurora.AdministrationService.API.Enum;
using Aurora.AdministrationService.API.Helper;
using Aurora.AdministrationService.API.Models.Dto.Hospitals;
using Aurora.AdministrationService.API.Models.Dto.LocationDetail.Create;
using Aurora.AdministrationService.API.Models.Dto.LocationDetail.Update;
using Aurora.AdministrationService.API.Models.Dto.Locations;
using Aurora.AdministrationService.API.Models.ResponseModels.Location;
using Aurora.AdministrationService.API.Models.ResponseModels.Locations;
using Aurora.AdministrationService.API.Resources;
using Aurora.AdministrationService.API.Services.IService.LocationAddresses;
using Aurora.AdministrationService.API.Services.IService.Locations;
using Aurora.AdministrationService.API.Services.IService.LocationTelecoms;
using Aurora.AdministrationService.CrossCutting.CommonModels;
using Aurora.AdministrationService.CrossCutting.Constants;
using Aurora.AdministrationService.Domain.V1.Entities.Locations;
using FluentAssertions;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.CodeAnalysis;
using Microsoft.Graph;
using Moq;
using LocationEntity = Aurora.AdministrationService.Domain.V1.Entities.Locations.Location;

namespace Aurora.AdministrationService.Tests.API.Controllers.Location
{
    public class LocationControllerTests
    {
        private readonly Mock<IRegionCodeValidationHelper> _mockRegionCodeValidationHelper;
        private readonly Mock<ILocationService> _mockLocationService;
        private readonly Mock<ILocationQueryService> _mockLocationQueryService;
        private readonly Mock<ILocationCommandService> _mockLocationCommandService;
        private readonly Mock<ILocationAddressQueryService> _mockLocationAddressQueryService;
        private readonly Mock<ILocationTelecomQueryService> _mockLocationTelecomQueryService;
        private readonly LocationController _controller;

        public LocationControllerTests()
        {
            _mockRegionCodeValidationHelper = new Mock<IRegionCodeValidationHelper>();
            _mockLocationService = new Mock<ILocationService>();
            _mockLocationQueryService = new Mock<ILocationQueryService>();
            _mockLocationCommandService = new Mock<ILocationCommandService>();
            _mockLocationAddressQueryService = new Mock<ILocationAddressQueryService>();
            _mockLocationTelecomQueryService = new Mock<ILocationTelecomQueryService>();
            _controller = new LocationController(_mockLocationService.Object, _mockRegionCodeValidationHelper.Object, _mockLocationQueryService.Object, _mockLocationCommandService.Object, _mockLocationAddressQueryService.Object, _mockLocationTelecomQueryService.Object);
        }

        [Fact]
        public async Task GetAllLocations_ShouldReturnBadRequest_WhenVerifyRegionCodeHeaderReturnsError()
        {
            // Arrange
            var errorResult = new GenericResponse<string> { HasError = true, IsSuccess = false };
            _mockRegionCodeValidationHelper
                .Setup(helper => helper.VerifyRegionCodeHeader(It.IsAny<HttpRequest>()))
                .Returns(errorResult);

            // Act
            var result = await _controller.GetAllLocations();

            // Assert
            result.Should().BeOfType<BadRequestObjectResult>();
            var badRequestResult = result as BadRequestObjectResult;
            badRequestResult?.Value.Should().BeEquivalentTo(errorResult);
        }

        [Fact]
        public async Task GetAllLocations_ShouldReturnOk_WithListOfLocations_WhenVerifyRegionCodeHeaderIsValid()
        {
            // Arrange
            var verifyStatus = new GenericResponse<string> { HasError = false, IsSuccess = true };
            var mockHttpContext = new DefaultHttpContext();
            mockHttpContext.Request.Headers["RegionCode"] = "MYS";
            _controller.ControllerContext = new Microsoft.AspNetCore.Mvc.ControllerContext
            {
                HttpContext = mockHttpContext
            };

            _mockRegionCodeValidationHelper
                .Setup(x => x.VerifyRegionCodeHeader(It.IsAny<HttpRequest>())).Returns(verifyStatus);

            var locations = new GenericResponseList<AdminLocationsDTO> { IsSuccess = true, Results = (new List<AdminLocationsDTO> { new AdminLocationsDTO { LocationId = 1, Name = "Location1" ,ResourceId="KLAN"} }).AsEnumerable() };
            _mockLocationService
                .Setup(service => service.GetLocations())
                .ReturnsAsync(locations);

            // Act
            var result = await _controller.GetAllLocations();

            // Assert
            result.Should().BeOfType<OkObjectResult>();
            var okResult = result as OkObjectResult;
            okResult?.Value.Should().BeEquivalentTo(locations);
        }

        [Fact]
        public async Task GetAllLocations_ShouldReturnOk_WithEmptyList_WhenNoLocationsExist()
        {
            // Arrange
            var verifyStatus = new GenericResponse<string> { HasError = false, IsSuccess = true };
            var mockHttpContext = new DefaultHttpContext();
            mockHttpContext.Request.Headers["RegionCode"] = "MYS";
            _controller.ControllerContext = new Microsoft.AspNetCore.Mvc.ControllerContext
            {
                HttpContext = mockHttpContext
            };

            _mockRegionCodeValidationHelper
                .Setup(x => x.VerifyRegionCodeHeader(It.IsAny<HttpRequest>())).Returns(verifyStatus);

            var locations = new GenericResponseList<AdminLocationsDTO>
            {
                IsSuccess = true,
                Results = (new List<AdminLocationsDTO>()
            {
                new AdminLocationsDTO
                {
                    LocationId = 1,
                    ResourceId ="KLAN",
                    Name = "Location1",
                    Address = "123 Test Street",
                    City = "Test City",
                    State = "Test State",
                    PostalCode = "12345",
                    Country = "Test Country",
                    PhoneNumber = "1234567890",
                    Active = true,
                    DateCreated = DateTime.UtcNow,
                    CreatedBy = "Admin",
                    LastModifiedBy = 2,
                    LastModifiedDate = DateTime.UtcNow,
                    Identifier = "LOC-001",
                    Status = "Active",
                    Description = "This is a test location",
                    LocationType = "Clinic",
                    PhysicalType = "Building",
                    AddressLine1 = "123 Test Street",
                    AddressLine2 = "Suite 101",
                    Latitude = 40.7128,
                    Longitude = -74.0060,
                    Altitude = 10,
                    ManagingOrganizationId = 100,
                    PartOfLocationId = null,
                    Mode = "Online",
                    FloorMap = "Map1",
                    CreatedAt = DateTime.UtcNow.AddMonths(-1),
                    UpdatedAt = DateTime.UtcNow,
                }}
                ).AsEnumerable()
            };
            _mockLocationService
                .Setup(service => service.GetLocations())
                .ReturnsAsync(locations);

            // Act
            var result = await _controller.GetAllLocations();

            // Assert
            result.Should().BeOfType<OkObjectResult>();
            var okResult = result as OkObjectResult;
            okResult?.Value.Should().BeEquivalentTo(locations);
        }

        [Fact]
        public async Task GetAllLocations_ShouldReturnOk_WithEmptyList_WhenLocationsExist()
        {
            // Arrange
            var verifyStatus = new GenericResponse<string> { HasError = false, IsSuccess = true };
            var mockHttpContext = new DefaultHttpContext();
            mockHttpContext.Request.Headers["RegionCode"] = "MYS";
            _controller.ControllerContext = new Microsoft.AspNetCore.Mvc.ControllerContext
            {
                HttpContext = mockHttpContext
            };

            _mockRegionCodeValidationHelper
                .Setup(x => x.VerifyRegionCodeHeader(It.IsAny<HttpRequest>())).Returns(verifyStatus);

            var locations = new GenericResponseList<AdminLocationsDTO> { IsSuccess = true, Results = null };
            _mockLocationService
                .Setup(service => service.GetLocations())
                .ReturnsAsync(locations);

            // Act
            var result = await _controller.GetAllLocations();

            // Assert
            result.Should().BeOfType<OkObjectResult>();
            var okResult = result as OkObjectResult;
            okResult?.Value.Should().BeEquivalentTo(locations);
        }

        //Get Location By Id
        [Fact]
        public async Task GetLocationById_ShouldReturnBadRequest_WhenRegionCodeValidationFails()
        {
            // Arrange
            var verifyStatus = new GenericResponse<string> { HasError = true, IsSuccess = false };
            var mockHttpContext = new DefaultHttpContext();
            mockHttpContext.Request.Headers["RegionCode"] = "MYS";
            _controller.ControllerContext = new Microsoft.AspNetCore.Mvc.ControllerContext
            {
                HttpContext = mockHttpContext
            };

            _mockRegionCodeValidationHelper
                .Setup(x => x.VerifyRegionCodeHeader(It.IsAny<HttpRequest>())).Returns(verifyStatus);

            var locationId = 1;

            // Act
            var result = await _controller.GetLocationById(locationId);

            // Assert
            result.Should().BeOfType<BadRequestObjectResult>();
            var badRequestResult = result as BadRequestObjectResult;
            badRequestResult?.Value.Should().BeEquivalentTo(verifyStatus);
        }

        [Fact]
        public async Task GetLocationById_ShouldReturnNotFound_WhenLocationDoesNotExist()
        {
            // Arrange
            var verifyStatus = new GenericResponse<string> { HasError = false, IsSuccess = true };
            var mockHttpContext = new DefaultHttpContext();
            mockHttpContext.Request.Headers["RegionCode"] = "MYS";
            _controller.ControllerContext = new Microsoft.AspNetCore.Mvc.ControllerContext
            {
                HttpContext = mockHttpContext
            };

            _mockRegionCodeValidationHelper
                .Setup(x => x.VerifyRegionCodeHeader(It.IsAny<HttpRequest>())).Returns(verifyStatus);

            var locationId = 1;
            var location = new GenericResponse<AdminLocationsDTO> { IsSuccess = false, Result = null };

            _mockLocationService
                .Setup(service => service.GetLocationById(locationId))
                .ReturnsAsync(location);

            // Act
            var result = await _controller.GetLocationById(locationId);

            // Assert
            result.Should().BeOfType<OkObjectResult>();
            var okResult = result as OkObjectResult;
            okResult?.Value.Should().BeEquivalentTo(location);
        }

        [Fact]
        public async Task AddLocation_ShouldReturnBadRequest_WhenVerifyRegionCodeHeaderReturnsError()
        {
            // Arrange
            var verifyStatus = new GenericResponse<string> { HasError = true, IsSuccess = false };
            var mockHttpContext = new DefaultHttpContext();
            mockHttpContext.Request.Headers["RegionCode"] = "MYS";
            _controller.ControllerContext = new Microsoft.AspNetCore.Mvc.ControllerContext
            {
                HttpContext = mockHttpContext
            };

            _mockRegionCodeValidationHelper
                .Setup(x => x.VerifyRegionCodeHeader(It.IsAny<HttpRequest>())).Returns(verifyStatus);

            var request = new AdminLocationsRequest { Name = "Test Location", Address = "Test Address", Active = true };

            // Act
            var result = await _controller.AddLocation(request);

            // Assert
            result.Should().BeOfType<BadRequestObjectResult>();
            var badRequestResult = result as BadRequestObjectResult;
            badRequestResult?.Value.Should().BeEquivalentTo(verifyStatus);
        }

        [Fact]
        public async Task AddLocation_ShouldReturnBadRequest_WhenModelStateIsInvalid()
        {
            // Arrange
            var verifyStatus = new GenericResponse<string> { HasError = false, IsSuccess = true };
            var mockHttpContext = new DefaultHttpContext();
            mockHttpContext.Request.Headers["RegionCode"] = "MYS";
            _controller.ControllerContext = new Microsoft.AspNetCore.Mvc.ControllerContext
            {
                HttpContext = mockHttpContext
            };

            _mockRegionCodeValidationHelper
                .Setup(x => x.VerifyRegionCodeHeader(It.IsAny<HttpRequest>())).Returns(verifyStatus);

            _controller.ModelState.AddModelError("ServiceDeliveryLocationRoleTypeCode", "The ServiceDeliveryLocationRoleTypeCode field is required.");

            var request = new AdminLocationsRequest { Address = "Test Address", Active = true }; // Missing ServiceDeliveryLocationRoleTypeCode field

            // Act
            var result = await _controller.AddLocation(request);

            // Assert
            result.Should().BeOfType<BadRequestObjectResult>();
            var badRequestResult = result as BadRequestObjectResult;

            // Validate the structure of ModelState
            var modelState = badRequestResult?.Value as SerializableError;
            modelState.Should().NotBeNull();
            modelState.Should().ContainKey("ServiceDeliveryLocationRoleTypeCode");
            modelState?["ServiceDeliveryLocationRoleTypeCode"].Should().BeAssignableTo<string[]>();
        }

        [Fact]
        public async Task AddLocation_ShouldReturnOk_WhenRegionCodeIsValidAndModelStateIsValid()
        {
            // Arrange
            var verifyStatus = new GenericResponse<string> { HasError = false, IsSuccess = true };
            var mockHttpContext = new DefaultHttpContext();
            mockHttpContext.Request.Headers["RegionCode"] = "MYS";
            _controller.ControllerContext = new Microsoft.AspNetCore.Mvc.ControllerContext
            {
                HttpContext = mockHttpContext
            };

            _mockRegionCodeValidationHelper
                .Setup(x => x.VerifyRegionCodeHeader(It.IsAny<HttpRequest>())).Returns(verifyStatus);

            var request = new AdminLocationsRequest { Name = "Test Location", Address = "Test Address", Active = true };

            var addLocationResponse = new GenericResponse<string> { IsSuccess = true, Result = "1" };
            _mockLocationService
                .Setup(service => service.AddLocation(request))
                .ReturnsAsync(addLocationResponse);

            // Act
            var result = await _controller.AddLocation(request);

            // Assert
            result.Should().BeOfType<OkObjectResult>();
            var okResult = result as OkObjectResult;
            okResult?.Value.Should().BeEquivalentTo(addLocationResponse);
        }

        //AddLocationDetails

        public static CreateLocationDetailDto GetMockLocationDetailDto()
        {
            return new CreateLocationDetailDto
            {
                LocationDetailInformation = new CreateLocationDetailInformationDto
                {
                    Name = "Test Location",
                    ResourceID = "12345",
                    Status = true
                },
                LocationDetailAddress = new CreateLocationDetailAddressDto
                {
                    Type = "Office",
                    Country = "Test Country",
                    State = "Test State",
                    City = "Test City",
                    Line1 = "123 Main St",
                    PostalCode = "12345"
                },
                LocationDetailTelecom = new CreateLocationDetailTelecomDto
                {
                    Value = "123-456-7890",
                },
                LocationDetailImages = new List<CreateLocationDetailImageDto>
                {
                    new CreateLocationDetailImageDto
                    {
                        Category = "Building",
                        FloorName = "Ground",
                        BuildingName = "Test Building",
                        URL = "http://example.com/image.jpg"
                    }
                }
            };
        }

        [Fact]
        public async Task AddLocationDetails_ShouldReturnBadRequest_WhenVerifyRegionCodeHeaderReturnsError()
        {
            // Arrange
            var verifyStatus = new GenericResponse<string> { HasError = true, IsSuccess = false };
            var mockHttpContext = new DefaultHttpContext();
            mockHttpContext.Request.Headers["RegionCode"] = "MYS";
            _controller.ControllerContext = new Microsoft.AspNetCore.Mvc.ControllerContext
            {
                HttpContext = mockHttpContext
            };

            _mockRegionCodeValidationHelper
                .Setup(x => x.VerifyRegionCodeHeader(It.IsAny<HttpRequest>())).Returns(verifyStatus);

            // Use the helper method to get the mocked request
            var request = GetMockLocationDetailDto();

            // Act
            var result = await _controller.AddLocationDetails(request);

            // Assert
            result.Should().BeOfType<BadRequestObjectResult>();
            var badRequestResult = result as BadRequestObjectResult;
            badRequestResult?.Value.Should().BeEquivalentTo(verifyStatus);
        }

        [Fact]
        public async Task AddLocationDetails_ShouldReturnBadRequest_WhenModelStateIsInvalid()
        {
            // Arrange
            var verifyStatus = new GenericResponse<string> { HasError = false, IsSuccess = true };
            var mockHttpContext = new DefaultHttpContext();
            mockHttpContext.Request.Headers["RegionCode"] = "MYS";
            _controller.ControllerContext = new Microsoft.AspNetCore.Mvc.ControllerContext
            {
                HttpContext = mockHttpContext
            };

            _mockRegionCodeValidationHelper
                .Setup(x => x.VerifyRegionCodeHeader(It.IsAny<HttpRequest>())).Returns(verifyStatus);

            _controller.ModelState.AddModelError("ServiceDeliveryLocationRoleTypeCode", "The ServiceDeliveryLocationRoleTypeCode field is required.");

            var request = GetMockLocationDetailDto();

            // Act
            var result = await _controller.AddLocationDetails(request);

            // Assert
            result.Should().BeOfType<BadRequestObjectResult>();
            var badRequestResult = result as BadRequestObjectResult;

            // Validate the structure of ModelState
            var modelState = badRequestResult?.Value as SerializableError;
            modelState.Should().NotBeNull();
            modelState.Should().ContainKey("ServiceDeliveryLocationRoleTypeCode");
            modelState?["ServiceDeliveryLocationRoleTypeCode"].Should().BeAssignableTo<string[]>();
        }

        [Fact]
        public async Task AddLocationDetails_ShouldReturnOk_WhenRegionCodeIsValidAndModelStateIsValid()
        {
            var verifyStatus = new GenericResponse<string> { HasError = false, IsSuccess = true };
            var mockHttpContext = new DefaultHttpContext();
            mockHttpContext.Request.Headers["RegionCode"] = "MYS";
            _controller.ControllerContext = new Microsoft.AspNetCore.Mvc.ControllerContext
            {
                HttpContext = mockHttpContext
            };

            _mockRegionCodeValidationHelper
                .Setup(x => x.VerifyRegionCodeHeader(It.IsAny<HttpRequest>())).Returns(verifyStatus);

            var request = GetMockLocationDetailDto();

            var genericResponse = new GenericResponse<CreateLocationDetailDto>
            {
                IsSuccess = true,
                HasError = false,
                Result = request,
                Message = Resource.RecordInsertionMessage,
            };

            _mockLocationCommandService
                .Setup(service => service.CreateLocationDetailAsync(It.IsAny<CreateLocationDetailDto>()))
                .ReturnsAsync(genericResponse);

            var result = await _controller.AddLocationDetails(request);

            result.Should().BeOfType<OkObjectResult>();
            var okResult = result as OkObjectResult;
            okResult?.Value.Should().BeEquivalentTo(genericResponse);
        }

        [Fact]
        public async Task AddLocationDetails_ShouldReturnBadRequest_WhenCreateLocationFails()
        {
            var verifyStatus = new GenericResponse<string>
            {
                HasError = false,
                IsSuccess = true
            };

            var mockHttpContext = new DefaultHttpContext();
            mockHttpContext.Request.Headers["RegionCode"] = "MYS";
            _controller.ControllerContext = new Microsoft.AspNetCore.Mvc.ControllerContext
            {
                HttpContext = mockHttpContext
            };

            _mockRegionCodeValidationHelper
                .Setup(x => x.VerifyRegionCodeHeader(It.IsAny<HttpRequest>())).Returns(verifyStatus);

            var request = GetMockLocationDetailDto();

            var genericResponse = new GenericResponse<CreateLocationDetailDto>
            {
                IsSuccess = false,
                HasError = true,
                Message = Resource.RecordInsertionFailureMessage,
            };

            _mockLocationCommandService
                .Setup(service => service.CreateLocationDetailAsync(It.IsAny<CreateLocationDetailDto>()))
                .ReturnsAsync(genericResponse);

            var result = await _controller.AddLocationDetails(request);

            result.Should().BeOfType<BadRequestObjectResult>();
            var badRequestResult = result as BadRequestObjectResult;
            badRequestResult?.Value.Should().BeEquivalentTo(genericResponse);
        }

        //Update Location Details
        public static UpdateLocationDetailDto GetMockUpdateLocationDetailDto()
        {
            // Initialize LocationDetailInformation
            var locationDetailInformation = new UpdateLocationDetailInformationDto
            {
                Id = 1,
                Name = "Updated Location",
                ResourceID = "67890",
                Status = false,
                RecordVersion = Array.Empty<byte>()
            };

            // Initialize LocationDetailAddress
            var locationDetailAddress = new UpdateLocationDetailAddressDto
            {
                Id = 1,
                Type = "Warehouse",
                Country = "Updated Country",
                State = "Updated State",
                City = "Updated City",
                Line1 = "456 Elm St",
                PostalCode = "67890",
                RecordVersion = Array.Empty<byte>()
            };

            // Initialize LocationDetailTelecom
            var locationDetailTelecom = new UpdateLocationDetailTelecomDto
            {
                Id = 1,
                Value = "updated@example.com",
                RecordVersion = Array.Empty<byte>()
            };

            // Initialize LocationDetailImages
            var locationDetailImages = new List<UpdateLocationDetailImageDto>
            {
                new UpdateLocationDetailImageDto
                {
                    Category = "FloorPlan",
                    FloorName = "First",
                    BuildingName = "Updated Building",
                    URL = "http://example.com/updated_image.jpg",
                    RecordVersion = Array.Empty<byte>()
                }
            };

            // Return the final object
            return new UpdateLocationDetailDto
            {
                LocationDetailInformation = locationDetailInformation,
                LocationDetailAddress = locationDetailAddress,
                LocationDetailTelecom = locationDetailTelecom,
                LocationDetailImages = locationDetailImages
            };
        }

        [Fact]
        public async Task UpdateLocationDetails_ShouldReturnBadRequest_WhenVerifyRegionCodeHeaderReturnsError()
        {
            // Arrange
            var verifyStatus = new GenericResponse<string> { HasError = true, IsSuccess = false };
            var mockHttpContext = new DefaultHttpContext();
            mockHttpContext.Request.Headers["RegionCode"] = "MYS";
            _controller.ControllerContext = new Microsoft.AspNetCore.Mvc.ControllerContext
            {
                HttpContext = mockHttpContext
            };

            _mockRegionCodeValidationHelper
                .Setup(x => x.VerifyRegionCodeHeader(It.IsAny<HttpRequest>())).Returns(verifyStatus);

            var request = GetMockUpdateLocationDetailDto();

            // Act
            var result = await _controller.UpdateLocationDetails(request);

            // Assert
            result.Should().BeOfType<BadRequestObjectResult>();
            var badRequestResult = result as BadRequestObjectResult;
            badRequestResult?.Value.Should().BeEquivalentTo(verifyStatus);
        }

        [Fact]
        public async Task UpdateLocationDetails_ShouldReturnBadRequest_WhenModelStateIsInvalid()
        {
            // Arrange
            var verifyStatus = new GenericResponse<string> { HasError = false, IsSuccess = true };
            var mockHttpContext = new DefaultHttpContext();
            mockHttpContext.Request.Headers["RegionCode"] = "MYS";
            _controller.ControllerContext = new Microsoft.AspNetCore.Mvc.ControllerContext
            {
                HttpContext = mockHttpContext
            };

            _mockRegionCodeValidationHelper
                .Setup(x => x.VerifyRegionCodeHeader(It.IsAny<HttpRequest>())).Returns(verifyStatus);

            _controller.ModelState.AddModelError("LocationDetailInformation.Id", "The Id field is required.");

            var request = GetMockUpdateLocationDetailDto();

            // Act
            var result = await _controller.UpdateLocationDetails(request);

            // Assert
            result.Should().BeOfType<BadRequestObjectResult>();
            var badRequestResult = result as BadRequestObjectResult;

            // Validate the structure of ModelState
            var modelState = badRequestResult?.Value as SerializableError;
            modelState.Should().NotBeNull();
            modelState.Should().ContainKey("LocationDetailInformation.Id");
            modelState?["LocationDetailInformation.Id"].Should().BeAssignableTo<string[]>();
        }

        [Fact]
        public async Task UpdateLocationDetails_ShouldReturnOk_WhenLocationIdIsInvalid()
        {
            // Arrange
            var verifyStatus = new GenericResponse<string> { HasError = false, IsSuccess = true };
            var mockHttpContext = new DefaultHttpContext();
            mockHttpContext.Request.Headers["RegionCode"] = "MYS";
            _controller.ControllerContext = new Microsoft.AspNetCore.Mvc.ControllerContext
            {
                HttpContext = mockHttpContext
            };

            _mockRegionCodeValidationHelper
                .Setup(x => x.VerifyRegionCodeHeader(It.IsAny<HttpRequest>())).Returns(verifyStatus);

            var request = GetMockUpdateLocationDetailDto();

            _mockLocationQueryService
                .Setup(x => x.FindLocationById(It.IsAny<int>()))
                .ReturnsAsync(default(Domain.V1.Entities.Locations.Location));

            // Act
            var result = await _controller.UpdateLocationDetails(request);

            // Assert
            result.Should().BeOfType<OkObjectResult>();
            var okResult = result as OkObjectResult;
            var dataResponse = okResult?.Value as GenericResponse<string>;
            dataResponse?.HasError.Should().BeTrue();
            dataResponse?.Message.Should().Be("Invalid location Id");
        }

        [Fact]
        public async Task UpdateLocationDetails_ShouldReturnOk_WhenLocationAddressIdIsInvalid()
        {
            // Arrange
            var verifyStatus = new GenericResponse<string> { HasError = false, IsSuccess = true };
            var mockHttpContext = new DefaultHttpContext();
            mockHttpContext.Request.Headers["RegionCode"] = "MYS";
            _controller.ControllerContext = new Microsoft.AspNetCore.Mvc.ControllerContext
            {
                HttpContext = mockHttpContext
            };

            _mockRegionCodeValidationHelper
                .Setup(x => x.VerifyRegionCodeHeader(It.IsAny<HttpRequest>())).Returns(verifyStatus);

            var request = new UpdateLocationDetailDto
            {
                LocationDetailInformation = new UpdateLocationDetailInformationDto { Id = 1, Name = "location1", ResourceID = "someResourceId", Status = true },
                LocationDetailAddress = new UpdateLocationDetailAddressDto { Id = 1 }, // Invalid address ID
                LocationDetailTelecom = new UpdateLocationDetailTelecomDto { Id = 1, Value = "value" }, // Invalid telecom ID
                LocationDetailImages = new List<UpdateLocationDetailImageDto>() // Initialize with an empty list or with data if needed

            };

            _mockLocationQueryService
                .Setup(x => x.FindLocationById(It.IsAny<long>()))
                .ReturnsAsync(new Domain.V1.Entities.Locations.Location { Id = 1, Name = "location1", ResourceID = "someResourceId", PartOf = "partOf", UpdatedBy = "testUser", Status = true, CreatedBy = "testUser", CreatedDate = DateTime.UtcNow, IsDeleted = false, });

            _mockLocationAddressQueryService
                .Setup(x => x.FindLocationAddressById(It.IsAny<int>()))
                .ReturnsAsync(default(LocationAddress));

            // Act
            var result = await _controller.UpdateLocationDetails(request);

            // Assert
            result.Should().BeOfType<OkObjectResult>();
            var okResult = result as OkObjectResult;
            var dataResponse = okResult?.Value as GenericResponse<string>;
            dataResponse?.HasError.Should().BeTrue();
            dataResponse?.Message.Should().Be("Invalid location address Id");
        }

        [Fact]
        public async Task UpdateLocationDetails_ShouldReturnOk_WhenLocationTelecomIdIsInvalid()
        {
            // Arrange
            var verifyStatus = new GenericResponse<string> { HasError = false, IsSuccess = true };
            var mockHttpContext = new DefaultHttpContext();
            mockHttpContext.Request.Headers["RegionCode"] = "MYS";
            _controller.ControllerContext = new Microsoft.AspNetCore.Mvc.ControllerContext
            {
                HttpContext = mockHttpContext
            };

            _mockRegionCodeValidationHelper
                .Setup(x => x.VerifyRegionCodeHeader(It.IsAny<HttpRequest>())).Returns(verifyStatus);

            var request = new UpdateLocationDetailDto
            {
                LocationDetailInformation = new UpdateLocationDetailInformationDto { Id = 1, Name = "location1", ResourceID = "someResourceId", Status = true },
                LocationDetailAddress = new UpdateLocationDetailAddressDto { Id = 1, },
                LocationDetailTelecom = new UpdateLocationDetailTelecomDto { Id = 1, Value = "value" }, // Invalid telecom ID
                LocationDetailImages = new List<UpdateLocationDetailImageDto>() // Initialize with an empty list or with data if needed
            };
            _mockLocationQueryService
                .Setup(x => x.FindLocationById(It.IsAny<long>()))
                .ReturnsAsync(new Domain.V1.Entities.Locations.Location { Id = 1, Name = "location1", ResourceID = "someResourceId", PartOf = "partOf", UpdatedBy = "testUser", Status = true, CreatedBy = "testUser", CreatedDate = DateTime.UtcNow, IsDeleted = false, });

            _mockLocationAddressQueryService
                .Setup(x => x.FindLocationAddressById(It.IsAny<long>()))
                .ReturnsAsync(new LocationAddress { Id = 1, Use = "Use1", LocationID = 1, Status = true, CreatedBy = "testUser", CreatedDate = DateTime.UtcNow, IsDeleted = false });

            _mockLocationTelecomQueryService
                .Setup(x => x.FindLocationTelecomById(It.IsAny<int>()))
                .ReturnsAsync(default(LocationTelecom));

            // Act
            var result = await _controller.UpdateLocationDetails(request);

            // Assert
            result.Should().BeOfType<OkObjectResult>();
            var okResult = result as OkObjectResult;
            var dataResponse = okResult?.Value as GenericResponse<string>;
            dataResponse?.HasError.Should().BeTrue();
            dataResponse?.Message.Should().Be("Invalid location telecom Id");
        }

        [Fact]
        public async Task UpdateLocationDetails_ShouldReturnOk_WhenUpdateIsSuccessful()
        {
            // Arrange
            var verifyStatus = new GenericResponse<string> { HasError = false, IsSuccess = true };
            var mockHttpContext = new DefaultHttpContext();
            mockHttpContext.Request.Headers["RegionCode"] = "MYS";
            _controller.ControllerContext = new Microsoft.AspNetCore.Mvc.ControllerContext
            {
                HttpContext = mockHttpContext
            };

            _mockRegionCodeValidationHelper
                .Setup(x => x.VerifyRegionCodeHeader(It.IsAny<HttpRequest>())).Returns(verifyStatus);
            var request = new UpdateLocationDetailDto
            {
                LocationDetailInformation = new UpdateLocationDetailInformationDto
                {
                    Id = 1, // Valid location ID
                    Name = "Updated Location",
                    ResourceID = "updatedResourceId",
                    Status = true
                },
                LocationDetailAddress = new UpdateLocationDetailAddressDto { Id = 1 }, // Valid address ID
                LocationDetailTelecom = new UpdateLocationDetailTelecomDto { Id = 1, Value = "updatedValue" },// Valid telecom ID
                LocationDetailImages = new List<UpdateLocationDetailImageDto>() // Initialize with an empty list or with data if needed
            };

            _mockLocationQueryService
                .Setup(x => x.FindLocationById(It.IsAny<long>()))
                .ReturnsAsync(new Domain.V1.Entities.Locations.Location { Id = 1, Name = "location1", ResourceID = "someResourceId", PartOf = "partOf", UpdatedBy = "testUser", Status = true, CreatedBy = "testUser", CreatedDate = DateTime.UtcNow, IsDeleted = false });

            _mockLocationAddressQueryService
                .Setup(x => x.FindLocationAddressById(It.IsAny<long>()))
                .ReturnsAsync(new LocationAddress { Id = 1, Use = "Use1", LocationID = 1, Status = true, CreatedBy = "testUser", CreatedDate = DateTime.UtcNow, IsDeleted = false });

            _mockLocationTelecomQueryService
                .Setup(x => x.FindLocationTelecomById(It.IsAny<long>()))
                .ReturnsAsync(new LocationTelecom { Id = 1, LocationID = 1, System = "system", Use = "use", Value = "value", CreatedBy = "testUser", CreatedDate = DateTime.UtcNow, IsDeleted = false });

            // Mock the command service to return a successful result
            _mockLocationCommandService
                .Setup(x => x.UpdateLocationDetailAsync(It.IsAny<UpdateLocationDetailDto>(), It.IsAny<Domain.V1.Entities.Locations.Location>(), It.IsAny<LocationAddress>(), It.IsAny<LocationTelecom>()))
                .ReturnsAsync(new GenericResponse<UpdateLocationDetailDto> { IsSuccess = true, Message = "Location details updated successfully" });

            // Act
            var result = await _controller.UpdateLocationDetails(request);

            // Assert
            result.Should().BeOfType<OkObjectResult>();
            var okResult = result as OkObjectResult;
            var dataResponse = okResult?.Value as GenericResponse<UpdateLocationDetailDto>;
            dataResponse?.IsSuccess.Should().BeTrue();
            dataResponse?.Message.Should().Be("Location details updated successfully");
        }

        //Update Location
        [Fact]
        public async Task UpdateLocation_ShouldReturnBadRequest_WhenVerifyRegionCodeHeaderReturnsError()
        {
            // Arrange
            var verifyStatus = new GenericResponse<string> { HasError = true, IsSuccess = false };
            var mockHttpContext = new DefaultHttpContext();
            mockHttpContext.Request.Headers["RegionCode"] = "MYSS";
            _controller.ControllerContext = new Microsoft.AspNetCore.Mvc.ControllerContext
            {
                HttpContext = mockHttpContext
            };

            _mockRegionCodeValidationHelper
                .Setup(x => x.VerifyRegionCodeHeader(It.IsAny<HttpRequest>())).Returns(verifyStatus);

            var request = new AdminLocationsRequest { LocationId = 1, Name = "Updated Location", Address = "Updated Address", Active = true };

            // Act
            var result = await _controller.UpdateLocation(request);

            // Assert
            result.Should().BeOfType<BadRequestObjectResult>();
            var badRequestResult = result as BadRequestObjectResult;
            badRequestResult?.Value.Should().BeEquivalentTo(verifyStatus);
        }

        [Fact]
        public async Task UpdateLocation_ShouldReturnBadRequest_WhenModelStateIsInvalid()
        {
            // Arrange
            var verifyStatus = new GenericResponse<string> { HasError = false, IsSuccess = true };
            var mockHttpContext = new DefaultHttpContext();
            mockHttpContext.Request.Headers["RegionCode"] = "MYS";
            _controller.ControllerContext = new Microsoft.AspNetCore.Mvc.ControllerContext
            {
                HttpContext = mockHttpContext
            };

            _mockRegionCodeValidationHelper
                .Setup(x => x.VerifyRegionCodeHeader(It.IsAny<HttpRequest>())).Returns(verifyStatus);

            _controller.ModelState.AddModelError("ServiceDeliveryLocationRoleTypeCode", "The ServiceDeliveryLocationRoleTypeCode field is required.");

            var request = new AdminLocationsRequest { LocationId = 1, Address = "Updated Address", Active = true }; // Missing ServiceDeliveryLocationRoleTypeCode

            // Act
            var result = await _controller.UpdateLocation(request);

            // Assert
            result.Should().BeOfType<BadRequestObjectResult>();
            var badRequestResult = result as BadRequestObjectResult;

            // Validate ModelState structure
            var modelState = badRequestResult?.Value as SerializableError;
            modelState.Should().NotBeNull();
            modelState.Should().ContainKey("ServiceDeliveryLocationRoleTypeCode");
            modelState?["ServiceDeliveryLocationRoleTypeCode"].Should().BeAssignableTo<string[]>();
        }

        [Fact]
        public async Task UpdateLocation_ShouldReturnOk_WhenRegionCodeAndModelStateAreValid()
        {
            // Arrange
            var verifyStatus = new GenericResponse<string> { HasError = false, IsSuccess = true };
            var mockHttpContext = new DefaultHttpContext();
            mockHttpContext.Request.Headers["RegionCode"] = "MYS";
            _controller.ControllerContext = new Microsoft.AspNetCore.Mvc.ControllerContext
            {
                HttpContext = mockHttpContext
            };

            _mockRegionCodeValidationHelper
                .Setup(x => x.VerifyRegionCodeHeader(It.IsAny<HttpRequest>())).Returns(verifyStatus);

            var request = new AdminLocationsRequest { LocationId = 1, Name = "Updated Location", Address = "Updated Address", Active = true };

            var updateResponse = new GenericResponse<string> { IsSuccess = true, HasError = false };
            _mockLocationService
                .Setup(service => service.UpdateLocation(request))
                .ReturnsAsync(updateResponse);

            // Act
            var result = await _controller.UpdateLocation(request);

            // Assert
            result.Should().BeOfType<OkObjectResult>();
            var okResult = result as OkObjectResult;
            okResult?.Value.Should().BeEquivalentTo(updateResponse);
        }

        [Fact]
        public async Task GetAllHospitals_ShouldReturnBadRequest_WhenRegionCodeValidationFails()
        {
            // Arrange
            var errorResult = new GenericResponse<string> { HasError = true, IsSuccess = false };
            _mockRegionCodeValidationHelper
                .Setup(helper => helper.VerifyRegionCodeHeader(It.IsAny<HttpRequest>()))
                .Returns(errorResult);

            // Act
            var result = await _controller.GetOurHospitals();

            // Assert
            result.Should().BeOfType<BadRequestObjectResult>();
            var badRequestResult = result as BadRequestObjectResult;
            badRequestResult?.Value.Should().BeEquivalentTo(errorResult);
        }

        [Fact]
        public async Task GetAllHospitals_ShouldReturnBadRequest_WhenRegionCodeIsMissing()
        {
            // Arrange
            var errorResult = new GenericResponse<string> { HasError = true, IsSuccess = false };
            var mockHttpContext = new DefaultHttpContext();
            _controller.ControllerContext = new ControllerContext
            {
                HttpContext = mockHttpContext
            };

            _mockRegionCodeValidationHelper
                .Setup(helper => helper.VerifyRegionCodeHeader(It.IsAny<HttpRequest>()))
                .Returns(errorResult);

            // Act
            var result = await _controller.GetOurHospitals();

            // Assert
            result.Should().BeOfType<BadRequestObjectResult>();
            var badRequestResult = result as BadRequestObjectResult;
            badRequestResult?.Value.Should().BeEquivalentTo(errorResult);
        }

        [Fact]
        public async Task GetAllHospitals_ShouldReturnOk_WithHospitalsGroupedByState_WhenRegionCodeIsValid()
        {
            // Arrange
            var verifyStatus = new GenericResponse<string> { HasError = false, IsSuccess = true };
            var mockHttpContext = new DefaultHttpContext();
            mockHttpContext.Request.Headers["RegionCode"] = "MYS";
            _controller.ControllerContext = new Microsoft.AspNetCore.Mvc.ControllerContext
            {
                HttpContext = mockHttpContext
            };

            _mockRegionCodeValidationHelper
                .Setup(x => x.VerifyRegionCodeHeader(It.IsAny<HttpRequest>())).Returns(verifyStatus);

            var hospitals = new GenericResponseList<GetHospitalDto>
            {
                Results = new List<GetHospitalDto>() {new GetHospitalDto
                {
                    State = "State1",
                    Hospitals = new List<HospitalDto>
                    {
                        new HospitalDto { Id = 1, Name = "Hospital1", City = "Test City", PhoneNumber = "1234567890" },
                        new HospitalDto { Id = 2, Name = "Hospital2", City = "Test City", PhoneNumber = "1234567890" }
                    }
                },
                new GetHospitalDto
                {
                    State = "State2",
                    Hospitals = new List<HospitalDto>
                    {
                        new HospitalDto { Id = 3, Name = "Hospital3", City = "Test City", PhoneNumber = "9876543210" }
                    }
                } }
            };

            _mockLocationQueryService
                .Setup(service => service.GetHospitalList())
                .Returns(hospitals);

            // Act
            var result = await _controller.GetOurHospitals();

            // Assert
            result.Should().BeOfType<OkObjectResult>();
            var okResult = result as OkObjectResult;

            var returnedHospitals = okResult?.Value as GenericResponseList<GetHospitalDto>;
            returnedHospitals.Should().NotBeNull();
            returnedHospitals?.Results.Should().HaveCount(2);

            var state1 = returnedHospitals?.Results?.FirstOrDefault(x => x.State == "State1");
            state1.Should().NotBeNull();
            state1?.Hospitals.Should().HaveCount(2);

            var state2 = returnedHospitals?.Results?.FirstOrDefault(x => x.State == "State2");
            state2.Should().NotBeNull();
            state2?.Hospitals.Should().HaveCount(1);
        }

        [Fact]
        public async Task GetAllHospitals_ShouldReturnOk_WithEmptyList_WhenNoHospitalsExist()
        {
            // Arrange
            var verifyStatus = new GenericResponse<string> { HasError = false, IsSuccess = true };
            var mockHttpContext = new DefaultHttpContext();
            mockHttpContext.Request.Headers["RegionCode"] = "MYS";
            _controller.ControllerContext = new Microsoft.AspNetCore.Mvc.ControllerContext
            {
                HttpContext = mockHttpContext
            };

            _mockRegionCodeValidationHelper
                .Setup(x => x.VerifyRegionCodeHeader(It.IsAny<HttpRequest>())).Returns(verifyStatus);
            var hospitals = new GenericResponseList<GetHospitalDto>(); // No hospitals
            _mockLocationQueryService
                .Setup(service => service.GetHospitalList())
                .Returns(hospitals);

            // Act
            var result = await _controller.GetOurHospitals();

            // Assert
            result.Should().BeOfType<OkObjectResult>();
            var okResult = result as OkObjectResult;
            okResult?.Value.Should().BeEquivalentTo(hospitals);
        }

        [Fact]
        public async Task GetAllHospitalsWithDistance_ShouldReturnBadRequest_WhenRegionCodeValidationFails()
        {
            // Arrange
            var errorResult = new GenericResponse<string> { HasError = true, IsSuccess = false };
            _mockRegionCodeValidationHelper
                .Setup(helper => helper.VerifyRegionCodeHeader(It.IsAny<HttpRequest>()))
                .Returns(errorResult);

            // Act
            var result = await _controller.GetAllHospitalWithDistance(10.0, 20.0);

            // Assert
            result.Should().BeOfType<BadRequestObjectResult>();
            var badRequestResult = result as BadRequestObjectResult;
            badRequestResult?.Value.Should().BeEquivalentTo(errorResult);
        }

        [Fact]
        public async Task GetAllHospitalsWithDistance_ShouldReturnBadRequest_WhenRegionCodeIsMissing()
        {
            // Arrange
            var errorResult = new GenericResponse<string> { HasError = true, IsSuccess = false };
            var mockHttpContext = new DefaultHttpContext();
            _controller.ControllerContext = new ControllerContext
            {
                HttpContext = mockHttpContext
            };

            _mockRegionCodeValidationHelper
                .Setup(helper => helper.VerifyRegionCodeHeader(It.IsAny<HttpRequest>()))
                .Returns(errorResult);

            // Act
            var result = await _controller.GetAllHospitalWithDistance(10.0, 20.0);

            // Assert
            result.Should().BeOfType<BadRequestObjectResult>();
            var badRequestResult = result as BadRequestObjectResult;
            badRequestResult?.Value.Should().BeEquivalentTo(errorResult);
        }

        [Fact]
        public async Task GetAllHospitalsWithDistance_ShouldReturnOk_WithHospitals_WhenRegionCodeIsValidAndCoordinatesProvided()
        {
            // Arrange
            var verifyStatus = new GenericResponse<string> { HasError = false, IsSuccess = true };
            var mockHttpContext = new DefaultHttpContext();
            mockHttpContext.Request.Headers["RegionCode"] = "MYS";
            _controller.ControllerContext = new Microsoft.AspNetCore.Mvc.ControllerContext
            {
                HttpContext = mockHttpContext
            };

            _mockRegionCodeValidationHelper
                .Setup(x => x.VerifyRegionCodeHeader(It.IsAny<HttpRequest>())).Returns(verifyStatus);

            var hospitals = new GenericResponseList<GetHospitalWithDistanceDto>()
            {
                Results = new List<GetHospitalWithDistanceDto>()
                {
                     new GetHospitalWithDistanceDto
                     {
                        State = "S1",
                        Hospitals = new List<HospitalWithDistanceDto>
                         {
                             new HospitalWithDistanceDto { Id = 1, Name = "Hospital1", City = "Test City", PhoneNumber = "1234567890", Distance = 0.12, ImageUrl = "Url1", Latitude = It.IsAny<decimal>(), Longitude = It.IsAny<decimal>(), LocationId = 1, State =  "S1", Url = "Url1"},
                             new HospitalWithDistanceDto { Id = 2, Name = "Hospital2", City = "Test City", PhoneNumber = "1234567890", Distance = 500.23, ImageUrl = "Url1", Latitude = It.IsAny<decimal>(), Longitude = It.IsAny<decimal>(), LocationId = 1, State =  "S1", Url = "Url1"},
                         }
                    }
                }
            };

            _mockLocationQueryService
                .Setup(service => service.GetHospitalListByDistance(It.IsAny<double>(), It.IsAny<double>(), true))
                .Returns(hospitals);

            // Act
            var result = await _controller.GetAllHospitalWithDistance(10.0, 20.0);

            // Assert
            result.Should().BeOfType<OkObjectResult>();
            var okResult = result as OkObjectResult;

            var returnedHospitals = okResult?.Value as GenericResponseList<GetHospitalWithDistanceDto>;
            returnedHospitals.Should().NotBeNull();
            returnedHospitals?.Results.Should().HaveCount(1);

            var state1 = returnedHospitals?.Results?.FirstOrDefault(x => x.State == "S1");
            state1.Should().NotBeNull();
            state1?.Hospitals.Should().HaveCount(2);
        }

        [Fact]
        public async Task GetAllHospitalsWithDistance_ShouldReturnOk_WithHospitals_WhenRegionCodeIsValidAndNoCoordinatesProvided()
        {
            // Arrange
            var verifyStatus = new GenericResponse<string> { HasError = false, IsSuccess = true };
            var mockHttpContext = new DefaultHttpContext();
            mockHttpContext.Request.Headers["RegionCode"] = "MYS";
            _controller.ControllerContext = new Microsoft.AspNetCore.Mvc.ControllerContext
            {
                HttpContext = mockHttpContext
            };

            _mockRegionCodeValidationHelper
                .Setup(x => x.VerifyRegionCodeHeader(It.IsAny<HttpRequest>())).Returns(verifyStatus);

            var hospitals = new GenericResponseList<GetHospitalWithDistanceDto>()
            {
                Results = new List<GetHospitalWithDistanceDto>()
                {
                    new GetHospitalWithDistanceDto()
            {
                State = "S1",
                Hospitals = new List<HospitalWithDistanceDto>
                {
                    new HospitalWithDistanceDto { Id = 1, Name = "Hospital1", City = "Test City", PhoneNumber = "1234567890", Distance = 0, ImageUrl = "Url1", Latitude = It.IsAny<decimal>(), Longitude = It.IsAny<decimal>(), LocationId = 1, State =  "S1", Url = "Url1"},
                    new HospitalWithDistanceDto { Id = 2, Name = "Hospital2", City = "Test City", PhoneNumber = "1234567890", Distance = 0, ImageUrl = "Url1", Latitude = It.IsAny<decimal>(), Longitude = It.IsAny<decimal>(), LocationId = 1, State =  "S1", Url = "Url1"},
                }
            }
                }
            };

            _mockLocationQueryService
                .Setup(service => service.GetHospitalListByDistance(It.IsAny<double>(), It.IsAny<double>(), false))
                .Returns(hospitals);

            // Act
            var result = await _controller.GetAllHospitalWithDistance(null, null);

            // Assert
            result.Should().BeOfType<OkObjectResult>();
            var okResult = result as OkObjectResult;

            var returnedHospitals = okResult?.Value as GenericResponseList<GetHospitalWithDistanceDto>;
            returnedHospitals.Should().NotBeNull();
            returnedHospitals?.Results.Should().HaveCount(1);

            var state1 = returnedHospitals?.Results?.FirstOrDefault(x => x.State == "S1");
            state1.Should().NotBeNull();
            state1?.Hospitals.Should().HaveCount(2);
        }

        [Fact]
        public async Task GetLocationTypeMaster_ShouldReturnOk_WhenRegionCodeIsValid()
        {
            // Arrange
            var regionCode = "MYS";
            var mockResponse = new GenericResponse<string>
            {
                IsSuccess = true,
                HasError = false,
                StatusCode = AdministrationService.CrossCutting.CommonModels.ResponseStatus.STATUS_SUCCESS,
                Message = null,
                Result = regionCode
            };

            var context = new DefaultHttpContext();
            var request = context.Request;
            request.Headers["RegionCode"] = regionCode;

            _mockRegionCodeValidationHelper.Setup(x => x.VerifyRegionCodeHeader(request))
                .Returns(mockResponse);

            var locations = new GenericResponseList<AdministrationService.API.Models.Dto.Locations.GetLocationTypeDto>
            {
                Results = new List<AdministrationService.API.Models.Dto.Locations.GetLocationTypeDto>() { new AdministrationService.API.Models.Dto.Locations.GetLocationTypeDto { Id = 1, Name = "Hospital A" } }
            };

            _mockLocationQueryService.Setup(x => x.GetLocationTypeMaster())
                .Returns(locations);

            // Act
            var result = await _controller.GetLocationTypeMaster();

            // Assert
            result.Should().BeOfType<OkObjectResult>();
        }

        [Fact]
        public async Task GetLocationTypeMaster_ShouldReturnNotFound_WhenNoLocationTypes()
        {
            // Arrange
            var mockedResponse = new GenericResponse<string>
            {
                IsSuccess = true,
                HasError = false,
                StatusCode = AdministrationService.CrossCutting.CommonModels.ResponseStatus.STATUS_SUCCESS,
                Message = string.Empty
            };
            var mockedNotFoundResponse = new GenericResponseList<AdministrationService.API.Models.Dto.Locations.GetLocationTypeDto>
            {
                HasError = false,
                IsSuccess = true,
                StatusCode = ResponceStatusCode.RecordNotFound.ToString(),
                Results = new List<AdministrationService.API.Models.Dto.Locations.GetLocationTypeDto>(),
            };

            _mockRegionCodeValidationHelper.Setup(x => x.VerifyRegionCodeHeader(It.IsAny<HttpRequest>()))
                .Returns(mockedResponse);

            _mockLocationQueryService.Setup(service => service.GetLocationTypeMaster())
               .Returns(mockedNotFoundResponse);

            // Act
            var result = await _controller.GetLocationTypeMaster();

            // Assert
            result.Should().BeOfType<NotFoundObjectResult>();
        }

        [Fact]
        public async Task GetLocationTypeMaster_ShouldReturnBadRequest_WhenRegionCodeIsInvalid()
        {
            // Arrange
            var mockedResponse = new GenericResponse<string>
            {
                IsSuccess = false,
                HasError = true,
                StatusCode = AdministrationService.CrossCutting.CommonModels.ResponseStatus.STATUS_BadRequest,
                Message = Resource.RegionCodeRequired
            };

            _mockRegionCodeValidationHelper.Setup(x => x.VerifyRegionCodeHeader(It.IsAny<HttpRequest>()))
                .Returns(mockedResponse);

            // Act
            var result = await _controller.GetLocationTypeMaster();

            // Assert
            result.Should().BeOfType<BadRequestObjectResult>();
        }

        [Fact]
        public async Task GetLocationPartOf_ShouldReturnOk_WhenRegionCodeIsValid()
        {
            // Arrange
            var regionCode = "MYS";
            var mockResponse = new GenericResponse<string>
            {
                IsSuccess = true,
                HasError = false,
                StatusCode = AdministrationService.CrossCutting.CommonModels.ResponseStatus.STATUS_SUCCESS,
                Message = null,
                Result = regionCode
            };

            var context = new DefaultHttpContext();
            var request = context.Request;
            request.Headers["RegionCode"] = regionCode;

            _mockRegionCodeValidationHelper.Setup(x => x.VerifyRegionCodeHeader(request))
                .Returns(mockResponse);

            var locations = new GenericResponseList<GetLocationPartOfDto>
            {
                Results = new List<GetLocationPartOfDto>() { new GetLocationPartOfDto { Id = 1, Name = "Location A", ResourceID = "Res1" } }
            };

            _mockLocationQueryService.Setup(x => x.GetLocationMastersList())
                .Returns(locations);

            // Act
            var result = await _controller.GetLocationMaster();

            // Assert
            result.Should().BeOfType<OkObjectResult>();
        }

        [Fact]
        public async Task GetLocationPartOf_ShouldReturnNotFound_WhenNoLocations()
        {
            // Arrange
            var mockedResponse = new GenericResponse<string>
            {
                IsSuccess = true,
                HasError = false,
                StatusCode = AdministrationService.CrossCutting.CommonModels.ResponseStatus.STATUS_SUCCESS,
                Message = string.Empty
            };
            var mockedNotFoundResponse = new GenericResponseList<GetLocationPartOfDto>
            {
                HasError = false,
                IsSuccess = true,
                StatusCode = ResponceStatusCode.RecordNotFound.ToString(),
                Results = new List<GetLocationPartOfDto>(),
            };

            _mockRegionCodeValidationHelper.Setup(x => x.VerifyRegionCodeHeader(It.IsAny<HttpRequest>()))
                .Returns(mockedResponse);

            _mockLocationQueryService.Setup(service => service.GetLocationMastersList())
               .Returns(mockedNotFoundResponse);

            // Act
            var result = await _controller.GetLocationMaster();

            // Assert
            result.Should().BeOfType<NotFoundObjectResult>();
        }

        [Fact]
        public async Task GetLocationPartOf_ShouldReturnBadRequest_WhenRegionCodeIsInvalid()
        {
            // Arrange
            var mockedResponse = new GenericResponse<string>
            {
                IsSuccess = false,
                HasError = true,
                StatusCode = AdministrationService.CrossCutting.CommonModels.ResponseStatus.STATUS_BadRequest,
                Message = Resource.RegionCodeRequired
            };

            _mockRegionCodeValidationHelper.Setup(x => x.VerifyRegionCodeHeader(It.IsAny<HttpRequest>()))
                .Returns(mockedResponse);

            // Act
            var result = await _controller.GetLocationMaster();

            // Assert
            result.Should().BeOfType<BadRequestObjectResult>();
        }

        #region LocationDetailById Controller unit tests

        [Fact]
        public async Task LocationDetailById_ShouldReturnOk_WhenRegionCodeIsValid()
        {
            // Arrange
            var regionCode = "MYS";
            var mockResponse = new GenericResponse<string>
            {
                IsSuccess = true,
                HasError = false,
                StatusCode = AdministrationService.CrossCutting.CommonModels.ResponseStatus.STATUS_SUCCESS,
                Message = null,
                Result = regionCode
            };

            var context = new DefaultHttpContext();
            var request = context.Request;
            request.Headers["RegionCode"] = regionCode;

            _mockRegionCodeValidationHelper.Setup(x => x.VerifyRegionCodeHeader(request))
                .Returns(mockResponse);

            var location = new GenericResponse<LocationEntity>
            {
                Result = new LocationEntity { Id = 5, ResourceID = "232", Name = "Bukit Jalil", Description = "Test", Status = true, CreatedBy = "admin", CreatedDate = DateTime.Now, IsDeleted = false }
            };

            _mockLocationQueryService.Setup(x => x.LocationDetailById(5))
                .ReturnsAsync(location);

            // Act
            var result = await _controller.GetLocationDetail(5);

            // Assert
            result.Should().BeOfType<OkObjectResult>();
        }

        [Fact]
        public async Task LocationDetailById_ShouldReturnNotFound_WhenNoLocations()
        {
            // Arrange
            var mockedResponse = new GenericResponse<string>
            {
                IsSuccess = true,
                HasError = false,
                StatusCode = AdministrationService.CrossCutting.CommonModels.ResponseStatus.STATUS_SUCCESS,
                Message = string.Empty
            };
            var mockedNotFoundResponse = new GenericResponse<LocationEntity>
            {
                HasError = false,
                IsSuccess = true,
                StatusCode = ResponceStatusCode.RecordNotFound.ToString(),
                Result = null
            };

            _mockRegionCodeValidationHelper.Setup(x => x.VerifyRegionCodeHeader(It.IsAny<HttpRequest>()))
                .Returns(mockedResponse);

            _mockLocationQueryService.Setup(service => service.LocationDetailById(5))
               .ReturnsAsync(mockedNotFoundResponse);

            // Act
            var result = await _controller.GetLocationDetail(5);

            // Assert
            result.Should().BeOfType<NotFoundObjectResult>();
        }

        [Fact]
        public async Task LocationDetailById_ShouldReturnBadRequest_WhenRegionCodeIsInvalid()
        {
            // Arrange
            var mockedResponse = new GenericResponse<string>
            {
                IsSuccess = false,
                HasError = true,
                StatusCode = AdministrationService.CrossCutting.CommonModels.ResponseStatus.STATUS_BadRequest,
                Message = Resource.RegionCodeRequired
            };

            _mockRegionCodeValidationHelper.Setup(x => x.VerifyRegionCodeHeader(It.IsAny<HttpRequest>()))
                .Returns(mockedResponse);

            // Act
            var result = await _controller.GetLocationDetail(5);

            // Assert
            result.Should().BeOfType<BadRequestObjectResult>();
        }

        #endregion


        [Fact]
        public async Task GetLocationSearch_ShouldReturnBadRequest_WhenVerifyRegionCodeHeaderReturnsError()
        {
            // Arrange
            var errorResult = new GenericResponse<string> { HasError = true, IsSuccess = false };
            _mockRegionCodeValidationHelper
                .Setup(helper => helper.VerifyRegionCodeHeader(It.IsAny<HttpRequest>()))
                .Returns(errorResult);

            // Act
            var result = await _controller.LocationSearch(1, 10, string.Empty, string.Empty, string.Empty);

            // Assert
            result.Should().BeOfType<BadRequestObjectResult>();
        }
        [Fact]
        public async Task GetLocationSearch_ShouldReturnNotFound_WhenNoLocation()
        {
            // Arrange
            var mockedResponse = new GenericResponse<string>
            {
                IsSuccess = true,
                HasError = false,
                StatusCode = AdministrationService.CrossCutting.CommonModels.ResponseStatus.STATUS_SUCCESS,
                Message = string.Empty
            };
            var mockedNotFoundResponse = new List<LocationSearchResponse>();

            _mockRegionCodeValidationHelper.Setup(x => x.VerifyRegionCodeHeader(It.IsAny<HttpRequest>()))
                .Returns(mockedResponse);

            _mockLocationQueryService.Setup(service => service.GetLocationSearch(It.IsAny<LocationSearchRequest>()))
               .ReturnsAsync(mockedNotFoundResponse);

            // Act
            var result = await _controller.LocationSearch(It.IsAny<int>(), It.IsAny<int>(), It.IsAny<string>(), It.IsAny<string>(), It.IsAny<string>());

            // Assert
            result.Should().BeOfType<NotFoundObjectResult>();
        }
        [Fact]
        public async Task GetLocationSearch_ShouldReturnFound()
        {
            // Arrange
            var mockedResponse = new GenericResponse<string>
            {
                IsSuccess = true,
                HasError = false,
                StatusCode = AdministrationService.CrossCutting.CommonModels.ResponseStatus.STATUS_SUCCESS,
                Message = string.Empty
            };
            var mockedNotFoundResponse = new List<LocationSearchResponse>() { new LocationSearchResponse() { Id = 1, Name = "test", Contact = "123456", Mode = "Physical", ResourceID = "PHIS", Status = true, UpdatedBy = "Admin", UpdatedDate = DateTime.UtcNow } };


            _mockRegionCodeValidationHelper.Setup(x => x.VerifyRegionCodeHeader(It.IsAny<HttpRequest>()))
                .Returns(mockedResponse);

            _mockLocationQueryService.Setup(service => service.GetLocationSearch(It.IsAny<LocationSearchRequest>()))
               .ReturnsAsync(mockedNotFoundResponse);

            // Act
            var result = await _controller.LocationSearch(It.IsAny<int>(), It.IsAny<int>(), It.IsAny<string>(), It.IsAny<string>(), It.IsAny<string>());

            // Assert
            result.Should().BeOfType<OkObjectResult>();
        }

        [Fact]
        public async Task GetNearestOrganizations_ShouldReturn_OkResult_WithData()
        {
            // Arrange
            var latitude = 40.7128;
            var longitude = -74.0060;

            var mockResponse = new GenericResponse<NearestOrganizationsResponseDto>
            {
                HasError = false,
                IsSuccess = true,
                StatusCode = "200",
                Result = new NearestOrganizationsResponseDto
                {
                    NearestContacts = new List<HospitalResponseDto>
                {
                    new HospitalResponseDto {
                        Name = "Hospital A",
                        Latitude = 40.713m,
                        Active = true,
                        Address ="test address",
                        City ="city",
                        Country ="Malysia",
                        Email ="test@testc.com",
                        LocationId =1,
                        OrganizationId =1,
                        PhoneNumber ="09854333",
                        PostalCode="2332333",
                        State="state",
                        Type="type",
                        WebsiteUrl="http://weburlexample.com",
                        Longitude = -74.007m ,
                    }
                },
                    OthersContacts = new List<HospitalResponseDto>
                {
                    new HospitalResponseDto {
                        Name = "Clinic B",
                        Latitude = 40.700m,
                        Longitude = -74.005m,
                         Active = true,
                        Address ="test address",
                        City ="city",
                        Country ="Malysia",
                        Email ="test@testc.com",
                        LocationId =1,
                        OrganizationId =1,
                        PhoneNumber ="09854333",
                        PostalCode="2332333",
                        State="state",
                        Type="type",
                        WebsiteUrl="http://weburlexample.com",
                    }
                }
                }
            };

            _mockLocationQueryService
                .Setup(service => service.GetNearByOrganizationsAsync(latitude, longitude))
                .ReturnsAsync(mockResponse);

            // Act
            var result = await _controller.GetNearestOrganizations(latitude, longitude);

            // Assert
            var okResult = Assert.IsType<OkObjectResult>(result);
            var responseData = Assert.IsType<GenericResponse<NearestOrganizationsResponseDto>>(okResult.Value);

            Assert.True(responseData.IsSuccess);
            Assert.NotNull(responseData.Result);
            Assert.NotEmpty(responseData.Result.NearestContacts);
            Assert.NotEmpty(responseData.Result.OthersContacts);
        }

        [Fact]
        public async Task GetNearestOrganizations_ShouldReturn_Empty_WhenNoOrganizationsExist()
        {
            // Arrange
            var latitude = 40.7128;
            var longitude = -74.0060;

            var mockResponse = new GenericResponse<NearestOrganizationsResponseDto>
            {
                HasError = false,
                IsSuccess = true,
                StatusCode = "200",
                Result = new NearestOrganizationsResponseDto
                {
                    NearestContacts = new List<HospitalResponseDto>(),
                    OthersContacts = new List<HospitalResponseDto>()
                }
            };

            _mockLocationQueryService
                .Setup(service => service.GetNearByOrganizationsAsync(latitude, longitude))
                .ReturnsAsync(mockResponse);

            // Act
            var result = await _controller.GetNearestOrganizations(latitude, longitude);

            // Assert
            var okResult = Assert.IsType<OkObjectResult>(result);
            var responseData = Assert.IsType<GenericResponse<NearestOrganizationsResponseDto>>(okResult.Value);

            Assert.True(responseData.IsSuccess);
            Assert.NotNull(responseData.Result);
            Assert.Empty(responseData.Result.NearestContacts);
            Assert.Empty(responseData.Result.OthersContacts);
        }

        #region


        [Fact]
        public async Task GetLocationDetails_ShouldReturnBadRequest_WhenRegionCodeInvalid()
        {
            // Arrange
            var mockResponse = new GenericResponse<string> { HasError = true };
            _mockRegionCodeValidationHelper
                .Setup(x => x.VerifyRegionCodeHeader(It.IsAny<HttpRequest>()))
                .Returns(mockResponse);

            // Act
            var result = await _controller.GetLocationDetailsById("resource123");

            // Assert
            result.Should().BeOfType<BadRequestObjectResult>();
            var badRequest = result as BadRequestObjectResult;
            badRequest?.Value.Should().BeEquivalentTo(mockResponse);
        }


        [Fact]
        public async Task GetLocationDetails_ShouldReturnNotFound_WhenNoDataFound()
        {
            // Arrange
            _mockRegionCodeValidationHelper
                .Setup(x => x.VerifyRegionCodeHeader(It.IsAny<HttpRequest>()))
                .Returns((GenericResponse<string>)null);

            var notFoundResponse = new GenericResponseList<AdminLocationsDTO>
            {
                HasError = false,
                IsSuccess = true,
                StatusCode = ResponceStatusCode.RecordNotFound.ToString(),
                Message = ResponseMessage.STATUS_NODATA,
                Results = new List<AdminLocationsDTO>()
            };

            _mockLocationQueryService
                .Setup(x => x.GetLocationDetailsByResourceId(It.IsAny<string>()))
                .ReturnsAsync(notFoundResponse);

            // Act
            var result = await _controller.GetLocationDetailsById("resource123");

            // Assert
            result.Should().BeOfType<NotFoundObjectResult>();
            var notFound = result as NotFoundObjectResult;
            notFound?.Value.Should().BeEquivalentTo(notFoundResponse);
        }


        [Fact]
        public async Task GetLocationDetails_ShouldReturnOk_WhenDataExists()
        {
            // Arrange
            _mockRegionCodeValidationHelper
                .Setup(x => x.VerifyRegionCodeHeader(It.IsAny<HttpRequest>()))
                .Returns((GenericResponse<string>)null);

            var expectedData = new List<AdminLocationsDTO>
    {
        new AdminLocationsDTO { LocationId = 1, Name = "Test Hospital", ResourceId = "resource123" }
    };

            var successResponse = new GenericResponseList<AdminLocationsDTO>
            {
                HasError = false,
                IsSuccess = true,
                StatusCode = AdministrationService.CrossCutting.CommonModels.ResponseStatus.STATUS_SUCCESS,
                Message = ResponseMessage.STATUS_SUCCESS,
                Results = expectedData
            };

            _mockLocationQueryService
                .Setup(x => x.GetLocationDetailsByResourceId("resource123"))
                .ReturnsAsync(successResponse);

            // Act
            var result = await _controller.GetLocationDetailsById("resource123");

            // Assert
            result.Should().BeOfType<OkObjectResult>();
            var okResult = result as OkObjectResult;
            okResult?.Value.Should().BeEquivalentTo(successResponse);
        }


        #endregion

        [Fact]
        public async Task Locations_ShouldReturnOk_WhenLocationsExist()
        {
            // Arrange
            var locationList = new List<GetLocationDto>
                {
                    new GetLocationDto {
                     Id = 1,
                     ResourceID="KLAN",
                     Name = "COLUMBIA ASIA HOSPITAL KLANG",
                     Alias="Klang",
                     Status = true,
                    Description = "Test Description",
                    PhysicalType = "Building",
                    Latitude = It.IsAny<decimal>(),
                    Longitude = It.IsAny<decimal>(),
                    Altitude = 10,
                    Mode = "Online",
                    RecordVersion= Array.Empty<byte>(),
                    IsDeleted = false,
                    PartOf="ExistingLocation",
                    Source="Internal",
                    OperationalStatus="Active",
                    URL="https://www.columbiaasia.com/malaysia/"
                        }
                };

            // Arrange
            var mockedResponse = new GenericResponse<string>
            {
                IsSuccess = true,
                HasError = false,
                StatusCode = ResponceStatusCode.Success.ToString(),
                Message = string.Empty
            };

            _mockRegionCodeValidationHelper.Setup(x => x.VerifyRegionCodeHeader(It.IsAny<HttpRequest>()))
                .Returns((mockedResponse));

            _mockLocationQueryService.Setup(x => x.GetLocations())
                .ReturnsAsync(locationList);

            // Act
            var result = await _controller.Locations();

            // Assert
            result.Should().BeOfType<OkObjectResult>();

            var okResult = result as OkObjectResult;
            var response = okResult.Value as GenericResponseList<GetLocationDto>;

            response.Should().NotBeNull();
            response.IsSuccess.Should().BeTrue();
            response.HasError.Should().BeFalse();
            response.Results.Should().NotBeEmpty().And.BeEquivalentTo(locationList);
            response.StatusCode.Should().Be(ResponceStatusCode.Success.ToString());
        }
        [Fact]
        public async Task Locations_ShouldReturnBadRequest_WhenRegionCodeIsInvalid()
        {
            // Arrange
            _mockRegionCodeValidationHelper.Setup(x => x.VerifyRegionCodeHeader(It.IsAny<HttpRequest>()))
                .Returns(new GenericResponse<string> { HasError = true });

            // Act
            var result = await _controller.Locations();

            // Assert
            result.Should().BeOfType<BadRequestObjectResult>();
        }

        [Fact]
        public async Task Locations_ShouldReturnNotFound_WhenNoLocationsExist()
        {
            // Arrange
            _mockRegionCodeValidationHelper.Setup(x => x.VerifyRegionCodeHeader(It.IsAny<HttpRequest>()))
                .Returns(new GenericResponse<string>() { });

            _mockLocationQueryService.Setup(x => x.GetLocations())
                .ReturnsAsync(new List<GetLocationDto>());

            // Act
            var result = await _controller.Locations();

            // Assert
            result.Should().BeOfType<NotFoundObjectResult>();

            var objectResult = result as NotFoundObjectResult;
            var response = objectResult.Value as GenericResponseList<GetLocationDto>;

            response.Should().NotBeNull();
            response.IsSuccess.Should().BeTrue();
            response.HasError.Should().BeFalse();
            response.Results.Should().BeEmpty();
            response.StatusCode.Should().Be(ResponceStatusCode.RecordNotFound.ToString());
            response.Message.Should().Be(ResponseMessage.STATUS_NODATA);
        }

        #region Search Hospital

        [Fact]
        public void SearchHospitals_ShouldReturnBadRequest_WhenRegionCodeValidationFails()
        {
            // Arrange
            var validationError = new GenericResponse<string> { HasError = true };
            _mockRegionCodeValidationHelper
                .Setup(x => x.VerifyRegionCodeHeader(It.IsAny<HttpRequest>()))
                .Returns(validationError);

            // Act
            var result = _controller.SearchHospitals("Gujarat");

            // Assert
            var badRequestResult = Assert.IsType<BadRequestObjectResult>(result);
            Assert.Equal(validationError, badRequestResult.Value);
        }
        [Fact]
        public void SearchHospitals_ShouldReturnNotFound_WhenNoHospitalsFound()
        {
            // Arrange
            _mockRegionCodeValidationHelper
                .Setup(x => x.VerifyRegionCodeHeader(It.IsAny<HttpRequest>()))
                .Returns((GenericResponse<string>?)null!); // Simulate no validation error
            _mockLocationQueryService
                .Setup(s => s.SearchHospitals("Speciality"))
                .Returns(new List<GetHospitalDto>());

            // Acts
            var result = _controller.SearchHospitals("Speciality");

            // Assert
            var notFoundResult = Assert.IsType<NotFoundObjectResult>(result);
            var response = notFoundResult.Value.Should().BeAssignableTo<GenericResponse<string>>().Subject;

            response.IsSuccess.Should().BeFalse();
            response.HasError.Should().BeTrue();
            response.StatusCode.Should().Be(ResponseStatusCode.STATUS_NOTFOUND);
            response.Message.Should().Be(ResponseMessage.STATUS_NODATA);
        }


        [Fact]
        public void SearchHospitals_ShouldReturnOk_WhenHospitalsAreFound()
        {
            // Arrange
            _mockRegionCodeValidationHelper
                .Setup(x => x.VerifyRegionCodeHeader(It.IsAny<HttpRequest>()))
                .Returns((GenericResponse<string>?)null!); // Simulate successful region code validation

            var expectedHospitalDto = new GetHospitalDto
            {
                State = "Gujarat",
                Hospitals = new List<HospitalDto>
        {
            new HospitalDto
            {
                Id = 1,
                Name = "City Hospital",
                State = "Gujarat",
                City = "Ahmedabad",
                PhoneNumber = "12345",
                ImageUrl = "image1.png",
                FloorMapCount = 1,
                Latitude = (decimal)23.0225,
                Longitude = (decimal)72.5714,
                LocationId = 1,
                Url = "https://cityhospital.com"
            }
        }
            };

            var expectedResponse = new List<GetHospitalDto> { expectedHospitalDto };

            _mockLocationQueryService
                .Setup(s => s.SearchHospitals("City"))
                .Returns(expectedResponse);

            // Act
            var result = _controller.SearchHospitals("City");

            // Assert
            var okResult = result.Should().BeOfType<OkObjectResult>().Subject;
            var response = okResult.Value.Should().BeAssignableTo<GenericResponse<List<GetHospitalDto>>>().Subject;

            response.IsSuccess.Should().BeTrue();
            response.HasError.Should().BeFalse();
            response.StatusCode.Should().Be(ResponseStatusCode.STATUS_SUCCESS);
            response.Message.Should().Be(ResponseMessage.STATUS_DATA_FOUND);
            response.MessageType.Should().Be(CommonConstants.SUCCESS);
            response.Result.Should().BeEquivalentTo(expectedResponse);
        }


        #endregion
    }
}