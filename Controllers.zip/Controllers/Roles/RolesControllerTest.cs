﻿using Aurora.AdministrationService.API.Controllers.Roles;
using Aurora.AdministrationService.API.Helper;
using Aurora.AdministrationService.API.Models.Dto.UserGroups.Roles;
using Aurora.AdministrationService.API.Services.IService.UserGroups.Roles;
using Aurora.AdministrationService.CrossCutting.CommonModels;
using Aurora.AdministrationService.CrossCutting.Constants;
using FluentAssertions;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Moq;

namespace Aurora.AdministrationService.Tests.API.Controllers.Roles
{
    public class RolesControllerTest
    {
        private readonly Mock<IRolesCommandService> _mockRolesCommandService;
        private readonly Mock<IRolesQueryService> _mockRolesQueryService;
        private readonly RolesController _controller;
        private readonly Mock<IRegionCodeValidationHelper> _regionHelperMock;

        public RolesControllerTest()
        {
            _regionHelperMock = new Mock<IRegionCodeValidationHelper>();
            _mockRolesCommandService = new Mock<IRolesCommandService>();
            _mockRolesQueryService = new Mock<IRolesQueryService>();
            _controller = new RolesController(_mockRolesQueryService.Object, _mockRolesCommandService.Object, _regionHelperMock.Object);
        }
        [Fact]
        public void GetRoless_InvalidRegionCode_ReturnsBadRequest()
        {
            // Arrange
            _regionHelperMock
                .Setup(helper => helper.VerifyRegionCodeHeader(It.IsAny<HttpRequest>()))
                .Returns(new GenericResponse<string> { HasError = true, Message = "Invalid RegionCode" });

            // Act
            var result = _controller.GetRolesList();

            // Assert
            var badRequestResult = result.Result as BadRequestObjectResult;
            badRequestResult.Should().NotBeNull();
            var response = badRequestResult?.Value as GenericResponse<string>;
            response.Should().NotBeNull();
            response?.HasError.Should().BeTrue();
            response?.Message.Should().Be("Invalid RegionCode");
        }

        [Fact]
        public void CreateRoles_InvalidRegionCode_ReturnsBadRequest()
        {
            // Arrange
            var roles = new RolesDto()
            {
                Code = "test",
                Location = "BRIM",
                IsObsolete = true,
                RoleName = "test",
                MenuID = 1,
                RoleDescription = "test",
                Source = "test",
            };
            _regionHelperMock
                .Setup(helper => helper.VerifyRegionCodeHeader(It.IsAny<HttpRequest>()))
                .Returns(new GenericResponse<string> { HasError = true, Message = "Invalid RegionCode" });

            // Act
            var result = _controller.CreateRoles(roles);

            // Assert
            var badRequestResult = result?.Result as BadRequestObjectResult;
            badRequestResult.Should().NotBeNull();
            var response = badRequestResult?.Value as GenericResponse<string>;
            response.Should().NotBeNull();
            response?.HasError.Should().BeTrue();
            response?.Message.Should().Be("Invalid RegionCode");
        }

        [Fact]
        public async Task GetRolesById_InvalidRegionCode_ReturnsBadRequest()
        {
            // Arrange
            _regionHelperMock
                .Setup(helper => helper.VerifyRegionCodeHeader(It.IsAny<HttpRequest>()))
                .Returns(new GenericResponse<string> { HasError = true, Message = "Invalid RegionCode" });

            // Act
            var result = await _controller.GetRolesById(1);

            // Assert
            var badRequestResult = result.Result as BadRequestObjectResult;

            badRequestResult.Should().NotBeNull();
            var response = badRequestResult?.Value as GenericResponse<string>;
            response.Should().NotBeNull();
            response?.HasError.Should().BeTrue();
            response?.Message.Should().Be("Invalid RegionCode");
        }

        [Fact]
        public void UpdateRolesDetails_InvalidRegionCode_ReturnsBadRequest()
        {
            // Arrange
            byte[] concurrencyToken = new byte[8] { byte.MinValue, byte.MinValue, byte.MinValue, byte.MinValue, byte.MinValue, byte.MinValue, byte.MinValue, byte.MaxValue };
            int id = 1;
            var roles = new UpdateRolesRequest()
            {
                Id = 1,
                Code = "test",
                Location = "BRIM",
                IsObsolete = true,
                RoleName = "test",
                MenuID = 1,
                RoleDescription = "test",
                Source = "test",
            };
            _regionHelperMock
                .Setup(helper => helper.VerifyRegionCodeHeader(It.IsAny<HttpRequest>()))
                .Returns(new GenericResponse<string> { HasError = true, Message = "Invalid RegionCode" });

            // Act
            var result = _controller.UpdateRolesDetails(id, roles);

            // Assert
            var badRequestResult = result?.Result as BadRequestObjectResult;
            badRequestResult.Should().NotBeNull();
            var response = badRequestResult?.Value as GenericResponse<string>;
            response.Should().NotBeNull();
            response?.HasError.Should().BeTrue();
            response?.Message.Should().Be("Invalid RegionCode");
        }

        [Fact]
        public async Task CreateRoles_ShouldReturnSuccessResponse_WhenIsAdded()
        {
            // Arrange
            var roles = new RolesDto()
            {
                Code = "test",
                Location = "BRIM",
                IsObsolete = true,
                RoleName = "test",
                MenuID = 1,
                RoleDescription = "test",
                Source = "test",
            };
            _mockRolesCommandService.Setup(service => service.CreateRolesAsync(roles)).ReturnsAsync(true);

            // Act
            var result = await _controller.CreateRoles(roles) as OkObjectResult;
            var response = result?.Value as GenericResponse<string>;

            // Assert
            result.Should().NotBeNull();
            result?.StatusCode.Should().Be(200);
            response?.IsSuccess.Should().BeTrue();
            response?.StatusCode.Should().Be(ResponseStatusCode.STATUS_SUCCESS);
            response?.Message.Should().Be(ResponseMessage.STATUS_DATA_ADDED);
        }

        [Fact]
        public void GetRolesList_ShouldReturnRolesList()
        {
            // Arrange
            var rolesList = new List<GetRolesDto> { new GetRolesDto() {
               Code = "test",
                Location = "BRIM",
                IsObsolete = true,
                RoleName = "test",
                MenuID = 1,
                RoleDescription = "test",
                Source = "test",
            } };
            _mockRolesQueryService.Setup(service => service.GetRolesList()).Returns(rolesList);

            // Act
            var result = _controller.GetRolesList();
            var okresult = result?.Result as OkObjectResult;
            var response = okresult?.Value as GenericResponseList<GetRolesDto>;

            // Assert
            result.Should().NotBeNull();
            response?.StatusCode.Should().Be("200");
            response?.IsSuccess.Should().BeTrue();
            response?.StatusCode.Should().Be(ResponseStatusCode.STATUS_SUCCESS);
            response?.Message.Should().Be(ResponseMessage.STATUS_DATA_FOUND);
            response?.TotalCount.Should().Be(rolesList.Count);

        }

        [Fact]
        public async Task GetRolesById_ShouldReturnNull_WhenIdIsInvalid()
        {
            // Act
            var result = await _controller.GetRolesById(null);
            var response = result.Value as GenericResponse<GetRolesDetailDto>;

            // Assert
            result.Should().NotBeNull();
            response.Should().BeNull();

        }

        [Fact]
        public async Task GetRolesById_ShouldReturnNotFound_WhenDoesNotExist()
        {
            // Arrange
            var id = 1;
            GetRolesDetailDto rolesDetailDto = new GetRolesDetailDto()
            {
                Code = "test",
                Location = "BRIM",
                IsObsolete = true,
                RoleName = "test",
                MenuID = 1,
                RoleDescription = "test",
                Source = "test",
            };
            _mockRolesQueryService
              .Setup(service => service.GetRolesById(2)).ReturnsAsync(rolesDetailDto);

            // Act
            var result = await _controller.GetRolesById(id);
            var okobjectresult = result?.Result as OkObjectResult;
            var response = okobjectresult?.Value as GenericResponse<GetRolesDetailDto>;

            // Assert
            result.Should().NotBeNull();
            response?.IsSuccess.Should().BeTrue();
            response?.StatusCode.Should().Be(ResponseStatusCode.STATUS_NOTFOUND);
            response?.Message.Should().Be(ResponseMessage.STATUS_NODATA);
        }

        [Fact]
        public async Task UpdateRolesDetails_ShouldReturnBadRequest_WhenAlreadyExists()
        {
            // Arrange
            int id = 1;
            var roles = new UpdateRolesRequest()
            {
                Id = 1,
                Code = "test",
                Location = "BRIM",
                IsObsolete = true,
                RoleName = "test",
                MenuID = 1,
                RoleDescription = "test",
                Source = "test",
            };
            _mockRolesQueryService.Setup(service => service.IsRolesAlreadyExist(id)).ReturnsAsync((true, ResponseMessage.STATUS_NODATA));

            // Act
            var result = await _controller.UpdateRolesDetails(id, roles);

            // Assert
            result.Should().NotBeNull();

        }

        [Fact]
        public async Task UpdateRolesDetails_RolesNotFound_ReturnsNotFound()
        {
            // Arrange
            byte[] concurrencyToken = new byte[8] { byte.MinValue, byte.MinValue, byte.MinValue, byte.MinValue, byte.MinValue, byte.MinValue, byte.MinValue, byte.MaxValue };
            int rolesId = 1;
            var rolesRequest = new UpdateRolesRequest()
            {
                Id = rolesId,
                Code = "test",
                Location = "BRIM",
                IsObsolete = true,
                RoleName = "test",
                MenuID = 1,
                RoleDescription = "test",
                Source = "test",
            };
            Domain.V1.Entities.UserGroups.Roles? roles = null;
            _mockRolesQueryService
                .Setup(service => service.FindRolesById(rolesId))
                .ReturnsAsync(roles);

            // Act
            var result = await _controller.UpdateRolesDetails(rolesId, rolesRequest);

            // Assert
            var actionResult = Assert.IsType<NotFoundObjectResult>(result);
            var response = Assert.IsType<GenericResponse<string>>(actionResult.Value);
            Assert.Equal(ResponseStatusCode.STATUS_NOTFOUND, response.StatusCode);
            Assert.Equal(ResponseMessage.STATUS_NODATA, response.Message);
        }

        [Fact]
        public async Task UpdateRolesDetails_UpdateSuccessful_ReturnsOk()
        {
            // Arrange
            int rolesId = 1;
            var rolesRequest = new UpdateRolesRequest()
            {
                Id = 1,
                Code = "test",
                Location = "BRIM",
                IsObsolete = true,
                RoleName = "test",
                MenuID = 1,
                RoleDescription = "test",
                Source = "test",
            };
            var existingRoles = new Domain.V1.Entities.UserGroups.Roles
            {
                Id = rolesId,
                Code = "test",
                Location = "BRIM",
                IsObsolete = true,
                RoleName = "test",
                MenuID = 1,
                RoleDescription = "test",
                Source = "test",
                CreatedBy = "Admin",
                CreatedDate = DateTime.UtcNow,
                IsDeleted = false
            };

            _mockRolesQueryService
                .Setup(service => service.FindRolesById(rolesId))
                .ReturnsAsync(existingRoles);

            _mockRolesCommandService
                .Setup(service => service.UpdateRolesAsync(rolesRequest, existingRoles))
                .ReturnsAsync(true);

            // Act
            var result = await _controller.UpdateRolesDetails(rolesId, rolesRequest);

            // Assert
            var actionResult = Assert.IsType<OkObjectResult>(result);
            var response = Assert.IsType<GenericResponse<string>>(actionResult.Value);
            Assert.Equal(ResponseStatusCode.STATUS_SUCCESS, response.StatusCode);
            Assert.Equal(ResponseMessage.STATUS_DATA_UPDATED, response.Message);
            Assert.Equal(CommonConstants.SUCCESS, response.MessageType);
        }

        [Fact]
        public async Task UpdateRolesDetails_UpdateFailed_ReturnsOkWithErrorMessage()
        {
            // Arrange
            int rolesId = 1;
            var rolesRequest = new UpdateRolesRequest()
            {
                Id = rolesId,
                Code = "test",
                Location = "BRIM",
                IsObsolete = true,
                RoleName = "test",
                MenuID = 1,
                RoleDescription = "test",
                Source = "test",
            };
            var existingRoles = new Domain.V1.Entities.UserGroups.Roles
            {
                Id = rolesId,
                Code = "test",
                Location = "BRIM",
                IsObsolete = true,
                RoleName = "test",
                MenuID = 1,
                RoleDescription = "test",
                Source = "test",
                CreatedBy = "Admin",
                CreatedDate = DateTime.UtcNow,
                IsDeleted = false
            };

            _mockRolesQueryService
                .Setup(service => service.FindRolesById(rolesId))
                .ReturnsAsync(existingRoles); // Simulate roles found

            _mockRolesCommandService
                .Setup(service => service.UpdateRolesAsync(rolesRequest, existingRoles))
                .ReturnsAsync(false); // Simulate update failure

            // Act
            var result = await _controller.UpdateRolesDetails(rolesId, rolesRequest);

            // Assert
            var actionResult = Assert.IsType<OkObjectResult>(result);
            Assert.Equal(ResponseStatusCode.STATUS_SUCCESS, actionResult.StatusCode.ToString());
        }

        [Fact]
        public async Task GetRolesById_ReturnsOk_WhenRolesIsFound()
        {
            // Arrange
            int rolesId = 1;
            var expectedRoles = new GetRolesDetailDto
            {
                Id = rolesId,
                Code = "test",
                Location = "BRIM",
                IsObsolete = true,
                RoleName = "test",
                MenuID = 1,
                RoleDescription = "test",
                Source = "test",
                IsDeleted = false,
            };
            _mockRolesQueryService.Setup(s => s.GetRolesById(rolesId)).ReturnsAsync(expectedRoles);

            // Act
            var result = await _controller.GetRolesById(rolesId);

            // Assert
            var actionResult = Assert.IsType<ActionResult<GenericResponse<GetRolesDetailDto>>>(result);
            var okResult = Assert.IsType<OkObjectResult>(actionResult.Result);
            var response = Assert.IsType<GenericResponse<GetRolesDetailDto>>(okResult.Value);
            Assert.True(response.IsSuccess);
            Assert.Equal(ResponseStatusCode.STATUS_SUCCESS, response.StatusCode);
            Assert.Equal(ResponseMessage.STATUS_DATA_FOUND, response.Message);
            Assert.Equal(expectedRoles, response.Result);
        }
    }
}
