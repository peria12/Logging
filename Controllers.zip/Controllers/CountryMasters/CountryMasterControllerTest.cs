﻿using Aurora.AdministrationService.API.Controllers.CountryMasters;
using Aurora.AdministrationService.API.Helper;
using Aurora.AdministrationService.API.Models.Dto.CountryMasters;
using Aurora.AdministrationService.API.Services.IService.CountryMasters;
using Aurora.AdministrationService.CrossCutting.CommonModels;
using Aurora.AdministrationService.CrossCutting.Constants;
using FluentAssertions;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Moq;

namespace Aurora.AdministrationService.Tests.API.Controllers.CountryMasters
{
    public class CountryMasterControllerTest
    {
        private readonly Mock<ICountryMasterCommandService> _mockCountryMasterCommandService;
        private readonly Mock<ICountryMasterQueryService> _mockCountryMasterQueryService;
        private readonly CountryMasterController _controller;
        private readonly Mock<IRegionCodeValidationHelper> _regionHelperMock;

        public CountryMasterControllerTest()
        {
            _regionHelperMock = new Mock<IRegionCodeValidationHelper>();
            _mockCountryMasterCommandService = new Mock<ICountryMasterCommandService>();
            _mockCountryMasterQueryService = new Mock<ICountryMasterQueryService>();
            _controller = new CountryMasterController(_mockCountryMasterQueryService.Object, _mockCountryMasterCommandService.Object, _regionHelperMock.Object);
        }
        [Fact]
        public void GetCountryMasters_InvalidRegionCode_ReturnsBadRequest()
        {
            // Arrange
            _regionHelperMock
                .Setup(helper => helper.VerifyRegionCodeHeader(It.IsAny<HttpRequest>()))
                .Returns(new GenericResponse<string> { HasError = true, Message = "Invalid RegionCode" });

            // Act
            var result = _controller.GetCountryMasterList();

            // Assert
            var badRequestResult = result.Result as BadRequestObjectResult;
            badRequestResult.Should().NotBeNull();
            var response = badRequestResult?.Value as GenericResponse<string>;
            response.Should().NotBeNull();
            response?.HasError.Should().BeTrue();
            response?.Message.Should().Be("Invalid RegionCode");
        }

        [Fact]
        public void CreateCountryMaster_InvalidRegionCode_ReturnsBadRequest()
        {
            // Arrange
            var countryMaster = new CountryMasterDto()
            {
                Code = "Test",
                Definition = "test",
                Source = "source",
                ResourceId = "test",
            };
            _regionHelperMock
                .Setup(helper => helper.VerifyRegionCodeHeader(It.IsAny<HttpRequest>()))
                .Returns(new GenericResponse<string> { HasError = true, Message = "Invalid RegionCode" });

            // Act
            var result = _controller.CreateCountryMaster(countryMaster);

            // Assert
            var badRequestResult = result?.Result as BadRequestObjectResult;
            badRequestResult.Should().NotBeNull();
            var response = badRequestResult?.Value as GenericResponse<string>;
            response.Should().NotBeNull();
            response?.HasError.Should().BeTrue();
            response?.Message.Should().Be("Invalid RegionCode");
        }

        [Fact]
        public async Task GetCountryMasterById_InvalidRegionCode_ReturnsBadRequest()
        {
            // Arrange
            _regionHelperMock
                .Setup(helper => helper.VerifyRegionCodeHeader(It.IsAny<HttpRequest>()))
                .Returns(new GenericResponse<string> { HasError = true, Message = "Invalid RegionCode" });

            // Act
            var result = await _controller.GetCountryMasterById(1);

            // Assert
            var badRequestResult = result.Result as BadRequestObjectResult;

            badRequestResult.Should().NotBeNull();
            var response = badRequestResult?.Value as GenericResponse<string>;
            response.Should().NotBeNull();
            response?.HasError.Should().BeTrue();
            response?.Message.Should().Be("Invalid RegionCode");
        }

        [Fact]
        public void UpdateCountryMasterDetails_InvalidRegionCode_ReturnsBadRequest()
        {
            // Arrange
            byte[] concurrencyToken = new byte[8] { byte.MinValue, byte.MinValue, byte.MinValue, byte.MinValue, byte.MinValue, byte.MinValue, byte.MinValue, byte.MaxValue };
            int id = 1;
            var countryMaster = new UpdateCountryMasterRequest()
            {
                Id = 1,
                Code = "Test",
                Definition = "test",
                Source = "source",
                ResourceId = "test",
                RecordVersion = concurrencyToken
            };
            _regionHelperMock
                .Setup(helper => helper.VerifyRegionCodeHeader(It.IsAny<HttpRequest>()))
                .Returns(new GenericResponse<string> { HasError = true, Message = "Invalid RegionCode" });

            // Act
            var result = _controller.UpdateCountryMasterDetails(id, countryMaster);

            // Assert
            var badRequestResult = result?.Result as BadRequestObjectResult;
            badRequestResult.Should().NotBeNull();
            var response = badRequestResult?.Value as GenericResponse<string>;
            response.Should().NotBeNull();
            response?.HasError.Should().BeTrue();
            response?.Message.Should().Be("Invalid RegionCode");
        }

        [Fact]
        public async Task CreateCountryMaster_ShouldReturnSuccessResponse_WhenIsAdded()
        {
            // Arrange
            var countryMaster = new CountryMasterDto()
            {
                Code = "Test",
                Definition = "test",
                Source = "source",
                ResourceId = "test",
            };
            _mockCountryMasterCommandService.Setup(service => service.CreateCountryMasterAsync(countryMaster)).ReturnsAsync(true);

            // Act
            var result = await _controller.CreateCountryMaster(countryMaster) as OkObjectResult;
            var response = result?.Value as GenericResponse<string>;

            // Assert
            result.Should().NotBeNull();
            result?.StatusCode.Should().Be(200);
            response?.IsSuccess.Should().BeTrue();
            response?.StatusCode.Should().Be(ResponseStatusCode.STATUS_SUCCESS);
            response?.Message.Should().Be(ResponseMessage.STATUS_DATA_ADDED);
        }

        [Fact]
        public void GetCountryMasterList_ShouldReturnCountryMasterList()
        {
            // Arrange
            var countryMasterList = new List<GetCountryMasterDto> { new GetCountryMasterDto() { ResourceId = "test", } };
            _mockCountryMasterQueryService.Setup(service => service.GetCountryMasterList()).Returns(countryMasterList);

            // Act
            var result = _controller.GetCountryMasterList();
            var okresult = result?.Result as OkObjectResult;
            var response = okresult?.Value as GenericResponseList<GetCountryMasterDto>;

            // Assert
            result.Should().NotBeNull();
            response?.StatusCode.Should().Be("200");
            response?.IsSuccess.Should().BeTrue();
            response?.StatusCode.Should().Be(ResponseStatusCode.STATUS_SUCCESS);
            response?.Message.Should().Be(ResponseMessage.STATUS_DATA_FOUND);
            response?.TotalCount.Should().Be(countryMasterList.Count);

        }

        [Fact]
        public async Task GetCountryMasterById_ShouldReturnNull_WhenIdIsInvalid()
        {
            // Act
            var result = await _controller.GetCountryMasterById(null);
            var response = result.Value as GenericResponse<GetCountryMasterDetailDto>;

            // Assert
            result.Should().NotBeNull();
            response.Should().BeNull();

        }

        [Fact]
        public async Task GetCountryMasterById_ShouldReturnNotFound_WhenDoesNotExist()
        {
            // Arrange
            var id = 1L;
            GetCountryMasterDetailDto countryMasterDetailDto = new GetCountryMasterDetailDto() { ResourceId = "test", };
            _mockCountryMasterQueryService
              .Setup(service => service.GetCountryMasterById(2)).ReturnsAsync(countryMasterDetailDto);

            // Act
            var result = await _controller.GetCountryMasterById(id);
            var okobjectresult = result?.Result as OkObjectResult;
            var response = okobjectresult?.Value as GenericResponse<GetCountryMasterDetailDto>;

            // Assert
            result.Should().NotBeNull();
            response?.IsSuccess.Should().BeTrue();
            response?.StatusCode.Should().Be(ResponseStatusCode.STATUS_NOTFOUND);
            response?.Message.Should().Be(ResponseMessage.STATUS_NODATA);
        }

        [Fact]
        public async Task UpdateCountryMasterDetails_ShouldReturnBadRequest_WhenAlreadyExists()
        {
            // Arrange
            byte[] concurrencyToken = new byte[8] { byte.MinValue, byte.MinValue, byte.MinValue, byte.MinValue, byte.MinValue, byte.MinValue, byte.MinValue, byte.MaxValue };
            int id = 1;
            var countryMaster = new UpdateCountryMasterRequest()
            {
                Id = 1,
                Code = "Test",
                Definition = "test",
                Source = "source",
                ResourceId = "test",
                RecordVersion = concurrencyToken,
            };
            _mockCountryMasterQueryService.Setup(service => service.IsCountryMasterAlreadyExist(id)).ReturnsAsync((true, ResponseMessage.STATUS_NODATA));

            // Act
            var result = await _controller.UpdateCountryMasterDetails(id, countryMaster);

            // Assert
            result.Should().NotBeNull();

        }

        [Fact]
        public async Task UpdateCountryMasterDetails_CountryMasterNotFound_ReturnsNotFound()
        {
            // Arrange
            byte[] concurrencyToken = new byte[8] { byte.MinValue, byte.MinValue, byte.MinValue, byte.MinValue, byte.MinValue, byte.MinValue, byte.MinValue, byte.MaxValue };
            int countryMasterId = 1;
            var countryMasterRequest = new UpdateCountryMasterRequest()
            {
                Id = countryMasterId,
                Code = "Test",
                Definition = "test",
                Source = "source",
                ResourceId = "test",
                RecordVersion = concurrencyToken,
            };
            Domain.V1.Entities.CountryMasters.CountryMaster countryMaster = null;
            _mockCountryMasterQueryService
                .Setup(service => service.FindCountryMasterById(countryMasterId))
                .ReturnsAsync(countryMaster);

            // Act
            var result = await _controller.UpdateCountryMasterDetails(countryMasterId, countryMasterRequest);

            // Assert
            var actionResult = Assert.IsType<NotFoundObjectResult>(result);
            var response = Assert.IsType<GenericResponse<string>>(actionResult.Value);
            Assert.Equal(ResponseStatusCode.STATUS_NOTFOUND, response.StatusCode);
            Assert.Equal(ResponseMessage.STATUS_NODATA, response.Message);
        }

        [Fact]
        public async Task UpdateCountryMasterDetails_UpdateSuccessful_ReturnsOk()
        {
            // Arrange
            byte[] concurrencyToken = new byte[8] { byte.MinValue, byte.MinValue, byte.MinValue, byte.MinValue, byte.MinValue, byte.MinValue, byte.MinValue, byte.MaxValue };
            int countryMasterId = 1;
            var countryMasterRequest = new UpdateCountryMasterRequest()
            {
                Id = 1,
                Code = "Test",
                Definition = "test",
                Source = "source",
                ResourceId = "test",
                RecordVersion = concurrencyToken
            };
            var existingCountryMaster = new Domain.V1.Entities.CountryMasters.CountryMaster
            {
                Id = countryMasterId,
                Code = "Test",
                Definition = "test",
                Source = "source",
                ResourceId = "test",
                CreatedBy = "Admin",
                CreatedDate = DateTime.UtcNow,
                IsDeleted = false
            };

            _mockCountryMasterQueryService
                .Setup(service => service.FindCountryMasterById(countryMasterId))
                .ReturnsAsync(existingCountryMaster);

            _mockCountryMasterCommandService
                .Setup(service => service.UpdateCountryMasterAsync(countryMasterRequest, existingCountryMaster))
                .ReturnsAsync(true);

            // Act
            var result = await _controller.UpdateCountryMasterDetails(countryMasterId, countryMasterRequest);

            // Assert
            var actionResult = Assert.IsType<OkObjectResult>(result);
            var response = Assert.IsType<GenericResponse<string>>(actionResult.Value);
            Assert.Equal(ResponseStatusCode.STATUS_SUCCESS, response.StatusCode);
            Assert.Equal(ResponseMessage.STATUS_DATA_UPDATED, response.Message);
            Assert.Equal(CommonConstants.SUCCESS, response.MessageType);
        }

        [Fact]
        public async Task UpdateCountryMasterDetails_UpdateFailed_ReturnsOkWithErrorMessage()
        {
            // Arrange
            byte[] concurrencyToken = new byte[8] { byte.MinValue, byte.MinValue, byte.MinValue, byte.MinValue, byte.MinValue, byte.MinValue, byte.MinValue, byte.MaxValue };
            int contentId = 1;
            var countryMasterRequest = new UpdateCountryMasterRequest()
            {
                Id = contentId,
                Code = "Test",
                Definition = "test",
                Source = "source",
                ResourceId = "test",
                RecordVersion = concurrencyToken
            };
            var existingCountryMaster = new Domain.V1.Entities.CountryMasters.CountryMaster
            {
                Id = contentId,
                Code = "Test",
                Definition = "test",
                Source = "source",
                ResourceId = "test",
                CreatedBy = "Admin",
                CreatedDate = DateTime.UtcNow,
                IsDeleted = false
            };

            _mockCountryMasterQueryService
                .Setup(service => service.FindCountryMasterById(contentId))
                .ReturnsAsync(existingCountryMaster); // Simulate countryMaster found

            _mockCountryMasterCommandService
                .Setup(service => service.UpdateCountryMasterAsync(countryMasterRequest, existingCountryMaster))
                .ReturnsAsync(false); // Simulate update failure

            // Act
            var result = await _controller.UpdateCountryMasterDetails(contentId, countryMasterRequest);

            // Assert
            var actionResult = Assert.IsType<OkObjectResult>(result);
            Assert.Equal(ResponseStatusCode.STATUS_SUCCESS, actionResult.StatusCode.ToString());
        }

        [Fact]
        public async Task GetCountryMasterById_ReturnsOk_WhenCountryMasterIsFound()
        {
            // Arrange
            int contentId = 1;
            byte[] concurrencyToken = new byte[8] { byte.MinValue, byte.MinValue, byte.MinValue, byte.MinValue, byte.MinValue, byte.MinValue, byte.MinValue, byte.MaxValue };
            var expectedCountryMaster = new GetCountryMasterDetailDto
            {
                Id = contentId,
                Code = "Test",
                Definition = "test",
                Source = "source",
                ResourceId = "test",
                IsDeleted = false,
                RecordVersion = concurrencyToken
            };
            _mockCountryMasterQueryService.Setup(s => s.GetCountryMasterById(contentId)).ReturnsAsync(expectedCountryMaster);

            // Act
            var result = await _controller.GetCountryMasterById(contentId);

            // Assert
            var actionResult = Assert.IsType<ActionResult<GenericResponse<GetCountryMasterDetailDto>>>(result);
            var okResult = Assert.IsType<OkObjectResult>(actionResult.Result);
            var response = Assert.IsType<GenericResponse<GetCountryMasterDetailDto>>(okResult.Value);
            Assert.True(response.IsSuccess);
            Assert.Equal(ResponseStatusCode.STATUS_SUCCESS, response.StatusCode);
            Assert.Equal(ResponseMessage.STATUS_DATA_FOUND, response.Message);
            Assert.Equal(expectedCountryMaster, response.Result);
        }

        [Fact]
        public void GetCountries_InvalidRegionCode_ReturnsBadRequest()
        {
            // Arrange
            _regionHelperMock
                .Setup(helper => helper.VerifyRegionCodeHeader(It.IsAny<HttpRequest>()))
                .Returns(new GenericResponse<string> { HasError = true, Message = "Invalid RegionCode" });

            // Act
            var result = _controller.GetCountriesList();

            // Assert
            var badRequestResult = result.Result as BadRequestObjectResult;
            badRequestResult.Should().NotBeNull();
            var response = badRequestResult?.Value as GenericResponse<string>;
            response.Should().NotBeNull();
            response?.HasError.Should().BeTrue();
            response?.Message.Should().Be("Invalid RegionCode");
        }

        [Fact]
        public void GetCountries_ShouldReturnCountryMasterList()
        {
            // Arrange
            var countryMasterList = new List<CountryResponseDto> { new CountryResponseDto() { ResourceId = "test", } };
            _mockCountryMasterQueryService.Setup(service => service.GetCountryMasters()).Returns(countryMasterList);

            // Act
            var result = _controller.GetCountriesList();
            var okresult = result?.Result as OkObjectResult;
            var response = okresult?.Value as GenericResponseList<GetCountryMasterDto>;

            // Assert
            result.Should().NotBeNull();
            response?.StatusCode.Should().Be("200");
            response?.IsSuccess.Should().BeTrue();
            response?.StatusCode.Should().Be(ResponseStatusCode.STATUS_SUCCESS);
            response?.Message.Should().Be(ResponseMessage.STATUS_DATA_FOUND);
            response?.TotalCount.Should().Be(countryMasterList.Count);

        }
    }
}
