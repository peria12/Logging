﻿using Aurora.AdministrationService.API.Controllers.InsurancePanels;
using Aurora.AdministrationService.API.Enum;
using Aurora.AdministrationService.API.Helper;
using Aurora.AdministrationService.API.Models.Dto.InsurancePanels.InsurancePanel;
using Aurora.AdministrationService.API.Services.IService.InsurancePanels;
using Aurora.AdministrationService.CrossCutting.CommonModels;
using Aurora.AdministrationService.CrossCutting.Constants;
using FluentAssertions;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Moq;

namespace Aurora.AdministrationService.Tests.API.Controllers.InsurancePanels
{
    public class InsurancePanelControllerTests
    {
        private readonly Mock<IInsurancePanelQueryService> _insuranccePanelServiceMock;
        private readonly InsurancePanelController _controller;
        private readonly Mock<IRegionCodeValidationHelper> _regionCodeValidationHelperMock;

        public InsurancePanelControllerTests()
        {
            _insuranccePanelServiceMock = new Mock<IInsurancePanelQueryService>();
            _regionCodeValidationHelperMock = new Mock<IRegionCodeValidationHelper>();
            _controller = new InsurancePanelController(_insuranccePanelServiceMock.Object, _regionCodeValidationHelperMock.Object);

        }

        #region GetAllSpecialities unit test cases

        /// <summary>
        /// Get AllSpecialities Returns200 WhenSuccessful
        /// </summary>
        /// <returns></returns>
        [Fact]
        public void GetAllInsurancePanels_Returns200_WhenSuccessful()
        {
            // Arrange
            var sucessresponse = new GenericResponseList<GetInsurancePanelMasterDto>() { HasError = false, IsSuccess = true, StatusCode = "200", Results = new List<GetInsurancePanelMasterDto>() };

            _insuranccePanelServiceMock.Setup(service => service.GetInsurancePanelMasterList()).Returns(sucessresponse);

            // Act
            var result =  _controller.GetAllInsurances();

            // Assert
            result.Should().BeOfType<OkObjectResult>()
                .Which.StatusCode.Should().Be(200);
        }

        /// <summary>
        /// GetAllInsurancePanels Returns 404 When No Records Found
        /// </summary>
        [Fact]
        public void GetAllInsurancePanels_Returns404_WhenNotFound()
        {
            // Arrange
            var notFoundResponse = new GenericResponseList<GetInsurancePanelMasterDto>()
            {
                HasError = true,
                IsSuccess = false,
                StatusCode = ResponceStatusCode.RecordNotFound.ToString(),
                Results = new List<GetInsurancePanelMasterDto>()
            };

            _insuranccePanelServiceMock
                .Setup(service => service.GetInsurancePanelMasterList())
                .Returns(notFoundResponse);

            // Act
            var result = _controller.GetAllInsurances();

            // Assert
            result.Should().BeOfType<NotFoundObjectResult>()
                .Which.StatusCode.Should().Be(404);
        }

        #endregion
        [Fact]
        public void SearchInsurance_ShouldReturnBadRequest_WhenRegionCodeIsInvalid()
        {
            // Arrange
            var validationResponse = new GenericResponse<string>
            {
                HasError = true,
                StatusCode = ResponseStatusCode.STATUS_BADREQUEST,
                IsSuccess = false,
                Message = "Invalid region code"
            };

            _regionCodeValidationHelperMock
                .Setup(x => x.VerifyRegionCodeHeader(It.IsAny<HttpRequest>()))
                .Returns(validationResponse);

            // Act
            var result = _controller.SearchInsurance("test");

            // Assert
            result.Should().BeOfType<BadRequestObjectResult>()
                .Which.Value.Should().BeEquivalentTo(validationResponse);
        }

        [Fact]
        public void SearchInsurance_ShouldReturnNotFound_WhenNoInsuranceFound()
        {
            // Arrange
            var noDataResponse = new GenericResponseList<GetInsurancePanelMasterDto>
            {
                HasError = false,
                IsSuccess = true,
                StatusCode = ResponceStatusCode.RecordNotFound.ToString(),
                Message = ResponseMessage.STATUS_NODATA,
                Results = new List<GetInsurancePanelMasterDto>()
            };

            _regionCodeValidationHelperMock
                .Setup(x => x.VerifyRegionCodeHeader(It.IsAny<HttpRequest>()))
                .Returns((GenericResponse<string>)null);

            _insuranccePanelServiceMock
                .Setup(x => x.SearchInsuranceList("dummy"))
                .Returns(noDataResponse);

            // Act
            var result = _controller.SearchInsurance("dummy");

            // Assert
            result.Should().BeOfType<NotFoundObjectResult>()
                .Which.Value.Should().BeEquivalentTo(noDataResponse);
        }

        [Fact]
        public void SearchInsurance_ShouldReturnOk_WhenInsuranceFound()
        {
            // Arrange
            var expectedResponse = new GenericResponseList<GetInsurancePanelMasterDto>
            {
                HasError = false,
                IsSuccess = true,
                StatusCode = ResponceStatusCode.Success.ToString(),
                Message = ResponseMessage.STATUS_SUCCESS,
                Results = new List<GetInsurancePanelMasterDto>
                {
                    new GetInsurancePanelMasterDto
                    {
                        Id = 1,
                        DebtorName = "ABC Insurance",
                        Logo = "logo.png"
                    }
                }
            };

            _regionCodeValidationHelperMock
                .Setup(x => x.VerifyRegionCodeHeader(It.IsAny<HttpRequest>()))
                .Returns((GenericResponse<string>)null);

            _insuranccePanelServiceMock
                .Setup(x => x.SearchInsuranceList("abc"))
                .Returns(expectedResponse);

            // Act
            var result = _controller.SearchInsurance("abc");

            // Assert
            result.Should().BeOfType<OkObjectResult>()
                .Which.Value.Should().BeEquivalentTo(expectedResponse);
        }

        [Fact]
        public void SearchInsurance_ShouldReturnOk_WhenSearchIsNull()
        {
            // Arrange
            var expectedResponse = new GenericResponseList<GetInsurancePanelMasterDto>
            {
                HasError = false,
                IsSuccess = true,
                StatusCode = ResponceStatusCode.Success.ToString(),
                Message = ResponseMessage.STATUS_SUCCESS,
                Results = new List<GetInsurancePanelMasterDto>
        {
            new GetInsurancePanelMasterDto { Id = 1, DebtorName = "XYZ", Logo = "logo.png" }
        }
            };

            _regionCodeValidationHelperMock
                .Setup(x => x.VerifyRegionCodeHeader(It.IsAny<HttpRequest>()))
                .Returns((GenericResponse<string>)null);

            _insuranccePanelServiceMock
                .Setup(x => x.SearchInsuranceList(null))
                .Returns(expectedResponse);

            // Act
            var result = _controller.SearchInsurance(null);

            // Assert
            result.Should().BeOfType<OkObjectResult>()
                .Which.Value.Should().BeEquivalentTo(expectedResponse);
        }
    }
}
