﻿using Aurora.AdministrationService.API.Controllers.ResourceMapping;
using Aurora.AdministrationService.API.Helper;
using Aurora.AdministrationService.API.Models.Dto.UserGroups.ResourceMapping;
using Aurora.AdministrationService.API.Services.IService.UserGroups.ResourceMapping;
using Aurora.AdministrationService.CrossCutting.CommonModels;
using Aurora.AdministrationService.CrossCutting.Constants;
using FluentAssertions;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Moq;

namespace Aurora.AdministrationService.Tests.API.Controllers.ResourceMapping
{
    public class ResourceMappingControllerTest
    {
        private readonly Mock<IResourceMappingCommandService> _mockResourceMappingCommandService;
        private readonly Mock<IResourceMappingQueryService> _mockResourceMappingQueryService;
        private readonly ResourceMappingController _controller;
        private readonly Mock<IRegionCodeValidationHelper> _regionHelperMock;

        public ResourceMappingControllerTest()
        {
            _regionHelperMock = new Mock<IRegionCodeValidationHelper>();
            _mockResourceMappingCommandService = new Mock<IResourceMappingCommandService>();
            _mockResourceMappingQueryService = new Mock<IResourceMappingQueryService>();
            _controller = new ResourceMappingController(_mockResourceMappingQueryService.Object, _mockResourceMappingCommandService.Object, _regionHelperMock.Object);
        }
        [Fact]
        public void GetResourceMappings_InvalidRegionCode_ReturnsBadRequest()
        {
            // Arrange
            _regionHelperMock
                .Setup(helper => helper.VerifyRegionCodeHeader(It.IsAny<HttpRequest>()))
                .Returns(new GenericResponse<string> { HasError = true, Message = "Invalid RegionCode" });

            // Act
            var result = _controller.GetResourceMappingList();

            // Assert
            var badRequestResult = result.Result as BadRequestObjectResult;
            badRequestResult.Should().NotBeNull();
            var response = badRequestResult?.Value as GenericResponse<string>;
            response.Should().NotBeNull();
            response?.HasError.Should().BeTrue();
            response?.Message.Should().Be("Invalid RegionCode");
        }

        [Fact]
        public void CreateResourceMapping_InvalidRegionCode_ReturnsBadRequest()
        {
            // Arrange
            var resourceMapping = new ResourceMappingDto()
            {
                Code = "test",
                ParentID = 1,
                IsScreenRequired = true,
                ResourceName = "test",
                CategoryID = 1,
                CSS = "test",
                ControllerAction = "test",
                Definition = "test",
                Display = "test",
                ICON = "test",
                ResourceTypeID = 1,
                SEQ = 1,
                SubCategoryID = 1,
                URL = "test",
                Source = "test",
            };
            _regionHelperMock
                .Setup(helper => helper.VerifyRegionCodeHeader(It.IsAny<HttpRequest>()))
                .Returns(new GenericResponse<string> { HasError = true, Message = "Invalid RegionCode" });

            // Act
            var result = _controller.CreateResourceMapping(resourceMapping);

            // Assert
            var badRequestResult = result?.Result as BadRequestObjectResult;
            badRequestResult.Should().NotBeNull();
            var response = badRequestResult?.Value as GenericResponse<string>;
            response.Should().NotBeNull();
            response?.HasError.Should().BeTrue();
            response?.Message.Should().Be("Invalid RegionCode");
        }

        [Fact]
        public async Task GetResourceMappingById_InvalidRegionCode_ReturnsBadRequest()
        {
            // Arrange
            _regionHelperMock
                .Setup(helper => helper.VerifyRegionCodeHeader(It.IsAny<HttpRequest>()))
                .Returns(new GenericResponse<string> { HasError = true, Message = "Invalid RegionCode" });

            // Act
            var result = await _controller.GetResourceMappingById(1);

            // Assert
            var badRequestResult = result.Result as BadRequestObjectResult;

            badRequestResult.Should().NotBeNull();
            var response = badRequestResult?.Value as GenericResponse<string>;
            response.Should().NotBeNull();
            response?.HasError.Should().BeTrue();
            response?.Message.Should().Be("Invalid RegionCode");
        }

        [Fact]
        public void UpdateResourceMappingDetails_InvalidRegionCode_ReturnsBadRequest()
        {
            // Arrange
            int id = 1;
            var resourceMapping = new UpdateResourceMappingRequest()
            {
                Id = 1,
                Code = "test",
                ParentID = 1,
                IsScreenRequired = true,
                ResourceName = "test",
                CategoryID = 1,
                CSS = "test",
                ControllerAction = "test",
                Definition = "test",
                Display = "test",
                ICON = "test",
                ResourceTypeID = 1,
                SEQ = 1,
                SubCategoryID = 1,
                URL = "test",
                Source = "test",
            };
            _regionHelperMock
                .Setup(helper => helper.VerifyRegionCodeHeader(It.IsAny<HttpRequest>()))
                .Returns(new GenericResponse<string> { HasError = true, Message = "Invalid RegionCode" });

            // Act
            var result = _controller.UpdateResourceMappingDetails(id, resourceMapping);

            // Assert
            var badRequestResult = result?.Result as BadRequestObjectResult;
            badRequestResult.Should().NotBeNull();
            var response = badRequestResult?.Value as GenericResponse<string>;
            response.Should().NotBeNull();
            response?.HasError.Should().BeTrue();
            response?.Message.Should().Be("Invalid RegionCode");
        }

        [Fact]
        public async Task CreateResourceMapping_ShouldReturnSuccessResponse_WhenIsAdded()
        {
            // Arrange
            var resourceMapping = new ResourceMappingDto()
            {
                Code = "test",
                ParentID = 1,
                IsScreenRequired = true,
                ResourceName = "test",
                CategoryID = 1,
                CSS = "test",
                ControllerAction = "test",
                Definition = "test",
                Display = "test",
                ICON = "test",
                ResourceTypeID = 1,
                SEQ = 1,
                SubCategoryID = 1,
                URL = "test",
                Source = "test",
            };
            _mockResourceMappingCommandService.Setup(service => service.CreateResourceMappingAsync(resourceMapping)).ReturnsAsync(true);

            // Act
            var result = await _controller.CreateResourceMapping(resourceMapping) as OkObjectResult;
            var response = result?.Value as GenericResponse<string>;

            // Assert
            result.Should().NotBeNull();
            result?.StatusCode.Should().Be(200);
            response?.IsSuccess.Should().BeTrue();
            response?.StatusCode.Should().Be(ResponseStatusCode.STATUS_SUCCESS);
            response?.Message.Should().Be(ResponseMessage.STATUS_DATA_ADDED);
        }

        [Fact]
        public void GetResourceMappingList_ShouldReturnResourceMappingList()
        {
            // Arrange
            var resourceMappingList = new List<GetResourceMappingDto> { new GetResourceMappingDto() {
                Code = "test",
                ParentID = 1,
                IsScreenRequired = true,
                ResourceName = "test",
                CategoryID = 1,
                CSS = "test",
                ControllerAction = "test",
                Definition = "test",
                Display = "test",
                ICON = "test",
                ResourceTypeID = 1,
                SEQ = 1,
                SubCategoryID = 1,
                URL = "test",
                Source = "test",
            } };
            _mockResourceMappingQueryService.Setup(service => service.GetResourceMappingList()).Returns(resourceMappingList);

            // Act
            var result = _controller.GetResourceMappingList();
            var okresult = result?.Result as OkObjectResult;
            var response = okresult?.Value as GenericResponseList<GetResourceMappingDto>;

            // Assert
            result.Should().NotBeNull();
            response?.StatusCode.Should().Be("200");
            response?.IsSuccess.Should().BeTrue();
            response?.StatusCode.Should().Be(ResponseStatusCode.STATUS_SUCCESS);
            response?.Message.Should().Be(ResponseMessage.STATUS_DATA_FOUND);
            response?.TotalCount.Should().Be(resourceMappingList.Count);

        }

        [Fact]
        public async Task GetResourceMappingById_ShouldReturnNull_WhenIdIsInvalid()
        {
            // Act
            var result = await _controller.GetResourceMappingById(null);
            var response = result.Value as GenericResponse<GetResourceMappingDetailDto>;

            // Assert
            result.Should().NotBeNull();
            response.Should().BeNull();

        }

        [Fact]
        public async Task GetResourceMappingById_ShouldReturnNotFound_WhenDoesNotExist()
        {
            // Arrange
            var id = 1;
            GetResourceMappingDetailDto resourceMappingDetailDto = new GetResourceMappingDetailDto()
            {
                Code = "test",
                ParentID = 1,
                IsScreenRequired = true,
                ResourceName = "test",
                CategoryID = 1,
                CSS = "test",
                ControllerAction = "test",
                Definition = "test",
                Display = "test",
                ICON = "test",
                ResourceTypeID = 1,
                SEQ = 1,
                SubCategoryID = 1,
                URL = "test",
                Source = "test",
            };
            _mockResourceMappingQueryService
              .Setup(service => service.GetResourceMappingById(2)).ReturnsAsync(resourceMappingDetailDto);

            // Act
            var result = await _controller.GetResourceMappingById(id);
            var okobjectresult = result?.Result as OkObjectResult;
            var response = okobjectresult?.Value as GenericResponse<GetResourceMappingDetailDto>;

            // Assert
            result.Should().NotBeNull();
            response?.IsSuccess.Should().BeTrue();
            response?.StatusCode.Should().Be(ResponseStatusCode.STATUS_NOTFOUND);
            response?.Message.Should().Be(ResponseMessage.STATUS_NODATA);
        }

        [Fact]
        public async Task UpdateResourceMappingDetails_ShouldReturnBadRequest_WhenAlreadyExists()
        {
            // Arrange
            int id = 1;
            var resourceMapping = new UpdateResourceMappingRequest()
            {
                Id = 1,
                Code = "test",
                ParentID = 1,
                IsScreenRequired = true,
                ResourceName = "test",
                CategoryID = 1,
                CSS = "test",
                ControllerAction = "test",
                Definition = "test",
                Display = "test",
                ICON = "test",
                ResourceTypeID = 1,
                SEQ = 1,
                SubCategoryID = 1,
                URL = "test",
                Source = "test",
            };
            _mockResourceMappingQueryService.Setup(service => service.IsResourceMappingAlreadyExist(id)).ReturnsAsync((true, ResponseMessage.STATUS_NODATA));

            // Act
            var result = await _controller.UpdateResourceMappingDetails(id, resourceMapping);

            // Assert
            result.Should().NotBeNull();

        }

        [Fact]
        public async Task UpdateResourceMappingDetails_ResourceMappingNotFound_ReturnsNotFound()
        {
            // Arrange
            int resourceMappingId = 1;
            var resourceMappingRequest = new UpdateResourceMappingRequest()
            {
                Id = resourceMappingId,
                Code = "test",
                ParentID = 1,
                IsScreenRequired = true,
                ResourceName = "test",
                CategoryID = 1,
                CSS = "test",
                ControllerAction = "test",
                Definition = "test",
                Display = "test",
                ICON = "test",
                ResourceTypeID = 1,
                SEQ = 1,
                SubCategoryID = 1,
                URL = "test",
                Source = "test",
            };
            Domain.V1.Entities.UserGroups.ResourceMapping resourceMapping = null;
            _mockResourceMappingQueryService
                .Setup(service => service.FindResourceMappingById(resourceMappingId))
                .ReturnsAsync(resourceMapping);

            // Act
            var result = await _controller.UpdateResourceMappingDetails(resourceMappingId, resourceMappingRequest);

            // Assert
            var actionResult = Assert.IsType<NotFoundObjectResult>(result);
            var response = Assert.IsType<GenericResponse<string>>(actionResult.Value);
            Assert.Equal(ResponseStatusCode.STATUS_NOTFOUND, response.StatusCode);
            Assert.Equal(ResponseMessage.STATUS_NODATA, response.Message);
        }

        [Fact]
        public async Task UpdateResourceMappingDetails_UpdateSuccessful_ReturnsOk()
        {
            // Arrange
            int resourceMappingId = 1;
            var resourceMappingRequest = new UpdateResourceMappingRequest()
            {
                Id = 1,
                Code = "test",
                ParentID = 1,
                IsScreenRequired = true,
                ResourceName = "test",
                CategoryID = 1,
                CSS = "test",
                ControllerAction = "test",
                Definition = "test",
                Display = "test",
                ICON = "test",
                ResourceTypeID = 1,
                SEQ = 1,
                SubCategoryID = 1,
                URL = "test",
                Source = "test",
            };
            var existingResourceMapping = new Domain.V1.Entities.UserGroups.ResourceMapping
            {
                Id = resourceMappingId,
                Code = "test",
                ParentID = 1,
                IsScreenRequired = true,
                ResourceName = "test",
                CategoryID = 1,
                CSS = "test",
                ControllerAction = "test",
                Definition = "test",
                Display = "test",
                ICON = "test",
                ResourceTypeID = 1,
                SEQ = 1,
                SubCategoryID = 1,
                URL = "test",
                Source = "test",
                CreatedBy = "Admin",
                CreatedDate = DateTime.UtcNow,
                IsDeleted = false
            };

            _mockResourceMappingQueryService
                .Setup(service => service.FindResourceMappingById(resourceMappingId))
                .ReturnsAsync(existingResourceMapping);

            _mockResourceMappingCommandService
                .Setup(service => service.UpdateResourceMappingAsync(resourceMappingRequest, existingResourceMapping))
                .ReturnsAsync(true);

            // Act
            var result = await _controller.UpdateResourceMappingDetails(resourceMappingId, resourceMappingRequest);

            // Assert
            var actionResult = Assert.IsType<OkObjectResult>(result);
            var response = Assert.IsType<GenericResponse<string>>(actionResult.Value);
            Assert.Equal(ResponseStatusCode.STATUS_SUCCESS, response.StatusCode);
            Assert.Equal(ResponseMessage.STATUS_DATA_UPDATED, response.Message);
            Assert.Equal(CommonConstants.SUCCESS, response.MessageType);
        }

        [Fact]
        public async Task UpdateResourceMappingDetails_UpdateFailed_ReturnsOkWithErrorMessage()
        {
            // Arrange
            int resourceMappingId = 1;
            var resourceMappingRequest = new UpdateResourceMappingRequest()
            {
                Id = resourceMappingId,
                Code = "test",
                ParentID = 1,
                IsScreenRequired = true,
                ResourceName = "test",
                CategoryID = 1,
                CSS = "test",
                ControllerAction = "test",
                Definition = "test",
                Display = "test",
                ICON = "test",
                ResourceTypeID = 1,
                SEQ = 1,
                SubCategoryID = 1,
                URL = "test",
                Source = "test",
            };
            var existingResourceMapping = new Domain.V1.Entities.UserGroups.ResourceMapping
            {
                Id = resourceMappingId,
                Code = "test",
                ParentID = 1,
                IsScreenRequired = true,
                ResourceName = "test",
                CategoryID = 1,
                CSS = "test",
                ControllerAction = "test",
                Definition = "test",
                Display = "test",
                ICON = "test",
                ResourceTypeID = 1,
                SEQ = 1,
                SubCategoryID = 1,
                URL = "test",
                Source = "test",
                CreatedBy = "Admin",
                CreatedDate = DateTime.UtcNow,
                IsDeleted = false
            };

            _mockResourceMappingQueryService
                .Setup(service => service.FindResourceMappingById(resourceMappingId))
                .ReturnsAsync(existingResourceMapping); // Simulate resourceMapping found

            _mockResourceMappingCommandService
                .Setup(service => service.UpdateResourceMappingAsync(resourceMappingRequest, existingResourceMapping))
                .ReturnsAsync(false); // Simulate update failure

            // Act
            var result = await _controller.UpdateResourceMappingDetails(resourceMappingId, resourceMappingRequest);

            // Assert
            var actionResult = Assert.IsType<OkObjectResult>(result);
            Assert.Equal(ResponseStatusCode.STATUS_SUCCESS, actionResult.StatusCode.ToString());
        }

        [Fact]
        public async Task GetResourceMappingById_ReturnsOk_WhenResourceMappingIsFound()
        {
            // Arrange
            int resourceMappingId = 1;
            var expectedResourceMapping = new GetResourceMappingDetailDto
            {
                Id = resourceMappingId,
                Code = "test",
                ParentID = 1,
                IsScreenRequired = true,
                ResourceName = "test",
                CategoryID = 1,
                CSS = "test",
                ControllerAction = "test",
                Definition = "test",
                Display = "test",
                ICON = "test",
                ResourceTypeID = 1,
                SEQ = 1,
                SubCategoryID = 1,
                URL = "test",
                Source = "test",
                IsDeleted = false,
            };
            _mockResourceMappingQueryService.Setup(s => s.GetResourceMappingById(resourceMappingId)).ReturnsAsync(expectedResourceMapping);

            // Act
            var result = await _controller.GetResourceMappingById(resourceMappingId);

            // Assert
            var actionResult = Assert.IsType<ActionResult<GenericResponse<GetResourceMappingDetailDto>>>(result);
            var okResult = Assert.IsType<OkObjectResult>(actionResult.Result);
            var response = Assert.IsType<GenericResponse<GetResourceMappingDetailDto>>(okResult.Value);
            Assert.True(response.IsSuccess);
            Assert.Equal(ResponseStatusCode.STATUS_SUCCESS, response.StatusCode);
            Assert.Equal(ResponseMessage.STATUS_DATA_FOUND, response.Message);
            Assert.Equal(expectedResourceMapping, response.Result);
        }
    }
}
