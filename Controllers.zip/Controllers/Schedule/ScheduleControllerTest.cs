﻿using Aurora.AdministrationService.API.Controllers.Schedule;
using Aurora.AdministrationService.API.Helper;
using Aurora.AdministrationService.API.Models.RequestModels.Leaves;
using Aurora.AdministrationService.API.Models.RequestModels.Schedules;
using Aurora.AdministrationService.API.Models.ResponseModels.Schedules;
using Aurora.AdministrationService.API.Services.IService.Schedule;
using Aurora.AdministrationService.CrossCutting.CommonModels;
using Aurora.AdministrationService.CrossCutting.Constants;
using FluentAssertions;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Moq;
using static Aurora.AdministrationService.CrossCutting.Constants.CommonConstants;
using static Aurora.AdministrationService.Tests.API.Services.Schedule.ScheduleQueryServiceTests;
using Aurora.AdministrationService.CrossCutting.Extensions;
using Microsoft.Graph;
using Aurora.AdministrationService.Domain.CommonModels;
using Azure.Core;
using Microsoft.CodeAnalysis.Emit;
using Aurora.AdministrationService.Domain.V1.Entities.PractitionerRoles;

namespace Aurora.AdministrationService.Tests.API.Controllers.Schedule
{
    public class ScheduleControllerTests
    {
        private readonly ScheduleController _controller;
        private readonly Mock<IScheduleCommandService> _mockScheduleCommandService;
        private readonly Mock<IScheduleQueryService> _scheduleQueryServiceMock;
        private readonly Mock<IRegionCodeValidationHelper> _mockRegionCodeValidationHelper;

        public ScheduleControllerTests()
        {
            _scheduleQueryServiceMock = new Mock<IScheduleQueryService>();
            _mockScheduleCommandService = new Mock<IScheduleCommandService>();
            _mockRegionCodeValidationHelper = new Mock<IRegionCodeValidationHelper>();

            _controller = new ScheduleController(
                _mockScheduleCommandService.Object,
                _scheduleQueryServiceMock.Object,
                _mockRegionCodeValidationHelper.Object
            );

            _controller.ControllerContext = new ControllerContext
            {
                HttpContext = new DefaultHttpContext()
            };
        }

        [Fact]
        public async Task UpdateScheduleLeave_ReturnsOk_WhenSuccessful()
        {
            // Arrange
            var request = new ScheduleLeavesRequestDto { practitionerId = 1, LocationResourceId = "LOC-001" };
            _mockRegionCodeValidationHelper
                .Setup(helper => helper.VerifyRegionCodeHeader(It.IsAny<HttpRequest>()))
                .Returns((GenericResponse<string>)null); // No error

            _scheduleQueryServiceMock
                .Setup(service => service.HasValidPractitionerIdentifier(request))
                .Returns(new List<PractitionerIdentifierRequestDto>()); // Valid identifier

            _mockScheduleCommandService
                .Setup(service => service.UpdateScheduleLeaveAsync(request))
                .ReturnsAsync((true, null)); // Success

            // Act
            var result = await _controller.UpdateScheduleLeave(request);

            // Assert
            result.Should().BeOfType<OkObjectResult>();
            var okResult = result as OkObjectResult;

            okResult!.Value.Should().BeOfType<GenericResponse<string>>();
            var response = okResult.Value as GenericResponse<string>;

            response!.IsSuccess.Should().BeTrue();
            response.HasError.Should().BeFalse();
            response.Message.Should().Be(ResponseMessage.STATUS_DATA_UPDATED);
        }
        [Fact]
        public async Task UpdateScheduleLeave_ReturnsBadRequest_WhenRegionCodeInvalid()
        {
            // Arrange
            _mockRegionCodeValidationHelper
                .Setup(helper => helper.VerifyRegionCodeHeader(It.IsAny<HttpRequest>()))
                .Returns(new GenericResponse<string> { HasError = true });

            var request = new ScheduleLeavesRequestDto
            {
                practitionerId = 1,
                LocationResourceId = "LOC-001",
                Action = "create",
                Type = "Schedule",
                NewOverrides = "test",
                RemovedOverrides = "test",
            };

            // Act
            var result = await _controller.UpdateScheduleLeave(request);

            // Assert
            result.Should().BeOfType<BadRequestObjectResult>();
        }
        [Fact]
        public async Task UpdateScheduleLeave_ReturnsInternalServerError_WhenCreationFails()
        {
            // Arrange
            var request = new ScheduleLeavesRequestDto { practitionerId = 1, LocationResourceId = "LOC-001" };
            _mockRegionCodeValidationHelper
                .Setup(helper => helper.VerifyRegionCodeHeader(It.IsAny<HttpRequest>()))
                .Returns((GenericResponse<string>)null); // No error

            _scheduleQueryServiceMock
                .Setup(service => service.HasValidPractitionerIdentifier(request))
                .Returns(new List<PractitionerIdentifierRequestDto>()); // Valid identifier

            _mockScheduleCommandService
                .Setup(service => service.UpdateScheduleLeaveAsync(request))
                .ReturnsAsync((false, "Database error")); // Failure

            // Act
            var result = await _controller.UpdateScheduleLeave(request);

            // Assert
            var badRequestResult = Assert.IsType<BadRequestObjectResult>(result);
            var response = Assert.IsType<GenericResponse<string>>(badRequestResult.Value);
            Assert.False(response.IsSuccess);
            Assert.True(response.HasError);
        }
        //Clone
        [Fact]
        public async Task CloneScheduleLeave_Should_ReturnOk_WhenCommandSucceeds()
        {
            // Arrange

            _mockRegionCodeValidationHelper
             .Setup(x => x.VerifyRegionCodeHeader(It.IsAny<HttpRequest>()))
             .Returns((GenericResponse<string>)null);
            _scheduleQueryServiceMock
                .Setup(x => x.IsDuplicateLeaveAsync(It.IsAny<ScheduleLeavesRequestDto>()))
                .ReturnsAsync(false);

            _scheduleQueryServiceMock
                .Setup(x => x.HasValidPractitionerIdentifier(It.IsAny<ScheduleLeavesRequestDto>()))
                .Returns(new List<PractitionerIdentifierRequestDto>());

            _mockScheduleCommandService
                .Setup(x => x.CloneScheduleLeaveAsync(It.IsAny<ScheduleLeavesRequestDto>()))
                .ReturnsAsync((true, ResponseMessage.SUCCESS_VALUE));

            var request = new ScheduleLeavesRequestDto { practitionerId = 1, LocationResourceId = "LOC-001" };

            // Act
            var result = await _controller.CloneScheduleLeave(request);

            // Assert
            var okResult = result.Should().BeOfType<OkObjectResult>().Subject;
            var value = okResult.Value.Should().BeOfType<GenericResponse<string>>().Subject;
            value.IsSuccess.Should().BeTrue();
            value.StatusCode.Should().Be(ResponseStatusCode.STATUS_SUCCESS);
            value.Message.Should().Be(ResponseMessage.SUCCESS_VALUE);
        }
        [Fact]
        public async Task CloneScheduleLeave_Should_ReturnBadRequest_WhenDuplicateLeave()
        {
            // Arrange
            _mockRegionCodeValidationHelper
                .Setup(x => x.VerifyRegionCodeHeader(It.IsAny<HttpRequest>()))
                .Returns((GenericResponse<string>)null);

            _scheduleQueryServiceMock
                .Setup(x => x.IsDuplicateLeaveAsync(It.IsAny<ScheduleLeavesRequestDto>()))
                .ReturnsAsync(true);

            var request = new ScheduleLeavesRequestDto { practitionerId = 1, LocationResourceId = "LOC-001" };

            // Act
            var result = await _controller.CloneScheduleLeave(request);

            // Assert
            var badRequest = result.Should().BeOfType<BadRequestObjectResult>().Subject;
            var value = badRequest.Value.Should().BeOfType<GenericResponse<string>>().Subject;
            value.HasError.Should().BeTrue();
            value.Message.Should().Be(ResponseMessage.DUPLICATE_LEAVE_NOTALLOWED);
        }

        [Fact]
        public async Task CloneScheduleLeave_ReturnsBadRequest_WhenRegionCodeInvalid()
        {
            // Arrange
            _mockRegionCodeValidationHelper
                .Setup(helper => helper.VerifyRegionCodeHeader(It.IsAny<HttpRequest>()))
                .Returns(new GenericResponse<string> { HasError = true });

            var request = new ScheduleLeavesRequestDto
            {
                practitionerId = 1,
                LocationResourceId = "LOC-001",
                Action = "create",
                Type = "Schedule",
                NewOverrides = "test",
                RemovedOverrides = "test",
            };

            // Act
            var result = await _controller.CloneScheduleLeave(request);

            // Assert
            Assert.IsType<BadRequestObjectResult>(result);
        }

        [Fact]
        public async Task CloneScheduleLeave_ReturnsBadRequest_WhenLeaveIsDuplicate()
        {
            // Arrange
            var request = new ScheduleLeavesRequestDto { practitionerId = 1, LocationResourceId = "LOC-001" };
            _mockRegionCodeValidationHelper
                .Setup(helper => helper.VerifyRegionCodeHeader(It.IsAny<HttpRequest>()))
                .Returns((GenericResponse<string>)null); // No error

            _scheduleQueryServiceMock
                .Setup(service => service.HasValidPractitionerIdentifier(request))
                .Returns(new List<PractitionerIdentifierRequestDto>());


            _scheduleQueryServiceMock
                .Setup(service => service.IsDuplicateLeaveAsync(request))
                .ReturnsAsync(true); // Duplicate leave

            // Act
            var result = await _controller.CloneScheduleLeave(request);

            // Assert
            var badRequestResult = Assert.IsType<BadRequestObjectResult>(result);
            var response = Assert.IsType<GenericResponse<string>>(badRequestResult.Value);
            Assert.False(response.IsSuccess);
            Assert.True(response.HasError);
            Assert.Equal(ResponseMessage.DUPLICATE_LEAVE_NOTALLOWED, response.Message);
        }

        [Fact]
        public async Task CloneScheduleLeave_ReturnsInternalServerError_WhenCreationFails()
        {
            // Arrange
            var request = new ScheduleLeavesRequestDto { practitionerId = 1, LocationResourceId = "LOC-001" };
            _mockRegionCodeValidationHelper
                .Setup(helper => helper.VerifyRegionCodeHeader(It.IsAny<HttpRequest>()))
                .Returns((GenericResponse<string>)null); // No error

            _scheduleQueryServiceMock
                .Setup(service => service.HasValidPractitionerIdentifier(request))
                .Returns(new List<PractitionerIdentifierRequestDto>()); // Valid identifier

            _scheduleQueryServiceMock
                .Setup(service => service.IsDuplicateLeaveAsync(request))
                .ReturnsAsync(false); // No duplicate

            _mockScheduleCommandService
                .Setup(service => service.CloneScheduleLeaveAsync(request))
                .ReturnsAsync((false, "Database error")); // Failure

            // Act
            var result = await _controller.CreateScheduleLeave(request);

            // Assert
            var badRequestResult = Assert.IsType<BadRequestObjectResult>(result);
            var response = Assert.IsType<GenericResponse<string>>(badRequestResult.Value);
            Assert.False(response.IsSuccess);
            Assert.True(response.HasError);
        }
        [Fact]
        public async Task CloneScheduleLeave_Should_ReturnBadRequest_WhenResultIsFalse()
        {
            // Arrange
            var expectedErrorMessage = "Something went wrong during cloning";

            _mockRegionCodeValidationHelper
                .Setup(x => x.VerifyRegionCodeHeader(It.IsAny<HttpRequest>()))
                .Returns((GenericResponse<string>)null);

            _scheduleQueryServiceMock
                .Setup(x => x.IsDuplicateLeaveAsync(It.IsAny<ScheduleLeavesRequestDto>()))
                .ReturnsAsync(false);

            _scheduleQueryServiceMock
                .Setup(x => x.HasValidPractitionerIdentifier(It.IsAny<ScheduleLeavesRequestDto>()))
                .Returns(new List<PractitionerIdentifierRequestDto>());

            _mockScheduleCommandService
                .Setup(x => x.CloneScheduleLeaveAsync(It.IsAny<ScheduleLeavesRequestDto>()))
                .ReturnsAsync((false, expectedErrorMessage)); // Force the `!result` case

            var request = new ScheduleLeavesRequestDto { practitionerId = 1, LocationResourceId = "LOC-001" };

            // Act
            var result = await _controller.CloneScheduleLeave(request);

            // Assert
            var badRequestResult = result.Should().BeOfType<BadRequestObjectResult>().Subject;
            var response = badRequestResult.Value.Should().BeOfType<GenericResponse<string>>().Subject;

            response.IsSuccess.Should().BeFalse();
            response.HasError.Should().BeTrue();
            response.StatusCode.Should().Be(ResponseStatusCode.STATUS_INTERNAL_SERVER_ERROR);
            response.Message.Should().Be(expectedErrorMessage);
        }

        //Create
        [Fact]
        public async Task CreateScheduleLeave_ReturnsOk_WhenSuccessful()
        {
            // Arrange
            var request = new ScheduleLeavesRequestDto { practitionerId = 1, LocationResourceId = "LOC-001" };
            _mockRegionCodeValidationHelper
                .Setup(helper => helper.VerifyRegionCodeHeader(It.IsAny<HttpRequest>()))
                .Returns((GenericResponse<string>)null); // No error

            _scheduleQueryServiceMock
                .Setup(service => service.HasValidPractitionerIdentifier(request))
                .Returns(new List<PractitionerIdentifierRequestDto>()); // Valid identifier

            _scheduleQueryServiceMock
                .Setup(service => service.IsDuplicateLeaveAsync(request))
                .ReturnsAsync(false); // No duplicate

            _mockScheduleCommandService
                .Setup(service => service.CreateScheduleLeaveAsync(request))
                .ReturnsAsync((true, null)); // Success

            // Act
            var result = await _controller.CreateScheduleLeave(request);

            // Assert
            var okResult = Assert.IsType<OkObjectResult>(result);
            var response = Assert.IsType<GenericResponse<string>>(okResult.Value);
            Assert.True(response.IsSuccess);
            Assert.False(response.HasError);
            Assert.Equal(ResponseMessage.SUCCESS_VALUE, response.Message);
        }
        [Fact]
        public async Task CreateScheduleLeave_ReturnsBadRequest_WhenRegionCodeInvalid()
        {
            // Arrange
            _mockRegionCodeValidationHelper
                .Setup(helper => helper.VerifyRegionCodeHeader(It.IsAny<HttpRequest>()))
                .Returns(new GenericResponse<string> { HasError = true });

            var request = new ScheduleLeavesRequestDto
            {
                practitionerId = 1,
                LocationResourceId = "LOC-001",
                Action = "create",
                Type = "Schedule",
                NewOverrides = "test",
                RemovedOverrides = "test",
            };

            // Act
            var result = await _controller.CreateScheduleLeave(request);

            // Assert
            Assert.IsType<BadRequestObjectResult>(result);
        }

        [Fact]
        public async Task CreateScheduleLeave_ReturnsBadRequest_WhenLeaveIsDuplicate()
        {
            // Arrange
            var request = new ScheduleLeavesRequestDto { practitionerId = 1, LocationResourceId = "LOC-001" };
            _mockRegionCodeValidationHelper
                .Setup(helper => helper.VerifyRegionCodeHeader(It.IsAny<HttpRequest>()))
                .Returns((GenericResponse<string>)null); // No error

            _scheduleQueryServiceMock
                .Setup(service => service.HasValidPractitionerIdentifier(request))
                .Returns(new List<PractitionerIdentifierRequestDto>());


            _scheduleQueryServiceMock
                .Setup(service => service.IsDuplicateLeaveAsync(request))
                .ReturnsAsync(true); // Duplicate leave

            // Act
            var result = await _controller.CreateScheduleLeave(request);

            // Assert
            var badRequestResult = Assert.IsType<BadRequestObjectResult>(result);
            var response = Assert.IsType<GenericResponse<string>>(badRequestResult.Value);
            Assert.False(response.IsSuccess);
            Assert.True(response.HasError);
            Assert.Equal(ResponseMessage.DUPLICATE_LEAVE_NOTALLOWED, response.Message);
        }

        [Fact]
        public async Task CreateScheduleLeave_ReturnsInternalServerError_WhenCreationFails()
        {
            // Arrange
            var request = new ScheduleLeavesRequestDto { practitionerId = 1, LocationResourceId = "LOC-001" };
            _mockRegionCodeValidationHelper
                .Setup(helper => helper.VerifyRegionCodeHeader(It.IsAny<HttpRequest>()))
                .Returns((GenericResponse<string>)null); // No error

            _scheduleQueryServiceMock
                .Setup(service => service.HasValidPractitionerIdentifier(request))
                .Returns(new List<PractitionerIdentifierRequestDto>()); // Valid identifier

            _scheduleQueryServiceMock
                .Setup(service => service.IsDuplicateLeaveAsync(request))
                .ReturnsAsync(false); // No duplicate

            _mockScheduleCommandService
                .Setup(service => service.CreateScheduleLeaveAsync(request))
                .ReturnsAsync((false, "Database error")); // Failure

            // Act
            var result = await _controller.CreateScheduleLeave(request);

            // Assert
            var badRequestResult = Assert.IsType<BadRequestObjectResult>(result);
            var response = Assert.IsType<GenericResponse<string>>(badRequestResult.Value);
            Assert.False(response.IsSuccess);
            Assert.True(response.HasError);
            Assert.Equal("Database error", response.Message);
        }

        #region GetAllUserGroups unit test cases using Theory

        /// <summary>
        /// GetAllUserGroups Returns Expected Status Based on Region Code Validation
        /// </summary>
        /// <param name="verifyStatus"></param>
        [Theory]
        [InlineData(true)]
        [InlineData(false)]
        public void GetAllUserGroups_ShouldReturnExpectedStatus_WhenRegionCodeValidationIsPerformed(bool verifyStatus)
        {
            // Arrange: Set up region code validation response based on verifyStatus
            if (verifyStatus)
            {
                _mockRegionCodeValidationHelper.Setup(r => r.VerifyRegionCodeHeader(It.IsAny<HttpRequest>()))
                    .Returns(new GenericResponse<string> { HasError = false });
            }
            else
            {
                _mockRegionCodeValidationHelper.Setup(r => r.VerifyRegionCodeHeader(It.IsAny<HttpRequest>()))
                    .Returns(new GenericResponse<string> { HasError = true });
            }

            var mockUserGroups = new List<GetAllUserGroupsResponse>
            {
                new GetAllUserGroupsResponse { Id = 1, GroupName = "Admin" },
                new GetAllUserGroupsResponse { Id = 2, GroupName = "User" }
            };
            var successResponse = new GenericResponseList<GetAllUserGroupsResponse>
            {
                StatusCode = "200",
                IsSuccess = true,
                Message = ResponseMessage.STATUS_SUCCESS,
                Results = mockUserGroups,
                TotalCount = mockUserGroups.Count,
                PageSize = 1,
                CurrentPage = 1,
                HasError = false
            };

            _scheduleQueryServiceMock.Setup(service => service.GetAllUserGroups()).Returns(mockUserGroups);

            // Act: Call the controller's GetAllUserGroups method
            var result = _controller.GetAllUserGroups() as ObjectResult;

            // Assert
            if (verifyStatus)
            {
                // Expecting successful response
                var response = Assert.IsType<OkObjectResult>(result);
                response.StatusCode.Should().Be(200);

                var responseValue = response.Value as GenericResponseList<GetAllUserGroupsResponse>;
                responseValue.Should().NotBeNull();
                responseValue.StatusCode.Should().Be("200");
                responseValue.IsSuccess.Should().BeTrue();
                responseValue.Results.Count().Should().Be(mockUserGroups.Count);
            }
            else
            {
                // Expecting BadRequest response due to failed region code validation
                var response = Assert.IsType<BadRequestObjectResult>(result);
                response.StatusCode.Should().Be(400);
            }
        }
        #endregion
        [Fact]
        public void GetAllHealthCareServices_ShouldReturnOk_WhenHealthCareServicesAreAvailable()
        {
            // Arrange
            var services = new List<GetAllHealthCareServicesResponseDto>
            {
                new GetAllHealthCareServicesResponseDto { Id = 1, Name = "Service 1" },
                new GetAllHealthCareServicesResponseDto { Id = 2, Name = "Service 2" }
            };
            _mockRegionCodeValidationHelper
               .Setup(helper => helper.VerifyRegionCodeHeader(It.IsAny<HttpRequest>()))
               .Returns(new GenericResponse<string> { HasError = false });

            _scheduleQueryServiceMock.Setup(hcs => hcs.GetHealthCareServices()).Returns(services);
            // Act
            var result = _controller.GetHealthCareServices();

            // Assert
            var okResult = Assert.IsType<OkObjectResult>(result);
            var response = Assert.IsType<GenericResponseList<GetAllHealthCareServicesResponseDto>>(okResult.Value);
            Assert.Equal(ResponseStatusCode.STATUS_SUCCESS, response.StatusCode);
            Assert.True(response.IsSuccess);
            Assert.Equal(services.Count, response.TotalCount);
            Assert.False(response.HasError);
        }

        [Fact]
        public void GetAllHealthCareServices_ShouldReturnNoData_WhenNoHealthCareServicesAvailable()
        {
            // Arrange
            var services = new List<GetAllHealthCareServicesResponseDto>(); // Empty list, no services
            _mockRegionCodeValidationHelper
              .Setup(helper => helper.VerifyRegionCodeHeader(It.IsAny<HttpRequest>()))
              .Returns(new GenericResponse<string> { HasError = false });

            _scheduleQueryServiceMock.Setup(hcs => hcs.GetHealthCareServices()).Returns(services);

            // Act
            var result = _controller.GetHealthCareServices();

            // Assert
            var okResult = Assert.IsType<OkObjectResult>(result);
            var response = Assert.IsType<GenericResponseList<GetAllHealthCareServicesResponseDto>>(okResult.Value);
            Assert.Equal(ResponseStatusCode.STATUS_SUCCESS, response.StatusCode);
            Assert.False(response.HasError);
            Assert.Equal(ResponseMessage.STATUS_NODATA, response.Message);
            Assert.Equal(0, response.TotalCount);
        }
        [Fact]
        public void GetAllHealthCareServices_ShouldReturnBadRequest_WhenRegionCodeValidationFails()
        {
            // Arrange
            var services = new List<GetAllHealthCareServicesResponseDto>();
            _mockRegionCodeValidationHelper
                .Setup(x => x.VerifyRegionCodeHeader(It.IsAny<HttpRequest>()))
                .Returns(new GenericResponse<string> { HasError = true });

            _scheduleQueryServiceMock.Setup(hcs => hcs.GetHealthCareServices()).Returns(services);

            // Act
            var result = _controller.GetHealthCareServices();

            // Assert
            result.Should().BeOfType<BadRequestObjectResult>()
                .Which.Value.Should().BeOfType<GenericResponse<string>>()
                .Which.HasError.Should().BeTrue();
        }
        [Fact]
        public void GetScheduleLeave_ReturnsBadRequest_WhenRegionCodeValidationFails()
        {
            // Arrange
            long practitionerId = 1;
            var locationResourceId = "1";
            var services = new List<TimeOffResponseDto>();
            _mockRegionCodeValidationHelper
                .Setup(x => x.VerifyRegionCodeHeader(It.IsAny<HttpRequest>()))
                .Returns(new GenericResponse<string> { HasError = true });

            _scheduleQueryServiceMock.Setup(hcs => hcs.GetScheduleLeaveService(practitionerId, locationResourceId)).Returns(services);

            // Act
            var result = _controller.GetScheduleLeave(practitionerId, locationResourceId);

            // Assert
            result.Should().BeOfType<BadRequestObjectResult>()
                .Which.Value.Should().BeOfType<GenericResponse<string>>()
                .Which.HasError.Should().BeTrue();
        }
        [Fact]
        public void GetScheduleLeave__ShouldReturnNoData_WhenNoServicesAvailable()
        {
            // Arrange
            long practitionerId = 1;
            var locationResourceId = "1";
            var services = new List<TimeOffResponseDto>(); // Empty list, no services
            _mockRegionCodeValidationHelper
              .Setup(helper => helper.VerifyRegionCodeHeader(It.IsAny<HttpRequest>()))
              .Returns(new GenericResponse<string> { HasError = false });

            _scheduleQueryServiceMock.Setup(hcs => hcs.GetScheduleLeaveService(practitionerId, locationResourceId)).Returns(services);

            // Act
            var result = _controller.GetScheduleLeave(practitionerId, locationResourceId);

            // Assert
            var okResult = Assert.IsType<OkObjectResult>(result);
            var response = Assert.IsType<GenericResponseList<TimeOffResponseDto>>(okResult.Value);
            Assert.Equal(ResponseStatusCode.STATUS_SUCCESS, response.StatusCode);
            Assert.False(response.HasError);
            Assert.Equal(ResponseMessage.STATUS_NODATA, response.Message);
            Assert.Equal(0, response.TotalCount);
        }
        [Fact]
        public void GetAlScheduleLeave_ShouldReturnOk_WhenAreAvailable()
        {
            // Arrange
            long practitionerId = 1;
            var locationResourceId = "1";
            var services = new List<TimeOffResponseDto>
            {
                new TimeOffResponseDto { Id = 1, Description = "Service 1" },
                new TimeOffResponseDto { Id = 2, Description = "Service 2" }
            };
            _mockRegionCodeValidationHelper
               .Setup(helper => helper.VerifyRegionCodeHeader(It.IsAny<HttpRequest>()))
            .Returns(new GenericResponse<string> { HasError = false });

            _scheduleQueryServiceMock.Setup(hcs => hcs.GetScheduleLeaveService(practitionerId, locationResourceId)).Returns(services);

            // Act
            var result = _controller.GetScheduleLeave(practitionerId, locationResourceId);

            // Assert
            var okResult = Assert.IsType<OkObjectResult>(result);
            var response = Assert.IsType<GenericResponseList<TimeOffResponseDto>>(okResult.Value);
            Assert.Equal(ResponseStatusCode.STATUS_SUCCESS, response.StatusCode);
            Assert.True(response.IsSuccess);
            Assert.Equal(services.Count, response.TotalCount);
            Assert.False(response.HasError);
        }

        #region CreateScheduleApi

        [Fact]
        public async Task CreateSchedule_ShouldReturnBadRequest_WhenRegionCodeValidationFails()
        {
            // Arrange
            _mockRegionCodeValidationHelper
                .Setup(x => x.VerifyRegionCodeHeader(It.IsAny<HttpRequest>()))
                .Returns(new GenericResponse<string> { HasError = true });

            var request = new CreateScheduleRequestDto
            {
                PractitionerId = 1,
                LocationId = "LOC001",
                Timezone = "UTC",
                SlotDuration = 10,
                SlotType = "Normal",
                BookableFor = "Group1,Group2",
                RequestableFor = "Group1",
                PractitionerAvailability = new PractitionerAvailabilityDto()
            };

            // Act
            var result = await _controller.CreateSchedule(request);

            // Assert
            // Assert
            result.Should().BeOfType<BadRequestObjectResult>()
                .Which.Value.Should().BeOfType<GenericResponse<string>>()
                .Which.HasError.Should().BeTrue();
        }

        [Fact]
        public async Task CreateSchedule_ShouldReturnBadRequest_WhenModelStateIsInvalid()
        {
            // Arrange
            _controller.ModelState.AddModelError("SlotType", "The field SlotType must be a string with a maximum length of 20.");
            var request = new CreateScheduleRequestDto
            {
                PractitionerId = 1,
                LocationId = "LOC001",
                Timezone = "UTC",
                SlotDuration = 10,
                SlotType = new string('A', 21),
                BookableFor = "Group1,Group2",
                RequestableFor = "Group1",
                PractitionerAvailability = new PractitionerAvailabilityDto()
            };

            // Act
            var result = await _controller.CreateSchedule(request);

            // Assert
            result.Should().BeOfType<BadRequestObjectResult>();
        }

        [Theory]
        [InlineData(0, "LOC001", 15, "2025-04-01", "2025-04-07", ValidationMessages.PRACTITIONERIDMUSTBEGREATERTHANZERO)]  // PractitionerId is 0
        [InlineData(1, "LOC001", 0, "2025-04-01", "2025-04-07", ValidationMessages.SLOTDURATIONMUSTBEGREATERTHANZERO)]  // SlotDuration is 0
        [InlineData(1, "LOC001", 15, "2025-04-10", "2025-04-07", ValidationMessages.SCHEDULESTARTDATEMUSTBEBEFORESCHEDULEENDDATE)]  // ScheduleStartDate >= ScheduleEndDate
        public async Task ValidatePractitionerAvailability_InvalidInputs_ReturnsExpectedError(long practitionerId, string locationId, int slotDuration, string scheduleStartDate, string scheduleEndDate, string expectedError)
        {
            DateTime parsedScheduleStartDate = DateTime.Parse(scheduleStartDate);
            DateTime parsedScheduleEndDate = DateTime.Parse(scheduleEndDate);
            string timezone = "Bukit/Mylasia";
            string slotType = "Consultation";
            string bookableFor = "1,2,3,4";
            string requestableFor = "5,6,7,8";

            var practitionerAvailability = new PractitionerAvailabilityDto
            {
                PractitionerRoleId = 1,
                ScheduleStartDate = parsedScheduleStartDate,
                ScheduleEndDate = parsedScheduleEndDate,
                Instructions = "Test Instructions",
                PractitionerAvailabilityDays = new List<PractitionerAvailabilityDayDto>
                {
                    new PractitionerAvailabilityDayDto
                    {
                        AvailabilityDay = "Monday",
                        DayStartTime = TimeSpan.FromHours(9),
                        DayEndTime = TimeSpan.FromHours(17),
                        PractitionerAvailabilityOccurances = new List<PractitionerAvailabilityOccuranceDto>
                        {
                            new PractitionerAvailabilityOccuranceDto
                            {
                                OccuranceType = "first"
                            }
                        },
                        PractitionerAvailabilityBreaks = new List<PractitionerAvailabilityBreakDto>
                        {
                            new PractitionerAvailabilityBreakDto
                            {
                                BreakTitle = "Lunch Break",
                                BreakStartTime = TimeSpan.FromHours(12),
                                BreakEndTime = TimeSpan.FromHours(13)
                            }
                        }
                    }
                }
            };

            var scheduleRequest = new CreateScheduleRequestDto
            {
                PractitionerId = practitionerId,
                LocationId = locationId,
                Timezone = timezone,
                SlotDuration = slotDuration,
                SlotType = slotType,
                BookableFor = bookableFor,
                RequestableFor = requestableFor,
                PractitionerAvailability = practitionerAvailability
            };

            var result = await _controller.CreateSchedule(scheduleRequest) as BadRequestObjectResult;

            // Extract the actual error message from the response
            var response = result?.Value as GenericResponse<string>;

            // Assert that the message in the response matches the expected error
            response?.Message.Should().Be(expectedError);
        }

        [Fact]
        public async Task ValidatePractitionerAvailability_InvalidDayTimes_ReturnsError()
        {
            //Arrange
            var request = new CreateScheduleRequestDto
            {
                PractitionerId = 1,
                LocationId = "LOC001",
                SlotDuration = 15,
                SlotType = "Consult",
                Timezone = "Bukit/MYS",
                RequestableFor = "1,2,3,4,5",
                BookableFor = "6,7,8,9",
                PractitionerAvailability = new PractitionerAvailabilityDto
                {
                    ScheduleStartDate = DateTime.Now,
                    ScheduleEndDate = DateTime.Now.AddDays(1),
                    PractitionerAvailabilityDays = new List<PractitionerAvailabilityDayDto>
                {
                    new PractitionerAvailabilityDayDto
                    {
                        AvailabilityDay = "Monday",
                        DayStartTime = TimeSpan.FromHours(10),
                        DayEndTime = TimeSpan.FromHours(9), // Invalid
                        PractitionerAvailabilityBreaks = new List<PractitionerAvailabilityBreakDto>()
                    }
                }
                }
            };

            //Act
            var result = await _controller.CreateSchedule(request) as BadRequestObjectResult;

            //Assert
            result.Should().NotBeNull(); // Ensure the result is not null
            result.Should().BeOfType<BadRequestObjectResult>();
        }

        [Fact]
        public async Task ValidatePractitionerAvailability_InvalidBreakTimes_ReturnsError()
        {
            var request = new CreateScheduleRequestDto
            {
                PractitionerId = 1,
                LocationId = "LOC001",
                SlotDuration = 15,
                SlotType = "Consult",
                Timezone = "Bukit/MYS",
                RequestableFor = "1,2,3,4,5",
                BookableFor = "6,7,8,9",
                PractitionerAvailability = new PractitionerAvailabilityDto
                {
                    ScheduleStartDate = DateTime.Now,
                    ScheduleEndDate = DateTime.Now.AddDays(1),
                    PractitionerAvailabilityDays = new List<PractitionerAvailabilityDayDto>
                {
                    new PractitionerAvailabilityDayDto
                    {
                        AvailabilityDay = "Tuesday",
                        DayStartTime = TimeSpan.FromHours(9),
                        DayEndTime = TimeSpan.FromHours(17),
                        PractitionerAvailabilityBreaks = new List<PractitionerAvailabilityBreakDto>
                        {
                            new PractitionerAvailabilityBreakDto
                            {
                                BreakTitle = "Lunch",
                                BreakStartTime = TimeSpan.FromHours(13),
                                BreakEndTime = TimeSpan.FromHours(12) // Invalid
                            }
                        }
                    }
                }
                }
            };

            //Act
            var result = await _controller.CreateSchedule(request) as BadRequestObjectResult;

            //Assert
            result.Should().NotBeNull(); // Ensure the result is not null
            result.Should().BeOfType<BadRequestObjectResult>();
        }

        [Fact]
        public async Task CreateSchedule_ShouldReturnBadRequest_WhenTimeOverlaps()
        {
            // Arrange
            var request = new CreateScheduleRequestDto
            {
                PractitionerId = 1,
                LocationId = "LOC001",
                SlotDuration = 15,
                SlotType = "Consult",
                Timezone = "Bukit/MYS",
                RequestableFor = "1,2,3,4,5",
                BookableFor = "6,7,8,9",
                PractitionerAvailability = new PractitionerAvailabilityDto
                {
                    ScheduleStartDate = DateTime.Now,
                    ScheduleEndDate = DateTime.Now.AddDays(1),
                    PractitionerAvailabilityDays = new List<PractitionerAvailabilityDayDto>
                {
                    new PractitionerAvailabilityDayDto
                    {
                        AvailabilityDay = "Tuesday",
                        DayStartTime = TimeSpan.FromHours(9),
                        DayEndTime = TimeSpan.FromHours(17),
                        PractitionerAvailabilityBreaks = new List<PractitionerAvailabilityBreakDto>
                        {
                            new PractitionerAvailabilityBreakDto
                            {
                                BreakTitle = "Lunch",
                                BreakStartTime = TimeSpan.FromHours(13),
                                BreakEndTime = TimeSpan.FromHours(14)
                            }
                        }
                    }
                }
                }
            };
            _scheduleQueryServiceMock.Setup(s => s.IsTimeOverlapping(request)).ReturnsAsync(true);

            // Act
            var result = await _controller.CreateSchedule(request);

            // Assert
            result.Should().BeOfType<BadRequestObjectResult>();
        }

        [Fact]
        public async Task CreateSchedule_ShouldReturnOk_WhenScheduleCreatedSuccessfully()
        {
            // Arrange
            var request = new CreateScheduleRequestDto
            {
                PractitionerId = 1,
                LocationId = "LOC001",
                SlotDuration = 15,
                SlotType = "Consult",
                Timezone = "Bukit/MYS",
                RequestableFor = "1,2,3,4,5",
                BookableFor = "6,7,8,9",
                PractitionerAvailability = new PractitionerAvailabilityDto
                {
                    ScheduleStartDate = DateTime.Now,
                    ScheduleEndDate = DateTime.Now.AddDays(1),
                    PractitionerAvailabilityDays = new List<PractitionerAvailabilityDayDto>
                    {
                        new PractitionerAvailabilityDayDto
                        {
                            AvailabilityDay = "Tuesday",
                            DayStartTime = TimeSpan.FromHours(9),
                            DayEndTime = TimeSpan.FromHours(17),
                            PractitionerAvailabilityBreaks = new List<PractitionerAvailabilityBreakDto>
                            {
                                new PractitionerAvailabilityBreakDto
                                {
                                    BreakTitle = "Lunch",
                                    BreakStartTime = TimeSpan.FromHours(13),
                                    BreakEndTime = TimeSpan.FromHours(14)
                                }
                            }
                        }
                    }
                }
            };
            _scheduleQueryServiceMock.Setup(s => s.IsTimeOverlapping(request)).ReturnsAsync(false);
            _mockScheduleCommandService.Setup(s => s.CreateScheduleAsync(request)).ReturnsAsync(true);

            // Act
            var result = await _controller.CreateSchedule(request);

            // Assert
            result.Should().BeOfType<OkObjectResult>();
        }

        #endregion

        #region View Schedule
        [Fact]
        public async Task ViewSchedule_ReturnsOkResult_WhenValidRequest()
        {
            // Arrange
            var practitionerId = "123";
            var locationId = "456";
            var specialtyId = "789";
            var startDate = DateTime.Now;
            var endDate = DateTime.Now.AddDays(7);

            var request = new ScheduleViewRequestDto
            {
                PractitionerId = practitionerId,
                LocationId = locationId,
                Specialty = specialtyId,
                StartDate = startDate,
                EndDate = endDate,
                ViewType = ScheduleViewType.Month // or Day/Week based on the use case
            };

            var scheduleResponse = new ScheduleResponseDto()
            {
                PractitionerId = practitionerId,
                ViewType = "Month"
            }; // Mock response to be returned
            _mockRegionCodeValidationHelper.Setup(x => x.VerifyRegionCodeHeader(It.IsAny<HttpRequest>()))
                .Returns((GenericResponse<string>)null);

            _scheduleQueryServiceMock.Setup(x => x.GetScheduleViewAsync(It.IsAny<ScheduleViewRequestDto>()))
                .ReturnsAsync(scheduleResponse);

            // Act
            var result = await _controller.ViewSchedule(request) as OkObjectResult;

            // Assert
            result.Should().NotBeNull();
            result.StatusCode.Should().Be(200);

            var response = result.Value as GenericResponse<ScheduleResponseDto>;
            response.Should().NotBeNull();
            response.IsSuccess.Should().BeTrue();
            response.Result.Should().Be(scheduleResponse);
        }

        [Fact]
        public async Task ViewSchedule_ReturnsBadRequest_WhenRegionCodeValidationFails()
        {
            // Arrange
            var practitionerId = "123";
            var locationId = "456";
            var specialtyId = "789";
            var startDate = DateTime.Now;
            var endDate = DateTime.Now.AddDays(7);

            var request = new ScheduleViewRequestDto
            {
                PractitionerId = practitionerId,
                LocationId = locationId,
                Specialty = specialtyId,
                StartDate = startDate,
                EndDate = endDate,
                ViewType = ScheduleViewType.Month // or Day/Week based on the use case
            };

            var errorResponse = new GenericResponse<string> { HasError = true };
            _mockRegionCodeValidationHelper.Setup(x => x.VerifyRegionCodeHeader(It.IsAny<HttpRequest>()))
                .Returns(errorResponse);

            // Act
            var result = await _controller.ViewSchedule(request) as BadRequestObjectResult;

            // Assert
            result.Should().NotBeNull();
            result.StatusCode.Should().Be(400);
            result.Value.Should().Be(errorResponse);
        }

        [Fact]
        public async Task ViewSchedule_ReturnsUnauthorized_WhenUnauthorized()
        {
            // Arrange
            var practitionerId = "123";
            var locationId = "456";
            var specialityId = "789";
            var startDate = DateTime.Now;
            var endDate = DateTime.Now.AddDays(7);

            var request = new ScheduleViewRequestDto
            {
                PractitionerId = practitionerId,
                LocationId = locationId,
                Specialty = specialityId,
                StartDate = startDate,
                EndDate = endDate,
                ViewType = ScheduleViewType.Month // or Day/Week based on the use case
            };

            var errorResponse = new GenericResponse<string> { HasError = true, Message = "Unauthorized" };
            _mockRegionCodeValidationHelper.Setup(x => x.VerifyRegionCodeHeader(It.IsAny<HttpRequest>()))
                .Returns(errorResponse);

            // Act
            var result = await _controller.ViewSchedule(request);

            // Assert
            result.Should().NotBeNull();
        }
        #endregion


        #region Get Schedule Details by AvailabilityId

        [Fact]
        public async Task ScheduleDetails_ShouldReturnOk_WhenScheduleExists()
        {
            // Arrange
            long availabilityId = 1;
            var expectedDto = new GetScheduleResponseDto
            {
                Id = availabilityId,
                PractitionerId = 1001,
                Practitionername = "John M Doe",
                LocationId = 2001,
                LocationName = "Kuala Lumpur",
                Speciality = "Cardiology",
                Timezone = "Asia/Kuala_Lumpur",
                SlotDuration = 10,
                SlotType = "Consultation",
                BookableFor = "Patients, AA_Admins",
                RequestableFor = "AA_ccmgroup",
                PractitionerAvailability = new GetPractitionerAvailabilityDto
                {
                    Id = availabilityId,
                    PractitionerRoleId = 101,
                    ScheduleStartDate = DateTime.UtcNow.AddDays(1),
                    ScheduleEndDate = DateTime.UtcNow.AddMonths(3),
                    Instructions = "Availability for consultation",
                    PractitionerAvailabilityDays = new List<GetPractitionerAvailabilityDayDto>
                    {
                        new GetPractitionerAvailabilityDayDto
                        {
                            Id = 1,
                            AvailabilityDay = "Monday",
                            DayStartTime = new TimeSpan(9, 0, 0),
                            DayEndTime = new TimeSpan(17, 0, 0),
                            PractitionerAvailabilityOccurances = new List<GetPractitionerAvailabilityOccuranceDto>
                            {
                                new GetPractitionerAvailabilityOccuranceDto
                                {
                                    Id = 1,
                                    OccuranceType = "Weekly"
                                }
                            },
                            PractitionerAvailabilityBreaks = new List<GetPractitionerAvailabilityBreakDto>
                            {
                                new GetPractitionerAvailabilityBreakDto
                                {
                                    Id = 1,
                                    BreakTitle = "Lunch Break",
                                    BreakStartTime = new TimeSpan(13, 0, 0),
                                    BreakEndTime = new TimeSpan(14, 0, 0)
                                }
                            }
                        }
                    }
                }
            };


            _mockRegionCodeValidationHelper
               .Setup(helper => helper.VerifyRegionCodeHeader(It.IsAny<HttpRequest>()))
            .Returns(new GenericResponse<string> { HasError = false });

            _scheduleQueryServiceMock
                .Setup(x => x.GetScheduleDetailsAsync(availabilityId))
                .ReturnsAsync(expectedDto);

            // Act
            var result = await _controller.ScheduleDetails(availabilityId);

            // Assert
            result.Should().BeOfType<OkObjectResult>();
            var okResult = result as OkObjectResult;

            var response = okResult?.Value as GenericResponse<GetScheduleResponseDto>;
            response.Should().NotBeNull();
            response!.IsSuccess.Should().BeTrue();
            response.Result.Should().BeEquivalentTo(expectedDto);
            response.StatusCode.Should().Be(ResponseStatusCode.STATUS_SUCCESS);
        }

        [Fact]
        public async Task ScheduleDetails_ShouldReturnBadRequest_WhenRegionCodeValidationFails()
        {
            // Arrange
            long availabilityId = 1;

            _mockRegionCodeValidationHelper
                .Setup(x => x.VerifyRegionCodeHeader(It.IsAny<HttpRequest>()))
                .Returns(new GenericResponse<string> { HasError = true });

            // Act
            var result = await _controller.ScheduleDetails(availabilityId);

            // Assert
            result.Should().BeOfType<BadRequestObjectResult>();
        }

        [Fact]
        public async Task ScheduleDetails_ShouldReturnBadRequest_WhenModelStateIsInvalid()
        {
            // Arrange
            _controller.ModelState.AddModelError("availabilityid", "Required");

            // Act
            var result = await _controller.ScheduleDetails(1);

            // Assert
            result.Should().BeOfType<BadRequestObjectResult>();
            var badRequestResult = result as BadRequestObjectResult;

            var response = badRequestResult?.Value as GenericResponse<GetScheduleResponseDto>;
            response.Should().NotBeNull();
            response!.IsSuccess.Should().BeFalse();
            response.HasError.Should().BeTrue();
            response.StatusCode.Should().Be(ResponseStatusCode.STATUS_BADREQUEST);
        }

        [Fact]
        public async Task ScheduleDetails_ShouldReturnBadRequest_WhenScheduleIsNull()
        {
            // Arrange
            long availabilityId = 999;

            _mockRegionCodeValidationHelper
               .Setup(helper => helper.VerifyRegionCodeHeader(It.IsAny<HttpRequest>()))
            .Returns(new GenericResponse<string> { HasError = false });

            _scheduleQueryServiceMock
                .Setup(x => x.GetScheduleDetailsAsync(availabilityId))
                .ReturnsAsync((GetScheduleResponseDto)null);

            // Act
            var result = await _controller.ScheduleDetails(availabilityId);

            // Assert
            result.Should().BeOfType<BadRequestObjectResult>();
            var badRequestResult = result as BadRequestObjectResult;

            var response = badRequestResult?.Value as GenericResponse<GetScheduleResponseDto>;
            response.Should().NotBeNull();
            response!.IsSuccess.Should().BeFalse();
            response.Result.Should().BeNull();
            response.StatusCode.Should().Be(ResponseStatusCode.STATUS_BADREQUEST);
        }
        [Fact]
        public async Task GetScheduleDetails_ShouldReturn200WithData_WhenRequestIsValid()
        {
            // Arrange
            var request = new ScheduleSearchRequestDto();

            var mockResult = new PaginationResult<ViewSearchScheduleResponseDto>
            {
                Records = new List<ViewSearchScheduleResponseDto>
                    {
                        new ViewSearchScheduleResponseDto {
                            PractitionerId =  15,
                            PractitionerResourceId = "PRAC001",
                            PractitionerName = "Smith A. John",
                            PractitionerSpecialty = "Neurology",
                            PractitionerRoleLocationId = "BRIM",
                            PractitionerRoleLocationName = "COLUMBIA ASIA HOSPITAL BUKIT RIMAU",
                            PractitionerSlotType = "Consultation",
                            ScheduleStartDate = DateTime.UtcNow.AddDays(1),
                            ScheduleEndDate = DateTime.UtcNow.AddMonths(3),
                            ScheduleAvailableDays = "Monday, Tuesday, Monday",
                            ScheduleLastUpdatedBy = "admin",
                            ScheduleLastUpdateDate = DateTime.UtcNow.AddDays(1),
                            Status = true
                        }
                    }.AsQueryable()
            };

            _mockRegionCodeValidationHelper
               .Setup(helper => helper.VerifyRegionCodeHeader(It.IsAny<HttpRequest>()))
            .Returns(new GenericResponse<string> { HasError = false });

            _scheduleQueryServiceMock
                .Setup(s => s.GetViewScheduleDetailsAsync(request))
                .ReturnsAsync(mockResult);

            // Act
            var result = await _controller.GetSchedules(request);

            // Assert
            result.Result.Should().BeOfType<OkObjectResult>();
            var okResult = result.Result as OkObjectResult;
            var response = okResult!.Value as GenericResponseList<ViewSearchScheduleResponseDto>;

            response.Should().NotBeNull();
            response!.IsSuccess.Should().BeTrue();
            response.StatusCode.Should().Be(ResponseStatusCode.STATUS_SUCCESS);
        }
        [Fact]
        public async Task GetScheduleDetails_ShouldReturn200WithNoData_WhenNoRecords()
        {
            // Arrange
            var request = new ScheduleSearchRequestDto();

            var emptyResult = new PaginationResult<ViewSearchScheduleResponseDto>
            {
                Records = new List<ViewSearchScheduleResponseDto>() { }.AsQueryable(),
                TotalCount = 0
            };

            _mockRegionCodeValidationHelper
               .Setup(helper => helper.VerifyRegionCodeHeader(It.IsAny<HttpRequest>()))
            .Returns(new GenericResponse<string> { HasError = false });

            _scheduleQueryServiceMock
                .Setup(s => s.GetViewScheduleDetailsAsync(request))
                .ReturnsAsync(emptyResult);

            // Act
            var result = await _controller.GetSchedules(request);

            // Assert
            result.Result.Should().BeOfType<OkObjectResult>();
            var okResult = result.Result as OkObjectResult;
            var response = okResult!.Value as GenericResponseList<ViewSearchScheduleResponseDto>;

            response.Should().NotBeNull();
            response!.IsSuccess.Should().BeTrue();
            response.Message.Should().Be(ResponseMessage.STATUS_NODATA);
            response.Results.Should().BeEmpty();
        }
        [Fact]
        public async Task GetScheduleDetails_ShouldReturn400_WhenRegionCodeIsInvalid()
        {
            // Arrange
            var request = new ScheduleSearchRequestDto();

            _mockRegionCodeValidationHelper
               .Setup(helper => helper.VerifyRegionCodeHeader(It.IsAny<HttpRequest>()))
            .Returns(new GenericResponse<string> { HasError = true });

            // Act
            var result = await _controller.GetSchedules(request);

            // Assert
            result.Result.Should().BeOfType<BadRequestObjectResult>();
        }
        [Fact]
        public async Task GetSchedules_ShouldReturnSuccessWithEmptyList_WhenResultIsNull()
        {
            // Arrange
            var request = new ScheduleSearchRequestDto();
            _mockRegionCodeValidationHelper
                .Setup(helper => helper.VerifyRegionCodeHeader(It.IsAny<HttpRequest>()))
             .Returns(new GenericResponse<string> { HasError = false });

            _scheduleQueryServiceMock.Setup(x => x.GetViewScheduleDetailsAsync(request))
                .ReturnsAsync((PaginationResult<ViewSearchScheduleResponseDto>)null!);

            // Act
            var result = await _controller.GetSchedules(request);

            // Assert
            var okResult = result.Result as OkObjectResult;
            var response = okResult!.Value as GenericResponseList<ViewSearchScheduleResponseDto>;
            response!.IsSuccess.Should().BeTrue();
            response.Results.Should().BeEmpty();
            response.TotalCount.Should().Be(0);
            response.Message.Should().Be(ResponseMessage.STATUS_NODATA);
        }
        #endregion

        #region Update Schedule Details

        private static UpdateScheduleRequestDto GetValidRequestDto()
        {
            return new UpdateScheduleRequestDto
            {
                PractitionerId = 1,
                LocationId = "LOC001",
                Timezone = "Pune/MH",
                SlotDuration = 10,
                SlotType = "Consultation",
                BookableFor = "1,2,3,4",
                RequestableFor = "6,7,8,9",
                UpdatePractitionerAvailability = new UpdatePractitionerAvailabilityDto()
                {
                    AvailabilityId = 1,
                    Instructions = "Updated for testing",
                    PractitionerRoleId = 1,
                    ScheduleEndDate = DateTime.UtcNow.AddDays(7),
                    ScheduleStartDate = DateTime.UtcNow,
                    IsDeleted = false,
                    UpdatePractitionerAvailabilityDays = new List<UpdatePractitionerAvailabilityDayDto>()
                    {
                        new UpdatePractitionerAvailabilityDayDto()
                        {
                            AvailabilityDay = "Monday",
                            DayStartTime = TimeSpan.FromHours(9),
                            DayEndTime = TimeSpan.FromHours(18),
                            IsDeleted = false,
                            PractitionerAvailabilityBreaks = new List<UpdatePractitionerAvailabilityBreakDto>
                            {
                                new UpdatePractitionerAvailabilityBreakDto()
                                {
                                    BreakStartTime = TimeSpan.FromHours(15),
                                    BreakEndTime = TimeSpan.FromHours(16),
                                    BreakTitle = "Lunch",
                                }
                            },
                            PractitionerAvailabilityOccurances = new List<UpdatePractitionerAvailabilityOccuranceDto>
                            {
                                new UpdatePractitionerAvailabilityOccuranceDto()
                                {
                                    OccuranceType = "Consultation"
                                }
                            }
                        }
                    }
                }
            };
        }

        [Fact]
        public async Task UpdateScheduleDetails_ShouldReturnBadRequest_WhenRegionCodeValidationFails()
        {
            // Arrange
            _mockRegionCodeValidationHelper
            .Setup(x => x.VerifyRegionCodeHeader(It.IsAny<HttpRequest>()))
            .Returns(new GenericResponse<string> { HasError = true });

            var request = GetValidRequestDto();

            // Act
            var result = await _controller.UpdateScheduleDetails(request);

            // Assert
            result.Should().BeOfType<BadRequestObjectResult>();
        }

        [Fact]
        public async Task UpdateScheduleDetails_ShouldReturnBadRequest_WhenModelStateIsInvalid()
        {
            // Arrange
            _mockRegionCodeValidationHelper
            .Setup(helper => helper.VerifyRegionCodeHeader(It.IsAny<HttpRequest>()))
            .Returns(new GenericResponse<string> { HasError = false });

            _controller.ModelState.AddModelError("key", "error");

            var request = GetValidRequestDto();

            // Act
            var result = await _controller.UpdateScheduleDetails(request);

            // Assert
            result.Should().BeOfType<BadRequestObjectResult>();
            var badRequest = result as BadRequestObjectResult;
            var response = badRequest.Value as GenericResponse<string>;
            response.Should().NotBeNull();
            response!.IsSuccess.Should().BeFalse();
            response.HasError.Should().BeTrue();
            response.StatusCode.Should().Be(ResponseStatusCode.STATUS_BADREQUEST);
            response.MessageType.Should().Be("INFO");
        }

        [Fact]
        public async Task UpdateScheduleDetails_ShouldReturnBadRequest_WhenValidationFails()
        {
            // Arrange
            var request = GetValidRequestDto();

            _mockRegionCodeValidationHelper.Setup(x => x.VerifyRegionCodeHeader(It.IsAny<HttpRequest>()))
                .Returns((GenericResponse<string>)null);

            _controller.ModelState.Clear();

            // Act
            var result = await _controller.UpdateScheduleDetails(request);

            // Assert
            var badRequest = result as BadRequestObjectResult;
            badRequest.Should().NotBeNull();
        }

        [Fact]
        public async Task UpdateScheduleDetails_ShouldReturnBadRequest_WhenTimeOverlapping()
        {
            // Arrange
            var request = GetValidRequestDto();

            _mockRegionCodeValidationHelper.Setup(x => x.VerifyRegionCodeHeader(It.IsAny<HttpRequest>()))
                .Returns((GenericResponse<string>)null);

            _scheduleQueryServiceMock.Setup(x => x.IsTimeOverlapping(It.IsAny<CreateScheduleRequestDto>()))
                .ReturnsAsync(true);

            // Act
            var result = await _controller.UpdateScheduleDetails(request);

            // Assert
            var badRequest = result as BadRequestObjectResult;
            badRequest.Should().NotBeNull();
            var response = badRequest!.Value as GenericResponse<string>;
            response!.Message.Should().Be(ResponseMessage.TIMEOVERLAPPING_VALIDATION_MESSAGE);
        }

        [Fact]
        public async Task UpdateScheduleDetails_ShouldReturnBadRequest_WhenAvailabilityNotFound()
        {
            // Arrange
            var request = GetValidRequestDto();

            _mockRegionCodeValidationHelper.Setup(x => x.VerifyRegionCodeHeader(It.IsAny<HttpRequest>()))
                .Returns((GenericResponse<string>)null);
            _scheduleQueryServiceMock.Setup(x => x.IsTimeOverlapping(It.IsAny<CreateScheduleRequestDto>()))
                .ReturnsAsync(false);

            _scheduleQueryServiceMock.Setup(x => x.GetAvailabilityWithDetailsAsync(It.IsAny<long>()))
                .ReturnsAsync((PractitionerAvailability)null!);

            // Act
            var result = await _controller.UpdateScheduleDetails(request);

            // Assert
            result.Should().BeOfType<BadRequestObjectResult>();
        }

        [Fact]
        public async Task UpdateScheduleDetails_ShouldReturnOk_WhenUpdateIsSuccessful()
        {
            // Arrange
            var request = GetValidRequestDto();
            var availability = new PractitionerAvailability()
            {
                CreatedBy = "Admin",
                CreatedDate = DateTime.UtcNow,
                IsDeleted = false,
                ScheduleEndDate = DateTime.UtcNow.AddDays(-10),
                ScheduleStartDate = DateTime.UtcNow,
                SlotsID = 1,
            };

            _mockRegionCodeValidationHelper.Setup(x => x.VerifyRegionCodeHeader(It.IsAny<HttpRequest>()))
                .Returns((GenericResponse<string>)null);

            _scheduleQueryServiceMock.Setup(x => x.IsTimeOverlapping(It.IsAny<CreateScheduleRequestDto>()))
                .ReturnsAsync(false);

            _scheduleQueryServiceMock.Setup(x => x.GetAvailabilityWithDetailsAsync(It.IsAny<long>()))
                .ReturnsAsync(availability);

            _mockScheduleCommandService.Setup(x => x.UpdateScheduleAsync(request, availability))
                .ReturnsAsync(true);

            // Act
            var result = await _controller.UpdateScheduleDetails(request);

            // Assert
            result.Should().BeOfType<OkObjectResult>();
            var okResult = result as OkObjectResult;
            var response = okResult!.Value as GenericResponse<string>;
            response!.IsSuccess.Should().BeTrue();
            response.StatusCode.Should().Be(ResponseStatusCode.STATUS_SUCCESS);
            response.Result.Should().Be("SUCCESS");
        }

        [Fact]
        public async Task UpdateScheduleDetails_ShouldReturnBadRequest_WhenUpdateFails()
        {
            // Arrange
            var request = GetValidRequestDto();
            var availability = new PractitionerAvailability()
            {
                CreatedBy = "Admin",
                CreatedDate = DateTime.UtcNow,
                IsDeleted = false,
                ScheduleEndDate = DateTime.UtcNow.AddDays(-10),
                ScheduleStartDate = DateTime.UtcNow,
                SlotsID = 1,
            };

            _mockRegionCodeValidationHelper.Setup(x => x.VerifyRegionCodeHeader(It.IsAny<HttpRequest>()))
                .Returns((GenericResponse<string>)null);

            _scheduleQueryServiceMock.Setup(x => x.IsTimeOverlapping(It.IsAny<CreateScheduleRequestDto>()))
                .ReturnsAsync(false);

            _scheduleQueryServiceMock.Setup(x => x.GetAvailabilityWithDetailsAsync(It.IsAny<long>()))
                .ReturnsAsync(availability);

            _mockScheduleCommandService.Setup(x => x.UpdateScheduleAsync(request, availability))
                .ReturnsAsync(false);

            // Act
            var result = await _controller.UpdateScheduleDetails(request);

            // Assert
            result.Should().BeOfType<BadRequestObjectResult>();
        }


        #endregion
    }
}