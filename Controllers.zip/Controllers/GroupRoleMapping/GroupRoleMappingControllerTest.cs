﻿using Aurora.AdministrationService.API.Controllers.GroupRoleMapping;
using Aurora.AdministrationService.API.Helper;
using Aurora.AdministrationService.API.Models.Dto.UserGroups.GroupRoleMapping;
using Aurora.AdministrationService.API.Services.IService.UserGroups.GroupRoleMapping;
using Aurora.AdministrationService.CrossCutting.CommonModels;
using Aurora.AdministrationService.CrossCutting.Constants;
using FluentAssertions;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Moq;

namespace Aurora.AdministrationService.Tests.API.Controllers.GroupRoleMapping
{
    public class GroupRoleMappingControllerTest
    {
        private readonly Mock<IGroupRoleMappingCommandService> _mockGroupRoleMappingCommandService;
        private readonly Mock<IGroupRoleMappingQueryService> _mockGroupRoleMappingQueryService;
        private readonly GroupRoleMappingController _controller;
        private readonly Mock<IRegionCodeValidationHelper> _regionHelperMock;

        public GroupRoleMappingControllerTest()
        {
            _regionHelperMock = new Mock<IRegionCodeValidationHelper>();
            _mockGroupRoleMappingCommandService = new Mock<IGroupRoleMappingCommandService>();
            _mockGroupRoleMappingQueryService = new Mock<IGroupRoleMappingQueryService>();
            _controller = new GroupRoleMappingController(_mockGroupRoleMappingQueryService.Object, _mockGroupRoleMappingCommandService.Object, _regionHelperMock.Object);
        }
        [Fact]
        public void GetGroupRoleMappings_InvalidRegionCode_ReturnsBadRequest()
        {
            // Arrange
            _regionHelperMock
                .Setup(helper => helper.VerifyRegionCodeHeader(It.IsAny<HttpRequest>()))
                .Returns(new GenericResponse<string> { HasError = true, Message = "Invalid RegionCode" });

            // Act
            var result = _controller.GetGroupRoleMappingList();

            // Assert
            var badRequestResult = result.Result as BadRequestObjectResult;
            badRequestResult.Should().NotBeNull();
            var response = badRequestResult?.Value as GenericResponse<string>;
            response.Should().NotBeNull();
            response?.HasError.Should().BeTrue();
            response?.Message.Should().Be("Invalid RegionCode");
        }

        [Fact]
        public void CreateGroupRoleMapping_InvalidRegionCode_ReturnsBadRequest()
        {
            // Arrange
            var groupRoleMapping = new GroupRoleMappingDto()
            {
                Code = "test",
                GroupID = 1,
                RoleID = 1,
                Definition = "test",
                Display = "test",
                Source = "test",
            };
            _regionHelperMock
                .Setup(helper => helper.VerifyRegionCodeHeader(It.IsAny<HttpRequest>()))
                .Returns(new GenericResponse<string> { HasError = true, Message = "Invalid RegionCode" });

            // Act
            var result = _controller.CreateGroupRoleMapping(groupRoleMapping);

            // Assert
            var badRequestResult = result?.Result as BadRequestObjectResult;
            badRequestResult.Should().NotBeNull();
            var response = badRequestResult?.Value as GenericResponse<string>;
            response.Should().NotBeNull();
            response?.HasError.Should().BeTrue();
            response?.Message.Should().Be("Invalid RegionCode");
        }

        [Fact]
        public async Task GetGroupRoleMappingById_InvalidRegionCode_ReturnsBadRequest()
        {
            // Arrange
            _regionHelperMock
                .Setup(helper => helper.VerifyRegionCodeHeader(It.IsAny<HttpRequest>()))
                .Returns(new GenericResponse<string> { HasError = true, Message = "Invalid RegionCode" });

            // Act
            var result = await _controller.GetGroupRoleMappingById(1);

            // Assert
            var badRequestResult = result.Result as BadRequestObjectResult;

            badRequestResult.Should().NotBeNull();
            var response = badRequestResult?.Value as GenericResponse<string>;
            response.Should().NotBeNull();
            response?.HasError.Should().BeTrue();
            response?.Message.Should().Be("Invalid RegionCode");
        }

        [Fact]
        public void UpdateGroupRoleMappingDetails_InvalidRegionCode_ReturnsBadRequest()
        {
            // Arrange
            int id = 1;
            var groupRoleMapping = new UpdateGroupRoleMappingRequest()
            {
                Id = 1,
                Code = "test",
                GroupID = 1,
                RoleID = 1,
                Definition = "test",
                Display = "test",
                Source = "test",
            };
            _regionHelperMock
                .Setup(helper => helper.VerifyRegionCodeHeader(It.IsAny<HttpRequest>()))
                .Returns(new GenericResponse<string> { HasError = true, Message = "Invalid RegionCode" });

            // Act
            var result = _controller.UpdateGroupRoleMappingDetails(id, groupRoleMapping);

            // Assert
            var badRequestResult = result?.Result as BadRequestObjectResult;
            badRequestResult.Should().NotBeNull();
            var response = badRequestResult?.Value as GenericResponse<string>;
            response.Should().NotBeNull();
            response?.HasError.Should().BeTrue();
            response?.Message.Should().Be("Invalid RegionCode");
        }

        [Fact]
        public async Task CreateGroupRoleMapping_ShouldReturnSuccessResponse_WhenIsAdded()
        {
            // Arrange
            var groupRoleMapping = new GroupRoleMappingDto()
            {
                Code = "test",
                GroupID = 1,
                RoleID = 1,
                Definition = "test",
                Display = "test",
                Source = "test",
            };
            _mockGroupRoleMappingCommandService.Setup(service => service.CreateGroupRoleMappingAsync(groupRoleMapping)).ReturnsAsync(true);

            // Act
            var result = await _controller.CreateGroupRoleMapping(groupRoleMapping) as OkObjectResult;
            var response = result?.Value as GenericResponse<string>;

            // Assert
            result.Should().NotBeNull();
            result?.StatusCode.Should().Be(200);
            response?.IsSuccess.Should().BeTrue();
            response?.StatusCode.Should().Be(ResponseStatusCode.STATUS_SUCCESS);
            response?.Message.Should().Be(ResponseMessage.STATUS_DATA_ADDED);
        }

        [Fact]
        public void GetGroupRoleMappingList_ShouldReturnGroupRoleMappingList()
        {
            // Arrange
            var groupRoleMappingList = new List<GetGroupRoleMappingDto> { new GetGroupRoleMappingDto() {
                Code = "test",
                GroupID = 1,
                RoleID = 1,
                Definition = "test",
                Display = "test",
                Source = "test",
            } };
            _mockGroupRoleMappingQueryService.Setup(service => service.GetGroupRoleMappingList()).Returns(groupRoleMappingList);

            // Act
            var result = _controller.GetGroupRoleMappingList();
            var okresult = result?.Result as OkObjectResult;
            var response = okresult?.Value as GenericResponseList<GetGroupRoleMappingDto>;

            // Assert
            result.Should().NotBeNull();
            response?.StatusCode.Should().Be("200");
            response?.IsSuccess.Should().BeTrue();
            response?.StatusCode.Should().Be(ResponseStatusCode.STATUS_SUCCESS);
            response?.Message.Should().Be(ResponseMessage.STATUS_DATA_FOUND);
            response?.TotalCount.Should().Be(groupRoleMappingList.Count);

        }

        [Fact]
        public async Task GetGroupRoleMappingById_ShouldReturnNull_WhenIdIsInvalid()
        {
            // Act
            var result = await _controller.GetGroupRoleMappingById(null);
            var response = result.Value as GenericResponse<GetGroupRoleMappingDetailDto>;

            // Assert
            result.Should().NotBeNull();
            response.Should().BeNull();

        }

        [Fact]
        public async Task GetGroupRoleMappingById_ShouldReturnNotFound_WhenDoesNotExist()
        {
            // Arrange
            var id = 1;
            GetGroupRoleMappingDetailDto groupRoleMappingDetailDto = new GetGroupRoleMappingDetailDto() 
            {
                Code = "test",
                GroupID = 1,
                RoleID = 1,
                Definition = "test",
                Display = "test",
                Source = "test",
            };
            _mockGroupRoleMappingQueryService
              .Setup(service => service.GetGroupRoleMappingById(2)).ReturnsAsync(groupRoleMappingDetailDto);

            // Act
            var result = await _controller.GetGroupRoleMappingById(id);
            var okobjectresult = result?.Result as OkObjectResult;
            var response = okobjectresult?.Value as GenericResponse<GetGroupRoleMappingDetailDto>;

            // Assert
            result.Should().NotBeNull();
            response?.IsSuccess.Should().BeTrue();
            response?.StatusCode.Should().Be(ResponseStatusCode.STATUS_NOTFOUND);
            response?.Message.Should().Be(ResponseMessage.STATUS_NODATA);
        }

        [Fact]
        public async Task UpdateGroupRoleMappingDetails_ShouldReturnBadRequest_WhenAlreadyExists()
        {
            // Arrange
            int id = 1;
            var groupRoleMapping = new UpdateGroupRoleMappingRequest()
            {
                Id = 1,
                Code = "test",
                GroupID = 1,
                RoleID = 1,
                Definition = "test",
                Display = "test",
                Source = "test",
            };
            _mockGroupRoleMappingQueryService.Setup(service => service.IsGroupRoleMappingAlreadyExist(id)).ReturnsAsync((true, ResponseMessage.STATUS_NODATA));

            // Act
            var result = await _controller.UpdateGroupRoleMappingDetails(id, groupRoleMapping);

            // Assert
            result.Should().NotBeNull();

        }

        [Fact]
        public async Task UpdateGroupRoleMappingDetails_GroupRoleMappingNotFound_ReturnsNotFound()
        {
            // Arrange
            int groupRoleMappingId = 1;
            var groupRoleMappingRequest = new UpdateGroupRoleMappingRequest()
            {
                Id = groupRoleMappingId,
                Code = "test",
                GroupID = 1,
                RoleID = 1,
                Definition = "test",
                Display = "test",
                Source = "test",
            };
            Domain.V1.Entities.UserGroups.GroupRoleMapping groupRoleMapping = null;
            _mockGroupRoleMappingQueryService
                .Setup(service => service.FindGroupRoleMappingById(groupRoleMappingId))
                .ReturnsAsync(groupRoleMapping);

            // Act
            var result = await _controller.UpdateGroupRoleMappingDetails(groupRoleMappingId, groupRoleMappingRequest);

            // Assert
            var actionResult = Assert.IsType<NotFoundObjectResult>(result);
            var response = Assert.IsType<GenericResponse<string>>(actionResult.Value);
            Assert.Equal(ResponseStatusCode.STATUS_NOTFOUND, response.StatusCode);
            Assert.Equal(ResponseMessage.STATUS_NODATA, response.Message);
        }

        [Fact]
        public async Task UpdateGroupRoleMappingDetails_UpdateSuccessful_ReturnsOk()
        {
            // Arrange
            int groupRoleMappingId = 1;
            var groupRoleMappingRequest = new UpdateGroupRoleMappingRequest()
            {
                Id = 1,
                Code = "test",
                GroupID = 1,
                RoleID = 1,
                Definition = "test",
                Display = "test",
                Source = "test",
            };
            var existingGroupRoleMapping = new Domain.V1.Entities.UserGroups.GroupRoleMapping
            {
                Id = groupRoleMappingId,
                Code = "test",
                GroupID = 1,
                RoleID = 1,
                Definition = "test",
                Display = "test",
                Source = "test",
                CreatedBy = "Admin",
                CreatedDate = DateTime.UtcNow,
                IsDeleted = false
            };

            _mockGroupRoleMappingQueryService
                .Setup(service => service.FindGroupRoleMappingById(groupRoleMappingId))
                .ReturnsAsync(existingGroupRoleMapping);

            _mockGroupRoleMappingCommandService
                .Setup(service => service.UpdateGroupRoleMappingAsync(groupRoleMappingRequest, existingGroupRoleMapping))
                .ReturnsAsync(true);

            // Act
            var result = await _controller.UpdateGroupRoleMappingDetails(groupRoleMappingId, groupRoleMappingRequest);

            // Assert
            var actionResult = Assert.IsType<OkObjectResult>(result);
            var response = Assert.IsType<GenericResponse<string>>(actionResult.Value);
            Assert.Equal(ResponseStatusCode.STATUS_SUCCESS, response.StatusCode);
            Assert.Equal(ResponseMessage.STATUS_DATA_UPDATED, response.Message);
            Assert.Equal(CommonConstants.SUCCESS, response.MessageType);
        }

        [Fact]
        public async Task UpdateGroupRoleMappingDetails_UpdateFailed_ReturnsOkWithErrorMessage()
        {
            // Arrange
            int groupRoleMappingId = 1;
            var groupRoleMappingRequest = new UpdateGroupRoleMappingRequest()
            {
                Id = groupRoleMappingId,
                Code = "test",
                GroupID = 1,
                RoleID = 1,
                Definition = "test",
                Display = "test",
                Source = "test",
            };
            var existingGroupRoleMapping = new Domain.V1.Entities.UserGroups.GroupRoleMapping
            {
                Id = groupRoleMappingId,
                Code = "test",
                GroupID = 1,
                RoleID = 1,
                Definition = "test",
                Display = "test",
                Source = "test",
                CreatedBy = "Admin",
                CreatedDate = DateTime.UtcNow,
                IsDeleted = false
            };

            _mockGroupRoleMappingQueryService
                .Setup(service => service.FindGroupRoleMappingById(groupRoleMappingId))
                .ReturnsAsync(existingGroupRoleMapping); // Simulate groupRoleMapping found

            _mockGroupRoleMappingCommandService
                .Setup(service => service.UpdateGroupRoleMappingAsync(groupRoleMappingRequest, existingGroupRoleMapping))
                .ReturnsAsync(false); // Simulate update failure

            // Act
            var result = await _controller.UpdateGroupRoleMappingDetails(groupRoleMappingId, groupRoleMappingRequest);

            // Assert
            var actionResult = Assert.IsType<OkObjectResult>(result);
            Assert.Equal(ResponseStatusCode.STATUS_SUCCESS, actionResult.StatusCode.ToString());
        }

        [Fact]
        public async Task GetGroupRoleMappingById_ReturnsOk_WhenGroupRoleMappingIsFound()
        {
            // Arrange
            int groupRoleMappingId = 1;
            var expectedGroupRoleMapping = new GetGroupRoleMappingDetailDto
            {
                Id = groupRoleMappingId,
                Code = "test",
                GroupID = 1,
                RoleID = 1,
                Definition = "test",
                Display = "test",
                Source = "test",
                IsDeleted = false,
            };
            _mockGroupRoleMappingQueryService.Setup(s => s.GetGroupRoleMappingById(groupRoleMappingId)).ReturnsAsync(expectedGroupRoleMapping);

            // Act
            var result = await _controller.GetGroupRoleMappingById(groupRoleMappingId);

            // Assert
            var actionResult = Assert.IsType<ActionResult<GenericResponse<GetGroupRoleMappingDetailDto>>>(result);
            var okResult = Assert.IsType<OkObjectResult>(actionResult.Result);
            var response = Assert.IsType<GenericResponse<GetGroupRoleMappingDetailDto>>(okResult.Value);
            Assert.True(response.IsSuccess);
            Assert.Equal(ResponseStatusCode.STATUS_SUCCESS, response.StatusCode);
            Assert.Equal(ResponseMessage.STATUS_DATA_FOUND, response.Message);
            Assert.Equal(expectedGroupRoleMapping, response.Result);
        }
    }
}
