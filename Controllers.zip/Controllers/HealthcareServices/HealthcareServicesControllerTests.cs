using Aurora.AdministrationService.API.Controllers;
using Aurora.AdministrationService.API.Helper;
using Aurora.AdministrationService.API.Models.Dto.Content;
using Aurora.AdministrationService.API.Models.Dto.HealthcareServices;
using Aurora.AdministrationService.API.Resources;
using Aurora.AdministrationService.API.Services.IService.HealthcareService;
using Aurora.AdministrationService.CrossCutting.CommonModels;
using Aurora.AdministrationService.CrossCutting.Constants;
using Aurora.AdministrationService.Domain.V1.Entities.HealthcareService;
using FluentAssertions;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Http.HttpResults;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using Microsoft.Graph.TermStore;
using Moq;
using System.Net;

namespace Aurora.AdministrationService.Tests.API.Controllers.HealthcareServices
{
    /// <summary>
    /// Test cases for HealthcareServices Controller
    /// </summary>
    public class HealthcareServicesControllerTests
    {
        private readonly Mock<IHealthcareServicesCommandService> _mockHealthcareServicesCommandService;
        private readonly Mock<IHealthcareServiceQueryService> _mockHealthcareServicesQueryService;
        private readonly Mock<IRegionCodeValidationHelper> _mockRegionHelper;
        private readonly HealthcareServicesController _controller;

        public HealthcareServicesControllerTests()
        {
            _mockHealthcareServicesCommandService = new Mock<IHealthcareServicesCommandService>();
            _mockHealthcareServicesQueryService = new Mock<IHealthcareServiceQueryService>();
            _mockRegionHelper = new Mock<IRegionCodeValidationHelper>();
            _controller = new HealthcareServicesController(_mockRegionHelper.Object, _mockHealthcareServicesQueryService.Object, _mockHealthcareServicesCommandService.Object);
        }

        [Fact]
        public async Task CreateHealthcareServices_InvalidRegionCode_ReturnsBadRequest()
        {
            //Arrange
            var request = GetHealthcareServiceMockData();
            _mockRegionHelper
                .Setup(helper => helper.VerifyRegionCodeHeader(It.IsAny<HttpRequest>()))
                .Returns(new GenericResponse<string> { HasError = true, Message = "Invalid RegionCode" });

            //Act
            var result = await _controller.CreateHealthcareService(request);

            //Assert
            var badRequestResult = result as BadRequestObjectResult;
            badRequestResult.Should().NotBeNull();
            var response = badRequestResult?.Value as GenericResponse<string>;
            response?.Message.Should().Be("Invalid RegionCode");
        }

        [Fact]
        public async Task CreateHealthcareService_ShouldReturnBadRequest_WhenModelStateIsInvalid()
        {
            // Arrange
            var request = GetHealthcareServiceMockData();
            _controller.ModelState.AddModelError("Error", "Invalid Model");

            // Act
            var result = await _controller.CreateHealthcareService(request);

            // Assert
            result.Should().BeOfType<BadRequestObjectResult>();  // Should return BadRequest for invalid model state
        }

        [Fact]
        public async Task CreateHealthcareServices_ValidRequest_ReturnsOkResult()
        {
            var request = GetHealthcareServiceMockData();
            var serviceResult = new GenericResponse<CreateHealthcareServicesDto>()
            {
                HasError = false,
                IsSuccess = true,
                StatusCode = ResponseStatus.STATUS_SUCCESS_Create,
                Result = request,
                Message = Resource.RecordInsertionMessage
            };
            _mockHealthcareServicesCommandService.Setup(x => x.CreateHealthcareServiceAsync(It.IsAny<CreateHealthcareServicesDto>()))
                                            .ReturnsAsync(serviceResult);

            // Act
            var result = await _controller.CreateHealthcareService(request);

            // Assert
            var okResult = result.Should().BeOfType<OkObjectResult>().Subject;
            okResult.Value.Should().Be(serviceResult);  // Should return a successful response with the result
        }

        [Fact]
        public async Task CreateHealthcareService_ShouldReturnBadRequest_WhenServiceCreationFails()
        {
            // Arrange
            var request = GetHealthcareServiceMockData();

            var serviceResult = new GenericResponse<CreateHealthcareServicesDto>()
            {
                HasError = true,
                IsSuccess = false,
                StatusCode = ResponseStatus.STATUS_BadRequest,
                Result = request,
                Message = Resource.RecordInsertionMessage
            };

            _mockHealthcareServicesCommandService
                .Setup(x => x.CreateHealthcareServiceAsync(It.IsAny<CreateHealthcareServicesDto>()))
                .ReturnsAsync(serviceResult);

            // Act
            var result = await _controller.CreateHealthcareService(request);

            // Assert
            result.Should().BeOfType<BadRequestObjectResult>(); // Should return BadRequest

        }
        [Fact]
        public async Task UpdateHealthcareServiceStatus_ReturnsBadRequest_WhenRegionCodeIsInvalid()
        {
            // Arrange
            var mockedResponse = new GenericResponse<string>
            {
                IsSuccess = false,
                HasError = true,
                StatusCode = ResponseStatus.STATUS_BadRequest,
                Message = Resource.RegionCodeRequired
            };

            _mockRegionHelper.Setup(x => x.VerifyRegionCodeHeader(It.IsAny<HttpRequest>()))
                .Returns(mockedResponse);

            var request = new UpdateHealthcareStatusRequest
            {
                Status = true
            };

            // Act
            var result = await _controller.UpdateHealthcareServiceStatus(1, request);

            // Assert
            result.Should().BeOfType<BadRequestObjectResult>();
        }

        [Fact]
        public async Task UpdateHealthcareServiceStatus_ReturnsBadRequest_WhenModelStateIsInvalid()
        {
            // Arrange
            var request = new UpdateHealthcareStatusRequest
            {
                Status = true // Simulate invalid model state (you can add more validation rules in the actual model)
            };

            _controller.ModelState.AddModelError("Status", "The Status field is required.");

            _mockRegionHelper.Setup(x => x.VerifyRegionCodeHeader(It.IsAny<HttpRequest>()))
                .Returns(new GenericResponse<string> { IsSuccess = true });

            // Act
            var result = await _controller.UpdateHealthcareServiceStatus(1, request);

            // Assert
            result.Should().BeOfType<NotFoundObjectResult>();
        }

        [Fact]
        public async Task UpdateHealthcareServiceStatus_ReturnsNotFound_WhenHealthcareServiceIdNotFound()
        {
            // Arrange
            var request = new UpdateHealthcareStatusRequest
            {
                Status = true
            };

            var mockResponse = new GenericResponse<string>
            {
                IsSuccess = false,
                HasError = true,
                StatusCode = ResponseStatus.STATUS_NotFound,
                Message = Resource.RecordNotFound,
                MessageType = CommonConstants.VALIDATION
            };

            _mockRegionHelper.Setup(x => x.VerifyRegionCodeHeader(It.IsAny<HttpRequest>()))
                .Returns(new GenericResponse<string> { IsSuccess = true });

            _mockHealthcareServicesQueryService.Setup(x => x.FindHealthcareServiceById(It.IsAny<long>()))
                .ReturnsAsync((Domain.V1.Entities.HealthcareService.HealthcareServices)null);

            // Act
            var result = await _controller.UpdateHealthcareServiceStatus(999, request); // ID 999 does not exist

            // Assert
            result.Should().BeOfType<NotFoundObjectResult>();
            var badRequestResult = result as NotFoundObjectResult;
            badRequestResult?.Value.Should().BeEquivalentTo(mockResponse);
        }

        [Fact]
        public async Task UpdateHealthcareServiceStatus_ReturnsOk_WhenStatusUpdatedSuccessfully()
        {
            // Arrange
            var request = new UpdateHealthcareStatusRequest
            {
                Status = true
            };

            var HealthcareService = new Domain.V1.Entities.HealthcareService.HealthcareServices
            {
                ID = 1,
                Name = "Test HealthcareService",
                Status = false,
                Location = "Malasia",
                CreatedBy = "testUser",
                CreatedDate = DateTime.UtcNow,
                IsDeleted = false,
                UpdatedDate = DateTime.UtcNow,
                RecordVersion = new byte[] { 1, 2, 3, 4 }
            };

            var mockResponse = new GenericResponse<UpdateHealthcareRequest>
            {
                IsSuccess = true,
                HasError = false,
                StatusCode = ResponseStatus.STATUS_SUCCESS,
                Message = "HealthcareService status updated successfully"
            };

            _mockRegionHelper.Setup(x => x.VerifyRegionCodeHeader(It.IsAny<HttpRequest>()))
                .Returns(new GenericResponse<string> { IsSuccess = true });

            _mockHealthcareServicesQueryService.Setup(x => x.FindHealthcareServiceById(1))
                .ReturnsAsync(HealthcareService);

            _mockHealthcareServicesCommandService.Setup(x => x.UpdatHealthcareServiceStatusAsync(It.IsAny<UpdateHealthcareRequest>(), HealthcareService))
                .ReturnsAsync(mockResponse);

            // Act
            var result = await _controller.UpdateHealthcareServiceStatus(1, request);

            // Assert
            result.Should().BeOfType<OkObjectResult>();
            var okResult = result as OkObjectResult;
            okResult?.Value.Should().BeEquivalentTo(mockResponse);
        }

        [Fact]
        public async Task UpdateHealthcareServiceStatus_ReturnsBadRequest_WhenUpdateFails()
        {
            // Arrange
            var request = new UpdateHealthcareStatusRequest
            {
                Status = true
            };

            var HealthcareService = new Domain.V1.Entities.HealthcareService.HealthcareServices
            {
                ID = 1,
                Name = "Test HealthcareService",
                Status = false,
                Location = "Columbia",
                CreatedBy = "testUser",
                CreatedDate = DateTime.UtcNow,
                IsDeleted = false,
                RecordVersion = new byte[] { 1, 2, 3, 4 },
                UpdatedDate = DateTime.UtcNow
            };

            var mockResponse = new GenericResponse<UpdateHealthcareRequest>
            {
                IsSuccess = false,
                HasError = true,
                StatusCode = ResponseStatus.STATUS_BadRequest,
                Message = "RecordVersion mismatch. Update failed."
            };

            _mockRegionHelper.Setup(x => x.VerifyRegionCodeHeader(It.IsAny<HttpRequest>()))
                .Returns(new GenericResponse<string> { IsSuccess = true });

            _mockHealthcareServicesQueryService.Setup(x => x.FindHealthcareServiceById(1))
                .ReturnsAsync(HealthcareService);

            _mockHealthcareServicesCommandService.Setup(x => x.UpdatHealthcareServiceStatusAsync(It.IsAny<UpdateHealthcareRequest>(), HealthcareService))
                .ReturnsAsync(mockResponse);

            // Act
            var result = await _controller.UpdateHealthcareServiceStatus(1, request);

            // Assert
            result.Should().BeOfType<BadRequestObjectResult>();
            var badRequestResult = result as BadRequestObjectResult;
            badRequestResult?.Value.Should().BeEquivalentTo(mockResponse);
        }

        [Fact]
        public async Task UpdateHealthcareServiceStatus_ReturnsBadRequest_WhenDbUpdateConcurrencyExceptionIsThrown()
        {
            // Arrange
            var id = 1; // HealthcareService ID to update
            var request = new UpdateHealthcareStatusRequest
            {
                Status = false, // New status
            };

            var HealthcareService = new Domain.V1.Entities.HealthcareService.HealthcareServices
            {
                ID = id,
                Name = "Test HealthcareService",
                Status = true,
                LaymanDescription = "DESC1",
                CreatedBy = "testUser",
                CreatedDate = DateTime.UtcNow,
                IsDeleted = false,
                RecordVersion = new byte[] { 1, 2, 3, 4 }, // Simulate a version mismatch
                UpdatedDate = DateTime.UtcNow,
            };

            // Mock the FindHealthcareServiceById method to return the HealthcareService
            _mockHealthcareServicesQueryService.Setup(x => x.FindHealthcareServiceById(id))
                .ReturnsAsync(HealthcareService);

            // Mock the UpdateHealthcareService method to throw DbUpdateConcurrencyException
            _mockHealthcareServicesCommandService.Setup(x => x.UpdatHealthcareServiceStatusAsync(It.IsAny<UpdateHealthcareRequest>(), HealthcareService))
                .ThrowsAsync(new DbUpdateConcurrencyException("Concurrency conflict occurred."));

            // Act
            var result = await _controller.UpdateHealthcareServiceStatus(id, request);

            // Assert
            result.Should().BeOfType<BadRequestObjectResult>();

            var badRequestResult = result as BadRequestObjectResult;
            badRequestResult.Should().NotBeNull();

            var response = badRequestResult?.Value as GenericResponse<string>;
            response.Should().NotBeNull();
            response?.HasError.Should().BeTrue();
            response?.StatusCode.Should().Be(ResponseStatusCode.STATUS_BADREQUEST);
            response?.Message.Should().Be(CommonConstants.ERROR_DB_CONCURRENCY);
            response?.MessageType.Should().Be(CommonConstants.ERROR);
        }

        [Fact]
        public void GetHealthcareServiceSearch_ShouldReturnOk_WhenNoParametersAreProvided()
        {
            // Arrange
            var mockedResponse = new List<HealthcareServiceSearchResponse>
            {
                new HealthcareServiceSearchResponse
                {
                    Id = 1,
                    Speciality = "HealthcareService 1",
                    Status = true,
                    Location = "Malaisa",
                    UpdatedBy = "Admin",
                    UpdatedDate = DateTime.UtcNow,
                },
                new HealthcareServiceSearchResponse
                {
                    Id = 2,
                    Speciality = "HealthcareService 2",
                    Status = false,
                    Location = "Malaisa",
                    UpdatedBy = "Admin",
                    UpdatedDate = DateTime.UtcNow,
                }
            };

            // Mock the HealthcareService query service to return the mocked response
            _mockHealthcareServicesQueryService.Setup(service => service.GetHealthcareServiceSearch(It.IsAny<GetHealthcareSearchRequest>()))
                .Returns(mockedResponse);

            // Act
            var result = _controller.GetHealthcareSearch(null, null, null, null, null);

            // Assert
            result.Should().BeOfType<OkObjectResult>();
            var okResult = result as OkObjectResult;

            // Assert the structure of the response
            okResult?.Value.Should().BeOfType<GenericResponseList<HealthcareServiceSearchResponse>>();
            var response = okResult?.Value as GenericResponseList<HealthcareServiceSearchResponse>;
            response?.Results.Should().BeEquivalentTo(mockedResponse);  // Verify that the HealthcareServices returned are correct.
            response?.StatusCode.Should().Be(ResponseStatusCode.STATUS_SUCCESS);
            response?.Message.Should().Be(ResponseMessage.STATUS_DATA_FOUND);
            response?.TotalCount.Should().Be(mockedResponse.Count);
            response?.CurrentPage.Should().Be(1);  // Assuming no page number provided.
            response?.PageSize.Should().Be(10);   // Assuming default page size is 10.
            response?.MessageType.Should().Be(CommonConstants.SUCCESS);
        }

        [Fact]
        public void GetHealthcareServiceSearch_ShouldReturnBadRequest_WhenInvalidParametersAreProvided()
        {
            var mockedResponse = new GenericResponse<string>
            {
                IsSuccess = false,
                HasError = true,
                StatusCode = ResponseStatus.STATUS_BadRequest,
                Message = Resource.RegionCodeRequired
            };

            _mockRegionHelper.Setup(x => x.VerifyRegionCodeHeader(It.IsAny<HttpRequest>()))
                .Returns(mockedResponse);

            // Act
            var result = _controller.GetHealthcareSearch(null, null, null, null, null);

            // Assert
            result.Should().BeOfType<BadRequestObjectResult>();
            var badRequestResult = result as BadRequestObjectResult;
            badRequestResult?.Value.Should().BeEquivalentTo(mockedResponse);
        }

        [Fact]
        public void GetHealthcareServiceSearch_ShouldReturnNotFound_WhenNoHealthcareServicesFound()
        {
            // Arrange
            var emptyResponse = new List<HealthcareServiceSearchResponse>();

            _mockHealthcareServicesQueryService.Setup(service => service.GetHealthcareServiceSearch(It.IsAny<GetHealthcareSearchRequest>()))
                .Returns(emptyResponse);

            // Act
            var result = _controller.GetHealthcareSearch(null, null, null, null, null);

            // Assert
            result.Should().BeOfType<NotFoundObjectResult>();
            var notFoundResult = result as NotFoundObjectResult;

            // Assert response properties
            var response = notFoundResult?.Value as GenericResponseList<HealthcareServiceSearchResponse>;
            response?.StatusCode.Should().Be(ResponseStatusCode.STATUS_NOTFOUND);
            response?.Message.Should().Be(ResponseMessage.STATUS_NODATA);
        }

        [Fact]
        public void GetHealthcareServiceSearch_ShouldReturnOk_WhenParametersAreProvided()
        {
            // Arrange
            var mockedResponse = new List<HealthcareServiceSearchResponse>
            {
                new HealthcareServiceSearchResponse
                {
                    Id = 1,
                    Speciality = "HealthcareService 1",
                    Status = true,
                    Location = "Columbia",
                    UpdatedBy = "Admin",
                    UpdatedDate = DateTime.UtcNow
                }
            };

            _mockHealthcareServicesQueryService.Setup(service => service.GetHealthcareServiceSearch(It.IsAny<GetHealthcareSearchRequest>()))
                .Returns(mockedResponse);

            var selectedSpeciality = "HealthcareService 1";
            var selectedStatus = "Active";
            var selectedlocation = "Columbia";

            // Act
            var result = _controller.GetHealthcareSearch(1, 10, selectedSpeciality, selectedlocation, selectedStatus);

            // Assert
            result.Should().BeOfType<OkObjectResult>();
            var okResult = result as OkObjectResult;
            var response = okResult?.Value as GenericResponseList<HealthcareServiceSearchResponse>;
            response?.Results.Should().BeEquivalentTo(mockedResponse);
            response?.TotalCount.Should().Be(mockedResponse.Count);
            response?.StatusCode.Should().Be(ResponseStatusCode.STATUS_SUCCESS);
            response?.Message.Should().Be(ResponseMessage.STATUS_DATA_FOUND);
            response?.CurrentPage.Should().Be(1);
            response?.PageSize.Should().Be(10);
        }

        [Fact]
        public void GetHealthcareServiceSearch_ShouldReturnOk_WhenlocationandspecialityAreProvided()
        {
            // Arrange
            var mockedResponse = new List<HealthcareServiceSearchResponse>
            {
                new HealthcareServiceSearchResponse
                {
                    Id = 1,
                    Speciality = "HealthcareService 1",
                    Status = true,
                    Location = "Columbia",
                    UpdatedBy = "Admin",
                    UpdatedDate = DateTime.UtcNow
                }
            };

            _mockHealthcareServicesQueryService.Setup(service => service.GetHealthcareServiceSearch(It.IsAny<GetHealthcareSearchRequest>()))
                .Returns(mockedResponse);

            var selectedLocation = "HealthcareService 1";
            var selectedspeciality = "Columbia";

            // Act
            var result = _controller.GetHealthcareSearch(1, 10, selectedspeciality, selectedLocation, null);

            // Assert
            result.Should().BeOfType<OkObjectResult>();
            var okResult = result as OkObjectResult;
            var response = okResult?.Value as GenericResponseList<HealthcareServiceSearchResponse>;
            response?.Results.Should().BeEquivalentTo(mockedResponse);
            response?.TotalCount.Should().Be(mockedResponse.Count);
            response?.StatusCode.Should().Be(ResponseStatusCode.STATUS_SUCCESS);
        }

        [Fact]
        public void GetHealthcareServiceSearch_ShouldReturnOk_WhenPagedResponseIsReturned()
        {
            // Arrange
            var mockedResponse = new List<HealthcareServiceSearchResponse>
            {
                new HealthcareServiceSearchResponse
                {
                    Id = 1,
                    Speciality = "HealthcareService 1",
                    Status = true,
                    Location = "Columbia",
                    UpdatedBy = "Admin",
                    UpdatedDate = DateTime.UtcNow
                },
                new HealthcareServiceSearchResponse
                {
                    Id = 2,
                    Speciality = "HealthcareService 2",
                    Status = false,
                    Location = "Asia",
                    UpdatedBy = "Admin",
                    UpdatedDate = DateTime.UtcNow
                }
            };

            _mockHealthcareServicesQueryService.Setup(service => service.GetHealthcareServiceSearch(It.IsAny<GetHealthcareSearchRequest>()))
                .Returns(mockedResponse);

            var pageNumber = 1;
            var pageSize = 2;

            // Act
            var result = _controller.GetHealthcareSearch(pageNumber, pageSize, null, null, null);

            // Assert
            result.Should().BeOfType<OkObjectResult>();
            var okResult = result as OkObjectResult;
            var response = okResult?.Value as GenericResponseList<HealthcareServiceSearchResponse>;
            response?.Results.Should().BeEquivalentTo(mockedResponse);
            response?.TotalCount.Should().Be(mockedResponse.Count);
            response?.CurrentPage.Should().Be(pageNumber);
            response?.PageSize.Should().Be(pageSize);
        }
        [Fact]
        public async Task UpdateHealthcareServices_ReturnsBadRequest_WhenRegionCodeIsInvalid()
        {
            // Arrange
            var mockedResponse = new GenericResponse<string>
            {
                IsSuccess = false,
                HasError = true,
                StatusCode = ResponseStatus.STATUS_BadRequest,
                Message = Resource.RegionCodeRequired
            };

            _mockRegionHelper.Setup(x => x.VerifyRegionCodeHeader(It.IsAny<HttpRequest>()))
                .Returns(mockedResponse);

            var request = new UpdateHealthcareServicesDto
            {
                Id = 1,
                Name = "Updated Test HealthcareServices",
                Status = true,
                LaymanDescription = "Updated Description",
                Location = "Updated Location",
                RecordVersion = new byte[] { 1, 2, 3, 4 }
            };

            // Act
            var result = await _controller.UpdateHealthcareService(request);

            // Assert
            result.Should().BeOfType<BadRequestObjectResult>();
        }

        [Fact]
        public async Task UpdateHealthcareService_ShouldReturnBadRequest_WhenModelStateIsInvalid()
        {
            // Arrange
            var updateRequest = new UpdateHealthcareServicesDto
            {
                Id = 1,
                Name = "Updated Test HealthcareServices",
                Status = true,
                LaymanDescription = "Updated Description",
                Location = "Updated Location",
                RecordVersion = new byte[] { 1, 2, 3, 4 },
                HealthcareServicesKeyWords = new()
                {
                    Id = 1,
                    Keyword = "TestKey",
                    RecordVersion = new byte[] { 1, 2, 3, 4, 5 }
                }
            };
            // Simulate invalid model state
            _controller.ModelState.AddModelError("Name", "The Name field is required.");

            // Act
            var result = await _controller.UpdateHealthcareService(updateRequest);

            // Assert
            result.Should().BeOfType<BadRequestObjectResult>();
        }

        [Fact]
        public async Task UpdateHealthcareService_ShouldReturnNotFound_WhenHealthcareServiceKeyWordsNotFound()
        {
            // Arrange
            var updateRequest = new UpdateHealthcareServicesDto
            {
                Id = 1,
                Name = "Updated Service",
                Status = true,
                LaymanDescription = "Updated description",
                Location = "Updated location",
                RecordVersion = new byte[] { 1, 2, 3 },
                HealthcareServicesKeyWords = new UpdateHealthcareServicesKeyWordsDto
                {
                    Id = 123, // Non-existing keyword ID
                    Keyword = "Test",
                    RecordVersion = new byte[] { 1, 2, 3 }
                }
            };

            var healthcareServices = new Domain.V1.Entities.HealthcareService.HealthcareServices
            {
                ID = 1,
                Name = "HealthcareServices",
                Status = true,
                LaymanDescription = "Description",
                Location = "Location",
                CreatedBy = "testUser",
                CreatedDate = DateTime.UtcNow,
                IsDeleted = false,
                UpdatedDate = DateTime.UtcNow,
                RecordVersion = new byte[] { 1, 2, 3, 4 }
            };

            _mockRegionHelper.Setup(x => x.VerifyRegionCodeHeader(It.IsAny<HttpRequest>()))
                .Returns(new GenericResponse<string> { IsSuccess = true });

            // Mock healthcare service found
            _mockHealthcareServicesQueryService
                .Setup(service => service.FindHealthcareServiceById(updateRequest.Id))
                .ReturnsAsync(healthcareServices);

            // Mock keywords as NOT FOUND
            _mockHealthcareServicesQueryService
                .Setup(service => service.GetHealthcareServiceKeyWordsById(updateRequest.HealthcareServicesKeyWords.Id))
                .ReturnsAsync((HealthcareServicesKeyWords)null);


            // Act
            var result = await _controller.UpdateHealthcareService(updateRequest);

            // Assert
            result.Should().BeOfType<NotFoundObjectResult>();
            var notFoundResult = result as NotFoundObjectResult;


            var response = notFoundResult.Value as GenericResponse<string>;
            response.Should().NotBeNull();
            response!.IsSuccess.Should().BeFalse();
            response.HasError.Should().BeTrue();
            response.Message.Should().Be(ResponseMessage.STATUS_NODATA);
        }



        [Fact]
        public async Task UpdateHealthcareServices_ReturnsOk_WhenHealthcareServicesIsUpdatedSuccessfully()
        {
            // Arrange
            var request = new UpdateHealthcareServicesDto
            {
                Id = 1,
                Name = "Updated Test HealthcareServices",
                Status = true,
                LaymanDescription = "Updated Description",
                Location = "Updated Location",
                RecordVersion = new byte[] { 1, 2, 3, 4 },
                HealthcareServicesKeyWords = new() { Id = 1, Keyword = "TestKey", RecordVersion = new byte[] { 1, 2, 3, 4, 5 } }

            };

            var healthcareServices = new Domain.V1.Entities.HealthcareService.HealthcareServices
            {
                ID = 1,
                Name = "HealthcareServices",
                Status = true,
                LaymanDescription = "Description",
                Location = "Location",
                CreatedBy = "testUser",
                CreatedDate = DateTime.UtcNow,
                IsDeleted = false,
                UpdatedDate = DateTime.UtcNow,
                RecordVersion = new byte[] { 1, 2, 3, 4 }
            };
            var healthcareServicesKeywords = new Domain.V1.Entities.HealthcareService.HealthcareServicesKeyWords
            {
                ID = 1,
                HealthcareServicesID = 1,
                Keyword = "HealthcareServices",
                CreatedBy = "testUser",
                CreatedDate = DateTime.UtcNow,
                IsDeleted = false,
                UpdatedDate = DateTime.UtcNow,
                RecordVersion = new byte[] { 1, 2, 3, 4 }
            };

            var mockResponse = new GenericResponse<UpdateHealthcareServicesDto>
            {
                IsSuccess = true,
                HasError = false,
                StatusCode = ResponseStatus.STATUS_SUCCESS,
                Message = "HealthcareServices updated successfully"
            };

            _mockRegionHelper.Setup(x => x.VerifyRegionCodeHeader(It.IsAny<HttpRequest>()))
                .Returns(new GenericResponse<string> { IsSuccess = true });

            _mockHealthcareServicesQueryService.Setup(x => x.FindHealthcareServiceById(1))
                .ReturnsAsync(healthcareServices);
            _mockHealthcareServicesQueryService.Setup(x => x.GetHealthcareServiceKeyWordsById(1))
                .ReturnsAsync(healthcareServicesKeywords);

            _mockHealthcareServicesCommandService.Setup(x => x.UpdateHealthcareServiceAsync(It.IsAny<UpdateHealthcareServicesDto>(), healthcareServices, healthcareServicesKeywords))
                .ReturnsAsync(mockResponse);

            // Act
            var result = await _controller.UpdateHealthcareService(request);

            // Assert
            result.Should().BeOfType<OkObjectResult>();
            var okResult = result as OkObjectResult;
            okResult?.Value.Should().BeEquivalentTo(mockResponse);
        }

        [Fact]
        public async Task UpdateHealthcareServices_ReturnsNotFound_WhenHealthcareServicesIdNotFound()
        {
            // Arrange
            var request = new UpdateHealthcareServicesDto
            {
                Id = 1,
                Name = "Updated Test HealthcareServices",
                Status = true,
                LaymanDescription = "Updated Description",
                Location = "Updated Location",
                RecordVersion = new byte[] { 1, 2, 3, 4 },
                HealthcareServicesKeyWords = new()
                {
                    Id = 1,
                    Keyword = "Update",
                    RecordVersion = new byte[] { 1, 2, 3, 4, 5 },
                }
            };

            var mockResponse = new GenericResponse<string>
            {
                IsSuccess = false,
                HasError = true,
                StatusCode = ResponseStatus.STATUS_NotFound,
                Message = Resource.RecordNotFound,
                MessageType = CommonConstants.ERROR,
            };

            _mockRegionHelper.Setup(x => x.VerifyRegionCodeHeader(It.IsAny<HttpRequest>()))
                .Returns(new GenericResponse<string> { IsSuccess = true });

            _mockHealthcareServicesQueryService.Setup(x => x.FindHealthcareServiceById(It.IsAny<long>()))
               .ReturnsAsync((Domain.V1.Entities.HealthcareService.HealthcareServices)null);

            // Act
            var result = await _controller.UpdateHealthcareService(request);

            // Assert
            result.Should().BeOfType<NotFoundObjectResult>();
            var badRequestResult = result as NotFoundObjectResult;
            badRequestResult?.Value.Should().BeEquivalentTo(mockResponse);
        }

        [Fact]
        public async Task UpdateHealthcareServices_ReturnsBadRequest_WhenUpdatedFails()
        {
            // Arrange
            var request = new UpdateHealthcareServicesDto
            {
                Id = 1,
                Name = "Updated Test HealthcareServices",
                Status = true,
                LaymanDescription = "Updated Description",
                Location = "Updated Location",
                RecordVersion = new byte[] { 1, 2, 3, 4 },
                HealthcareServicesKeyWords = new() { Id = 1, Keyword = "TestKey", RecordVersion = new byte[] { 1, 2, 3, 4, 5 } }
            };

            var HealthcareServices = new Domain.V1.Entities.HealthcareService.HealthcareServices
            {
                ID = 1,
                Name = "HealthcareServices",
                Status = true,
                LaymanDescription = "Description",
                Location = "Location",
                CreatedBy = "testUser",
                CreatedDate = DateTime.UtcNow,
                IsDeleted = false,
                UpdatedDate = DateTime.UtcNow,
                RecordVersion = new byte[] { 1, 2, 3, 4 }
            };
            var HealthcareServicesKeywords = new Domain.V1.Entities.HealthcareService.HealthcareServicesKeyWords
            {
                ID = 1,
                HealthcareServicesID = 1,
                Keyword = "HealthcareServices",
                CreatedBy = "testUser",
                CreatedDate = DateTime.UtcNow,
                IsDeleted = false,
                UpdatedDate = DateTime.UtcNow,
                RecordVersion = new byte[] { 1, 2, 3, 4 }
            };

            var mockResponse = new GenericResponse<UpdateHealthcareServicesDto>
            {
                IsSuccess = false,
                HasError = true,
                StatusCode = ResponseStatus.STATUS_BadRequest,
                Message = "RecordVersion mismatch. Update failed."
            };

            _mockRegionHelper.Setup(x => x.VerifyRegionCodeHeader(It.IsAny<HttpRequest>()))
                .Returns(new GenericResponse<string> { IsSuccess = true });

            _mockHealthcareServicesQueryService.Setup(x => x.FindHealthcareServiceById(1))
                .ReturnsAsync(HealthcareServices);
            _mockHealthcareServicesQueryService.Setup(x => x.GetHealthcareServiceKeyWordsById(1))
                .ReturnsAsync(HealthcareServicesKeywords);

            _mockHealthcareServicesCommandService.Setup(x => x.UpdateHealthcareServiceAsync(request, HealthcareServices, HealthcareServicesKeywords))
                .ReturnsAsync(mockResponse);

            // Act
            var result = await _controller.UpdateHealthcareService(request);

            // Assert
            result.Should().BeOfType<BadRequestObjectResult>();
            var okResult = result as BadRequestObjectResult;
            okResult?.Value.Should().BeEquivalentTo(mockResponse);
        }

        [Fact]
        public async Task UpdateHealthcareServices_ReturnsBadRequest_WhenDbUpdateConcurrencyExceptionIsThrown()
        {
            // Arrange
            var request = new UpdateHealthcareServicesDto
            {
                Id = 1,
                Name = "Updated Test HealthcareServices",
                Status = true,
                LaymanDescription = "Updated Description",
                Location = "Updated Location",
                RecordVersion = new byte[] { 1, 2, 3, 4, 5 },
                HealthcareServicesKeyWords = new() { Id = 1, Keyword = "TestKey", RecordVersion = new byte[] { 1, 2, 3, 4, 5 } }

            };
            var HealthcareServices = new Domain.V1.Entities.HealthcareService.HealthcareServices
            {
                ID = 1,
                Name = "HealthcareServices",
                Status = true,
                LaymanDescription = "Description",
                Location = "Location",
                CreatedBy = "testUser",
                CreatedDate = DateTime.UtcNow,
                IsDeleted = false,
                UpdatedDate = DateTime.UtcNow,
                RecordVersion = new byte[] { 1, 2, 3, 4 }
            };
            var HealthcareServicesKeywords = new Domain.V1.Entities.HealthcareService.HealthcareServicesKeyWords
            {
                ID = 1,
                HealthcareServicesID = 1,
                Keyword = "HealthcareServices",
                CreatedBy = "testUser",
                CreatedDate = DateTime.UtcNow,
                IsDeleted = false,
                UpdatedDate = DateTime.UtcNow,
                RecordVersion = new byte[] { 1, 2, 3, 4 }
            };

            _mockRegionHelper.Setup(x => x.VerifyRegionCodeHeader(It.IsAny<HttpRequest>()))
                .Returns(new GenericResponse<string> { IsSuccess = true });

            _mockHealthcareServicesQueryService.Setup(x => x.FindHealthcareServiceById(1))
               .ReturnsAsync(HealthcareServices);
            _mockHealthcareServicesQueryService.Setup(x => x.GetHealthcareServiceKeyWordsById(1))
                .ReturnsAsync(HealthcareServicesKeywords);

            // Mock the UpdateHealthcareServices method to throw DbUpdateConcurrencyException
            _mockHealthcareServicesCommandService.Setup(x => x.UpdateHealthcareServiceAsync(request, HealthcareServices, HealthcareServicesKeywords))
               .ThrowsAsync(new DbUpdateConcurrencyException("Concurrency conflict occurred."));

            // Act
            var result = await _controller.UpdateHealthcareService(request);

            // Assert
            result.Should().BeOfType<BadRequestObjectResult>();

            var badRequestResult = result as BadRequestObjectResult;
            badRequestResult.Should().NotBeNull();

            var response = badRequestResult?.Value as GenericResponse<string>;
            response.Should().NotBeNull();
            response?.HasError.Should().BeTrue();
            response?.StatusCode.Should().Be(ResponseStatusCode.STATUS_BADREQUEST);
            response?.Message.Should().Be(CommonConstants.ERROR_DB_CONCURRENCY);
            response?.MessageType.Should().Be(CommonConstants.ERROR);
        }

        [Fact]
        public async Task GetHealthcareServiceDetailsById_ReturnsBadRequest_WhenRegionCodeHeaderIsInvalid()
        {
            // Arrange
            var badRequestResponse = new GenericResponse<string>
            {
                IsSuccess = false,
                StatusCode = ResponseStatusCode.STATUS_BADREQUEST,
                Message = "Region Code is invalid",
                HasError = true,
                MessageType = CommonConstants.ERROR
            };
            _mockRegionHelper.Setup(r => r.VerifyRegionCodeHeader(It.IsAny<HttpRequest>()))
                                            .Returns(badRequestResponse);

            // Act
            var result = await _controller.GetHealthcareServiceDetailsById(1);

            // Assert
            var actionResult = result.Result as BadRequestObjectResult;
            actionResult.Should().NotBeNull();
            var response = actionResult.Value as GenericResponse<string>;
            response.Should().NotBeNull();
            response.Message.Should().Be("Region Code is invalid");
        }

        [Fact]
        public async Task GetHealthcareServiceDetailsById_ReturnsNotFound_WhenHealthcareServiceNotFound()
        {
            // Arrange
            _mockRegionHelper.Setup(r => r.VerifyRegionCodeHeader(It.IsAny<HttpRequest>()))
                                            .Returns((GenericResponse<string>)null);
            _mockHealthcareServicesQueryService.Setup(s => s.GetHealthcareServiceAsync(It.IsAny<long>()))
                                        .ReturnsAsync((GetHealthcareServiceDto)null);

            // Act
            var result = await _controller.GetHealthcareServiceDetailsById(1);

            // Assert
            var actionResult = result.Result as NotFoundObjectResult;
            actionResult.Should().NotBeNull();
            var response = actionResult.Value as GenericResponse<string>;
            response.Should().NotBeNull();
            response.Message.Should().Be(ResponseMessage.STATUS_NODATA);
        }

        [Fact]
        public async Task GetHealthcareServiceDetailsById_ReturnsOk_WhenHealthcareServiceFound()
        {
            // Arrange
            _mockRegionHelper.Setup(r => r.VerifyRegionCodeHeader(It.IsAny<HttpRequest>()))
                                            .Returns((GenericResponse<string>)null);

            var healthcareService = new GetHealthcareServiceDto { /* fill this with mock data */ };
            _mockHealthcareServicesQueryService.Setup(s => s.GetHealthcareServiceAsync(It.IsAny<long>()))
                                        .ReturnsAsync(healthcareService);

            // Act
            var result = await _controller.GetHealthcareServiceDetailsById(1);

            // Assert
            var actionResult = result.Result as OkObjectResult;
            actionResult.Should().NotBeNull();
            var response = actionResult.Value as GenericResponse<GetHealthcareServiceDto>;
            response.Should().NotBeNull();
            response.IsSuccess.Should().BeTrue();
            response.Message.Should().Be(ResponseMessage.STATUS_DATA_FOUND);
            response.Result.Should().Be(healthcareService);
        }

        private static CreateHealthcareServicesDto GetHealthcareServiceMockData()
        {
            // Arrange
            return new CreateHealthcareServicesDto { Name = "Darmalogist", LaymanDescription = "Skin Doctor", Location = "KLAN" };
        }

        [Fact]
        public async Task DeleteHealthcareService_ShouldReturnBadRequest_WhenRegionCodeIsInvalid()
        {
            // Arrange
            var badRequestResponse = new GenericResponse<string>
            {
                IsSuccess = false,
                StatusCode = ResponseStatusCode.STATUS_BADREQUEST,
                Message = "Region Code is invalid",
                HasError = true,
                MessageType = CommonConstants.ERROR
            };
            _mockRegionHelper.Setup(r => r.VerifyRegionCodeHeader(It.IsAny<HttpRequest>()))
                                            .Returns(badRequestResponse);

            // Act
            var result = await _controller.DeleteHealthcareService(1);

            // Assert
            result.Should().BeOfType<BadRequestObjectResult>();
        }

        [Fact]
        public async Task DeleteHealthcareService_ShouldReturnNotFound_WhenServiceNotFound()
        {
            // Arrange
            _mockRegionHelper.Setup(r => r.VerifyRegionCodeHeader(It.IsAny<HttpRequest>()))
                                            .Returns((GenericResponse<string>)null);

            _mockHealthcareServicesQueryService.Setup(x => x.FindHealthcareServiceById(It.IsAny<long>()))
               .ReturnsAsync((Domain.V1.Entities.HealthcareService.HealthcareServices)null);

            // Act
            var result = await _controller.DeleteHealthcareService(0);

            // Assert
            result.Should().BeOfType<NotFoundObjectResult>();

            var notFoundResult = result as NotFoundObjectResult;
            var response = notFoundResult.Value as GenericResponse<string>;

            response.Should().NotBeNull();
            response.StatusCode.Should().Be(ResponseStatusCode.STATUS_NOTFOUND);
            response.Message.Should().Be(ResponseMessage.STATUS_NODATA);
            response.IsSuccess.Should().BeTrue();
            response.HasError.Should().BeFalse();
        }

        [Fact]
        public async Task DeleteHealthcareService_ShouldReturnOk_WhenDeletedSuccessfully()
        {
            // Arrange
            var healthcareServices = new Domain.V1.Entities.HealthcareService.HealthcareServices
            {
                ID = 1,
                Name = "HealthcareServices",
                Status = true,
                LaymanDescription = "Description",
                Location = "Location",
                CreatedBy = "testUser",
                CreatedDate = DateTime.UtcNow,
                IsDeleted = true,
                UpdatedDate = DateTime.UtcNow,
                RecordVersion = new byte[] { 1, 2, 3, 4 }
            };
            _mockRegionHelper.Setup(r => r.VerifyRegionCodeHeader(It.IsAny<HttpRequest>()))
                                            .Returns((GenericResponse<string>)null);

            _mockHealthcareServicesQueryService.Setup(x => x.FindHealthcareServiceById(It.IsAny<long>()))
                .ReturnsAsync(healthcareServices);

            _mockHealthcareServicesCommandService.Setup(x => x.DeleteHealthcareServiceAsync(It.IsAny<byte[]>(), It.IsAny<Domain.V1.Entities.HealthcareService.HealthcareServices>()))
                .ReturnsAsync(true);

            // Act
            var result = await _controller.DeleteHealthcareService(1);

            // Assert
            result.Should().BeOfType<OkObjectResult>();

            var okResult = result as OkObjectResult;
            var response = okResult.Value as GenericResponse<string>;

            response.Should().NotBeNull();
            response.StatusCode.Should().Be(ResponseStatusCode.STATUS_SUCCESS);
            response.Message.Should().Be(Resource.RecordDeleteionMessage);
            response.MessageType.Should().Be(CommonConstants.SUCCESS);
        }

        [Fact]
        public async Task DeleteHealthcareService_ShouldReturnBadRequest_WhenDeletionFails()
        {
            // Arrange
            var healthcareServices = new Domain.V1.Entities.HealthcareService.HealthcareServices
            {
                ID = 1,
                Name = "HealthcareServices",
                Status = true,
                LaymanDescription = "Description",
                Location = "Location",
                CreatedBy = "testUser",
                CreatedDate = DateTime.UtcNow,
                IsDeleted = false,
                UpdatedDate = DateTime.UtcNow,
                RecordVersion = new byte[] { 1, 2, 3, 4 }
            };
            _mockRegionHelper.Setup(r => r.VerifyRegionCodeHeader(It.IsAny<HttpRequest>()))
                                            .Returns((GenericResponse<string>)null);

            _mockHealthcareServicesQueryService.Setup(x => x.FindHealthcareServiceById(It.IsAny<long>()))
                .ReturnsAsync(healthcareServices);

            _mockHealthcareServicesCommandService.Setup(x => x.DeleteHealthcareServiceAsync(It.IsAny<byte[]>(), It.IsAny<Domain.V1.Entities.HealthcareService.HealthcareServices>()))
                .ReturnsAsync(false);

            // Act
            var result = await _controller.DeleteHealthcareService(1);

            // Assert
            var badRequestResult = result as ObjectResult;
            badRequestResult.Should().NotBeNull();
            badRequestResult.StatusCode.Should().Be((int)HttpStatusCode.BadRequest);

            var response = badRequestResult.Value as GenericResponse<string>;
            response.Should().NotBeNull();
            response.StatusCode.Should().Be(ResponseStatusCode.STATUS_BADREQUEST);
            response.Message.Should().Be(Resource.RecordDeletionFailureMessage);
            response.MessageType.Should().Be(CommonConstants.ERROR);
        }
    }
}
