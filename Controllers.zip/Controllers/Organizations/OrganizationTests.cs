﻿using Aurora.AdministrationService.API.Controllers.Organizations;
using Aurora.AdministrationService.API.Enum;
using Aurora.AdministrationService.API.Helper;
using Aurora.AdministrationService.API.Models.Dto.Organizations;
using Aurora.AdministrationService.API.Models.ResponseModels.Organizations;
using Aurora.AdministrationService.API.Resources;
using Aurora.AdministrationService.API.Services.IService.Organizations;
using Aurora.AdministrationService.CrossCutting.CommonModels;
using FluentAssertions;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Moq;

namespace Aurora.AdministrationService.Tests.API.Controllers.Organizations
{
    public class OrganizationTests
    {
        private readonly Mock<IOrganizationService> _mockOrganizationService;
        private readonly Mock<IOrganizationQueryService> _mockOrganizationQueryService;
        private readonly OrganizationController _controller;
        private readonly Mock<IRegionCodeValidationHelper> _mockRegionCodeHelper;
        public OrganizationTests()
        {
            _mockRegionCodeHelper = new Mock<IRegionCodeValidationHelper>();
            _mockOrganizationService = new Mock<IOrganizationService>();
            _mockOrganizationQueryService = new Mock<IOrganizationQueryService>();

            _controller = new OrganizationController(
                _mockOrganizationService.Object,
                _mockRegionCodeHelper.Object,
                _mockOrganizationQueryService.Object
            );
        }

        [Fact]
        public async Task GetAllOrganizations_ShouldReturnOk_WhenRegionCodeIsValid()
        {
            // Arrange
            var regionCode = "MYS";
            var mockResponse = new GenericResponse<string>
            {
                IsSuccess = false,
                HasError = true,
                StatusCode = ResponseStatus.STATUS_BadRequest,
                Message = null,
                Result = regionCode
            };

            var context = new DefaultHttpContext();
            var request = context.Request;

            // Add headers to the HttpRequest
            request.Headers["RegionCode"] = regionCode;

            _mockRegionCodeHelper.Setup(x => x.VerifyRegionCodeHeader(request))
                .Returns(mockResponse);

            _mockOrganizationService.Setup(x => x.GetAllOrganizationsAsync())
                .ReturnsAsync(new GenericResponseList<OrganizationResponseDTO>()
                {
                    Results = new List<OrganizationResponseDTO>() { }
                });

            // Act
            var result = await _controller.GetOrganizations();

            // Assert
            result.Should().BeOfType<OkObjectResult>();
        }

        [Fact]
        public async Task GetAllOrganizations_ShouldReturnNotFound_WhenNoOrganizations()
        {
            // Arrange
            var mockedResponse = new GenericResponse<string>
            {
                IsSuccess = true,
                HasError = false,
                StatusCode = ResponseStatus.STATUS_SUCCESS,
                Message = string.Empty
            };
            var mockedNotFoundResponse = new GenericResponseList<OrganizationResponseDTO>()
            {
                HasError = false,
                IsSuccess = true,
                StatusCode = ((int)ResponceStatusCode.NotFound).ToString(),
                Results = new List<OrganizationResponseDTO>(),
            };

            _mockRegionCodeHelper.Setup(x => x.VerifyRegionCodeHeader(It.IsAny<HttpRequest>()))
                .Returns(mockedResponse);

            _mockOrganizationService.Setup(service => service.GetAllOrganizationsAsync())
               .ReturnsAsync(mockedNotFoundResponse);

            // Act
            var result = await _controller.GetOrganizations();

            // Assert
            result.Should().BeOfType<NotFoundObjectResult>();
        }

        [Fact]
        public async Task GetAllOrganizations_ShouldReturnBadRequest_WhenRegionCodeIsInvalid()
        {
            // Arrange
            var mockedResponse = new GenericResponse<string>
            {
                IsSuccess = false,
                HasError = true,
                StatusCode = ResponseStatus.STATUS_BadRequest,
                Message = Resource.RegionCodeRequired
            };

            _mockRegionCodeHelper.Setup(x => x.VerifyRegionCodeHeader(It.IsAny<HttpRequest>()))
                .Returns(mockedResponse);

            // Act
            var result = await _controller.GetOrganizations();

            // Assert
            result.Should().BeOfType<BadRequestObjectResult>();
        }

        [Fact]
        public async Task GetAllOrganizationMaster_ShouldReturnOk_WhenRegionCodeIsValid()
        {
            // Arrange
            var regionCode = "MYS";
            var mockResponse = new GenericResponse<string>
            {
                IsSuccess = true,
                HasError = false,
                StatusCode = ResponseStatus.STATUS_SUCCESS,
                Message = null,
                Result = regionCode
            };

            var context = new DefaultHttpContext();
            var request = context.Request;
            request.Headers["RegionCode"] = regionCode;

            _mockRegionCodeHelper.Setup(x => x.VerifyRegionCodeHeader(request))
            .Returns(mockResponse);

            var hospitals = new GenericResponseList<GetOraganizationMasterDto>()
            {
                Results = new List<GetOraganizationMasterDto>() { new GetOraganizationMasterDto { Id = 1, Name = "Org1", ResourceID = "123", } }
            };

            _mockOrganizationQueryService.Setup(x => x.GetOrganizationMasterList())
                .Returns(hospitals);

            // Act
            var result = await _controller.GetOrganizationMaster();

            // Assert
            result.Should().BeOfType<OkObjectResult>();
        }

        [Fact]
        public async Task GetAllOrganizationMaster_ShouldReturnNotFound_WhenNoOrganizations()
        {
            // Arrange
            var mockedResponse = new GenericResponse<string>
            {
                IsSuccess = true,
                HasError = false,
                StatusCode = ResponseStatus.STATUS_SUCCESS,
                Message = string.Empty
            };
            var mockedNotFoundResponse = new GenericResponseList<GetOraganizationMasterDto>
            {
                HasError = false,
                IsSuccess = true,
                StatusCode = ResponceStatusCode.RecordNotFound.ToString(),
                Results = new List<GetOraganizationMasterDto>(),
            };

            _mockRegionCodeHelper.Setup(x => x.VerifyRegionCodeHeader(It.IsAny<HttpRequest>()))
                .Returns(mockedResponse);

            _mockOrganizationQueryService.Setup(service => service.GetOrganizationMasterList())
               .Returns(mockedNotFoundResponse);

            // Act
            var result = await _controller.GetOrganizationMaster();

            // Assert
            result.Should().BeOfType<NotFoundObjectResult>();
        }

        [Fact]
        public async Task GetAllOrganizationMaster_ShouldReturnBadRequest_WhenRegionCodeIsInvalid()
        {
            // Arrange
            var mockedResponse = new GenericResponse<string>
            {
                IsSuccess = false,
                HasError = true,
                StatusCode = ResponseStatus.STATUS_BadRequest,
                Message = Resource.RegionCodeRequired
            };

            _mockRegionCodeHelper.Setup(x => x.VerifyRegionCodeHeader(It.IsAny<HttpRequest>()))
                .Returns(mockedResponse);

            // Act
            var result = await _controller.GetOrganizationMaster();

            // Assert
            result.Should().BeOfType<BadRequestObjectResult>();
        }
    }
}
