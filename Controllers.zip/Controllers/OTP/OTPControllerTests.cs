﻿using Aurora.AdministrationService.API.Enum.OTP;
using Aurora.AdministrationService.API.Helper;
using Aurora.AdministrationService.API.Models.RequestModels.OTP;
using Aurora.AdministrationService.API.Models.ResponseModels.OTP;
using Aurora.AdministrationService.API.Services.IService.OTP;
using Aurora.AdministrationService.CrossCutting.CommonModels;
using FluentAssertions;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Moq;
using PatientWebAdmin.API.Controllers.OTP;

namespace Aurora.PatientLifeCycleService.Tests.Controllers.OTP
{
    /// <summary>
    /// Test cases for Otp Contorller
    /// </summary>
    public class OtpControllerTests
    {
        private readonly Mock<IRegionCodeValidationHelper> _regionCodeHelperMock;
        private readonly Mock<IOtpService> _otpServiceMock;
        private readonly OtpController _controller;
       
        public OtpControllerTests()
        {
            _regionCodeHelperMock = new Mock<IRegionCodeValidationHelper>();
            _otpServiceMock = new Mock<IOtpService>();
            _controller = new OtpController(_otpServiceMock.Object, _regionCodeHelperMock.Object);
        }

        [Fact]
        public async Task SendOTP_ShouldReturnOk_WhenRequestIsValid()
        {
            // Arrange
            var contactSelectionDto = new ContactSelectionDto { Email = "example@example.com" };
            var response = new GenericResponse<string> { IsSuccess = true, Message = "OTP sent successfully." };

            _regionCodeHelperMock
                .Setup(helper => helper.VerifyRegionCodeHeader(It.IsAny<HttpRequest>()))
                .Returns((GenericResponse<string>)null!);

            _otpServiceMock
                .Setup(service => service.SendOtpAsync(contactSelectionDto))
                .ReturnsAsync(response);

            // Act
            var result = await _controller.SendOTP(contactSelectionDto);

            // Assert
            result.Should().BeOfType<OkObjectResult>();
                
        }
        [Fact]
        public async Task SendOTP_ShouldReturnBadRequest_WhenRegionCodeIsInvalid()
        {
            // Arrange
            var contactSelectionDto = new ContactSelectionDto { Email = "example@example.com" };
            var verifyStatus = new GenericResponse<string> { HasError = true, Message = "Invalid region code." };

            _regionCodeHelperMock
                .Setup(helper => helper.VerifyRegionCodeHeader(It.IsAny<HttpRequest>()))
                .Returns(verifyStatus);

            // Act
            var result = await _controller.SendOTP(contactSelectionDto);

            // Assert
            result.Should().BeOfType<BadRequestObjectResult>()
                .Which.Value.Should().BeEquivalentTo(verifyStatus);
        }

        [Fact]
        public async Task SendOTP_ShouldReturnBadRequest_WhenModelStateIsInvalid()
        {
            // Arrange
            var contactSelectionDto = new ContactSelectionDto(); // Missing required properties

            _controller.ModelState.AddModelError("Contact", "Contact is required.");

            // Act
            var result = await _controller.SendOTP(contactSelectionDto);

            // Assert
            result.Should().BeOfType<BadRequestObjectResult>();
        }

        [Fact]
        public async Task ValidateOtp_ShouldReturnOk_WhenRequestIsValid()
        {
            // Arrange
            var request = new OtpValidationRequest
            {
                UserId = "12345",
                Otp = "123456",
                OtpType = OTPType.Email,
                Email = "example@example.com",
                MobileNo = "1234567890"
            };
            var response = new GenericResponse<OTPResponse> { IsSuccess = true, Message = "OTP validated successfully." };

            _regionCodeHelperMock
                .Setup(helper => helper.VerifyRegionCodeHeader(It.IsAny<HttpRequest>()))
                .Returns((GenericResponse<string>)null!);

            _otpServiceMock
                .Setup(service => service.ValidateOtpAsync(request.UserId, request.Otp, request.OtpType, request.Email, request.MobileNo))
                .ReturnsAsync(response);

            // Act
            var result = await _controller.ValidateOtp(request);

            // Assert
            result.Should().BeOfType<OkObjectResult>();
        }

        [Fact]
        public async Task ValidateOtp_ShouldReturnBadRequest_WhenRegionCodeIsInvalid()
        {
            // Arrange
            var request = new OtpValidationRequest { UserId = "12345", Otp = "123456" };
            var verifyStatus = new GenericResponse<string> { IsSuccess = false, HasError=true, Message = "Invalid region code." };

            _regionCodeHelperMock
                .Setup(helper => helper.VerifyRegionCodeHeader(It.IsAny<HttpRequest>()))
                .Returns(verifyStatus);

            // Act
            var result = await _controller.ValidateOtp(request);

            // Assert
            result.Should().BeOfType<BadRequestObjectResult>()
                .Which.Value.Should().BeEquivalentTo(verifyStatus);
        }
    }
}
