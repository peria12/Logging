﻿using Aurora.AdministrationService.API.Models.Dto.FloorMap;
using Aurora.AdministrationService.CrossCutting.CommonModels;
using Moq;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Http;
using Xunit;
using Microsoft.Extensions.Logging;
using Aurora.AdministrationService.API.Helper;
using Aurora.AdministrationService.CrossCutting.Constants;
using Aurora.AdministrationService.API.Controllers.FloorMap;
using Aurora.AdministrationService.API.Services.IService.FloorMap;
using Aurora.AdministrationService.API.Models.Dto.Locations.LocationImages;

namespace Aurora.AdministrationService.API.Tests.FloorMap
{
    public class FloorMapControllerTests
    {
        private readonly Mock<IFloorMapQueryService> _floorMapQueryServiceMock;
        private readonly Mock<IRegionCodeValidationHelper> _regionCodeValidationHelperMock;
        private readonly FloorMapController _controller;

        public FloorMapControllerTests()
        {
            _floorMapQueryServiceMock = new Mock<IFloorMapQueryService>();
            _regionCodeValidationHelperMock = new Mock<IRegionCodeValidationHelper>();

            _controller = new FloorMapController(
                _floorMapQueryServiceMock.Object,
                _regionCodeValidationHelperMock.Object
            );
        }

        #region Test: GetFloorMaps

        [Fact]
        public void GetFloorMaps_ReturnsBadRequest_WhenRegionCodeIsInvalid()
        {
            // Arrange
            var locationId = 123;
            var pageNumber = 1;
            var pageSize = 10;

            // Mock region code validation failure
            _regionCodeValidationHelperMock.Setup(r => r.VerifyRegionCodeHeader(It.IsAny<HttpRequest>()))
                .Returns(new GenericResponse<string> { IsSuccess = false, HasError = true, Message = "Invalid Region Code" });

            // Act
            var result = _controller.GetFloorMapDetail(locationId, pageNumber, pageSize);

            // Assert
            var badRequestResult = Assert.IsType<BadRequestObjectResult>(result);
            var response = Assert.IsType<GenericResponse<string>>(badRequestResult.Value);
            Assert.False(response.IsSuccess);
            Assert.Equal("Invalid Region Code", response.Message);
        }

        [Fact]
        public void GetFloorMaps_ReturnsBadRequest_WhenModelStateIsInvalid()
        {
            // Arrange
            var locationId = 123;
            var pageNumber = 1;
            var pageSize = 10;

            _controller.ModelState.AddModelError("locationId", "Location ID is required");

            // Act
            var result = _controller.GetFloorMapDetail(locationId, pageNumber, pageSize);

            // Assert
            var badRequestResult = Assert.IsType<BadRequestObjectResult>(result);
            Assert.IsType<SerializableError>(badRequestResult.Value);
        }

        [Fact]
        public void GetFloorMaps_ReturnsNotFound_WhenFloorMapsAreNotFound()
        {
            // Arrange
            var locationId = 123;
            var pageNumber = 1;
            var pageSize = 10;

            _regionCodeValidationHelperMock.Setup(r => r.VerifyRegionCodeHeader(It.IsAny<HttpRequest>()))
                .Returns(new GenericResponse<string> { IsSuccess = true, Result = "MYS" });

            // Mock the service to return a not found status
            _floorMapQueryServiceMock.Setup(f => f.GetFloorMaps(It.IsAny<long>(), It.IsAny<int?>(), It.IsAny<int?>()))
                .Returns(new GenericResponseList<GetLocationImageByLocationIdDto> { StatusCode = ResponseStatusCode.STATUS_NOTFOUND });

            // Act
            var result = _controller.GetFloorMapDetail(locationId, pageNumber, pageSize);

            // Assert
            var notFoundResult = Assert.IsType<NotFoundObjectResult>(result);
            var response = Assert.IsType<GenericResponseList<GetLocationImageByLocationIdDto>>(notFoundResult.Value);
            Assert.Equal(ResponseStatusCode.STATUS_NOTFOUND, response.StatusCode);
        }

        [Fact]
        public void GetFloorMaps_ReturnsOk_WhenFloorMapsAreFound()
        {
            // Arrange
            var locationId = 123;
            var pageNumber = 1;
            var pageSize = 10;

            _regionCodeValidationHelperMock.Setup(r => r.VerifyRegionCodeHeader(It.IsAny<HttpRequest>()))
                .Returns(new GenericResponse<string> { IsSuccess = true, Result = "MYS" });

            // Mock the service to return a valid response
            var floorMaps = new GenericResponseList<GetLocationImageByLocationIdDto>
            {
                IsSuccess = true,
                HasError = false,
                StatusCode = ResponseStatusCode.STATUS_SUCCESS,
                Results = new List<GetLocationImageByLocationIdDto> { new GetLocationImageByLocationIdDto { ID = 1,  URL = "mapurl1" } }
            };
            _floorMapQueryServiceMock.Setup(f => f.GetFloorMaps(It.IsAny<long>(), It.IsAny<int?>(), It.IsAny<int?>()))
                .Returns(floorMaps);

            // Act
            var result = _controller.GetFloorMapDetail(locationId, pageNumber, pageSize);

            // Assert
            var okResult = Assert.IsType<OkObjectResult>(result);
            var response = Assert.IsType<GenericResponseList<GetLocationImageByLocationIdDto>>(okResult.Value);
            Assert.True(response.IsSuccess);
            Assert.NotEmpty(response.Results);
        }

        #endregion
    }
}
