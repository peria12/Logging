﻿using Aurora.AdministrationService.API.Controllers.AdminLanguage;
using Aurora.AdministrationService.API.Helper;
using Aurora.AdministrationService.API.Models.ResponseModels.V1.AdminDoctor;
using Aurora.AdministrationService.API.Services.IService.AdminDoctor;
using Aurora.AdministrationService.API.Services.IService.DoctorLanguage;
using Aurora.AdministrationService.CrossCutting.CommonModels;
using Aurora.AdministrationService.CrossCutting.Constants;
using Aurora.AdministrationService.Tests.API.CommonMock;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Moq;

namespace Aurora.AdministrationService.Tests.API.Controllers.V1.AdminLanguage;

public class LanguageControllerTests
{
    private readonly Mock<IDoctorLanguageQueryService> _mockQueryService;
    private readonly Mock<IRegionCodeValidationHelper> _mockRegionHelper;
    private readonly LanguageController _controller;

    public LanguageControllerTests()
    {
        _mockQueryService = new Mock<IDoctorLanguageQueryService>();
        _mockRegionHelper = new Mock<IRegionCodeValidationHelper>();
        _controller = new LanguageController(_mockQueryService.Object, _mockRegionHelper.Object);
    }

    public static IEnumerable<object[]> GetDoctorLanguageList()
    {
        yield return new object[] { 200, true };
        yield return new object[] { 400, false };
        yield return new object[] { 400, true, false };
    }

    [Theory]
    [MemberData(nameof(GetDoctorLanguageList))]
    public async Task GetDoctorLanguageList_ShouldReturnExpectedResult(int expectedStatusCode, bool isValidResponse, bool isVerifyStatus = true)
    {
        var languageResult = new GenericResponseList<LanguageResponseDto>()
        {
            IsSuccess = true,
            HasError = false,
            Results = !isValidResponse ? null : new List<LanguageResponseDto>()
            {
                DTO.GetLanguageResponseDto()
            }
        };

        _mockQueryService.Setup(q => q.GetDoctorLanguageList()).ReturnsAsync(languageResult);

        if (isVerifyStatus)
            _mockRegionHelper.Setup(r => r.VerifyRegionCodeHeader(It.IsAny<HttpRequest>())).Returns(new GenericResponse<string>() { IsSuccess = true });
        else
            _mockRegionHelper.Setup(r => r.VerifyRegionCodeHeader(It.IsAny<HttpRequest>())).Returns(new GenericResponse<string>() { IsSuccess = false, HasError = true });

        var result = await _controller.GetDoctorLanguageList();
        if (!isValidResponse)
        {
            var objectResult = Assert.IsType<BadRequestResult>(result);
            Assert.Equal(expectedStatusCode, objectResult?.StatusCode);
        }
        else if (expectedStatusCode == 200)
        {
            var objectResult = Assert.IsType<OkObjectResult>(result);
            Assert.Equal(expectedStatusCode, objectResult?.StatusCode);
        }
        else
        {
            var objectResult = Assert.IsType<BadRequestObjectResult>(result);
            Assert.Equal(expectedStatusCode, objectResult?.StatusCode);
        }
    }
}
