﻿using Aurora.AdministrationService.API.Controllers.UploadFile;
using Aurora.AdministrationService.API.Helper;
using Aurora.AdministrationService.API.Models.ResponseModels.UploadFile;
using Aurora.AdministrationService.API.Services.IService.FileUpload;
using Aurora.AdministrationService.API.Validations;
using Aurora.AdministrationService.CrossCutting.CommonModels;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Graph;
using Moq;

namespace Aurora.AdministrationService.Tests.API.Controllers.V1.UploadFile;

public class UploadFileControllerTests
{
    private readonly Mock<IUploadFiles> _mockUploadFilesService;
    private readonly Mock<IRegionCodeValidationHelper> _mockRegionHelper;
    private readonly Mock<IFileValidator> _mockFileValidator;
    private readonly UploadFileController _controller;

    public UploadFileControllerTests()
    {
        _mockUploadFilesService = new Mock<IUploadFiles>();
        _mockRegionHelper = new Mock<IRegionCodeValidationHelper>();
        _mockFileValidator = new Mock<IFileValidator>();
        _controller = new UploadFileController(_mockUploadFilesService.Object, _mockRegionHelper.Object, _mockFileValidator.Object);
    }

    [Theory]
    [InlineData("ValidRegion", "ValidModule", true, true, 200)]
    [InlineData("InvalidRegion", "ValidModule", false, true, 400)]
    [InlineData("ValidRegion", "InvalidModule", true, false, 400)]
    public async Task UploadFile_TestCases(string regionCode, string moduleName, bool isRegionValid, bool isFileValid, int expectedStatusCode)
    {
        // Arrange
        var fileMock = new Mock<IFormFile>();
        var content = "Fake file content";
        var fileName = "test.txt";
        var stream = new MemoryStream(System.Text.Encoding.UTF8.GetBytes(content));
        fileMock.Setup(f => f.OpenReadStream()).Returns(stream);
        fileMock.Setup(f => f.FileName).Returns(fileName);

        _mockRegionHelper.Setup(r => r.VerifyRegionCodeHeader(It.IsAny<HttpRequest>()))
                         .Returns(isRegionValid ? null : new GenericResponse<string>() { IsSuccess = true, HasError = true });

        _mockFileValidator.Setup(f => f.IsValid(It.IsAny<IFormFile>(), It.IsAny<string>(), out It.Ref<string>.IsAny))
                          .Returns(isFileValid);

        if (isRegionValid && isFileValid)
        {
            _mockUploadFilesService.Setup(u => u.UploadFileToModuleAsync(moduleName, fileName, It.IsAny<Stream>(), regionCode))
                                   .ReturnsAsync(new GenericResponse<string>() { Result = "http://example.com/uploadedfile", IsSuccess = true });
        }

        // Act
        var result = await _controller.UploadFile(regionCode, moduleName, fileMock.Object) as ObjectResult;

        // Assert
        Assert.NotNull(result);
        Assert.Equal(expectedStatusCode, result.StatusCode);
    }

    [Theory]
    [InlineData("ValidRegion", "Module1", "ExistingFile1", true, null, true, "FileUpdatedURI")]
    [InlineData("InvalidRegion", "Module1", "ExistingFile1", false, "Invalid file format", true, null)]
    [InlineData("ValidRegion", "Module1", "ExistingFile1", true, null, false, "Invalid file format")]
    public async Task UpdateFile_ReturnsExpectedResult(
        string regionCode,
        string moduleName,
        string existingFileName,
        bool isRegionValid,
        string regionError,
        bool isFileValid,
        string fileServiceResponse)
    {
        // Arrange
        var fileMock = new Mock<IFormFile>();
        var ms = new MemoryStream();
        var writer = new StreamWriter(ms);
        writer.Write("Dummy content");
        writer.Flush();
        ms.Position = 0;
        var serviceResponse = new GenericResponse<string>() { IsSuccess = true, HasError = false, Result = fileServiceResponse };
        fileMock.Setup(f => f.OpenReadStream()).Returns(ms);
        fileMock.Setup(f => f.Length).Returns(ms.Length);

        var validationResult = isRegionValid ? null : "https://test.com";
        bool isValid = (isRegionValid && isFileValid);
        _mockRegionHelper.Setup(r => r.VerifyRegionCodeHeader(It.IsAny<HttpRequest>())).Returns(new GenericResponse<string>() { IsSuccess = true, HasError = false, Result = validationResult });
        _mockFileValidator.Setup(v => v.IsValid(It.IsAny<IFormFile>(), moduleName, out It.Ref<string>.IsAny)).Returns((IFormFile f, string m, out string err) =>
        {
            err = isValid ? null : "Invalid file format";
            return isValid;
        });
        _mockUploadFilesService.Setup(u => u.UpdateFileInModuleAsync(moduleName, existingFileName, It.IsAny<Stream>(), regionCode))
            .ReturnsAsync(serviceResponse);

        // Act
        var result = await _controller.UpdateFile(regionCode, moduleName, existingFileName, fileMock.Object);

        // Assert
        if (!isRegionValid || !isFileValid)
        {
            var badRequestResult = Assert.IsType<BadRequestObjectResult>(result);
            Assert.Equal(regionError ?? "Invalid file format", badRequestResult.Value);
        }
        else
        {
            var okResult = Assert.IsType<OkObjectResult>(result);
            var response = Assert.IsType <GenericResponse<string>>(okResult.Value);
            Assert.True(response.IsSuccess);
        }
    }

    [Theory]
    [InlineData(null, "ValidModule", "file.txt", 400)] // Invalid region code
    [InlineData("ValidRegion", "InvalidModule", "file.txt", 400)] // Invalid module name
    [InlineData("ValidRegion", "Logos", "", 400)] // Empty file name
    [InlineData("ValidRegion", "Onboarding", "file?.txt", 400)] // Invalid character in file name
    [InlineData("ValidRegion", "Logos", "file.txt", 200)] // Valid case
    public async Task RemoveFile_ShouldReturnExpectedStatusCode(string regionCode, string moduleName, string fileName, int expectedStatusCode)
    {
        // Arrange
        _mockRegionHelper.Setup(r => r.VerifyRegionCodeHeader(It.IsAny<HttpRequest>()))
            .Returns(regionCode == null ? new GenericResponse<string> { IsSuccess = false, HasError = true} : null);

        _mockUploadFilesService.Setup(u => u.RemoveFileFromModuleAsync(It.IsAny<string>(), It.IsAny<string>(), It.IsAny<string>()))
            .ReturnsAsync(new GenericResponse<string> { HasError = false, IsSuccess = true });

        // Act
        var result = await _controller.RemoveFile(regionCode, moduleName, fileName) as ObjectResult;

        // Assert
        Assert.NotNull(result);
        Assert.Equal(expectedStatusCode, result.StatusCode);
    }

    [Theory]
    [InlineData("ValidRegion", "Logos", "validfile.png", true, true)]
    [InlineData("ValidRegion", "InvalidModule", "validfile.png", false)]
    [InlineData("ValidRegion", "", "", true)]
    [InlineData("ValidRegion", "Logos", "", true)]
    [InlineData("ValidRegion", "Logos", "//", true)]
    public async Task GetImage_ReturnsExpectedResult(string regionCode, string moduleName, string fileName, bool expectedSuccess, bool is200Ok = false)
    {
        // Arrange
        var mockHttpContext = new DefaultHttpContext();
        mockHttpContext.Request.Headers["RegionCode"] = regionCode;
        var sampleStream = new MemoryStream();
        var writer = new StreamWriter(sampleStream);
        writer.Write("Sample file content");
        writer.Flush();
        sampleStream.Position = 0; // Reset position for reading

        _controller.ControllerContext = new ControllerContext
        {
            HttpContext = mockHttpContext
        };

        var regionHelperResponse = new GenericResponse<string> { HasError = !expectedSuccess, IsSuccess = expectedSuccess };
        _mockRegionHelper.Setup(r => r.VerifyRegionCodeHeader(It.IsAny<HttpRequest>()))
            .Returns(regionHelperResponse);

        _mockUploadFilesService.Setup(s => s.GetImageStreamForDownloadAsync(moduleName, fileName, regionCode))
            .ReturnsAsync(new GenericResponse<FileResponse>
            {
                IsSuccess = expectedSuccess,
                Result = new FileResponse() { ContentType = "image/png", Stream = sampleStream }
            });

        // Act
        var result = await _controller.GetImage(regionCode, moduleName, fileName);

        // Assert
        if (is200Ok)
        {
            var fileResult = Assert.IsType<FileStreamResult>(result);
            Assert.Equal("image/png", fileResult.ContentType);
        }
        else
        {
            Assert.IsType<BadRequestObjectResult>(result);
        }
    }
}

