﻿using Aurora.AdministrationService.API.Controllers.FAQ;
using Aurora.AdministrationService.API.Enum;
using Aurora.AdministrationService.API.Enum.FAQs;
using Aurora.AdministrationService.API.Helper;
using Aurora.AdministrationService.API.Models.Dto.FAQs;
using Aurora.AdministrationService.API.Models.Dto.V1.FAQ;
using Aurora.AdministrationService.API.Models.RequestModels.V1.Faq;
using Aurora.AdministrationService.API.Models.ResponseModels.FAQ;
using Aurora.AdministrationService.API.Models.ResponseModels.V1.Faq;
using Aurora.AdministrationService.API.Services.IService.Faq;
using Aurora.AdministrationService.CrossCutting.CommonModels;
using Aurora.AdministrationService.CrossCutting.Constants;
using Aurora.AdministrationService.Domain.V1.Entities;
using FluentAssertions;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using Moq;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Aurora.AdministrationService.Tests.API.Controllers.V1.Faq
{
    public class FAQControllerTests
    {
        private readonly Mock<IFaqCommandService> _faqCommandServiceMock;
        private readonly Mock<IFaqQueryService> _faqQueryServiceMock;
        private readonly Mock<IRegionCodeValidationHelper> _regionCodeValidationHelperMock;
        private readonly FAQController _controller;
        private readonly UpdateFaqRequest _updateFaqRequestMockData;
        private readonly Domain.V1.Entities.FAQ _faqMockData;
        private readonly Domain.V1.Entities.FAQLanguage _fAQLanguageMockData;
        private const string spliterCharacter = "_";
        private const string replaceCharacter = " ";
        public FAQControllerTests()
        {
            _updateFaqRequestMockData = new UpdateFaqRequest()
            {
                Description = "description",
                Header = "header",
                Platforms = "platform",
                RecordVersion = Array.Empty<byte>(),
                Status = true,
                UserType = "user"
            };
            _faqMockData = new Domain.V1.Entities.FAQ
            {
                IsDeleted = false,
                CreatedDate = DateTime.UtcNow,
                ID = 1,
                Platforms = "",
                Status = true
            };
            _fAQLanguageMockData = new FAQLanguage
            {
                CreatedDate = DateTime.UtcNow,
                FAQID = 1,
                Id = 1,
                IsDeleted = false,
                Status = true,
            };
            _faqCommandServiceMock = new Mock<IFaqCommandService>();
            _faqQueryServiceMock = new Mock<IFaqQueryService>();
            _regionCodeValidationHelperMock = new Mock<IRegionCodeValidationHelper>();

            _controller = new FAQController(
                _faqCommandServiceMock.Object,
                _faqQueryServiceMock.Object,
                _regionCodeValidationHelperMock.Object
            );
        }

        #region Add FAQ

        [Fact]
        public async Task AddFaq_Returns200_WhenSuccessful()
        {
            // Arrange
            var request = new FaqDto
            {
                Description = "Description",
                Header = "Header",
                Status = true,
                Platforms = "Web",
                UserType = "Admin"
            };

            var response = new GenericResponse<string> { IsSuccess = true, HasError = false };

            _faqCommandServiceMock
                .Setup(service => service.AddFaqAsync(request))
                .ReturnsAsync(response);

            // Act
            var result = await _controller.AddFaq(request);

            // Assert
            result.Should().BeOfType<OkObjectResult>();
        }

        [Fact]
        public async Task AddFaq_Returns400_WhenHeaderIsMissing()
        {
            // Arrange
            var request = new FaqDto
            {
                Header = null, // Missing required header
                Description = "Description",
                Status = true,
                Platforms = "Web",
                UserType = "Admin"
            };

            _controller.ModelState.AddModelError("Header", "Header is required");

            // Act
            var result = await _controller.AddFaq(request);

            // Assert
            result.Should().BeOfType<BadRequestObjectResult>().Which.StatusCode.Should().Be(400);
        }


        [Fact]
        public async Task AddFaq_ReturnsBadRequest_WhenRegionCodeIsInvalid()
        {
            // Arrange: Mock region code validation failure
            _regionCodeValidationHelperMock.Setup(helper => helper.VerifyRegionCodeHeader(It.IsAny<HttpRequest>()))
                .Returns(new GenericResponse<string> { HasError = true });

            // Act: Call GetFaqDetailById with an ID
            var result = await _controller.AddFaq(It.IsAny<FaqDto>());

            // Assert: Verify the result is a BadRequest
            Assert.IsType<BadRequestObjectResult>(result);
        }

        [Fact]
        public async Task AddFaq_ReturnsBadRequest_WhenServiceReturnsError()
        {
            // Arrange
            var request = new FaqDto
            {
                Description = "Description",
                Header = "Header",
                Status = true,
                Platforms = "Web",
                UserType = "Admin"
            };

            var response = new GenericResponse<string> { IsSuccess = false, HasError = true };

            _faqCommandServiceMock
                .Setup(service => service.AddFaqAsync(request))
                .ReturnsAsync(response);

            // Act
            var result = await _controller.AddFaq(request);

            // Assert
            result.Should().BeOfType<BadRequestResult>();
        }

        #endregion

        #region Get FAQ By ID

        [Fact]
        public async Task GetFaqDetailById_Returns200_WhenFAQExists()
        {
            // Arrange
            var faqResponse = new GenericResponse<FaqByDetailResponse>
            {
                IsSuccess = true,
                HasError = false,
                Result = new FaqByDetailResponse
                {
                    Id = 1,
                    RecordVersion = new byte[5],
                    UniqueID = "12345",
                    LanguageID = 1,
                    Header = "Test FAQ",
                    Description = "Description",
                    Status = true,
                    Platforms = "Web",
                    UserType = "Admin"
                }
            };

            _faqQueryServiceMock
                .Setup(service => service.GetFaqDetailById(1))
                .ReturnsAsync(faqResponse);

            // Act
            var result = await _controller.GetFaqDetailById(1);

            // Assert
            result.Should().BeOfType<OkObjectResult>().Which.StatusCode.Should().Be(200);
        }

        [Fact]
        public async Task GetFaqDetailById_Returns404_WhenFAQDoesNotExist()
        {
            // Arrange
            var faqResponse = new GenericResponse<FaqByDetailResponse>
            {
                IsSuccess = true,
                HasError = false,
                Result = new FaqByDetailResponse
                {
                    Id = 1,
                    RecordVersion = new byte[5],
                    UniqueID = "12345",
                    LanguageID = 1,
                    Header = "Test FAQ",
                    Description = "Description",
                    Status = true,
                    Platforms = "Web",
                    UserType = "Admin"
                }
            };

            _faqQueryServiceMock
                .Setup(service => service.GetFaqDetailById(1))
                .ReturnsAsync(faqResponse);

            // Act
            var result = await _controller.GetFaqDetailById(1);

            // Assert
            result.Should().BeOfType<OkObjectResult>();
        }

        #endregion

        #region Update FAQ


        [Fact]
        public async Task UpdateFaq_Returns400_WhenLanguageIDIsNull()
        {
            // Arrange
            var request = new UpdateFaqRequest { Header = "Updated FAQ", Description = "", Platforms = "", RecordVersion = new byte[5], Status = true, UserType = "", UniqueID = "", LanguageID = null };

            _controller.ModelState.AddModelError("LanguageID", "LanguageID is required");

            // Act
            var result = await _controller.UpdateFaq(1, request);

            // Assert
            result.Should().BeOfType<BadRequestObjectResult>().Which.StatusCode.Should().Be(400);
        }

        #endregion

        #region Delete FAQ

        [Fact]
        public async Task DeleteFaq_Returns200_WhenSuccessful()
        {
            // Arrange
            byte[] recordVersion = new byte[5];
            var faq = new Domain.V1.Entities.FAQ
            {
                RecordVersion = recordVersion,
                ID = 1,
                IsDeleted = false,
                CreatedDate = DateTime.UtcNow,
                Platforms = "",
                Status = true,
                CreatedBy = ""
            };

            var faqLanguage = new FAQLanguage { CreatedDate = DateTime.Now, FAQID = 1, Id = 1, Status = true, IsDeleted = false };
            var faqUserType = new FAQUserTypes { Id = 1, IsDeleted = false, CreatedDate = DateTime.Now };

            var response = new GenericResponse<string> { IsSuccess = true };

            _faqQueryServiceMock
                .Setup(service => service.GetFaqByIdAsync(1))
                .ReturnsAsync(faq);

            _faqQueryServiceMock
                .Setup(service => service.GetFaqLanguageAsync(1))
                .ReturnsAsync(faqLanguage);

            _faqQueryServiceMock
                .Setup(service => service.GetFaqUserTypesAsync(1))
                .ReturnsAsync(faqUserType);

            _faqCommandServiceMock
                .Setup(service => service.DeleteFaqAsync(faq, faqLanguage, faqUserType))
                .ReturnsAsync(response);

            // Act
            var result = await _controller.DeleteFaq(1);

            // Assert
            result.Should().BeOfType<OkObjectResult>().Which.StatusCode.Should().Be(200);
        }


        [Fact]
        public async Task DeleteFaq_Returns404_WhenFAQDoesNotExist()
        {
            // Arrange
            _faqQueryServiceMock
                .Setup(service => service.GetFaqByIdAsync(1))
                .ReturnsAsync(It.IsAny<Domain.V1.Entities.FAQ>());

            // Act
            var result = await _controller.DeleteFaq(1);

            // Assert
            result.Should().BeOfType<NotFoundObjectResult>().Which.StatusCode.Should().Be(404);
        }



        /// <summary>
        /// ✅ Returns 400 when LanguageID is null
        /// </summary>
        [Fact]
        public async Task UpdateFaq_Returns400_WhenLanguageIDIsNull2()
        {
            // Arrange
            var request = new UpdateFaqRequest
            {
                Header = "Updated FAQ",
                Description = "Updated Description",
                Platforms = "Web",
                Status = true,
                UserType = "Admin",
                UniqueID = "12345",
                RecordVersion = new byte[5],
                LanguageID = null // Null LanguageID should trigger BadRequest 
            };

            // Act
            var result = await _controller.UpdateFaq(1, request);

            // Assert
            result.Should().BeOfType<NotFoundObjectResult>().Which.StatusCode.Should().Be(404);
        }





        /// <summary>
        /// ✅ Returns 400 when Update fails (result is not successful)
        /// </summary>
        [Fact]
        public async Task UpdateFaq_Returns400_When_UpdateFails()
        {
            // Arrange
            var faq = new Domain.V1.Entities.FAQ
            {
                RecordVersion = new byte[5],
                ID = 1,
                IsDeleted = false,
                CreatedDate = DateTime.UtcNow,
                Platforms = "",
                Status = true,
                CreatedBy = ""
            };
            var faqLanguage = new FAQLanguage { Id = 1, IsDeleted = false, CreatedDate = DateTime.Now, FAQID = 1, Status = true };
            var faqUserType = new FAQUserTypes { Id = 1, IsDeleted = false, CreatedDate = DateTime.Now, FAQID = 1 };

            _faqQueryServiceMock.Setup(service => service.GetFaqByIdAsync(1)).ReturnsAsync(faq);
            _faqQueryServiceMock.Setup(service => service.GetFaqLanguageAsync(1)).ReturnsAsync(faqLanguage);
            _faqQueryServiceMock.Setup(service => service.GetFaqUserTypesAsync(1)).ReturnsAsync(faqUserType);

            var failedUpdateResponse = new GenericResponse<string> { IsSuccess = false };

            _faqCommandServiceMock
                .Setup(service => service.UpdateFaqAsync(It.IsAny<UpdateFaqRequest>(), faq, faqLanguage, faqUserType))
                .ReturnsAsync(failedUpdateResponse);

            // Act
            var result = await _controller.UpdateFaq(1, new UpdateFaqRequest
            {
                Header = "Updated FAQ",
                Description = "Updated Description",
                Platforms = "Web",
                Status = true,
                UserType = "Admin",
                UniqueID = "12345",
                RecordVersion = new byte[5],
                LanguageID = null
            });

            // Assert
            result.Should().BeOfType<BadRequestObjectResult>().Which.StatusCode.Should().Be(400);
        }

        /// <summary>
        /// ✅ Returns 400 when DbUpdateConcurrencyException occurs
        /// </summary>
        [Fact]
        public async Task UpdateFaq_Returns400_When_DbUpdateConcurrencyException_Occurs()
        {
            // Arrange
            var faq = new Domain.V1.Entities.FAQ
            {
                RecordVersion = new byte[5],
                ID = 1,
                IsDeleted = false,
                CreatedDate = DateTime.UtcNow,
                Platforms = "",
                Status = true,
                CreatedBy = ""
            };
            var faqLanguage = new FAQLanguage { Id = 1, IsDeleted = false, CreatedDate = DateTime.Now, FAQID = 1, Status = true };
            var faqUserType = new FAQUserTypes { Id = 1, IsDeleted = false, CreatedDate = DateTime.Now, FAQID = 1 };

            _faqQueryServiceMock.Setup(service => service.GetFaqByIdAsync(1)).ReturnsAsync(faq);
            _faqQueryServiceMock.Setup(service => service.GetFaqLanguageAsync(1)).ReturnsAsync(faqLanguage);
            _faqQueryServiceMock.Setup(service => service.GetFaqUserTypesAsync(1)).ReturnsAsync(faqUserType);

            _faqCommandServiceMock
                .Setup(service => service.UpdateFaqAsync(It.IsAny<UpdateFaqRequest>(), faq, faqLanguage, faqUserType))
                .ThrowsAsync(new DbUpdateConcurrencyException());

            // Act
            var result = await _controller.UpdateFaq(1, new UpdateFaqRequest
            {
                Header = "Updated FAQ",
                Description = "Updated Description",
                Platforms = "Web",
                Status = true,
                UserType = "Admin",
                UniqueID = "12345",
                RecordVersion = new byte[5],
                LanguageID = null
            });

            // Assert
            result.Should().BeOfType<BadRequestObjectResult>().Which.StatusCode.Should().Be(400);
        }

        #endregion

        [Fact]
        public async Task GetFaqDetailById_ReturnsBadRequest_WhenRegionCodeIsInvalid()
        {
            // Arrange: Mock region code validation failure
            _regionCodeValidationHelperMock.Setup(helper => helper.VerifyRegionCodeHeader(It.IsAny<HttpRequest>()))
                .Returns(new GenericResponse<string> { HasError = true });

            // Act: Call GetFaqDetailById with an ID
            var result = await _controller.GetFaqDetailById(1);

            // Assert: Verify the result is a BadRequest
            Assert.IsType<BadRequestObjectResult>(result);
        }

        [Fact]
        public async Task GetFaqDetailById_ReturnsNotFound_WhenFaqDoesNotExist()
        {
            // Arrange: Mock region code validation success and a failed FAQ query
            _regionCodeValidationHelperMock.Setup(helper => helper.VerifyRegionCodeHeader(It.IsAny<HttpRequest>()))
                .Returns(new GenericResponse<string> { HasError = false });
            _faqQueryServiceMock.Setup(service => service.GetFaqDetailById(1))
                .ReturnsAsync(new GenericResponse<FaqByDetailResponse>
                {
                    HasError = true,
                    StatusCode = ResponceStatusCode.RecordNotFound.ToString()
                });

            // Act: Call GetFaqDetailById with a non-existent ID
            var result = await _controller.GetFaqDetailById(1);

            // Assert: Verify the result is a NotFound response
            Assert.IsType<NotFoundObjectResult>(result);
        }

        [Fact]
        public async Task GetFaqDetailById_ReturnsBadRequest_WhenFaqQueryFails()
        {
            // Arrange: Mock region code validation success and a generic error from FAQ query
            _regionCodeValidationHelperMock.Setup(helper => helper.VerifyRegionCodeHeader(It.IsAny<HttpRequest>()))
                .Returns(new GenericResponse<string> { HasError = false });
            _faqQueryServiceMock.Setup(service => service.GetFaqDetailById(1))
                .ReturnsAsync(new GenericResponse<FaqByDetailResponse> { HasError = true });

            // Act: Call GetFaqDetailById with a valid ID
            var result = await _controller.GetFaqDetailById(1);

            // Assert: Verify the result is a BadRequest response
            Assert.IsType<BadRequestResult>(result);
        }

        [Fact]
        public async Task GetFaqDetailById_ReturnsOk_WhenFaqIsFound()
        {
            // Arrange: Mock region code validation success and a successful FAQ query
            _regionCodeValidationHelperMock.Setup(helper => helper.VerifyRegionCodeHeader(It.IsAny<HttpRequest>()))
                .Returns(new GenericResponse<string> { HasError = false });
            _faqQueryServiceMock.Setup(service => service.GetFaqDetailById(1))
                .ReturnsAsync(new GenericResponse<FaqByDetailResponse> { IsSuccess = true });

            // Act: Call GetFaqDetailById with a valid ID
            var result = await _controller.GetFaqDetailById(1);

            // Assert: Verify the result is an OkObjectResult
            Assert.IsType<OkObjectResult>(result);
        }



        [Fact]
        public async Task UpdateFaq_ReturnsBadRequest_WhenRegionCodeIsInvalid()
        {
            // Arrange: Mock region code validation failure
            _regionCodeValidationHelperMock.Setup(helper => helper.VerifyRegionCodeHeader(It.IsAny<HttpRequest>()))
                .Returns(new GenericResponse<string> { HasError = true });

            // Act: Call UpdateFaq
            var result = await _controller.UpdateFaq(1, _updateFaqRequestMockData);

            // Assert: Verify the result is a BadRequest
            Assert.IsType<BadRequestObjectResult>(result);
        }

        [Fact]
        public async Task UpdateFaq_ReturnsBadRequest_WhenModelStateIsInvalid()
        {
            // Arrange: Mock region code validation success
            _regionCodeValidationHelperMock.Setup(helper => helper.VerifyRegionCodeHeader(It.IsAny<HttpRequest>()))
                .Returns(new GenericResponse<string> { HasError = false });

            // Simulate an invalid model state
            _controller.ModelState.AddModelError("error", "Invalid model");

            // Act: Call UpdateFaq with an invalid model state
            var result = await _controller.UpdateFaq(1, _updateFaqRequestMockData);

            // Assert: Verify the result is a BadRequest
            Assert.IsType<BadRequestObjectResult>(result);
        }

        [Fact]
        public async Task UpdateFaq_ReturnsBadRequest_WhenLanguageIDIsNull()
        {
            // Arrange: Mock region code validation success
            _regionCodeValidationHelperMock.Setup(helper => helper.VerifyRegionCodeHeader(It.IsAny<HttpRequest>()))
                .Returns(new GenericResponse<string> { HasError = false });

            _updateFaqRequestMockData.LanguageID = null;
            // Act: Call UpdateFaq with a request where LanguageID is null
            var result = await _controller.UpdateFaq(1, _updateFaqRequestMockData);

            // Assert: Verify the result is a BadRequest
            Assert.IsType<NotFoundObjectResult>(result);
        }

        [Fact]
        public async Task UpdateFaq_ReturnsNotFound_WhenFaqOrDependenciesAreDeleted()
        {
            // Arrange: Mock region code validation success
            _regionCodeValidationHelperMock.Setup(helper => helper.VerifyRegionCodeHeader(It.IsAny<HttpRequest>()))
                .Returns(new GenericResponse<string> { HasError = false });

            // Mock the existence of a FAQ but with deleted dependencies
            _faqQueryServiceMock.Setup(service => service.GetFaqByIdAsync(It.IsAny<long>()))
                .ReturnsAsync(_faqMockData);
            _faqQueryServiceMock.Setup(service => service.GetFaqLanguageAsync(It.IsAny<long>()))
                .ReturnsAsync(It.IsAny<FAQLanguage>());
            _faqQueryServiceMock.Setup(service => service.GetFaqUserTypesAsync(It.IsAny<long>()))
                .ReturnsAsync(new FAQUserTypes
                {
                    IsDeleted = false,
                    Id = 1,
                    CreatedDate = DateTime.Now
                });
            _faqCommandServiceMock.Setup(service => service.UpdateFaqAsync(It.IsAny<UpdateFaqRequest>(), It.IsAny<Domain.V1.Entities.FAQ>(), It.IsAny<FAQLanguage>(), It.IsAny<FAQUserTypes>()))
                .ReturnsAsync(new GenericResponse<string> { IsSuccess = false });
            _updateFaqRequestMockData.LanguageID = 1;
            // Act: Call UpdateFaq with a valid ID but deleted dependencies
            var result = await _controller.UpdateFaq(1, _updateFaqRequestMockData);

            // Assert: Verify the result is a NotFound
            Assert.IsType<BadRequestObjectResult>(result);
        }

        [Fact]
        public async Task UpdateFaq_ReturnsOk_WhenUpdateIsSuccessful()
        {
            // Arrange: Mock region code validation success
            _regionCodeValidationHelperMock.Setup(helper => helper.VerifyRegionCodeHeader(It.IsAny<HttpRequest>()))
                .Returns(new GenericResponse<string> { HasError = false });

            // Mock the existence of a valid FAQ and its dependencies
            _faqQueryServiceMock.Setup(service => service.GetFaqByIdAsync(It.IsAny<long>()))
                .ReturnsAsync(_faqMockData);
            _faqQueryServiceMock.Setup(service => service.GetFaqLanguageAsync(It.IsAny<long>()))
                .ReturnsAsync(_fAQLanguageMockData);
            _faqQueryServiceMock.Setup(service => service.GetFaqUserTypesAsync(It.IsAny<long>()))
                .ReturnsAsync(new FAQUserTypes
                {
                    IsDeleted = false,
                    Id = 1,
                    CreatedDate = DateTime.Now
                });
            _faqCommandServiceMock.Setup(service => service.UpdateFaqAsync(It.IsAny<UpdateFaqRequest>(), It.IsAny<Domain.V1.Entities.FAQ>(), It.IsAny<FAQLanguage>(), It.IsAny<FAQUserTypes>()))
                .ReturnsAsync(new GenericResponse<string> { IsSuccess = true });
            _updateFaqRequestMockData.LanguageID = 1;
            // Act: Call UpdateFaq with valid data
            var result = await _controller.UpdateFaq(1, _updateFaqRequestMockData);

            // Assert: Verify the result is an Ok
            Assert.IsType<OkObjectResult>(result);
        }


        [Fact]
        public async Task UpdateFaq_ReturnsBadRequest_WhenUpdateFailed()
        {
            // Arrange: Mock region code validation success
            _regionCodeValidationHelperMock.Setup(helper => helper.VerifyRegionCodeHeader(It.IsAny<HttpRequest>()))
                .Returns(new GenericResponse<string> { HasError = false });

            // Mock the existence of a valid FAQ and its dependencies
            _faqQueryServiceMock.Setup(service => service.GetFaqByIdAsync(It.IsAny<long>()))
                .ReturnsAsync(_faqMockData);
            _faqQueryServiceMock.Setup(service => service.GetFaqLanguageAsync(It.IsAny<long>()))
                .ReturnsAsync(_fAQLanguageMockData);
            _faqQueryServiceMock.Setup(service => service.GetFaqUserTypesAsync(It.IsAny<long>()))
                .ReturnsAsync(new FAQUserTypes
                {
                    IsDeleted = false,
                    Id = 1,
                    CreatedDate = DateTime.Now
                });
            _faqCommandServiceMock.Setup(service => service.UpdateFaqAsync(It.IsAny<UpdateFaqRequest>(), It.IsAny<Domain.V1.Entities.FAQ>(), It.IsAny<FAQLanguage>(), It.IsAny<FAQUserTypes>()))
                .ReturnsAsync(new GenericResponse<string> { IsSuccess = false, HasError = true });
            _updateFaqRequestMockData.LanguageID = 1;
            // Act: Call UpdateFaq with valid data
            var result = await _controller.UpdateFaq(1, _updateFaqRequestMockData);

            // Assert: Verify the result is an Ok
            Assert.IsType<BadRequestObjectResult>(result);
        }

        [Fact]
        public async Task UpdateFaq_ReturnsBadRequest_WhenDbUpdateConcurrencyExceptionOccurs()
        {
            // Arrange: Mock region code validation success
            _regionCodeValidationHelperMock.Setup(helper => helper.VerifyRegionCodeHeader(It.IsAny<HttpRequest>()))
                .Returns(new GenericResponse<string> { HasError = false });

            // Mock the existence of a valid FAQ and its dependencies
            _faqQueryServiceMock.Setup(service => service.GetFaqByIdAsync(It.IsAny<long>()))
                .ReturnsAsync(_faqMockData);
            _faqQueryServiceMock.Setup(service => service.GetFaqLanguageAsync(It.IsAny<long>()))
                .ReturnsAsync(_fAQLanguageMockData);
            _faqQueryServiceMock.Setup(service => service.GetFaqUserTypesAsync(It.IsAny<long>()))
                .ReturnsAsync(new FAQUserTypes
                {
                    IsDeleted = false,
                    Id = 1,
                    CreatedDate = DateTime.Now
                });

            // Simulate a DbUpdateConcurrencyException
            _faqCommandServiceMock.Setup(service => service.UpdateFaqAsync(It.IsAny<UpdateFaqRequest>(), It.IsAny<Domain.V1.Entities.FAQ>(), It.IsAny<FAQLanguage>(), It.IsAny<FAQUserTypes>()))
                .ThrowsAsync(new DbUpdateConcurrencyException());
            _updateFaqRequestMockData.LanguageID = 1;
            // Act: Call UpdateFaq with valid data
            var result = await _controller.UpdateFaq(1, _updateFaqRequestMockData);

            // Assert: Verify the result is a BadRequest
            Assert.IsType<BadRequestObjectResult>(result);
        }


        [Fact]
        public async Task DeleteFaq_ReturnsBadRequest_WhenRegionCodeIsInvalid()
        {
            // Arrange: Mock region code validation failure
            _regionCodeValidationHelperMock.Setup(helper => helper.VerifyRegionCodeHeader(It.IsAny<HttpRequest>()))
                .Returns(new GenericResponse<string> { HasError = true });

            // Act: Call DeleteFaq
            var result = await _controller.DeleteFaq(1);

            // Assert: Verify the result is a BadRequest
            Assert.IsType<BadRequestObjectResult>(result);
        }

        [Fact]
        public async Task DeleteFaq_ReturnsBadRequest_WhenModelStateIsInvalid()
        {
            // Arrange: Mock region code validation success
            _regionCodeValidationHelperMock.Setup(helper => helper.VerifyRegionCodeHeader(It.IsAny<HttpRequest>()))
                .Returns(new GenericResponse<string> { HasError = false });

            // Simulate an invalid model state
            _controller.ModelState.AddModelError("error", "Invalid model");

            // Act: Call DeleteFaq with an invalid model state
            var result = await _controller.DeleteFaq(1);

            // Assert: Verify the result is a BadRequest
            Assert.IsType<BadRequestObjectResult>(result);
        }

        [Fact]
        public async Task DeleteFaq_ReturnsNotFound_WhenFaqDoesNotExistOrIsDeleted()
        {
            // Arrange: Mock region code validation success
            _regionCodeValidationHelperMock.Setup(helper => helper.VerifyRegionCodeHeader(It.IsAny<HttpRequest>()))
                .Returns(new GenericResponse<string> { HasError = false });

            // Mock the non-existence of the FAQ
            _faqQueryServiceMock.Setup(service => service.GetFaqByIdAsync(It.IsAny<long>()))
                .ReturnsAsync(It.IsAny<Domain.V1.Entities.FAQ>());

            // Act: Call DeleteFaq with a non-existing FAQ
            var result = await _controller.DeleteFaq(1);

            // Assert: Verify the result is a NotFound
            Assert.IsType<NotFoundObjectResult>(result);
        }

        [Fact]
        public async Task DeleteFaq_ReturnsNotFound_WhenFaqLanguageIsDeletedOrNotFound()
        {
            // Arrange: Mock region code validation success
            _regionCodeValidationHelperMock.Setup(helper => helper.VerifyRegionCodeHeader(It.IsAny<HttpRequest>()))
                .Returns(new GenericResponse<string> { HasError = false });

            // Mock the existence of the FAQ but deleted FAQ language
            _faqQueryServiceMock.Setup(service => service.GetFaqByIdAsync(It.IsAny<long>()))
                .ReturnsAsync(_faqMockData);
            _faqQueryServiceMock.Setup(service => service.GetFaqLanguageAsync(It.IsAny<long>()))
                .ReturnsAsync(It.IsAny<FAQLanguage>());
            // Mock the delete operation to succeed
            _faqCommandServiceMock.Setup(service => service.DeleteFaqAsync(It.IsAny<Domain.V1.Entities.FAQ>(), It.IsAny<FAQLanguage>(), It.IsAny<FAQUserTypes>()))
                .ReturnsAsync(new GenericResponse<string> { IsSuccess = false, HasError = true });
            // Act: Call DeleteFaq with a deleted FAQ language
            var result = await _controller.DeleteFaq(1);

            // Assert: Verify the result is a NotFound
            Assert.IsType<BadRequestObjectResult>(result);
        }

        [Fact]
        public async Task DeleteFaq_ReturnsNotFound_WhenFaqUserTypeIsDeletedOrNotFound()
        {
            // Arrange: Mock region code validation success
            _regionCodeValidationHelperMock.Setup(helper => helper.VerifyRegionCodeHeader(It.IsAny<HttpRequest>()))
                .Returns(new GenericResponse<string> { HasError = false });

            // Mock the existence of the FAQ, FAQ language, but deleted FAQ user type
            _faqQueryServiceMock.Setup(service => service.GetFaqByIdAsync(It.IsAny<long>()))
                .ReturnsAsync(_faqMockData);
            _faqQueryServiceMock.Setup(service => service.GetFaqLanguageAsync(It.IsAny<long>()))
                .ReturnsAsync(_fAQLanguageMockData);
            _faqQueryServiceMock.Setup(service => service.GetFaqUserTypesAsync(It.IsAny<long>()))
                .ReturnsAsync(It.IsAny<FAQUserTypes>());
            _faqCommandServiceMock.Setup(service => service.DeleteFaqAsync(It.IsAny<Domain.V1.Entities.FAQ>(), It.IsAny<FAQLanguage>(), It.IsAny<FAQUserTypes>()))
               .ReturnsAsync(new GenericResponse<string> { IsSuccess = false, HasError = true });
            // Act: Call DeleteFaq with a deleted FAQ user type
            var result = await _controller.DeleteFaq(1);

            // Assert: Verify the result is a NotFound
            Assert.IsType<BadRequestObjectResult>(result);
        }

        [Fact]
        public async Task DeleteFaq_ReturnsBadRequest_WhenDeleteFails()
        {
            // Arrange: Mock region code validation success
            _regionCodeValidationHelperMock.Setup(helper => helper.VerifyRegionCodeHeader(It.IsAny<HttpRequest>()))
                .Returns(new GenericResponse<string> { HasError = false });

            // Mock the existence of valid FAQ, FAQ language, and FAQ user type
            _faqQueryServiceMock.Setup(service => service.GetFaqByIdAsync(It.IsAny<long>()))
                .ReturnsAsync(_faqMockData);
            _faqQueryServiceMock.Setup(service => service.GetFaqLanguageAsync(It.IsAny<long>()))
                .ReturnsAsync(_fAQLanguageMockData);
            _faqQueryServiceMock.Setup(service => service.GetFaqUserTypesAsync(It.IsAny<long>()))
                .ReturnsAsync(new FAQUserTypes { IsDeleted = false, CreatedDate = DateTime.UtcNow, Id = 1 });

            // Mock the delete operation to fail
            _faqCommandServiceMock.Setup(service => service.DeleteFaqAsync(It.IsAny<Domain.V1.Entities.FAQ>(), It.IsAny<FAQLanguage>(), It.IsAny<FAQUserTypes>()))
                .ReturnsAsync(new GenericResponse<string> { IsSuccess = false, HasError = true });

            // Act: Call DeleteFaq with valid data
            var result = await _controller.DeleteFaq(1);

            // Assert: Verify the result is a BadRequest
            Assert.IsType<BadRequestObjectResult>(result);
        }

        [Fact]
        public async Task DeleteFaq_ReturnsOk_WhenDeleteIsSuccessful()
        {
            // Arrange: Mock region code validation success
            _regionCodeValidationHelperMock.Setup(helper => helper.VerifyRegionCodeHeader(It.IsAny<HttpRequest>()))
                .Returns(new GenericResponse<string> { HasError = false });

            // Mock the existence of valid FAQ, FAQ language, and FAQ user type
            _faqQueryServiceMock.Setup(service => service.GetFaqByIdAsync(It.IsAny<long>()))
                .ReturnsAsync(_faqMockData);
            _faqQueryServiceMock.Setup(service => service.GetFaqLanguageAsync(It.IsAny<long>()))
                .ReturnsAsync(_fAQLanguageMockData);
            _faqQueryServiceMock.Setup(service => service.GetFaqUserTypesAsync(It.IsAny<long>()))
                .ReturnsAsync(new FAQUserTypes { Id = 1, CreatedDate = DateTime.Now, IsDeleted = false });

            // Mock the delete operation to succeed
            _faqCommandServiceMock.Setup(service => service.DeleteFaqAsync(It.IsAny<Domain.V1.Entities.FAQ>(), It.IsAny<FAQLanguage>(), It.IsAny<FAQUserTypes>()))
                .ReturnsAsync(new GenericResponse<string> { IsSuccess = true, HasError = false });

            // Act: Call DeleteFaq with valid data
            var result = await _controller.DeleteFaq(1);

            // Assert: Verify the result is Ok
            Assert.IsType<OkObjectResult>(result);
        }

        [Fact]
        public async Task GetFAQs_ReturnsBadRequest_WhenRegionCodeIsInvalid()
        {
            // Arrange: Mock region code validation failure
            _regionCodeValidationHelperMock.Setup(helper => helper.VerifyRegionCodeHeader(It.IsAny<HttpRequest>()))
                .Returns(new GenericResponse<string> { HasError = true });

            // Act: Call GetFAQs
            var result = await _controller.GetFAQs(null, null);

            // Assert: Verify the result is a BadRequest
            Assert.IsType<BadRequestObjectResult>(result);
        }

        [Fact]
        public async Task GetFAQs_ReturnsNotFound_WhenResponseHasErrorAndStatusIsNotFound()
        {
            // Arrange: Mock region code validation success
            _regionCodeValidationHelperMock.Setup(helper => helper.VerifyRegionCodeHeader(It.IsAny<HttpRequest>()))
                .Returns(new GenericResponse<string> { HasError = false });

            // Mock a response with error and status code STATUS_NOTFOUND
            _faqQueryServiceMock.Setup(service => service.GetFaqs(It.IsAny<int?>(), It.IsAny<int?>(), It.IsAny<string>(), It.IsAny<string>(), It.IsAny<string>(), It.IsAny<string>()))
                .ReturnsAsync(new GenericResponseList<GetFaqResponse> { HasError = true, StatusCode = ResponseStatusCode.STATUS_NOTFOUND.ToString() });

            // Act: Call GetFAQs
            var result = await _controller.GetFAQs(null, null);

            // Assert: Verify the result is a NotFound
            Assert.IsType<NotFoundObjectResult>(result);
        }

        [Fact]
        public async Task GetFAQs_ReturnsBadRequest_WhenResponseHasError()
        {
            // Arrange: Mock region code validation success
            _regionCodeValidationHelperMock.Setup(helper => helper.VerifyRegionCodeHeader(It.IsAny<HttpRequest>()))
                .Returns(new GenericResponse<string> { HasError = false });

            // Mock a response with error but not status code STATUS_NOTFOUND
            _faqQueryServiceMock.Setup(service => service.GetFaqs(It.IsAny<int?>(), It.IsAny<int?>(), It.IsAny<string>(), It.IsAny<string>(), It.IsAny<string>(), It.IsAny<string>()))
                .ReturnsAsync(new GenericResponseList<GetFaqResponse> { HasError = true, StatusCode = "SomeError" });

            // Act: Call GetFAQs
            var result = await _controller.GetFAQs(null, null);

            // Assert: Verify the result is a BadRequest
            Assert.IsType<BadRequestObjectResult>(result);
        }

        [Fact]
        public async Task GetFAQs_ReturnsOk_WhenFAQsAreRetrievedSuccessfully()
        {
            // Arrange: Mock region code validation success
            _regionCodeValidationHelperMock.Setup(helper => helper.VerifyRegionCodeHeader(It.IsAny<HttpRequest>()))
                .Returns(new GenericResponse<string> { HasError = false });

            // Mock a successful response with a list of FAQs
            var faqList = new List<GetFaqResponse>
        {
            new GetFaqResponse { Id=1, Status=true, Platforms="", UserType="", LanguageID = 1, Header = "Sample Question 1", Description = "Sample Answer 1" },
            new GetFaqResponse { Id=1, Status=true, Platforms="", UserType="", LanguageID = 2, Header = "Sample Question 2", Description = "Sample Answer 2" }
        };
            _faqQueryServiceMock.Setup(service => service.GetFaqs(It.IsAny<int?>(), It.IsAny<int?>(), It.IsAny<string>(), It.IsAny<string>(), It.IsAny<string>(), It.IsAny<string>()))
                .ReturnsAsync(new GenericResponseList<GetFaqResponse> { IsSuccess = true, HasError = false, Results = faqList });

            // Act: Call GetFAQs
            var result = await _controller.GetFAQs(null, null);

            // Assert: Verify the result is Ok
            var okResult = Assert.IsType<OkObjectResult>(result);
            var returnedData = Assert.IsType<GenericResponseList<GetFaqResponse>>(okResult.Value);
            Assert.NotNull(returnedData.Results);
            Assert.Equal(faqList.Count, returnedData.Results.Count());
        }

        [Fact]
        public async Task GetFAQsBySearch_ReturnsBadRequest_WhenRegionCodeIsInvalid()
        {
            // Arrange: Mock region code validation failure
            _regionCodeValidationHelperMock.Setup(helper => helper.VerifyRegionCodeHeader(It.IsAny<HttpRequest>()))
                .Returns(new GenericResponse<string> { HasError = true });

            // Act: Call GetFAQsBySearch
            var result = await _controller.GetFAQsBySearch(null, null, null, null, null, null);

            // Assert: Verify the result is a BadRequest
            Assert.IsType<BadRequestObjectResult>(result);
        }

        [Fact]
        public async Task GetFAQsBySearch_ReturnsNotFound_WhenResponseHasErrorAndStatusIsNotFound()
        {
            // Arrange: Mock region code validation success
            _regionCodeValidationHelperMock.Setup(helper => helper.VerifyRegionCodeHeader(It.IsAny<HttpRequest>()))
                .Returns(new GenericResponse<string> { HasError = false });

            // Mock a response with error and status code STATUS_NOTFOUND
            _faqQueryServiceMock.Setup(service => service.GetFaqs(It.IsAny<int?>(), It.IsAny<int?>(), It.IsAny<string>(), It.IsAny<string>(), It.IsAny<string>(), It.IsAny<string>()))
                .ReturnsAsync(new GenericResponseList<GetFaqResponse> { HasError = true, StatusCode = ResponseStatusCode.STATUS_NOTFOUND.ToString() });

            // Act: Call GetFAQsBySearch
            var result = await _controller.GetFAQsBySearch(null, null, null, null, null, null);

            // Assert: Verify the result is a NotFound
            Assert.IsType<NotFoundObjectResult>(result);
        }

        [Fact]
        public async Task GetFAQsBySearch_ReturnsBadRequest_WhenResponseHasError()
        {
            // Arrange: Mock region code validation success
            _regionCodeValidationHelperMock.Setup(helper => helper.VerifyRegionCodeHeader(It.IsAny<HttpRequest>()))
                .Returns(new GenericResponse<string> { HasError = false });

            // Mock a response with error but not status code STATUS_NOTFOUND
            _faqQueryServiceMock.Setup(service => service.GetFaqs(It.IsAny<int?>(), It.IsAny<int?>(), It.IsAny<string>(), It.IsAny<string>(), It.IsAny<string>(), It.IsAny<string>()))
                .ReturnsAsync(new GenericResponseList<GetFaqResponse> { HasError = true, StatusCode = "SomeError" });

            // Act: Call GetFAQsBySearch
            var result = await _controller.GetFAQsBySearch(null, null, null, null, null, null);

            // Assert: Verify the result is a BadRequest
            Assert.IsType<BadRequestObjectResult>(result);
        }

        [Fact]
        public async Task GetFAQsBySearch_ReturnsOk_WhenFAQsAreRetrievedSuccessfully()
        {
            // Arrange: Mock region code validation success
            _regionCodeValidationHelperMock.Setup(helper => helper.VerifyRegionCodeHeader(It.IsAny<HttpRequest>()))
                .Returns(new GenericResponse<string> { HasError = false });

            // Mock a successful response with a list of FAQs
            var faqList = new List<GetFaqResponse>
        {
            new GetFaqResponse { Id=1, Platforms="one", UserType="1", Status=true, Header = "Sample Question 1", Description = "Sample Answer 1" },
            new GetFaqResponse { Id=1, Platforms="two", UserType="2", Status=true, Header = "Sample Question 2", Description = "Sample Answer 2" }
        };
            _faqQueryServiceMock.Setup(service => service.GetFaqs(It.IsAny<int?>(), It.IsAny<int?>(), It.IsAny<string>(), It.IsAny<string>(), It.IsAny<string>(), It.IsAny<string>()))
                .ReturnsAsync(new GenericResponseList<GetFaqResponse> { IsSuccess = true, HasError = false, Results = faqList });

            // Act: Call GetFAQsBySearch
            var result = await _controller.GetFAQsBySearch(null, null, null, null, null, null);

            // Assert: Verify the result is Ok
            var okResult = Assert.IsType<OkObjectResult>(result);
            var returnedData = Assert.IsType<GenericResponseList<GetFaqResponse>>(okResult.Value);
            Assert.NotNull(returnedData.Results);
            Assert.Equal(faqList.Count, returnedData.Results.Count());
        }


        [Fact]
        public async Task UpdateFaqsStatus_ReturnsBadRequest_WhenRegionCodeIsInvalid()
        {
            // Arrange: Mock region code validation failure
            _regionCodeValidationHelperMock.Setup(helper => helper.VerifyRegionCodeHeader(It.IsAny<HttpRequest>()))
                .Returns(new GenericResponse<string> { HasError = true });

            // Act: Call UpdateFaqsStatus
            var result = await _controller.UpdateFaqsStatus(1, It.IsAny<UpdateFaqStatusRequest>());

            // Assert: Verify the result is a BadRequest
            Assert.IsType<BadRequestObjectResult>(result);
        }

        [Fact]
        public async Task UpdateFaqsStatus_ReturnsBadRequest_WhenModelStateIsInvalid()
        {
            // Arrange: Mock region code validation success
            _regionCodeValidationHelperMock.Setup(helper => helper.VerifyRegionCodeHeader(It.IsAny<HttpRequest>()))
                .Returns(new GenericResponse<string> { HasError = false });

            // Simulate invalid model state
            _controller.ModelState.AddModelError("Status", "Required");

            // Act: Call UpdateFaqsStatus
            var result = await _controller.UpdateFaqsStatus(1, It.IsAny<UpdateFaqStatusRequest>());

            // Assert: Verify the result is a BadRequest
            Assert.IsType<BadRequestObjectResult>(result);
        }

        [Fact]
        public async Task UpdateFaqsStatus_ReturnsNotFound_WhenFaqDoesNotExist()
        {
            // Arrange: Mock region code validation success
            _regionCodeValidationHelperMock.Setup(helper => helper.VerifyRegionCodeHeader(It.IsAny<HttpRequest>()))
                .Returns(new GenericResponse<string> { HasError = false });

            // Mock the FAQ query service to return null (FAQ not found)
            _faqQueryServiceMock.Setup(service => service.GetFaqByIdAsync(It.IsAny<long>()))
                .ReturnsAsync(It.IsAny<Domain.V1.Entities.FAQ>());

            // Act: Call UpdateFaqsStatus
            var result = await _controller.UpdateFaqsStatus(1, It.IsAny<UpdateFaqStatusRequest>());

            // Assert: Verify the result is a NotFound response
            var notFoundResult = Assert.IsType<NotFoundObjectResult>(result);
            var response = Assert.IsType<GenericResponse<string>>(notFoundResult.Value);
            Assert.False(response.IsSuccess);
            Assert.Equal(ResponseStatusCode.STATUS_NOTFOUND.ToString(), response.StatusCode);
        }
        [Fact]
        public async Task UpdateFaqsStatus_ReturnsNotFound_WhenFAQUserTypesDoesNotExist()
        {
            // Arrange: Mock region code validation success
            _regionCodeValidationHelperMock.Setup(helper => helper.VerifyRegionCodeHeader(It.IsAny<HttpRequest>()))
                .Returns(new GenericResponse<string> { HasError = false });

            // Mock the FAQ query service to return null (FAQ not found)
            _faqQueryServiceMock.Setup(service => service.GetFaqByIdAsync(It.IsAny<long>()))
                 .ReturnsAsync(_faqMockData);

            _faqQueryServiceMock.Setup(service => service.GetFaqLanguageAsync(It.IsAny<long>()))
                .ReturnsAsync(_fAQLanguageMockData);

            _faqQueryServiceMock.Setup(service => service.GetFaqUserTypesAsync(It.IsAny<long>()))
                .ReturnsAsync(It.IsAny<FAQUserTypes>());

            // Act: Call UpdateFaqsStatus
            var result = await _controller.UpdateFaqsStatus(1, It.IsAny<UpdateFaqStatusRequest>());

            // Assert: Verify the result is a NotFound response
            var notFoundResult = Assert.IsType<NotFoundObjectResult>(result);
            var response = Assert.IsType<GenericResponse<string>>(notFoundResult.Value);
            Assert.False(response.IsSuccess);
            Assert.Equal(ResponseStatusCode.STATUS_NOTFOUND.ToString(), response.StatusCode);
        }

        [Fact]
        public async Task UpdateFaqsStatus_ReturnsNotFound_WhenFaqLanguageIsDeleted()
        {
            // Arrange: Mock region code validation success
            _regionCodeValidationHelperMock.Setup(helper => helper.VerifyRegionCodeHeader(It.IsAny<HttpRequest>()))
                .Returns(new GenericResponse<string> { HasError = false });

            // Mock the FAQ query service to return a FAQ but a deleted FAQ language
            _faqQueryServiceMock.Setup(service => service.GetFaqByIdAsync(It.IsAny<long>()))
                .ReturnsAsync(_faqMockData);

            _faqQueryServiceMock.Setup(service => service.GetFaqLanguageAsync(It.IsAny<long>()))
                .ReturnsAsync(It.IsAny<FAQLanguage>());

            // Act: Call UpdateFaqsStatus
            var result = await _controller.UpdateFaqsStatus(1, It.IsAny<UpdateFaqStatusRequest>());

            // Assert: Verify the result is a NotFound response
            var notFoundResult = Assert.IsType<NotFoundObjectResult>(result);
            var response = Assert.IsType<GenericResponse<string>>(notFoundResult.Value);
            Assert.False(response.IsSuccess);
            Assert.Equal(ResponseStatusCode.STATUS_NOTFOUND.ToString(), response.StatusCode);
        }

        [Fact]
        public async Task UpdateFaqsStatus_ReturnsOk_WhenUpdateIsSuccessful()
        {
            // Arrange: Mock region code validation success
            _regionCodeValidationHelperMock.Setup(helper => helper.VerifyRegionCodeHeader(It.IsAny<HttpRequest>()))
                .Returns(new GenericResponse<string> { HasError = false });

            // Mock the FAQ and related services to return valid data
            _faqQueryServiceMock.Setup(service => service.GetFaqByIdAsync(It.IsAny<long>()))
                .ReturnsAsync(_faqMockData);

            _faqQueryServiceMock.Setup(service => service.GetFaqLanguageAsync(It.IsAny<long>()))
                .ReturnsAsync(_fAQLanguageMockData);

            var faqUserType = new FAQUserTypes { IsDeleted = false, CreatedDate = DateTime.UtcNow, Id = 1 };
            _faqQueryServiceMock.Setup(service => service.GetFaqUserTypesAsync(It.IsAny<long>()))
                .ReturnsAsync(faqUserType);

            var updateRequest = new UpdateFaqStatusRequest { Status = false };
            var updateResult = new GenericResponse<string> { IsSuccess = true, HasError = false };
            _faqCommandServiceMock.Setup(service => service.UpdateFaqAsync(It.IsAny<UpdateFaqRequest>(), It.IsAny<Domain.V1.Entities.FAQ>(), It.IsAny<FAQLanguage>(), It.IsAny<FAQUserTypes>()))
                .ReturnsAsync(updateResult);

            // Act: Call UpdateFaqsStatus
            var result = await _controller.UpdateFaqsStatus(1, updateRequest);

            // Assert: Verify the result is Ok
            var okResult = Assert.IsType<OkObjectResult>(result);
            var response = Assert.IsType<GenericResponse<string>>(okResult.Value);
            Assert.True(response.IsSuccess);
        }


        [Fact]
        public async Task UpdateFaqsStatus_BadRequest_WhenUpdateFailed()
        {
            // Arrange: Mock region code validation success
            _regionCodeValidationHelperMock.Setup(helper => helper.VerifyRegionCodeHeader(It.IsAny<HttpRequest>()))
                .Returns(new GenericResponse<string> { HasError = false });

            // Mock the FAQ and related services to return valid data
            _faqQueryServiceMock.Setup(service => service.GetFaqByIdAsync(It.IsAny<long>()))
                .ReturnsAsync(_faqMockData);

            _faqQueryServiceMock.Setup(service => service.GetFaqLanguageAsync(It.IsAny<long>()))
                .ReturnsAsync(_fAQLanguageMockData);

            var faqUserType = new FAQUserTypes { IsDeleted = false, CreatedDate = DateTime.UtcNow, Id = 1 };
            _faqQueryServiceMock.Setup(service => service.GetFaqUserTypesAsync(It.IsAny<long>()))
                .ReturnsAsync(faqUserType);

            var updateRequest = new UpdateFaqStatusRequest { Status = false };
            var updateResult = new GenericResponse<string> { IsSuccess = false, HasError = true };
            _faqCommandServiceMock.Setup(service => service.UpdateFaqAsync(It.IsAny<UpdateFaqRequest>(), It.IsAny<Domain.V1.Entities.FAQ>(), It.IsAny<FAQLanguage>(), It.IsAny<FAQUserTypes>()))
                .ReturnsAsync(updateResult);

            // Act: Call UpdateFaqsStatus
            var result = await _controller.UpdateFaqsStatus(1, updateRequest);

            // Assert: Verify the result is Ok
            var okResult = Assert.IsType<BadRequestObjectResult>(result);
            var response = Assert.IsType<GenericResponse<string>>(okResult.Value);
            Assert.True(response.HasError);
        }

        [Fact]
        public async Task UpdateFaqsStatus_ReturnsBadRequest_WhenDbUpdateConcurrencyExceptionOccurs()
        {
            // Arrange: Mock region code validation success
            _regionCodeValidationHelperMock.Setup(helper => helper.VerifyRegionCodeHeader(It.IsAny<HttpRequest>()))
                .Returns(new GenericResponse<string> { HasError = false });

            // Mock the FAQ and related services to return valid data

            _faqQueryServiceMock.Setup(service => service.GetFaqByIdAsync(It.IsAny<long>()))
                .ReturnsAsync(_faqMockData);

            _faqQueryServiceMock.Setup(service => service.GetFaqLanguageAsync(It.IsAny<long>()))
                .ReturnsAsync(_fAQLanguageMockData);

            var faqUserType = new FAQUserTypes { IsDeleted = false, CreatedDate = DateTime.UtcNow, Id = 1 };
            _faqQueryServiceMock.Setup(service => service.GetFaqUserTypesAsync(It.IsAny<long>()))
                .ReturnsAsync(faqUserType);

            var updateRequest = new UpdateFaqStatusRequest { Status = false };

            // Simulate DbUpdateConcurrencyException
            _faqCommandServiceMock.Setup(service => service.UpdateFaqAsync(It.IsAny<UpdateFaqRequest>(), It.IsAny<Domain.V1.Entities.FAQ>(), It.IsAny<FAQLanguage>(), It.IsAny<FAQUserTypes>()))
                .ThrowsAsync(new DbUpdateConcurrencyException());

            // Act: Call UpdateFaqsStatus
            var result = await _controller.UpdateFaqsStatus(1, updateRequest);

            // Assert: Verify the result is a BadRequest
            var badRequestResult = Assert.IsType<BadRequestObjectResult>(result);
            var response = Assert.IsType<GenericResponse<string>>(badRequestResult.Value);
            Assert.False(response.IsSuccess);
            Assert.Equal(ResponseStatusCode.STATUS_BADREQUEST.ToString(), response.StatusCode);
        }

        #region Get All Status 


        [Fact]
        public async void GetAllStatus_ReturnsOkResult_WithValidData()
        {
            // Arrange
            _regionCodeValidationHelperMock.Setup(helper => helper.VerifyRegionCodeHeader(It.IsAny<HttpRequest>()))
                .Returns((GenericResponse<string>)null); // No validation error

            // Act
            var result = await _controller.GetAllStatus();

            // Assert
            var okResult = result.Should().BeOfType<OkObjectResult>().Subject;
            var response = okResult.Value as GenericResponseList<GetAllStatusTypeDto>;

            response.Should().NotBeNull();
            response.HasError.Should().BeFalse();
            response.IsSuccess.Should().BeTrue();
            response.StatusCode.Should().Be(((int)ResponceStatusCode.Success).ToString());
            response.Results.Should().NotBeNull();
            response.Results.Should().HaveCount(2);
            response.Results.Should().Contain(s => s.Id == (int)GetStatus.Active);
            response.Results.Should().Contain(s => s.Id == (int)GetStatus.Inactive);
        }

        [Fact]
        public async Task GetAllStatus_ReturnsBadRequest_WhenRegionValidationFails()
        {
            // Arrange
            _regionCodeValidationHelperMock.Setup(helper => helper.VerifyRegionCodeHeader(It.IsAny<HttpRequest>()))
                .Returns(new GenericResponse<string> { HasError = true });

            // Act
            var result = await _controller.GetAllStatus();

            // Assert
            result.Should().BeOfType<BadRequestObjectResult>();
        }

        [Fact]
        public async Task GetAllStatus_ReturnsCorrectStatusValues()
        {
            // Arrange
            _regionCodeValidationHelperMock.Setup(helper => helper.VerifyRegionCodeHeader(It.IsAny<HttpRequest>()))
                .Returns((GenericResponse<string>)null); // No validation error

            // Act
            var result = await _controller.GetAllStatus() as OkObjectResult;
            var response = result.Value as GenericResponseList<GetAllStatusTypeDto>;

            // Assert
            response.Should().NotBeNull();
            response.Results.Should().NotBeNull();
            var resultList = response.Results.ToList();
            resultList[0].Status.Should().Be(Enum.GetName(GetStatus.Active).Replace(spliterCharacter, replaceCharacter));
            resultList[1].Status.Should().Be(Enum.GetName(GetStatus.Inactive).Replace(spliterCharacter, replaceCharacter));
        }
        [Fact]
        public async Task GetAllStatus_ReturnsHttp200OK()
        {
            // Arrange
            _regionCodeValidationHelperMock.Setup(helper => helper.VerifyRegionCodeHeader(It.IsAny<HttpRequest>()))
                .Returns((GenericResponse<string>)null); // No validation error

            // Act
            var result = await _controller.GetAllStatus() as OkObjectResult;

            // Assert
            result.Should().NotBeNull();
            result.StatusCode.Should().Be(StatusCodes.Status200OK);
        }

        #endregion
        #region Get All Platforms

        [Fact]
        public async Task GetAllPlatformsTypes_ReturnsOk_WithValidData()
        {
            // Arrange
            _regionCodeValidationHelperMock.Setup(r => r.VerifyRegionCodeHeader(It.IsAny<HttpRequest>()))
                              .Returns((GenericResponse<string>)null);

            // Act
            var result = await _controller.GetAllPlatformsTypes();

            // Assert
            var okResult = Assert.IsType<OkObjectResult>(result);
            var response = Assert.IsType<GenericResponseList<GetAllPlatformsTypesDto>>(okResult.Value);
            Assert.False(response.HasError);
            Assert.True(response.IsSuccess);
            Assert.Equal(((int)ResponceStatusCode.Success).ToString(), response.StatusCode);
            Assert.NotEmpty(response.Results);
            Assert.Equal(ResponseMessage.STATUS_RECORDS_LOADED, response.Message);
            Assert.Equal(CommonConstants.SUCCESS, response.MessageType);
        }

        [Fact]
        public async Task GetAllPlatformsTypes_ContainsExpectedPlatformTypes()
        {
            // Arrange
            _regionCodeValidationHelperMock.Setup(r => r.VerifyRegionCodeHeader(It.IsAny<HttpRequest>()))
                              .Returns((GenericResponse<string>)null);

            // Act
            var result = await _controller.GetAllPlatformsTypes();

            // Assert
            var okResult = Assert.IsType<OkObjectResult>(result);
            var response = Assert.IsType<GenericResponseList<GetAllPlatformsTypesDto>>(okResult.Value);
            var expectedPlatforms = new List<int> { (int)AllPlatforms.PatientPortal, (int)AllPlatforms.PatientApp, (int)AllPlatforms.OtherPortal, (int)AllPlatforms.DoctorApp };

            foreach (var item in response.Results)
            {
                Assert.Contains(item.Id, expectedPlatforms);
            }
        }

        [Fact]
        public async Task GetAllPlatformsTypes_PlatformNamesAreNotEmpty()
        {
            // Arrange
            _regionCodeValidationHelperMock.Setup(r => r.VerifyRegionCodeHeader(It.IsAny<HttpRequest>()))
                              .Returns((GenericResponse<string>)null);

            // Act
            var result = await _controller.GetAllPlatformsTypes();

            // Assert
            var okResult = Assert.IsType<OkObjectResult>(result);
            var response = Assert.IsType<GenericResponseList<GetAllPlatformsTypesDto>>(okResult.Value);

            foreach (var item in response.Results)
            {
                Assert.False(string.IsNullOrWhiteSpace(item.Platforms));
            }
        }

        [Fact]
        public async Task GetAllPlatformsTypes_ReturnsCorrectNumberOfPlatforms()
        {
            // Arrange
            _regionCodeValidationHelperMock.Setup(r => r.VerifyRegionCodeHeader(It.IsAny<HttpRequest>()))
                              .Returns((GenericResponse<string>)null);

            // Act
            var result = await _controller.GetAllPlatformsTypes();

            // Assert
            var okResult = Assert.IsType<OkObjectResult>(result);
            var response = Assert.IsType<GenericResponseList<GetAllPlatformsTypesDto>>(okResult.Value);
            Assert.NotNull(response.Results);
            Assert.Equal(4, response.Results.Count());
        }
        #endregion
    }
}

