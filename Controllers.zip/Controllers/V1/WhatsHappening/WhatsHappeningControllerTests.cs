﻿using Aurora.AdministrationService.API.Controllers.WhatsHappenings;
using Aurora.AdministrationService.API.Enum;
using Aurora.AdministrationService.API.Helper;
using Aurora.AdministrationService.API.Models.Dto.WhatHappenings;
using Aurora.AdministrationService.API.Models.RequestModels.V1.WhatsHappening;
using Aurora.AdministrationService.API.Models.ResponseModels.WhatsHappening;
using Aurora.AdministrationService.API.Resources;
using Aurora.AdministrationService.API.Services.IService.WhatsHappenings;
using Aurora.AdministrationService.CrossCutting.CommonModels;
using Aurora.AdministrationService.CrossCutting.Constants;
using FluentAssertions;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Moq;

namespace Aurora.AdministrationService.Tests.API.Controllers.V1.WhatsHappening
{
    public class WhatsHappeningControllerTests
    {
        private readonly Mock<IWhatsHappeningQueryService> _whatsHappeningServiceMock;
        private readonly WhatsHappeningController _controller;
        private readonly Mock<IWhatsHappeningCommandService> _whatsHappeningCommandServiceMock;
        private readonly Mock<IRegionCodeValidationHelper> _regionCodeValidationHelperMock;

        /// <summary> Initializes a new instance of the <see cref="WhatsHappeningControllerTests"/> class.</summary>
        /// <remarks>
        /// - Mocks dependencies for <see cref="IWhatsHappeningQueryService"/> and <see cref="IRegionCodeValidationHelper"/>.
        /// - Creates an instance of <see cref="WhatsHappeningController"/> with mocked dependencies for unit testing.
        /// </remarks>
        public WhatsHappeningControllerTests()
        {
            _whatsHappeningServiceMock = new Mock<IWhatsHappeningQueryService>();
            _whatsHappeningCommandServiceMock = new Mock<IWhatsHappeningCommandService>();
            _regionCodeValidationHelperMock = new Mock<IRegionCodeValidationHelper>();
            _controller = new WhatsHappeningController(_whatsHappeningServiceMock.Object,
            _regionCodeValidationHelperMock.Object, _whatsHappeningCommandServiceMock.Object);
        }

        #region Get WhatsHappening Search with Filters Controller Test Cases


        /// <summary>
        /// Tests that <see cref="WhatsHappeningController.GetWhatsHappeningBySearch"/> 
        /// returns a BadRequest response when the region code is invalid.
        /// </summary>
        /// <remarks>
        /// - Mocks an invalid region code validation response.
        /// - Calls the API with search filters.
        /// - Asserts that the result is a <see cref="BadRequestObjectResult"/> containing the expected error response.
        /// </remarks>
        [Fact]
        public async Task GetWhatsHappeningBySearch_ShouldReturnBadRequest_WhenRegionCodeIsInvalid()
        {
            // Arrange
            var mockFilters = new WhatsHappeningSearchFilterDto
            {
                Title = "Blood Donation Drive",
                //Category = "Charity",
                //Hospital = "Global Health Center",
                CategoryId = 1,
                HospitalId = 1,
                Status = "Inactive",
                StartDate = new DateTime(2024, 06, 15, 0, 0, 0, DateTimeKind.Utc),
                EndDate = new DateTime(2024, 06, 20, 0, 0, 0, DateTimeKind.Utc),
                PageNumber = 2,
                PageSize = 5
            };

            // Create a GenericResponse with the error information
            var invalidRegionCodeResponse = new GenericResponse<string>
            {
                HasError = true,
                StatusCode = ResponseStatusCode.STATUS_BADREQUEST,// Assuming 400 as BadRequest status code
                IsSuccess = false,
            };

            // Mock the region code validation to simulate an invalid region code
            _regionCodeValidationHelperMock
                .Setup(x => x.VerifyRegionCodeHeader(It.IsAny<HttpRequest>()))
                .Returns(invalidRegionCodeResponse);

            // Act
            var result = await _controller.GetWhatsHappeningBySearch(mockFilters);

            // Assert
            result.Should().BeOfType<BadRequestObjectResult>()
                .Which.Value.Should().BeEquivalentTo(invalidRegionCodeResponse);
        }

        /// <summary>
        /// Tests that <see cref="WhatsHappeningController.GetWhatsHappeningBySearch"/> 
        /// returns an OK response when doctors are found based on the provided search filters.
        /// </summary>
        /// <remarks>
        /// - Mocks a successful response from the service with sample data.
        /// - Ensures that the region code validation helper is called.
        /// - Calls the API with search filters.
        /// - Asserts that the result is an <see cref="OkObjectResult"/> with a status code of 200.
        /// </remarks>
        [Fact]
        public async Task GetWhatsHappeningBySearch_ShouldReturnOk_WhenDoctorsFound()
        {
            // Arrange
            var mockFilters = new WhatsHappeningSearchFilterDto
            {
                Title = "Blood Donation Drive",
                //Category = "Charity",
                //Hospital = "Global Health Center",
                CategoryId = 1,
                HospitalId = 1,
                Status = "Active",
                StartDate = new DateTime(2024, 06, 15, 0, 0, 0, DateTimeKind.Utc),
                EndDate = new DateTime(2024, 06, 20, 0, 0, 0, DateTimeKind.Utc),
                PageNumber = 2,
                PageSize = 5
            };
            var data = new GenericResponse<PaginatedWhatsHappeningResponseDto>
            {
                IsSuccess = true,
                HasError = false,
                Result = new PaginatedWhatsHappeningResponseDto
                {
                    CurrentPage = 1,
                    PageSize = 10,
                    TotalRecords = 10,
                    Data = GetMockWhatsHappeningData()
                }
            };

            _regionCodeValidationHelperMock
                .Setup(helper => helper.VerifyRegionCodeHeader(It.IsAny<HttpRequest>()));

            _whatsHappeningServiceMock
                .Setup(service => service.GetWhatsHappeningBySearch(mockFilters))
                .ReturnsAsync(data);

            // Act
            var result = await _controller.GetWhatsHappeningBySearch(mockFilters);

            // Assert
            result.Should().NotBeNull();
            result.Should().BeOfType<OkObjectResult>();

            var okResult = result as OkObjectResult;
            okResult.Should().NotBeNull();
            okResult!.StatusCode.Should().Be(200);

            var response = okResult.Value as GenericResponse<PaginatedWhatsHappeningResponseDto>;
            response.Should().NotBeNull();
            response!.IsSuccess.Should().BeTrue();
            response.HasError.Should().BeFalse();
            response.Result.Should().NotBeNull();

            var paginatedData = response.Result;
            paginatedData!.Data.Should().NotBeNullOrEmpty();
            paginatedData.Data.Should().HaveCountGreaterThan(0);
        }

        /// <summary> Generates a mock list of "What's Happening" events for testing purposes.</summary>
        /// <returns>A list of <see cref="GetWhatsHappeningDto"/> containing sample event data.</returns>
        private static List<GetWhatsHappeningDto> GetMockWhatsHappeningData()
        {
            return new List<GetWhatsHappeningDto>
            {
                new GetWhatsHappeningDto
                {
                    Id = 1,
                    Title = "Health Awareness Camp",
                    Url = "https://example.com/health-camp",
                    ImageUrl = "https://example.com/images/health-camp.jpg", // Renamed from ImageURL if needed
                    CategoryId = 1,
                    StartDate = new DateTime(2024, 05, 10, 0, 0, 0, DateTimeKind.Utc),
                    EndDate = new DateTime(2024, 05, 12, 0, 0, 0, DateTimeKind.Utc),
                    Description = "A three-day health awareness camp with free checkups.",
                    Status = true,
                    LocationId = 1001,
                    LocationName = "City Park",
                    LocationLatitude = 37.7749M,
                    LocationLongitude = -122.4194M,
                    LocationCity = "San Francisco",
                    LocationState = "California",
                    CreatedDate = new DateTime(2024, 05, 09, 0, 0, 0, DateTimeKind.Utc),
                    UpdatedDate = new DateTime(2024, 05, 09, 0, 0, 0, DateTimeKind.Utc),
                    RecordVersion = MockRecordVersion.Generate(),
                    CreatedBy = "Seeder",
                    UpdatedBy = "Seeder"
                },
                new GetWhatsHappeningDto
                {
                    Id = 2,
                    Title = "Blood Donation Drive",
                    Url = "https://example.com/blood-donation",
                    ImageUrl = "https://example.com/images/blood-donation.jpg", // Renamed from ImageURL
                    CategoryId = 1,
                    StartDate = new DateTime(2024, 06, 10, 0, 0, 0, DateTimeKind.Utc),
                    EndDate = new DateTime(2024, 06, 12, 0, 0, 0, DateTimeKind.Utc),
                    Description = "Join our blood donation drive and save lives!",
                    Status = true,
                    LocationId = 1002,
                    LocationName = "Downtown Community Center",
                    LocationLatitude = 40.7128M,
                    LocationLongitude = -74.0060M,
                    LocationCity = "New York",
                    LocationState = "New York",
                    UpdatedDate = new DateTime(2024, 05, 09, 0, 0, 0, DateTimeKind.Utc),
                    RecordVersion = MockRecordVersion.Generate(),
                    CreatedBy = "Seeder",
                    UpdatedBy = "Seeder"
                },
                new GetWhatsHappeningDto
                {
                    Id = 3,
                    Title = "Mental Health Workshop",
                    Url = "https://example.com/mental-health",
                    ImageUrl = "https://example.com/images/mental-health.jpg", // Renamed from ImageURL
                    CategoryId = 1,
                    StartDate = new DateTime(2024, 07, 10, 0, 0, 0, DateTimeKind.Utc),
                    EndDate = new DateTime(2024, 07, 12, 0, 0, 0, DateTimeKind.Utc),
                    Description = "A workshop on mental health awareness and self-care.",
                    Status = false,
                    LocationId = 1003,
                    LocationName = "Wellness Center",
                    LocationLatitude = 34.0522M,
                    LocationLongitude = -118.2437M,
                    LocationCity = "Los Angeles",
                    LocationState = "California",
                    UpdatedDate = new DateTime(2024, 05, 09, 0, 0, 0, DateTimeKind.Utc),
                    RecordVersion = MockRecordVersion.Generate(),
                    CreatedBy = "Seeder",
                    UpdatedBy = "Seeder"
                }
            };
        }

        #endregion

        #region Delete WhatsHappening Controller Test Cases

        [Fact]
        public async Task DeleteWhatsHappeningById_ShouldReturnBadRequest_WhenRegionCodeIsInvalid()
        {
            //Arrange
            var mockRequest = new DeleteWhatsHappeningRequest
            {
                Id = 1,
                RecordVersion = new byte[] { 1, 2, 3, 4, 5 }
            };

            // Create a GenericResponse with the error information
            var invalidRegionCodeResponse = new GenericResponse<string>
            {
                HasError = true,
                StatusCode = ResponseStatusCode.STATUS_BADREQUEST,// Assuming 400 as BadRequest status code
                IsSuccess = false,
            };

            // Mock the region code validation to simulate an invalid region code
            _regionCodeValidationHelperMock
                .Setup(x => x.VerifyRegionCodeHeader(It.IsAny<HttpRequest>()))
                .Returns(invalidRegionCodeResponse);

            // Act
            var result = await _controller.DeleteWhatsHappeningById(mockRequest);

            // Assert
            result.Should().BeOfType<BadRequestObjectResult>()
                .Which.Value.Should().BeEquivalentTo(invalidRegionCodeResponse);
        }

        [Fact]
        public async Task DeleteWhatsHappeningById_ShouldReturnOk_WhenWhatsHappeningDeletedSucessfully()
        {
            //Arrange
            var mockRequest = new DeleteWhatsHappeningRequest
            {
                Id = 1,
                RecordVersion = new byte[] { 1, 2, 3, 4, 5 }
            };
            var data = new GenericResponse<string>()
            {
                HasError = false,
                IsSuccess = true,
                StatusCode = ((int)ResponceStatusCode.Success).ToString(),
                Result = null,
                Message = ResponseMessage.WHATSHAPPENING_DELETION_SUCCESS
            };


            _regionCodeValidationHelperMock
                .Setup(helper => helper.VerifyRegionCodeHeader(It.IsAny<HttpRequest>()));


            _whatsHappeningServiceMock
                .Setup(service => service.GetWhatsHappeningById(mockRequest.Id))
                 .ReturnsAsync(GetSampleWhatsHappeningDetailDTO());


            _whatsHappeningCommandServiceMock
                .Setup(service => service.DeleteWhatsHappeningByIdAsync(mockRequest.RecordVersion, mockRequest.Id))
                 .ReturnsAsync(data);

            // Act
            var result = await _controller.DeleteWhatsHappeningById(mockRequest);

            // Assert
            var okResult = result as OkObjectResult;
            okResult.Should().NotBeNull();
            okResult?.StatusCode.Should().Be(200);
        }

        [Fact]
        public async Task DeleteWhatsHappeningById_ShouldReturnNotFound_WhenWhatsHappeningNotFound()
        {
            //Arrange
            var mockRequest = new DeleteWhatsHappeningRequest
            {
                Id = 1,
                RecordVersion = new byte[] { 1, 2, 3, 4, 5 }
            };
            var data = new GenericResponse<string>()
            {
                HasError = false,
                IsSuccess = true,
                StatusCode = ((int)ResponceStatusCode.Success).ToString(),
                Result = null,
                Message = ResponseMessage.WHATSHAPPENING_DELETION_SUCCESS
            };

            _regionCodeValidationHelperMock
                .Setup(helper => helper.VerifyRegionCodeHeader(It.IsAny<HttpRequest>()));

            _whatsHappeningServiceMock
                 .Setup(service => service.GetWhatsHappeningById(mockRequest.Id))
                 .ReturnsAsync((GetWhatsHappeningDetailDto)null!);

            _whatsHappeningCommandServiceMock
                .Setup(service => service.DeleteWhatsHappeningByIdAsync(mockRequest.RecordVersion, mockRequest.Id))
                 .ReturnsAsync(data);

            // Act
            var result = await _controller.DeleteWhatsHappeningById(mockRequest);

            // Assert
            var notFoundResult = result as NotFoundObjectResult;
            notFoundResult.Should().NotBeNull();
            notFoundResult?.StatusCode.Should().Be(404);
        }

        [Fact]
        public async Task DeleteWhatsHappeningById_ShouldReturnBadRequest_WhenWhatsHappeningIdPassedNull()
        {
            //Arrange
            var mockRequest = new DeleteWhatsHappeningRequest
            {
                Id = -1,
                RecordVersion = new byte[] { 1, 2, 3, 4, 5 }
            };
            var data = new GenericResponse<string>()
            {
                HasError = false,
                IsSuccess = true,
                StatusCode = ((int)ResponceStatusCode.Success).ToString(),
                Result = null,
                Message = ResponseMessage.WHATSHAPPENING_DELETION_SUCCESS
            };


            _regionCodeValidationHelperMock
                .Setup(helper => helper.VerifyRegionCodeHeader(It.IsAny<HttpRequest>()));

            _whatsHappeningCommandServiceMock
                .Setup(service => service.DeleteWhatsHappeningByIdAsync(mockRequest.RecordVersion, mockRequest.Id))
                 .ReturnsAsync(data);

            // Act
            var result = await _controller.DeleteWhatsHappeningById(mockRequest);

            // Assert
            var badRequestResult = result as BadRequestObjectResult;
            badRequestResult.Should().NotBeNull();
            badRequestResult?.StatusCode.Should().Be(400);
        }

        public static GetWhatsHappeningDetailDto GetSampleWhatsHappeningDetailDTO()
        {
            return new GetWhatsHappeningDetailDto
            {
                Id = 1,
                Title = "AI & Innovation Summit 2025",
                URL = "https://example.com/ai-summit",
                //Category = "Technology",
                CategoryId = 1,
                StartDate = new DateTime(2025, 6, 15, 9, 0, 0, DateTimeKind.Utc),
                EndDate = new DateTime(2025, 6, 17, 18, 0, 0, DateTimeKind.Utc),
                Description = "An annual summit featuring AI advancements, research, and industry trends.",
                Status = true,
                RecordVersion = new byte[] { 10, 20, 30, 40, 50 }, // Sample byte array
                IsDeleted = false
            };
        }
        #endregion

        #region Get WhatsHappening By ID Controoler Test Cases
        [Fact]
        public async Task GetWhatsHappeningsDetailById_ShouldReturnBadRequest_WhenRegionCodeIsInvalid()
        {
            //Arrange
            int mockId = 1;
            // Create a GenericResponse with the error information
            var invalidRegionCodeResponse = new GenericResponse<string>
            {
                HasError = true,
                StatusCode = ResponseStatusCode.STATUS_BADREQUEST,// Assuming 400 as BadRequest status code
                IsSuccess = false,
            };

            // Mock the region code validation to simulate an invalid region code
            _regionCodeValidationHelperMock
                .Setup(x => x.VerifyRegionCodeHeader(It.IsAny<HttpRequest>()))
                .Returns(invalidRegionCodeResponse);

            // Act
            var result = await _controller.GetWhatsHappeningsDetail(mockId);

            // Assert
            result.Should().BeOfType<BadRequestObjectResult>()
                .Which.Value.Should().BeEquivalentTo(invalidRegionCodeResponse);
        }
        [Fact]
        public async Task GetWhatsHappeningsDetailById_ShouldReturnOk_WhenWhatsHappeningExists()
        {
            //Arrange
            int mockId = 1;

            var data = new GenericResponse<WhatsHappeningDetailDto>()
            {
                HasError = false,
                IsSuccess = true,
                StatusCode = ((int)ResponceStatusCode.Success).ToString(),
                Result = new WhatsHappeningDetailDto { },
                Message = Resource.RecordLoadMessage
            };

            _regionCodeValidationHelperMock
                .Setup(helper => helper.VerifyRegionCodeHeader(It.IsAny<HttpRequest>()));

            _whatsHappeningServiceMock
                .Setup(service => service.GetWhatsHappeningDetail(mockId))
                 .ReturnsAsync(data);
            // Act
            var result = await _controller.GetWhatsHappeningsDetail(mockId);

            // Assert
            var okResult = result as OkObjectResult;
            okResult.Should().NotBeNull();
            okResult?.StatusCode.Should().Be(200);
        }

        [Fact]
        public async Task GetWhatsHappeningsDetailById_ShouldReturnNotFound_WhenWhatsHappeningDoesNotExist()
        {
            // Arrange
            int mockId = 1;

            var notFoundResponse = new GenericResponse<WhatsHappeningDetailDto>()
            {
                HasError = false,
                IsSuccess = false,
                StatusCode = ResponseStatusCode.STATUS_NOTFOUND.ToString()
            };

            _regionCodeValidationHelperMock
                .Setup(helper => helper.VerifyRegionCodeHeader(It.IsAny<HttpRequest>()));

            _whatsHappeningServiceMock
                .Setup(service => service.GetWhatsHappeningDetail(mockId))
                .ReturnsAsync(notFoundResponse);

            // Act
            var result = await _controller.GetWhatsHappeningsDetail(mockId);

            // Assert
            var notFoundResult = result as NotFoundObjectResult;
            notFoundResult.Should().NotBeNull();
            notFoundResult?.StatusCode.Should().Be(404); // 404 for Not Found
            var response = notFoundResult?.Value as GenericResponse<WhatsHappeningDetailDto>;
            response.Should().BeEquivalentTo(notFoundResponse);
        }
        #endregion

        #region Create WhatsHappening Controller test cases
        /// <summary>
        /// Tests that <see cref="WhatsHappeningController.CreateWhatsHappening"/> 
        /// returns a BadRequest response when the region code is invalid.
        /// </summary>
        /// <remarks>
        /// - Mocks an invalid region code validation response.
        /// - Calls the API with search filters.
        /// - Asserts that the result is a <see cref="BadRequestObjectResult"/> containing the expected error response.
        /// </remarks>
        [Fact]
        public async Task CreateWhatsHappening_ShouldReturnBadRequest_WhenRegionCodeIsInvalid()
        {
            // Arrange
            var mockRequest = new CreateWhatsHappeningRequest // Changed from WhatsHappeningDto
            {
                Title = "Health Awareness Campaign",
                URL = "https://example.com/health-awareness",
                HospitalId = 101,
                CategoryId = 1,
                Image = "https://example.com/images/health-awareness.jpg",
                StartDate = DateTime.UtcNow,
                EndDate = DateTime.UtcNow.AddHours(1),
                Description = "A campaign to raise awareness about health issues.",
                Status = true
            };

            // Create a GenericResponse with the error information
            var invalidRegionCodeResponse = new GenericResponse<string>
            {
                HasError = true,
                StatusCode = ResponseStatusCode.STATUS_BADREQUEST, // Assuming 400 as BadRequest status code
                IsSuccess = false,
            };

            // Mock the region code validation to simulate an invalid region code
            _regionCodeValidationHelperMock
                .Setup(x => x.VerifyRegionCodeHeader(It.IsAny<HttpRequest>()))
                .Returns(invalidRegionCodeResponse);

            // Act
            var result = await _controller.CreateWhatsHappening(mockRequest);

            // Assert
            result.Should().BeOfType<BadRequestObjectResult>()
                .Which.Value.Should().BeEquivalentTo(invalidRegionCodeResponse);
        }


        /// <summary>
        /// Tests that <see cref="WhatsHappeningController.CreateWhatsHappening"/> 
        /// returns an OK response when doctors are found based on the provided search filters.
        /// </summary>
        /// <remarks>
        /// - Mocks a successful response from the service with sample data.
        /// - Ensures that the region code validation helper is called.
        /// - Calls the API with search filters.
        /// </remarks>
        [Fact]
        public async Task CreateWhatsHappening_ShouldReturnOk_WhenWhatsHappeningCreated()
        {
            // Arrange
            var mockRequest = new CreateWhatsHappeningRequest
            {
                Id = 1,
                Title = "Health Awareness Campaign",
                URL = "https://example.com/health-awareness",
                HospitalId = 101,
                CategoryId = 1,
                Image = "https://example.com/images/health-awareness.jpg",
                StartDate = DateTime.UtcNow,
                EndDate = DateTime.UtcNow.AddHours(1),
                Description = "A campaign to raise awareness about health issues.",
                Status = true,
                IsDeleted = false
            };

            var data = new GenericResponse<string>
            {
                HasError = false,
                IsSuccess = true,
                StatusCode = ResponseStatus.STATUS_SUCCESS_Create,
                Result = null,
                Message = Resource.RecordInsertionMessage
            };

            _regionCodeValidationHelperMock
                .Setup(helper => helper.VerifyRegionCodeHeader(It.IsAny<HttpRequest>()));

            _whatsHappeningCommandServiceMock
                .Setup(service => service.CreateWhatsHappeningAsync(mockRequest))
                .ReturnsAsync(data);

            // Act
            var result = await _controller.CreateWhatsHappening(mockRequest);

            // Assert
            result.Should().NotBeNull();
            result.Should().BeOfType<OkObjectResult>();

            var okResult = result as OkObjectResult;
            okResult.Should().NotBeNull();
            okResult?.StatusCode.Should().Be(200);

            var response = okResult?.Value as GenericResponse<string>;
            response.Should().NotBeNull();
            response!.IsSuccess.Should().BeTrue();
            response.HasError.Should().BeFalse();
        }

        [Fact]
        /// <summary>
        /// Tests that <see cref="WhatsHappeningController.CreateWhatsHappening"/> 
        /// returns a BadRequest response when the result is unsuccessful.
        /// </summary>
        public async Task CreateWhatsHappening_ShouldReturnBadRequest_WhenResultIsNotSuccess()
        {
            // Arrange
            var mockRequest = new CreateWhatsHappeningRequest
            {
                Id = 1,
                Title = "Health Awareness Campaign",
                URL = "https://example.com/health-awareness",
                HospitalId = 101,
                CategoryId = 1,
                Image = "https://example.com/images/health-awareness.jpg",
                StartDate = DateTime.UtcNow,
                EndDate = DateTime.UtcNow.AddHours(1),
                Description = "A campaign to raise awareness about health issues.",
                Status = true,
                IsDeleted = false
            };

            var data = new GenericResponse<string>
            {
                HasError = true,
                IsSuccess = false,  // Set IsSuccess to false to simulate failure
                StatusCode = ResponseStatusCode.STATUS_BADREQUEST,  // Assuming 400 for Bad Request
                Result = null,
                Message = "Error creating WhatsHappening"
            };

            // Mock the region code validation to simulate a valid region code
            _regionCodeValidationHelperMock
                .Setup(helper => helper.VerifyRegionCodeHeader(It.IsAny<HttpRequest>()))
                .Returns(new GenericResponse<string> { HasError = false, IsSuccess = true });

            // Mock the CreateWhatsHappeningAsync to return the unsuccessful response
            _whatsHappeningCommandServiceMock
                .Setup(service => service.CreateWhatsHappeningAsync(mockRequest))
                .ReturnsAsync(data);

            // Act
            var result = await _controller.CreateWhatsHappening(mockRequest);

            // Assert
            result.Should().NotBeNull();
            result.Should().BeOfType<BadRequestObjectResult>();

            var badRequestResult = result as BadRequestObjectResult;
            badRequestResult.Should().NotBeNull();
            badRequestResult?.StatusCode.Should().Be(400);

            var response = badRequestResult?.Value as GenericResponse<string>;
            response.Should().NotBeNull();
            response!.IsSuccess.Should().BeFalse();
            response.HasError.Should().BeTrue();
        }

        [Fact]
        public async Task CreateWhatsHappening_ShouldReturnBadRequest_WhenModelStateIsInvalid()
        {
            // Arrange
            var mockRequest = new CreateWhatsHappeningRequest
            {
                Id = 1,
                Title = "",  // Invalid because Title is required.
                URL = "https://example.com/health-awareness",
                HospitalId = 101,
                CategoryId = 1,
                Image = "https://example.com/images/health-awareness.jpg",
                StartDate = DateTime.UtcNow,
                EndDate = DateTime.UtcNow.AddHours(1),
                Description = "A campaign to raise awareness about health issues.",
                Status = true,
                IsDeleted = false
            };

            // Mock the region code validation to simulate a valid region code
            _regionCodeValidationHelperMock
                .Setup(x => x.VerifyRegionCodeHeader(It.IsAny<HttpRequest>()))
                .Returns(new GenericResponse<string> { HasError = false, IsSuccess = true });

            // Simulate invalid ModelState by adding a model validation error
            _controller.ModelState.AddModelError("Title", "Title is required");

            // Act
            var result = await _controller.CreateWhatsHappening(mockRequest);

            // Assert
            result.Should().BeOfType<BadRequestObjectResult>();
            var badRequestResult = result as BadRequestObjectResult;
            badRequestResult.Should().NotBeNull();

            var modelState = badRequestResult?.Value as SerializableError;
            modelState.Should().NotBeNull();

            // Assert that the model state contains the expected validation error
            modelState.Should().ContainKey("Title");
        }

        #endregion


      #region Update WhatsHappening Controller test cases

        /// <summary>
        /// Tests that <see cref="WhatsHappeningController.UpdateWhatsHappening"/> 
        /// returns a BadRequest response when the region code is invalid.
        /// </summary>
        /// <remarks>
        /// - Mocks an invalid region code validation response.
        /// - Calls the API with search filters.
        /// - Asserts that the result is a <see cref="BadRequestObjectResult"/> containing the expected error response.
        /// </remarks>
        [Fact]
        public async Task UpdateWhatsHappening_ShouldReturnBadRequest_WhenRegionCodeIsInvalid()
        {
            // Arrange
            var mockRequest = new UpdateWhatsHappeningRequest
            {
                Id = 1,
                RecordVersion = Array.Empty<byte>(),
                Title = "Health Awareness Campaign",
                URL = "https://example.com/health-awareness",
                HospitalId = 101,
                CategoryId = 1,
                Image = "https://example.com/images/health-awareness.jpg",
                StartDate = DateTime.UtcNow,
                EndDate = DateTime.UtcNow.AddHours(1),
                Description = "A campaign to raise awareness about health issues.",
                Status = true,
                IsDeleted = false
            };

            // Create a GenericResponse with the error information
            var invalidRegionCodeResponse = new GenericResponse<string>
            {
                HasError = true,
                StatusCode = ResponseStatusCode.STATUS_BADREQUEST,// Assuming 400 as BadRequest status code
                IsSuccess = false,
            };

            // Mock the region code validation to simulate an invalid region code
            _regionCodeValidationHelperMock
                .Setup(x => x.VerifyRegionCodeHeader(It.IsAny<HttpRequest>()))
                .Returns(invalidRegionCodeResponse);

            // Act
            var result = await _controller.UpdateWhatsHappening(mockRequest);

            // Assert
            result.Should().BeOfType<BadRequestObjectResult>()
                .Which.Value.Should().BeEquivalentTo(invalidRegionCodeResponse);
        }


        /// <summary>
        /// Tests that <see cref="WhatsHappeningController.GetWhatsHappeningBySearch"/> 
        /// returns an OK response when doctors are found based on the provided search filters.
        /// </summary>
        /// <remarks>
        /// - Mocks a successful response from the service with sample data.
        /// - Ensures that the region code validation helper is called.
        /// - Calls the API with search filters.
        /// - Asserts that the result is an <see cref="OkObjectResult"/> with a status code of 200.
        /// </remarks>
        [Fact]
        public async Task UpdateWhatsHappening_ShouldReturnOk_WhenWhatsHappeningUpdated()
        {
            // Arrange
            var mockRequest = new UpdateWhatsHappeningRequest
            {
                Id = 1,
                Title = "Health Awareness Campaign",
                URL = "https://example.com/health-awareness",
                HospitalId = 101,
                CategoryId = 1,
                Image = "https://example.com/images/health-awareness.jpg",
                StartDate = DateTime.UtcNow,
                EndDate = DateTime.UtcNow.AddHours(1),
                Description = "A campaign to raise awareness about health issues.",
                Status = true,
                RecordVersion = new byte[] { 1, 2, 3, 4 },
                IsDeleted = false
            };
            var existingentity = new Domain.V1.Entities.Marketings.WhatsHappening()
            {
                ID = 1,
                Title = "Health Awareness Campaign",
                URL = "https://hospital.org/health-campaign",
                //Category = "Health",
                CategoryID = 1,
                HospitalID = 101,
                StartDate = DateTime.UtcNow,
                EndDate = DateTime.UtcNow.AddDays(7),
                Image = "health_campaign.png",
                Description = "A week-long health awareness program.",
                Status = true,
                IsDeleted = false,
                CreatedBy = "Admin",
                CreatedDate = DateTime.UtcNow,
                UpdatedBy = "Admin",
                UpdatedDate = DateTime.UtcNow,
                Location = new Domain.V1.Entities.Locations.Location
                {
                    Id = 3,
                    ResourceID = "LOC-003",
                    Status = false, // Inactive
                    Name = "Emergency Center",
                    ManagingOrganization = Guid.NewGuid(),
                    PartOf = "Organization-002",
                    IsDeleted = false,
                    CreatedBy = "Admin",
                    CreatedDate = DateTime.UtcNow,
                    UpdatedBy = "Admin",
                    UpdatedDate = DateTime.UtcNow,
                    Longitude = (decimal)101.6932,
                    Latitude = (decimal)3.1453,
                    Description = "24/7 emergency response unit."
                }
            };

            var data = new GenericResponse<string>
            {
                HasError = false,
                IsSuccess = true,
                StatusCode = ResponseStatus.STATUS_SUCCESS_Create,
                Result = null,
                Message = ResponseMessage.WHATSHAPPENING_UPDATION_SUCCESS
            };

            _regionCodeValidationHelperMock
                .Setup(helper => helper.VerifyRegionCodeHeader(It.IsAny<HttpRequest>()));


            _whatsHappeningServiceMock
                .Setup(service => service.FindWhatsHappeningById(1))
                .ReturnsAsync(existingentity);

            _whatsHappeningCommandServiceMock
                .Setup(service => service.UpdateWhatsHappeningAsync(mockRequest, existingentity))
                .ReturnsAsync(data);

            // Act
            var result = await _controller.UpdateWhatsHappening(mockRequest);

            // Assert
            result.Should().NotBeNull();
            result.Should().BeOfType<OkObjectResult>();

            var okResult = result as OkObjectResult;
            okResult.Should().NotBeNull();
            okResult?.StatusCode.Should().Be(200);

            var response = okResult?.Value as GenericResponse<string>;
            response.Should().NotBeNull();
            response!.IsSuccess.Should().BeTrue();
            response.HasError.Should().BeFalse();
        }

        /// <summary>
        /// Tests that <see cref="WhatsHappeningController.GetWhatsHappeningBySearch"/> 
        /// returns an OK response when doctors are found based on the provided search filters.
        /// </summary>
        /// <remarks>
        /// - Mocks a successful response from the service with sample data.
        /// - Ensures that the region code validation helper is called.
        /// - Calls the API with search filters.
        /// - Asserts that the result is an <see cref="OkObjectResult"/> with a status code of 200.
        /// </remarks>
        [Fact]
        public async Task UpdateWhatsHappening_ShouldReturnBadRequest_WhenWhatsHappeningInvalidModelPassed()
        {
            // Arrange
            var mockRequest = new UpdateWhatsHappeningRequest
            {
                Id = 1,
                Title = "",
                URL = "https://example.com/health-awareness",
                HospitalId = 101,
                CategoryId = 1,
                Image = "https://example.com/images/health-awareness.jpg",
                StartDate = DateTime.UtcNow,
                EndDate = DateTime.UtcNow.AddHours(1),
                Description = "A campaign to raise awareness about health issues.",
                Status = true,
                RecordVersion = new byte[] { 1, 2, 3, 4 },
                IsDeleted = false
            };
            var existingentity = new Domain.V1.Entities.Marketings.WhatsHappening()
            {
                ID = 1,
                Title = "Health Awareness Campaign",
                URL = "https://hospital.org/health-campaign",
                CategoryID = 1,
                HospitalID = 101,
                StartDate = DateTime.UtcNow,
                EndDate = DateTime.UtcNow.AddDays(7),
                Image = "health_campaign.png",
                Description = "A week-long health awareness program.",
                Status = true,
                IsDeleted = false,
                CreatedBy = "Admin",
                CreatedDate = DateTime.UtcNow,
                UpdatedBy = "Admin",
                UpdatedDate = DateTime.UtcNow,
                Location = new Domain.V1.Entities.Locations.Location
                {
                    Id = 3,
                    ResourceID = "LOC-003",
                    Status = false, // Inactive
                    Name = "Emergency Center",
                    ManagingOrganization = Guid.NewGuid(),
                    PartOf = "Organization-002",
                    IsDeleted = false,
                    CreatedBy = "Admin",
                    CreatedDate = DateTime.UtcNow,
                    UpdatedBy = "Admin",
                    UpdatedDate = DateTime.UtcNow,
                    Longitude = (decimal)101.6932,
                    Latitude = (decimal)3.1453,
                    Description = "24/7 emergency response unit."
                }
            };

            var data = new GenericResponse<string>
            {
                HasError = false,
                IsSuccess = true,
                StatusCode = ResponseStatus.STATUS_SUCCESS_Create,
                Result = null,
                Message = ResponseMessage.WHATSHAPPENING_UPDATION_SUCCESS
            };
            _controller.ModelState.AddModelError("Title", "The Title field is required.");

            _regionCodeValidationHelperMock
                .Setup(helper => helper.VerifyRegionCodeHeader(It.IsAny<HttpRequest>()));


            _whatsHappeningServiceMock
                .Setup(service => service.FindWhatsHappeningById(1))
                .ReturnsAsync(existingentity);

            _whatsHappeningCommandServiceMock
                .Setup(service => service.UpdateWhatsHappeningAsync(mockRequest, existingentity))
                .ReturnsAsync(data);

            // Act
            var result = await _controller.UpdateWhatsHappening(mockRequest);

            // Assert
            result.Should().NotBeNull();
            result.Should().BeOfType<BadRequestObjectResult>();

        }

        /// <summary>
        /// Tests that <see cref="WhatsHappeningController.GetWhatsHappeningBySearch"/> 
        /// returns an OK response when doctors are found based on the provided search filters.
        /// </summary>
        /// <remarks>
        /// - Mocks a successful response from the service with sample data.
        /// - Ensures that the region code validation helper is called.
        /// - Calls the API with search filters.
        /// - Asserts that the result is an <see cref="OkObjectResult"/> with a status code of 200.
        /// </remarks>
        [Fact]
        public async Task UpdateWhatsHappening_ShouldReturnBadRequest_WhenWhatsHappeningIdNotFound()
        {
            // Arrange
            var mockRequest = new UpdateWhatsHappeningRequest
            {
                Id = 1,
                Title = "Health Awareness Campaign",
                URL = "https://example.com/health-awareness",
                HospitalId = 101,
                CategoryId = 1,
                Image = "https://example.com/images/health-awareness.jpg",
                StartDate = DateTime.UtcNow,
                EndDate = DateTime.UtcNow.AddHours(1),
                Description = "A campaign to raise awareness about health issues.",
                Status = true,
                RecordVersion = new byte[] { 1, 2, 3, 4 },
                IsDeleted = false
            };

            _regionCodeValidationHelperMock
                .Setup(helper => helper.VerifyRegionCodeHeader(It.IsAny<HttpRequest>()));


            _whatsHappeningServiceMock
                .Setup(service => service.FindWhatsHappeningById(1))
                .ReturnsAsync((Domain.V1.Entities.Marketings.WhatsHappening)null!);

            // Act
            var result = await _controller.UpdateWhatsHappening(mockRequest);

            // Assert
            result.Should().NotBeNull();
            result.Should().BeOfType<BadRequestObjectResult>();

        }

        [Fact]
        public async Task UpdateWhatsHappening_ReturnsBadRequest_WhenUpdatedFails()
        {
            // Arrange
            var mockRequest = new UpdateWhatsHappeningRequest
            {
                Id = 1,
                Title = "Health Awareness Campaign",
                URL = "https://example.com/health-awareness",
                HospitalId = 101,
                CategoryId = 1,
                Image = "https://example.com/images/health-awareness.jpg",
                StartDate = DateTime.UtcNow,
                EndDate = DateTime.UtcNow.AddHours(1),
                Description = "A campaign to raise awareness about health issues.",
                Status = true,
                RecordVersion = new byte[] { 1, 2, 3, 4 },
                IsDeleted = false
            };

            var existingentity = new Domain.V1.Entities.Marketings.WhatsHappening()
            {
                ID = 1,
                Title = "Health Awareness Campaign",
                URL = "https://hospital.org/health-campaign",
                //Category = "Health",
                CategoryID = 1,
                HospitalID = 101,
                StartDate = DateTime.UtcNow,
                EndDate = DateTime.UtcNow.AddDays(7),
                Image = "health_campaign.png",
                Description = "A week-long health awareness program.",
                Status = true,
                IsDeleted = false,
                CreatedBy = "Admin",
                CreatedDate = DateTime.UtcNow,
                UpdatedBy = "Admin",
                UpdatedDate = DateTime.UtcNow,
                Location = new Domain.V1.Entities.Locations.Location
                {
                    Id = 3,
                    ResourceID = "LOC-003",
                    Status = false, // Inactive
                    Name = "Emergency Center",
                    ManagingOrganization = Guid.NewGuid(),
                    PartOf = "Organization-002",
                    IsDeleted = false,
                    CreatedBy = "Admin",
                    CreatedDate = DateTime.UtcNow,
                    UpdatedBy = "Admin",
                    UpdatedDate = DateTime.UtcNow,
                    Longitude = (decimal)101.6932,
                    Latitude = (decimal)3.1453,
                    Description = "24/7 emergency response unit."
                }
            };

            var mockResponse = new GenericResponse<string>
            {
                IsSuccess = false,
                HasError = true,
                StatusCode = ResponseStatus.STATUS_BadRequest,
                Message = "RecordVersion mismatch. Update failed."
            };

            _regionCodeValidationHelperMock
            .Setup(helper => helper.VerifyRegionCodeHeader(It.IsAny<HttpRequest>()));


            _whatsHappeningServiceMock
                .Setup(service => service.FindWhatsHappeningById(1))
                .ReturnsAsync(existingentity);

            _whatsHappeningCommandServiceMock
                .Setup(service => service.UpdateWhatsHappeningAsync(mockRequest, existingentity))
                .ReturnsAsync(mockResponse);

            // Act
            var result = await _controller.UpdateWhatsHappening(mockRequest);

            // Assert
            result.Should().BeOfType<BadRequestObjectResult>();
            var okResult = result as BadRequestObjectResult;
            okResult?.Value.Should().BeEquivalentTo(mockResponse);
        }
        #endregion
        [Fact]
        public async Task UpdateWhatsHappening_ShouldReturnBadRequest_WhenIdIsNull()
        {
            // Arrange
            var request = new UpdateWhatsHappeningRequest
            {
                Id = null, // Simulating null ID
                RecordVersion = Array.Empty<byte>(),
                Title = "null"
            };

            // Act
            var result = await _controller.UpdateWhatsHappening(request);

            // Assert
            result.Should().BeOfType<BadRequestObjectResult>();
            var badRequestResult = result as BadRequestObjectResult;
            badRequestResult?.Value.Should().BeNull();
        }
        [Fact]
        public async Task GetCategories_ShouldReturnOk_WhenDataExists()
        {
            // Arrange
            var categories = new List<GetCategoryListDto>
        {
            new GetCategoryListDto
            {
                ID = 1,
                Code = "CAT001",
                Definition = "Category 1",
                IsDeleted = false,
                CreatedBy = "Admin",
                CreatedDate = DateTime.UtcNow
            }
        };
            _whatsHappeningServiceMock.Setup(service => service.GetCategoryList())
                        .ReturnsAsync(categories);

            // Act
            var result = await _controller.GetCategories();

            // Assert
            var okResult = result.Should().BeOfType<OkObjectResult>().Subject;
            var response = okResult.Value.Should().BeAssignableTo<GenericResponse<List<GetCategoryListDto>>>().Subject;
            response.IsSuccess.Should().BeTrue();
            response.Result.Should().HaveCount(1);
        }

        [Fact]
        public async Task GetCategories_ShouldReturnNotFound_WhenNoDataExists()
        {
            // Arrange
            _whatsHappeningServiceMock.Setup(service => service.GetCategoryList())
                        .ReturnsAsync(new List<GetCategoryListDto>());

            // Act
            var result = await _controller.GetCategories();

            // Assert
            var notFoundResult = result.Should().BeOfType<NotFoundObjectResult>().Subject;
            var response = notFoundResult.Value.Should().BeAssignableTo<GenericResponse<string>>().Subject;
            response.IsSuccess.Should().BeFalse();
            response.StatusCode.Should().Be(ResponseStatusCode.STATUS_NOTFOUND);
        }

        [Fact]
        public async Task GetCategories_ShouldReturnNotFound_WhenServiceReturnsNull()
        {
            // Arrange
            _whatsHappeningServiceMock.Setup(service => service.GetCategoryList())
                        .ReturnsAsync((List<GetCategoryListDto>)null);

            // Act
            var result = await _controller.GetCategories();

            // Assert
            var notFoundResult = result.Should().BeOfType<NotFoundObjectResult>().Subject;
            var response = notFoundResult.Value.Should().BeAssignableTo<GenericResponse<string>>().Subject;
            response.IsSuccess.Should().BeFalse();
            response.HasError.Should().BeTrue();
        }
    }
}
