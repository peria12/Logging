﻿using Aurora.AdministrationService.API.Controllers.AdminDoctor;
using Aurora.AdministrationService.API.Enum;
using Aurora.AdministrationService.API.Helper;
using Aurora.AdministrationService.API.Models.Dto.Doctor;
using Aurora.AdministrationService.API.Models.Dto.Marketing.DoctorProfile.Manage;
using Aurora.AdministrationService.API.Models.Dto.PractitionerRoles.RoleMasters;
using Aurora.AdministrationService.API.Models.Dto.Practitioners;
using Aurora.AdministrationService.API.Models.RequestModels.V1.AdminDoctor;
using Aurora.AdministrationService.API.Models.ResponseModels.Practitioners;
using Aurora.AdministrationService.API.Models.ResponseModels.V1.AdminDoctor;
using Aurora.AdministrationService.API.Models.ResponseModels.V1.AdminDoctor.Practitioners;
using Aurora.AdministrationService.API.Services.IService.AdminDoctor;
using Aurora.AdministrationService.CrossCutting.CommonModels;
using Aurora.AdministrationService.CrossCutting.Constants;
using Aurora.AdministrationService.CrossCutting.Extensions;
using FluentAssertions;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Moq;

namespace Aurora.AdministrationService.Tests.API.Controllers.V1.AdminDoctor
{

    public class AdminDoctorControllerTests
    {
        private readonly Mock<IDoctorQueryService> _doctorQueryServiceMock;
        private readonly Mock<IDoctorCommandService> _doctorCommandServiceMock;
        private readonly DoctorController _controller;
        private readonly Mock<IRegionCodeValidationHelper> _regionCodeValidationHelperMock;
        public AdminDoctorControllerTests()
        {
            _doctorQueryServiceMock = new Mock<IDoctorQueryService>();
            _doctorCommandServiceMock = new Mock<IDoctorCommandService>();
            _regionCodeValidationHelperMock = new Mock<IRegionCodeValidationHelper>();

            _controller = new DoctorController(_doctorQueryServiceMock.Object, _doctorCommandServiceMock.Object, _regionCodeValidationHelperMock.Object);

        }
        [Fact]
        public async Task GetDoctorSearchByNameAndSpeciality_ShouldReturnBadRequest_WhenRegionCodeIsInvalid()
        {
            // Arrange
            var searchQuery = "Dietitian";
            var Role = "Dietitian";
            // Create a GenericResponse with the error information
            var invalidRegionCodeResponse = new GenericResponse<string>
            {
                HasError = true,
                StatusCode = ResponseStatusCode.STATUS_BADREQUEST,// Assuming 400 as BadRequest status code
                IsSuccess = false,
            };

            // Mock the region code validation to simulate an invalid region code
            _regionCodeValidationHelperMock
                .Setup(x => x.VerifyRegionCodeHeader(It.IsAny<HttpRequest>()))
                .Returns(invalidRegionCodeResponse);

            // Act
            var result = await _controller.GetDoctorSearchByNameAndSpeciality(searchQuery, Role);

            // Assert
            result.Should().BeOfType<BadRequestObjectResult>()
                .Which.Value.Should().BeEquivalentTo(invalidRegionCodeResponse);
        }
        [Fact]
        public async Task GetDoctorSearchByNameAndSpeciality_ShouldReturnOk_WhenDoctorsFound()
        {
            // Arrange
            var searchQuery = "John";
            var Role = "Dietitian";
            var data = new GenericResponseList<AdminDoctorSearchResponse>
            {
                IsSuccess = true,
                HasError = false,
                Results = new List<AdminDoctorSearchResponse>
                {
                   new AdminDoctorSearchResponse
                   {
                        PractitionerId = 12345,
                        FirstName = "John",
                        MiddleName = "M.",
                        LastName = "Doe",
                        PractitionerRolesSearchLocation= new List<PractitionerSearchLocationResponse>
                        {
                            new PractitionerSearchLocationResponse
                            {
                                LocationId=1,
                                Speciality="dermatology",
                                Code="derma",
                                Organization="CA",
                                AddressCity="Bukit",
                                AddressState="jalil"
                            }
                        },
                        ImageUrl = "http://example.com/image.jpg"
                   },
                }
            };

            _regionCodeValidationHelperMock
                .Setup(helper => helper.VerifyRegionCodeHeader(It.IsAny<HttpRequest>()));

            _doctorQueryServiceMock
                .Setup(service => service.SearchDoctorByNameAndSpeciality(searchQuery, Role))
                 .ReturnsAsync(data);

            // Act
            var result = await _controller.GetDoctorSearchByNameAndSpeciality(searchQuery, Role);

            // Assert
            var okResult = result as OkObjectResult;
            okResult.Should().NotBeNull();
            okResult?.StatusCode.Should().Be(200);
        }

        [Fact]
        public async Task GetDoctorProfileById_ReturnsOk_WhenDoctorExists()
        {
            // Arrange
            long doctorId = 1;
            var mockResponse = new GenericResponse<PractitionerProfileResponseDto>
            {
                Result = new PractitionerProfileResponseDto
                {
                    Id = doctorId,
                    FirstName = "John",
                    LastName = "Doe",
                },
                IsSuccess = true,
                HasError = false
            };

            _doctorQueryServiceMock.Setup(s => s.GetDoctorProfile(doctorId))
                        .ReturnsAsync(mockResponse);

            // Act
            var result = await _controller.GetDoctorProfileById(doctorId);

            // Assert
            var okResult = Assert.IsType<OkObjectResult>(result);
            var response = Assert.IsType<GenericResponse<PractitionerProfileResponseDto>>(okResult.Value);
            Assert.True(response.IsSuccess);
            Assert.NotNull(response.Result);  // Ensure response.Result is not null
            Assert.Equal("John", response.Result!.FirstName);
            Assert.Equal("Doe", response.Result.LastName);
        }

        [Fact]
        public async Task GetDoctorProfileById_ReturnsNotFound_WhenDoctorDoesNotExist()
        {
            // Arrange
            long doctorId = 1;
            _doctorQueryServiceMock.Setup(s => s.GetDoctorProfile(doctorId));

            // Act
            var result = await _controller.GetDoctorProfileById(doctorId);

            // Assert
            var notFoundResult = Assert.IsType<NotFoundObjectResult>(result);
            var response = Assert.IsType<GenericResponse<PractitionerProfileResponseDto>>(notFoundResult.Value);
            Assert.True(response.HasError);
            Assert.False(response.IsSuccess);
            Assert.Equal(ResponseStatusCode.STATUS_NOTFOUND, response.StatusCode);
        }

        [Fact]
        public async Task GetDoctorSchedule_Should_Return_BadRequest_When_Invalid_RegionCode()
        {
            // Arrange
            var request = new GetDoctorScheduleRequest
            {
                PractitionerId = "1",
                LocationId = 1
            };
            var errorResponse = new GenericResponse<string> { HasError = true, Message = "Invalid Region Code" };

            _regionCodeValidationHelperMock
                .Setup(helper => helper.VerifyRegionCodeHeader(It.IsAny<HttpRequest>()))
                .Returns(errorResponse);

            // Act
            var result = await _controller.GetSchedule(request);

            // Assert
            var badRequestResult = result as BadRequestObjectResult;
            badRequestResult.Should().NotBeNull();
            badRequestResult!.StatusCode.Should().Be(400);
            badRequestResult.Value.Should().BeEquivalentTo(errorResponse);
        }

        [Fact]
        public async Task GetDoctorSchedule_Should_Return_Ok_With_Schedule_When_Valid_Request()
        {
            // Arrange
            var request = new GetDoctorScheduleRequest
            {
                PractitionerId = "1",
                LocationId = 1,
                SelectedStartDate = DateTime.UtcNow,
                SelectedEndDate = DateTime.UtcNow.AddDays(7)
            };

            var mockSchedule = new GenericResponse<AdministrationService.API.Models.ResponseModels.V1.AdminDoctor.DoctorScheduleResponse>();

            _regionCodeValidationHelperMock
                .Setup(helper => helper.VerifyRegionCodeHeader(It.IsAny<HttpRequest>()));


            _doctorQueryServiceMock
                .Setup(service => service.GetDoctorScheduleAsync(request.PractitionerId, request.LocationId, (DateTime)request.SelectedStartDate, (DateTime)request.SelectedEndDate))
                .ReturnsAsync(mockSchedule);

            // Act
            var result = await _controller.GetSchedule(request);

            // Assert
            var okResult = result as OkObjectResult;
            okResult.Should().NotBeNull();
            okResult!.StatusCode.Should().Be(200);
            okResult.Value.Should().BeEquivalentTo(mockSchedule);
        }

        [Fact]
        public async Task GetDoctorSchedule_Should_Return_Ok_With_EmptyList_When_No_Schedules_Found()
        {
            // Arrange
            var request = new GetDoctorScheduleRequest
            {
                PractitionerId = "1",
                LocationId = 1,
                SelectedStartDate = DateTime.UtcNow,
                SelectedEndDate = DateTime.UtcNow.AddDays(7)
            };

            var emptySchedule = new GenericResponse<AdministrationService.API.Models.ResponseModels.V1.AdminDoctor.DoctorScheduleResponse>();

            _regionCodeValidationHelperMock
                .Setup(helper => helper.VerifyRegionCodeHeader(It.IsAny<HttpRequest>())); // No error

            _doctorQueryServiceMock
                    .Setup(service => service.GetDoctorScheduleAsync(request.PractitionerId, request.LocationId, (DateTime)request.SelectedStartDate, (DateTime)request.SelectedEndDate))
                    .ReturnsAsync(emptySchedule);

            // Act
            var result = await _controller.GetSchedule(request);

            // Assert
            var okResult = result as OkObjectResult;
            okResult.Should().NotBeNull();
            okResult!.StatusCode.Should().Be(200);
            okResult.Value.Should().BeEquivalentTo(emptySchedule);
        }

        [Fact]
        public async Task GetDoctorSchedule_Should_Return_InternalServerError_When_ExceptionOccurs()
        {
            // Arrange
            var request = new GetDoctorScheduleRequest
            {
                PractitionerId = "1",
                LocationId = 1,
                SelectedStartDate = DateTime.UtcNow,
                SelectedEndDate = DateTime.UtcNow.AddDays(7)
            };

            _regionCodeValidationHelperMock
                .Setup(helper => helper.VerifyRegionCodeHeader(It.IsAny<HttpRequest>())); // No error

            _doctorQueryServiceMock
                .Setup(service => service.GetDoctorScheduleAsync(It.IsAny<string>(), It.IsAny<long>(), It.IsAny<DateTime>(), It.IsAny<DateTime>()))
                .ThrowsAsync(new Exception("Database error"));

            // Act
            Func<Task> act = async () => await _controller.GetSchedule(request);

            // Assert
            await act.Should().ThrowAsync<Exception>().WithMessage("Database error");
        }

        [Fact]
        public async Task GetDoctorSearchByFilter_ShouldReturnBadRequest_WhenResponseIsNull()
        {
            // Arrange
            var searchCriteria = new DoctorSearchCriteriaRequest();
            var role = "General Practitioner";

            _doctorQueryServiceMock
                .Setup(service => service.GetDoctorSearchByFilter(searchCriteria, role))
                .ReturnsAsync((List<PractitionerSearchResponse>)null);

            // Act
            var result = await _controller.GetDoctorSearchByFilter(searchCriteria, role);

            // Assert
            result.Should().BeOfType<BadRequestObjectResult>()
                .Which.Value.Should().BeEquivalentTo(new GenericResponseList<PractitionerSearchResponse>
                {
                    HasError = true,
                    IsSuccess = false,
                    StatusCode = ResponseStatusCode.STATUS_NOTFOUND,
                    Message = ResponseMessage.STATUS_NODATA,
                });
        }

        [Fact]
        public async Task GetDoctorSearchByFilter_ShouldReturnOk_WhenDoctorsAreFound()
        {
            // Arrange
            var searchCriteria = new DoctorSearchCriteriaRequest();
            var role = "Cardiologist";

            var expectedResponse = new List<PractitionerSearchResponse>
            {
                new PractitionerSearchResponse
                {
                    FirstName = "Alice",
                    LastName = "Smith",
                },
            };

            _doctorQueryServiceMock
                .Setup(service => service.GetDoctorSearchByFilter(searchCriteria, role))
                .ReturnsAsync(expectedResponse);

            // Act
            var result = await _controller.GetDoctorSearchByFilter(searchCriteria, role);

            // Assert
            var okResult = result as OkObjectResult;
            okResult.Should().NotBeNull();
            okResult?.StatusCode.Should().Be(200);
            okResult?.Value.Should().BeEquivalentTo(new GenericResponseList<PractitionerSearchResponse>
            {
                Results = expectedResponse,
                IsSuccess = true,
                HasError = false,
                Message = ResponseMessage.STATUS_SUCCESS,
                StatusCode = ResponseStatusCode.STATUS_SUCCESS
            });
        }

        [Fact]
        public async Task GetDoctorSearchByNameAndSpeciality_ShouldReturnBadRequest_WhenNoDoctorsFound()
        {
            var searchQuery = "Unknown";
            var role = "UnknownRole";
            var data = new GenericResponseList<AdminDoctorSearchResponse> { IsSuccess = true, HasError = false, Results = new List<AdminDoctorSearchResponse>() };
            _doctorQueryServiceMock.Setup(service => service.SearchDoctorByNameAndSpeciality(searchQuery, role)).ReturnsAsync(data);
            var result = await _controller.GetDoctorSearchByNameAndSpeciality(searchQuery, role);
            result.Should().BeOfType<BadRequestResult>();
        }

        [Fact]
        public async Task GetDoctorSearchByNameAndSpeciality_ShouldHandleException()
        {
            var searchQuery = "Error";
            var role = "ErrorRole";
            _doctorQueryServiceMock.Setup(service => service.SearchDoctorByNameAndSpeciality(It.IsAny<string>(), It.IsAny<string>())).ThrowsAsync(new Exception("Database error"));
            Func<Task> act = async () => await _controller.GetDoctorSearchByNameAndSpeciality(searchQuery, role);
            await act.Should().ThrowAsync<Exception>().WithMessage("Database error");
        }

        #region Get Practitioner Profile controller test cases

        [Fact]
        public async Task GetPractitionerInfo_ShouldReturnBadRequest_WhenRegionCodeIsInvalid()
        {
            // Arrange
            long Id = 4;
            // Create a GenericResponse with the error information
            var invalidRegionCodeResponse = new GenericResponse<string>
            {
                HasError = true,
                StatusCode = ResponseStatusCode.STATUS_BADREQUEST,// Assuming 400 as BadRequest status code
                IsSuccess = false,
            };

            // Mock the region code validation to simulate an invalid region code
            _regionCodeValidationHelperMock
                .Setup(x => x.VerifyRegionCodeHeader(It.IsAny<HttpRequest>()))
                .Returns(invalidRegionCodeResponse);

            // Act
            var result = await _controller.GetPractitionerInfo(Id);

            // Assert
            result.Should().BeOfType<BadRequestObjectResult>()
                .Which.Value.Should().BeEquivalentTo(invalidRegionCodeResponse);
        }

        [Fact]
        public async Task GetPractitionerInfo_Should_ReturnNotFound_When_NoDoctor_Found()
        {
            // Arrange
            long Id = 4;
            var notFoundResponse = new GenericResponse<GetPractitionerInfoDto>
            {
                HasError = true,
                IsSuccess = false,
                StatusCode = ResponseStatusCode.STATUS_NOTFOUND,
                Message = ResponseMessage.STATUS_NODATA
            };

            _regionCodeValidationHelperMock
                .Setup(helper => helper.VerifyRegionCodeHeader(It.IsAny<HttpRequest>())); // No error

            _doctorQueryServiceMock
                    .Setup(service => service.GetPractitionerInfo(Id))
                    .ReturnsAsync((GetPractitionerInfoDto)null);

            // Act
            var result = await _controller.GetPractitionerInfo(Id);

            // Assert
            var NotfoundResult = result as NotFoundObjectResult;
            NotfoundResult.Should().NotBeNull();
            NotfoundResult!.StatusCode.Should().Be(404);
            NotfoundResult.Value.Should().BeEquivalentTo(notFoundResponse);
        }

        [Fact]
        public async Task GetPractitionerInfo_Should_ReturnOk_When_Doctor_Found()
        {
            // Arrange
            long Id = 4;
            var FoundResponse = new GenericResponse<GetPractitionerInfoDto>
            {
                Result = new GetPractitionerInfoDto(),
                IsSuccess = true,
                HasError = false,
                Message = ResponseMessage.STATUS_SUCCESS,
                StatusCode = ResponseStatusCode.STATUS_SUCCESS
            };

            _regionCodeValidationHelperMock
                .Setup(helper => helper.VerifyRegionCodeHeader(It.IsAny<HttpRequest>())); // No error

            _doctorQueryServiceMock
                    .Setup(service => service.GetPractitionerInfo(Id))
                    .ReturnsAsync(new GetPractitionerInfoDto());

            // Act
            var result = await _controller.GetPractitionerInfo(Id);

            // Assert
            var okfoundResult = result as OkObjectResult;
            okfoundResult.Should().NotBeNull();
            okfoundResult!.StatusCode.Should().Be(200);
            okfoundResult.Value.Should().BeEquivalentTo(FoundResponse);
        }

        #endregion
        [Fact]
        public async Task GetDoctorList_ShouldReturnBadRequest_WhenRegionCodeIsInvalid()
        {
            // Arrange
            var query = new DoctorListRequest
            {
                Pagination = new PaginationQuery { PageSize = 10, PageNumber = 1 }
            };

            var invalidRegionCodeResponse = new GenericResponse<string>
            {
                HasError = true,
                StatusCode = ResponseStatusCode.STATUS_BADREQUEST,
                IsSuccess = false
            };

            _regionCodeValidationHelperMock
                .Setup(x => x.VerifyRegionCodeHeader(It.IsAny<HttpRequest>()))
                .Returns(invalidRegionCodeResponse);

            // Act
            var result = await _controller.GetDoctorList(query);

            // Assert
            result.Should().BeOfType<BadRequestObjectResult>()
                .Which.Value.Should().BeEquivalentTo(invalidRegionCodeResponse);
        }

        [Fact]
        public async Task GetDoctorList_ShouldReturnOk_WhenDoctorsFound()
        {
            // Arrange
            var query = new DoctorListRequest
            {
                Pagination = new PaginationQuery { PageSize = 10, PageNumber = 1 }
            };

            var doctorList = new GenericResponseList<DoctorListDto>
            {
                IsSuccess = true,
                HasError = false,
                Results = new List<DoctorListDto>
        {
            new DoctorListDto { ID = 1, GivenName = "John Doe" }
        },
                TotalCount = 1,
                PageSize = 10,
                CurrentPage = 1
            };

            _regionCodeValidationHelperMock
                .Setup(helper => helper.VerifyRegionCodeHeader(It.IsAny<HttpRequest>()))
                .Returns((GenericResponse<string>)null); // No error, so it should return null

            _doctorQueryServiceMock
                .Setup(service => service.GetDoctorList(It.IsAny<DoctorListRequest>()))
                .ReturnsAsync(doctorList);

            // Act
            var result = await _controller.GetDoctorList(query);

            // Assert
            var okResult = result as OkObjectResult;
            okResult.Should().NotBeNull();
            okResult?.StatusCode.Should().Be(200);
            okResult?.Value.Should().BeEquivalentTo(doctorList);
        }

        #region GetDoctorList 
        [Fact]
        public async Task GetPractitionerList_ShouldReturnBadRequest_WhenRegionCodeIsInvalid()
        {
            // Arrange
            // Create a GenericResponse with the error information
            var invalidRegionCodeResponse = new GenericResponse<string>
            {
                HasError = true,
                StatusCode = ResponseStatusCode.STATUS_BADREQUEST,// Assuming 400 as BadRequest status code
                IsSuccess = false,
            };

            // Mock the region code validation to simulate an invalid region code
            _regionCodeValidationHelperMock
                .Setup(x => x.VerifyRegionCodeHeader(It.IsAny<HttpRequest>()))
                .Returns(invalidRegionCodeResponse);

            // Act
            var result = await _controller.GetPractitioners();

            // Assert
            result.Should().BeOfType<BadRequestObjectResult>()
                .Which.Value.Should().BeEquivalentTo(invalidRegionCodeResponse);
        }

        [Fact]
        public async Task GetDoctorsList_ResponseIsNull_ReturnsNotFound()
        {
            // Arrange
            _regionCodeValidationHelperMock
                .Setup(helper => helper.VerifyRegionCodeHeader(It.IsAny<HttpRequest>()))
                .Returns((GenericResponse<string>)null); // No error, so it should return null

            // Act
            var result = await _controller.GetPractitioners();

            // Assert
            var notFoundResult = result as NotFoundObjectResult;
            var response = notFoundResult.Value as GenericResponseList<GetPractitionerListDto>;
            response.HasError.Should().BeTrue();
            response.IsSuccess.Should().BeFalse();
            response.StatusCode.Should().Be(ResponseStatusCode.STATUS_NOTFOUND);
            response.Message.Should().Be(ResponseMessage.STATUS_NODATA);
        }

        [Fact]
        public async Task GetDoctorsList_ResponseIsNotSuccess_ReturnsNotFound()
        {
            // Arrange
            _regionCodeValidationHelperMock
                .Setup(helper => helper.VerifyRegionCodeHeader(It.IsAny<HttpRequest>()))
                .Returns((GenericResponse<string>)null); // No error, so it should return null

            // Act
            var result = await _controller.GetPractitioners();

            // Assert
            var notFoundResult = result as NotFoundObjectResult;
            Assert.NotNull(notFoundResult);
            var response = notFoundResult.Value as GenericResponseList<GetPractitionerListDto>;
            response.HasError.Should().BeTrue();
            response.IsSuccess.Should().BeFalse();
            response.StatusCode.Should().Be(ResponseStatusCode.STATUS_NOTFOUND);
            response.Message.Should().Be(ResponseMessage.STATUS_NODATA);
        }

        [Fact]
        public async Task GetDoctorsList_ResponseIsSuccess_ReturnsOk()
        {
            // Arrange
            var expectedResults = new List<GetPractitionerListDto>
            {
                new GetPractitionerListDto { Id = 1, FamilyName = "FN", GivenName = "GN", MiddleName ="MN", ResourceId ="PRACT125" },
                new GetPractitionerListDto { Id = 2, FamilyName = "FN1", GivenName = "GN1", MiddleName ="MN1", ResourceId ="PRACT250"  }
            };

            var response = new GenericResponseList<GetPractitionerListDto>
            {
                Results = expectedResults,
                IsSuccess = true,
                HasError = false,
                Message = ResponseMessage.STATUS_SUCCESS,
                StatusCode = ResponseStatusCode.STATUS_SUCCESS
            };

            _doctorQueryServiceMock.Setup(service => service.GetDoctors())
                 .ReturnsAsync(response);

            // Act
            var result = await _controller.GetPractitioners();

            // Assert
            var okResult = result as OkObjectResult;
            var responseResult = okResult.Value as GenericResponseList<GetPractitionerListDto>;
            responseResult.HasError.Should().BeFalse();
            responseResult.IsSuccess.Should().BeTrue();
            responseResult.StatusCode.Should().Be(ResponseStatusCode.STATUS_SUCCESS);
            responseResult.Message.Should().Be(ResponseMessage.STATUS_SUCCESS);
        }
        #endregion

        #region DoctorDetailsById
        [Fact]
        public async Task GetDoctorDetailsById_ShouldReturnBadRequest_WhenRegionCodeIsInvalid()
        {
            // Arrange
            // Create a GenericResponse with the error information
            var invalidRegionCodeResponse = new GenericResponse<string>
            {
                HasError = true,
                StatusCode = ResponseStatusCode.STATUS_BADREQUEST,// Assuming 400 as BadRequest status code
                IsSuccess = false,
            };

            // Mock the region code validation to simulate an invalid region code
            _regionCodeValidationHelperMock
                .Setup(x => x.VerifyRegionCodeHeader(It.IsAny<HttpRequest>()))
                .Returns(invalidRegionCodeResponse);

            // Act
            var result = await _controller.GetDoctorDetailsById(1);

            // Assert
            result.Should().BeOfType<BadRequestObjectResult>()
                .Which.Value.Should().BeEquivalentTo(invalidRegionCodeResponse);
        }

        [Fact]
        public async Task GetDoctorDetailsById_ResponseIsSuccess_ReturnsOk()
        {
            // Arrange
            var practitionerLocationList = new List<GetPractitionerLocationListDto>
            {
                new GetPractitionerLocationListDto { Id=1, ResourceId  ="PRACT121", Name ="GN" }
            };

            var practitionerSpecialtyList = new List<GetPractitionerSpecialtyListDto>
            {
                new GetPractitionerSpecialtyListDto { LocationId = "BRIM", PractitionerRoleId =1,  Specialty ="Cardio" }
            };

            var expectedResults = new List<GetDoctorDetailsDto>
            {
                new GetDoctorDetailsDto { Id = 1, Code ="Doctor", ResourceId = "PRACT121", PractitionerLocation = practitionerLocationList, PractitionerSpeciality =practitionerSpecialtyList  },
                new GetDoctorDetailsDto { Id = 2, Code ="Doctor", ResourceId = "PRACT122",  }
            };

            var response = new GenericResponseList<GetDoctorDetailsDto>
            {
                Results = expectedResults,
                IsSuccess = true,
                HasError = false,
                Message = ResponseMessage.STATUS_SUCCESS,
                StatusCode = ResponseStatusCode.STATUS_SUCCESS
            };

            _doctorQueryServiceMock.Setup(service => service.GetDoctorDetailsById(1))
                 .ReturnsAsync(response);

            // Act
            var result = await _controller.GetDoctorDetailsById(1);

            // Assert
            var okResult = result as OkObjectResult;
            var responseResult = okResult.Value as GenericResponseList<GetDoctorDetailsDto>;
            responseResult.HasError.Should().BeFalse();
            responseResult.IsSuccess.Should().BeTrue();
            responseResult.StatusCode.Should().Be(ResponseStatusCode.STATUS_SUCCESS);
            responseResult.Message.Should().Be(ResponseMessage.STATUS_SUCCESS);
        }
        #endregion

        #region GetTimeZoneList 
        [Fact]
        public void GetTimeZoneList_ShouldReturnBadRequest_WhenRegionCodeIsInvalid()
        {
            // Arrange
            // Create a GenericResponse with the error information
            var invalidRegionCodeResponse = new GenericResponse<string>
            {
                HasError = true,
                StatusCode = ResponseStatusCode.STATUS_BADREQUEST,// Assuming 400 as BadRequest status code
                IsSuccess = false,
            };

            // Mock the region code validation to simulate an invalid region code
            _regionCodeValidationHelperMock
                .Setup(x => x.VerifyRegionCodeHeader(It.IsAny<HttpRequest>()))
                .Returns(invalidRegionCodeResponse);

            // Act
            var result = _controller.GetTimeZones();

            // Assert
            var badRequestResult = result.Result as BadRequestObjectResult;
            badRequestResult?.Value.Should().BeEquivalentTo(invalidRegionCodeResponse);
        }


        [Fact]
        public void GetTimeZoneList_ServiceReturnsNull_ReturnsNotFound()
        {
            // Arrange

            _regionCodeValidationHelperMock.Setup(x => x.VerifyRegionCodeHeader(It.IsAny<HttpRequest>()));
            _doctorQueryServiceMock.Setup(x => x.GetTimeZones()).Returns((GenericResponseList<GetPractitionerTimeZoneDto>)null);

            // Act
            var result = _controller.GetTimeZones();

            // Assert
            var notFoundResult = result.Result as NotFoundObjectResult;
            var response = notFoundResult.Value as GenericResponseList<GetPractitionerTimeZoneDto>;
            response.HasError.Should().BeTrue();
            response.IsSuccess.Should().BeFalse();
            response.StatusCode.Should().Be(ResponseStatusCode.STATUS_NOTFOUND);
            response.Message.Should().Be(ResponseMessage.STATUS_NODATA);
        }

        [Fact]
        public void GetTimeZoneList_ResponseIsSuccess_ReturnsOk()
        {
            // Arrange
            var expectedResults = new List<GetPractitionerTimeZoneDto>
            {
                new GetPractitionerTimeZoneDto { Id = 1, TimeZoneName = string.Format("{0}/{1}", AppConstants.ContinentName, AppConstants.MYSRegionCode) },
            };

            var timeZoneResponse = new GenericResponseList<GetPractitionerTimeZoneDto>
            {
                Results = expectedResults,
                IsSuccess = true,
                HasError = false,
                Message = ResponseMessage.STATUS_SUCCESS,
                StatusCode = ResponseStatusCode.STATUS_SUCCESS
            };

            _doctorQueryServiceMock.Setup(service => service.GetTimeZones())
                 .Returns(timeZoneResponse);

            // Act
            var result = _controller.GetTimeZones();

            // Assert
            var okResult = result.Result as OkObjectResult;
            var response = okResult.Value as GenericResponseList<GetPractitionerTimeZoneDto>;
            response.HasError.Should().BeFalse();
            response.IsSuccess.Should().BeTrue();
            response.StatusCode.Should().Be(ResponseStatusCode.STATUS_SUCCESS);
            response.Message.Should().Be(ResponseMessage.STATUS_SUCCESS);
        }
        #endregion

        [Fact]
        public async Task GetPractitionerCode_ShouldReturnOk_WhenValidPractitionerIdAndRegionCode()
        {
            // Arrange
            long id = 1;
            var mockResponse = new GenericResponseList<GetRoleMasterDetailDto>
            {
                Results = new List<GetRoleMasterDetailDto>
                {
                new GetRoleMasterDetailDto
                {
                    Code = "Test",
                    Id = 1
                },
                     new GetRoleMasterDetailDto
                        {
                    Code = "Demo",
                    Id = 2
                    }
                 },
                IsSuccess = true,
                HasError = false,
                StatusCode = ResponseStatusCode.STATUS_SUCCESS,
                Message = ResponseMessage.STATUS_SUCCESS
            };

            // Mock region code validation to return no error
            _regionCodeValidationHelperMock
                .Setup(m => m.VerifyRegionCodeHeader(It.IsAny<HttpRequest>()))
                .Returns((GenericResponse<string>)null); // No error

            // Mock doctor query service to return mockResponse
            _doctorQueryServiceMock
                .Setup(m => m.GetPractitionerCode(It.IsAny<long>()))
                .ReturnsAsync(mockResponse);

            // Act
            var result = await _controller.GetPractitionerCode(id);

            // Assert
            var okResult = Assert.IsType<OkObjectResult>(result);
            var returnValue = Assert.IsType<GenericResponseList<GetRoleMasterDetailDto>>(okResult.Value);
            Assert.NotNull(returnValue);
            Assert.Matches(returnValue.Results.First().Code, mockResponse.Results.First().Code);
        }

        [Fact]
        public async Task GetPractitionerCode_ShouldReturnBadRequest_WhenRegionCodeIsInvalid()
        {
            // Arrange
            long id = 1;
            var invalidResponse = new GenericResponse<string>
            {
                HasError = true,
                Message = "Invalid region code header"
            };

            _regionCodeValidationHelperMock
                .Setup(helper => helper.VerifyRegionCodeHeader(It.IsAny<HttpRequest>()))
                .Returns(invalidResponse);

            // Act
            var result = await _controller.GetPractitionerCode(id);

            // Assert
            var badRequestResult = Assert.IsType<BadRequestObjectResult>(result);
            var response = Assert.IsType<GenericResponse<string>>(badRequestResult.Value);
            Assert.True(response.HasError);
            Assert.Equal("Invalid region code header", response.Message);
        }

        [Fact]
        public async Task GetPractitionerInfo_ShouldReturnBadRequest_WhenRegionCodeIsInvalidTest()
        {
            // Arrange
            var invalidResponse = new GenericResponse<string> { HasError = true };
            _regionCodeValidationHelperMock.Setup(x => x.VerifyRegionCodeHeader(It.IsAny<HttpRequest>()))
                .Returns(invalidResponse);

            // Act
            var result = await _controller.GetPractitionerInfo(1);

            // Assert
            result.Should().BeOfType<BadRequestObjectResult>()
                .Which.Value.Should().BeEquivalentTo(invalidResponse);
        }

        [Fact]
        public async Task GetPractitionerInfo_ShouldReturnNotFound_WhenPractitionerDoesNotExist()
        {
            // Arrange
            _regionCodeValidationHelperMock.Setup(x => x.VerifyRegionCodeHeader(It.IsAny<HttpRequest>()))
                .Returns((GenericResponse<string>)null);

            _doctorQueryServiceMock.Setup(x => x.GetPractitionerInfo(It.IsAny<long>()))
                .ReturnsAsync((GetPractitionerInfoDto)null);

            // Act
            var result = await _controller.GetPractitionerInfo(1);

            // Assert
            result.Should().BeOfType<NotFoundObjectResult>();
        }

        [Fact]
        public async Task GetPractitionerInfo_ShouldReturnOk_WhenPractitionerExists()
        {
            // Arrange
            var dto = new GetPractitionerInfoDto();
            _regionCodeValidationHelperMock.Setup(x => x.VerifyRegionCodeHeader(It.IsAny<HttpRequest>()))
                .Returns((GenericResponse<string>)null);

            _doctorQueryServiceMock.Setup(x => x.GetPractitionerInfo(It.IsAny<long>()))
                .ReturnsAsync(dto);

            // Act
            var result = await _controller.GetPractitionerInfo(1);

            // Assert
            var okResult = result.Should().BeOfType<OkObjectResult>().Subject;
            var response = okResult.Value.Should().BeAssignableTo<GenericResponse<GetPractitionerInfoDto>>().Subject;
            response.IsSuccess.Should().BeTrue();
            response.HasError.Should().BeFalse();
            response.Result.Should().Be(dto);
        }

        [Fact]
        public async Task UpdatePractitionerInfo_ShouldReturnBadRequest_WhenRegionCodeIsInvalid()
        {
            // Arrange
            var request = new UpdatePractitionerInfoRequest { PractitionerId = 1 };
            var invalidResponse = new GenericResponse<string> { HasError = true };

            _regionCodeValidationHelperMock.Setup(x => x.VerifyRegionCodeHeader(It.IsAny<HttpRequest>()))
                .Returns(invalidResponse);

            // Act
            var result = await _controller.UpdatePractitionerInfo(1, request);

            // Assert
            result.Should().BeOfType<BadRequestObjectResult>()
                .Which.Value.Should().BeEquivalentTo(invalidResponse);
        }

        [Fact]
        public async Task UpdatePractitionerInfo_ShouldReturnBadRequest_WhenIdMismatch()
        {
            // Arrange
            var request = new UpdatePractitionerInfoRequest { PractitionerId = 2 };
            _regionCodeValidationHelperMock.Setup(x => x.VerifyRegionCodeHeader(It.IsAny<HttpRequest>()))
                .Returns((GenericResponse<string>)null);

            // Act
            var result = await _controller.UpdatePractitionerInfo(1, request);

            // Assert
            result.Should().BeOfType<BadRequestObjectResult>();
        }

        [Fact]
        public async Task UpdatePractitionerInfo_ShouldReturnNotFound_WhenPractitionerNotFound()
        {
            // Arrange
            var request = new UpdatePractitionerInfoRequest { PractitionerId = 1 };
            _regionCodeValidationHelperMock.Setup(x => x.VerifyRegionCodeHeader(It.IsAny<HttpRequest>()))
                .Returns((GenericResponse<string>)null);

            _doctorQueryServiceMock.Setup(x => x.GetPractitionerInfo(It.IsAny<long>()))
                .ReturnsAsync((GetPractitionerInfoDto)null);

            // Act
            var result = await _controller.UpdatePractitionerInfo(1, request);

            // Assert
            result.Should().BeOfType<NotFoundObjectResult>();
        }

        [Fact]
        public async Task UpdatePractitionerInfo_ShouldReturnOk_WhenUpdateSucceeds()
        {
            // Arrange
            var request = new UpdatePractitionerInfoRequest { PractitionerId = 1 };
            var practitioner = new GetPractitionerInfoDto();

            _regionCodeValidationHelperMock.Setup(x => x.VerifyRegionCodeHeader(It.IsAny<HttpRequest>()))
                .Returns((GenericResponse<string>)null);

            _doctorQueryServiceMock.Setup(x => x.GetPractitionerInfo(It.IsAny<long>()))
                .ReturnsAsync(practitioner);

            _doctorCommandServiceMock.Setup(x => x.UpdatePractitionerInfo(request))
                .ReturnsAsync(true);

            // Act
            var result = await _controller.UpdatePractitionerInfo(1, request);

            // Assert
            var okResult = result.Should().BeOfType<OkObjectResult>().Subject;
            var response = okResult.Value.Should().BeAssignableTo<GenericResponse<GetPractitionerInfoDto>>().Subject;
            response.IsSuccess.Should().BeTrue();
            response.HasError.Should().BeFalse();
        }

        [Fact]
        public async Task UpdatePractitionerInfo_ShouldReturnInternalServerError_WhenUpdateFails()
        {
            // Arrange
            var request = new UpdatePractitionerInfoRequest { PractitionerId = 1 };
            var practitioner = new GetPractitionerInfoDto();

            _regionCodeValidationHelperMock.Setup(x => x.VerifyRegionCodeHeader(It.IsAny<HttpRequest>()))
                .Returns((GenericResponse<string>)null);

            _doctorQueryServiceMock.Setup(x => x.GetPractitionerInfo(It.IsAny<long>()))
                .ReturnsAsync(practitioner);

            _doctorCommandServiceMock.Setup(x => x.UpdatePractitionerInfo(request))
                .ReturnsAsync(false);

            // Act
            var result = await _controller.UpdatePractitionerInfo(1, request);

            // Assert
            result.Should().BeOfType<ObjectResult>().Which.StatusCode.Should().Be(StatusCodes.Status500InternalServerError);
        }

        [Fact]
        public async Task GetPractitionerNames_IdIsZero_ReturnsBadRequest()
        {
            // Arrange
            int invalidId = 0;

            _regionCodeValidationHelperMock
                .Setup(x => x.VerifyRegionCodeHeader(It.IsAny<HttpRequest>()))
                .Returns((GenericResponse<string>)null); // Simulate valid region

            // Act
            var result = await _controller.GetPractitionerNames(invalidId);

            // Assert
            var badRequestResult = result.Should().BeOfType<BadRequestObjectResult>().Subject;

            badRequestResult.StatusCode.Should().Be((int)ResponceStatusCode.BadRequest);

            var response = badRequestResult.Value.Should().BeOfType<GenericResponseList<GetRoleMasterDetailDto>>().Subject;

            response.IsSuccess.Should().BeFalse();
            response.HasError.Should().BeTrue();
            response.Results.Should().BeNull();
            response.StatusCode.Should().Be(((int)ResponceStatusCode.BadRequest).ToString());
            response.Message.Should().Be(ResponseMessage.STATUS_BAD_REQUEST);
        }

        [Fact]
        public async Task GetDoctorProfileDetails_ShouldReturnNotFound_WhenDoctorNotFound()
        {
            // Arrange
            var practitionerId = 2L;

            _doctorQueryServiceMock
                .Setup(service => service.GetDoctorProfileDetails(practitionerId))
                .ReturnsAsync((GenericResponse<DoctorProfileDetailsDto>)null!);

            // Act
            var result = await _controller.GetDoctorProfileDetails(practitionerId);

            // Assert
            result.Should().BeOfType<NotFoundObjectResult>();
            var notFoundResult = result as NotFoundObjectResult;
            notFoundResult!.StatusCode.Should().Be(404);
            var response = notFoundResult.Value.Should().BeOfType<GenericResponse<DoctorProfileDetailsDto>>().Subject;
            response.HasError.Should().BeTrue();
            response.IsSuccess.Should().BeFalse();
            response.Message.Should().Be(ResponseMessage.STATUS_NODATA);
        }

        [Fact]
        public async Task GetDoctorProfileDetails_ShouldReturnOk_WhenDoctorIsFound()
        {
            // Arrange
            long practitionerId = 1L;
            var expectedDto = new DoctorProfileDetailsDto
            {
                Id = 1,
                URL = "https://image.url/photo.jpg",
                Prefix = "Dr.",
                Suffix = "MD",
                GivenName = "Jane",
                FamilyName = "Smith",
                Description = "Cardiologist with 10+ years of experience",
                ManageDoctorProfileId = 1001,
                ResourceId = "res123",
                PractitionerRoleId = 5001,
                PractitionerId = "pract123",
                PractitionerCommunications = "en, es",
                Interests = "Medical Research, Teaching",
                ExperienceDetails = new List<ExperienceDetailsDto>
        {
            new ExperienceDetailsDto
            {
                JobDurationFrom = new DateTime(2020, 1, 1),
                JobDurationTo = new DateTime(2022, 12, 31),
                Designation = "Senior Cardiologist",
                Organization = "HeartCare Hospital",
                Location = "NYC",
                CurrentlyWorkingHere = false
            }
        },
                EducationalQualifications = new List<EducationalQualificationDto>
        {
            new EducationalQualificationDto
            {
                EducationalDegree = "MBBS",
                Institute = "Harvard Medical School",
                YearOfPassing = 2010
            }
        },
                SectionDetails = new List<SectionDto>
        {
            new SectionDto
            {
                Title = "Cardiology",
                Description = "Expert in treating heart-related conditions."
            },
            new SectionDto
            {
                Title = "Neurology",
                Description = "Specialized in nervous system disorders."
            }
        },
                OrganizationDetails = new List<DoctorOrganizationDto>
        {
            new DoctorOrganizationDto
            {
                Id = 5,
                LocationName = "HeartCare Hospital - NYC",
                OrganizationName = "HeartCare",
                Alias = "HC",
                City = "New York",
                Specialties = "Cardiology, Internal Medicine",
                Longitude = -73.935242m,
                Latitude = 40.730610m,
                Altitude = 30.5m,
                ScheduleStartDate = new DateTime(2025, 05, 01),
                ScheduleEndDate = new DateTime(2025, 12, 31),
                NextAvailability = "2025-04-28",
                PractitionerRoleId = 5001
            }
        }
            };

            var expectedResponse = new GenericResponse<DoctorProfileDetailsDto>
            {
                Result = expectedDto,
                IsSuccess = true,
                HasError = false,
                StatusCode = ResponseStatusCode.STATUS_SUCCESS,
                Message = ResponseMessage.STATUS_SUCCESS
            };

            _doctorQueryServiceMock
                .Setup(service => service.GetDoctorProfileDetails(practitionerId))
                .ReturnsAsync(expectedResponse);

            // Act
            var result = await _controller.GetDoctorProfileDetails(practitionerId);

            // Assert
            result.Should().BeOfType<OkObjectResult>();
            var okResult = result as OkObjectResult;
            okResult!.StatusCode.Should().Be(200);

            var response = okResult.Value.Should().BeOfType<GenericResponse<DoctorProfileDetailsDto>>().Subject;
            response.IsSuccess.Should().BeTrue();
            response.HasError.Should().BeFalse();
            response.StatusCode.Should().Be(ResponseStatusCode.STATUS_SUCCESS);
            response.Message.Should().Be(ResponseMessage.STATUS_SUCCESS);
            response.Result.Should().BeEquivalentTo(expectedDto);
        }

        [Fact]
        public async Task GetDoctorProfileDetails_ShouldReturnOk_WithPartialDoctorData()
        {
            // Arrange
            var practitionerId = 1L; // Now string, to match updated DTO

            var partialDto = new DoctorProfileDetailsDto
            {
                Id = 3,
                URL = "https://img.url/partial.jpg",
                Prefix = "Dr.",
                Suffix = "",
                GivenName = "Mark",
                FamilyName = "Lee",
                Description = "General Practitioner",
                ManageDoctorProfileId = 301,
                ResourceId = "res789",
                PractitionerRoleId = 9001,
                PractitionerId = "pract006",
                PractitionerCommunications = "English,Hindi",

                ExperienceDetails = new List<ExperienceDetailsDto>(), 
                EducationalQualifications = new List<EducationalQualificationDto>
        {
            new EducationalQualificationDto
            {
                EducationalDegree = "MBBS",
                Institute = "Stanford University",
                YearOfPassing = 2015
            }
        },
                Interests = "Reading,Swimming", 
                SectionDetails = new List<SectionDto>
        {
            new SectionDto
            {
                Title = "Cardiology",
                Description = "Expert in treating heart-related conditions."
            },
            new SectionDto
            {
                Title = "Neurology",
                Description = "Specialized in nervous system disorders."
            }
        },
                OrganizationDetails = new List<DoctorOrganizationDto>
        {
            new DoctorOrganizationDto
            {
                Id= 7,
                LocationName = "Stanford Clinic",
                OrganizationName = "Stanford Health",
                Alias = "SH",
                City = "Palo Alto",
                Specialties = "cardio,physiotheripist",
                Longitude = -122.143019m,
                Latitude = 37.441883m,
                Altitude = 30.0m,
                ScheduleStartDate = new DateTime(2025, 05, 01),
                ScheduleEndDate = new DateTime(2025, 12, 31),
                NextAvailability = null,
                PractitionerRoleId = 9001
            }
        }
            };

            var expectedResponse = new GenericResponse<DoctorProfileDetailsDto>
            {
                Result = partialDto,
                IsSuccess = true,
                HasError = false,
                StatusCode = ResponseStatusCode.STATUS_SUCCESS,
                Message = ResponseMessage.STATUS_SUCCESS
            };

            _doctorQueryServiceMock
                .Setup(service => service.GetDoctorProfileDetails(practitionerId))
                .ReturnsAsync(expectedResponse);

            // Act
            var result = await _controller.GetDoctorProfileDetails(practitionerId);

            // Assert
            result.Should().BeOfType<OkObjectResult>();
            var okResult = result as OkObjectResult;
            okResult!.Value.Should().BeEquivalentTo(expectedResponse);
        }



        [Fact]
        public async Task GetDoctorSearchField_ShouldReturnBadRequest_WhenRegionCodeIsInvalid()
        {
            // Arrange
            // Create a GenericResponse with the error information
            var invalidRegionCodeResponse = new GenericResponse<string>
            {
                HasError = true,
                StatusCode = ResponseStatusCode.STATUS_BADREQUEST,// Assuming 400 as BadRequest status code
                IsSuccess = false,
            };

            // Mock the region code validation to simulate an invalid region code
            _regionCodeValidationHelperMock
                .Setup(x => x.VerifyRegionCodeHeader(It.IsAny<HttpRequest>()))
                .Returns(invalidRegionCodeResponse);

            // Act
            var result = await _controller.GetDoctorSearchField(null);

            // Assert
            result.Should().BeOfType<BadRequestObjectResult>()
                .Which.Value.Should().BeEquivalentTo(invalidRegionCodeResponse);
        }
        
        [Fact]
        public async Task GetDoctorSearchField_ShouldReturnOk_WhenDoctorsFound()
        {
            var expectedResults = new List<DoctorSearchResponseDto>
            {
                new DoctorSearchResponseDto { Id = 1, FirstName = "FN", LastName = "GN", MiddleName ="MN" },
                   
                new DoctorSearchResponseDto { Id = 2, FirstName = "FN1", LastName = "GN1", MiddleName ="MN1" }
            };

            var response = new GenericResponseList<DoctorSearchResponseDto>
            {
                Results = expectedResults,
                IsSuccess = true,
                HasError = false,
                Message = ResponseMessage.STATUS_SUCCESS,
                StatusCode = ResponseStatusCode.STATUS_SUCCESS
            };

            _regionCodeValidationHelperMock
                .Setup(helper => helper.VerifyRegionCodeHeader(It.IsAny<HttpRequest>()))
                .Returns((GenericResponse<string>)null); // No error, so it should return null

            _doctorQueryServiceMock.Setup(service => service.GetDoctorSearchList(null))
                 .ReturnsAsync(response);

            // Act
            var result = await _controller.GetDoctorSearchField(null);

            // Assert
            var okResult = result as OkObjectResult;
            var responseResult = okResult.Value as GenericResponseList<DoctorSearchResponseDto>;
            responseResult.HasError.Should().BeFalse();
            responseResult.IsSuccess.Should().BeTrue();
            responseResult.StatusCode.Should().Be(ResponseStatusCode.STATUS_SUCCESS);
            responseResult.Message.Should().Be(ResponseMessage.STATUS_SUCCESS);
        }

        [Fact]
        public async Task GetDoctorSearchField_ShouldReturnOk_WhenNoDoctorsFound()
        {
            var expectedResults = new List<DoctorSearchResponseDto>();

            var response = new GenericResponseList<DoctorSearchResponseDto>
            {
                Results = expectedResults,
                IsSuccess = false,
                HasError = true,
                Message = ResponseMessage.STATUS_NODATA,
                StatusCode = ResponseStatusCode.STATUS_NOTFOUND
            };

            _regionCodeValidationHelperMock
                .Setup(helper => helper.VerifyRegionCodeHeader(It.IsAny<HttpRequest>()))
                .Returns((GenericResponse<string>)null); // No error, so it should return null

            _doctorQueryServiceMock.Setup(service => service.GetDoctorSearchList(null))
                 .ReturnsAsync(response);

            // Act
            var result = await _controller.GetDoctorSearchField(null);

            // Assert
            var okResult = result as NotFoundObjectResult;
            var responseResult = okResult.Value as GenericResponse<string>;
            responseResult.HasError.Should().BeTrue();
            responseResult.IsSuccess.Should().BeFalse();
            responseResult.StatusCode.Should().Be(ResponseStatusCode.STATUS_NOTFOUND);
            responseResult.Message.Should().Be(ResponseMessage.STATUS_NODATA);
        }
            //// Assert
            //result.Should().BeOfType<OkObjectResult>();
            //var okResult = result as OkObjectResult;
            //okResult!.StatusCode.Should().Be(200);

            //var response = okResult.Value.Should().BeOfType<GenericResponse<DoctorProfileDetailsDto>>().Subject;
            //response.IsSuccess.Should().BeTrue();
            //response.HasError.Should().BeFalse();
            //response.Result.Should().BeEquivalentTo(partialDto);
        }
    
}

