﻿using Aurora.AdministrationService.API.Controllers.AdminOrganization;
using Aurora.AdministrationService.API.Helper;
using Aurora.AdministrationService.API.Models.Dto.Hospitals;
using Aurora.AdministrationService.API.Models.Dto.Locations;
using Aurora.AdministrationService.API.Services.IService.AdminOrganization;
using Aurora.AdministrationService.CrossCutting.CommonModels;
using Aurora.AdministrationService.CrossCutting.Constants;
using FluentAssertions;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Graph;
using Moq;

namespace Aurora.AdministrationService.Tests.API.Controllers.V1.AdminOrganization
{
    public class OrganizationControllerTest
    {
        private readonly Mock<IOrganizationsQueryService> _doctorServiceMock;
        private readonly OrganizationController _controller;
        private readonly Mock<IRegionCodeValidationHelper> _regionCodeValidationHelperMock;
        public OrganizationControllerTest()
        {
            _doctorServiceMock = new Mock<IOrganizationsQueryService>();
            _regionCodeValidationHelperMock = new Mock<IRegionCodeValidationHelper>();
            _controller = new OrganizationController(_doctorServiceMock.Object, _regionCodeValidationHelperMock.Object);
        }

        [Fact]
        public void GetAllHospital_ShouldReturnBadRequest_WhenRegionCodeIsInvalid()
        {
            double? latitude = 0.01;
            double? longitude = 0.02;
            // Create a GenericResponse with the error information
            var invalidRegionCodeResponse = new GenericResponse<string>
            {
                HasError = true,
                StatusCode = ResponseStatusCode.STATUS_BADREQUEST,// Assuming 400 as BadRequest status code
                IsSuccess = false,
            };
            // Mock the region code validation to simulate an invalid region code
            _regionCodeValidationHelperMock
                .Setup(x => x.VerifyRegionCodeHeader(It.IsAny<HttpRequest>()))
                .Returns(invalidRegionCodeResponse);
            // Act
            var result =  _controller.GetAllHospitalWithDistance(latitude, longitude);
            // Assert
            result.Should().BeOfType<BadRequestObjectResult>()
                .Which.Value.Should().BeEquivalentTo(invalidRegionCodeResponse);
        }

        [Fact]
        public void GetSpeciality_ShouldReturnOk_WhenDoctorsFound()
        {
            // Arrange
            double latitude = 0.01;
            double longitude = 0.02;
            bool isDistanceCalculationNeeded = true;
            _regionCodeValidationHelperMock
                .Setup(helper => helper.VerifyRegionCodeHeader(It.IsAny<HttpRequest>()));
            _doctorServiceMock
                .Setup(service => service.GetHospitalListByDistance(latitude, longitude, isDistanceCalculationNeeded));
            // Act
            var result =  _controller.GetAllHospitalWithDistance(latitude, longitude);
            // Assert
            var okResult = result as OkObjectResult;
            okResult.Should().NotBeNull();
            okResult?.StatusCode.Should().Be(200);
        }

        [Fact]
        public void GetAllHospitalWithDistance_ElsePart_ReturnsOkResult()
        {
            // Arrange
            var verifyStatus = new GenericResponse<string>() { HasError = false };
            _regionCodeValidationHelperMock
                .Setup(helper => helper.VerifyRegionCodeHeader(It.IsAny<HttpRequest>()))
                .Returns(verifyStatus);

            // Mock GetHospitalListByDistance with default values (assuming it returns some sample list of hospitals)
            var sampleHospitals = new GenericResponseList<GetHospitalWithDistanceDto>
            {
                Results = new List<GetHospitalWithDistanceDto>(),
            };
            _doctorServiceMock
                .Setup(service => service.GetHospitalListByDistance(default, default, false))
                .Returns(sampleHospitals);

            // Act
            var result =  _controller.GetAllHospitalWithDistance(null, null);

            // Assert
            var okResult = Assert.IsType<OkObjectResult>(result);  // Check if response is 200 OK
            var returnedHospitals = Assert.IsAssignableFrom<GenericResponseList<GetHospitalWithDistanceDto>>(okResult.Value);  // Check if the result is of type IEnumerable<Hospital>
            Assert.Equal(sampleHospitals, returnedHospitals);  // Verify that the correct hospitals were returned
        }

        [Fact]
        public async Task GetAllHospitals_ShouldReturnBadRequest_WhenRegionCodeIsInvalid()
        {
            // Arrange: Setup the mock for an invalid region code
            var mockErrorResponse = new GenericResponse<string> { HasError = true, Message = "Invalid region code." };
            _regionCodeValidationHelperMock.Setup(x => x.VerifyRegionCodeHeader(It.IsAny<HttpRequest>()))
                .Returns(mockErrorResponse);

            // Act: Call the controller method
            var result = await _controller.GetAllHospitals();

            // Assert: The result should be a BadRequest with the appropriate error
            result.Should().BeOfType<BadRequestObjectResult>()
                .Which.Value.Should().BeEquivalentTo(mockErrorResponse);
        }

        [Fact]
        public async Task GetAllHospitals_ShouldReturnOk_WhenRegionCodeIsValid()
        {
            // Arrange: Setup the mock for a valid region code
            _regionCodeValidationHelperMock.Setup(x => x.VerifyRegionCodeHeader(It.IsAny<HttpRequest>()))
                .Returns(new GenericResponse<string> { }); // No error in the response

            // Arrange: Setup the mock for the hospitals data

            var hospitals = new List<HospitalsDto>
            {
                new HospitalsDto { Id = 1, Name = "Hospital A", Alias = "Hospital A Alias" },
                new HospitalsDto { Id = 2, Name = "Hospital B", Alias = "Hospital B Alias" }
            };
            var mockHospitals = new GenericResponseList<HospitalsDto>
            {
                Results = hospitals,
                IsSuccess = true,

            };
            _doctorServiceMock.Setup(x => x.GetHospitals())
                .ReturnsAsync(mockHospitals);

            // Act: Call the controller method
            var result = await _controller.GetAllHospitals();

            // Assert: The result should be an OkObjectResult with the expected data
            result.Should().BeOfType<OkObjectResult>()
                .Which.Value.Should().BeEquivalentTo(mockHospitals);
        }
    }
}
