﻿using Aurora.AdministrationService.API.Controllers.Agreement;
using Aurora.AdministrationService.API.Helper;
using Aurora.AdministrationService.API.Models.Dto.V1.Agreement;
using Aurora.AdministrationService.API.Models.RequestModels.V1.Agreement;
using Aurora.AdministrationService.API.Models.ResponseModels.V1.Agreement;
using Aurora.AdministrationService.API.Resources;
using Aurora.AdministrationService.API.Services.IService.Agreement;
using Aurora.AdministrationService.API.Services.Service.Agreement;
using Aurora.AdministrationService.CrossCutting.CommonModels;
using Aurora.AdministrationService.CrossCutting.Constants;
using Aurora.AdministrationService.Domain.V1.Entities;
using Aurora.AdministrationService.Tests.API.CommonMock;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using Moq;

namespace Aurora.AdministrationService.Tests.API.Controllers.V1.Agreement;

public class AgreementControllerTests
{
    private readonly Mock<IAgreementQueryService> _mockQueryService;
    private readonly Mock<IAgreementCommandService> _mockCommandService;
    private readonly Mock<IRegionCodeValidationHelper> _mockRegionHelper;
    private readonly AgreementController _controller;

    public AgreementControllerTests()
    {
        _mockQueryService = new Mock<IAgreementQueryService>();
        _mockCommandService = new Mock<IAgreementCommandService>();
        _mockRegionHelper = new Mock<IRegionCodeValidationHelper>();
        _controller = new AgreementController(_mockQueryService.Object, _mockCommandService.Object, _mockRegionHelper.Object);
    }

    public static IEnumerable<object[]> GetAgreementTestCases()
    {
        yield return new object[] { 1, DTO.GetAgreement(), 200, false };
        yield return new object[] { 1, DTO.GetAgreement(), 400, false, false };
        yield return new object[] { 1, DTO.GetAgreement(), 400, true };
        yield return new object[] { 2, null, 404, false };
    }

    public static IEnumerable<object[]> GetAgreementsTestCases()
    {
        yield return new object[] { ResponseStatusCode.STATUS_SUCCESS, 200, false };
        yield return new object[] { ResponseStatusCode.STATUS_SUCCESS, 400, false, false };
        yield return new object[] { ResponseStatusCode.STATUS_SUCCESS, 400, true };
        yield return new object[] { ResponseStatusCode.STATUS_NOTFOUND, 404, false };
    }

    public static IEnumerable<object[]> AddAgreementTestCases()
    {
        yield return new object[] { ResponseStatusCode.STATUS_SUCCESS, DTO.GetAgreementDto(), 200, false };
        yield return new object[] { ResponseStatusCode.STATUS_BADREQUEST, DTO.GetAgreementDto(), 400, false, false };
        yield return new object[] { ResponseStatusCode.STATUS_BADREQUEST, DTO.GetAgreementDto(), 400, true };
        yield return new object[] { ResponseStatusCode.STATUS_CONFLICT, DTO.GetAgreementDto(), 409, false };
        yield return new object[] { ResponseStatusCode.STATUS_BADREQUEST, DTO.GetAgreementDto(), 400, false };
    }
    public static IEnumerable<object[]> AddAgreementConflictTestCases()
    {
        yield return new object[] { ResponseStatusCode.STATUS_BADREQUEST, DTO.GetAgreementDto(), 400, false, false };
        yield return new object[] { ResponseStatusCode.STATUS_BADREQUEST, DTO.GetAgreementDto(), 400, true };
        yield return new object[] { ResponseStatusCode.STATUS_CONFLICT, DTO.GetAgreementDto(), 409, false };
    }

    public static IEnumerable<object[]> UpdateAgreementTestCases()
    {
        yield return new object[] { ResponseStatusCode.STATUS_SUCCESS, DTO.GetUpdateAgreementsRequest(), 200, false };
        yield return new object[] { ResponseStatusCode.STATUS_BADREQUEST, DTO.GetUpdateAgreementsRequest(), 400, false, false };
        yield return new object[] { ResponseStatusCode.STATUS_BADREQUEST, DTO.GetUpdateAgreementsRequest(), 400, false, true, true };
        yield return new object[] { ResponseStatusCode.STATUS_BADREQUEST, DTO.GetUpdateAgreementsRequest(), 400, false, true, false, false };
        yield return new object[] { ResponseStatusCode.STATUS_BADREQUEST, DTO.GetUpdateAgreementsRequest(), 400, false, true, false, true, true };
        yield return new object[] { ResponseStatusCode.STATUS_BADREQUEST, DTO.GetUpdateAgreementsRequest(), 400, true };
    }
    
    public static IEnumerable<object[]> UpdateAgreementsStatusTestCases()
    {
        yield return new object[] { ResponseStatusCode.STATUS_SUCCESS, DTO.GetUpdateAgreementsStatusRequest(), 200, false };
        yield return new object[] { ResponseStatusCode.STATUS_BADREQUEST, DTO.GetUpdateAgreementsStatusRequest(), 400, false, false };
        yield return new object[] { ResponseStatusCode.STATUS_NOTFOUND, DTO.GetUpdateAgreementsStatusRequest(), 404, false, true, true };
        yield return new object[] { ResponseStatusCode.STATUS_BADREQUEST, DTO.GetUpdateAgreementsStatusRequest(), 400, false, true, false, false };
        yield return new object[] { ResponseStatusCode.STATUS_NOTFOUND, DTO.GetUpdateAgreementsStatusRequest(), 400, false, true, false, true, true };
        yield return new object[] { ResponseStatusCode.STATUS_NOTFOUND, DTO.GetUpdateAgreementsStatusRequest(), 404, false, true, false, true, false, true };
        yield return new object[] { ResponseStatusCode.STATUS_BADREQUEST, DTO.GetUpdateAgreementsStatusRequest(), 400, true };
    }
    
    public static IEnumerable<object[]> DeleteAgreementTestCases()
    {
        yield return new object[] { ResponseStatusCode.STATUS_SUCCESS, 200, false };
        yield return new object[] { ResponseStatusCode.STATUS_BADREQUEST, 400, false, false };
        yield return new object[] { ResponseStatusCode.STATUS_NOTFOUND, 404, false, true, true };
        yield return new object[] { ResponseStatusCode.STATUS_BADREQUEST, 400, false, true, false, false };
        yield return new object[] { ResponseStatusCode.STATUS_NOTFOUND, 404, false, true, false, true, true };
        yield return new object[] { ResponseStatusCode.STATUS_BADREQUEST, 400, true };
    }

    [Theory]
    [MemberData(nameof(GetAgreementTestCases))]
    public async Task GetAgreementById_ShouldReturnExpectedResult(long agreementId, Domain.V1.Entities.Agreement agreement, int expectedStatusCode, bool isModelInvalid, bool isVerifyStatus = true)
    {
        var agreementResult = agreement == null ? null : new GenericResponse<AgreementByDetailResponse>()
        {
            IsSuccess = true,
            HasError = false,
            Result = new AgreementByDetailResponse
            {
                Id = agreementId,
                RecordVersion = agreement.RecordVersion,
                UniqueId = agreement.UniqueID,
                Description = "",
                FrequencyID = 1,
                LanguageID = 1,
                Name = "",
            }
        };
        _mockQueryService.Setup(q => q.GetAgreementById(agreementId)).ReturnsAsync(agreementResult);

        if (isVerifyStatus)
            _mockRegionHelper.Setup(r => r.VerifyRegionCodeHeader(It.IsAny<HttpRequest>())).Returns(new GenericResponse<string>() { IsSuccess = true });
        else
            _mockRegionHelper.Setup(r => r.VerifyRegionCodeHeader(It.IsAny<HttpRequest>())).Returns(new GenericResponse<string>() { IsSuccess = false, HasError = true });

        if (isModelInvalid)
            _controller.ModelState.AddModelError("Key", "Error message");

        var result = await _controller.GetAgreementById(agreementId);

        if (isModelInvalid || !isVerifyStatus)
        {
            var objectResult = Assert.IsType<BadRequestObjectResult>(result);
            Assert.Equal(expectedStatusCode, objectResult.StatusCode);
        }
        else if (agreement == null)
        {
            var objectResult = Assert.IsType<NotFoundResult>(result);
            Assert.Equal(expectedStatusCode, objectResult.StatusCode);
        }
        else
        {
            var objectResult = Assert.IsType<OkObjectResult>(result);
            Assert.Equal(expectedStatusCode, objectResult.StatusCode);
        }
    }

    [Theory]
    [MemberData(nameof(GetAgreementsTestCases))]
    public async Task GetAgreements_ShouldReturnExpectedResult(string status, int expectedStatusCode, bool isModelInvalid, bool isVerifyStatus = true)
    {
        var agreementResult = new GenericResponseList<GetAgreementResponse>()
        {
            IsSuccess = true,
            HasError = false,
            StatusCode = status
        };

        _mockQueryService.Setup(q => q.GetAgreements(null, null, null, null,null)).ReturnsAsync(agreementResult);

        if (isVerifyStatus)
            _mockRegionHelper.Setup(r => r.VerifyRegionCodeHeader(It.IsAny<HttpRequest>())).Returns(new GenericResponse<string>() { IsSuccess = true });
        else
            _mockRegionHelper.Setup(r => r.VerifyRegionCodeHeader(It.IsAny<HttpRequest>())).Returns(new GenericResponse<string>() { IsSuccess = false, HasError = true });

        if (isModelInvalid)
            _controller.ModelState.AddModelError("Key", "Error message");

        var result = await _controller.GetAgreements(null, null, null, null) as ObjectResult;

        if (isModelInvalid || !isVerifyStatus)
        {
            Assert.Equal(expectedStatusCode, result?.StatusCode);
        }
        else if (status == ResponseStatusCode.STATUS_NOTFOUND)
        {
            Assert.Equal(expectedStatusCode, result?.StatusCode);
        }
        else
        {
            Assert.Equal(expectedStatusCode, result?.StatusCode);
        }
    }

    [Theory]
    [MemberData(nameof(GetAgreementsTestCases))]
    public async Task GetAgreementsByLanguage_ShouldReturnExpectedResult(
        string status,
        int expectedStatusCode,
        bool isModelInvalid,
        bool isVerifyStatus = true)
    {
        // Arrange
        var agreementResult = new GenericResponseList<GetAgreementResponse>()
        {
            IsSuccess = true,
            HasError = false,
            StatusCode = status
        };

        _mockQueryService.Setup(q => q.GetAgreements(It.IsAny<int?>(), It.IsAny<int?>(), It.IsAny<string>(), null,null)).ReturnsAsync(agreementResult);

        if (isVerifyStatus)
            _mockRegionHelper.Setup(r => r.VerifyRegionCodeHeader(It.IsAny<HttpRequest>())).Returns(new GenericResponse<string>() { IsSuccess = true });
        else
            _mockRegionHelper.Setup(r => r.VerifyRegionCodeHeader(It.IsAny<HttpRequest>())).Returns(new GenericResponse<string>() { IsSuccess = false, HasError = true });

        if (isModelInvalid)
            _controller.ModelState.AddModelError("Key", "Error message");

        // Act
        var result = await _controller.GetAgreementsByLanguage(null, null, "en",null) as ObjectResult;

        // Assert
        if (isModelInvalid || !isVerifyStatus)
        {
            Assert.Equal(expectedStatusCode, result?.StatusCode);
        }
        else if (status == ResponseStatusCode.STATUS_NOTFOUND)
        {
            Assert.Equal(expectedStatusCode, result?.StatusCode);
        }
        else
        {
            Assert.Equal(expectedStatusCode, result?.StatusCode);
        }
    }

    [Theory]
    [MemberData(nameof(GetAgreementsTestCases))]
    public async Task GetAgreementsByUniqueId_ShouldReturnExpectedResult(
        string status,
        int expectedStatusCode,
        bool isModelInvalid,
        bool isVerifyStatus = true)
    {
        // Arrange
        var agreementResult = new GenericResponseList<GetAgreementResponse>()
        {
            IsSuccess = true,
            HasError = false,
            StatusCode = status
        };

        _mockQueryService.Setup(q => q.GetAgreements(null, null, null, It.IsAny<string>(), null)).ReturnsAsync(agreementResult);

        if (isVerifyStatus)
            _mockRegionHelper.Setup(r => r.VerifyRegionCodeHeader(It.IsAny<HttpRequest>())).Returns(new GenericResponse<string>() { IsSuccess = true });
        else
            _mockRegionHelper.Setup(r => r.VerifyRegionCodeHeader(It.IsAny<HttpRequest>())).Returns(new GenericResponse<string>() { IsSuccess = false, HasError = true });

        if (isModelInvalid)
            _controller.ModelState.AddModelError("Key", "Error message");

        // Act
        var result = await _controller.GetAgreementsByAgreementUniqueId("test") as ObjectResult;

        // Assert
        if (isModelInvalid || !isVerifyStatus)
        {
            Assert.Equal(expectedStatusCode, result?.StatusCode);
        }
        else if (status == ResponseStatusCode.STATUS_NOTFOUND)
        {
            Assert.Equal(expectedStatusCode, result?.StatusCode);
        }
        else
        {
            Assert.Equal(expectedStatusCode, result?.StatusCode);
        }
    }

    [Theory]
    [MemberData(nameof(AddAgreementTestCases))]
    public async Task AddAgreement_ShouldReturnExpectedResult(string status, AgreementDto request, int expectedStatusCode, bool isModelInvalid = false, bool isVerifyStatus = true)
    {
        var agreementResult = new GenericResponse<string>()
        {
            IsSuccess = true,
            HasError = status != ResponseStatusCode.STATUS_SUCCESS ? true : false,
            StatusCode = status
        };

        _mockCommandService.Setup(q => q.AddAgreementAsync(request)).ReturnsAsync(agreementResult);

        if (isVerifyStatus)
            _mockRegionHelper.Setup(r => r.VerifyRegionCodeHeader(It.IsAny<HttpRequest>())).Returns(new GenericResponse<string>() { IsSuccess = true });
        else
            _mockRegionHelper.Setup(r => r.VerifyRegionCodeHeader(It.IsAny<HttpRequest>())).Returns(new GenericResponse<string>() { IsSuccess = false, HasError = true });

        if (isModelInvalid)
            _controller.ModelState.AddModelError("Key", "Error message");

        var result = await _controller.AddAgreement(request);

        if (isModelInvalid || !isVerifyStatus)
        {
            var objectResult = Assert.IsType<BadRequestObjectResult>(result);
            Assert.Equal(expectedStatusCode, objectResult.StatusCode);
        }
        else if (status == ResponseStatusCode.STATUS_CONFLICT)
        {
            var objectResult = Assert.IsType<ConflictObjectResult>(result);
            Assert.Equal(expectedStatusCode, objectResult.StatusCode);
        }
        else if (status == ResponseStatusCode.STATUS_BADREQUEST)
        {
            var objectResult = Assert.IsType<BadRequestResult>(result);
            Assert.Equal(expectedStatusCode, objectResult.StatusCode);
        }
        else
        {
            var objectResult = Assert.IsType<OkObjectResult>(result);
            Assert.Equal(expectedStatusCode, objectResult.StatusCode);
        }
    }
    [Theory]
    [MemberData(nameof(AddAgreementConflictTestCases))]
    public async Task AddAgreement_ReturnFailureResult_WhenUniqueIdExist(string status, AgreementDto request, int expectedStatusCode, bool isModelInvalid = false, bool isVerifyStatus = true)
    {
        var agreementResult = new GenericResponse<string>()
        {
            IsSuccess = true,
            HasError = status != ResponseStatusCode.STATUS_SUCCESS ? true : false,
            StatusCode = status
        };

        _mockCommandService.Setup(q => q.AddAgreementAsync(request)).ReturnsAsync(agreementResult);
        _mockQueryService.Setup(q => q.IsUniqueIDAlreadyExist(request.UniqueId)).ReturnsAsync(true);
        _mockQueryService.Setup(q => q.IsAgreementNameAlreadyExist(request.Name,request.LanguageID??0)).ReturnsAsync((true,true));

        if (isVerifyStatus)
            _mockRegionHelper.Setup(r => r.VerifyRegionCodeHeader(It.IsAny<HttpRequest>())).Returns(new GenericResponse<string>() { IsSuccess = true });
        else
            _mockRegionHelper.Setup(r => r.VerifyRegionCodeHeader(It.IsAny<HttpRequest>())).Returns(new GenericResponse<string>() { IsSuccess = false, HasError = true });

        if (isModelInvalid)
            _controller.ModelState.AddModelError("Key", "Error message");

        var result = await _controller.AddAgreement(request);

        if (isModelInvalid || !isVerifyStatus)
        {
            var objectResult = Assert.IsType<BadRequestObjectResult>(result);
            Assert.Equal(expectedStatusCode, objectResult.StatusCode);
        }
        else if (status == ResponseStatusCode.STATUS_CONFLICT)
        {
            var objectResult = Assert.IsType<ConflictObjectResult>(result);
            Assert.Equal(expectedStatusCode, objectResult.StatusCode);
        }
       
    }
    [Theory]
    [MemberData(nameof(AddAgreementConflictTestCases))]
    public async Task AddAgreement_ReturnFailureResult_WhenAgreementNameExist(string status, AgreementDto request, int expectedStatusCode, bool isModelInvalid = false, bool isVerifyStatus = true)
    {
        var agreementResult = new GenericResponse<string>()
        {
            IsSuccess = true,
            HasError = status != ResponseStatusCode.STATUS_SUCCESS ? true : false,
            StatusCode = status
        };

        _mockCommandService.Setup(q => q.AddAgreementAsync(request)).ReturnsAsync(agreementResult);
        _mockQueryService.Setup(q => q.IsUniqueIDAlreadyExist(request.UniqueId)).ReturnsAsync(true);
        _mockQueryService.Setup(q => q.IsAgreementNameAlreadyExist(request.Name, request.LanguageID ?? 0)).ReturnsAsync((false, true));

        if (isVerifyStatus)
            _mockRegionHelper.Setup(r => r.VerifyRegionCodeHeader(It.IsAny<HttpRequest>())).Returns(new GenericResponse<string>() { IsSuccess = true });
        else
            _mockRegionHelper.Setup(r => r.VerifyRegionCodeHeader(It.IsAny<HttpRequest>())).Returns(new GenericResponse<string>() { IsSuccess = false, HasError = true });

        if (isModelInvalid)
            _controller.ModelState.AddModelError("Key", "Error message");

        var result = await _controller.AddAgreement(request);

        if (isModelInvalid || !isVerifyStatus)
        {
            var objectResult = Assert.IsType<BadRequestObjectResult>(result);
            Assert.Equal(expectedStatusCode, objectResult.StatusCode);
        }
        else if (status == ResponseStatusCode.STATUS_CONFLICT)
        {
            var objectResult = Assert.IsType<ConflictObjectResult>(result);
            Assert.Equal(expectedStatusCode, objectResult.StatusCode);
        }

    }
    [Theory]
    [MemberData(nameof(UpdateAgreementTestCases))]
    public async Task UpdateAgreement_ShouldReturnExpectedResult(string status, UpdateAgreementsRequest request, int expectedStatusCode, bool isModelInvalid = false, bool isVerifyStatus = true, bool isLanguageCodeInvalid = false, bool isValidUpdate = true, bool isException = false)
    {
        var agreementResult = new GenericResponse<string>()
        {
            IsSuccess = isValidUpdate,
            HasError = status != ResponseStatusCode.STATUS_SUCCESS ? true : false,
            StatusCode = status
        };
        var existingAgreementLanguage = status == ResponseStatusCode.STATUS_NOTFOUND ? null : DTO.GetAgreementLanguage();

        if (isLanguageCodeInvalid)
            request.LanguageID = null;

        _mockQueryService.Setup(q => q.GetAgreementByIdAsync(It.IsAny<long>())).ReturnsAsync(DTO.GetAgreement());
        _mockQueryService.Setup(q => q.GetAgreementLanguageAsync(It.IsAny<long>())).ReturnsAsync(existingAgreementLanguage);
        _mockCommandService.Setup(q => q.UpdateAgreementAsync(It.IsAny<UpdateAgreementsRequest>(), It.IsAny<Domain.V1.Entities.Agreement>(), It.IsAny<AgreementLanguage>())).ReturnsAsync(agreementResult);
        if (isException)
        {
            _mockCommandService.Setup(q => q.UpdateAgreementAsync(It.IsAny<UpdateAgreementsRequest>(), It.IsAny<Domain.V1.Entities.Agreement>(), It.IsAny<AgreementLanguage>())).ThrowsAsync(new DbUpdateConcurrencyException());
        }
        if (isVerifyStatus)
            _mockRegionHelper.Setup(r => r.VerifyRegionCodeHeader(It.IsAny<HttpRequest>())).Returns(new GenericResponse<string>() { IsSuccess = true });
        else
            _mockRegionHelper.Setup(r => r.VerifyRegionCodeHeader(It.IsAny<HttpRequest>())).Returns(new GenericResponse<string>() { IsSuccess = false, HasError = true });

        if (isModelInvalid)
            _controller.ModelState.AddModelError("Key", "Error message");

        var result = await _controller.UpdateAgreement(1, request) as ObjectResult;
        Assert.Equal(expectedStatusCode, result?.StatusCode);
    }
    


    [Theory]
    [MemberData(nameof(UpdateAgreementsStatusTestCases))]
    public async Task UpdateAgreementsStatus_ShouldReturnExpectedResult(string status, UpdateAgreementsStatusRequest request, int expectedStatusCode, bool isModelInvalid = false, bool isVerifyStatus = true, bool isLanguageCodeInvalid = false, bool isValidUpdate = true, bool isException = false, bool isAgreementInvalid = false)
    {
        var agreementResult = new GenericResponse<string>()
        {
            IsSuccess = isValidUpdate,
            HasError = status != ResponseStatusCode.STATUS_SUCCESS ? true : false,
            StatusCode = status
        };
        var existingAgreementLanguage = isLanguageCodeInvalid ? null : DTO.GetAgreementLanguage();
        var existingAgreement = isAgreementInvalid ? null : DTO.GetAgreement();

        _mockQueryService.Setup(q => q.GetAgreementByIdAsync(It.IsAny<long>())).ReturnsAsync(existingAgreement);
        _mockQueryService.Setup(q => q.GetAgreementLanguageAsync(It.IsAny<long>())).ReturnsAsync(existingAgreementLanguage);
        _mockCommandService.Setup(q => q.UpdateAgreementAsync(It.IsAny<UpdateAgreementsRequest>(), It.IsAny<Domain.V1.Entities.Agreement>(), It.IsAny<AgreementLanguage>())).ReturnsAsync(agreementResult);
        
        if (isException)
        {
            _mockCommandService.Setup(q => q.UpdateAgreementAsync(It.IsAny<UpdateAgreementsRequest>(), It.IsAny<Domain.V1.Entities.Agreement>(), It.IsAny<AgreementLanguage>())).ThrowsAsync(new DbUpdateConcurrencyException());
        }
        if (isVerifyStatus)
            _mockRegionHelper.Setup(r => r.VerifyRegionCodeHeader(It.IsAny<HttpRequest>())).Returns(new GenericResponse<string>() { IsSuccess = true });
        else
            _mockRegionHelper.Setup(r => r.VerifyRegionCodeHeader(It.IsAny<HttpRequest>())).Returns(new GenericResponse<string>() { IsSuccess = false, HasError = true });

        if (isModelInvalid)
            _controller.ModelState.AddModelError("Key", "Error message");

        var result = await _controller.UpdateAgreementsStatus(1, request) as ObjectResult;
        Assert.Equal(expectedStatusCode, result?.StatusCode);
    }
    
    [Theory]
    [MemberData(nameof(DeleteAgreementTestCases))]
    public async Task DeleteAgreement_ShouldReturnExpectedResult(string status, int expectedStatusCode, bool isModelInvalid = false, bool isVerifyStatus = true, bool isLanguageCodeInvalid = false, bool isValidUpdate = true, bool isAgreementInvalid = false)
    {
        var agreementResult = new GenericResponse<string>()
        {
            IsSuccess = isValidUpdate,
            HasError = status != ResponseStatusCode.STATUS_SUCCESS ? true : false,
            StatusCode = status
        };
        var existingAgreementLanguage = isLanguageCodeInvalid ? null : DTO.GetAgreementLanguage();
        var existingAgreement = isAgreementInvalid ? null : DTO.GetAgreement();

        _mockQueryService.Setup(q => q.GetAgreementByIdAsync(It.IsAny<long>())).ReturnsAsync(existingAgreement);
        _mockQueryService.Setup(q => q.GetAgreementLanguageAsync(It.IsAny<long>())).ReturnsAsync(existingAgreementLanguage);
        _mockCommandService.Setup(q => q.DeleteAgreementAsync(It.IsAny<byte[]>(), It.IsAny<Domain.V1.Entities.Agreement>(), It.IsAny<AgreementLanguage>())).ReturnsAsync(agreementResult);
        
        if (isVerifyStatus)
            _mockRegionHelper.Setup(r => r.VerifyRegionCodeHeader(It.IsAny<HttpRequest>())).Returns(new GenericResponse<string>() { IsSuccess = true });
        else
            _mockRegionHelper.Setup(r => r.VerifyRegionCodeHeader(It.IsAny<HttpRequest>())).Returns(new GenericResponse<string>() { IsSuccess = false, HasError = true });

        if (isModelInvalid)
            _controller.ModelState.AddModelError("Key", "Error message");

        var result = await _controller.DeleteAgreement(1) as ObjectResult;
        Assert.Equal(expectedStatusCode, result?.StatusCode);
    }

    [Fact]
    public async Task UpdateAgreement_ReturnsNotFound_WhenExistingAgreementLanguageIsNull()
    {
        // Arrange
        var verifyStatus = new GenericResponse<string>() { HasError = false };
        _mockRegionHelper
            .Setup(helper => helper.VerifyRegionCodeHeader(It.IsAny<HttpRequest>()))
            .Returns(verifyStatus);

        var agreementId = 1L;  // Example ID
        var request = new UpdateAgreementsRequest
        {
            LanguageID = 1,  // Assuming valid LanguageID is provided
            RecordVersion=Array.Empty<byte>(),
            Description = "",
            FrequencyID = 1,
            Name = "",
            UniqueId = "1"
        };

        // Mock GetAgreementByIdAsync to return a non-null agreement
        var agreement = new Domain.V1.Entities.Agreement { 
            ID = agreementId, IsDeleted = false ,
            CreatedBy   = "Test",
            CreatedDate = DateTime.UtcNow,
            Status = true,
            UpdatedBy = "Test",
            UpdatedDate = DateTime.UtcNow,
        };
        _mockQueryService
            .Setup(service => service.GetAgreementByIdAsync(agreementId))
            .ReturnsAsync(agreement);

        // Mock GetAgreementLanguageAsync to return null (this simulates the scenario where the language record is missing)
        _mockQueryService
            .Setup(service => service.GetAgreementLanguageAsync(agreementId))
            .ReturnsAsync(It.IsAny<AgreementLanguage>());

        // Act
        var result = await _controller.UpdateAgreement(agreementId, request);

        // Assert
        var notFoundResult = Assert.IsType<NotFoundObjectResult>(result);  // Check if response is 404 NotFound
        var response = Assert.IsType<GenericResponse<string>>(notFoundResult.Value);  // Check if the response is of correct type
        Assert.Equal(ResponseStatusCode.STATUS_NOTFOUND, response.StatusCode);  // Ensure status code is STATUS_NOTFOUND
        Assert.Equal(Resource.RecordNotFound, response.Message);  // Check if message is "Record Not Found"
    }
}