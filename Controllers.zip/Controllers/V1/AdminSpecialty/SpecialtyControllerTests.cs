﻿using Aurora.AdministrationService.API.Controllers.AdminSpeciality;
using Aurora.AdministrationService.API.Helper;
using Aurora.AdministrationService.API.Models.ResponseModels.V1.AdminSpeciality;
using Aurora.AdministrationService.API.Services.IService.AdminSpecialty;
using Aurora.AdministrationService.CrossCutting.CommonModels;
using Aurora.AdministrationService.CrossCutting.Constants;
using FluentAssertions;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Moq;

namespace Aurora.AdministrationService.Tests.API.Controllers.V1.AdminDoctor
{
    public class SpecialtyControllerTests
    {
        private readonly Mock<ISpecialityServices> _doctorServiceMock;
        private readonly SpecialityController _controller;
        private readonly Mock<IRegionCodeValidationHelper> _regionCodeValidationHelperMock;
        public SpecialtyControllerTests()
        {
            _doctorServiceMock = new Mock<ISpecialityServices>();
            _regionCodeValidationHelperMock = new Mock<IRegionCodeValidationHelper>();

            _controller = new SpecialityController(_doctorServiceMock.Object, _regionCodeValidationHelperMock.Object);
        }

        [Fact]
        public void GetAllSpeciality_ShouldReturnBadRequest_WhenRegionCodeIsInvalid()
        {
            var specialistType = "Dietitian";
            // Create a GenericResponse with the error information
            var invalidRegionCodeResponse = new GenericResponse<string>
            {
                HasError = true,
                StatusCode = ResponseStatusCode.STATUS_BADREQUEST,// Assuming 400 as BadRequest status code
                IsSuccess = false,
            };

            // Mock the region code validation to simulate an invalid region code
            _regionCodeValidationHelperMock
                .Setup(x => x.VerifyRegionCodeHeader(It.IsAny<HttpRequest>()))
                .Returns(invalidRegionCodeResponse);

            // Act
            var result = _controller.GetAllSpecialities(specialistType);

            // Assert
            result.Should().BeOfType<BadRequestObjectResult>()
                .Which.Value.Should().BeEquivalentTo(invalidRegionCodeResponse);
        }

        [Fact]
        public void GetSpeciality_ShouldReturnOk_WhenDoctorsFound()
        {
            // Arrange
            var specialistType = "Dietitian";
          
            var data = new List<SpecialtyResponseDto>
            { 
                new SpecialtyResponseDto{
                PractitionerRoleCodeId = 1,
                HealthcareServiceName = "Test"}
            };

            _regionCodeValidationHelperMock
                .Setup(helper => helper.VerifyRegionCodeHeader(It.IsAny<HttpRequest>()));

            _doctorServiceMock
                .Setup(service => service.GetAllSpecialityList(specialistType))
                 .Returns(data);

            // Act
            var result = _controller.GetAllSpecialities(specialistType);

            // Assert
            var okResult = result as OkObjectResult;
            okResult.Should().NotBeNull();
            okResult?.StatusCode.Should().Be(200);
        }


        [Fact]
        public void GetAllSpecialityList_ReturnsBadRequest_WhenDoctorListIsEmptyOrNull()
        {
            // Arrange
            var verifyStatus = new GenericResponse<string>() { HasError = false };
            _regionCodeValidationHelperMock
                .Setup(helper => helper.VerifyRegionCodeHeader(It.IsAny<HttpRequest>()))
                .Returns(verifyStatus);

            // Mock the GetAllSpecialityList method to return an empty list or null
            var emptyDoctorList = new List<SpecialtyResponseDto> { new SpecialtyResponseDto { } };  // or you can use .Results = new List<Doctor>(); for an empty list
            _doctorServiceMock
                .Setup(service => service.GetAllSpecialityList(It.IsAny<string>()))
                .Returns(emptyDoctorList);

            // Act
            var result = _controller.GetAllSpecialities("someRole");

            // Assert
            Assert.IsType<OkObjectResult>(result);  // Check if response is 400 BadRequest
        }
    }
}

