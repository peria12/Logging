﻿using Aurora.AdministrationService.API.Controllers.AdminInsurance;
using Aurora.AdministrationService.API.Helper;
using Aurora.AdministrationService.API.Models.ResponseModels.V1.AdminInsurance;
using Aurora.AdministrationService.API.Services.IService.AdminInsurance;
using Aurora.AdministrationService.CrossCutting.CommonModels;
using Aurora.AdministrationService.CrossCutting.Constants;
using FluentAssertions;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Moq;

namespace Aurora.AdministrationService.Tests.API.Controllers.V1.AdminDoctor
{
    public class InsuranceControllerTests
    {
        private readonly Mock<IInsuranceQueryService> _doctorServiceMock;
        private readonly InsuranceController _controller;
        private readonly Mock<IRegionCodeValidationHelper> _regionCodeValidationHelperMock;
        public InsuranceControllerTests()
        {
            _doctorServiceMock = new Mock<IInsuranceQueryService>();
            _regionCodeValidationHelperMock = new Mock<IRegionCodeValidationHelper>();
            _controller = new InsuranceController(_doctorServiceMock.Object, _regionCodeValidationHelperMock.Object);
        }

        [Fact]
        public async Task GetSpeciality_ShouldReturnBadRequest_WhenRegionCodeIsInvalid()
        {
            // Arrange
            // Create a GenericResponse with the error information
            var invalidRegionCodeResponse = new GenericResponse<string>
            {
                HasError = true,
                StatusCode = ResponseStatusCode.STATUS_BADREQUEST,// Assuming 400 as BadRequest status code
                IsSuccess = false,
            };

            // Mock the region code validation to simulate an invalid region code
            _regionCodeValidationHelperMock
                .Setup(x => x.VerifyRegionCodeHeader(It.IsAny<HttpRequest>()))
                .Returns(invalidRegionCodeResponse);

            // Act
            var result = await _controller.GetAllInsurance();

            // Assert
            result.Should().BeOfType<BadRequestObjectResult>()
                .Which.Value.Should().BeEquivalentTo(invalidRegionCodeResponse);
        }

        [Fact]
        public async Task GetSpeciality_ShouldReturnOk_WhenDoctorsFound()
        {
            // Arrange
            var data = new GenericResponseList<InsuranceResponseDto>
            {
                IsSuccess = true,
                HasError = false,
                Results = new List<InsuranceResponseDto>
                {
                   new InsuranceResponseDto
                   {

                       Id= 1,
                       DebtorName="test",
                       Logo="ytr"
                   },
                }
            };
            _regionCodeValidationHelperMock
                .Setup(helper => helper.VerifyRegionCodeHeader(It.IsAny<HttpRequest>()));

            _doctorServiceMock
                .Setup(service => service.GetAllInsuranceList())
                 .ReturnsAsync(data);

            // Act
            var result = await _controller.GetAllInsurance();

            // Assert
            var okResult = result as OkObjectResult;
            okResult.Should().NotBeNull();
            okResult?.StatusCode.Should().Be(200);
        }
    }
}

