﻿using Aurora.AdministrationService.API.Controllers.SystemSettings;
using Aurora.AdministrationService.API.Models.Dto.SystemsSettings;
using Aurora.AdministrationService.API.Services.IService.SystemSettings;
using Aurora.AdministrationService.CrossCutting.CommonModels;
using Microsoft.AspNetCore.Mvc;
using Moq;

namespace Aurora.AdministrationService.Tests.API.Controllers.V1.SystemSettings;
public class SystemSettingsControllerTests
{
    private readonly Mock<ISystemSettingsQueryService> _mockSystemSettingsService;
    private readonly SystemSettingsController _controller;

    public SystemSettingsControllerTests()
    {
        _mockSystemSettingsService = new Mock<ISystemSettingsQueryService>();
        _controller = new SystemSettingsController(_mockSystemSettingsService.Object);
    }

    [Fact]
    public async Task GetSystemsModules_ReturnsOkResult_WithSystemModules()
    {
        // Arrange
        var systemModules = new List<SystemSettingsDto> { new SystemSettingsDto(), new SystemSettingsDto() };
        _mockSystemSettingsService.Setup(service => service.GetSystemModulesAsync())
            .ReturnsAsync(new GenericResponse<IEnumerable<SystemSettingsDto>>
            {
                Result = systemModules
            });

        // Act
        var result = await _controller.GetSystemsModules();

        // Assert
        var okResult = Assert.IsType<OkObjectResult>(result);
        var returnValue = Assert.IsAssignableFrom< GenericResponse<IEnumerable<SystemSettingsDto>>>(okResult.Value);
        Assert.Equal(systemModules.Count, returnValue?.Result?.Count());
    }

    [Fact]
    public async Task GetSystemsModules_ReturnsOkResult_WhenNoSystemModules()
    {
        // Arrange
        var systemModules = new List<SystemSettingsDto>();
        _mockSystemSettingsService.Setup(service => service.GetSystemModulesAsync())
            .ReturnsAsync(new GenericResponse<IEnumerable<SystemSettingsDto>>
            {
                Result = systemModules
            });

        // Act
        var result = await _controller.GetSystemsModules();

        // Assert
        var okResult = Assert.IsType<OkObjectResult>(result);
        Assert.IsAssignableFrom<GenericResponse<IEnumerable<SystemSettingsDto>>>(okResult.Value);
    }
}
