﻿using Aurora.AdministrationService.API.Controllers.Passcode;
using Aurora.AdministrationService.API.Models.Dto.Users;
using Aurora.AdministrationService.API.Models.RequestModels.Passcode;
using Aurora.AdministrationService.API.Services.IService.Passcode;
using Aurora.AdministrationService.CrossCutting.CommonModels;
using FluentAssertions;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Configuration;
using Moq;

namespace Aurora.AdministrationService.Tests.API.Controllers.Passcode
{
    public class PasscodeControllerTests
    {
        private readonly Mock<IPasscodeQueryService> _passwordQueryServiceMock;
        private readonly PasscodeResetController _controller;

        public PasscodeControllerTests()
        {
            _passwordQueryServiceMock = new Mock<IPasscodeQueryService>();
            var configMock = new Mock<IConfiguration>();
            _controller = new PasscodeResetController(configMock.Object, _passwordQueryServiceMock.Object);
        }

        [Fact]
        public async Task LoginPasscode_Success_ShouldReturnOk()
        {
            // Arrange
            var request = new LoginPasscodeRequest { Passcode = "123456", UserName = "USER123" };
            var expectedResponse = new GenericResponse<LoginSuccessResponseDto>
            {
                IsSuccess = true,
                HasError = false,
                StatusCode = ResponseStatus.STATUS_SUCCESS,
                Message = ResponseMessage.LOGIN_SUCCESS,
                Result = new LoginSuccessResponseDto { UniqueId = "USER123", Token = "JWT-TOKEN" }
            };

            _passwordQueryServiceMock
                .Setup(s => s.LoginPasscodeAsync(request))
                .ReturnsAsync(expectedResponse);

            // Act
            var result = await _controller.LoginPasscode(request) as OkObjectResult;

            // Assert
            result.Should().NotBeNull();
            result!.StatusCode.Should().Be(200);
            result.Value.Should().BeEquivalentTo(expectedResponse);
        }

        [Fact]
        public async Task LoginPasscode_InvalidPasscode_ShouldReturnBadRequest()
        {
            // Arrange
            var request = new LoginPasscodeRequest { Passcode = "999999", UserName = "USER123" };
            var expectedResponse = new GenericResponse<LoginSuccessResponseDto>
            {
                IsSuccess = false,
                HasError = true,
                StatusCode = ResponseStatus.STATUS_BadRequest,
                Message = ResponseMessage.INVALID_CREDENTIAL
            };

            _passwordQueryServiceMock
                .Setup(s => s.LoginPasscodeAsync(request))
                .ReturnsAsync(expectedResponse);

            // Act
            var result = await _controller.LoginPasscode(request) as OkObjectResult;

            // Assert
            result.Should().NotBeNull();
            result!.StatusCode.Should().Be(200);
            result.Value.Should().BeEquivalentTo(expectedResponse);
        }

        [Fact]
        public async Task LoginPasscode_AccountLocked_ShouldReturnBadRequest()
        {
            // Arrange
            var request = new LoginPasscodeRequest { Passcode = "123456", UserName = "USER123" };
            var expectedResponse = new GenericResponse<LoginSuccessResponseDto>
            {
                IsSuccess = false,
                HasError = true,
                StatusCode = ResponseStatus.STATUS_BadRequest,
                Message = "Account locked for multiple attempts."
            };

            _passwordQueryServiceMock
                .Setup(s => s.LoginPasscodeAsync(request))
                .ReturnsAsync(expectedResponse);

            // Act
            var result = await _controller.LoginPasscode(request) as OkObjectResult;

            // Assert
            result.Should().NotBeNull();
            result!.StatusCode.Should().Be(200);
            result.Value.Should().BeEquivalentTo(expectedResponse);
        }

    }
}
