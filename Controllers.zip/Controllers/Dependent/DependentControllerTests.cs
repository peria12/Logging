﻿using Aurora.AdministrationService.API.Controllers.Dependent;
using Aurora.AdministrationService.API.Helper;
using Aurora.AdministrationService.API.Models.Dto.Dependent;
using Aurora.AdministrationService.API.Models.Dto.Dependents;
using Aurora.AdministrationService.API.Models.ResponseModels.Dependent;
using Aurora.AdministrationService.API.Resources;
using Aurora.AdministrationService.API.Services.IService.Dependent;
using Aurora.AdministrationService.API.Services.IService.Users.UserIdentifiers;
using Aurora.AdministrationService.API.Services.IService.Users.UserTelecoms;
using Aurora.AdministrationService.CrossCutting.CommonModels;
using Aurora.AdministrationService.CrossCutting.Constants;
using AutoMapper;
using FluentAssertions;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.VisualStudio.TestPlatform.CommunicationUtilities.Resources;
using Moq;
using System.Net;

namespace Aurora.AdministrationService.Tests.API.Controllers.Dependent;

public class DependentControllerTests
{
    private readonly DependentController _controller;
    private readonly Mock<IRegionCodeValidationHelper> _regionCodeHelperMock;
    private readonly Mock<IDependentQueryService> _dependentQueryServiceMock;
    private readonly Mock<IDependentCommandService> _dependentCommandServiceMock;
    private readonly Mock<IUserTelecomQueryService> _telecomQueryServiceMock;
    private readonly Mock<IUserIdentifierQueryService> _identifierQueryServiceMock;
    private readonly Mock<IValidationHelper> _validationHelperMock;
    private readonly Mock<IMapper> _mapperMock;

    public DependentControllerTests()
    {
        _regionCodeHelperMock = new Mock<IRegionCodeValidationHelper>();
        _dependentQueryServiceMock = new Mock<IDependentQueryService>();
        _dependentCommandServiceMock = new Mock<IDependentCommandService>();
        _telecomQueryServiceMock = new Mock<IUserTelecomQueryService>();
        _identifierQueryServiceMock = new Mock<IUserIdentifierQueryService>();
        _validationHelperMock = new Mock<IValidationHelper>();
        _mapperMock = new Mock<IMapper>();

        _controller = new DependentController(
            _regionCodeHelperMock.Object,
            _validationHelperMock.Object,
            _dependentCommandServiceMock.Object,
            _dependentQueryServiceMock.Object,
            _mapperMock.Object
        );
        _controller.ControllerContext = new ControllerContext
        {
            HttpContext = new DefaultHttpContext()
        };
    }

    [Theory]
    [InlineData(null, 400)] // Invalid region code
    [InlineData("", 400)] // Invalid user ID
    [InlineData("123", 404)] // User not found
    [InlineData("123", 404, true, false)] // Dependent record does not match
    [InlineData("123", 404, true, true, true, true)] // Dependent record does not match
    [InlineData("123", 500, true, true, false)] // Deletion failed
    [InlineData("123", 200, true, true, true)] // Successful deletion
    public async Task DeactivateUserDependent_ShouldReturnExpectedStatus(string userId, int expectedStatus, bool userExists = false, bool dependentExists = false, bool deleteSuccess = false, bool isDependentNull = false)
    {
        // Arrange
        _regionCodeHelperMock.Setup(r => r.VerifyRegionCodeHeader(It.IsAny<HttpRequest>()))
            .Returns(userId == null ? new GenericResponse<string> { HasError = true } : null);

        _regionCodeHelperMock.Setup(r => r.GetUserIdByToken(It.IsAny<HttpRequest>()))
            .Returns(userId);

        var user = new Domain.V1.Entities.Users.User
        {
            Id = 123,
            BioAuthenticationEnabled = true,
            CreatedBy = "test",
            CreatedDate = DateTime.UtcNow,
            IsDeleted = false,
            IsTempAccount = false,
            NotificationsEnabled = true,
            SOSButtonEnabled = true,
            Status = true,
            UpdatedBy = "test",
            UserName = "test",
            UserType = "test"
        };
        if (userExists)
        {
            _dependentQueryServiceMock.Setup(q => q.GetUserByUserIdAsync(It.IsAny<string>()))
                .ReturnsAsync(user);
        }
        else
        {
            _dependentQueryServiceMock.Setup(q => q.GetUserByUserIdAsync(It.IsAny<string>()))
                .ReturnsAsync((Domain.V1.Entities.Users.User)null);
        }

        if (dependentExists)
        {
            var dependents = new List<Domain.V1.Entities.Dependent.Dependent>
            {
                new Domain.V1.Entities.Dependent.Dependent {
                    DependentUserID = 123 ,
                    CreatedDate = DateTime.UtcNow,
                    ID = 1,
                    IsDeleted = false,
                    Relationship = "test",
                    Status = true,
                    UserID = 456,
                }
            };

            _dependentQueryServiceMock.Setup(q => q.GetDependentByUserId(It.IsAny<long>()))
                .Returns(dependents);

            _dependentQueryServiceMock.Setup(q => q.GetDependentByUserIdandDependentId(It.IsAny<long>(), It.IsAny<long>()))
                .Returns(dependents.FirstOrDefault());
        }
        else
        {
            _dependentQueryServiceMock.Setup(q => q.GetDependentByUserId(It.IsAny<long>()))
                .Returns(new List<Domain.V1.Entities.Dependent.Dependent>());
        }

        _dependentCommandServiceMock.Setup(c => c.DeactivateUserDependent(It.IsAny<Domain.V1.Entities.Dependent.Dependent>()))
            .ReturnsAsync(deleteSuccess);

        if (isDependentNull)
            _dependentQueryServiceMock.Setup(q => q.GetDependentByUserIdandDependentId(It.IsAny<long>(), It.IsAny<long>()))
                .Returns((Domain.V1.Entities.Dependent.Dependent)null);
        // Act
        var result = await _controller.DeactivateUserDependent(1) as ObjectResult;

        // Assert
        Assert.NotNull(result);
        Assert.Equal(expectedStatus, result.StatusCode);
    }

    [Theory]
    [InlineData(false)]
    [InlineData(true)]
    public void GetChildProfileAsync_ShouldReturnExpectedStatus(bool verifyStatus)
    {
        // Arrange
        if (verifyStatus)
            _regionCodeHelperMock.Setup(r => r.VerifyRegionCodeHeader(It.IsAny<HttpRequest>()))
                .Returns(new GenericResponse<string> { HasError = false });
        else
            _regionCodeHelperMock.Setup(r => r.VerifyRegionCodeHeader(It.IsAny<HttpRequest>()))
                .Returns(new GenericResponse<string> { HasError = true });

        var dependent = new GetDependentProfileResponse
        {
            UHID = 123
        };
        _dependentQueryServiceMock.Setup(q => q.GetDependentProfileById(It.IsAny<long>()))
                .Returns(new GenericResponse<GetDependentProfileResponse> { HasError = false, IsSuccess = true, Result = dependent });

        // Act
        var result = _controller.GetChildProfileAsync(123) as ObjectResult;

        // Assert
        if (verifyStatus)
        {
            var response = Assert.IsType<GenericResponse<GetDependentProfileResponse>>(result.Value);
            Assert.True(response.IsSuccess);
            Assert.NotNull(response.Result);
        }
        else
        {
            var response = Assert.IsType<BadRequestObjectResult>(result);
            Assert.NotNull(result);
            Assert.Equal(400, result.StatusCode);
        }
    }

    [Theory]
    [InlineData(false, false)]
    [InlineData(true, false)]
    [InlineData(true, true)]
    public void GetPatientDependentAndOther_ShouldReturnExpectedStatus(bool verifyStatus, bool invalidUser)
    {
        // Arrange
        if (verifyStatus)
            _regionCodeHelperMock.Setup(r => r.VerifyRegionCodeHeader(It.IsAny<HttpRequest>()))
                .Returns(new GenericResponse<string> { HasError = false });
        else
            _regionCodeHelperMock.Setup(r => r.VerifyRegionCodeHeader(It.IsAny<HttpRequest>()))
                .Returns(new GenericResponse<string> { HasError = true });
        if (invalidUser)
            _regionCodeHelperMock.Setup(r => r.GetUserIdByToken(It.IsAny<HttpRequest>()))
            .Returns("123");
        else
            _regionCodeHelperMock.Setup(r => r.GetUserIdByToken(It.IsAny<HttpRequest>()))
            .Returns(string.Empty);

        var dependent = new List<GetDependentsWithCategory>
            {
                new GetDependentsWithCategory()
                {
                }
            };
        _dependentQueryServiceMock.Setup(q => q.GetDependentsWithCategory(It.IsAny<long>()))
                .Returns(new GenericResponseList<GetDependentsWithCategory> { HasError = false, IsSuccess = true, Results = dependent });

        // Act
        var result = _controller.GetPatientDependentAndOther() as ObjectResult;

        // Assert
        if (!verifyStatus || !invalidUser)
        {
            var response = Assert.IsType<BadRequestObjectResult>(result);
            Assert.NotNull(result);
            Assert.Equal(400, result.StatusCode);
        }
        else
        {
            var response = Assert.IsType<GenericResponseList<GetDependentsWithCategory>>(result.Value);
            Assert.True(response.IsSuccess);
            Assert.NotNull(response.Results);
        }
    }

    /// <summary>
    /// Helper method to create a mock DependentOtherRequestDto
    /// </summary>
    private DependentOtherRequestDto CreateMockDependentRequestDto()
    {
        return new DependentOtherRequestDto
        {
            Relationship = "Parent",
            Name = "John Doe",
            PhoneNumber = "1234567890",
            Country = "Malaysia",
            PhoneCountryCode = "+60",
            Gender = "Male",
            RelationshipCategory = "Family",
            Email = "john.doe@example.com",
            IdentifierNumber = "ID123456",
            IdentifierType = "NRIC",
            IdentifierPassport = "A1234567",
            PassportIssueCountry = "USA",
            PassportExpiryDate = DateTime.UtcNow.AddYears(5),
            DateOfBirth = new DateTime(1990, 01, 01, 0, 0, 0, DateTimeKind.Utc),
            IsValid = true
        };
    }

    #region Test Cases for Dependent Controller 
    /// <summary>
    /// Test case for invalid RegionCode
    /// </summary>
    [Fact]
    public async Task NewPatientDependent_ShouldReturn_BadRequest_WhenRegionCodeIsInvalid()
    {
        // Arrange
        var requestDto = CreateMockDependentRequestDto();

        _regionCodeHelperMock.Setup(x => x.VerifyRegionCodeHeader(It.IsAny<HttpRequest>()))
                         .Returns(new GenericResponse<string>
                         {
                             IsSuccess = false,
                             HasError = true,
                             StatusCode = ResponseStatus.STATUS_BadRequest,
                             Message = ResponseMessage.STATUS_INVALID_REGIONCODE
                         });

        // Act
        var result = await _controller.NewPatientDependent(requestDto) as BadRequestObjectResult;

        // Assert
        result.Should().NotBeNull();
        result.StatusCode.Should().Be((int)HttpStatusCode.BadRequest);

        var response = result.Value.Should().BeAssignableTo<GenericResponse<string>>().Subject;
        response.HasError.Should().BeTrue();
        response.Message.Should().Be(ResponseMessage.STATUS_INVALID_REGIONCODE);
    }

    [Fact]
    public async Task NewPatientDependent_ShouldReturnBadRequest_WhenRegionCodeHasError()
    {
        // Arrange
        var mockVerifyStatus = new GenericResponse<string>
        {
            IsSuccess = false,
            HasError = true,
            StatusCode = ResponseStatusCode.STATUS_BADREQUEST,
            Message = ValidationMessage.INVALID_REGION_CODE
        };

        _regionCodeHelperMock
            .Setup(helper => helper.VerifyRegionCodeHeader(It.IsAny<HttpRequest>()))
            .Returns(mockVerifyStatus);

        var requestDto = CreateMockDependentRequestDto(); // Create a mock DTO

        // Act
        var result = await _controller.NewPatientDependent(requestDto);

        // Assert
        var badRequestResult = Assert.IsType<BadRequestObjectResult>(result);
        var response = badRequestResult.Value as GenericResponse<string>;

        response.Should().NotBeNull();
        response!.IsSuccess.Should().BeFalse();
        response.HasError.Should().BeTrue();
        response.StatusCode.Should().Be(ResponseStatusCode.STATUS_BADREQUEST);
        response.Message.Should().Be(ValidationMessage.INVALID_REGION_CODE);

        _regionCodeHelperMock.Verify(x => x.VerifyRegionCodeHeader(It.IsAny<HttpRequest>()), Times.Once);
    }

    [Fact]
    public async Task NewPatientDependent_ShouldReturnBadRequest_WhenModelStateIsInvalid()
    {
        // Arrange
        var requestDto = CreateMockDependentRequestDto();
        _controller.ModelState.AddModelError("PatientName", "Patient name is required");

        // Act
        var result = await _controller.NewPatientDependent(requestDto);

        // Assert
        var badRequestResult = Assert.IsType<BadRequestObjectResult>(result);
        var modelState = badRequestResult.Value as SerializableError;

        modelState.Should().NotBeNull();
        modelState!.Should().ContainKey("PatientName");
        modelState["PatientName"].Should().BeOfType<string[]>().Which.Should().Contain("Patient name is required");

        // Verify that no service methods were called since ModelState is invalid
        _dependentCommandServiceMock.Verify(x => x.AddDependentOthersAsync(It.IsAny<DependentOtherRequestDto>(), It.IsAny<string>(), It.IsAny<string>(), It.IsAny<string>()), Times.Never);
    }

    [Fact]
    public async Task NewPatientDependent_ShouldReturnBadRequest_WhenUserIdIsInvalid()
    {
        // Arrange
        var requestDto = CreateMockDependentRequestDto();

        // Simulate invalid user ID returned from token
        _regionCodeHelperMock
            .Setup(helper => helper.GetUserIdByToken(It.IsAny<HttpRequest>()))
            .Returns(string.Empty);  // Invalid (empty) user ID

        // Act
        var result = await _controller.NewPatientDependent(requestDto);

        // Assert
        var badRequestResult = Assert.IsType<BadRequestObjectResult>(result);
        var response = badRequestResult.Value as GenericResponse<string>;

        response.Should().NotBeNull();
        response!.IsSuccess.Should().BeFalse();
        response.HasError.Should().BeTrue();
        response.StatusCode.Should().Be(ResponseStatus.STATUS_BadRequest);
        response.Message.Should().Be(ResponseMessage.STATUS_INVALID_REQUEST);

        // Verify the GetUserIdByToken method was called once
        _regionCodeHelperMock.Verify(x => x.GetUserIdByToken(It.IsAny<HttpRequest>()), Times.Once);

        // Ensure no service calls were made due to invalid user ID
        _dependentCommandServiceMock.Verify(x => x.AddDependentOthersAsync(It.IsAny<DependentOtherRequestDto>(), It.IsAny<string>(), It.IsAny<string>(), It.IsAny<string>()), Times.Never);
    }

    [Fact]
    public async Task NewPatientDependent_ShouldReturnBadRequest_WhenValidationFails()
    {
        // Arrange
        var requestDto = CreateMockDependentRequestDto();

        _regionCodeHelperMock.Setup(x => x.VerifyRegionCodeHeader(It.IsAny<HttpRequest>()))
                         .Returns(new GenericResponse<string> { IsSuccess = true, Result = "123" });

        _regionCodeHelperMock.Setup(x => x.GetUserIdByToken(It.IsAny<HttpRequest>()))
                         .Returns("123");

        var validationResponse = new GenericResponse<string>
        {
            IsSuccess = false,
            HasError = true,
            StatusCode = ResponseStatusCode.STATUS_BADREQUEST,
            Message = ResponseMessage.STATUS_INVALID_REQUEST // Replace with the actual error message
        };

        _validationHelperMock.Setup(x => x.SignupValidationForDepentent(It.IsAny<string>(), It.IsAny<DependentOtherRequestDto>()))
                             .Returns(validationResponse);

        // Act
        var result = await _controller.NewPatientDependent(requestDto);

        // Assert
        var badRequestResult = Assert.IsType<BadRequestObjectResult>(result);
        var response = badRequestResult.Value as GenericResponse<string>;

        response.Should().NotBeNull();
        response!.IsSuccess.Should().BeFalse();
        response.HasError.Should().BeTrue();
        response.StatusCode.Should().Be(ResponseStatusCode.STATUS_BADREQUEST);
        response.Message.Should().Be(ResponseMessage.STATUS_INVALID_REQUEST);

        _validationHelperMock.Verify(x => x.SignupValidationForDepentent(It.IsAny<string>(), It.IsAny<DependentOtherRequestDto>()), Times.Once);
    }

    [Fact]
    public async Task NewPatientDependent_ShouldReturnOkRequest()
    {
        // Arrange
        var requestDto = CreateMockDependentRequestDto();

        var mappedDto = new DependentOtherRequestDto
        {
            Name = requestDto.Name,
            Gender = requestDto.Gender,
            PhoneNumber = requestDto.PhoneNumber,
            PhoneCountryCode = requestDto.PhoneCountryCode,
            Email = requestDto.Email,
            DateOfBirth = requestDto.DateOfBirth,
            Relationship = requestDto.Relationship,
            RelationshipCategory = requestDto.RelationshipCategory,
            Country = requestDto.Country,
            PassportIssueCountry = requestDto.PassportIssueCountry,
            PassportExpiryDate = requestDto.PassportExpiryDate,
            IdentifierNumber = requestDto.IdentifierNumber
        };


        _regionCodeHelperMock.Setup(x => x.VerifyRegionCodeHeader(It.IsAny<HttpRequest>()))
                             .Returns(new GenericResponse<string> { IsSuccess = true, Result = "123" });

        _regionCodeHelperMock.Setup(x => x.GetUserIdByToken(It.IsAny<HttpRequest>()))
                             .Returns("123");

        var validationResponse = new GenericResponse<string>
        {
            IsSuccess = true,
            HasError = false,
            StatusCode = ResponseStatusCode.STATUS_SUCCESS,
            Message = ""
        };

        var responseDto = new ChildAndOthersResponseDto()
        {
            DependentId = 12,
            DependentUserId = 123
        };

        _validationHelperMock.Setup(x => x.SignupValidationForDepentent(It.IsAny<string>(), It.IsAny<DependentOtherRequestDto>()))
                             .Returns(validationResponse);

        _dependentCommandServiceMock.Setup(x => x.AddDependentOthersAsync(It.IsAny<DependentOtherRequestDto>(), It.IsAny<string>(), It.IsAny<string>(), It.IsAny<string>()))
                                    .ReturnsAsync(new GenericResponse<ChildAndOthersResponseDto>
                                    {
                                        StatusCode = ResponseStatusCode.STATUS_SUCCESS,
                                        IsSuccess = true,
                                        Result = responseDto,
                                        HasError = false
                                    });

        // Act
        var result = await _controller.NewPatientDependent(requestDto);

        // Assert
        var okResult = Assert.IsType<OkObjectResult>(result);
        var response = okResult.Value as GenericResponse<ChildAndOthersResponseDto>;

        response.Should().NotBeNull();
        response!.IsSuccess.Should().BeTrue();
        response.HasError.Should().BeFalse();
        response.StatusCode.Should().Be(ResponseStatusCode.STATUS_SUCCESS);
        response.Result.DependentId.Should().Be(responseDto.DependentId);

        // Verify Mappings and Service Calls
        _validationHelperMock.Verify(x => x.SignupValidationForDepentent(It.IsAny<string>(), It.IsAny<DependentOtherRequestDto>()), Times.Once);
        _dependentCommandServiceMock.Verify(x => x.AddDependentOthersAsync(It.IsAny<DependentOtherRequestDto>(), It.IsAny<string>(), It.IsAny<string>(), It.IsAny<string>()), Times.Once);
    }

    #endregion

    #region Test Cases for Update Dependent Controller 

    /// <summary>
    /// Creates a mock instance of UpdateDependentDto
    /// </summary>
    private static UpdateDependentDto CreateMockUpdateDependentDto()
    {
        return new UpdateDependentDto
        {
            Id = 1,
            Name = "John Doe",
            Gender = "Male",
            PhoneNumber = "1234567890",
            PhoneCountryCode = "+60",
            Email = "john.doe@example.com",
            DateOfBirth = new DateTime(1990, 01, 01),
            PassportNumber = "A1234567",
            Relationship = "Parent",
            RelationshipCategory = "Family",
            Country = "Malaysia",
            PassportIssueCountry = "USA",
            PassportExpiryDate = DateTime.UtcNow.AddYears(5),
            IdentifierNumber = "ID123456",
            IsValid = true
        };
    }

    /// <summary>
    /// Test case to verify BadRequest when ModelState is invalid
    /// </summary>
    [Fact]
    public async Task UpdatePatientDependentProfile_ShouldReturn_BadRequest_WhenModelStateIsInvalid()
    {
        // Arrange
        var invalidDto = CreateMockUpdateDependentDto();
        _controller.ModelState.AddModelError("Name", "Name is required");

        // Act
        var result = await _controller.UpdatePatientDependentProfile(invalidDto);

        // Assert
        var badRequestResult = Assert.IsType<BadRequestObjectResult>(result);
        var modelState = badRequestResult.Value as SerializableError;

        modelState.Should().NotBeNull();
        modelState!.Should().ContainKey("Name");
        modelState["Name"].Should().BeOfType<string[]>().Which.Should().Contain("Name is required");

        // Verify that no service methods were called due to invalid ModelState
        _dependentCommandServiceMock.Verify(x => x.UpdateDependentOthersAsync(It.IsAny<long>(), It.IsAny<UpdateDependentandOthersDto>()), Times.Never);
    }

    /// <summary>
    /// Test case to verify BadRequest when RegionCode is missing
    /// </summary>
    [Fact]
    public async Task UpdatePatientDependentProfile_ShouldReturn_BadRequest_WhenRegionCodeIsMissing()
    {
        // Arrange
        var updateDto = CreateMockUpdateDependentDto();

        _regionCodeHelperMock
            .Setup(x => x.VerifyRegionCodeHeader(It.IsAny<HttpRequest>()))
            .Returns((GenericResponse<string>)null);

        // Act
        var result = await _controller.UpdatePatientDependentProfile(updateDto);

        // Assert
        var badRequestResult = Assert.IsType<BadRequestObjectResult>(result);
        var response = badRequestResult.Value as GenericResponse<string>;

        response.Should().NotBeNull();
        response!.IsSuccess.Should().BeFalse();
        response.HasError.Should().BeTrue();
        response.StatusCode.Should().Be(ResponseStatus.STATUS_BadRequest);
        response.Message.Should().Be(Resource.RegionCodeRequired);

        _regionCodeHelperMock.Verify(x => x.VerifyRegionCodeHeader(It.IsAny<HttpRequest>()), Times.Once);
    }

    /// <summary>
    /// Test case to verify BadRequest when RegionCode validation fails
    /// </summary>
    [Fact]
    public async Task UpdatePatientDependentProfile_ShouldReturn_BadRequest_WhenRegionCodeIsInvalid()
    {
        // Arrange
        var updateDto = CreateMockUpdateDependentDto();

        var invalidRegionResponse = new GenericResponse<string>
        {
            HasError = true,
            StatusCode = ResponseStatusCode.STATUS_BADREQUEST,
            IsSuccess = false,
            Message = ResponseMessage.STATUS_INVALID_REGIONCODE
        };

        _regionCodeHelperMock
            .Setup(x => x.VerifyRegionCodeHeader(It.IsAny<HttpRequest>()))
            .Returns(invalidRegionResponse);

        // Act
        var result = await _controller.UpdatePatientDependentProfile(updateDto);

        // Assert
        var badRequestResult = Assert.IsType<BadRequestObjectResult>(result);
        var response = badRequestResult.Value as GenericResponse<string>;

        response.Should().NotBeNull();
        response!.IsSuccess.Should().BeFalse();
        response.HasError.Should().BeTrue();
        response.StatusCode.Should().Be(ResponseStatusCode.STATUS_BADREQUEST);
        response.Message.Should().Be(ResponseMessage.STATUS_INVALID_REGIONCODE);

        _regionCodeHelperMock.Verify(x => x.VerifyRegionCodeHeader(It.IsAny<HttpRequest>()), Times.Once);
    }

    /// <summary>
    /// Test case to verify BadRequest when UserId is invalid
    /// </summary>
    [Fact]
    public async Task UpdatePatientDependentProfile_ShouldReturn_BadRequest_WhenUserIdIsInvalid()
    {
        // Arrange
        var updateDto = CreateMockUpdateDependentDto();

        var regionResponse = new GenericResponse<string>
        {
            HasError = false,
            StatusCode = ResponseStatusCode.STATUS_SUCCESS,
            IsSuccess = true,
            Result = "US"
        };

        _regionCodeHelperMock
            .Setup(x => x.VerifyRegionCodeHeader(It.IsAny<HttpRequest>()))
            .Returns(regionResponse);

        // Simulate invalid (empty) user ID
        _regionCodeHelperMock
            .Setup(x => x.GetUserIdByToken(It.IsAny<HttpRequest>()))
            .Returns(string.Empty);

        // Act
        var result = await _controller.UpdatePatientDependentProfile(updateDto);

        // Assert
        var badRequestResult = Assert.IsType<BadRequestObjectResult>(result);
        var response = badRequestResult.Value as GenericResponse<string>;

        response.Should().NotBeNull();
        response!.IsSuccess.Should().BeFalse();
        response.HasError.Should().BeTrue();
        response.StatusCode.Should().Be(ResponseStatus.STATUS_BadRequest);
    }

    /// <summary>
    /// Test case to verify BadRequest when validation fails
    /// </summary>
    [Fact]
    public async Task UpdatePatientDependentProfile_ShouldReturn_BadRequest_WhenValidationFails()
    {
        // Arrange
        var updateDto = CreateMockUpdateDependentDto();

        var regionResponse = new GenericResponse<string>
        {
            HasError = false,
            StatusCode = ResponseStatusCode.STATUS_SUCCESS,
            IsSuccess = true,
            Result = "US"
        };

        var validationResponse = new GenericResponse<string>
        {
            HasError = true,
            StatusCode = ResponseStatusCode.STATUS_BADREQUEST,
            IsSuccess = false,
            Message = "Validation Failed"
        };

        _regionCodeHelperMock
            .Setup(x => x.VerifyRegionCodeHeader(It.IsAny<HttpRequest>()))
            .Returns(regionResponse);

        _validationHelperMock
            .Setup(x => x.SignupValidationForUpdateDepentent(It.IsAny<string>(), It.IsAny<UpdateDependentDto>()))
            .Returns(validationResponse);

        // Act
        var result = await _controller.UpdatePatientDependentProfile(updateDto);

        // Assert
        var badRequestResult = Assert.IsType<BadRequestObjectResult>(result);
        var response = badRequestResult.Value as GenericResponse<string>;

        response.Should().NotBeNull();
        response!.IsSuccess.Should().BeFalse();
        response.HasError.Should().BeTrue();
        response.StatusCode.Should().Be(ResponseStatusCode.STATUS_BADREQUEST);
        response.Message.Should().Be("Validation Failed");

        _validationHelperMock.Verify(x => x.SignupValidationForUpdateDepentent(It.IsAny<string>(), It.IsAny<UpdateDependentDto>()), Times.Once);
    }


    /// <summary>
    /// Test case to verify Ok result when the update is successful
    /// </summary>
    [Fact]
    public async Task UpdatePatientDependentProfile_ShouldReturn_Ok_WhenUpdateIsSuccessful()
    {
        // Arrange
        var updateDto = CreateMockUpdateDependentDto();

        var regionResponse = new GenericResponse<string>
        {
            HasError = false,
            StatusCode = ResponseStatusCode.STATUS_SUCCESS,
            IsSuccess = true,
            Result = "US"
        };

        var validationResponse = new GenericResponse<string>
        {
            HasError = false,
            StatusCode = ResponseStatusCode.STATUS_SUCCESS,
            IsSuccess = true,
            Message = "Valid"
        };

        var successResponse = new GenericResponse<ChildAndOthersResponseDto>
        {

            HasError = false,
            IsSuccess = true,
            Message = Resource.RecordUpdationMessage,
            StatusCode = ResponseStatus.STATUS_SUCCESS,
        };

        // Mock Region Code Validation
        _regionCodeHelperMock.Setup(x => x.VerifyRegionCodeHeader(It.IsAny<HttpRequest>()))
                             .Returns(regionResponse);

        // Mock User ID extraction
        _regionCodeHelperMock.Setup(x => x.GetUserIdByToken(It.IsAny<HttpRequest>()))
                             .Returns("123");

        // Mock Validation Helper
        _validationHelperMock.Setup(x => x.SignupValidationForUpdateDepentent(It.IsAny<string>(), It.IsAny<UpdateDependentDto>()))
                             .Returns(validationResponse);

        // Mock Mapper
        var mappedDto = new UpdateDependentandOthersDto
        {
            Region = "US",
            IdentificationType = "Valid",
            DateOfBirth = DateTime.Now.AddYears(-20)
        };

        _mapperMock.Setup(x => x.Map<UpdateDependentandOthersDto>(It.IsAny<UpdateDependentDto>()))
                   .Returns(mappedDto);

        // Mock Service Method
        _dependentCommandServiceMock.Setup(x => x.UpdateDependentOthersAsync(It.IsAny<long>(), It.IsAny<UpdateDependentandOthersDto>()))
                                    .ReturnsAsync(successResponse);

        // Act
        var result = await _controller.UpdatePatientDependentProfile(updateDto);

        // Assert
        var okResult = Assert.IsType<OkObjectResult>(result);
        var response = okResult.Value as GenericResponse<ChildAndOthersResponseDto>;

        response.Should().NotBeNull();
        response!.IsSuccess.Should().BeTrue();
        response.HasError.Should().BeFalse();
        response.StatusCode.Should().Be(ResponseStatusCode.STATUS_SUCCESS);

    }

    #endregion
}
