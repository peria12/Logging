﻿using Aurora.AdministrationService.API.Controllers.Marketing.Banner;
using Aurora.AdministrationService.API.Enum;
using Aurora.AdministrationService.API.Helper;
using Aurora.AdministrationService.API.Models.Dto.Marketing.Banner;
using Aurora.AdministrationService.API.Resources;
using Aurora.AdministrationService.API.Services.IService.Marketing.Banner;
using Aurora.AdministrationService.API.Services.Service.Marketing.Banner;
using Aurora.AdministrationService.CrossCutting.CommonModels;
using Aurora.AdministrationService.CrossCutting.Constants;
using FluentAssertions;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using Moq;

namespace Aurora.AdministrationService.Tests.API.Controllers.Marketing.Banner
{
    /// <summary>
    /// Added test cases banner controller methods
    /// </summary>
    public class BannerControllerTests
    {
        private readonly Mock<IRegionCodeValidationHelper> _mockRegionCodeValidationHelper;
        private readonly Mock<IBannerQueryService> _mockBannerQueryService;
        private readonly Mock<IBannerCommandService> _mockBannerCommandService;
        private readonly BannerController _controller;

        public BannerControllerTests()
        {
            _mockRegionCodeValidationHelper = new Mock<IRegionCodeValidationHelper>();
            _mockBannerQueryService = new Mock<IBannerQueryService>();
            _mockBannerCommandService = new Mock<IBannerCommandService>();
            _controller = new BannerController(_mockBannerQueryService.Object, _mockRegionCodeValidationHelper.Object, _mockBannerCommandService.Object);
        }

        [Fact]
        public async Task GetMarketingMainBanner_ReturnsBadRequest_WhenRegionCodeIsInvalid()
        {
            // Arrange
            var mockedResponse = new GenericResponse<string>
            {
                IsSuccess = false,
                HasError = true,
                StatusCode = ResponseStatus.STATUS_BadRequest,
                Message = Resource.RegionCodeRequired
            };

            _mockRegionCodeValidationHelper.Setup(x => x.VerifyRegionCodeHeader(It.IsAny<HttpRequest>()))
                .Returns(mockedResponse);

            // Act
            var result = await _controller.GetMarketingMainBanner();

            // Assert
            result.Should().BeOfType<BadRequestObjectResult>();
        }

        [Fact]
        public async Task GetMarketingMainBanner_ReturnsOk_WhenRegionCodeIsValid()
        {
            // Arrange
            var regionCode = "MYS";
            var mockResponse = new GenericResponse<string>
            {
                IsSuccess = true,
                HasError = false,
                StatusCode = ResponseStatus.STATUS_SUCCESS,
                Message = null,
                Result = regionCode
            };

            var context = new DefaultHttpContext();
            var request = context.Request;
            request.Headers["RegionCode"] = regionCode;

            _mockRegionCodeValidationHelper.Setup(x => x.VerifyRegionCodeHeader(request))
            .Returns(mockResponse);

            var banners = new GenericResponse<List<GetBannerDto>>()
            {
                Result = new List<GetBannerDto>() { new GetBannerDto { ID = 1, Url = "https://example.com", ImageUrl = "image1.jpg", Title = "Banner 1", IsActive = true, StartDate = DateTime.UtcNow, EndDate = DateTime.UtcNow } }
            };

            _mockBannerQueryService.Setup(x => x.GetMarketingMainBanners())
                  .ReturnsAsync(banners);

            // Act
            var result = await _controller.GetMarketingMainBanner();

            // Assert
            result.Should().BeOfType<OkObjectResult>();
            var okResult = result as OkObjectResult;
            okResult?.Value.Should().BeEquivalentTo(banners);
        }

        [Fact]
        public async Task GetMarketingMainBanner_ReturnsInternalServerError_WhenExceptionOccurs()
        {
            // Arrange
            var regionCode = "MYS";

            var context = new DefaultHttpContext();
            var request = context.Request;
            request.Headers["RegionCode"] = regionCode;

            var mockedResponse = new GenericResponse<string>
            {
                IsSuccess = false,
                HasError = true,
                StatusCode = ResponseStatus.STATUS_BadRequest,
                Message = Resource.RegionCodeRequired
            };

            _mockRegionCodeValidationHelper.Setup(x => x.VerifyRegionCodeHeader(It.IsAny<HttpRequest>()))
                .Returns(mockedResponse);

            _mockBannerQueryService.Setup(x => x.GetMarketingMainBanners())
                .ThrowsAsync(new System.Exception("Something went wrong"));

            // Act
            var result = await _controller.GetMarketingMainBanner();

            // Assert
            result.Should().BeOfType<BadRequestObjectResult>();
        }

        [Fact]
        public async Task AddBanner_ReturnsBadRequest_WhenRegionCodeIsInvalid()
        {
            // Arrange
            var mockedResponse = new GenericResponse<string>
            {
                IsSuccess = false,
                HasError = true,
                StatusCode = ResponseStatus.STATUS_BadRequest,
                Message = Resource.RegionCodeRequired
            };

            _mockRegionCodeValidationHelper.Setup(x => x.VerifyRegionCodeHeader(It.IsAny<HttpRequest>()))
                .Returns(mockedResponse);

            var request = new BannerDto
            {
                Title = "Test Banner",
                Status = false,
                URL = "https://example.com"
            };

            // Act
            var result = await _controller.AddBanner(request);

            // Assert
            result.Should().BeOfType<BadRequestObjectResult>();
        }

        [Fact]
        public async Task AddBanner_ReturnsBadRequest_WhenModelStateIsInvalid()
        {
            // Arrange
            var request = new BannerDto
            {
                Title = "", // Invalid: empty title, assuming Title is required
                Status = true,
                URL = "https://example.com"
            };

            // Manually set the ModelState to invalid by adding an error.
            _controller.ModelState.AddModelError("Title", "The Title field is required.");

            _mockRegionCodeValidationHelper.Setup(x => x.VerifyRegionCodeHeader(It.IsAny<HttpRequest>()))
                .Returns(new GenericResponse<string> { IsSuccess = true });

            // Act
            var result = await _controller.AddBanner(request);

            // Assert
            result.Should().BeOfType<BadRequestObjectResult>();
        }

        [Fact]
        public async Task AddBanner_ReturnsBadRequest_WhenStartDateIsGreaterThanEndDate()
        {
            // Arrange
            var request = new BannerDto
            {
                Title = "Banner Title",
                URL = "https://example.com/banner1",
                ImageUrl = "https://example.com/images/banner1",
                StartDate = DateTime.UtcNow.AddDays(1), // StartDate is greater than EndDate
                EndDate = DateTime.UtcNow,
                Status = true
            };

            _mockRegionCodeValidationHelper.Setup(x => x.VerifyRegionCodeHeader(It.IsAny<HttpRequest>()))
                .Returns(new GenericResponse<string> { IsSuccess = true });

            // Act
            var result = await _controller.AddBanner(request);

            // Assert
            result.Should().BeOfType<BadRequestObjectResult>();

            var badRequestResult = result as BadRequestObjectResult;
            badRequestResult.Should().NotBeNull();

            var response = badRequestResult?.Value as GenericResponse<string>;
            response.Should().NotBeNull();
            response?.HasError.Should().BeTrue();
            response?.Message.Should().Be("StartDate must be less than or equal to EndDate.");
            response?.MessageType.Should().Be(CommonConstants.VALIDATION);
        }

        [Fact]
        public async Task AddBanner_ReturnsOk_WhenBannerIsCreatedSuccessfully()
        {
            // Arrange
            var request = new BannerDto
            {
                Title = "Test Banner",
                Status = true,
                EndDate = DateTime.UtcNow.AddDays(5),
                ImageUrl = "ImageUrl",
                StartDate = DateTime.UtcNow,
                URL = "https://example.com"
            };

            var mockResponse = new GenericResponse<BannerDto>
            {
                IsSuccess = true,
                HasError = false,
                StatusCode = ResponseStatus.STATUS_SUCCESS,
                Message = "Banner created successfully",
                Result = request
            };

            _mockRegionCodeValidationHelper.Setup(x => x.VerifyRegionCodeHeader(It.IsAny<HttpRequest>()))
                .Returns(new GenericResponse<string>
                {
                    IsSuccess = true,
                    HasError = false,
                    StatusCode = ResponseStatus.STATUS_SUCCESS
                });

            _mockBannerCommandService.Setup(x => x.CreateBanner(It.IsAny<BannerDto>()))
                .ReturnsAsync(mockResponse);

            // Act
            var result = await _controller.AddBanner(request);

            // Assert
            result.Should().BeOfType<OkObjectResult>();
            var okResult = result as OkObjectResult;
            okResult?.Value.Should().BeEquivalentTo(mockResponse);
        }

        [Fact]
        public async Task AddBanner_ReturnsBadRequest_WhenBannerCreationFails()
        {
            // Arrange
            var request = new BannerDto
            {
                Title = "Test Banner",
                Status = true,
                URL = "https://example.com"
            };

            var mockResponse = new GenericResponse<BannerDto>
            {
                IsSuccess = false,
                HasError = true,
                StatusCode = ResponseStatus.STATUS_BadRequest,
                Message = "Banner creation failed"
            };

            _mockRegionCodeValidationHelper.Setup(x => x.VerifyRegionCodeHeader(It.IsAny<HttpRequest>()))
                .Returns(new GenericResponse<string>
                {
                    IsSuccess = true,
                    HasError = false,
                    StatusCode = ResponseStatus.STATUS_SUCCESS
                });

            _mockBannerCommandService.Setup(x => x.CreateBanner(It.IsAny<BannerDto>()))
                .ReturnsAsync(mockResponse);

            // Act
            var result = await _controller.AddBanner(request);

            // Assert
            result.Should().BeOfType<BadRequestObjectResult>();
            var badRequestResult = result as BadRequestObjectResult;
            badRequestResult?.Value.Should().BeEquivalentTo(mockResponse);
        }

        [Fact]
        public async Task UpdateBanner_ReturnsBadRequest_WhenRegionCodeIsInvalid()
        {
            // Arrange
            var mockedResponse = new GenericResponse<string>
            {
                IsSuccess = false,
                HasError = true,
                StatusCode = ResponseStatus.STATUS_BadRequest,
                Message = Resource.RegionCodeRequired
            };

            _mockRegionCodeValidationHelper.Setup(x => x.VerifyRegionCodeHeader(It.IsAny<HttpRequest>()))
                .Returns(mockedResponse);

            var request = new UpdateBannerRequest
            {
                Title = "Updated Test Banner",
                Status = true,
                URL = "https://updatedexample.com"
            };

            // Act
            var result = await _controller.UpdateBanner(1, request);

            // Assert
            result.Should().BeOfType<BadRequestObjectResult>();
        }

        [Fact]
        public async Task UpdateBanner_ReturnsOk_WhenBannerIsUpdatedSuccessfully()
        {
            // Arrange
            var request = new UpdateBannerRequest
            {
                Title = "Updated Test Banner",
                Status = true,
                EndDate = DateTime.UtcNow.AddDays(5),
                ImageUrl = "UpdatedImageUrl",
                StartDate = DateTime.UtcNow,
                URL = "https://updatedexample.com"
            };

            var banner = new Domain.V1.Entities.Banner
            {
                ID = 1,
                Title = "Test Banner",
                Status = false,
                URL = "https://example.com",
                CreatedBy = "testUser",
                CreatedDate = DateTime.UtcNow,
                IsDeleted = false,
                UpdatedDate = DateTime.UtcNow,
            };

            var mockResponse = new GenericResponse<UpdateBannerRequest>
            {
                IsSuccess = true,
                HasError = false,
                StatusCode = ResponseStatus.STATUS_SUCCESS,
                Message = "Banner updated successfully"
            };

            _mockRegionCodeValidationHelper.Setup(x => x.VerifyRegionCodeHeader(It.IsAny<HttpRequest>()))
                .Returns(new GenericResponse<string> { IsSuccess = true });

            _mockBannerQueryService.Setup(x => x.FindBannerById(1))
                .ReturnsAsync(banner);

            _mockBannerCommandService.Setup(x => x.UpdateBanner(It.IsAny<UpdateBannerRequest>(), banner))
                .ReturnsAsync(mockResponse);

            // Act
            var result = await _controller.UpdateBanner(1, request);

            // Assert
            result.Should().BeOfType<OkObjectResult>();
            var okResult = result as OkObjectResult;
            okResult?.Value.Should().BeEquivalentTo(mockResponse);
        }

        [Fact]
        public async Task UpdateBanner_ReturnsBadRequest_WhenModelStateIsInvalid()
        {
            // Arrange
            var request = new UpdateBannerRequest
            {
                Title = "",
                Status = true,
                URL = "https://example.com"
            };

            _controller.ModelState.AddModelError("Title", "The Title field is required.");

            _mockRegionCodeValidationHelper.Setup(x => x.VerifyRegionCodeHeader(It.IsAny<HttpRequest>()))
                .Returns(new GenericResponse<string> { IsSuccess = true });

            _mockBannerQueryService.Setup(x => x.FindBannerById(It.IsAny<long>()))
                .ReturnsAsync(new Domain.V1.Entities.Banner { ID = 1, CreatedBy = "testUser", CreatedDate = DateTime.UtcNow, IsDeleted = false, Title = "", UpdatedDate = DateTime.UtcNow });

            // Act
            var result = await _controller.UpdateBanner(1, request);

            // Assert
            result.Should().BeOfType<BadRequestObjectResult>();
        }

        [Fact]
        public async Task UpdateBanner_ReturnsBadRequest_WhenStartDateIsGreaterThanEndDate()
        {
            // Arrange
            var request = new UpdateBannerRequest
            {
                Title = "Banner Title",
                URL = "https://example.com/banner1",
                ImageUrl = "https://example.com/images/banner1",
                StartDate = DateTime.UtcNow.AddDays(1), // StartDate is greater than EndDate
                EndDate = DateTime.UtcNow,
                Status = true
            };

            _mockRegionCodeValidationHelper.Setup(x => x.VerifyRegionCodeHeader(It.IsAny<HttpRequest>()))
                .Returns(new GenericResponse<string> { IsSuccess = true });

            _mockBannerQueryService.Setup(x => x.FindBannerById(It.IsAny<long>()))
                .ReturnsAsync(new Domain.V1.Entities.Banner
                {
                    ID = 1,
                    CreatedBy = "testUser",
                    CreatedDate = DateTime.UtcNow,
                    IsDeleted = false,
                    Title = "Existing Banner",
                    UpdatedDate = DateTime.UtcNow
                });

            // Act
            var result = await _controller.UpdateBanner(1, request);

            // Assert
            result.Should().BeOfType<BadRequestObjectResult>();

            var badRequestResult = result as BadRequestObjectResult;
            badRequestResult.Should().NotBeNull();

            var response = badRequestResult?.Value as GenericResponse<string>;
            response.Should().NotBeNull();
            response?.HasError.Should().BeTrue();
            response?.Message.Should().Be("StartDate must be less than or equal to EndDate.");
            response?.MessageType.Should().Be(CommonConstants.VALIDATION);
        }

        [Fact]
        public async Task UpdateBanner_ReturnsNotFound_WhenBannerIdNotFound()
        {
            // Arrange
            var request = new UpdateBannerRequest
            {
                Title = "Updated Test Banner",
                Status = true,
                URL = "https://updatedexample.com"
            };

            var mockResponse = new GenericResponse<string>
            {
                IsSuccess = false,
                HasError = true,
                StatusCode = ResponseStatus.STATUS_NotFound,
                Message = Resource.RecordNotFound,
                MessageType = CommonConstants.VALIDATION,
            };

            _mockRegionCodeValidationHelper.Setup(x => x.VerifyRegionCodeHeader(It.IsAny<HttpRequest>()))
                .Returns(new GenericResponse<string> { IsSuccess = true });

            _mockBannerQueryService.Setup(x => x.FindBannerById(It.IsAny<long>()))
                .ReturnsAsync((Domain.V1.Entities.Banner?)null);

            // Act
            var result = await _controller.UpdateBanner(999, request); // ID 999 does not exist

            // Assert
            result.Should().BeOfType<NotFoundObjectResult>();
            var badRequestResult = result as NotFoundObjectResult;
            badRequestResult?.Value.Should().BeEquivalentTo(mockResponse);
        }

        [Fact]
        public async Task UpdateBanner_ReturnsBadRequest_WhenUpdatedFails()
        {
            // Arrange
            var request = new UpdateBannerRequest
            {
                Title = "Updated Test Banner",
                Status = true,
                EndDate = DateTime.UtcNow.AddDays(5),
                ImageUrl = "UpdatedImageUrl",
                StartDate = DateTime.UtcNow,
                RecordVersion = [1,2,3,4],
                URL = "https://updatedexample.com"
            };

            var banner = new Domain.V1.Entities.Banner
            {
                ID = 1,
                Title = "Test Banner",
                Status = true,
                URL = "https://example.com",
                CreatedBy = "testUser",
                CreatedDate = DateTime.UtcNow,
                IsDeleted = false,
                RecordVersion = [1,2,3,5],
                UpdatedDate = DateTime.UtcNow,
            };

            var mockResponse = new GenericResponse<UpdateBannerRequest>
            {
                IsSuccess = false,
                HasError = true,
                StatusCode = ResponseStatus.STATUS_BadRequest,
                Message = "RecordVersion mismatch. Update failed."
            };

            _mockRegionCodeValidationHelper.Setup(x => x.VerifyRegionCodeHeader(It.IsAny<HttpRequest>()))
                .Returns(new GenericResponse<string> { IsSuccess = true });

            _mockBannerQueryService.Setup(x => x.FindBannerById(1))
                .ReturnsAsync(banner);

            _mockBannerCommandService.Setup(x => x.UpdateBanner(request, banner))
                .ReturnsAsync(mockResponse);

            // Act
            var result = await _controller.UpdateBanner(1, request);

            // Assert
            result.Should().BeOfType<BadRequestObjectResult>();
            var okResult = result as BadRequestObjectResult;
            okResult?.Value.Should().BeEquivalentTo(mockResponse);
        }

        [Fact]
        public async Task UpdateBanner_ReturnsBadRequest_WhenDbUpdateConcurrencyExceptionIsThrown()
        {
            // Arrange
            var request = new UpdateBannerRequest
            {
                Title = "Updated Test Banner",
                Status = true,
                EndDate = DateTime.UtcNow.AddDays(5),
                ImageUrl = "UpdatedImageUrl",
                StartDate = DateTime.UtcNow,
                RecordVersion = [1, 2, 3, 4],
                URL = "https://updatedexample.com"
            };

            var banner = new Domain.V1.Entities.Banner
            {
                ID = 1,
                Title = "Test Banner",
                Status = true,
                URL = "https://example.com",
                CreatedBy = "testUser",
                CreatedDate = DateTime.UtcNow,
                IsDeleted = false,
                RecordVersion = [1, 2, 3, 5], // Simulate a version mismatch
                UpdatedDate = DateTime.UtcNow,
            };

            _mockRegionCodeValidationHelper.Setup(x => x.VerifyRegionCodeHeader(It.IsAny<HttpRequest>()))
                .Returns(new GenericResponse<string> { IsSuccess = true });

            _mockBannerQueryService.Setup(x => x.FindBannerById(1))
                .ReturnsAsync(banner);

            // Mock the UpdateBanner method to throw DbUpdateConcurrencyException
            _mockBannerCommandService.Setup(x => x.UpdateBanner(request, banner))
                .ThrowsAsync(new DbUpdateConcurrencyException("Concurrency conflict occurred."));

            // Act
            var result = await _controller.UpdateBanner(1, request);

            // Assert
            result.Should().BeOfType<BadRequestObjectResult>();

            var badRequestResult = result as BadRequestObjectResult;
            badRequestResult.Should().NotBeNull();

            var response = badRequestResult?.Value as GenericResponse<string>;
            response.Should().NotBeNull();
            response?.HasError.Should().BeTrue();
            response?.StatusCode.Should().Be(ResponseStatusCode.STATUS_BADREQUEST);
            response?.Message.Should().Be(CommonConstants.ERROR_DB_CONCURRENCY);
            response?.MessageType.Should().Be(CommonConstants.ERROR);
        }

        [Fact]
        public async Task UpdateBannerStatus_ReturnsBadRequest_WhenRegionCodeIsInvalid()
        {
            // Arrange
            var mockedResponse = new GenericResponse<string>
            {
                IsSuccess = false,
                HasError = true,
                StatusCode = ResponseStatus.STATUS_BadRequest,
                Message = Resource.RegionCodeRequired
            };

            _mockRegionCodeValidationHelper.Setup(x => x.VerifyRegionCodeHeader(It.IsAny<HttpRequest>()))
                .Returns(mockedResponse);

            var request = new UpdateBannerStatusRequest
            {
                Status = true
            };

            // Act
            var result = await _controller.UpdateBannerStatus(1, request);

            // Assert
            result.Should().BeOfType<BadRequestObjectResult>();
        }

        [Fact]
        public async Task UpdateBannerStatus_ReturnsBadRequest_WhenModelStateIsInvalid()
        {
            // Arrange
            var request = new UpdateBannerStatusRequest
            {
                Status = true // Simulate invalid model state (you can add more validation rules in the actual model)
            };

            _controller.ModelState.AddModelError("Status", "The Status field is required.");

            _mockRegionCodeValidationHelper.Setup(x => x.VerifyRegionCodeHeader(It.IsAny<HttpRequest>()))
                .Returns(new GenericResponse<string> { IsSuccess = true });

            // Act
            var result = await _controller.UpdateBannerStatus(1, request);

            // Assert
            result.Should().BeOfType<BadRequestObjectResult>();
        }

        [Fact]
        public async Task UpdateBannerStatus_ReturnsNotFound_WhenBannerIdNotFound()
        {
            // Arrange
            var request = new UpdateBannerStatusRequest
            {
                Status = true
            };

            var mockResponse = new GenericResponse<string>
            {
                IsSuccess = false,
                HasError = true,
                StatusCode = ResponseStatus.STATUS_NotFound,
                Message = Resource.RecordNotFound,
                MessageType = CommonConstants.VALIDATION
            };

            _mockRegionCodeValidationHelper.Setup(x => x.VerifyRegionCodeHeader(It.IsAny<HttpRequest>()))
                .Returns(new GenericResponse<string> { IsSuccess = true });

            _mockBannerQueryService.Setup(x => x.FindBannerById(It.IsAny<long>()))
                .ReturnsAsync((Domain.V1.Entities.Banner?)null);

            // Act
            var result = await _controller.UpdateBannerStatus(999, request); // ID 999 does not exist

            // Assert
            result.Should().BeOfType<NotFoundObjectResult>();
            var badRequestResult = result as NotFoundObjectResult;
            badRequestResult?.Value.Should().BeEquivalentTo(mockResponse);
        }

        [Fact]
        public async Task UpdateBannerStatus_ReturnsOk_WhenStatusUpdatedSuccessfully()
        {
            // Arrange
            var request = new UpdateBannerStatusRequest
            {
                Status = true
            };

            var banner = new Domain.V1.Entities.Banner
            {
                ID = 1,
                Title = "Test Banner",
                Status = false,
                URL = "https://example.com",
                CreatedBy = "testUser",
                CreatedDate = DateTime.UtcNow,
                IsDeleted = false,
                UpdatedDate = DateTime.UtcNow,
                RecordVersion = new byte[] { 1, 2, 3, 4 }
            };

            var mockResponse = new GenericResponse<UpdateBannerRequest>
            {
                IsSuccess = true,
                HasError = false,
                StatusCode = ResponseStatus.STATUS_SUCCESS,
                Message = "Banner status updated successfully"
            };

            _mockRegionCodeValidationHelper.Setup(x => x.VerifyRegionCodeHeader(It.IsAny<HttpRequest>()))
                .Returns(new GenericResponse<string> { IsSuccess = true });

            _mockBannerQueryService.Setup(x => x.FindBannerById(1))
                .ReturnsAsync(banner);

            _mockBannerCommandService.Setup(x => x.UpdateBanner(It.IsAny<UpdateBannerRequest>(), banner))
                .ReturnsAsync(mockResponse);

            // Act
            var result = await _controller.UpdateBannerStatus(1, request);

            // Assert
            result.Should().BeOfType<OkObjectResult>();
            var okResult = result as OkObjectResult;
            okResult?.Value.Should().BeEquivalentTo(mockResponse);
        }

        [Fact]
        public async Task UpdateBannerStatus_ReturnsBadRequest_WhenUpdateFails()
        {
            // Arrange
            var request = new UpdateBannerStatusRequest
            {
                Status = true
            };

            var banner = new Domain.V1.Entities.Banner
            {
                ID = 1,
                Title = "Test Banner",
                Status = false,
                URL = "https://example.com",
                CreatedBy = "testUser",
                CreatedDate = DateTime.UtcNow,
                IsDeleted = false,
                RecordVersion = new byte[] { 1, 2, 3, 4 },
                UpdatedDate = DateTime.UtcNow
            };

            var mockResponse = new GenericResponse<UpdateBannerRequest>
            {
                IsSuccess = false,
                HasError = true,
                StatusCode = ResponseStatus.STATUS_BadRequest,
                Message = "RecordVersion mismatch. Update failed."
            };

            _mockRegionCodeValidationHelper.Setup(x => x.VerifyRegionCodeHeader(It.IsAny<HttpRequest>()))
                .Returns(new GenericResponse<string> { IsSuccess = true });

            _mockBannerQueryService.Setup(x => x.FindBannerById(1))
                .ReturnsAsync(banner);

            _mockBannerCommandService.Setup(x => x.UpdateBanner(It.IsAny<UpdateBannerRequest>(), banner))
                .ReturnsAsync(mockResponse);

            // Act
            var result = await _controller.UpdateBannerStatus(1, request);

            // Assert
            result.Should().BeOfType<BadRequestObjectResult>();
            var badRequestResult = result as BadRequestObjectResult;
            badRequestResult?.Value.Should().BeEquivalentTo(mockResponse);
        }

        [Fact]
        public async Task UpdateBannerStatus_ReturnsBadRequest_WhenDbUpdateConcurrencyExceptionIsThrown()
        {
            // Arrange
            var id = 1; // Banner ID to update
            var request = new UpdateBannerStatusRequest
            {
                Status = false, // New status
            };

            var banner = new Domain.V1.Entities.Banner
            {
                ID = id,
                Title = "Test Banner",
                Status = true,
                URL = "https://example.com",
                CreatedBy = "testUser",
                CreatedDate = DateTime.UtcNow,
                IsDeleted = false,
                RecordVersion = new byte[] { 1, 2, 3, 4 }, // Simulate a version mismatch
                UpdatedDate = DateTime.UtcNow,
            };

            // Mock the FindBannerById method to return the banner
            _mockBannerQueryService.Setup(x => x.FindBannerById(id))
                .ReturnsAsync(banner);

            // Mock the UpdateBanner method to throw DbUpdateConcurrencyException
            _mockBannerCommandService.Setup(x => x.UpdateBanner(It.IsAny<UpdateBannerRequest>(), banner))
                .ThrowsAsync(new DbUpdateConcurrencyException("Concurrency conflict occurred."));

            // Act
            var result = await _controller.UpdateBannerStatus(id, request);

            // Assert
            result.Should().BeOfType<BadRequestObjectResult>();

            var badRequestResult = result as BadRequestObjectResult;
            badRequestResult.Should().NotBeNull();

            var response = badRequestResult?.Value as GenericResponse<string>;
            response.Should().NotBeNull();
            response?.HasError.Should().BeTrue();
            response?.StatusCode.Should().Be(ResponseStatusCode.STATUS_BADREQUEST);
            response?.Message.Should().Be(CommonConstants.ERROR_DB_CONCURRENCY);
            response?.MessageType.Should().Be(CommonConstants.ERROR);
        }

        [Fact]
        public async Task DeleteBanner_ReturnsBadRequest_WhenRegionCodeIsInvalid()
        {
            // Arrange
            var mockedResponse = new GenericResponse<string>
            {
                IsSuccess = false,
                HasError = true,
                StatusCode = ResponseStatus.STATUS_BadRequest,
                Message = Resource.RegionCodeRequired
            };

            _mockRegionCodeValidationHelper.Setup(x => x.VerifyRegionCodeHeader(It.IsAny<HttpRequest>()))
                .Returns(mockedResponse);

            // Act
            var result = await _controller.DeleteBanner(1);

            // Assert
            result.Should().BeOfType<BadRequestObjectResult>();
        }

        [Fact]
        public async Task DeleteBanner_ReturnsBadRequest_WhenModelStateIsInvalid()
        {
            // Arrange
            _controller.ModelState.AddModelError("RecordVersion", "The RecordVersion field is required.");

            _mockRegionCodeValidationHelper.Setup(x => x.VerifyRegionCodeHeader(It.IsAny<HttpRequest>()))
                .Returns(new GenericResponse<string> { IsSuccess = true });

            // Act
            var result = await _controller.DeleteBanner(1);

            // Assert
            result.Should().BeOfType<BadRequestObjectResult>();
        }

        [Fact]
        public async Task DeleteBanner_ReturnsNotFound_WhenBannerIdNotFound()
        {
            // Arrange
            var mockResponse = new GenericResponse<string>
            {
                IsSuccess = false,
                HasError = true,
                StatusCode = ResponseStatus.STATUS_NotFound,
                Message = Resource.RecordNotFound,
                MessageType = CommonConstants.VALIDATION,
            };

            _mockRegionCodeValidationHelper.Setup(x => x.VerifyRegionCodeHeader(It.IsAny<HttpRequest>()))
                .Returns(new GenericResponse<string> { IsSuccess = true });

            _mockBannerQueryService.Setup(x => x.FindBannerById(It.IsAny<long>()))
                .ReturnsAsync((Domain.V1.Entities.Banner?)null);

            // Act
            var result = await _controller.DeleteBanner(999); // ID 999 does not exist

            // Assert
            result.Should().BeOfType<NotFoundObjectResult>();
            var badRequestResult = result as NotFoundObjectResult;
            badRequestResult?.Value.Should().BeEquivalentTo(mockResponse);
        }

        [Fact]
        public async Task DeleteBanner_ReturnsOk_WhenBannerIsDeletedSuccessfully()
        {
            // Arrange
            var banner = new Domain.V1.Entities.Banner
            {
                ID = 1,
                Title = "Test Banner",
                Status = false,
                URL = "https://example.com",
                CreatedBy = "testUser",
                CreatedDate = DateTime.UtcNow,
                IsDeleted = false,
                UpdatedDate = DateTime.UtcNow,
            };

            var mockResponse = new GenericResponse<string>
            {
                IsSuccess = true,
                HasError = false,
                StatusCode = ResponseStatus.STATUS_SUCCESS_Create,
                Result = ResponseMessage.STATUS_DATA_DELETED,
                Message = Resource.RecordUpdationMessage
            };

            _mockRegionCodeValidationHelper.Setup(x => x.VerifyRegionCodeHeader(It.IsAny<HttpRequest>()))
                .Returns(new GenericResponse<string> { IsSuccess = true });

            _mockBannerQueryService.Setup(x => x.FindBannerById(1))
                .ReturnsAsync(banner);

            _mockBannerCommandService.Setup(x => x.DeleteBanner(It.IsAny<byte[]>(), banner))
                .ReturnsAsync(mockResponse); // Simulate successful deletion

            // Act
            var result = await _controller.DeleteBanner(1);

            // Assert
            result.Should().BeOfType<OkObjectResult>();
            var okResult = result as OkObjectResult;
            okResult?.Value.Should().BeEquivalentTo(mockResponse);
        }

        [Fact]
        public async Task DeleteBanner_ReturnsBadRequest_WhenDeleteFails()
        {
            // Arrange
            var banner = new Domain.V1.Entities.Banner
            {
                ID = 1,
                Title = "Test Banner",
                Status = false,
                URL = "https://example.com",
                CreatedBy = "testUser",
                CreatedDate = DateTime.UtcNow,
                IsDeleted = false,
                UpdatedDate = DateTime.UtcNow,
            };

            var mockResponse = new GenericResponse<string>
            {
                IsSuccess = false,
                HasError = true,
                StatusCode = ResponseStatus.STATUS_BadRequest,
                Message = "Failed to delete the banner"
            };

            _mockRegionCodeValidationHelper.Setup(x => x.VerifyRegionCodeHeader(It.IsAny<HttpRequest>()))
                .Returns(new GenericResponse<string> { IsSuccess = true });

            _mockBannerQueryService.Setup(x => x.FindBannerById(1))
                .ReturnsAsync(banner);

            _mockBannerCommandService.Setup(x => x.DeleteBanner(It.IsAny<byte[]>(), banner))
                .ReturnsAsync(mockResponse); // Simulate failed deletion

            // Act
            var result = await _controller.DeleteBanner(1);

            // Assert
            result.Should().BeOfType<BadRequestObjectResult>();
            var badRequestResult = result as BadRequestObjectResult;
            badRequestResult?.Value.Should().BeEquivalentTo(mockResponse);
        }

        [Fact]
        public async Task GetBannerDetailById_ShouldReturnOk_WhenBannerExists()
        {
            // Arrange
            int bannerId = 1;
            var banner = new Domain.V1.Entities.Banner
            {
                ID = bannerId,
                Title = "Test Banner",
                URL = "http://example.com",
                ImageUrl = "http://example.com/image.jpg",
                StartDate = DateTime.UtcNow,
                EndDate = DateTime.UtcNow.AddDays(1),
                Status = true,
                RecordVersion = [ 1, 2, 3, 4 ],
                CreatedBy = "testUser",
                CreatedDate = DateTime.UtcNow,
                IsDeleted = false,
                UpdatedDate = DateTime.UtcNow,
                UpdatedBy = "testUser"
            };

            // Mock GetBannerDetailById to return the banner
            var mockBannerResponse = new GenericResponse<GetBannerDetailDto>
            {
                IsSuccess = true,
                HasError = false,
                StatusCode = ResponseStatus.STATUS_SUCCESS,
                Result = new GetBannerDetailDto
                {
                    Id = banner.ID,
                    Title = banner.Title,
                    URL = banner.URL,
                    ImageUrl = banner.ImageUrl,
                    StartDate = banner.StartDate,
                    EndDate = banner.EndDate,
                    RecordVersion = banner.RecordVersion,
                    Status = banner.Status,
                }
            };

            _mockBannerQueryService.Setup(s => s.GetBannerDetailById(bannerId))
                                   .ReturnsAsync(mockBannerResponse);

            // Act
            var result = await _controller.GetBannerDetailById(bannerId);

            // Assert
            var okResult = Assert.IsType<OkObjectResult>(result);
            var response = Assert.IsType<GenericResponse<GetBannerDetailDto>>(okResult.Value);
            Assert.True(response.IsSuccess);
            Assert.NotNull(response.Result);
            Assert.Equal(bannerId, response.Result.Id);
            Assert.Equal(banner.Title, response.Result.Title);
            Assert.Equal(banner.URL, response.Result.URL);
        }

        [Fact]
        public async Task GetBannerDetailById_ShouldReturnNotFound_WhenBannerDoesNotExist()
        {
            // Arrange
            int bannerId = 9999; // Assuming this ID doesn't exist in the database
            var mockBannerResponse = new GenericResponse<GetBannerDetailDto>
            {
                IsSuccess = false,
                HasError = true,
                StatusCode = ResponceStatusCode.RecordNotFound.ToString(),
                Message = "No record found",
                Result = null
            };

            _mockBannerQueryService.Setup(s => s.GetBannerDetailById(bannerId))
                                   .ReturnsAsync(mockBannerResponse);

            // Act
            var result = await _controller.GetBannerDetailById(bannerId);

            // Assert
            var notFoundResult = Assert.IsType<NotFoundObjectResult>(result);
            var response = Assert.IsType<GenericResponse<GetBannerDetailDto>>(notFoundResult.Value);
            Assert.False(response.IsSuccess);
            Assert.Equal("No record found", response.Message);
        }

        [Fact]
        public async Task GetBannerDetailById_ShouldReturnBadRequest_WhenRegionCodeValidationFails()
        {
            // Arrange
            int bannerId = 1;
            var validationErrorResponse = new GenericResponse<string>
            {
                IsSuccess = false,
                HasError = true,
                StatusCode = "BAD_REQUEST",
                Message = "Region code validation failed",
                Result = null
            };

            // Mock VerifyRegionCodeHeader to return validation failure
            _mockRegionCodeValidationHelper.Setup(r => r.VerifyRegionCodeHeader(It.IsAny<HttpRequest>()))
                                            .Returns(validationErrorResponse);

            // Act
            var result = await _controller.GetBannerDetailById(bannerId);

            // Assert
            var badRequestResult = Assert.IsType<BadRequestObjectResult>(result);
            var response = Assert.IsType<GenericResponse<string>>(badRequestResult.Value);
            Assert.False(response.IsSuccess);
            Assert.Equal("Region code validation failed", response.Message);
        }

        [Fact]
        public async Task GetBannerDetailById_ShouldReturnOk_WhenValidRegionCodeAndBannerExists()
        {
            // Arrange
            int bannerId = 1;
            var banner = new Domain.V1.Entities.Banner
            {
                ID = bannerId,
                Title = "Valid Banner",
                URL = "http://example.com",
                ImageUrl = "http://example.com/image.jpg",
                StartDate = DateTime.UtcNow,
                EndDate = DateTime.UtcNow.AddDays(1),
                Status = true,
                RecordVersion = [ 1, 2, 3, 4 ],
                CreatedBy = "testUser",
                CreatedDate = DateTime.UtcNow,
                IsDeleted = false,
                UpdatedDate = DateTime.UtcNow,
                UpdatedBy = "testUser"
            };

            var mockBannerResponse = new GenericResponse<GetBannerDetailDto>
            {
                IsSuccess = true,
                HasError = false,
                StatusCode = ResponseStatus.STATUS_SUCCESS,
                Result = new GetBannerDetailDto
                {
                    Id = banner.ID,
                    Title = banner.Title,
                    URL = banner.URL,
                    ImageUrl = banner.ImageUrl,
                    StartDate = banner.StartDate,
                    EndDate = banner.EndDate,
                    RecordVersion = banner.RecordVersion,
                    Status = banner.Status,
                }
            };

            _mockRegionCodeValidationHelper.Setup(r => r.VerifyRegionCodeHeader(It.IsAny<HttpRequest>()))
                                            .Returns(new GenericResponse<string> { IsSuccess = true });

            _mockBannerQueryService.Setup(s => s.GetBannerDetailById(bannerId))
                                   .ReturnsAsync(mockBannerResponse);

            // Act
            var result = await _controller.GetBannerDetailById(bannerId);

            // Assert
            var okResult = Assert.IsType<OkObjectResult>(result);
            var response = Assert.IsType<GenericResponse<GetBannerDetailDto>>(okResult.Value);
            Assert.True(response.IsSuccess);
            Assert.NotNull(response.Result);
            Assert.Equal(bannerId, response.Result.Id);
        }


        [Fact]
        public void GetBannerSearch_ShouldReturnOk_WhenNoParametersAreProvided()
        {
            // Arrange
            var mockedResponse = new List<BannerSearchResponse>
            {
                new BannerSearchResponse
                {
                    Id = 1,
                    Title = "Banner 1",
                    Status = true,
                    StartDate = DateTime.UtcNow,
                    EndDate = DateTime.UtcNow.AddDays(1),
                    UpdatedBy = "Admin",
                    UpdatedDate = DateTime.UtcNow,
                },
                new BannerSearchResponse
                {
                    Id = 2,
                    Title = "Banner 2",
                    Status = false,
                    StartDate = DateTime.UtcNow.AddDays(-1),
                    EndDate = DateTime.UtcNow.AddDays(1),
                    UpdatedBy = "Admin",
                    UpdatedDate = DateTime.UtcNow,
                }
            };

            // Mock the banner query service to return the mocked response
            _mockBannerQueryService.Setup(service => service.GetBannerSearch(It.IsAny<BannerSearchRequest>()))
                .Returns(mockedResponse);

            // Act
            var result = _controller.GetBannerSearch(null, null, null, null, null, null);

            // Assert
            result.Should().BeOfType<OkObjectResult>();
            var okResult = result as OkObjectResult;

            // Assert the structure of the response
            okResult?.Value.Should().BeOfType<GenericResponseList<BannerSearchResponse>>();
            var response = okResult?.Value as GenericResponseList<BannerSearchResponse>;
            response?.Results.Should().BeEquivalentTo(mockedResponse);  // Verify that the banners returned are correct.
            response?.StatusCode.Should().Be(ResponseStatusCode.STATUS_SUCCESS);
            response?.Message.Should().Be(ResponseMessage.STATUS_DATA_FOUND);
            response?.TotalCount.Should().Be(mockedResponse.Count);
            response?.CurrentPage.Should().Be(1);  // Assuming no page number provided.
            response?.PageSize.Should().Be(10);   // Assuming default page size is 10.
            response?.MessageType.Should().Be(CommonConstants.SUCCESS);
        }

        [Fact]
        public void GetBannerSearch_ShouldReturnBadRequest_WhenInvalidParametersAreProvided()
        {
            var mockedResponse = new GenericResponse<string>
            {
                IsSuccess = false,
                HasError = true,
                StatusCode = ResponseStatus.STATUS_BadRequest,
                Message = Resource.RegionCodeRequired
            };

            _mockRegionCodeValidationHelper.Setup(x => x.VerifyRegionCodeHeader(It.IsAny<HttpRequest>()))
                .Returns(mockedResponse);

            // Act
            var result = _controller.GetBannerSearch(null, null, null, null, null, null);

            // Assert
            result.Should().BeOfType<BadRequestObjectResult>();
            var badRequestResult = result as BadRequestObjectResult;
            badRequestResult?.Value.Should().BeEquivalentTo(mockedResponse);
        }

        [Fact]
        public void GetBannerSearch_ShouldReturnNotFound_WhenNoBannersFound()
        {
            // Arrange
            var emptyResponse = new List<BannerSearchResponse>();

            _mockBannerQueryService.Setup(service => service.GetBannerSearch(It.IsAny<BannerSearchRequest>()))
                .Returns(emptyResponse);

            // Act
            var result = _controller.GetBannerSearch(null, null, null, null, null, null);

            // Assert
            result.Should().BeOfType<NotFoundObjectResult>();
            var notFoundResult = result as NotFoundObjectResult;

            // Assert response properties
            var response = notFoundResult?.Value as GenericResponseList<BannerSearchResponse>;
            response?.StatusCode.Should().Be(ResponseStatusCode.STATUS_NOTFOUND);
            response?.Message.Should().Be(ResponseMessage.STATUS_NODATA);
        }

        [Fact]
        public void GetBannerSearch_ShouldReturnOk_WhenParametersAreProvided()
        {
            // Arrange
            var mockedResponse = new List<BannerSearchResponse>
            {
                new BannerSearchResponse
                {
                    Id = 1,
                    Title = "Banner 1",
                    Status = true,
                    StartDate = DateTime.UtcNow,
                    EndDate = DateTime.UtcNow.AddDays(1),
                    UpdatedBy = "Admin",
                    UpdatedDate = DateTime.UtcNow
                }
            };

            _mockBannerQueryService.Setup(service => service.GetBannerSearch(It.IsAny<BannerSearchRequest>()))
                .Returns(mockedResponse);

            var selectedBannerTitle = "Banner 1";
            var selectedStatus = "Active";
            var selectedStartDate = DateTime.UtcNow.AddDays(-1);
            var selectedEndDate = DateTime.UtcNow.AddDays(1);

            // Act
            var result = _controller.GetBannerSearch(1, 10, selectedBannerTitle, selectedStartDate, selectedEndDate, selectedStatus);

            // Assert
            result.Should().BeOfType<OkObjectResult>();
            var okResult = result as OkObjectResult;
            var response = okResult?.Value as GenericResponseList<BannerSearchResponse>;
            response?.Results.Should().BeEquivalentTo(mockedResponse);
            response?.TotalCount.Should().Be(mockedResponse.Count);
            response?.StatusCode.Should().Be(ResponseStatusCode.STATUS_SUCCESS);
            response?.Message.Should().Be(ResponseMessage.STATUS_DATA_FOUND);
            response?.CurrentPage.Should().Be(1);
            response?.PageSize.Should().Be(10);
        }

        [Fact]
        public void GetBannerSearch_ShouldReturnOk_WhenStartDateAndEndDateAreProvided()
        {
            // Arrange
            var mockedResponse = new List<BannerSearchResponse>
            {
                new BannerSearchResponse
                {
                    Id = 1,
                    Title = "Banner 1",
                    Status = true,
                    StartDate = DateTime.UtcNow.AddDays(-5),
                    EndDate = DateTime.UtcNow.AddDays(5),
                    UpdatedBy = "Admin",
                    UpdatedDate = DateTime.UtcNow
                }
            };

            _mockBannerQueryService.Setup(service => service.GetBannerSearch(It.IsAny<BannerSearchRequest>()))
                .Returns(mockedResponse);

            var selectedStartDate = DateTime.UtcNow.AddDays(-10);
            var selectedEndDate = DateTime.UtcNow.AddDays(10);

            // Act
            var result = _controller.GetBannerSearch(1, 10, null, selectedStartDate, selectedEndDate, null);

            // Assert
            result.Should().BeOfType<OkObjectResult>();
            var okResult = result as OkObjectResult;
            var response = okResult?.Value as GenericResponseList<BannerSearchResponse>;
            response?.Results.Should().BeEquivalentTo(mockedResponse);
            response?.TotalCount.Should().Be(mockedResponse.Count);
            response?.StatusCode.Should().Be(ResponseStatusCode.STATUS_SUCCESS);
        }

        [Fact]
        public void GetBannerSearch_ShouldReturnOk_WhenPagedResponseIsReturned()
        {
            // Arrange
            var mockedResponse = new List<BannerSearchResponse>
            {
                new BannerSearchResponse
                {
                    Id = 1,
                    Title = "Banner 1",
                    Status = true,
                    StartDate = DateTime.UtcNow,
                    EndDate = DateTime.UtcNow.AddDays(1),
                    UpdatedBy = "Admin",
                    UpdatedDate = DateTime.UtcNow
                },
                new BannerSearchResponse
                {
                    Id = 2,
                    Title = "Banner 2",
                    Status = false,
                    StartDate = DateTime.UtcNow.AddDays(-1),
                    EndDate = DateTime.UtcNow.AddDays(1),
                    UpdatedBy = "Admin",
                    UpdatedDate = DateTime.UtcNow
                }
            };

            _mockBannerQueryService.Setup(service => service.GetBannerSearch(It.IsAny<BannerSearchRequest>()))
                .Returns(mockedResponse);

            var pageNumber = 1;
            var pageSize = 2;

            // Act
            var result = _controller.GetBannerSearch(pageNumber, pageSize, null, null, null, null);

            // Assert
            result.Should().BeOfType<OkObjectResult>();
            var okResult = result as OkObjectResult;
            var response = okResult?.Value as GenericResponseList<BannerSearchResponse>;
            response?.Results.Should().BeEquivalentTo(mockedResponse);
            response?.TotalCount.Should().Be(mockedResponse.Count);
            response?.CurrentPage.Should().Be(pageNumber);
            response?.PageSize.Should().Be(pageSize);
        }
    }
}
