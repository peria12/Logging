﻿using Aurora.AdministrationService.API.Controllers.Marketing.DoctorProfile;
using Aurora.AdministrationService.API.Helper;
using Aurora.AdministrationService.API.Models.Dto.Marketing.DoctorProfile;
using Aurora.AdministrationService.API.Models.Dto.Marketing.DoctorProfile.Manage;
using Aurora.AdministrationService.API.Models.Dto.Marketing.DoctorProfile.Summary;
using Aurora.AdministrationService.API.Models.Dto.Marketing.DoctorProfile.View;
using Aurora.AdministrationService.API.Models.ResponseModels.PractitionerPhotos;
using Aurora.AdministrationService.API.Resources;
using Aurora.AdministrationService.API.Services.IService.Marketing.DoctorProfile;
using Aurora.AdministrationService.CrossCutting.CommonModels;
using Aurora.AdministrationService.CrossCutting.Constants;
using FluentAssertions;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using Moq;

namespace Aurora.AdministrationService.Tests.API.Controllers.Marketing.DoctorProfile
{
    public class DoctorProfileControllerTests
    {
        private readonly Mock<IRegionCodeValidationHelper> _mockRegionCodeValidationHelper;
        private readonly Mock<IDoctorProfileCommandService> _mockDoctorProfileCommandService;
        private readonly Mock<IDoctorProfileQueryService> _mockDoctorProfileQueryService;
        private readonly DoctorProfileController _controller;

        public DoctorProfileControllerTests()
        {
            _mockRegionCodeValidationHelper = new Mock<IRegionCodeValidationHelper>();
            _mockDoctorProfileCommandService = new Mock<IDoctorProfileCommandService>();
            _mockDoctorProfileQueryService = new Mock<IDoctorProfileQueryService>();
            _controller = new DoctorProfileController(_mockRegionCodeValidationHelper.Object, _mockDoctorProfileCommandService.Object, _mockDoctorProfileQueryService.Object);
        }

        [Fact]
        public async Task ManageDoctorProfile_ShouldReturnOk_WhenInputIsValid()
        {
            // Arrange
            var verifyStatus = new GenericResponse<string> { HasError = false, IsSuccess = true };
            var request = new ManageDoctorDetailsDto
            {
                ManageDoctorPrimaryDetails = new ManageDoctorPrimaryDetailsDto
                {
                    PractitionerID = 1,
                    FirstName = "John",
                    LastName = "Doe",
                    GenderID = 1,
                }
            };

            var serviceResponse = new GenericResponse<string>
            {
                IsSuccess = true,
                StatusCode = ResponseStatusCode.STATUS_SUCCESS_UPDATED,
                Message = ResponseMessage.STATUS_DATA_UPDATED,
                HasError = false,
                MessageType = CommonConstants.SUCCESS
            };

            _mockRegionCodeValidationHelper.Setup(x => x.VerifyRegionCodeHeader(It.IsAny<HttpRequest>()))
                .Returns(verifyStatus); // No region code validation error

            _mockDoctorProfileCommandService.Setup(x => x.ManageDoctorProfileAsync(request))
                .ReturnsAsync(true); // Service returns true

            // Act
            var result = await _controller.ManageDoctorProfile(request);

            // Assert
            result.Should().BeOfType<OkObjectResult>();
            var okResult = result as OkObjectResult;
            okResult.Should().NotBeNull();
            okResult?.Value.Should().NotBeNull();
            okResult?.Value.Should().BeEquivalentTo(serviceResponse);
        }

        [Fact]
        public async Task ManageDoctorProfile_ShouldReturnBadRequest_WhenModelStateIsInvalid()
        {
            // Arrange
            _controller.ModelState.AddModelError("FirstName", "Required"); // Simulate invalid ModelState

            // Act
            var result = await _controller.ManageDoctorProfile(It.IsAny<ManageDoctorDetailsDto>());

            // Assert
            result.Should().BeOfType<BadRequestObjectResult>();
            var badRequestResult = result as BadRequestObjectResult;
            badRequestResult.Should().NotBeNull();
            badRequestResult?.Value.Should().NotBeNull();
            badRequestResult?.Value.Should().BeOfType<SerializableError>();
        }

        [Fact]
        public async Task ManageDoctorProfile_ShouldReturnBadRequest_WhenRegionCodeValidationFails()
        {
            // Arrange
            var verifyStatus = new GenericResponse<string> { HasError = true, IsSuccess = false, Message = "Invalid region code" };
            var request = new ManageDoctorDetailsDto
            {
                ManageDoctorPrimaryDetails = new ManageDoctorPrimaryDetailsDto
                {
                    PractitionerID = 1,
                    FirstName = "John",
                    LastName = "Doe",
                    GenderID = 1,
                }
            };

            _mockRegionCodeValidationHelper.Setup(x => x.VerifyRegionCodeHeader(It.IsAny<HttpRequest>()))
                .Returns(verifyStatus); // Simulate region code validation failure

            // Act
            var result = await _controller.ManageDoctorProfile(request);

            // Assert
            result.Should().BeOfType<BadRequestObjectResult>();
            var badRequestResult = result as BadRequestObjectResult;
            badRequestResult.Should().NotBeNull();
            badRequestResult?.Value.Should().NotBeNull();
            badRequestResult?.Value.Should().BeEquivalentTo(verifyStatus);
        }

        [Fact]
        public async Task ManageDoctorProfile_ShouldReturnBadRequest_WhenServiceReturnsFalse()
        {
            // Arrange
            var verifyStatus = new GenericResponse<string> { HasError = false, IsSuccess = true };
            var request = new ManageDoctorDetailsDto
            {
                ManageDoctorPrimaryDetails = new ManageDoctorPrimaryDetailsDto
                {
                    PractitionerID = 1,
                    FirstName = "John",
                    LastName = "Doe",
                    GenderID = 1,
                }
            };

            var serviceResponse = new GenericResponse<string>
            {
                IsSuccess = false,
                StatusCode = ResponseStatusCode.STATUS_BADREQUEST,
                Message = ResponseMessage.STATUS_DATA_UPDATE_FAIL,
                HasError = true,
                MessageType = CommonConstants.INFO
            };

            _mockRegionCodeValidationHelper.Setup(x => x.VerifyRegionCodeHeader(It.IsAny<HttpRequest>()))
                .Returns(verifyStatus); // No region code validation error

            _mockDoctorProfileCommandService.Setup(x => x.ManageDoctorProfileAsync(request))
                .ReturnsAsync(false); // Service returns false

            // Act
            var result = await _controller.ManageDoctorProfile(request);

            // Assert
            result.Should().BeOfType<BadRequestObjectResult>();
            var badRequestResult = result as BadRequestObjectResult;
            badRequestResult.Should().NotBeNull();
            badRequestResult?.Value.Should().NotBeNull();
            badRequestResult?.Value.Should().BeEquivalentTo(serviceResponse);
        }

        //MANAGE RANK TESTS
        [Fact]
        public async Task UpdateRank_ReturnsBadRequest_WhenRegionCodeIsInvalid()
        {
            // Arrange
            var mockedResponse = new GenericResponse<string>
            {
                IsSuccess = false,
                HasError = true,
                StatusCode = ResponseStatus.STATUS_BadRequest,
                Message = Resource.RegionCodeRequired
            };

            _mockRegionCodeValidationHelper.Setup(x => x.VerifyRegionCodeHeader(It.IsAny<HttpRequest>()))
                .Returns(mockedResponse);

            var request = new ManageRankDto
            {
                Id = 11,
                Rank = "5",
                RecordVersion = new byte[8] { byte.MinValue, byte.MinValue, byte.MinValue, byte.MinValue, byte.MinValue, byte.MinValue, byte.MinValue, byte.MaxValue }
            };

            // Act
            var result = await _controller.UpdateRank(request);

            // Assert
            result.Should().BeOfType<BadRequestObjectResult>();
        }
        [Fact]
        public async Task UpdateRank_ReturnsOk_WhenRankIsUpdatedSuccessfully()
        {
            // Arrange
            var request = new ManageRankDto
            {
                Id = 11,
                Rank = "5",
                RecordVersion = new byte[8] { byte.MinValue, byte.MinValue, byte.MinValue, byte.MinValue, byte.MinValue, byte.MinValue, byte.MinValue, byte.MaxValue }
            };

            var mockResponse = new GenericResponse<string>
            {
                IsSuccess = true,
                HasError = false,
                StatusCode = ResponseStatus.STATUS_SUCCESS,
                Message = "Rank updated successfully"
            };

            _mockRegionCodeValidationHelper.Setup(x => x.VerifyRegionCodeHeader(It.IsAny<HttpRequest>()))
                .Returns(new GenericResponse<string> { IsSuccess = true });

            _mockDoctorProfileCommandService.Setup(x => x.UpdateRank(It.IsAny<ManageRankDto>()))
                .ReturnsAsync(mockResponse);

            // Act
            var result = await _controller.UpdateRank(request);

            // Assert
            result.Should().BeOfType<OkObjectResult>();
            var okResult = result as OkObjectResult;
            okResult?.Value.Should().BeEquivalentTo(mockResponse);
        }
        [Fact]
        public async Task UpdateRank_ReturnsBadrequest_WhenRankIsNotUpdated()
        {
            // Arrange
            var request = new ManageRankDto
            {
                Id = 11,
                Rank = "5",
                RecordVersion = new byte[8] { byte.MinValue, byte.MinValue, byte.MinValue, byte.MinValue, byte.MinValue, byte.MinValue, byte.MinValue, byte.MaxValue }
            };

            var mockResponse = new GenericResponse<string>
            {
                IsSuccess = false,
                HasError = true,
                StatusCode = ResponseStatus.STATUS_NotFound,
                Message = Resource.RecordNotFound
            };

            _mockRegionCodeValidationHelper.Setup(x => x.VerifyRegionCodeHeader(It.IsAny<HttpRequest>()))
                .Returns(new GenericResponse<string> { IsSuccess = true });

            _mockDoctorProfileCommandService.Setup(x => x.UpdateRank(It.IsAny<ManageRankDto>()))
                .ReturnsAsync(mockResponse);

            // Act
            var result = await _controller.UpdateRank(request);

            // Assert
            result.Should().BeOfType<BadRequestObjectResult>();
        }
        [Fact]
        public async Task UpdateRank_ReturnsBadRequest_WhenModelStateIsInvalid()
        {
            // Arrange
            var request = new ManageRankDto
            {
                Id = 11,
                Rank = "5",
                RecordVersion = new byte[8] { byte.MinValue, byte.MinValue, byte.MinValue, byte.MinValue, byte.MinValue, byte.MinValue, byte.MinValue, byte.MaxValue }
            };

            _controller.ModelState.AddModelError("Title", "The Id field is required.");

            _mockRegionCodeValidationHelper.Setup(x => x.VerifyRegionCodeHeader(It.IsAny<HttpRequest>()))
                .Returns(new GenericResponse<string> { IsSuccess = true });
            // Act
            var result = await _controller.UpdateRank(request);

            // Assert
            result.Should().BeOfType<BadRequestObjectResult>();
        }
        [Fact]
        public async Task UpdateBannerStatus_ReturnsBadRequest_WhenRegionCodeIsInvalid()
        {
            // Arrange
            var mockedResponse = new GenericResponse<string>
            {
                IsSuccess = false,
                HasError = true,
                StatusCode = ResponseStatus.STATUS_BadRequest,
                Message = Resource.RegionCodeRequired
            };

            _mockRegionCodeValidationHelper.Setup(x => x.VerifyRegionCodeHeader(It.IsAny<HttpRequest>()))
                .Returns(mockedResponse);

            var request = new ManageRankDto
            {
                Id = 11,
                Rank = "5",
                RecordVersion = new byte[8] { byte.MinValue, byte.MinValue, byte.MinValue, byte.MinValue, byte.MinValue, byte.MinValue, byte.MinValue, byte.MaxValue }
            };

            // Act
            var result = await _controller.UpdateRank(request);

            // Assert
            result.Should().BeOfType<BadRequestObjectResult>();
        }
        [Fact]
        public async Task UpdateRank_ReturnsBadRequest_WhenRankIsNull()
        {
            // Arrange
            var request = new ManageRankDto
            {
                Id = 11,
                Rank = "",
                RecordVersion = new byte[8] { byte.MinValue, byte.MinValue, byte.MinValue, byte.MinValue, byte.MinValue, byte.MinValue, byte.MinValue, byte.MaxValue }
            };

            _mockRegionCodeValidationHelper.Setup(x => x.VerifyRegionCodeHeader(It.IsAny<HttpRequest>()))
                .Returns(new GenericResponse<string> { IsSuccess = true });
            // Act
            var result = await _controller.UpdateRank(request);

            // Assert
            result.Should().BeOfType<BadRequestObjectResult>();
        }
        [Fact]
        public async Task UpdateBanner_ReturnsBadRequest_WhenDbUpdateConcurrencyExceptionIsThrown()
        {
            // Arrange
            var request = new ManageRankDto
            {
                Id = 11,
                Rank = "5",
                RecordVersion = new byte[8] { byte.MinValue, byte.MinValue, byte.MinValue, byte.MinValue, byte.MinValue, byte.MinValue, byte.MinValue, byte.MaxValue }
            };

            _mockRegionCodeValidationHelper.Setup(x => x.VerifyRegionCodeHeader(It.IsAny<HttpRequest>()))
                .Returns(new GenericResponse<string> { IsSuccess = true });

            // Mock the UpdateBanner method to throw DbUpdateConcurrencyException
            _mockDoctorProfileCommandService.Setup(x => x.UpdateRank(request))
                .ThrowsAsync(new DbUpdateConcurrencyException("Concurrency conflict occurred."));

            // Act
            var result = await _controller.UpdateRank(request);

            // Assert
            result.Should().BeOfType<BadRequestObjectResult>();

            var badRequestResult = result as BadRequestObjectResult;
            badRequestResult.Should().NotBeNull();

            var response = badRequestResult?.Value as GenericResponse<string>;
            response.Should().NotBeNull();
            response?.HasError.Should().BeTrue();
            response?.StatusCode.Should().Be(ResponseStatusCode.STATUS_BADREQUEST);
            response?.Message.Should().Be(CommonConstants.ERROR_DB_CONCURRENCY);
            response?.MessageType.Should().Be(CommonConstants.ERROR);
        }


        [Fact]
        public async Task GetDoctorProfileGridData_ShouldReturnOK()
        {
            // Arrange
            List<DoctorProfileDto> data = new List<DoctorProfileDto>();
            data.Add(new DoctorProfileDto());
            _mockDoctorProfileQueryService.Setup(x => x.GetDoctorProfileGridData())
                .ReturnsAsync(data); // Service returns true
            // Act
            var result = await _controller.GetDoctorProfileGridData();

            // Assert
            result.Should().BeOfType<OkObjectResult>();
            var okResult = result as OkObjectResult;
            okResult.Should().NotBeNull();
        }

        [Fact]
        public async Task GetDoctorProfileGridData_ShouldReturnNoData()
        {
            // Arrange
            List<DoctorProfileDto> data = new List<DoctorProfileDto>();
            _mockDoctorProfileQueryService.Setup(x => x.GetDoctorProfileGridData())
                .ReturnsAsync(data); // Service returns true
            // Act
            var result = await _controller.GetDoctorProfileGridData();

            // Assert
            result.Should().BeOfType<NotFoundObjectResult>();
            var okResult = result as NotFoundObjectResult;
            okResult.Should().NotBeNull();
        }

        [Fact]
        public async Task GetDoctorProfileBySearch_ShouldReturnOK()
        {
            // Arrange
            var request = new DoctorProfileSearchFilterDto
            {
                Name = "vijay",
            };
            List<DoctorProfileDto> data = new List<DoctorProfileDto>();
            data.Add(new DoctorProfileDto() { Name = "vijay" });

            _mockDoctorProfileQueryService.Setup(x => x.GetDoctorProfileBySearch(request))
                .ReturnsAsync(data); // Service returns true
            // Act
            var result = await _controller.GetDoctorProfileBySearch(request);

            // Assert
            result.Should().BeOfType<OkObjectResult>();
            var okResult = result as OkObjectResult;
            okResult.Should().NotBeNull();
        }

        [Fact]
        public async Task GetDoctorProfileBySearch_ShouldReturnNoData()
        {
            // Arrange
            var request = new DoctorProfileSearchFilterDto
            {
                Name = "vijay",
            };
            List<DoctorProfileDto> data = new List<DoctorProfileDto>();

            _mockDoctorProfileQueryService.Setup(x => x.GetDoctorProfileBySearch(request))
                .ReturnsAsync(data); // Service returns true
            // Act
            var result = await _controller.GetDoctorProfileBySearch(request);

            // Assert
            result.Should().BeOfType<NotFoundObjectResult>();
            var okResult = result as NotFoundObjectResult;
            okResult.Should().NotBeNull();
        }

        [Fact]
        public async Task GetSearchFiltersData_ReturnsNotFound_WhenServiceReturnsNull()
        {
            // Arrange
            var verifyStatus = new GenericResponse<string> { HasError = false, IsSuccess = true };
            var request = new ManageDoctorDetailsDto
            {
                ManageDoctorPrimaryDetails = new ManageDoctorPrimaryDetailsDto
                {
                    PractitionerID = 0,
                    FirstName = "A",
                    LastName = "A",
                    GenderID = 0,
                }
            };

            _mockRegionCodeValidationHelper.Setup(x => x.VerifyRegionCodeHeader(It.IsAny<HttpRequest>()))
                .Returns(verifyStatus);

            _mockDoctorProfileCommandService.Setup(x => x.ManageDoctorProfileAsync(request))
                .ReturnsAsync(true);

            // Act
            var result = await _controller.GetSearchFiltersData();

            // Assert
            result.Should().BeOfType<NotFoundObjectResult>();
            var okResult = result as NotFoundObjectResult;
            okResult.Should().NotBeNull();
        }

        [Fact]
        public async Task GetSearchFiltersData_ReturnsOk_WhenServiceReturnsData()
        {
            // Arrange
            var verifyStatus = new GenericResponse<string> { HasError = false, IsSuccess = true };
            var request = new ManageDoctorDetailsDto
            {
                ManageDoctorPrimaryDetails = new ManageDoctorPrimaryDetailsDto
                {
                    PractitionerID = 1,
                    FirstName = "John",
                    LastName = "Doe",
                    GenderID = 1,
                }
            };

            _mockRegionCodeValidationHelper.Setup(x => x.VerifyRegionCodeHeader(It.IsAny<HttpRequest>()))
                .Returns(verifyStatus);

            _mockDoctorProfileCommandService.Setup(x => x.ManageDoctorProfileAsync(request))
                .ReturnsAsync(true);

            // Act
            var result = await _controller.GetSearchFiltersData();

            // Assert
            result.Should().BeOfType<NotFoundObjectResult>();
            var okResult = result as NotFoundObjectResult;
            okResult.Should().NotBeNull();
        }

        [Fact]
        public async Task GetPublicationById_InvalidRegionCode_ReturnsBadRequest()
        {
            // Arrange
            _mockRegionCodeValidationHelper.Setup(x => x.VerifyRegionCodeHeader(It.IsAny<HttpRequest>()))
                .Returns(new GenericResponse<string> { HasError = true });

            // Act
            var result = await _controller.GetPublicationById(1);

            // Assert
            Assert.IsType<BadRequestObjectResult>(result.Result);
        }

        [Fact]
        public async Task GetPublicationById_InvalidId_ReturnsBadRequest()
        {
            // Arrange
            _mockRegionCodeValidationHelper.Setup(x => x.VerifyRegionCodeHeader(It.IsAny<HttpRequest>()))
                .Returns(new GenericResponse<string> { HasError = false });

            // Act
            var result1 = await _controller.GetPublicationById(null);
            var result2 = await _controller.GetPublicationById(0);
            var result3 = await _controller.GetPublicationById(-1);

            // Assert
            Assert.IsType<BadRequestObjectResult>(result1.Result);
            Assert.IsType<BadRequestObjectResult>(result2.Result);
            Assert.IsType<BadRequestObjectResult>(result3.Result);
        }

        [Fact]
        public async Task GetPublicationById_NotFound_ReturnsNotFound()
        {
            // Arrange
            _mockRegionCodeValidationHelper.Setup(x => x.VerifyRegionCodeHeader(It.IsAny<HttpRequest>()))
                .Returns(new GenericResponse<string> { HasError = false });

            _mockDoctorProfileQueryService.Setup(x => x.GetPublicationById(It.IsAny<long>()))
                .ReturnsAsync((List<ManageDoctorPublicationDetailsDto>)null);

            // Act
            var result = await _controller.GetPublicationById(1);

            // Assert
            Assert.IsType<NotFoundObjectResult>(result.Result);
        }

        [Fact]
        public async Task GetPublicationById_Found_ReturnsOk()
        {
            // Arrange
            _mockRegionCodeValidationHelper.Setup(x => x.VerifyRegionCodeHeader(It.IsAny<HttpRequest>()))
                .Returns(new GenericResponse<string> { HasError = false });

            var mockPublication = new List<ManageDoctorPublicationDetailsDto>
            {
                new()
                {
                      Id = 1,
                Title = "Test Publication",
                Description = "Test Description",
                RecordVersion = new byte[] { 1, 2, 3 }
                }
              
            };

            _mockDoctorProfileQueryService.Setup(x => x.GetPublicationById(It.IsAny<long>()))
                .ReturnsAsync(mockPublication);

            // Act
            var result = await _controller.GetPublicationById(1);

            // Assert
            var okResult = Assert.IsType<OkObjectResult>(result.Result);
            var response = Assert.IsType<GenericResponseList<ManageDoctorPublicationDetailsDto>>(okResult.Value);

            Assert.NotNull(response.Results);
            Assert.Equal(1, response.Results.Select(a => a.Id).FirstOrDefault());
            Assert.Equal("Test Publication", response.Results.Select(a => a.Title).FirstOrDefault());
            Assert.Equal("Test Description", response.Results.Select(a => a.Description).FirstOrDefault());
        }

        [Fact]
        public async Task GetSectionById_InvalidRegionCode_ReturnsBadRequest()
        {
            // Arrange
            _mockRegionCodeValidationHelper.Setup(x => x.VerifyRegionCodeHeader(It.IsAny<HttpRequest>()))
                .Returns(new GenericResponse<string> { HasError = true });

            // Act
            var result = await _controller.GetSectionById(1);

            // Assert
            Assert.IsType<BadRequestObjectResult>(result.Result);
        }

        [Fact]
        public async Task GetSectionById_InvalidId_ReturnsBadRequest()
        {
            // Arrange
            _mockRegionCodeValidationHelper.Setup(x => x.VerifyRegionCodeHeader(It.IsAny<HttpRequest>()))
                .Returns(new GenericResponse<string> { HasError = false });

            // Act
            var result1 = await _controller.GetSectionById(null);
            var result2 = await _controller.GetSectionById(0);
            var result3 = await _controller.GetSectionById(-1);

            // Assert
            Assert.IsType<BadRequestObjectResult>(result1.Result);
            Assert.IsType<BadRequestObjectResult>(result2.Result);
            Assert.IsType<BadRequestObjectResult>(result3.Result);
        }

        [Fact]
        public async Task GetSectionById_NotFound_ReturnsNotFound()
        {
            // Arrange
            _mockRegionCodeValidationHelper.Setup(x => x.VerifyRegionCodeHeader(It.IsAny<HttpRequest>()))
                .Returns(new GenericResponse<string> { HasError = false });

            _mockDoctorProfileQueryService.Setup(x => x.GetSectionById(It.IsAny<long>()))
                .ReturnsAsync((List<ManageDoctorSectionDetailsDto>)null);

            // Act
            var result = await _controller.GetSectionById(1);

            // Assert
            Assert.IsType<NotFoundObjectResult>(result.Result);
        }

        [Fact]
        public async Task GetSectionById_Found_ReturnsOk()
        {
            // Arrange
            _mockRegionCodeValidationHelper.Setup(x => x.VerifyRegionCodeHeader(It.IsAny<HttpRequest>()))
                .Returns(new GenericResponse<string> { HasError = false });

            var mockSection = new List<ManageDoctorSectionDetailsDto>
            {
                new()
                {
                     Id = 1,
                Description = "Test Description",
                RecordVersion = new byte[] { 1, 2, 3 },
                IsDeleted = false
                }
               
            };

            _mockDoctorProfileQueryService.Setup(x => x.GetSectionById(It.IsAny<long>()))
                .ReturnsAsync(mockSection);

            // Act
            var result = await _controller.GetSectionById(1);

            // Assert
            var okResult = Assert.IsType<OkObjectResult>(result.Result);
            var response = Assert.IsType<GenericResponseList<ManageDoctorSectionDetailsDto>>(okResult.Value);

            Assert.NotNull(response.Results);
            Assert.Equal(1, response.Results.Select(a=>a.Id).FirstOrDefault());
            Assert.Equal("Test Description", response.Results.Select(a => a.Description).FirstOrDefault());
        }

        [Fact]
        public async Task GetPractitionerInterests_ShouldReturnData_WhenExists()
        {
            // Arrange
            int practitionerId = 21;

         var expectedResponseList = new List<DoctorProfileInterestDto>
        {
            new DoctorProfileInterestDto
        {
        PractitionerId = practitionerId,       
        DoctorInterest = new DoctorInterestDto
        {
            Interests = "Cardiology, Surgery",
            RecordVersion = Array.Empty<byte>()
        }
        }
        };

            _mockDoctorProfileQueryService
                .Setup(service => service.GetDoctorProfileInterest(practitionerId))
                .ReturnsAsync(expectedResponseList);

            // Act
            var result = await _controller.GetPractitionerInterests(practitionerId);

            // Assert
            result.Should().NotBeNull();
            var objectResult = result.Should().BeOfType<OkObjectResult>().Subject;
            var response = objectResult.Value.Should().BeOfType<GenericResponseList<DoctorProfileInterestDto>>().Subject;

            response.IsSuccess.Should().BeTrue();
            response.StatusCode.Should().Be(ResponseStatusCode.STATUS_SUCCESS);
            response.Message.Should().Be(ResponseMessage.STATUS_DATA_FOUND);
            response.MessageType.Should().Be(CommonConstants.SUCCESS);
            response.HasError.Should().BeFalse();
            response.Results.Should().BeEquivalentTo(expectedResponseList);
        }

        [Fact]
        public async Task GetPractitionerInterests_ShouldReturnNotFound_WhenNoDataExists()
        {
            // Arrange
            int nonExistentPractitionerId = 9999;

            _mockDoctorProfileQueryService
                .Setup(service => service.GetDoctorProfileInterest(nonExistentPractitionerId))
                .ReturnsAsync((List<DoctorProfileInterestDto>)null); // Simulate no data

            // Act
            var result = await _controller.GetPractitionerInterests(nonExistentPractitionerId);

            // Assert
            result.Should().NotBeNull();
            var objectResult = result.Should().BeOfType<NotFoundObjectResult>().Subject;
            var response = objectResult.Value.Should().BeOfType<GenericResponseList<DoctorProfileInterestDto>>().Subject;

            response.IsSuccess.Should().BeFalse();
            response.StatusCode.Should().Be(ResponseStatusCode.STATUS_NOTFOUND);
            response.HasError.Should().BeTrue();
            response.Message.Should().Be(ResponseMessage.STATUS_NODATA);
            response.MessageType.Should().Be(CommonConstants.ERROR);
            response.Results.Should().BeNull();
        }

        [Fact]
        public async Task GetDoctorDetails_ShouldReturnData_WhenExists()
        {
            // Arrange
            int doctorId = 21;

            var expectedResponse = new ManageDoctorProfileDto
            {
                PractitionerId = doctorId,
                DoctorDetailsInfo = new DoctorDetailsInfo
                {
                    Salutation = "Dr.",
                    FirstName = "John",
                    MiddleName = "A.",
                    LastName = "Doe",
                    GenderID = 1,
                    Designation = "Cardiologist",
                    Status = true,
                    RecordVersion = Array.Empty<byte>()
                },
                DoctorLocations = new List<DoctorLocationInfo>
            {
            new DoctorLocationInfo
            {
                LocationId = 101,
                Location = "Hyderabad",
                Status = true,
                RecordVersion = Array.Empty<byte>()
            }
            },
                DoctorSpecialities = new List<DoctorSpecialty>
             {
            new DoctorSpecialty
            {
                SpecialtyId = 201,
                Speciality = "Cardiology",
                Status = true,
                RecordVersion = Array.Empty<byte>()
            }
            },
               ImageDetail = new GetPractitionerPhotosDto
                {
                    Id = 1,
                    PractitionerID = 12345,
                    ContentType = "image/jpeg",
                    Data = new byte[] { 1, 2, 3, 4, 5 },  // Example byte array
                    URL = "https://example.com/photo.jpg",
                    Size = "1024x768",
                    Hash = "abcd1234",
                    Title = "Profile Photo",
                    Status = true,
                    CreationDate = DateTime.Now,
                    IsDeleted = false,
                    RecordVersion = MockRecordVersion.Generate() 
                }
            };

            _mockDoctorProfileQueryService
                .Setup(service => service.GetDoctorPrimaryDetails(doctorId))
                .ReturnsAsync(expectedResponse);

            // Act
            var result = await _controller.GetDoctorDetails(doctorId);

            // Assert
            result.Should().NotBeNull();
            var objectResult = result.Should().BeOfType<OkObjectResult>().Subject;
            var response = objectResult.Value.Should().BeOfType<GenericResponse<ManageDoctorProfileDto>>().Subject;

            response.IsSuccess.Should().BeTrue();
            response.StatusCode.Should().Be(ResponseStatusCode.STATUS_SUCCESS);
            response.Message.Should().Be(ResponseMessage.STATUS_DATA_FOUND);
            response.MessageType.Should().Be(CommonConstants.SUCCESS);
            response.HasError.Should().BeFalse();
            response.Result.Should().BeEquivalentTo(expectedResponse);
        }

        [Fact]
        public async Task GetDoctorDetails_ShouldReturnNotFound_WhenNoDataExists()
        {
            // Arrange
            int nonExistentDoctorId = 9999;

            _mockDoctorProfileQueryService
                .Setup(service => service.GetDoctorPrimaryDetails(nonExistentDoctorId))
                .ReturnsAsync((ManageDoctorProfileDto)null); // Simulate no data

            // Act
            var result = await _controller.GetDoctorDetails(nonExistentDoctorId);

            // Assert
            result.Should().NotBeNull();
            var objectResult = result.Should().BeOfType<NotFoundObjectResult>().Subject;
            var response = objectResult.Value.Should().BeOfType<GenericResponse<ManageDoctorProfileDto>>().Subject;

            response.IsSuccess.Should().BeFalse();
            response.StatusCode.Should().Be(ResponseStatusCode.STATUS_NOTFOUND);
            response.HasError.Should().BeTrue();
            response.Message.Should().Be(ResponseMessage.STATUS_NODATA);
            response.MessageType.Should().Be(CommonConstants.ERROR);
            response.Result.Should().BeNull();
        }

        [Fact]
        public async Task GetDoctorProfileEducationalQualificationById_ReturnsOkResult_WhenDataExists()
        {
            // Arrange
            long doctorId = 1;
            var qualifications = new List<EducationalQualificationDto>
        {
            new EducationalQualificationDto
            {
                ManageDoctorProfileID = doctorId,
                EducationalDegree = "MBBS",
                Institute = "ABC University",
                YearOfPassing = 2020
            }
        };

            _mockDoctorProfileQueryService
                .Setup(service => service.GetDoctorProfileEducationalQualificationById(doctorId))
                .ReturnsAsync(qualifications);

            // Act
            var result = await _controller.GetDoctorProfileEducationalQualificationById(doctorId);

            // Assert
            var okResult = Assert.IsType<OkObjectResult>(result);
            var response = Assert.IsType<GenericResponseList<EducationalQualificationDto>>(okResult.Value);
            Assert.True(response.IsSuccess);
            Assert.False(response.HasError);
            Assert.Equal(ResponseStatusCode.STATUS_SUCCESS, response.StatusCode);
            Assert.NotEmpty(response.Results);
        }
        [Fact]
        public async Task GetDoctorProfileEducationalQualificationById_ReturnsNotFound_WhenDataDoesNotExist()
        {
            // Arrange
            long doctorId = 2;
            _mockDoctorProfileQueryService
                .Setup(service => service.GetDoctorProfileEducationalQualificationById(doctorId))
                .ReturnsAsync((List<EducationalQualificationDto>)null);

            // Act
            var result = await _controller.GetDoctorProfileEducationalQualificationById(doctorId);

            // Assert
            var notFoundResult = Assert.IsType<NotFoundObjectResult>(result);
            var response = Assert.IsType<GenericResponseList<EducationalQualificationDto>>(notFoundResult.Value);
            Assert.False(response.IsSuccess);
            Assert.True(response.HasError);
            Assert.Equal(ResponseStatusCode.STATUS_NOTFOUND, response.StatusCode);
        }

        [Fact]
        public async Task GetDoctorProfileExperienceDetailById_ReturnsOkResult_WhenDataExists()
        {
            // Arrange
            long doctorId = 1;
            var mockResponse = new List<ExperienceDetailsDto>
            {
                new ExperienceDetailsDto { Id = 1, Title = "Surgeon", Organization = "ABC Hospital" ,RecordVersion=[1]}
            };

            _mockDoctorProfileQueryService
                .Setup(service => service.GetDoctorProfileExperienceDetailById(doctorId))
                .ReturnsAsync(mockResponse);

            // Act
            var result = await _controller.GetDoctorProfileExperienceDetailById(doctorId);

            // Assert
            var okResult = Assert.IsType<OkObjectResult>(result);
            var response = Assert.IsType<GenericResponseList<ExperienceDetailsDto>>(okResult.Value);
            Assert.True(response.IsSuccess);
            Assert.NotNull(response.Results);
        }

        [Fact]
        public async Task GetDoctorProfileExperienceDetailById_ReturnsNotFound_WhenDataDoesNotExist()
        {
            // Arrange
            long doctorId = 2;
            _mockDoctorProfileQueryService
                .Setup(service => service.GetDoctorProfileExperienceDetailById(doctorId))
                .ReturnsAsync((List<ExperienceDetailsDto>)null);

            // Act
            var result = await _controller.GetDoctorProfileExperienceDetailById(doctorId);

            // Assert
            var notFoundResult = Assert.IsType<NotFoundObjectResult>(result);
            var response = Assert.IsType<GenericResponseList<ExperienceDetailsDto>>(notFoundResult.Value);
            Assert.False(response.IsSuccess);
            Assert.True(response.HasError);
        }

        [Fact]
        public async Task UpdateDoctorProfile_ShouldReturnOk_WhenUpdateIsSuccessful()
        {
            // Arrange
            var mockService = new Mock<IDoctorProfileCommandService>();

            var updateDto = new UpdateDoctorProfileDto
            {
                UpdatePrimaryDetails = new UpdateDoctorPrimaryDetailDto
                {
                    DoctorProfileId = 1,
                    PractitionerId = 101,
                    Description = "Experienced physician",
                    DoctorDetailsInfo = new DoctorDetailsInfo
                    {
                        Salutation = "Dr.",
                        FirstName = "Jane",
                        MiddleName = "A.",
                        LastName = "Doe",
                        GenderID = 2,
                        Designation = "Cardiologist",
                        Status = true,
                        RecordVersion = BitConverter.GetBytes(1)
                    }
                },
                PhotosDetails = new UpdatePractitionerPhotosDto
                {
                    PractitionerID = 101,
                    ContentType = "image/jpeg",
                    Data = new byte[] { 1, 2, 3 },
                    URL = "https://example.com/photo.jpg",
                    Size = "500KB",
                    Hash = "abc123",
                    Title = "Profile Pic",
                    RecordVersion = BitConverter.GetBytes(1)
                },
                EducationalQualifications = new List<UpdateEducationalQualificationRequest>(),
                ExperienceDetails = new List<UpdateExperienceDetailsDto>(),
                PublicationDetails = new List<UpdateDoctorPublicationDetailsDto>(),
                AdditionalDetails = new List<UpdateDoctorAdditionalDetailsDto>(),
                Interests = new List<DoctorInterestDto>()
            };

            var expectedResponse = new GenericResponse<string>
            {
                IsSuccess = true,
                Message = "Updated",
                StatusCode = ResponseStatusCode.STATUS_SUCCESS,
                HasError = false
            };

            mockService.Setup(s => s.UpdateDoctorProfile(It.IsAny<long>(), It.IsAny<UpdateDoctorProfileDto>()))
                       .ReturnsAsync(expectedResponse);

           var _controllercommand = new DoctorProfileController(_mockRegionCodeValidationHelper.Object, mockService.Object, _mockDoctorProfileQueryService.Object);

          

            // Act
            var result = await _controllercommand.UpdateDoctorProfile(1, updateDto);

            // Assert
            var okResult = Assert.IsType<OkObjectResult>(result);
            var actualResponse = Assert.IsType<GenericResponse<string>>(okResult.Value);
            Assert.True(actualResponse.IsSuccess);
        }
   
    }
}