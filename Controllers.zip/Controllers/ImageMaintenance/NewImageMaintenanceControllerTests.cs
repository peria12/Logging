﻿using Aurora.AdministrationService.API.Controllers.ImageMaintenance;
using Aurora.AdministrationService.API.Helper;
using Aurora.AdministrationService.API.Models.Dto.ImageMaintenance;
using Aurora.AdministrationService.API.Services.IService.ImageMaintenance;
using Aurora.AdministrationService.CrossCutting.CommonModels;
using FluentAssertions;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Moq;

namespace Aurora.AdministrationService.Tests.API.Controllers.ImageMaintenance;

public class NewImageMaintenanceControllerTests
{
    private readonly Mock<IImageMaintenanceCommandServices> _imageMaintenanceCommandServicesMock;
    private readonly Mock<IImageMaintenanceQueryService> _imageMaintenanceQueryServiceMock;
    private readonly Mock<IRegionCodeValidationHelper> _regionHelperMock;
    private readonly ImageMaintenanceController _controller;

    public NewImageMaintenanceControllerTests()
    {
        _imageMaintenanceCommandServicesMock = new Mock<IImageMaintenanceCommandServices>();
        _imageMaintenanceQueryServiceMock = new Mock<IImageMaintenanceQueryService>();
        _regionHelperMock = new Mock<IRegionCodeValidationHelper>();
        _controller = new ImageMaintenanceController(
            _regionHelperMock.Object,
            _imageMaintenanceCommandServicesMock.Object,
            _imageMaintenanceQueryServiceMock.Object
        );
    }

    [Fact]
    public async Task CreateImage_ShouldReturnBadRequest_WhenRegionCodeHeaderIsInvalid()
    {
        // Arrange
        var newImageMaintenance = new AdministrationService.API.Models.RequestModels.ImageMaintenance.CreateImageMaintenanceRequest()

        {
            Description = "description",
            Header = "header",
            ScreenType = "0",
        };
        _regionHelperMock.Setup(r => r.VerifyRegionCodeHeader(It.IsAny<Microsoft.AspNetCore.Http.HttpRequest>()))
            .Returns(new GenericResponse<string> { HasError = true });

        // Act
        var result = await _controller.CreateImage(newImageMaintenance);

        // Assert
        var badRequestResult = Assert.IsType<BadRequestObjectResult>(result);
        Assert.Equal(StatusCodes.Status400BadRequest, badRequestResult.StatusCode);
    }

    [Fact]
    public async Task CreateImage_ShouldReturnOk_WhenDataIsValid()
    {
        // Arrange
        var newImageMaintenance = new AdministrationService.API.Models.RequestModels.ImageMaintenance.CreateImageMaintenanceRequest()
        {
            Description = "description",
            Header = "header",
            ScreenType = "0",
        };
        _regionHelperMock.Setup(r => r.VerifyRegionCodeHeader(It.IsAny<Microsoft.AspNetCore.Http.HttpRequest>()))
            .Returns(It.IsAny<GenericResponse<string>>());
        _regionHelperMock.Setup(r => r.GetUserIdByToken(It.IsAny<Microsoft.AspNetCore.Http.HttpRequest>())).Returns("testuser");
        _imageMaintenanceCommandServicesMock.Setup(s => s.CreateImageMaintenance(It.IsAny<string>(), It.IsAny<AdministrationService.API.Models.RequestModels.ImageMaintenance.CreateImageMaintenanceRequest>()))
            .ReturnsAsync(new GenericResponse<string> { IsSuccess = true });

        // Act
        var result = await _controller.CreateImage(newImageMaintenance);

        // Assert
        var okResult = Assert.IsType<OkObjectResult>(result);
        Assert.Equal(StatusCodes.Status200OK, okResult.StatusCode);
    }

    [Fact]
    public async Task CreateImage_ShouldReturnBadRequest_WhenRequestIsNull()
    {
        // Act
        var result = await _controller.CreateImage(null);

        // Assert
        result.Should().BeOfType<BadRequestResult>()
            .Which.StatusCode.Should().Be(StatusCodes.Status400BadRequest);
    }

    [Fact]
    public async Task CreateImage_ShouldReturnBadRequest_WhenServiceReturnsNull()
    {
        // Arrange
        var newImageMaintenance = new AdministrationService.API.Models.RequestModels.ImageMaintenance.CreateImageMaintenanceRequest()
        {
            Description = "description",
            Header = "header",
            ScreenType = "0",
        };

        _regionHelperMock.Setup(r => r.VerifyRegionCodeHeader(It.IsAny<Microsoft.AspNetCore.Http.HttpRequest>()))
            .Returns(It.IsAny<GenericResponse<string>>());
        _regionHelperMock.Setup(r => r.GetUserIdByToken(It.IsAny<Microsoft.AspNetCore.Http.HttpRequest>())).Returns("testuser");

        _imageMaintenanceCommandServicesMock.Setup(s => s.CreateImageMaintenance(It.IsAny<string>(), It.IsAny<AdministrationService.API.Models.RequestModels.ImageMaintenance.CreateImageMaintenanceRequest>()))
            .ReturnsAsync((GenericResponse<string>)null); // Simulating a null response

        // Act
        var result = await _controller.CreateImage(newImageMaintenance);

        // Assert
        result.Should().BeOfType<BadRequestResult>()
            .Which.StatusCode.Should().Be(StatusCodes.Status400BadRequest);
    }

    [Fact]
    public async Task UpdateImage_ShouldReturnNotFound_WhenImageMaintenanceNotFound()
    {
        // Arrange
        var updateRequest = new UpdateImageMaintainanceRequests()
        {
            Description = "description",
            Header = "header",
            ScreenType = "0",
        };
        _regionHelperMock.Setup(r => r.VerifyRegionCodeHeader(It.IsAny<Microsoft.AspNetCore.Http.HttpRequest>()))
            .Returns(It.IsAny<GenericResponse<string>>());
        _imageMaintenanceQueryServiceMock.Setup(q => q.FindImageMaintenanceById(1))
            .ReturnsAsync(It.IsAny<Domain.V1.Entities.ImageMaintenance>());

        // Act
        var result = await _controller.UpdateImage(1, updateRequest);

        // Assert
        var notFoundResult = Assert.IsType<NotFoundObjectResult>(result);
        Assert.Equal(StatusCodes.Status404NotFound, notFoundResult.StatusCode);
    }

    [Fact]
    public async Task UpdateImage_ShouldReturnOk_WhenUpdateIsSuccessful()
    {
        // Arrange
        var updateRequest = new UpdateImageMaintainanceRequests()
        {
            Description = "description",
            Header = "header",
            ScreenType = "0",
        };
        var existingImageMaintenance = new Domain.V1.Entities.ImageMaintenance
        {
            Id = 1,
            CreatedBy = "34",
            CreatedDate = DateTime.Now,
            IsDeleted = false,
            Status = true,

        };
        _regionHelperMock.Setup(r => r.VerifyRegionCodeHeader(It.IsAny<Microsoft.AspNetCore.Http.HttpRequest>()))
            .Returns(It.IsAny<GenericResponse<string>>());
        _regionHelperMock.Setup(r => r.GetUserIdByToken(It.IsAny<Microsoft.AspNetCore.Http.HttpRequest>())).Returns("testuser");
        _imageMaintenanceQueryServiceMock.Setup(q => q.FindImageMaintenanceById(1))
            .ReturnsAsync(existingImageMaintenance);
        _imageMaintenanceCommandServicesMock.Setup(s => s.UpdateImageMaintenance(It.IsAny<string>(), It.IsAny<UpdateImageMaintainanceRequests>(), It.IsAny<Domain.V1.Entities.ImageMaintenance>()))
            .ReturnsAsync(new GenericResponse<string> { IsSuccess = true });

        // ActUpdateImage_ShouldReturnBadRequest_WhenRequestIsNull
        var result = await _controller.UpdateImage(1, updateRequest);

        // Assert
        var okResult = Assert.IsType<OkObjectResult>(result);
        Assert.Equal(StatusCodes.Status200OK, okResult.StatusCode);
    }

    [Fact]
    public async Task UpdateImage_ShouldReturnBadRequest_WhenRegionCodeHeaderIsInvalid()
    {
        // Arrange
        var updateRequest = new UpdateImageMaintainanceRequests()
        {
            Description = "description",
            Header = "header",
            ScreenType = "0",
        };

        _regionHelperMock.Setup(r => r.VerifyRegionCodeHeader(It.IsAny<Microsoft.AspNetCore.Http.HttpRequest>()))
            .Returns(new GenericResponse<string> { HasError = true });

        // Act
        var result = await _controller.UpdateImage(1, updateRequest);

        // Assert
        result.Should().BeOfType<BadRequestObjectResult>()
            .Which.StatusCode.Should().Be(StatusCodes.Status400BadRequest);
    }

    [Fact]
    public async Task UpdateImage_ShouldReturnBadRequest_WhenRequestIsNull()
    {
        // Act
        var result = await _controller.UpdateImage(1, null);

        // Assert
        result.Should().BeOfType<BadRequestResult>()
            .Which.StatusCode.Should().Be(StatusCodes.Status400BadRequest);
    }

    [Fact]
    public async Task UpdateImage_ShouldReturnBadRequest_WhenUpdateImageMaintenanceReturnsNull()
    {
        // Arrange
        var updateRequest = new UpdateImageMaintainanceRequests()
        {
            Description = "description",
            Header = "header",
            ScreenType = "0",
        };
        var existingImageMaintenance = new Domain.V1.Entities.ImageMaintenance
        {
            Id = 1,
            CreatedBy = "34",
            CreatedDate = DateTime.Now,
            IsDeleted = false,
            Status = true,
        };

        _regionHelperMock.Setup(r => r.VerifyRegionCodeHeader(It.IsAny<Microsoft.AspNetCore.Http.HttpRequest>()))
            .Returns(It.IsAny<GenericResponse<string>>());
        _regionHelperMock.Setup(r => r.GetUserIdByToken(It.IsAny<Microsoft.AspNetCore.Http.HttpRequest>())).Returns("testuser");
        _imageMaintenanceQueryServiceMock.Setup(q => q.FindImageMaintenanceById(1))
            .ReturnsAsync(existingImageMaintenance);

        _imageMaintenanceCommandServicesMock.Setup(s => s.UpdateImageMaintenance(It.IsAny<string>(), It.IsAny<UpdateImageMaintainanceRequests>(), It.IsAny<Domain.V1.Entities.ImageMaintenance>()))
            .ReturnsAsync((GenericResponse<string>)null); // Simulating a null response

        // Act
        var result = await _controller.UpdateImage(1, updateRequest);

        // Assert
        result.Should().BeOfType<BadRequestResult>()
            .Which.StatusCode.Should().Be(StatusCodes.Status400BadRequest);
    }

    [Fact]
    public async Task DeleteOnBoardingImage_ShouldReturnNotFound_WhenImageMaintenanceNotFound()
    {
        // Arrange
        _regionHelperMock.Setup(r => r.VerifyRegionCodeHeader(It.IsAny<Microsoft.AspNetCore.Http.HttpRequest>()))
            .Returns(It.IsAny<GenericResponse<string>>());
        _imageMaintenanceQueryServiceMock.Setup(q => q.FindImageMaintenanceById(1))
            .ReturnsAsync(It.IsAny<Domain.V1.Entities.ImageMaintenance>());

        // Act
        var result = await _controller.DeleteOnBoardingImage(1);

        // Assert
        var notFoundResult = Assert.IsType<NotFoundObjectResult>(result);
        Assert.Equal(StatusCodes.Status404NotFound, notFoundResult.StatusCode);
    }

    [Fact]
    public async Task DeleteOnBoardingImage_ShouldReturnOk_WhenDeleteIsSuccessful()
    {
        // Arrange
        var existingImageMaintenance = new Domain.V1.Entities.ImageMaintenance
        {
            Id = 1,
            CreatedBy = "34",
            CreatedDate = DateTime.Now,
            IsDeleted = false,
            Status = true,
        };
        _regionHelperMock.Setup(r => r.VerifyRegionCodeHeader(It.IsAny<Microsoft.AspNetCore.Http.HttpRequest>()))
            .Returns(It.IsAny<GenericResponse<string>>());
        _regionHelperMock.Setup(r => r.GetUserIdByToken(It.IsAny<Microsoft.AspNetCore.Http.HttpRequest>())).Returns("testuser");
        _imageMaintenanceQueryServiceMock.Setup(q => q.FindImageMaintenanceById(1))
            .ReturnsAsync(existingImageMaintenance);
        _imageMaintenanceCommandServicesMock.Setup(s => s.DeleteImageMaintenanceById(It.IsAny<string>(), It.IsAny<byte[]>(), It.IsAny<Domain.V1.Entities.ImageMaintenance>()))
            .ReturnsAsync(new GenericResponse<string> { IsSuccess = true });

        // Act
        var result = await _controller.DeleteOnBoardingImage(1);

        // Assert
        var okResult = Assert.IsType<OkObjectResult>(result);
        Assert.Equal(StatusCodes.Status200OK, okResult.StatusCode);
    }

    [Fact]
public async Task DeleteOnBoardingImage_ShouldReturnBadRequest_WhenIdIsInvalid()
{
    // Act
    var result = await _controller.DeleteOnBoardingImage(0);

    // Assert
    result.Should().BeOfType<BadRequestResult>()
        .Which.StatusCode.Should().Be(StatusCodes.Status400BadRequest);
}

[Fact]
public async Task DeleteOnBoardingImage_ShouldReturnBadRequest_WhenRegionCodeHeaderIsInvalid()
{
    // Arrange
    _regionHelperMock.Setup(r => r.VerifyRegionCodeHeader(It.IsAny<Microsoft.AspNetCore.Http.HttpRequest>()))
        .Returns(new GenericResponse<string> { HasError = true });

    // Act
    var result = await _controller.DeleteOnBoardingImage(1);

    // Assert
    result.Should().BeOfType<BadRequestObjectResult>()
        .Which.StatusCode.Should().Be(StatusCodes.Status400BadRequest);
}

[Fact]
public async Task DeleteOnBoardingImage_ShouldReturnBadRequest_WhenDeleteImageMaintenanceReturnsNull()
{
    // Arrange
    var existingImageMaintenance = new Domain.V1.Entities.ImageMaintenance
    {
        Id = 1,
        CreatedBy = "34",
        CreatedDate = DateTime.Now,
        IsDeleted = false,
        Status = true,
        RecordVersion = Array.Empty<byte>()
    };

    _regionHelperMock.Setup(r => r.VerifyRegionCodeHeader(It.IsAny<Microsoft.AspNetCore.Http.HttpRequest>()))
        .Returns(It.IsAny<GenericResponse<string>>());
    _regionHelperMock.Setup(r => r.GetUserIdByToken(It.IsAny<Microsoft.AspNetCore.Http.HttpRequest>())).Returns("testuser");
    _imageMaintenanceQueryServiceMock.Setup(q => q.FindImageMaintenanceById(1))
        .ReturnsAsync(existingImageMaintenance);
    _imageMaintenanceCommandServicesMock.Setup(s => s.DeleteImageMaintenanceById(It.IsAny<string>(), It.IsAny<byte[]>(), It.IsAny<Domain.V1.Entities.ImageMaintenance>()))
        .ReturnsAsync((GenericResponse<string>)null);

    // Act
    var result = await _controller.DeleteOnBoardingImage(1);

    // Assert
    result.Should().BeOfType<BadRequestResult>()
        .Which.StatusCode.Should().Be(StatusCodes.Status400BadRequest);
}

    [Fact]
    public async Task UpdateImageStatus_ShouldReturnBadRequest_WhenRequestIsNull()
    {
        // Arrange
        UpdateImageMaintenanceStatusRequests? updateRequest = null;

        // Act
#pragma warning disable CS8604 // Possible null reference argument.
        var result = await _controller.UpdateImageStatus(1, updateRequest);
#pragma warning restore CS8604 // Possible null reference argument.

        // Assert
        var badRequestResult = Assert.IsType<BadRequestResult>(result);
        Assert.Equal(StatusCodes.Status400BadRequest, badRequestResult.StatusCode);
    }

    [Fact]
    public async Task UpdateImageStatus_ShouldReturnBadRequest_WhenRegionCodeHeaderIsInvalid()
    {
        // Arrange
        var updateRequest = new UpdateImageMaintenanceStatusRequests()
        {
            Id = 1,
            Status = false,
        };
        _regionHelperMock.Setup(r => r.VerifyRegionCodeHeader(It.IsAny<Microsoft.AspNetCore.Http.HttpRequest>()))
            .Returns(new GenericResponse<string> { HasError = true });

        // Act
        var result = await _controller.UpdateImageStatus(1, updateRequest);

        // Assert
        var badRequestResult = Assert.IsType<BadRequestObjectResult>(result);
        Assert.Equal(StatusCodes.Status400BadRequest, badRequestResult.StatusCode);
    }

    [Fact]
    public async Task UpdateImageStatus_ShouldReturnNotFound_WhenImageMaintenanceNotFound()
    {
        // Arrange
        var updateRequest = new UpdateImageMaintenanceStatusRequests()
        {
            Id = 1,
            Status = false,
        };
        _regionHelperMock.Setup(r => r.VerifyRegionCodeHeader(It.IsAny<Microsoft.AspNetCore.Http.HttpRequest>()))
            .Returns(It.IsAny<GenericResponse<string>>());
        _imageMaintenanceQueryServiceMock.Setup(q => q.FindImageMaintenanceById(1))
            .ReturnsAsync(It.IsAny<Domain.V1.Entities.ImageMaintenance>());

        // Act
        var result = await _controller.UpdateImageStatus(1, updateRequest);

        // Assert
        var notFoundResult = Assert.IsType<NotFoundObjectResult>(result);
        var response = Assert.IsType<GenericResponse<string>>(notFoundResult.Value);
        Assert.Equal(StatusCodes.Status404NotFound.ToString(), response.StatusCode);
    }

    [Fact]
    public async Task UpdateImageStatus_ShouldReturnBadRequest_WhenUpdateFails()
    {
        // Arrange
        var updateRequest = new UpdateImageMaintenanceStatusRequests()
        {
            Id = 1,
            Status = false,
        };
        var existingImageMaintenance = new Domain.V1.Entities.ImageMaintenance
        {
            Id = 1,
            CreatedBy = "2",
            CreatedDate = DateTime.UtcNow,
            IsDeleted = false,
            Status = false,
        };
        _regionHelperMock.Setup(r => r.VerifyRegionCodeHeader(It.IsAny<Microsoft.AspNetCore.Http.HttpRequest>()))
            .Returns(It.IsAny<GenericResponse<string>>());
        _regionHelperMock.Setup(r => r.GetUserIdByToken(It.IsAny<Microsoft.AspNetCore.Http.HttpRequest>())).Returns("testuser");
        _imageMaintenanceQueryServiceMock.Setup(q => q.FindImageMaintenanceById(1))
            .ReturnsAsync(existingImageMaintenance);
        _imageMaintenanceCommandServicesMock.Setup(s => s.UpdateStatusImageMaintenance(It.IsAny<string>(), It.IsAny<UpdateImageMaintenanceStatusRequests>(), It.IsAny<Domain.V1.Entities.ImageMaintenance>()))
            .ReturnsAsync(It.IsAny<GenericResponse<string>>());

        // Act
        var result = await _controller.UpdateImageStatus(1, updateRequest);

        // Assert
        var badRequestResult = Assert.IsType<BadRequestResult>(result);
        Assert.Equal(StatusCodes.Status400BadRequest, badRequestResult.StatusCode);
    }

    [Fact]
    public async Task UpdateImageStatus_ShouldReturnOk_WhenUpdateIsSuccessful()
    {
        // Arrange
        var updateRequest = new UpdateImageMaintenanceStatusRequests()
        {
            Id = 1,
            Status = false,
        };
        var existingImageMaintenance = new Domain.V1.Entities.ImageMaintenance
        {
            Id = 1,
            CreatedBy = "2",
            CreatedDate = DateTime.UtcNow,
            IsDeleted = false,
            Status = false,

        };
        var response = new GenericResponse<string> { IsSuccess = true };
        _regionHelperMock.Setup(r => r.VerifyRegionCodeHeader(It.IsAny<Microsoft.AspNetCore.Http.HttpRequest>()))
            .Returns(It.IsAny<GenericResponse<string>>());
        _regionHelperMock.Setup(r => r.GetUserIdByToken(It.IsAny<Microsoft.AspNetCore.Http.HttpRequest>())).Returns("testuser");
        _imageMaintenanceQueryServiceMock.Setup(q => q.FindImageMaintenanceById(1))
            .ReturnsAsync(existingImageMaintenance);
        _imageMaintenanceCommandServicesMock.Setup(s => s.UpdateStatusImageMaintenance(It.IsAny<string>(), It.IsAny<UpdateImageMaintenanceStatusRequests>(), It.IsAny<Domain.V1.Entities.ImageMaintenance>()))
            .ReturnsAsync(response);

        // Act
        var result = await _controller.UpdateImageStatus(1, updateRequest);

        // Assert
        var okResult = Assert.IsType<OkObjectResult>(result);
        Assert.Equal(StatusCodes.Status200OK, okResult.StatusCode);
    }



    #region GetImageMaintenances Tests
    [Fact]
    public async Task GetImageMaintenances_ShouldReturnBadRequest_WhenRegionCodeHeaderFails()
    {
        // Arrange
        _regionHelperMock.Setup(r => r.VerifyRegionCodeHeader(It.IsAny<Microsoft.AspNetCore.Http.HttpRequest>()))
            .Returns(new GenericResponse<string> { HasError = true });

        // Act
        var result = await _controller.GetImageMaintenances(1, 10);

        // Assert
        var badRequestResult = Assert.IsType<BadRequestObjectResult>(result);
        Assert.Equal(StatusCodes.Status400BadRequest, badRequestResult.StatusCode);
    }

    [Fact]
    public async Task GetImageMaintenances_ShouldReturnOk_WhenDataIsFound()
    {
        // Arrange
        var imageMaintenances = new GenericResponseList<ImageMaintenanceDetailDto>
        {
            IsSuccess = true,
            StatusCode = ResponseStatus.STATUS_SUCCESS,
            Results = new List<ImageMaintenanceDetailDto> { new ImageMaintenanceDetailDto() }
        };
        _regionHelperMock.Setup(r => r.VerifyRegionCodeHeader(It.IsAny<Microsoft.AspNetCore.Http.HttpRequest>()))
            .Returns(   It.IsAny<GenericResponse<string>>());
        _imageMaintenanceQueryServiceMock.Setup(q => q.GetImageMaintenancesBySearch(It.IsAny<ImageMaintenanceSearchRequest>()))
            .ReturnsAsync(imageMaintenances);

        // Act
        var result = await _controller.GetImageMaintenances(1, 10);

        // Assert
        var okResult = Assert.IsType<OkObjectResult>(result);
        Assert.Equal(StatusCodes.Status200OK, okResult.StatusCode);
    }
    #endregion

    #region SearchImage Tests
    [Fact]
    public async Task SearchImage_ShouldReturnBadRequest_WhenRegionCodeHeaderFails()
    {
        // Arrange
        _regionHelperMock.Setup(r => r.VerifyRegionCodeHeader(It.IsAny<Microsoft.AspNetCore.Http.HttpRequest>()))
            .Returns(new GenericResponse<string> { HasError = true });

        // Act
        var result = await _controller.SearchImage(1, 10, null, null, null);

        // Assert
        var badRequestResult = Assert.IsType<BadRequestObjectResult>(result);
        Assert.Equal(StatusCodes.Status400BadRequest, badRequestResult.StatusCode);
    }

    [Fact]
    public async Task SearchImage_ShouldReturnNotFound_WhenNoDataFound()
    {
        // Arrange
        var imageMaintenances = new GenericResponseList<ImageMaintenanceDetailDto>
        {
            IsSuccess = false,
            StatusCode = ResponseStatus.STATUS_NotFound,
            Results = new List<ImageMaintenanceDetailDto> { new ImageMaintenanceDetailDto() }
        };
        _regionHelperMock.Setup(r => r.VerifyRegionCodeHeader(It.IsAny<Microsoft.AspNetCore.Http.HttpRequest>()))
            .Returns(It.IsAny<GenericResponse<string>>());
        _imageMaintenanceQueryServiceMock.Setup(q => q.GetImageMaintenancesBySearch(It.IsAny<ImageMaintenanceSearchRequest>()))
            .ReturnsAsync(imageMaintenances);

        // Act
        var result = await _controller.SearchImage(1, 10, null, null, null);

        // Assert
        var notFoundResult = Assert.IsType<NotFoundObjectResult>(result);
        var response = Assert.IsType< GenericResponseList < ImageMaintenanceDetailDto>>(notFoundResult.Value);
        Assert.Equal(ResponseStatus.STATUS_NotFound, response.StatusCode);
    }

    [Fact]
    public async Task SearchImage_ShouldReturnOk_WhenDataIsFound()
    {
        // Arrange
        var imageMaintenances = new GenericResponseList<ImageMaintenanceDetailDto>
        {
            IsSuccess = false,
            StatusCode = ResponseStatus.STATUS_SUCCESS,
            Results = new List<ImageMaintenanceDetailDto> { new ImageMaintenanceDetailDto() }
        };
        _regionHelperMock.Setup(r => r.VerifyRegionCodeHeader(It.IsAny<Microsoft.AspNetCore.Http.HttpRequest>()))
            .Returns(It.IsAny<GenericResponse<string>>());
        _imageMaintenanceQueryServiceMock.Setup(q => q.GetImageMaintenancesBySearch(It.IsAny<ImageMaintenanceSearchRequest>()))
            .ReturnsAsync(imageMaintenances);

        // Act
        var result = await _controller.SearchImage(1, 10, null, null, null);

        // Assert
        var okResult = Assert.IsType<OkObjectResult>(result);
        Assert.Equal(StatusCodes.Status200OK, okResult.StatusCode);
    }

    [Fact]
    public async Task SearchImage_ShouldReturnBadRequest_WhenQueryReturnsNull()
    {
        // Arrange
        _regionHelperMock.Setup(r => r.VerifyRegionCodeHeader(It.IsAny<Microsoft.AspNetCore.Http.HttpRequest>()))
            .Returns(It.IsAny<GenericResponse<string>>());

        _imageMaintenanceQueryServiceMock.Setup(q => q.GetImageMaintenancesBySearch(It.IsAny<ImageMaintenanceSearchRequest>()))
            .ReturnsAsync((GenericResponseList<ImageMaintenanceDetailDto>)null);

        // Act
        var result = await _controller.SearchImage(1, 10, null, null, null);

        // Assert
        result.Should().BeOfType<BadRequestResult>()
            .Which.StatusCode.Should().Be(StatusCodes.Status400BadRequest);
    }

    [Fact]
    public async Task SearchImage_ShouldReturnInternalServerError_WhenQueryFails()
    {
        // Arrange
        var imageMaintenances = new GenericResponseList<ImageMaintenanceDetailDto>
        {
            IsSuccess = false,
            StatusCode = ResponseStatus.STATUS_InternalServerError
        };

        _regionHelperMock.Setup(r => r.VerifyRegionCodeHeader(It.IsAny<Microsoft.AspNetCore.Http.HttpRequest>()))
            .Returns(It.IsAny<GenericResponse<string>>());

        _imageMaintenanceQueryServiceMock.Setup(q => q.GetImageMaintenancesBySearch(It.IsAny<ImageMaintenanceSearchRequest>()))
            .ReturnsAsync(imageMaintenances);

        // Act
        var result = await _controller.SearchImage(1, 10, null, null, null);

        // Assert
        result.Should().BeOfType<ObjectResult>()
            .Which.StatusCode.Should().Be(StatusCodes.Status500InternalServerError);
    }

    [Fact]
    public async Task SearchImage_ShouldReturnOk_WithValidSearchParameters()
    {
        // Arrange
        var imageMaintenances = new GenericResponseList<ImageMaintenanceDetailDto>
        {
            IsSuccess = true,
            StatusCode = ResponseStatus.STATUS_SUCCESS,
            Results = new List<ImageMaintenanceDetailDto>
        {
            new ImageMaintenanceDetailDto { Id = 1, Header = "Test Image" }
        }
        };

        _regionHelperMock.Setup(r => r.VerifyRegionCodeHeader(It.IsAny<Microsoft.AspNetCore.Http.HttpRequest>()))
            .Returns(It.IsAny<GenericResponse<string>>());

        _imageMaintenanceQueryServiceMock.Setup(q => q.GetImageMaintenancesBySearch(It.IsAny<ImageMaintenanceSearchRequest>()))
            .ReturnsAsync(imageMaintenances);

        // Act
        var result = await _controller.SearchImage(1, 10, "0,1", DateTime.Now, "Active");

        // Assert
        result.Should().BeOfType<OkObjectResult>()
            .Which.StatusCode.Should().Be(StatusCodes.Status200OK);

        var response = (result as OkObjectResult)?.Value as GenericResponseList<ImageMaintenanceDetailDto>;
        response.Should().NotBeNull();
        response.Results.Should().HaveCountGreaterThan(0);
    }

    #endregion

    #region GetOnBoardingImageDetailById Tests
    [Fact]
    public async Task GetOnBoardingImageDetailById_ShouldReturnBadRequest_WhenRegionCodeHeaderFails()
    {
        // Arrange
        _regionHelperMock.Setup(r => r.VerifyRegionCodeHeader(It.IsAny<Microsoft.AspNetCore.Http.HttpRequest>()))
            .Returns(new GenericResponse<string> { HasError = true });

        // Act
        var result = await _controller.GetOnBoardingImageDetailById(1);

        // Assert
        var badRequestResult = Assert.IsType<BadRequestObjectResult>(result);
        Assert.Equal(StatusCodes.Status400BadRequest, badRequestResult.StatusCode);
    }

    [Fact]
    public async Task GetOnBoardingImageDetailById_ShouldReturnBadRequest_WhenIdIsInvalid()
    {
        // Act
        var result = await _controller.GetOnBoardingImageDetailById(0);

        // Assert
        var badRequestResult = Assert.IsType<BadRequestResult>(result);
        Assert.Equal(StatusCodes.Status400BadRequest, badRequestResult.StatusCode);
    }

    [Fact]
    public async Task GetOnBoardingImageDetailById_ShouldReturnNotFound_WhenNoDataFound()
    {
        // Arrange
        var imageMaintenances = new GenericResponse<ImageMaintenanceDetailDto>
        {
            IsSuccess = false,
            StatusCode = ResponseStatus.STATUS_NotFound,
            Result =  new ImageMaintenanceDetailDto() 
        };
        _regionHelperMock.Setup(r => r.VerifyRegionCodeHeader(It.IsAny<Microsoft.AspNetCore.Http.HttpRequest>()))
            .Returns(It.IsAny<GenericResponse<string>>());
        _imageMaintenanceQueryServiceMock.Setup(q => q.GetOnBoardImageMaintenanceDetailAsync(It.IsAny<int>()))
            .ReturnsAsync(imageMaintenances);

        // Act
        var result = await _controller.GetOnBoardingImageDetailById(1);

        // Assert
        var notFoundResult = Assert.IsType<NotFoundObjectResult>(result);
        var response = Assert.IsType<GenericResponse<ImageMaintenanceDetailDto>>(notFoundResult.Value);
        Assert.Equal(ResponseStatus.STATUS_NotFound, response.StatusCode);
    }

    [Fact]
    public async Task GetOnBoardingImageDetailById_ShouldReturnOk_WhenDataIsFound()
    {
        // Arrange
        var imageMaintenances = new GenericResponse<ImageMaintenanceDetailDto>
        {
            IsSuccess = true,
            StatusCode = ResponseStatus.STATUS_SUCCESS,
            Result = new ImageMaintenanceDetailDto()
        };
        _regionHelperMock.Setup(r => r.VerifyRegionCodeHeader(It.IsAny<Microsoft.AspNetCore.Http.HttpRequest>()))
            .Returns(It.IsAny<GenericResponse<string>>());
        _imageMaintenanceQueryServiceMock.Setup(q => q.GetOnBoardImageMaintenanceDetailAsync(It.IsAny<int>()))
            .ReturnsAsync(imageMaintenances);

        // Act
        var result = await _controller.GetOnBoardingImageDetailById(1);

        // Assert
        var okResult = Assert.IsType<OkObjectResult>(result);
        Assert.Equal(StatusCodes.Status200OK, okResult.StatusCode);
    }

    [Fact]
    public async Task GetOnBoardingImageDetailById_ShouldReturnInternalServerError_WhenServiceFails()
    {
        // Arrange
        var imageMaintenances = new GenericResponse<ImageMaintenanceDetailDto>
        {
            IsSuccess = false,
            StatusCode = ResponseStatus.STATUS_InternalServerError
        };

        _regionHelperMock.Setup(r => r.VerifyRegionCodeHeader(It.IsAny<Microsoft.AspNetCore.Http.HttpRequest>()))
            .Returns(It.IsAny<GenericResponse<string>>());

        _imageMaintenanceQueryServiceMock.Setup(q => q.GetOnBoardImageMaintenanceDetailAsync(It.IsAny<int>()))
            .ReturnsAsync(imageMaintenances);

        // Act
        var result = await _controller.GetOnBoardingImageDetailById(1);

        // Assert
        result.Should().BeOfType<ObjectResult>()
            .Which.StatusCode.Should().Be(StatusCodes.Status500InternalServerError);
    }
    #endregion

    #region GetScreenTypes Tests
    [Fact]
    public void GetScreenTypes_ShouldReturnBadRequest_WhenRegionCodeHeaderFails()
    {
        // Arrange
        _regionHelperMock.Setup(r => r.VerifyRegionCodeHeader(It.IsAny<Microsoft.AspNetCore.Http.HttpRequest>()))
            .Returns(new GenericResponse<string> { HasError = true });

        // Act
        var result =  _controller.GetScreenTypes();

        // Assert
        var badRequestResult = Assert.IsType<BadRequestObjectResult>(result);
        Assert.Equal(StatusCodes.Status400BadRequest, badRequestResult.StatusCode);
    }

     

    [Fact]
    public void GetScreenTypes_ShouldReturnOk_WhenDataIsFound()
    {
        // Arrange
        var imageMaintenances = new GenericResponse<ImageMaintenanceDetailDto>
        {
            IsSuccess = true,
            StatusCode = ResponseStatus.STATUS_SUCCESS,
            Result = new ImageMaintenanceDetailDto()
        };
        _regionHelperMock.Setup(r => r.VerifyRegionCodeHeader(It.IsAny<Microsoft.AspNetCore.Http.HttpRequest>()))
            .Returns(It.IsAny<GenericResponse<string>>());
        _imageMaintenanceQueryServiceMock.Setup(q => q.GetOnBoardImageMaintenanceDetailAsync(It.IsAny<int>()))
            .ReturnsAsync(imageMaintenances);

        // Act
        var result =  _controller.GetScreenTypes();

        // Assert
        var okResult = Assert.IsType<OkObjectResult>(result);
        Assert.Equal(StatusCodes.Status200OK, okResult.StatusCode);
    }

     
    #endregion
}