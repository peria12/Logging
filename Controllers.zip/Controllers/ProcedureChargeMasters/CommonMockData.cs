﻿using Aurora.AdministrationService.API.Models.Dto.ProcedureChargeMasters;
using Aurora.AdministrationService.Domain.V1.Entities.ProcedureChargeMasters;

namespace Aurora.AdministrationService.Tests.API.Controllers.ProcedureChargeMasters
{
    public static class CommonMockData
    {
        public static ProcedureChargeMaster GetMockProcedureChargeMaster()
        {
            return new ProcedureChargeMaster
            {
                MasterType = "TypeA",
                ItemCode = "Item001",
                ItemDescription = "Procedure Charge Master Description",
                ItemTypeCode = "Type001",
                ItemTypeDescription = "Service Item Type Description",
                FacilityCode = "FAC123",
                ProcedureCode = "test",
                ProcedureDesc = "test",
                CreatedBy = "Admin",
                UpdatedBy = "Admin",
                CreatedDate = DateTime.UtcNow,
                UpdatedDate = DateTime.UtcNow,
                IsDeleted = false,
                RecordVersion = new byte[] { 1, 2, 3, 4 }
            };
        }

        public static ProcedureChargeMasterDto GetMockProcedureChargeMasterDto()
        {
            return new ProcedureChargeMasterDto
            {
                MasterType = "TypeA",
                ItemCode = "Item001",
                ItemDescription = "Procedure Charge Master Description",
                ItemTypeCode = "Type001",
                ItemTypeDescription = "Service Item Type Description",
                FacilityCode = "FAC123",
                ProcedureCode = "test",
                ProcedureDesc = "test",
            };
        }

        public static ProcedureChargeMaster GetMockProcedureChargeMaster2(long id = 2)
        {
            return new ProcedureChargeMaster
            {
                Id = 2,
                MasterType = "TypeA",
                ItemCode = "Item001",
                ItemDescription = "Procedure Charge Master Description",
                ItemTypeCode = "Type001",
                ItemTypeDescription = "Service Item Type Description",
                FacilityCode = "FAC123",
                ProcedureCode = "test",
                ProcedureDesc = "test",
                CreatedBy = "Admin",
                UpdatedBy = "Admin",
                CreatedDate = DateTime.UtcNow,
                UpdatedDate = DateTime.UtcNow,
                IsDeleted = false,
                RecordVersion = new byte[] { 1, 2, 3, 4 }
            };
        }

        public static ProcedureChargeMasterDto GetMockCreateProcedureChargeMasterRequest()
        {
            var mockDto = GetMockProcedureChargeMasterDto();
            return new ProcedureChargeMasterDto
            {
                MasterType = mockDto.MasterType,
                ItemCode = mockDto.ItemCode,
                ItemDescription = mockDto.ItemDescription,
                ItemTypeCode = mockDto.ItemTypeCode,
                ItemTypeDescription = mockDto.ItemTypeDescription,
                FacilityCode = mockDto.FacilityCode,
                ProcedureCode = mockDto.ProcedureCode,
                ProcedureDesc = mockDto.ProcedureDesc
            };
        }

        public static ProcedureChargeMaster GetMockProcedureChargeMaster3(long id = 5)
        {
            return new ProcedureChargeMaster
            {
                Id = 5,
                MasterType = "TypeA",
                ItemCode = "Item001",
                ItemDescription = "Procedure Charge Master Description",
                ItemTypeCode = "Type001",
                ItemTypeDescription = "Service Item Type Description",
                FacilityCode = "FAC123",
                ProcedureCode = "test",
                ProcedureDesc = "test",
                CreatedBy = "Admin",
                UpdatedBy = "Admin",
                CreatedDate = DateTime.UtcNow,
                UpdatedDate = DateTime.UtcNow,
                IsDeleted = false,
                RecordVersion = new byte[] { 1, 2, 3, 4 }
            };
        }

        public static UpdateProcedureChargeMasterRequest GetMockUpdateProcedureChargeMasterRequest(string itemCode, byte[] recordVersion)
        {
            var mockDto = GetMockProcedureChargeMasterDto();
            return new UpdateProcedureChargeMasterRequest
            {
                MasterType = mockDto.MasterType,
                ItemCode = itemCode,
                ItemDescription = mockDto.ItemDescription,
                ItemTypeCode = mockDto.ItemTypeCode,
                ItemTypeDescription = mockDto.ItemTypeDescription,
                ProcedureCode = mockDto.ProcedureCode,
                ProcedureDesc = mockDto.ProcedureDesc,
                FacilityCode = mockDto.FacilityCode,
                RecordVersion = recordVersion // Use provided recordVersion or default
            };
        }
    }
}
