﻿using Aurora.AdministrationService.API.Controllers.ProcedureChargeMasters;
using Aurora.AdministrationService.API.Models.Dto.ProcedureChargeMasters;
using Aurora.AdministrationService.API.Services.IService.ProcedureChargeMasters;
using Aurora.AdministrationService.CrossCutting.CommonModels;
using Aurora.AdministrationService.CrossCutting.Constants;
using Aurora.AdministrationService.Domain.V1.Entities.ProcedureChargeMasters;
using AutoMapper;
using FluentAssertions;
using Microsoft.AspNetCore.Mvc;
using Moq;
using System.Net;
using System.Text;

namespace Aurora.AdministrationService.Tests.API.Controllers.ProcedureChargeMasters
{
    public class ProcedureChargeMasterControllerTests
    {
        private readonly Mock<IProcedureChargeMasterQueryService> _mockQueryService;
        private readonly Mock<IProcedureChargeMasterCommandService> _mockCommandService;
        private readonly Mock<IMapper> _mockMapper;
        private readonly ProcedureChargeMasterController _controller;

        public ProcedureChargeMasterControllerTests()
        {
            _mockQueryService = new Mock<IProcedureChargeMasterQueryService>();
            _mockCommandService = new Mock<IProcedureChargeMasterCommandService>();
            _mockMapper = new Mock<IMapper>();

            _controller = new ProcedureChargeMasterController
            (

                _mockCommandService.Object, _mockQueryService.Object, _mockMapper.Object
            );
        }

        [Theory]
        [InlineData(true, ResponseMessage.STATUS_DATA_UPDATED)]  // Update scenario
        [InlineData(false, ResponseMessage.STATUS_DATA_ADDED)]   // Add scenario
        public async Task AddOrUpdateProcedureChargeMaster_ShouldReturnCorrectResponse(bool doesExist, string expectedMessage)
        {
            // Arrange
            var procedureChargeMasterDto = CommonMockData.GetMockProcedureChargeMasterDto(); // Mock DTO

            var existingServiceEntity = doesExist ? new ProcedureChargeMaster
            {
                ItemCode = procedureChargeMasterDto.ItemCode,
                ItemDescription = procedureChargeMasterDto.ItemDescription,
                RecordVersion = Array.Empty<byte>(),
                IsDeleted = false,
                CreatedDate = DateTime.UtcNow.AddDays(-1),
                CreatedBy = "TestUser"
            } : null;

            _mockQueryService.Setup(q => q.CheckExistingProcedureChargeMasterAsync(procedureChargeMasterDto.ItemCode))
                .ReturnsAsync(existingServiceEntity!);

            if (doesExist)
            {
                var updateRequest = _mockMapper.Object.Map<UpdateProcedureChargeMasterRequest>(procedureChargeMasterDto);
                _mockMapper.Setup(m => m.Map<UpdateProcedureChargeMasterRequest>(procedureChargeMasterDto))
                    .Returns(updateRequest);

                _mockCommandService.Setup(c => c.UpdateProcedureChargeMasterAsync(updateRequest, It.IsAny<ProcedureChargeMaster>()))
                    .ReturnsAsync( true );
            }
            else
            {
                var newRequest = _mockMapper.Object.Map<ProcedureChargeMasterDto>(procedureChargeMasterDto);
                _mockMapper.Setup(m => m.Map<ProcedureChargeMasterDto>(procedureChargeMasterDto))
                    .Returns(newRequest);

                _mockCommandService.Setup(c => c.CreateProcedureChargeMasterAsync(newRequest))
                    .ReturnsAsync(true);
            }

            // Act
            var result = await _controller.AddOrUpdateProcedureChargeMaster(procedureChargeMasterDto);

            // Assert
            var okResult = result.Should().BeOfType<OkObjectResult>().Subject;
            var response = okResult.Value.Should().BeOfType<GenericResponse<string>>().Subject;

            response.IsSuccess.Should().BeTrue();
            response.StatusCode.Should().Be(ResponseStatusCode.STATUS_SUCCESS);

            response.Message.Should().Be(expectedMessage);

            response.HasError.Should().BeFalse();
            response.MessageType.Should().Be(CommonConstants.SUCCESS);

            if (doesExist)
            {
                _mockCommandService.Verify(c => c.UpdateProcedureChargeMasterAsync(It.IsAny<UpdateProcedureChargeMasterRequest>(), It.IsAny<ProcedureChargeMaster>()), Times.Once);
                _mockCommandService.Verify(c => c.CreateProcedureChargeMasterAsync(It.IsAny<ProcedureChargeMasterDto>()), Times.Never);
            }
            else
            {
                _mockCommandService.Verify(c => c.CreateProcedureChargeMasterAsync(It.IsAny<ProcedureChargeMasterDto>()), Times.Once);
                _mockCommandService.Verify(c => c.UpdateProcedureChargeMasterAsync(It.IsAny<UpdateProcedureChargeMasterRequest>(), It.IsAny<ProcedureChargeMaster>()), Times.Never);
            }
        }


        [Fact]
        public async Task AddOrUpdateProcedureChargeMaster_ShouldReturnBadRequest_WhenModelStateIsInvalid()
        {
            // Arrange
            _controller.ModelState.AddModelError("ItemCode", "ItemCode is required");

            var procedureChargeMasterDto = new ProcedureChargeMasterDto
            {
                ItemCode = "SCM001",
                ItemDescription = "Sample Item"
            };

            // Act
            var result = await _controller.AddOrUpdateProcedureChargeMaster(procedureChargeMasterDto);

            // Assert
            var badRequestResult = result.Should().BeOfType<BadRequestObjectResult>().Subject;
            var modelState = badRequestResult.Value.Should().BeOfType<SerializableError>().Subject;
            modelState.Should().ContainKey("ItemCode");
        }

        [Fact]
        public async Task DeleteProcedureChargeMaster_ShouldReturnSuccess_WhenRecordExists()
        {
            // Arrange
            var itemCode = "SER123";
            var existingService = new ProcedureChargeMaster
            {
                ItemCode = "SCM001",
                ItemDescription = "Sample Item", // Required property
                RecordVersion = Encoding.UTF8.GetBytes("1"),
                IsDeleted = false,
                CreatedDate = DateTime.UtcNow,
                CreatedBy = "TestUser1"// Corrected for byte[] type
            };

            _mockQueryService.Setup(q => q.CheckExistingProcedureChargeMasterAsync(itemCode))
                .ReturnsAsync(existingService);

            _mockCommandService.Setup(c => c.DeleteProcedureChargeMasterByIdAsync(existingService.RecordVersion, existingService))
                .ReturnsAsync(true);

            // Act
            var result = await _controller.DeleteProcedureChargeMaster(itemCode);

            // Assert
            var okResult = result.Should().BeOfType<OkObjectResult>().Subject;
            var response = okResult.Value.Should().BeOfType<GenericResponse<string>>().Subject;

            response.IsSuccess.Should().BeTrue();
            response.StatusCode.Should().Be(ResponseStatusCode.STATUS_SUCCESS);
            response.Message.Should().Be(ResponseMessage.STATUS_DATA_DELETED);
            response.HasError.Should().BeFalse();
            response.MessageType.Should().Be(CommonConstants.SUCCESS);

            _mockQueryService.Verify(q => q.CheckExistingProcedureChargeMasterAsync(itemCode), Times.Once);
            _mockCommandService.Verify(c => c.DeleteProcedureChargeMasterByIdAsync(existingService.RecordVersion, existingService), Times.Once);
        }

        [Fact]
        public async Task DeleteProcedureChargeMaster_ShouldReturnNotFound_WhenRecordDoesNotExist()
        {
            // Arrange
            var itemCode = "INVALID_Service";

            _mockQueryService.Setup(q => q.CheckExistingProcedureChargeMasterAsync(itemCode))
                .ReturnsAsync((ProcedureChargeMaster)null!);

            // Act
            var result = await _controller.DeleteProcedureChargeMaster(itemCode);

            // Assert
            var notFoundResult = result.Should().BeOfType<NotFoundObjectResult>().Subject;
            var response = notFoundResult.Value.Should().BeOfType<GenericResponse<string>>().Subject;

            response.IsSuccess.Should().BeFalse();
            response.StatusCode.Should().Be(ResponseStatusCode.STATUS_NOTFOUND);
            response.Message.Should().Be(ResponseMessage.STATUS_NODATA);
            response.HasError.Should().BeTrue();
            response.MessageType.Should().Be(CommonConstants.ERROR);

            _mockQueryService.Verify(q => q.CheckExistingProcedureChargeMasterAsync(itemCode), Times.Once);
            _mockCommandService.Verify(c => c.DeleteProcedureChargeMasterByIdAsync(It.IsAny<byte[]>(), It.IsAny<ProcedureChargeMaster>()), Times.Never);
        }

        [Fact]
        public async Task GetProcedureChargeMasterById_ShouldReturnNotFound_WhenRecordDoesNotExist()
        {
            // Arrange
            var id = 999;  // Non-existent ID
            _mockQueryService.Setup(q => q.GetProcedureChargeMasterById(id))
                .ReturnsAsync((GetProcedureChargeMasterDetailDto)null!);

            // Act
            var result = await _controller.GetProcedureChargeById(id);

            // Assert
            var notFoundResult = result.Should().BeOfType<NotFoundObjectResult>().Subject;
            var response = notFoundResult.Value.Should().BeOfType<GenericResponse<string>>().Subject;

            response.IsSuccess.Should().BeFalse();
            response.StatusCode.Should().Be(ResponseStatusCode.STATUS_NOTFOUND);
            response.Message.Should().Be(ResponseMessage.STATUS_NODATA);
            response.HasError.Should().BeTrue();
            response.MessageType.Should().Be(CommonConstants.ERROR);

            _mockQueryService.Verify(q => q.GetProcedureChargeMasterById(id), Times.Once);
        }

        [Fact]
        public async Task GetProcedureChargeMasterById_ShouldReturnOk_WhenRecordExists()
        {
            // Arrange
            var id = 123; // Existing ID
            var procedureChargeMasterDetail = new GetProcedureChargeMasterDetailDto
            {
                ItemCode = "Ser123",
                MasterType = "General",
                IsDeleted = false,
                RecordVersion=new byte[] {1,1,1,1 }
            };

            _mockQueryService.Setup(q => q.GetProcedureChargeMasterById(id))
                .ReturnsAsync(procedureChargeMasterDetail);

            // Act
            var result = await _controller.GetProcedureChargeById(id);

            // Assert
            var okResult = result.Should().BeOfType<OkObjectResult>().Subject;
            var response = okResult.Value.Should().BeOfType<GenericResponse<GetProcedureChargeMasterDetailDto>>().Subject;

            response.IsSuccess.Should().BeTrue();
            response.StatusCode.Should().Be(ResponseStatusCode.STATUS_SUCCESS);
            response.Message.Should().Be(ResponseMessage.STATUS_DATA_FOUND);
            response.HasError.Should().BeFalse();
            response.MessageType.Should().Be(CommonConstants.SUCCESS);
            response.Result.Should().NotBeNull();
            response.Result?.ItemCode.Should().Be("Ser123");

            _mockQueryService.Verify(q => q.GetProcedureChargeMasterById(id), Times.Once);
        }

        [Fact]
        public async Task GetProcedureChargeMasterList_ShouldReturnNotFound_WhenNoRecordsExist()
        {

            // Arrange
            _mockQueryService.Setup(q => q.GetProcedureChargeMasterList())
                .ReturnsAsync((List<GetProcedureChargeMasterDto>)null!); // Explicitly mark as nullable

            // Act
            var result = await _controller.GetProcedureChargeList();

            // Assert
            var notFoundResult = result.Should().BeOfType<NotFoundObjectResult>().Subject;
            var response = notFoundResult.Value.Should().BeOfType<GenericResponse<string>>().Subject;

            response.IsSuccess.Should().BeFalse();
            response.StatusCode.Should().Be(ResponseStatusCode.STATUS_NOTFOUND);
            response.Message.Should().Be(ResponseMessage.STATUS_NODATA);
            response.HasError.Should().BeTrue();
            response.MessageType.Should().Be(CommonConstants.ERROR);

            _mockQueryService.Verify(q => q.GetProcedureChargeMasterList(), Times.Once);
        }

        [Fact]
        public async Task GetProcedureChargeMasterList_ShouldReturnNotFound_WhenListIsEmpty()
        {
            // Arrange
            _mockQueryService.Setup(q => q.GetProcedureChargeMasterList())
                .ReturnsAsync(new List<GetProcedureChargeMasterDto>()); // Empty list

            // Act
            var result = await _controller.GetProcedureChargeList();

            // Assert
            var notFoundResult = result.Should().BeOfType<NotFoundObjectResult>().Subject;
            var response = notFoundResult.Value.Should().BeOfType<GenericResponse<string>>().Subject;

            response.IsSuccess.Should().BeFalse();
            response.StatusCode.Should().Be(ResponseStatusCode.STATUS_NOTFOUND);
            response.Message.Should().Be(ResponseMessage.STATUS_NODATA);
            response.HasError.Should().BeTrue();
            response.MessageType.Should().Be(CommonConstants.ERROR);

            _mockQueryService.Verify(q => q.GetProcedureChargeMasterList(), Times.Once);
        }

        [Fact]
        public async Task GetProcedureChargeMasterList_ShouldReturnOk_WhenRecordsExist()
        {
            // Arrange
            var procedureChargeMasterList = new List<GetProcedureChargeMasterDto>
            {
                new GetProcedureChargeMasterDto
                {
                  ItemCode = "Ser123",
                    MasterType = "General",
                    IsDeleted = false,
                    RecordVersion = new byte[]{1,1,1,1 }
                },
                new GetProcedureChargeMasterDto
                {
                   ItemCode = "Ser123123",
                    MasterType = "General",
                    IsDeleted = false,
                    RecordVersion = new byte[]{1,1,1,1 }
                }
            };

            _mockQueryService.Setup(q => q.GetProcedureChargeMasterList())
                .ReturnsAsync(procedureChargeMasterList);

            // Act
            var result = await _controller.GetProcedureChargeList();

            // Assert
            var okResult = result.Should().BeOfType<OkObjectResult>().Subject;
            var response = okResult.Value.Should().BeOfType<GenericResponse<List<GetProcedureChargeMasterDto>>>().Subject;
            response.IsSuccess.Should().BeTrue();
            response.StatusCode.Should().Be(ResponseStatusCode.STATUS_SUCCESS);
            response.Message.Should().Be(ResponseMessage.STATUS_DATA_FOUND);
            response.HasError.Should().BeFalse();
            response.MessageType.Should().Be(CommonConstants.SUCCESS);
            response.Result.Should().NotBeNullOrEmpty();
            response.Result.Should().HaveCount(2);
            response.Result?[0].ItemCode.Should().Be("Ser123");
            response.Result?[^1].ItemCode.Should().Be("Ser123123");
            _mockQueryService.Verify(q => q.GetProcedureChargeMasterList(), Times.Once);
        }
        [Fact]
        public async Task DeleteProcedureChargeMaster_ShouldReturnBadRequest_WhenModelStateIsInvalid()
        {
            // Arrange
            var mockQueryService = new Mock<IProcedureChargeMasterQueryService>();
            var mockCommandService = new Mock<IProcedureChargeMasterCommandService>();

            //var controller = new (mockQueryService.Object, mockCommandService.Object);
            _controller.ModelState.AddModelError("itemCode", "ItemCode is required");

            // Act
            var result = await _controller.DeleteProcedureChargeMaster(string.Empty);

            // Assert
            result.Should().BeOfType<BadRequestObjectResult>()
                .Which.Value.Should().BeAssignableTo<SerializableError>();

            var badRequest = result as BadRequestObjectResult;
            badRequest.StatusCode.Should().Be((int)HttpStatusCode.BadRequest);
        }

    }
}
