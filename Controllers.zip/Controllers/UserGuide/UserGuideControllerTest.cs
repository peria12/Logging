﻿using Aurora.AdministrationService.API.Controllers.UserGuide;
using Aurora.AdministrationService.API.Enum.ImageMaintenance;
using Aurora.AdministrationService.API.Helper;
using Aurora.AdministrationService.API.Models.Dto.ImageMaintenance;
using Aurora.AdministrationService.API.Services.IService.ImageMaintenance;
using Aurora.AdministrationService.CrossCutting.CommonModels;
using Aurora.AdministrationService.CrossCutting.Constants;
using FluentAssertions;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Moq;

namespace Aurora.AdministrationService.Tests.API.Controllers.UserGuide
{
    public class UserGuideControllerTest
    {
        private readonly Mock<IImageMaintenanceQueryService> _mockImageMaintenanceQueryService;
        private readonly UserGuideController _controller;
        private readonly Mock<IRegionCodeValidationHelper> _regionHelperMock;

        public UserGuideControllerTest()
        {
            _regionHelperMock = new Mock<IRegionCodeValidationHelper>();
            _mockImageMaintenanceQueryService = new Mock<IImageMaintenanceQueryService>();
            _controller = new UserGuideController(_regionHelperMock.Object,_mockImageMaintenanceQueryService.Object);
        }
        [Fact]
        public async Task GetOnBoardingBackgroundImageDetail_InvalidRegionCode_ReturnsBadRequest()
        {
            // Arrange
            _regionHelperMock
                .Setup(helper => helper.VerifyRegionCodeHeader(It.IsAny<HttpRequest>()))
                .Returns(new GenericResponse<string> { HasError = true, Message = "Invalid RegionCode" });

            // Act
            var result = await _controller.GetOnBoardingBackgroundImageDetail();

            // Assert
            var badRequestResult = result as BadRequestObjectResult;
            badRequestResult.Should().NotBeNull();
            var response = badRequestResult?.Value as GenericResponse<string>;
            response.Should().NotBeNull();
            response?.HasError.Should().BeTrue();
            response?.Message.Should().Be("Invalid RegionCode");
        }

       

        [Fact]
        public async Task GetSplashScreenBackgroundImageDetail_InvalidRegionCode_ReturnsBadRequest()
        {
            // Arrange
            _regionHelperMock
                .Setup(helper => helper.VerifyRegionCodeHeader(It.IsAny<HttpRequest>()))
                .Returns(new GenericResponse<string> { HasError = true, Message = "Invalid RegionCode" });

            // Act
            var result =await _controller.GetSplashScreenBackgroundImageDetail();

            // Assert
            var badRequestResult = result as BadRequestObjectResult;
            badRequestResult.Should().NotBeNull();
            var response = badRequestResult?.Value as GenericResponse<string>;
            response.Should().NotBeNull();
            response?.HasError.Should().BeTrue();
            response?.Message.Should().Be("Invalid RegionCode");
        }

        

        [Fact]
        public void GetOnBoardingBackgroundImageDetail_ShouldReturnOnBoardingBackgroundImageDetailList()
        {
            // Arrange
             string spliterCharacter = "_";
            string replaceCharacter = " ";
            var onBoardingImageMaintenanceList = new List<OnBoardingImageMaintenanceDetailDto> { new OnBoardingImageMaintenanceDetailDto() };
            string[] selectedScreenTypes = new string[]
             {
                (System.Enum.GetName(ImageMaintenanceScreenType.OnBoarding_1)??string.Empty).Replace(spliterCharacter,replaceCharacter),
                (System.Enum.GetName(ImageMaintenanceScreenType.OnBoarding_2)??string.Empty).Replace(spliterCharacter,replaceCharacter),
                (System.Enum.GetName(ImageMaintenanceScreenType.OnBoarding_3)??string.Empty).Replace(spliterCharacter,replaceCharacter),
                (System.Enum.GetName(ImageMaintenanceScreenType.OnBoarding_4)??string.Empty).Replace(spliterCharacter,replaceCharacter),
                (System.Enum.GetName(ImageMaintenanceScreenType.OnBoarding_5)??string.Empty).Replace(spliterCharacter,replaceCharacter),
                (System.Enum.GetName(ImageMaintenanceScreenType.OnBoarding_6)??string.Empty).Replace(spliterCharacter,replaceCharacter),
                (System.Enum.GetName(ImageMaintenanceScreenType.OnBoarding_7)??string.Empty).Replace(spliterCharacter,replaceCharacter),
                (System.Enum.GetName(ImageMaintenanceScreenType.OnBoarding_8)??string.Empty).Replace(spliterCharacter,replaceCharacter),
                (System.Enum.GetName(ImageMaintenanceScreenType.OnBoarding_9)??string.Empty).Replace(spliterCharacter,replaceCharacter),
                (System.Enum.GetName(ImageMaintenanceScreenType.OnBoarding_10)??string.Empty).Replace(spliterCharacter,replaceCharacter),
             };

            _mockImageMaintenanceQueryService.Setup(service => service.GetImageMaintenancesByScreenType(selectedScreenTypes)).ReturnsAsync(onBoardingImageMaintenanceList);

            // Act
            var result = _controller.GetOnBoardingBackgroundImageDetail();
            var okresult = result?.Result as OkObjectResult;
            var response = okresult?.Value as GenericResponseList<OnBoardingImageMaintenanceDetailDto>;

            // Assert
            result.Should().NotBeNull();
            response?.StatusCode.Should().Be("200");
            response?.IsSuccess.Should().BeTrue();
            response?.StatusCode.Should().Be(ResponseStatusCode.STATUS_SUCCESS);
            response?.Message.Should().Be(ResponseMessage.STATUS_RECORDS_LOADED);

        }
        [Fact]
        public void GetSplashScreenBackgroundImageDetail_ShouldReturnOnBoardingBackgroundImageDetailList()
        {
            // Arrange
            string spliterCharacter = "_";
            string replaceCharacter = " ";
            var onBoardingImageMaintenanceList = new List<OnBoardingImageMaintenanceDetailDto> { new OnBoardingImageMaintenanceDetailDto() };
            string[] selectedScreenTypes = new string[]
           {
                (System.Enum.GetName(ImageMaintenanceScreenType.Splash_Screen_1)??string.Empty).Replace(spliterCharacter,replaceCharacter),
                (System.Enum.GetName(ImageMaintenanceScreenType.Splash_Screen_2)??string.Empty).Replace(spliterCharacter,replaceCharacter)
           };

            _mockImageMaintenanceQueryService.Setup(service => service.GetImageMaintenancesByScreenType(selectedScreenTypes)).ReturnsAsync(onBoardingImageMaintenanceList);

            // Act
            var result = _controller.GetSplashScreenBackgroundImageDetail();
            var okresult = result?.Result as OkObjectResult;
            var response = okresult?.Value as GenericResponseList<OnBoardingImageMaintenanceDetailDto>;

            // Assert
            result.Should().NotBeNull();
            response?.StatusCode.Should().Be("200");
            response?.IsSuccess.Should().BeTrue();
            response?.StatusCode.Should().Be(ResponseStatusCode.STATUS_SUCCESS);
            response?.Message.Should().Be(ResponseMessage.STATUS_RECORDS_LOADED);

        }

    }
}
