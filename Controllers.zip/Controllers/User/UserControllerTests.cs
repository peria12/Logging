﻿using Aurora.AdministrationService.API.Controllers.User;
using Aurora.AdministrationService.API.Enum.Patient;
using Aurora.AdministrationService.API.Helper;
using Aurora.AdministrationService.API.Models.Dto.Users;
using Aurora.AdministrationService.API.Models.Dto.Users.UserNames;
using Aurora.AdministrationService.API.Models.RequestModels.V1.User;
using Aurora.AdministrationService.API.Resources;
using Aurora.AdministrationService.API.Services.IService.Users;
using Aurora.AdministrationService.API.Services.IService.Users.UserIdentifiers;
using Aurora.AdministrationService.API.Services.IService.Users.UserNames;
using Aurora.AdministrationService.API.Services.IService.Users.UserTelecoms;
using Aurora.AdministrationService.API.Services.Service.Users;
using Aurora.AdministrationService.API.Services.Service.Users.UserNames;
using Aurora.AdministrationService.API.Services.Service.Users.UserTelecoms;
using Aurora.AdministrationService.CrossCutting.CommonModels;
using Aurora.AdministrationService.CrossCutting.Constants;
using AutoMapper;
using FluentAssertions;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Http.HttpResults;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using Moq;
using System.Security.Claims;

namespace Aurora.AdministrationService.Tests.API.Controllers.User
{
    public class UserControllerTests
    {

        private readonly Mock<IUserQueryService> _userServiceMock;
        private readonly Mock<IUserTelecomQueryService> _userTelecomQueryServiceMock;
        private readonly Mock<IUserIdentifierQueryService> _userIdentifierQueryServiceMock;
        private readonly Mock<IUserCommandService> _userCommandServiceMock;
        private readonly Mock<IUserNamesQueryService> _userNamesQueryServiceMock;
        private readonly Mock<IUserNamesCommandService> _userNamesCommandServiceMock;
        private readonly Mock<IRegionCodeValidationHelper> _regionCodeHelperMock;
        private readonly Mock<IValidationHelper> _validationHelperMock;
        private readonly Mock<IMapper> _mapperMock;
        private readonly UserController _controller;

        public UserControllerTests()
        {
            _userServiceMock = new Mock<IUserQueryService>();
            _userCommandServiceMock = new Mock<IUserCommandService>();
            _userTelecomQueryServiceMock = new Mock<IUserTelecomQueryService>();
            _userIdentifierQueryServiceMock = new Mock<IUserIdentifierQueryService>();
            _userNamesQueryServiceMock = new Mock<IUserNamesQueryService>();
            _userNamesCommandServiceMock = new Mock<IUserNamesCommandService>();
            _regionCodeHelperMock = new Mock<IRegionCodeValidationHelper>();
            _validationHelperMock = new Mock<IValidationHelper>();
            _mapperMock = new Mock<IMapper>();
            _controller = new UserController(
                _mapperMock.Object,
                _userServiceMock.Object,
                _userCommandServiceMock.Object,
                _userTelecomQueryServiceMock.Object,
                _userNamesQueryServiceMock.Object,
                _userNamesCommandServiceMock.Object,
                _userIdentifierQueryServiceMock.Object,
                _regionCodeHelperMock.Object,
                _validationHelperMock.Object
                );
        }

        [Fact]
        public async Task NewRegisterPatient_ShouldReturnBadRequest_WhenModelStateIsInvalid()
        {
            // Arrange
            _controller.ModelState.AddModelError("Error", "Invalid request");

            // Act
            var result = await _controller.NewRegisterPatient(new NewPatientRegistrationRequest() { Gender = "Male", Name = "Test", Nationality = "Indian", PhoneCountryCode = "+60", PhoneNumber = "12345" });

            // Assert
            result.Should().BeOfType<BadRequestObjectResult>();
        }

        [Fact]
        public async Task NewRegisterPatient_ShouldReturnBadRequest_WhenSignupValidationFails()
        {
            // Arrange
            var newPatientRequest = new NewPatientRegistrationRequest() { Gender = "Male", Name = "Test", Nationality = "Indian", PhoneCountryCode = "+60", PhoneNumber = "12345" };
            var validationResponse = new GenericResponse<string>
            {
                HasError = true,
                StatusCode = ResponseStatus.STATUS_BadRequest,
                Message = "Signup validation failed"
            };
            _regionCodeHelperMock.Setup(r => r.VerifyRegionCodeHeader(It.IsAny<HttpRequest>()))
                .Returns(new GenericResponse<string> { Result = "MYS" });

            _validationHelperMock.Setup(v => v.SignupValidation(It.IsAny<string>(), It.IsAny<NewPatientRegistrationRequest>()))
                .Returns(validationResponse);

            // Act
            var result = await _controller.NewRegisterPatient(newPatientRequest);

            // Assert
            var badRequestResult = result as BadRequestObjectResult;
            badRequestResult?.Should().NotBeNull();
            badRequestResult?.StatusCode.Should().Be(400);
        }

        [Fact]
        public async Task NewRegisterPatient_ShouldReturnBadRequest_WhenRegionCodeHeaderIsMissing()
        {
            // Arrange
            _regionCodeHelperMock
                .Setup(helper => helper.VerifyRegionCodeHeader(It.IsAny<HttpRequest>()))
                .Returns(new GenericResponse<string> { HasError = true, Message = "Invalid RegionCode" });


            _controller.ControllerContext = new ControllerContext
            {
                HttpContext = new DefaultHttpContext()
            };

            // Act
            var result = await _controller.NewRegisterPatient(new NewPatientRegistrationRequest() { Gender = "Male", Name = "Test", Nationality = "Indian", PhoneCountryCode = "+60", PhoneNumber = "12345" });

            // Assert
            result.Should().BeOfType<BadRequestObjectResult>();
        }
        [Fact]
        public async Task NewRegisterPatient_ShouldReturnOk_WhenValidRegionCodeAndRequest()
        {
            // Arrange
            var request = new NewPatientRegistrationRequest() { Gender = "Male", Name = "Test", Nationality = "Indian", PhoneCountryCode = "+60", PhoneNumber = "12345" };
            var selectedRegionCode = "MYS";
            var selectedIdentificationType = "MyKad_MyKid_MyPR";
            var validationResponse = new GenericResponse<string> { IsSuccess = true, Result = selectedIdentificationType };

            _regionCodeHelperMock.Setup(helper => helper.VerifyRegionCodeHeader(It.IsAny<HttpRequest>()))
                .Returns(new GenericResponse<string> { IsSuccess = true, Result = selectedRegionCode });

            _validationHelperMock.Setup(helper => helper.SignupValidation(selectedRegionCode, request))
                .Returns(validationResponse);

            var patientRequest = new PatientRegistrationRequest() { Gender = "Male", Name = "Test", Nationality = "Indian", PhoneCountryCode = "+60", PhoneNumber = "12345", IdentificationType = "Passport", PassportIssueCountry = "India", UHID = "test" };
            _mapperMock.Setup(m => m.Map<PatientRegistrationRequest>(It.IsAny<NewPatientRegistrationRequest>()))
                .Returns(patientRequest);

            var serviceResponse = new PatientSignUpResponseDto { UserId = "test", UserUniqueId = "test" };
            _userCommandServiceMock.Setup(service => service.NewPatientSignup(It.IsAny<PatientRegistrationRequest>()))
                .ReturnsAsync(serviceResponse);

            // Act
            var result = await _controller.NewRegisterPatient(request);

            // Assert
            result.Should().BeOfType<OkObjectResult>();
        }

        [Fact]
        public async Task NewRegisterPatient_ShouldReturnOk_WhenEmailExist()
        {
            // Arrange
            var request = new NewPatientRegistrationRequest() { Gender = "Male", Name = "Test", Nationality = "Indian", PhoneCountryCode = "+60", PhoneNumber = "12345" };
            var selectedRegionCode = "MYS";
            var selectedIdentificationType = "MyKad_MyKid_MyPR";
            var validationResponse = new GenericResponse<string> { IsSuccess = true, Result = selectedIdentificationType };

            _regionCodeHelperMock.Setup(helper => helper.VerifyRegionCodeHeader(It.IsAny<HttpRequest>()))
                .Returns(new GenericResponse<string> { IsSuccess = true, Result = selectedRegionCode });

            _validationHelperMock.Setup(helper => helper.SignupValidation(selectedRegionCode, request))
                .Returns(validationResponse);

            _userTelecomQueryServiceMock.Setup(telecom => telecom.IsUserEmailIdAlreadyExist(It.IsAny<string>()))
            .Returns(true);

            // Act
            var result = await _controller.NewRegisterPatient(request);

            // Assert
            result.Should().BeOfType<BadRequestObjectResult>();
        }
        [Fact]
        public async Task NewRegisterPatient_ShouldReturnOk_WhenPassportExist()
        {
            // Arrange
            var request = new NewPatientRegistrationRequest() { Gender = "Male", Name = "Test", Nationality = "Indian", PhoneCountryCode = "+60", PhoneNumber = "12345" };
            var selectedRegionCode = "MYS";
            var selectedIdentificationType = "MyKad_MyKid_MyPR";
            var validationResponse = new GenericResponse<string> { IsSuccess = true, Result = selectedIdentificationType };

            _regionCodeHelperMock.Setup(helper => helper.VerifyRegionCodeHeader(It.IsAny<HttpRequest>()))
                .Returns(new GenericResponse<string> { IsSuccess = true, Result = selectedRegionCode });

            _validationHelperMock.Setup(helper => helper.SignupValidation(selectedRegionCode, request))
                .Returns(validationResponse);

            _userTelecomQueryServiceMock.Setup(telecom => telecom.IsUserEmailIdAlreadyExist(It.IsAny<string>()))
            .Returns(false);
            _userTelecomQueryServiceMock.Setup(telecom => telecom.IsUserPhoneNumberAlreadyExist(It.IsAny<string>()))
            .Returns(true);

            // Act
            var result = await _controller.NewRegisterPatient(request);

            // Assert
            result.Should().BeOfType<BadRequestObjectResult>();
        }
        [Fact]
        public async Task NewRegisterPatient_ShouldReturnOk_WhenPassportNotExist()
        {
            // Arrange
            var request = new NewPatientRegistrationRequest() { Gender = "Male", Name = "Test", Nationality = "Indian", PhoneCountryCode = "+60", PhoneNumber = "12345" };
            var selectedRegionCode = "MYS";
            var selectedIdentificationType = "MyKad_MyKid_MyPR";
            var validationResponse = new GenericResponse<string> { IsSuccess = true, Result = selectedIdentificationType };

            _regionCodeHelperMock.Setup(helper => helper.VerifyRegionCodeHeader(It.IsAny<HttpRequest>()))
                .Returns(new GenericResponse<string> { IsSuccess = true, Result = selectedRegionCode });

            _validationHelperMock.Setup(helper => helper.SignupValidation(selectedRegionCode, request))
                .Returns(validationResponse);

            _userTelecomQueryServiceMock.Setup(telecom => telecom.IsUserEmailIdAlreadyExist(It.IsAny<string>()))
            .Returns(false);
            _userTelecomQueryServiceMock.Setup(telecom => telecom.IsUserPhoneNumberAlreadyExist(It.IsAny<string>()))
            .Returns(false);

            var patientRequest = new PatientRegistrationRequest() { Gender = "Male", Name = "Test", Nationality = "Indian", PhoneCountryCode = "+60", PhoneNumber = "12345", IdentificationType = "Passport", PassportIssueCountry = "India", UHID = "test" };
            _mapperMock.Setup(m => m.Map<PatientRegistrationRequest>(It.IsAny<NewPatientRegistrationRequest>()))
                .Returns(patientRequest);

            var serviceResponse = new PatientSignUpResponseDto { UserId = "test", UserUniqueId = "test" };
            _userCommandServiceMock.Setup(service => service.NewPatientSignup(It.IsAny<PatientRegistrationRequest>()))
                .ReturnsAsync(serviceResponse);


            // Act
            var result = await _controller.NewRegisterPatient(request);

            // Assert
            result.Should().BeOfType<OkObjectResult>();
        }
        [Fact]
        public async Task NewRegisterPatient_ShouldReturnNotOk_WhenPassportNotExistRegistrationFailed()
        {
            // Arrange
            var request = new NewPatientRegistrationRequest() { Gender = "Male", Name = "Test", Nationality = "Indian", PhoneCountryCode = "+60", PhoneNumber = "12345" };
            var selectedRegionCode = "MYS";
            var selectedIdentificationType = "MyKad_MyKid_MyPR";
            var validationResponse = new GenericResponse<string> { IsSuccess = true, Result = selectedIdentificationType };

            _regionCodeHelperMock.Setup(helper => helper.VerifyRegionCodeHeader(It.IsAny<HttpRequest>()))
                .Returns(new GenericResponse<string> { IsSuccess = true, Result = selectedRegionCode });

            _validationHelperMock.Setup(helper => helper.SignupValidation(selectedRegionCode, request))
                .Returns(validationResponse);

            _userTelecomQueryServiceMock.Setup(telecom => telecom.IsUserEmailIdAlreadyExist(It.IsAny<string>()))
            .Returns(false);
            _userTelecomQueryServiceMock.Setup(telecom => telecom.IsUserPhoneNumberAlreadyExist(It.IsAny<string>()))
            .Returns(false);

            var patientRequest = new PatientRegistrationRequest() { Gender = "Male", Name = "Test", Nationality = "Indian", PhoneCountryCode = "+60", PhoneNumber = "12345", IdentificationType = "Passport", PassportIssueCountry = "India", UHID = "test" };
            _mapperMock.Setup(m => m.Map<PatientRegistrationRequest>(It.IsAny<NewPatientRegistrationRequest>()))
                .Returns(patientRequest);

            var serviceResponse = new PatientSignUpResponseDto { UserId = string.Empty, UserUniqueId = string.Empty };
            _userCommandServiceMock.Setup(service => service.NewPatientSignup(It.IsAny<PatientRegistrationRequest>()))
                .ReturnsAsync(serviceResponse);


            // Act
            var result = await _controller.NewRegisterPatient(request);

            // Assert
            result.Should().BeOfType<BadRequestObjectResult>();
        }

        [Fact]
        public async Task NewRegisterPatient_ShouldReturnOk_WhenSignupValidationError()
        {
            // Arrange
            var request = new NewPatientRegistrationRequest() { Gender = "Male", Name = "Test", Nationality = "Indian", PhoneCountryCode = "+60", PhoneNumber = "12345" };
            var selectedRegionCode = "MYS";
            var validationResponse = new GenericResponse<string> { IsSuccess = false, HasError = true };

            _regionCodeHelperMock.Setup(helper => helper.VerifyRegionCodeHeader(It.IsAny<HttpRequest>()))
                .Returns(new GenericResponse<string> { IsSuccess = true, Result = selectedRegionCode });

            _validationHelperMock.Setup(helper => helper.SignupValidation(selectedRegionCode, request))
                .Returns(validationResponse);

            // Act
            var result = await _controller.NewRegisterPatient(request);

            // Assert
            result.Should().BeOfType<BadRequestObjectResult>();
        }

        [Fact]
        public void GetSalutations_ShouldReturnOk_WhenRegionCodeIsValid()
        {
            // Arrange
            _regionCodeHelperMock.Setup(helper => helper.VerifyRegionCodeHeader(It.IsAny<HttpRequest>()))
                .Returns(new GenericResponse<string> { IsSuccess = true, Result = RegionCode.MALAYSIA_REGION_CODE.ToString() });

            // Act
            var result = _controller.GetSalutations();

            // Assert
            result.Should().BeOfType<OkObjectResult>();
        }

        [Fact]
        public void GetSalutations_ShouldBadRequest_WhenRegionCodeIsInValid()
        {
            // Arrange
            _regionCodeHelperMock.Setup(helper => helper.VerifyRegionCodeHeader(It.IsAny<HttpRequest>()))
                .Returns(new GenericResponse<string>
                {
                    IsSuccess = false,
                    HasError = true,
                    StatusCode = ResponseStatus.STATUS_BadRequest,
                    Message = Resource.RegionCodeRequired
                });

            // Act
            var result = _controller.GetSalutations();

            // Assert
            result.Should().BeOfType<BadRequestObjectResult>();
            var badrequest = result as BadRequestObjectResult;
            var response = badrequest?.Value as GenericResponse<string>;
            response?.Message.Should().Be(Resource.RegionCodeRequired);
        }

        [Fact]
        public void VerifyExistingUser_ShouldReturnBadRequest_WhenRegionCodeIsInvalid()
        {
            // Arrange
            var request = new UserVerificationRequest();
            _regionCodeHelperMock.Setup(helper => helper.VerifyRegionCodeHeader(It.IsAny<HttpRequest>()))
                .Returns(new GenericResponse<string> { IsSuccess = false, HasError = true, Message = ResponseMessage.STATUS_INVALID_REGIONCODE });

            // Act
            var result = _controller.VerifyExistingUser(request);

            // Assert
            result.Should().BeOfType<BadRequestObjectResult>();
        }

        [Fact]
        public void VerifyExistingUser_ShouldReturnOk_WhenUserVerificationSucceeds()
        {
            // Arrange
            var request = new UserVerificationRequest();
            request.UserId = "123456";
            request.PassportNo = "";

            var regionCode = RegionCode.MALAYSIA_REGION_CODE.ToString();

            _regionCodeHelperMock.Setup(helper => helper.VerifyRegionCodeHeader(It.IsAny<HttpRequest>()))
                .Returns(new GenericResponse<string> { IsSuccess = true, Result = regionCode });

            _userIdentifierQueryServiceMock.Setup(service => service.IsUserIdentifierAlreadyExist(request.UserId, request.PassportNo, System.Enum.GetName(PatientUserIdentificationType.MyKad_MyKid_MyPR) ?? string.Empty))
                .Returns(true);

            // Act
            var result = _controller.VerifyExistingUser(request);

            // Assert
            result.Should().BeOfType<OkObjectResult>();
        }

        #region Get User Types Tests

        [Fact]
        public void GetUserTypes_ShouldBadRequest_WhenRegionCodeIsInValid()
        {
            // Arrange
            _regionCodeHelperMock.Setup(helper => helper.VerifyRegionCodeHeader(It.IsAny<HttpRequest>()))
                .Returns(new GenericResponse<string>
                {
                    IsSuccess = false,
                    HasError = true,
                    StatusCode = ResponseStatus.STATUS_BadRequest,
                    Message = Resource.RegionCodeRequired
                });

            // Act
            var result = _controller.GetUserTypes();

            // Assert
            result.Should().BeOfType<BadRequestObjectResult>();
            var badrequest = result as BadRequestObjectResult;
            var response = badrequest?.Value as GenericResponse<string>;
            response?.Message.Should().Be(Resource.RegionCodeRequired);
        }

        [Fact]
        public void GetUserTypes_ShouldReturnOk_WhenRegionCodeIsValid()
        {
            // Arrange
            _regionCodeHelperMock.Setup(helper => helper.VerifyRegionCodeHeader(It.IsAny<HttpRequest>()))
                .Returns(new GenericResponse<string> { IsSuccess = true, Result = RegionCode.MALAYSIA_REGION_CODE.ToString() });

            // Act
            var result = _controller.GetUserTypes();

            // Assert
            result.Should().BeOfType<OkObjectResult>();
        }

        #endregion

        #region Search User Tests

        [Fact]
        public async Task Search_ShouldBadRequest_WhenRegionCodeIsInValid()
        {
            // Arrange
            _regionCodeHelperMock.Setup(helper => helper.VerifyRegionCodeHeader(It.IsAny<HttpRequest>()))
                .Returns(new GenericResponse<string>
                {
                    IsSuccess = false,
                    HasError = true,
                    StatusCode = ResponseStatus.STATUS_BadRequest,
                    Message = Resource.RegionCodeRequired
                });
            var usersearchreq = new UserSearchRequestDto { UserName = "", Status = "true", UserType = "Admin" };
            // Act
            var result = await _controller.Search(usersearchreq);

            // Assert
            result.Should().BeOfType<BadRequestObjectResult>();
        }

        [Fact]
        public async Task Search_NoResultsFound_ReturnsNotFound()
        {
            // Arrange
            _regionCodeHelperMock.Setup(helper => helper.VerifyRegionCodeHeader(It.IsAny<HttpRequest>()))
                .Returns(new GenericResponse<string> { IsSuccess = true, Result = RegionCode.MALAYSIA_REGION_CODE.ToString() });

            _userServiceMock.Setup(s => s.SearchUsers(It.IsAny<int>(), It.IsAny<int>(), It.IsAny<string>(),
                It.IsAny<string>(), It.IsAny<string>())).ReturnsAsync(new List<UserSearchResponseDto>());

            var searchCriteria = new UserSearchRequestDto
            {
                PageNo = 1,
                PageSize = 10,
                UserName = "test",
                UserType = "Admin",
                Status = "Active"
            };

            // Act
            var result = await _controller.Search(searchCriteria);

            // Assert
            var notFoundResult = Assert.IsType<NotFoundObjectResult>(result);
            var response = notFoundResult.Value as GenericResponseList<UserSearchResponseDto>;
            Assert.True(response.HasError);
            Assert.Equal("Record Not Found", response.Message);
        }

        [Fact]
        public async Task Search_Success_ReturnsOk()
        {
            // Arrange
            _regionCodeHelperMock.Setup(helper => helper.VerifyRegionCodeHeader(It.IsAny<HttpRequest>()))
                .Returns(new GenericResponse<string> { IsSuccess = true, Result = RegionCode.MALAYSIA_REGION_CODE.ToString() });

            var mockResponse = new List<UserSearchResponseDto>
            {
                new UserSearchResponseDto { UserName = "testUser1", UserType = "Admin", Status = true },
                new UserSearchResponseDto { UserName = "testUser2", UserType = "User", Status = false }
            };

            _userServiceMock.Setup(s => s.SearchUsers(It.IsAny<int>(), It.IsAny<int>(), It.IsAny<string>(),
                It.IsAny<string>(), It.IsAny<string>())).ReturnsAsync(mockResponse);

            var searchCriteria = new UserSearchRequestDto
            {
                PageNo = 1,
                PageSize = 10,
                UserName = "test",
                UserType = "Admin",
                Status = "Active"
            };

            // Act
            var result = await _controller.Search(searchCriteria);

            // Assert
            var okResult = Assert.IsType<OkObjectResult>(result);
            var response = okResult.Value as GenericResponseList<UserSearchResponseDto>;
            Assert.True(response.IsSuccess);
        }

        #endregion

        #region VerifyExistingUser Tests
        [Fact]
        public void VerifyExistingUser_ShouldReturnBadRequest_WhenBothUserIdAndPassportNoAreMissing()
        {
            // Arrange
            _regionCodeHelperMock.Setup(r => r.VerifyRegionCodeHeader(It.IsAny<HttpRequest>()))
                .Returns(new GenericResponse<string> { IsSuccess = true, Result = RegionCode.MALAYSIA_REGION_CODE });

            var request = new UserVerificationRequest
            {
                UserId = string.Empty,
                PassportNo = string.Empty
            };

            // Act
            var result = _controller.VerifyExistingUser(request);

            // Assert
            var badRequestResult = result as BadRequestObjectResult;
            badRequestResult?.Should().NotBeNull();
            badRequestResult?.StatusCode.Should().Be(400);

            var response = badRequestResult?.Value as GenericResponse<string>;
            response?.Should().NotBeNull();
            response?.Message.Should().Be(Resource.VerifyExistingUserValidationFailed);
        }

        [Fact]
        public void VerifyExistingUser_ShouldReturnBadRequest_WhenRegionCodeIsNotValidForAnyCase()
        {
            // Arrange
            var invalidRegionCodeResponse = new GenericResponse<string>
            {
                IsSuccess = false,
                HasError = true,
                StatusCode = ResponseStatus.STATUS_BadRequest,
                Message = ResponseMessage.STATUS_INVALID_REGIONCODE
            };

            _regionCodeHelperMock.Setup(r => r.VerifyRegionCodeHeader(It.IsAny<HttpRequest>()))
                .Returns(invalidRegionCodeResponse);

            // Act
            var result = _controller.VerifyExistingUser(new UserVerificationRequest());

            // Assert
            var badRequestResult = result as BadRequestObjectResult;
            badRequestResult?.Should().NotBeNull();
            badRequestResult?.StatusCode.Should().Be(400);

            var response = badRequestResult?.Value as GenericResponse<string>;
            response?.Should().NotBeNull();
            response?.Message?.Should().Be(ResponseMessage.STATUS_INVALID_REGIONCODE);
        }

        [Fact]
        public void VerifyExistingUser_ShouldReturnOk_WhenValidRequestForMalaysia()
        {
            // Arrange
            var validRegionCodeResponse = new GenericResponse<string>
            {
                IsSuccess = true,
                Result = RegionCode.MALAYSIA_REGION_CODE
            };

            _regionCodeHelperMock.Setup(r => r.VerifyRegionCodeHeader(It.IsAny<HttpRequest>()))
                .Returns(validRegionCodeResponse);

            var mockResponse = new GenericResponse<string>
            {
                IsSuccess = true,
                StatusCode = ResponseStatus.STATUS_SUCCESS,
                Message = "User exists"
            };
            var request = new UserVerificationRequest
            {
                UserId = "123456",
                PassportNo = "A12345678"
            };
            _userIdentifierQueryServiceMock.Setup(service => service.IsUserIdentifierAlreadyExist(request.UserId, request.PassportNo, System.Enum.GetName(PatientUserIdentificationType.MyKad_MyKid_MyPR) ?? string.Empty))
                .Returns(true);



            // Act
            var result = _controller.VerifyExistingUser(request);

            // Assert
            var okResult = result as OkObjectResult;
            okResult?.Should().NotBeNull();
            okResult?.StatusCode.Should().Be(200);

            var response = okResult?.Value as GenericResponse<string>;
            response?.Should().NotBeNull();
            response?.IsSuccess.Should().BeTrue();
            response?.Message?.Should().Be("User exists");
        }

        [Fact]
        public void VerifyExistingUser_ShouldReturnOk_WhenValidRequestForVietnam()
        {
            // Arrange
            var validRegionCodeResponse = new GenericResponse<string>
            {
                IsSuccess = true,
                Result = RegionCode.VIETNAM_REGION_CODE
            };

            _regionCodeHelperMock.Setup(r => r.VerifyRegionCodeHeader(It.IsAny<HttpRequest>()))
                .Returns(validRegionCodeResponse);

            var mockResponse = new GenericResponse<string>
            {
                IsSuccess = true,
                StatusCode = ResponseStatus.STATUS_SUCCESS,
                Message = "User exists"
            };
            var request = new UserVerificationRequest
            {
                UserId = "987654",
                PassportNo = "B98765432"
            };
            _userIdentifierQueryServiceMock.Setup(service => service.IsUserIdentifierAlreadyExist(request.UserId, request.PassportNo, System.Enum.GetName(PatientUserIdentificationType.MyKad_MyKid_MyPR) ?? string.Empty))
                .Returns(true);



            // Act
            var result = _controller.VerifyExistingUser(request);

            // Assert
            var okResult = result as OkObjectResult;
            okResult?.Should().NotBeNull();
            okResult?.StatusCode.Should().Be(200);

            var response = okResult?.Value as GenericResponse<string>;
            response?.Should().NotBeNull();
            response?.IsSuccess.Should().BeTrue();
            response?.Message.Should().Be("User exists");
        }

        [Fact]
        public void VerifyExistingUser_ShouldReturnOk_WhenValidRequestForIndonesia()
        {
            // Arrange
            var validRegionCodeResponse = new GenericResponse<string>
            {
                IsSuccess = true,
                Result = RegionCode.INDONESIA_REGION_CODE
            };

            _regionCodeHelperMock.Setup(r => r.VerifyRegionCodeHeader(It.IsAny<HttpRequest>()))
                .Returns(validRegionCodeResponse);

            var mockResponse = new GenericResponse<string>
            {
                IsSuccess = true,
                StatusCode = ResponseStatus.STATUS_SUCCESS,
                Message = "User exists"
            };


            var request = new UserVerificationRequest
            {
                UserId = "112233",
                PassportNo = "C11223344"
            };
            _userIdentifierQueryServiceMock.Setup(service => service.IsUserIdentifierAlreadyExist(request.UserId, request.PassportNo, System.Enum.GetName(PatientUserIdentificationType.MyKad_MyKid_MyPR) ?? string.Empty))
               .Returns(true);

            // Act
            var result = _controller.VerifyExistingUser(request);

            // Assert
            var okResult = result as OkObjectResult;
            okResult?.Should().NotBeNull();
            okResult?.StatusCode.Should().Be(200);

            var response = okResult?.Value as GenericResponse<string>;
            response?.Should().NotBeNull();
            response?.IsSuccess.Should().BeTrue();
            response?.Message.Should().Be("User exists");
        }

        [Fact]
        public void VerifyExistingUser_ShouldBadRequest_WhenValidRequestForOther()
        {
            // Arrange
            var validRegionCodeResponse = new GenericResponse<string>
            {
                IsSuccess = true,
                Result = "Other"
            };

            _regionCodeHelperMock.Setup(r => r.VerifyRegionCodeHeader(It.IsAny<HttpRequest>()))
                .Returns(validRegionCodeResponse);

            var mockResponse = new GenericResponse<string>
            {
                IsSuccess = true,
                StatusCode = ResponseStatus.STATUS_SUCCESS,
                Message = "User exists"
            };


            var request = new UserVerificationRequest
            {
                UserId = "112233",
                PassportNo = "C11223344"
            };
            _userIdentifierQueryServiceMock.Setup(service => service.IsUserIdentifierAlreadyExist(request.UserId, request.PassportNo, System.Enum.GetName(PatientUserIdentificationType.MyKad_MyKid_MyPR) ?? string.Empty))
               .Returns(true);

            // Act
            var result = _controller.VerifyExistingUser(request);

            // Assert
            var okResult = result as BadRequestObjectResult;
            okResult?.Should().NotBeNull();
            okResult?.StatusCode.Should().Be(400);

        }

        #endregion

        #region GetRelationships Tests
        [Fact]
        public void GetRelationShips_ShouldReturnBadRequest_WhenRegionCodeIsInvalid()
        {
            // Arrange
            var invalidRegionCodeResponse = new GenericResponse<string>
            {
                IsSuccess = false,
                HasError = true,
                StatusCode = ResponseStatus.STATUS_BadRequest,
                Message = ResponseMessage.STATUS_INVALID_REGIONCODE
            };

            _regionCodeHelperMock.Setup(r => r.VerifyRegionCodeHeader(It.IsAny<HttpRequest>()))
                .Returns(invalidRegionCodeResponse);

            // Act
            var result = _controller.GetRelationShips();

            // Assert
            var badRequestResult = result as BadRequestObjectResult;
            badRequestResult?.Should().NotBeNull();
            badRequestResult?.StatusCode.Should().Be(400);
        }

        [Fact]
        public void GetRelationShips_ShouldReturnOK_WhenRegionCodeIsValid()
        {
            // Arrange
            var validRegionCodeResponse = new GenericResponse<string>
            {
                IsSuccess = true,
                Result = RegionCode.MALAYSIA_REGION_CODE
            };

            _regionCodeHelperMock.Setup(r => r.VerifyRegionCodeHeader(It.IsAny<HttpRequest>()))
                .Returns(validRegionCodeResponse);

            // Act
            var result = _controller.GetRelationShips();

            // Assert
            var okResult = result as OkObjectResult;
            okResult?.Should().NotBeNull();
            okResult?.StatusCode.Should().Be(200);

            var responseValue = okResult?.Value as GenericResponse<RelationShipsResponseDto>;
            responseValue?.Should().NotBeNull();
            responseValue?.IsSuccess.Should().BeTrue();
            responseValue?.Result.Should().NotBeNull();
        }

        [Fact]
        public void GetRelationShips_ShouldReturnOK_WhenRegionCodeIsOtherThanMalaysia()
        {
            // Arrange
            var validRegionCodeResponse = new GenericResponse<string>
            {
                IsSuccess = true,
                Result = RegionCode.INDONESIA_REGION_CODE  // A region other than Malaysia
            };

            _regionCodeHelperMock.Setup(r => r.VerifyRegionCodeHeader(It.IsAny<HttpRequest>()))
                .Returns(validRegionCodeResponse);

            // Act
            var result = _controller.GetRelationShips();

            // Assert
            var okResult = result as OkObjectResult;
            okResult?.Should().NotBeNull();
            okResult?.StatusCode.Should().Be(200);

            var responseValue = okResult?.Value as GenericResponse<RelationShipsResponseDto>;
            responseValue?.Should().NotBeNull();
            responseValue?.IsSuccess.Should().BeTrue();
            responseValue?.Result.Should().NotBeNull();
            responseValue?.Result?.RelationShips.Should().NotBeEmpty();

            // Verify that default relationship options are loaded
            responseValue?.Result?.RelationShips.Should().NotContain("Basha");  // "Basha" should not be present in non-Malaysia regions
        }

        #endregion

        #region GetSettings Tests
        [Fact]
        public async Task GetSettings_ShouldReturnBadRequest_WhenInvalidRegionCode()
        {
            // Arrange
            _regionCodeHelperMock.Setup(r => r.VerifyRegionCodeHeader(It.IsAny<HttpRequest>()))
                .Returns(new GenericResponse<string> { Result = "MYS", HasError = true });

            // Act
            var result = await _controller.GetSettings();

            // Assert
            var badRequestResult = result as BadRequestObjectResult;
            badRequestResult?.Should().NotBeNull();
            badRequestResult?.StatusCode.Should().Be(400);
        }

        [Fact]
        public async Task GetSettings_ShouldReturnBadRequest_WhenInvalidtoken()
        {
            // Arrange
            _regionCodeHelperMock.Setup(r => r.VerifyRegionCodeHeader(It.IsAny<HttpRequest>()))
                .Returns(new GenericResponse<string> { Result = "MYS" });
            _regionCodeHelperMock.Setup(r => r.GetUserIdByToken(It.IsAny<HttpRequest>()))
                 .Returns(string.Empty);
            // Act
            var result = await _controller.GetSettings();

            // Assert
            var badRequestResult = result as BadRequestObjectResult;
            badRequestResult?.Should().NotBeNull();
            badRequestResult?.StatusCode.Should().Be(400);
        }

        [Fact]
        public async Task GetSettings_ShouldReturnOkRequest_WhenValidtoken()
        {
            // Arrange
            var userId = 1L;
            var userSettingDetailDto = new UserSettingDetailDto() { IsBioAuthenticationEnabled = true, IsSOSButtonEnabled = true };
            _regionCodeHelperMock.Setup(r => r.VerifyRegionCodeHeader(It.IsAny<HttpRequest>()))
                .Returns(new GenericResponse<string> { Result = "MYS" });
            _regionCodeHelperMock.Setup(r => r.GetUserIdByToken(It.IsAny<HttpRequest>()))
                 .Returns("1");

            _userServiceMock.Setup(user => user.GetUserSettingDetails(userId)).Returns(userSettingDetailDto);
            // Act
            var result = await _controller.GetSettings();

            // Assert
            var OkResult = result as OkObjectResult;
            OkResult?.Should().NotBeNull();
            OkResult?.StatusCode.Should().Be(200);
        }
        #endregion

        #region UpdateUserSettings Tests
        [Fact]
        public async Task UpdateUserSettings_ShouldReturnBadRequest_WhenInvalidRegionCode()
        {
            // Arrange
            UserSettingDetailDto userSettingDetailDto = new UserSettingDetailDto() { IsBioAuthenticationEnabled = true };
            _regionCodeHelperMock.Setup(r => r.VerifyRegionCodeHeader(It.IsAny<HttpRequest>()))
                .Returns(new GenericResponse<string> { Result = "MYS", HasError = true });

            // Act
            var result = await _controller.UpdateUserSettings(userSettingDetailDto);

            // Assert
            var badRequestResult = result as BadRequestObjectResult;
            badRequestResult?.Should().NotBeNull();
            badRequestResult?.StatusCode.Should().Be(400);
        }

        [Fact]
        public async Task UpdateUserSettings_ShouldReturnBadRequest_WhenInvalidtoken()
        {
            // Arrange
            UserSettingDetailDto userSettingDetailDto = new UserSettingDetailDto() { IsBioAuthenticationEnabled = true };
            _regionCodeHelperMock.Setup(r => r.VerifyRegionCodeHeader(It.IsAny<HttpRequest>()))
                .Returns(new GenericResponse<string> { Result = "MYS" });
            _regionCodeHelperMock.Setup(r => r.GetUserIdByToken(It.IsAny<HttpRequest>()))
                 .Returns(string.Empty);
            // Act
            var result = await _controller.UpdateUserSettings(userSettingDetailDto);

            // Assert
            var badRequestResult = result as BadRequestObjectResult;
            badRequestResult?.Should().NotBeNull();
            badRequestResult?.StatusCode.Should().Be(400);
        }
        [Fact]
        public async Task UpdateUserSettings_ShouldReturnBadRequest_WhenEptyInput()
        {
            // Arrange
            UserSettingDetailDto userSettingDetailDto = new UserSettingDetailDto() { IsBioAuthenticationEnabled = true };
            var userId = 1L;
            _regionCodeHelperMock.Setup(r => r.VerifyRegionCodeHeader(It.IsAny<HttpRequest>()))
                .Returns(new GenericResponse<string> { Result = "MYS" });
            _regionCodeHelperMock.Setup(r => r.GetUserIdByToken(It.IsAny<HttpRequest>()))
                 .Returns("1");

            _userServiceMock.Setup(user => user.GetUserSettingDetails(userId)).Returns(userSettingDetailDto);
            // Act
            var result = await _controller.UpdateUserSettings(null);

            // Assert
            var OkResult = result as BadRequestObjectResult;
            OkResult?.Should().NotBeNull();
            OkResult?.StatusCode.Should().Be(400);
        }

        [Fact]
        public async Task UpdateUserSettings_ShouldReturnOkRequest_WhenValidtokenAndUserNotFound()
        {
            // Arrange
            UserSettingDetailDto userSettingDetailDto = new UserSettingDetailDto() { IsBioAuthenticationEnabled = true };
            var userId = 1L;
            _regionCodeHelperMock.Setup(r => r.VerifyRegionCodeHeader(It.IsAny<HttpRequest>()))
                .Returns(new GenericResponse<string> { Result = "MYS" });
            _regionCodeHelperMock.Setup(r => r.GetUserIdByToken(It.IsAny<HttpRequest>()))
                 .Returns("1");

            _userServiceMock.Setup(user => user.GetUserSettingDetails(userId)).Returns(userSettingDetailDto);
            // Act
            var result = await _controller.UpdateUserSettings(userSettingDetailDto);

            // Assert
            var notFoundResult = result as NotFoundObjectResult;
            notFoundResult?.Should().NotBeNull();
            notFoundResult?.StatusCode.Should().Be(404);
        }
        [Fact]
        public async Task UpdateUserSettings_ShouldReturnOkRequest_WhenValidtokenAndValidUser()
        {
            // Arrange
            UserSettingDetailDto userSettingDetailDto = new UserSettingDetailDto() { IsBioAuthenticationEnabled = true };
            var userId = 1L;
            Domain.V1.Entities.Users.User user = new Domain.V1.Entities.Users.User() { BioAuthenticationEnabled = true, CreatedBy = string.Empty, CreatedDate = DateTime.UtcNow, IsDeleted = false, IsTempAccount = false, NotificationsEnabled = false, SOSButtonEnabled = false, Status = true, UpdatedBy = string.Empty, UserName = string.Empty, UserType = "Patient" };
            _regionCodeHelperMock.Setup(r => r.VerifyRegionCodeHeader(It.IsAny<HttpRequest>()))
                .Returns(new GenericResponse<string> { Result = "MYS" });
            _regionCodeHelperMock.Setup(r => r.GetUserIdByToken(It.IsAny<HttpRequest>()))
                 .Returns("1");
            _userServiceMock.Setup(user => user.FindUserById(userId)).ReturnsAsync(user);
            _userServiceMock.Setup(user => user.GetUserSettingDetails(userId)).Returns(userSettingDetailDto);
            _userCommandServiceMock.Setup(users => users.UpdateUserSettingsAsync(userSettingDetailDto, user)).ReturnsAsync(true);
            // Act
            var result = await _controller.UpdateUserSettings(userSettingDetailDto);

            // Assert
            var okResult = result as OkObjectResult;
            okResult?.Should().NotBeNull();
            okResult?.StatusCode.Should().Be(200);
        }
        [Fact]
        public async Task UpdateUserSettings_ShouldReturnBadRequest_WhenConcurrencyExceptionOccur()
        {
            // Arrange
            UserSettingDetailDto userSettingDetailDto = new UserSettingDetailDto() { IsBioAuthenticationEnabled = true };
            var userId = 1L;
            Domain.V1.Entities.Users.User user = new Domain.V1.Entities.Users.User() { BioAuthenticationEnabled = true, CreatedBy = string.Empty, CreatedDate = DateTime.UtcNow, IsDeleted = false, IsTempAccount = false, NotificationsEnabled = false, SOSButtonEnabled = false, Status = true, UpdatedBy = string.Empty, UserName = string.Empty, UserType = "Patient" };
            _regionCodeHelperMock.Setup(r => r.VerifyRegionCodeHeader(It.IsAny<HttpRequest>()))
                .Returns(new GenericResponse<string> { Result = "MYS" });
            _regionCodeHelperMock.Setup(r => r.GetUserIdByToken(It.IsAny<HttpRequest>()))
                 .Returns("1");
            _userServiceMock.Setup(user => user.FindUserById(userId)).ReturnsAsync(user);
            _userServiceMock.Setup(user => user.GetUserSettingDetails(userId)).Returns(userSettingDetailDto);
            _userCommandServiceMock.Setup(users => users.UpdateUserSettingsAsync(It.IsAny<UserSettingDetailDto>(), It.IsAny<Domain.V1.Entities.Users.User>()))
                .Throws(new DbUpdateConcurrencyException(CommonConstants.ERROR_DB_CONCURRENCY));
            // Act
            var result = await _controller.UpdateUserSettings(userSettingDetailDto);

            // Assert
            var badrequestResult = result as BadRequestObjectResult;
            badrequestResult?.Should().NotBeNull();
            badrequestResult?.StatusCode.Should().Be(400);
        }
        #endregion

        #region UpdatePreferedNameAndSaluation Tests
        [Fact]
        public async Task UpdatePreferedNameAndSaluation_ShouldReturnBadRequest_WhenInvalidRegionCode()
        {
            // Arrange
            string uniqueId = "test";
            UpdatePreferredNameAndSaluationRequest updatePreferredNameAndSaluationRequest = new UpdatePreferredNameAndSaluationRequest() { PreferredName = "test", Salutation = "Mr" };
            _regionCodeHelperMock.Setup(r => r.VerifyRegionCodeHeader(It.IsAny<HttpRequest>()))
                .Returns(new GenericResponse<string> { Result = "MYS", HasError = true });

            // Act
            var result = await _controller.UpdatePreferedNameAndSaluation(uniqueId, updatePreferredNameAndSaluationRequest);

            // Assert
            var badRequestResult = result as BadRequestObjectResult;
            badRequestResult?.Should().NotBeNull();
            badRequestResult?.StatusCode.Should().Be(400);
        }

        [Fact]
        public async Task UpdatePreferedNameAndSaluation_ShouldReturnBadRequest_WhenInvalidtoken()
        {
            // Arrange
            string uniqueId = "test";
            UpdatePreferredNameAndSaluationRequest updatePreferredNameAndSaluationRequest = new UpdatePreferredNameAndSaluationRequest() { PreferredName = "test", Salutation = "Mr" };
            _regionCodeHelperMock.Setup(r => r.VerifyRegionCodeHeader(It.IsAny<HttpRequest>()))
                .Returns(new GenericResponse<string> { Result = "MYS" });
            _regionCodeHelperMock.Setup(r => r.GetUserIdByToken(It.IsAny<HttpRequest>()))
                 .Returns(string.Empty);
            // Act
            var result = await _controller.UpdatePreferedNameAndSaluation(uniqueId, updatePreferredNameAndSaluationRequest);

            // Assert
            var badRequestResult = result as BadRequestObjectResult;
            badRequestResult?.Should().NotBeNull();
            badRequestResult?.StatusCode.Should().Be(400);
        }

        [Fact]
        public async Task UpdatePreferedNameAndSaluation_ShouldReturnOkRequest_WhenValidtokenAndUserNotFound()
        {
            // Arrange
            string uniqueId = "admin";
            long userId = 1L;
            var user = new Domain.V1.Entities.Users.User
            {
                Id = userId,
                UserName = "admin",
                Status = true,
                Gender = "Male",
                BirthDate = DateTime.UtcNow,
                ManagingOrganization = "1",
                Source = "Aurora",
                IsTempAccount = true,
                UserType = "Patient",
                Passcode = "1234",
                Language = 1,
                NotificationsEnabled = true,
                BioAuthenticationEnabled = true,
                SOSButtonEnabled = true,
                AppVersion = "v1",
                Password = "1234",
                IsMarketingConsentEnable = true,
                Salt = "salt",
                LocationEnable = true,
                IsDeleted = false,
                CreatedBy = "Admin",
                CreatedDate = DateTime.UtcNow,
                UpdatedBy = "Admin",  // Adding the missing property
                UpdatedDate = DateTime.UtcNow,// Assuming UpdatedDate is required as well
            };

            Domain.V1.Entities.Users.UserNames userNames = new Domain.V1.Entities.Users.UserNames() { CreatedBy = string.Empty, IsDeleted = false, CreatedDate = DateTime.UtcNow, UpdatedBy = string.Empty, UserID = 1 };
            UpdatePreferredNameAndSaluationRequest updatePreferredNameAndSaluationRequest = new UpdatePreferredNameAndSaluationRequest() { PreferredName = "test", Salutation = "Mr" };
            _regionCodeHelperMock.Setup(r => r.VerifyRegionCodeHeader(It.IsAny<HttpRequest>()))
                .Returns(new GenericResponse<string> { Result = "MYS" });
            _regionCodeHelperMock.Setup(r => r.GetUserIdByToken(It.IsAny<HttpRequest>()))
                 .Returns("1");

            _userServiceMock.Setup(userName => userName.FindUserById(userId)).ReturnsAsync(user);
            _userNamesQueryServiceMock.Setup(userName => userName.GetUserNamesByUserUniqueId(uniqueId)).ReturnsAsync((true, userNames));
            _userNamesCommandServiceMock.Setup(userName => userName.UpdatePreferredNameAndSaluation(updatePreferredNameAndSaluationRequest, userNames,user, "MYS")).ReturnsAsync(true);
            // Act
            var result = await _controller.UpdatePreferedNameAndSaluation(uniqueId, updatePreferredNameAndSaluationRequest);

            // Assert
            var okResult = result as OkObjectResult;
            okResult?.Should().NotBeNull();
            okResult?.StatusCode.Should().Be(200);
        }

        [Fact]
        public async Task UpdatePreferedNameAndSaluation_ShouldReturnOkRequest_WhenConcurrencyExceptionOccur()
        {
            // Arrange
            string uniqueId = "admin";
            long userId = 1L;
            var user = new Domain.V1.Entities.Users.User
            {
                Id = userId,
                UserName = "admin",
                Status = true,
                Gender = "Male",
                BirthDate = DateTime.UtcNow,
                ManagingOrganization = "1",
                Source = "Aurora",
                IsTempAccount = true,
                UserType = "Patient",
                Passcode = "1234",
                Language = 1,
                NotificationsEnabled = true,
                BioAuthenticationEnabled = true,
                SOSButtonEnabled = true,
                AppVersion = "v1",
                Password = "1234",
                IsMarketingConsentEnable = true,
                Salt = "salt",
                LocationEnable = true,
                IsDeleted = false,
                CreatedBy = "Admin",
                CreatedDate = DateTime.UtcNow,
                UpdatedBy = "Admin",  // Adding the missing property
                UpdatedDate = DateTime.UtcNow,// Assuming UpdatedDate is required as well
            };


            Domain.V1.Entities.Users.UserNames userNames = new Domain.V1.Entities.Users.UserNames() { CreatedBy = string.Empty, IsDeleted = false, CreatedDate = DateTime.UtcNow, UpdatedBy = string.Empty, UserID = 1 };
            UpdatePreferredNameAndSaluationRequest updatePreferredNameAndSaluationRequest = new UpdatePreferredNameAndSaluationRequest() { PreferredName = "test", Salutation = "Mr" };
            _regionCodeHelperMock.Setup(r => r.VerifyRegionCodeHeader(It.IsAny<HttpRequest>()))
                .Returns(new GenericResponse<string> { Result = "MYS" });
            _regionCodeHelperMock.Setup(r => r.GetUserIdByToken(It.IsAny<HttpRequest>()))
                 .Returns("1");

            _userServiceMock.Setup(userName => userName.FindUserById(userId)).ReturnsAsync(user);
            _userNamesQueryServiceMock.Setup(userName => userName.GetUserNamesByUserUniqueId(uniqueId)).ReturnsAsync((true, userNames));
            _userNamesCommandServiceMock.Setup(userName => userName.UpdatePreferredNameAndSaluation(updatePreferredNameAndSaluationRequest, userNames, user, "MYS"))
                .Throws(new DbUpdateConcurrencyException(CommonConstants.ERROR_DB_CONCURRENCY));
            // Act
            var result = await _controller.UpdatePreferedNameAndSaluation(uniqueId, updatePreferredNameAndSaluationRequest);

            // Assert
            var badrequestResult = result as BadRequestObjectResult;
            badrequestResult?.Should().NotBeNull();
            badrequestResult?.StatusCode.Should().Be(400);
        }

        [Fact]
        public async Task UpdatePreferedNameAndSaluation_ShouldReturnOkRequest_WhenUserNotFound()
        {
            // Arrange
            string uniqueId = "admin";
            long userId = 1L;
            var user = new Domain.V1.Entities.Users.User
            {
                Id = userId,
                UserName = "admin",
                Status = true,
                Gender = "Male",
                BirthDate = DateTime.UtcNow,
                ManagingOrganization = "1",
                Source = "Aurora",
                IsTempAccount = true,
                UserType = "Patient",
                Passcode = "1234",
                Language = 1,
                NotificationsEnabled = true,
                BioAuthenticationEnabled = true,
                SOSButtonEnabled = true,
                AppVersion = "v1",
                Password = "1234",
                IsMarketingConsentEnable = true,
                Salt = "salt",
                LocationEnable = true,
                IsDeleted = false,
                CreatedBy = "Admin",
                CreatedDate = DateTime.UtcNow,
                UpdatedBy = "Admin",  // Adding the missing property
                UpdatedDate = DateTime.UtcNow,// Assuming UpdatedDate is required as well
            };

            Domain.V1.Entities.Users.UserNames userNames = new Domain.V1.Entities.Users.UserNames() { CreatedBy = string.Empty, IsDeleted = false, CreatedDate = DateTime.UtcNow, UpdatedBy = string.Empty, UserID = 1 };
            UpdatePreferredNameAndSaluationRequest updatePreferredNameAndSaluationRequest = new UpdatePreferredNameAndSaluationRequest() { PreferredName = "test", Salutation = "Mr" };
            _regionCodeHelperMock.Setup(r => r.VerifyRegionCodeHeader(It.IsAny<HttpRequest>()))
                .Returns(new GenericResponse<string> { Result = "MYS" });
            _regionCodeHelperMock.Setup(r => r.GetUserIdByToken(It.IsAny<HttpRequest>()))
                 .Returns("1");

            _userNamesQueryServiceMock.Setup(userName => userName.GetUserNamesByUserUniqueId(uniqueId)).ReturnsAsync((false, userNames));
            _userServiceMock.Setup(userName => userName.FindUserById(userId)).ReturnsAsync(user);
            // Act
            var result = await _controller.UpdatePreferedNameAndSaluation(uniqueId, updatePreferredNameAndSaluationRequest);

            // Assert
            var notFoundResult = result as NotFoundObjectResult;
            notFoundResult?.Should().NotBeNull();
            notFoundResult?.StatusCode.Should().Be(404);
        }

        [Fact]
        public async Task UpdatePreferedNameAndSaluation_WhenUserNotFound()
        {
            // Arrange
            string uniqueId = "admin";
            long userId = 1L;
            var user = new Domain.V1.Entities.Users.User
            {
                Id = userId,
                UserName = "admin",
                Status = true,
                Gender = "Male",
                BirthDate = DateTime.UtcNow,
                ManagingOrganization = "1",
                Source = "Aurora",
                IsTempAccount = true,
                UserType = "Patient",
                Passcode = "1234",
                Language = 1,
                NotificationsEnabled = true,
                BioAuthenticationEnabled = true,
                SOSButtonEnabled = true,
                AppVersion = "v1",
                Password = "1234",
                IsMarketingConsentEnable = true,
                Salt = "salt",
                LocationEnable = true,
                IsDeleted = false,
                CreatedBy = "Admin",
                CreatedDate = DateTime.UtcNow,
                UpdatedBy = "Admin",  // Adding the missing property
                UpdatedDate = DateTime.UtcNow,// Assuming UpdatedDate is required as well
            };

            Domain.V1.Entities.Users.UserNames userNames = new Domain.V1.Entities.Users.UserNames() { CreatedBy = string.Empty, IsDeleted = false, CreatedDate = DateTime.UtcNow, UpdatedBy = string.Empty, UserID = 1 };
            UpdatePreferredNameAndSaluationRequest updatePreferredNameAndSaluationRequest = new UpdatePreferredNameAndSaluationRequest() { PreferredName = "test", Salutation = "Mr" };
            _regionCodeHelperMock.Setup(r => r.VerifyRegionCodeHeader(It.IsAny<HttpRequest>()))
                .Returns(new GenericResponse<string> { Result = "MYS" });
            _regionCodeHelperMock.Setup(r => r.GetUserIdByToken(It.IsAny<HttpRequest>()))
                 .Returns("1");

            _userNamesQueryServiceMock.Setup(userName => userName.GetUserNamesByUserUniqueId(uniqueId)).ReturnsAsync((false, userNames));
            _userServiceMock.Setup(userName => userName.FindUserById(2L)).ReturnsAsync(user);
            // Act
            var result = await _controller.UpdatePreferedNameAndSaluation(uniqueId, updatePreferredNameAndSaluationRequest);

            // Assert
            var notFoundResult = result as NotFoundObjectResult;
            notFoundResult?.Should().NotBeNull();
            notFoundResult?.StatusCode.Should().Be(404);
        }

        #endregion

        #region GetUserPersonalInformation Tests
        [Fact]
        public async Task GetUserPersonalInformation_ShouldReturnBadRequest_WhenInvalidRegionCode()
        {
            // Arrange
            _regionCodeHelperMock.Setup(r => r.VerifyRegionCodeHeader(It.IsAny<HttpRequest>()))
                .Returns(new GenericResponse<string> { Result = "MYS", HasError = true });

            // Act
            var result = await _controller.GetUserPersonalInformation();

            // Assert
            var badRequestResult = result as BadRequestObjectResult;
            badRequestResult?.Should().NotBeNull();
            badRequestResult?.StatusCode.Should().Be(400);
        }

        [Fact]
        public async Task GetUserPersonalInformation_ShouldReturnBadRequest_WhenInvalidtoken()
        {
            // Arrange
            _regionCodeHelperMock.Setup(r => r.VerifyRegionCodeHeader(It.IsAny<HttpRequest>()))
                .Returns(new GenericResponse<string> { Result = "MYS" });
            _regionCodeHelperMock.Setup(r => r.GetUserIdByToken(It.IsAny<HttpRequest>()))
                 .Returns(string.Empty);
            // Act
            var result = await _controller.GetUserPersonalInformation();

            // Assert
            var badRequestResult = result as BadRequestObjectResult;
            badRequestResult?.Should().NotBeNull();
            badRequestResult?.StatusCode.Should().Be(400);
        }

        [Fact]
        public async Task GetUserPersonalInformation_ShouldReturnOkRequest_WhenValidtokenAndUserNotFound()
        {
            // Arrange
            string uniqueId = "test";
            UserPersonalInformation userPersonalInformation = new UserPersonalInformation()
            {
                Id = 1,
                CountryCode = "+91",
                DOB = "1981-04-04",
                EmailId = "123",
                FullName = "test",
                Gender = "Male",
                Language = "en",
                MobileNumber = "123",
                MRNDetails = new List<MRNInformation>(),
                NotificationEnabled = true,
                Passcode = "test",
                PreferredName = "test",
                ProfileImage = "test",
                Salutation = "test",
                SosbuttonEnabled = true,
                TotalMRNCount = 0,
                UniqueId = uniqueId,
                Relationship="Son",
                RelationshipCategory="Child"
            };
            Domain.V1.Entities.Users.UserNames userNames = new Domain.V1.Entities.Users.UserNames() { CreatedBy = string.Empty, IsDeleted = false, CreatedDate = DateTime.UtcNow, UpdatedBy = string.Empty, UserID = 1 };
            _regionCodeHelperMock.Setup(r => r.VerifyRegionCodeHeader(It.IsAny<HttpRequest>()))
                .Returns(new GenericResponse<string> { Result = "MYS" });
            _regionCodeHelperMock.Setup(r => r.GetUserIdByToken(It.IsAny<HttpRequest>()))
                 .Returns("1");

            _userServiceMock.Setup(user => user.GetUserPersonalInformation(1)).ReturnsAsync((true, userPersonalInformation));
            // Act
            var result = await _controller.GetUserPersonalInformation();

            // Assert
            var okResult = result as OkObjectResult;
            okResult?.Should().NotBeNull();
            okResult?.StatusCode.Should().Be(200);
        }

        [Fact]
        public async Task GetUserPersonalInformation_ShouldReturnOkRequest_WhenUserNotFound()
        {
            // Arrange
            string uniqueId = "test";
            Domain.V1.Entities.Users.UserNames userNames = new Domain.V1.Entities.Users.UserNames() { CreatedBy = string.Empty, IsDeleted = false, CreatedDate = DateTime.UtcNow, UpdatedBy = string.Empty, UserID = 1 };
            _regionCodeHelperMock.Setup(r => r.VerifyRegionCodeHeader(It.IsAny<HttpRequest>()))
                .Returns(new GenericResponse<string> { Result = "MYS" });
            _regionCodeHelperMock.Setup(r => r.GetUserIdByToken(It.IsAny<HttpRequest>()))
                 .Returns("1");

            _userNamesQueryServiceMock.Setup(userName => userName.GetUserNamesByUserUniqueId(uniqueId)).ReturnsAsync((false, userNames));
            // Act
            var result = await _controller.GetUserPersonalInformation();

            // Assert
            var notFoundResult = result as NotFoundObjectResult;
            notFoundResult?.Should().NotBeNull();
            notFoundResult?.StatusCode.Should().Be(404);
        }

        #endregion

        #region GetUserInformationById Tests
        [Fact]
        public async Task GetUserInformationById_ShouldReturnBadRequest_WhenInvalidRegionCode()
        {
            // Arrange
            _regionCodeHelperMock.Setup(r => r.VerifyRegionCodeHeader(It.IsAny<HttpRequest>()))
                .Returns(new GenericResponse<string> { Result = "MYS", HasError = true });

            // Act
            var result = await _controller.GetUserInformationById(1);

            // Assert
            var badRequestResult = result as BadRequestObjectResult;
            badRequestResult?.Should().NotBeNull();
            badRequestResult?.StatusCode.Should().Be(400);
        }
                
        [Fact]
        public async Task GetUserInformationById_ShouldReturnOkRequest_WhenUserFound()
        {
            // Arrange
            string uniqueId = "test";
            UserPersonalInformation userPersonalInformation = new UserPersonalInformation()
            {
                Id = 1,
                CountryCode = "+91",
                DOB = "1981-04-04",
                EmailId = "123",
                FullName = "test",
                Gender = "Male",
                Language = "en",
                MobileNumber = "123",
                MRNDetails = new List<MRNInformation>(),
                NotificationEnabled = true,
                Passcode = "test",
                PreferredName = "test",
                ProfileImage = "test",
                Salutation = "test",
                SosbuttonEnabled = true,
                TotalMRNCount = 0,
                UniqueId = uniqueId,
                Relationship="Son",
                RelationshipCategory="Child"
            };
            _regionCodeHelperMock.Setup(r => r.VerifyRegionCodeHeader(It.IsAny<HttpRequest>()))
                .Returns(new GenericResponse<string> { Result = "MYS" });
            

            _userServiceMock.Setup(user => user.GetUserPersonalInformation(1)).ReturnsAsync((true, userPersonalInformation));
            // Act
            var result = await _controller.GetUserInformationById(1);

            // Assert
            var okResult = result as OkObjectResult;
            okResult?.Should().NotBeNull();
            okResult?.StatusCode.Should().Be(200);
        }

        [Fact]
        public async Task GetUserInformationById_ShouldReturnOkRequest_WhenUserNotFound()
        {
            // Arrange
             _regionCodeHelperMock.Setup(r => r.VerifyRegionCodeHeader(It.IsAny<HttpRequest>()))
                .Returns(new GenericResponse<string> { Result = "MYS" });
            _userServiceMock.Setup(user => user.GetUserPersonalInformation(1)).ReturnsAsync((false, new UserPersonalInformation() { }));

            // Act
            var result = await _controller.GetUserInformationById(1);

            // Assert
            var notFoundResult = result as NotFoundObjectResult;
            notFoundResult?.Should().NotBeNull();
            notFoundResult?.StatusCode.Should().Be(404);
        }

        [Fact]
        public async Task GetUserInformationById_IdLessThan1_ReturnsBadRequest()
        {
            // Arrange
            _regionCodeHelperMock
                .Setup(x => x.VerifyRegionCodeHeader(It.IsAny<HttpRequest>()))
                .Returns((GenericResponse<string>)null!); // No error from region check

            // Act
            var result = await _controller.GetUserInformationById(0);

            // Assert
            result.Should().BeOfType<BadRequestObjectResult>()
                  .Which.Value.Should().BeOfType<GenericResponse<string>>()
                  .Which.Should().Match<GenericResponse<string>>(r =>
                      r.StatusCode == ResponseStatus.STATUS_BadRequest &&
                      r.Message == ResponseMessage.STATUS_INVALID_REQUEST);
        }

        #endregion

        #region ResetPassword Tests

        [Fact]
        public async Task ResetPassword_InvalidRegionHeader_ReturnsBadRequest()
        {
            // Arrange
            _regionCodeHelperMock.Setup(helper => helper.VerifyRegionCodeHeader(It.IsAny<HttpRequest>()))
                .Returns(new GenericResponse<string>
                {
                    IsSuccess = false,
                    HasError = true,
                    StatusCode = ResponseStatus.STATUS_BadRequest,
                    Message = Resource.RegionCodeRequired
                });

            var resetpasswordrequest = new UserResetPasswordRequest() { Id=1};


            var result = await _controller.ResetPassword(resetpasswordrequest);

            Assert.IsType<BadRequestObjectResult>(result);
        }

        [Fact]
        public async Task ResetPassword_InvalidUserId_ReturnsBadRequest()
        {
            _regionCodeHelperMock.Setup(x => x.VerifyRegionCodeHeader(It.IsAny<HttpRequest>()))
                .Returns((GenericResponse<string>)null);

            _regionCodeHelperMock.Setup(x => x.GetUserIdByToken(It.IsAny<HttpRequest>()))
                .Returns(string.Empty);

            var resetpasswordrequest = new UserResetPasswordRequest() { Id = 1 };

            var result = await _controller.ResetPassword(resetpasswordrequest);

            Assert.IsType<BadRequestObjectResult>(result);
        }

        [Fact]
        public async Task ResetPassword_NullRequest_ReturnsBadRequest()
        {
            _regionCodeHelperMock.Setup(x => x.VerifyRegionCodeHeader(It.IsAny<HttpRequest>()))
                .Returns((GenericResponse<string>)null);

            _regionCodeHelperMock.Setup(x => x.GetUserIdByToken(It.IsAny<HttpRequest>()))
                .Returns("123");

            var result = await _controller.ResetPassword(null);

            Assert.IsType<BadRequestObjectResult>(result);
        }

        [Fact]
        public async Task ResetPassword_UserNotFound_ReturnsNotFound()
        {
            _regionCodeHelperMock.Setup(x => x.VerifyRegionCodeHeader(It.IsAny<HttpRequest>()))
                .Returns((GenericResponse<string>)null);

            _regionCodeHelperMock.Setup(x => x.GetUserIdByToken(It.IsAny<HttpRequest>()))
                .Returns("123");

            _userServiceMock.Setup(x => x.FindUserById(It.IsAny<long>()))
                .ReturnsAsync((Domain.V1.Entities.Users.User)null);

            var result = await _controller.ResetPassword(new UserResetPasswordRequest { Id = 1 });

            Assert.IsType<NotFoundObjectResult>(result);
        }

        [Fact]
        public async Task ResetPassword_Success_ReturnsOk()
        {
            var request = new UserResetPasswordRequest { Id = 1 };

            _regionCodeHelperMock.Setup(x => x.VerifyRegionCodeHeader(It.IsAny<HttpRequest>()))
                .Returns((GenericResponse<string>)null);

            _regionCodeHelperMock.Setup(x => x.GetUserIdByToken(It.IsAny<HttpRequest>()))
                .Returns("123");

            var userData = new Domain.V1.Entities.Users.User {
                Id = 1,
                UserName = "admin",
                Status = true,
                Gender = "Male",
                BirthDate = DateTime.UtcNow,
                ManagingOrganization = "1",
                Source = "Aurora",
                IsTempAccount = true,
                UserType = "Patient",
                Passcode = "1234",
                Language = 1,
                NotificationsEnabled = true,
                BioAuthenticationEnabled = true,
                SOSButtonEnabled = true,
                AppVersion = "v1",
                Password = "1234",
                IsMarketingConsentEnable = true,
                Salt = "salt",
                LocationEnable = true,
                IsDeleted = false,
                CreatedBy = "Admin",
                CreatedDate = DateTime.UtcNow,
                UpdatedBy = "Admin",  // Adding the missing property
                UpdatedDate = DateTime.UtcNow,// Assuming UpdatedDate is required as well
            };

            _userServiceMock.Setup(x => x.FindUserById(request.Id))
                .ReturnsAsync(userData);

            _userCommandServiceMock.Setup(x => x.ResetPassword(request, It.IsAny<Domain.V1.Entities.Users.User>()))
                .ReturnsAsync(true);

            var result = await _controller.ResetPassword(request);

            var okResult = Assert.IsType<OkObjectResult>(result);
            var response = Assert.IsType<GenericResponse<string>>(okResult.Value);
            Assert.True(response.IsSuccess);
        }

        [Fact]
        public async Task ResetPassword_DbConcurrencyError_ReturnsBadRequest()
        {
            var request = new UserResetPasswordRequest { Id = 1 };

            _regionCodeHelperMock.Setup(x => x.VerifyRegionCodeHeader(It.IsAny<HttpRequest>()))
                .Returns((GenericResponse<string>)null);

            _regionCodeHelperMock.Setup(x => x.GetUserIdByToken(It.IsAny<HttpRequest>()))
                .Returns("123");

            var userData = new Domain.V1.Entities.Users.User
            {
                Id = 1,
                UserName = "admin",
                Status = true,
                Gender = "Male",
                BirthDate = DateTime.UtcNow,
                ManagingOrganization = "1",
                Source = "Aurora",
                IsTempAccount = true,
                UserType = "Patient",
                Passcode = "1234",
                Language = 1,
                NotificationsEnabled = true,
                BioAuthenticationEnabled = true,
                SOSButtonEnabled = true,
                AppVersion = "v1",
                Password = "1234",
                IsMarketingConsentEnable = true,
                Salt = "salt",
                LocationEnable = true,
                IsDeleted = false,
                CreatedBy = "Admin",
                CreatedDate = DateTime.UtcNow,
                UpdatedBy = "Admin",  // Adding the missing property
                UpdatedDate = DateTime.UtcNow,// Assuming UpdatedDate is required as well
            };

            _userServiceMock.Setup(x => x.FindUserById(request.Id))
                .ReturnsAsync(userData);

            _userCommandServiceMock.Setup(x => x.ResetPassword(request, It.IsAny<Domain.V1.Entities.Users.User>()))
                .ThrowsAsync(new DbUpdateConcurrencyException());

            var result = await _controller.ResetPassword(request);

            var badResult = Assert.IsType<BadRequestObjectResult>(result);
            var response = Assert.IsType<GenericResponse<string>>(badResult.Value);
            Assert.True(response.HasError);
        }

        #endregion

        #region Create User Tests

        private static CreateUserRequestDto GetValidUser()
        {
            return new CreateUserRequestDto
            {
                UserName = "testuser",
                Password = "password123",
                UserType = "Admin",
                UserGroup = "Group1",
                FirstName = "John",
                LastName = "Doe",
                Mobile = "1234567890",
                Email = "test@example.com",
                BirthDate = new DateTime(1990, 1, 1),
                Gender = "Male"
            };
        }

        [Fact]
        public async Task Create_ShouldReturnBadRequest_WhenRegionCodeInvalid()
        {
            // Arrange
            _regionCodeHelperMock.Setup(helper => helper.VerifyRegionCodeHeader(It.IsAny<HttpRequest>()))
                .Returns(new GenericResponse<string>
                {
                    IsSuccess = false,
                    HasError = true,
                    StatusCode = ResponseStatus.STATUS_BadRequest,
                    Message = Resource.RegionCodeRequired
                });

            var result = await _controller.Create(GetValidUser());

            Assert.IsType<BadRequestObjectResult>(result);
        }

        [Fact]
        public async Task Create_ShouldReturnBadRequest_WhenModelStateInvalid()
        {
            _controller.ModelState.AddModelError("UserName", "Required");

            var result = await _controller.Create(GetValidUser());

            Assert.IsType<BadRequestObjectResult>(result);
        }

        [Fact]
        public async Task Create_ShouldReturnBadRequest_WhenUserNameExists()
        {
            _userServiceMock.Setup(x => x.IsUserNameAlreadyExist(It.IsAny<string>()))
                                 .Returns(true);

            var result = await _controller.Create(GetValidUser());

            Assert.IsType<BadRequestObjectResult>(result);
        }

        [Fact]
        public async Task Create_ShouldReturnBadRequest_WhenEmailExists()
        {
            _userServiceMock.Setup(x => x.IsUserNameAlreadyExist(It.IsAny<string>()))
                                 .Returns(false);
            _userTelecomQueryServiceMock.Setup(x => x.IsUserEmailIdAlreadyExist(It.IsAny<string>()))
                                        .Returns(true);

            var result = await _controller.Create(GetValidUser());

            Assert.IsType<BadRequestObjectResult>(result);
        }

        [Fact]
        public async Task Create_ShouldReturnBadRequest_WhenPhoneExists()
        {
            _userServiceMock.Setup(x => x.IsUserNameAlreadyExist(It.IsAny<string>()))
                                 .Returns(false);
            _userTelecomQueryServiceMock.Setup(x => x.IsUserEmailIdAlreadyExist(It.IsAny<string>()))
                                        .Returns(false);
            _userTelecomQueryServiceMock.Setup(x => x.IsUserPhoneNumberAlreadyExist(It.IsAny<string>()))
                                        .Returns(true);

            var result = await _controller.Create(GetValidUser());

            Assert.IsType<BadRequestObjectResult>(result);
        }

        [Fact]
        public async Task Create_ShouldReturnBadRequest_WhenCreateFails()
        {
            _userServiceMock.Setup(x => x.IsUserNameAlreadyExist(It.IsAny<string>())).Returns(false);
            _userTelecomQueryServiceMock.Setup(x => x.IsUserEmailIdAlreadyExist(It.IsAny<string>())).Returns(false);
            _userTelecomQueryServiceMock.Setup(x => x.IsUserPhoneNumberAlreadyExist(It.IsAny<string>())).Returns(false);
            _userCommandServiceMock.Setup(x => x.CreateAsync(It.IsAny<CreateUserRequestDto>())).ReturnsAsync(false);

            var result = await _controller.Create(GetValidUser());

            Assert.IsType<BadRequestObjectResult>(result);
        }

        [Fact]
        public async Task Create_ShouldReturnOk_WhenCreateSucceeds()
        {
            _userServiceMock.Setup(x => x.IsUserNameAlreadyExist(It.IsAny<string>())).Returns(false);
            _userTelecomQueryServiceMock.Setup(x => x.IsUserEmailIdAlreadyExist(It.IsAny<string>())).Returns(false);
            _userTelecomQueryServiceMock.Setup(x => x.IsUserPhoneNumberAlreadyExist(It.IsAny<string>())).Returns(false);
            _userCommandServiceMock.Setup(x => x.CreateAsync(It.IsAny<CreateUserRequestDto>())).ReturnsAsync(true);

            var result = await _controller.Create(GetValidUser());

            Assert.IsType<OkObjectResult>(result);
        }

        [Fact]
        public async Task Create_ShouldReturnBadRequest_WhenDbConcurrencyExceptionThrown()
        {
            _userServiceMock.Setup(x => x.IsUserNameAlreadyExist(It.IsAny<string>())).Returns(false);
            _userTelecomQueryServiceMock.Setup(x => x.IsUserEmailIdAlreadyExist(It.IsAny<string>())).Returns(false);
            _userTelecomQueryServiceMock.Setup(x => x.IsUserPhoneNumberAlreadyExist(It.IsAny<string>())).Returns(false);
            _userCommandServiceMock.Setup(x => x.CreateAsync(It.IsAny<CreateUserRequestDto>())).ThrowsAsync(new DbUpdateConcurrencyException());

            var result = await _controller.Create(GetValidUser());

            Assert.IsType<BadRequestObjectResult>(result);
        }

        #endregion

        #region update user status

        [Fact]
        public async Task UpdateStatus_Should_ReturnBadRequest_When_RegionCodeInvalid()
        {
            // Arrange
            var verifyStatus = new GenericResponse<string> { HasError = true, Message = "Invalid region code." };
            _regionCodeHelperMock.Setup(r => r.VerifyRegionCodeHeader(It.IsAny<HttpRequest>())).Returns(verifyStatus);

            var request = new UpdateUserStatusRequest { Status = true };

            // Act
            var result = await _controller.UpdateStatus(1, request);

            // Assert
            var badRequestResult = result as BadRequestObjectResult;
            Assert.NotNull(badRequestResult);
            badRequestResult.Should().NotBeNull();
            var response = badRequestResult.Value as GenericResponse<string>;
            response!.HasError.Should().BeTrue();
        }

        [Fact]
        public async Task UpdateStatus_Should_ReturnBadRequest_When_RequestIsNull()
        {
            // Arrange
            _regionCodeHelperMock.Setup(r => r.VerifyRegionCodeHeader(It.IsAny<HttpRequest>())).Returns((GenericResponse<string>)null!);

            // Act
            var result = await _controller.UpdateStatus(1, null);

            // Assert
            var badRequestResult = result as BadRequestObjectResult;
            Assert.NotNull(badRequestResult);
            badRequestResult.Should().NotBeNull();
            var response = badRequestResult.Value as GenericResponse<string>;
            response!.HasError.Should().BeTrue();
        }

        [Fact]
        public async Task UpdateStatus_Should_ReturnNotFound_When_UserNotFound()
        {
            // Arrange
            _regionCodeHelperMock.Setup(r => r.VerifyRegionCodeHeader(It.IsAny<HttpRequest>())).Returns((GenericResponse<string>)null!);
            _userServiceMock.Setup(x => x.FindUserById(It.IsAny<long>())).ReturnsAsync((Domain.V1.Entities.Users.User)null!);

            var request = new UpdateUserStatusRequest { Status = false };

            // Act
            var result = await _controller.UpdateStatus(1, request);

            // Assert
            var notFoundResult = result as NotFoundObjectResult;
            notFoundResult.Should().NotBeNull();
            var response = notFoundResult!.Value as GenericResponse<string>;
            response!.HasError.Should().BeTrue();
        }

        [Fact]
        public async Task UpdateStatus_Should_ReturnNotFound_When_UserIsDeleted()
        {
            // Arrange
            _regionCodeHelperMock.Setup(r => r.VerifyRegionCodeHeader(It.IsAny<HttpRequest>())).Returns((GenericResponse<string>)null!);
            _userServiceMock.Setup(x => x.FindUserById(It.IsAny<long>())).ReturnsAsync(new Domain.V1.Entities.Users.User { Id = 1, IsDeleted = true, BioAuthenticationEnabled = true, CreatedBy = "Admin", CreatedDate = DateTime.UtcNow, IsTempAccount = true, NotificationsEnabled = true, SOSButtonEnabled = true, Status = true, UpdatedBy = "Admin", UserName = "Test1", UserType = "test2" });

            var request = new UpdateUserStatusRequest { Status = true };

            // Act
            var result = await _controller.UpdateStatus(1, request);

            // Assert
            var notFoundResult = result as NotFoundObjectResult;
            notFoundResult.Should().NotBeNull();
            var response = notFoundResult!.Value as GenericResponse<string>;
            response!.HasError.Should().BeTrue();
        }

        [Fact]
        public async Task UpdateStatus_Should_ReturnOk_When_UpdateSuccessful()
        {
            // Arrange
            _regionCodeHelperMock.Setup(r => r.VerifyRegionCodeHeader(It.IsAny<HttpRequest>())).Returns((GenericResponse<string>)null!);

            var user = new Domain.V1.Entities.Users.User
            {
                Id = 1,
                IsDeleted = false,
                UserType = "Admin",
                BioAuthenticationEnabled = true,
                IsTempAccount = false,
                NotificationsEnabled = true,
                SOSButtonEnabled = true,
                UserName = "TestUser",
                CreatedBy = "Admin",
                CreatedDate = DateTime.UtcNow,
                Status = true,
                UpdatedBy = "Admin",

            };

            _userServiceMock.Setup(x => x.FindUserById(It.IsAny<long>())).ReturnsAsync(user);

            _userCommandServiceMock.Setup(x => x.UpdateUserStatusAsync(It.IsAny<UpdateUserRequest>(), It.IsAny<Domain.V1.Entities.Users.User>()))
                .ReturnsAsync(new GenericResponse<string> { IsSuccess = true, Message = "Success" });

            var request = new UpdateUserStatusRequest { Status = true };

            // Act
            var result = await _controller.UpdateStatus(1, request);

            // Assert
            var okResult = result as OkObjectResult;
            okResult.Should().NotBeNull();
            var response = (okResult!.Value as GenericResponse<string>)!;
            response.IsSuccess.Should().BeTrue();
        }

        [Fact]
        public async Task UpdateStatus_Should_ReturnBadRequest_When_UpdateFails()
        {
            // Arrange
            _regionCodeHelperMock.Setup(r => r.VerifyRegionCodeHeader(It.IsAny<HttpRequest>())).Returns((GenericResponse<string>)null!);

            var user = new Domain.V1.Entities.Users.User
            {
                Id = 1,
                IsDeleted = false,
                BioAuthenticationEnabled = false,
                CreatedBy = "Admin",
                CreatedDate = DateTime.UtcNow,
                IsTempAccount = false,
                NotificationsEnabled = false,
                SOSButtonEnabled = false,
                Status = false,
                UpdatedBy = "Admin",
                UserName = "Test1",
                UserType = "Test2"
            };

            _userServiceMock.Setup(x => x.FindUserById(It.IsAny<long>())).ReturnsAsync(user);

            _userCommandServiceMock.Setup(x => x.UpdateUserStatusAsync(It.IsAny<UpdateUserRequest>(), It.IsAny<Domain.V1.Entities.Users.User>()))
                .ReturnsAsync(new GenericResponse<string> { IsSuccess = false, Message = "Failed" });

            var request = new UpdateUserStatusRequest { Status = true };

            // Act
            var result = await _controller.UpdateStatus(1, request);

            // Assert
            var badRequestResult = result as BadRequestObjectResult;
            Assert.NotNull(badRequestResult);
            badRequestResult.Should().NotBeNull();
            var response = badRequestResult.Value as GenericResponse<string>;
            response!.IsSuccess.Should().BeFalse();
        }

        [Fact]
        public async Task UpdateStatus_Should_Handle_DbUpdateConcurrencyException()
        {
            // Arrange
            _regionCodeHelperMock.Setup(r => r.VerifyRegionCodeHeader(It.IsAny<HttpRequest>())).Returns((GenericResponse<string>)null!);

            var user = new Domain.V1.Entities.Users.User
            {
                Id = 1,
                IsDeleted = false,
                BioAuthenticationEnabled = false,
                CreatedBy = "Admin",
                CreatedDate = DateTime.UtcNow,
                IsTempAccount = false,
                NotificationsEnabled = false,
                SOSButtonEnabled = false,
                Status = false,
                UpdatedBy = "Admin",
                UserName = "Test1",
                UserType = "Test2"

            };

            _userServiceMock.Setup(x => x.FindUserById(It.IsAny<long>())).ReturnsAsync(user);

            _userCommandServiceMock.Setup(x => x.UpdateUserStatusAsync(It.IsAny<UpdateUserRequest>(), It.IsAny<Domain.V1.Entities.Users.User>()))
                .ThrowsAsync(new DbUpdateConcurrencyException());

            var request = new UpdateUserStatusRequest { Status = true };

            // Act
            var result = await _controller.UpdateStatus(1, request);

            // Assert
            var badRequestResult = result as BadRequestObjectResult;
            Assert.NotNull(badRequestResult);
            badRequestResult.Should().NotBeNull();
            var response = badRequestResult.Value as GenericResponse<string>;
            response!.HasError.Should().BeTrue();
            response.Message.Should().Be(CommonConstants.ERROR_DB_CONCURRENCY);
        }

        #endregion

        #region Update User Tests

        [Fact]
        public async Task UpdateUser_ReturnsBadRequest_WhenRegionCodeIsInvalid()
        {
            // Arrange
            _regionCodeHelperMock.Setup(x => x.VerifyRegionCodeHeader(It.IsAny<HttpRequest>()))
                  .Returns((GenericResponse<string>)null);

            var dto = new UpdateUserRequestDto()
            {
                Id=1,
                UserName = "testuser",
                Password = "password123",
                UserType = "Admin",
                UserGroup = "Group1",
                FirstName = "John",
                LastName = "Doe",
                Mobile = "1234567890",
                Email = "test@example.com",
                BirthDate = new DateTime(1990, 1, 1),
                Gender = "Male"
            };

            // Act
            var result = await _controller.UpdateUser(dto);

            // Assert
            Assert.IsType<BadRequestObjectResult>(result);
        }

        [Fact]
        public async Task UpdateUser_ReturnsBadRequest_WhenModelStateIsInvalid()
        {
            // Arrange
            _controller.ModelState.AddModelError("Name", "Required");
            var dto = new UpdateUserRequestDto()
            {
                Id = 1,
                UserName = "testuser",
                Password = "password123",
                UserType = "Admin",
                UserGroup = "Group1",
                FirstName = "John",
                LastName = "Doe",
                Mobile = "1234567890",
                Email = "test@example.com",
                BirthDate = new DateTime(1990, 1, 1),
                Gender = "Male"
            };
            // Act
            var result = await _controller.UpdateUser(dto);

            // Assert
            Assert.IsType<BadRequestObjectResult>(result);
        }

        [Fact]
        public async Task UpdateUser_ReturnsBadRequest_WhenUserNameExists()
        {
            // Arrange
            var dto = new UpdateUserRequestDto
            {
                Id = 1,
                UserName = "testuser",
                Password = "password123",
                UserType = "Admin",
                UserGroup = "Group1",
                FirstName = "John",
                LastName = "Doe",
                Mobile = "1234567890",
                Email = "test@example.com",
                BirthDate = new DateTime(1990, 1, 1),
                Gender = "Male"
            };

            _regionCodeHelperMock.Setup(x => x.VerifyRegionCodeHeader(It.IsAny<HttpRequest>()))
                  .Returns((GenericResponse<string>)null);

            _userServiceMock.Setup(x => x.IsUserNameAlreadyExistById(dto.UserName, dto.Id)).Returns(true);

            // Act
            var result = await _controller.UpdateUser(dto);

            // Assert
            var badRequest = Assert.IsType<BadRequestObjectResult>(result);

            var response = Assert.IsType<GenericResponse<string>>(badRequest.Value);

            Assert.Equal(Resource.UserNameAlreadyExists, response.Message);
        }

        [Fact]
        public async Task UpdateUser_ReturnsBadRequest_WhenEmailExists()
        {
            var dto = new UpdateUserRequestDto
            {
                Id = 1,
                UserName = "testuser",
                Password = "password123",
                UserType = "Admin",
                UserGroup = "Group1",
                FirstName = "John",
                LastName = "Doe",
                Mobile = "1234567890",
                Email = "test@example.com",
                BirthDate = new DateTime(1990, 1, 1),
                Gender = "Male"
            };

            _regionCodeHelperMock.Setup(x => x.VerifyRegionCodeHeader(It.IsAny<HttpRequest>()))
                 .Returns((GenericResponse<string>)null);

            _userServiceMock.Setup(x => x.IsUserNameAlreadyExistById(It.IsAny<string>(), dto.Id)).Returns(false);

            _userTelecomQueryServiceMock.Setup(x => x.IsUserEmailIdAlreadyExistById(dto.Email, dto.Id)).Returns(true);

            var result = await _controller.UpdateUser(dto);

            var badRequest = Assert.IsType<BadRequestObjectResult>(result);

            var response = Assert.IsType<GenericResponse<string>>(badRequest.Value);

            Assert.Equal(Resource.EmailAlreadyExists, response.Message);

        }

        [Fact]
        public async Task UpdateUser_ReturnsBadRequest_WhenPhoneNumberExists()
        {
            var dto = new UpdateUserRequestDto {Id = 1, UserName = "testuser", Password = "password123", UserType = "Admin", UserGroup = "Group1", FirstName = "John", LastName = "Doe", Mobile = "1234567890", Email = "test@example.com", BirthDate = new DateTime(1990, 1, 1), Gender = "Male" };

            _regionCodeHelperMock.Setup(x => x.VerifyRegionCodeHeader(It.IsAny<HttpRequest>()))
                 .Returns((GenericResponse<string>)null);

            _userServiceMock.Setup(x => x.IsUserNameAlreadyExistById(It.IsAny<string>(), dto.Id)).Returns(false);

            _userTelecomQueryServiceMock.Setup(x => x.IsUserEmailIdAlreadyExistById(It.IsAny<string>(), dto.Id)).Returns(false);

            _userTelecomQueryServiceMock.Setup(x => x.IsUserPhoneNumberAlreadyExistById(dto.Mobile, dto.Id)).Returns(true);

            var result = await _controller.UpdateUser(dto);

            var badRequest = Assert.IsType<BadRequestObjectResult>(result);

            var response = Assert.IsType<GenericResponse<string>>(badRequest.Value);

            Assert.Equal(Resource.PhoneNumberAlreadyExists, response.Message);

        }

        [Fact]
        public async Task UpdateUser_ReturnsBadRequest_WhenUpdateFails()
        {
            var dto = new UpdateUserRequestDto
            {
                Id = 1,
                UserName = "testuser",
                Password = "password123",
                UserType = "Admin",
                UserGroup = "Group1",
                FirstName = "John",
                LastName = "Doe",
                Mobile = "1234567890",
                Email = "test@example.com",
                BirthDate = new DateTime(1990, 1, 1),
                Gender = "Male"
            };

            var user = new Domain.V1.Entities.Users.User()
            { 
                BioAuthenticationEnabled = true, 
                CreatedBy = string.Empty,
                CreatedDate = DateTime.UtcNow, 
                IsDeleted = false, IsTempAccount = false, NotificationsEnabled = false,
                SOSButtonEnabled = false, Status = true, UpdatedBy = string.Empty, UserName = string.Empty, 
                UserType = "Patient" 
            };

            _regionCodeHelperMock.Setup(x => x.VerifyRegionCodeHeader(It.IsAny<HttpRequest>()))
                             .Returns((GenericResponse<string>)null);

            _userServiceMock.Setup(x => x.IsUserNameAlreadyExistById(It.IsAny<string>(), dto.Id)).Returns(false);

            _userTelecomQueryServiceMock.Setup(x => x.IsUserEmailIdAlreadyExistById(It.IsAny<string>(), dto.Id)).Returns(false);

            _userTelecomQueryServiceMock.Setup(x => x.IsUserPhoneNumberAlreadyExistById(It.IsAny<string>(), dto.Id)).Returns(false);

            _userServiceMock.Setup(x => x.FindUserById(dto.Id)).ReturnsAsync(user);
            _userCommandServiceMock.Setup(x => x.UpdateAsync(dto, user)).ReturnsAsync(false);

            var result = await _controller.UpdateUser(dto);

            var badRequest = Assert.IsType<BadRequestObjectResult>(result);

            var response = Assert.IsType<GenericResponse<string>>(badRequest.Value);

            Assert.Equal(ResponseMessage.STATUS_FAILED, response.Message);
        }

        [Fact]
        public async Task UpdateUser_ReturnsBadRequest_WhenDbConcurrencyExceptionThrown()
        {
            var dto = new UpdateUserRequestDto
            {
                Id = 1,
                UserName = "testuser",
                Password = "password123",
                UserType = "Admin",
                UserGroup = "Group1",
                FirstName = "John",
                LastName = "Doe",
                Mobile = "1234567890",
                Email = "test@example.com",
                BirthDate = new DateTime(1990, 1, 1),
                Gender = "Male"
            };

            _regionCodeHelperMock.Setup(x => x.VerifyRegionCodeHeader(It.IsAny<HttpRequest>()))
                             .Returns((GenericResponse<string>)null);

            _userServiceMock.Setup(x => x.IsUserNameAlreadyExistById(It.IsAny<string>(), dto.Id)).Returns(false);

            _userTelecomQueryServiceMock.Setup(x => x.IsUserEmailIdAlreadyExistById(It.IsAny<string>(), dto.Id)).Returns(false);

            _userTelecomQueryServiceMock.Setup(x => x.IsUserPhoneNumberAlreadyExistById(It.IsAny<string>(), dto.Id)).Returns(false);

            _userServiceMock.Setup(x => x.FindUserById(dto.Id)).ThrowsAsync(new DbUpdateConcurrencyException());

            var result = await _controller.UpdateUser(dto);

            var badRequest = Assert.IsType<BadRequestObjectResult>(result);

            var response = Assert.IsType<GenericResponse<string>>(badRequest.Value);

            Assert.Equal(CommonConstants.ERROR_DB_CONCURRENCY, response.Message);
        }

        [Fact]
        public async Task UpdateUser_ReturnsOk_WhenUpdateSucceeds()
        {
            var dto = new UpdateUserRequestDto {Id = 1, UserName = "testuser", Password = "password123", UserType = "Admin", UserGroup = "Group1", FirstName = "John", LastName = "Doe", Mobile = "1234567890", Email = "test@example.com", BirthDate = new DateTime(1990, 1, 1), Gender = "Male" };
            var user = new Domain.V1.Entities.Users.User()
            {
                BioAuthenticationEnabled = true,
                CreatedBy = string.Empty,
                CreatedDate = DateTime.UtcNow,
                IsDeleted = false,
                IsTempAccount = false,
                NotificationsEnabled = false,
                SOSButtonEnabled = false,
                Status = true,
                UpdatedBy = string.Empty,
                UserName = string.Empty,
                UserType = "Patient"
            };

            _regionCodeHelperMock.Setup(x => x.VerifyRegionCodeHeader(It.IsAny<HttpRequest>())).Returns((GenericResponse<string>)null);
            _userServiceMock.Setup(x => x.IsUserNameAlreadyExistById(It.IsAny<string>(), dto.Id)).Returns(false);
            _userTelecomQueryServiceMock.Setup(x => x.IsUserEmailIdAlreadyExistById(It.IsAny<string>(), dto.Id)).Returns(false);
            _userTelecomQueryServiceMock.Setup(x => x.IsUserPhoneNumberAlreadyExistById(It.IsAny<string>(), dto.Id)).Returns(false);
            _userServiceMock.Setup(x => x.FindUserById(dto.Id)).ReturnsAsync(user);
            _userCommandServiceMock.Setup(x => x.UpdateAsync(dto, user)).ReturnsAsync(true);

            var result = await _controller.UpdateUser(dto);

            var okResult = Assert.IsType<OkObjectResult>(result);

            var response = Assert.IsType<GenericResponse<string>>(okResult.Value);

            Assert.Equal(ResponseMessage.STATUS_DATA_UPDATED, response.Message);
        }
        #endregion

        #region DeletePatientAccount Tests

        [Fact]
        public async Task DeletePatientAccount_InvalidRegionHeader_ReturnsBadRequest()
        {
            // Arrange
            DeletePatientAccountRequestDto deletePatientAccountRequestDto = new DeletePatientAccountRequestDto()
            {
                otherReason = string.Empty,
                selectedReason = string.Empty,
                LocationId = "KLAN",
                PatientMrnId = "KLAN-0000000001"
            };
            _regionCodeHelperMock.Setup(helper => helper.VerifyRegionCodeHeader(It.IsAny<HttpRequest>()))
                .Returns(new GenericResponse<string>
                {
                    IsSuccess = false,
                    HasError = true,
                    StatusCode = ResponseStatus.STATUS_BadRequest,
                    Message = Resource.RegionCodeRequired
                });

            var result = await _controller.DeletePatientAccount(deletePatientAccountRequestDto);

            Assert.IsType<BadRequestObjectResult>(result);
        }

        [Fact]
        public async Task DeletePatientAccount_InvalidUserId_ReturnsBadRequest()
        {
            DeletePatientAccountRequestDto deletePatientAccountRequestDto = new DeletePatientAccountRequestDto()
            {
                otherReason = string.Empty,
                selectedReason = string.Empty,
                LocationId = "KLAN",
                PatientMrnId = "KLAN-0000000001"
            };
            _regionCodeHelperMock.Setup(x => x.VerifyRegionCodeHeader(It.IsAny<HttpRequest>()))
                .Returns((GenericResponse<string>)null);

            _regionCodeHelperMock.Setup(x => x.GetUserIdByToken(It.IsAny<HttpRequest>()))
                .Returns(string.Empty);

            var result = await _controller.DeletePatientAccount(deletePatientAccountRequestDto);

            Assert.IsType<BadRequestObjectResult>(result);
        }

        [Fact]
        public async Task DeletePatientAccount_NullRequest_ReturnsBadRequest()
        {
            DeletePatientAccountRequestDto deletePatientAccountRequestDto = new DeletePatientAccountRequestDto()
            {
                otherReason = string.Empty,
                selectedReason = string.Empty,
                LocationId = "KLAN",
                PatientMrnId = "KLAN-0000000001"
            };
            _regionCodeHelperMock.Setup(x => x.VerifyRegionCodeHeader(It.IsAny<HttpRequest>()))
                .Returns(new GenericResponse<string>() { Result = "MYS", IsSuccess = true });

            _regionCodeHelperMock.Setup(x => x.GetUserIdByToken(It.IsAny<HttpRequest>()))
                .Returns("123");

            var result = await _controller.DeletePatientAccount(deletePatientAccountRequestDto);

            Assert.IsType<NotFoundObjectResult>(result);
        }

        [Fact]
        public async Task DeletePatientAccount_UserNotFound_ReturnsNotFound()
        {
            DeletePatientAccountRequestDto deletePatientAccountRequestDto = new DeletePatientAccountRequestDto()
            {
                otherReason = string.Empty,
                selectedReason = string.Empty,
                LocationId = "KLAN",
                PatientMrnId = "KLAN-0000000001"
            };

            _regionCodeHelperMock.Setup(x => x.VerifyRegionCodeHeader(It.IsAny<HttpRequest>()))
                .Returns(new GenericResponse<string>() { Result = "MYS", IsSuccess = true });

            _regionCodeHelperMock.Setup(x => x.GetUserIdByToken(It.IsAny<HttpRequest>()))
                .Returns("123");

            _userServiceMock.Setup(x => x.FindUserById(It.IsAny<long>()))
                .ReturnsAsync((Domain.V1.Entities.Users.User)null);

            var result = await _controller.DeletePatientAccount(deletePatientAccountRequestDto);

            Assert.IsType<NotFoundObjectResult>(result);
        }

        [Fact]
        public async Task DeletePatientAccount_Success_ReturnsOk()
        {
            // Arrange
            DeletePatientAccountRequestDto deletePatientAccountRequestDto = new DeletePatientAccountRequestDto()
            {
                otherReason = string.Empty,
                selectedReason = string.Empty,
                LocationId = "KLAN",
                PatientMrnId = "KLAN-0000000001"
            };
            var request = new UserResetPasswordRequest { Id = 1 };

            _regionCodeHelperMock.Setup(x => x.VerifyRegionCodeHeader(It.IsAny<HttpRequest>()))
                .Returns(new GenericResponse<string>() { Result = "MYS", IsSuccess = true });

            _regionCodeHelperMock.Setup(x => x.GetUserIdByToken(It.IsAny<HttpRequest>()))
                .Returns("1");

            var userData = new Domain.V1.Entities.Users.User
            {
                Id = 1,
                UserName = "admin",
                Status = true,
                Gender = "Male",
                BirthDate = DateTime.UtcNow,
                ManagingOrganization = "1",
                Source = "Aurora",
                IsTempAccount = true,
                UserType = "Patient",
                Passcode = "1234",
                Language = 1,
                NotificationsEnabled = true,
                BioAuthenticationEnabled = true,
                SOSButtonEnabled = true,
                AppVersion = "v1",
                Password = "1234",
                IsMarketingConsentEnable = true,
                Salt = "salt",
                LocationEnable = true,
                IsDeleted = false,
                CreatedBy = "Admin",
                CreatedDate = DateTime.UtcNow,
                UpdatedBy = "Admin",  // Adding the missing property
                UpdatedDate = DateTime.UtcNow,// Assuming UpdatedDate is required as well
            };

            _userServiceMock.Setup(x => x.FindUserById(request.Id))
                .ReturnsAsync(userData);

            _userCommandServiceMock.Setup(x => x.DeletePatientAccountAsync(userData, deletePatientAccountRequestDto, "MYS"))
                .ReturnsAsync(true);

            var result = await _controller.DeletePatientAccount(deletePatientAccountRequestDto);

            var okResult = Assert.IsType<OkObjectResult>(result);
            var response = Assert.IsType<GenericResponse<string>>(okResult.Value);
            Assert.True(response.IsSuccess);
        }

        [Fact]
        public async Task DeletePatientAccount_DbConcurrencyError_ReturnsBadRequest()
        {
            // Arrange
            DeletePatientAccountRequestDto deletePatientAccountRequestDto = new DeletePatientAccountRequestDto()
            {
                otherReason = string.Empty,
                selectedReason = string.Empty,
                LocationId = "KLAN",
                PatientMrnId = "KLAN-0000000001"
            };
            var request = new UserResetPasswordRequest { Id = 1 };

            _regionCodeHelperMock.Setup(x => x.VerifyRegionCodeHeader(It.IsAny<HttpRequest>()))
                .Returns(new GenericResponse<string>() { Result = "MYS" , IsSuccess = true});

            _regionCodeHelperMock.Setup(x => x.GetUserIdByToken(It.IsAny<HttpRequest>()))
                .Returns("1");

            var userData = new Domain.V1.Entities.Users.User
            {
                Id = 1,
                UserName = "admin",
                Status = true,
                Gender = "Male",
                BirthDate = DateTime.UtcNow,
                ManagingOrganization = "1",
                Source = "Aurora",
                IsTempAccount = true,
                UserType = "Patient",
                Passcode = "1234",
                Language = 1,
                NotificationsEnabled = true,
                BioAuthenticationEnabled = true,
                SOSButtonEnabled = true,
                AppVersion = "v1",
                Password = "1234",
                IsMarketingConsentEnable = true,
                Salt = "salt",
                LocationEnable = true,
                IsDeleted = false,
                CreatedBy = "Admin",
                CreatedDate = DateTime.UtcNow,
                UpdatedBy = "Admin",  // Adding the missing property
                UpdatedDate = DateTime.UtcNow,// Assuming UpdatedDate is required as well
            };

            _userServiceMock.Setup(x => x.FindUserById(request.Id))
                .ReturnsAsync(userData);

            _userCommandServiceMock.Setup(x => x.DeletePatientAccountAsync(userData, deletePatientAccountRequestDto, "MYS"))
                 .ThrowsAsync(new DbUpdateConcurrencyException());

            var result = await _controller.DeletePatientAccount(deletePatientAccountRequestDto);


            var badResult = Assert.IsType<BadRequestObjectResult>(result);
            var response = Assert.IsType<GenericResponse<string>>(badResult.Value);
            Assert.True(response.HasError);
        }
        [Fact]
        public async Task DeletePatientAccount_Fail_ReturnsBadRequest()
        {
            // Arrange
            DeletePatientAccountRequestDto deletePatientAccountRequestDto = new DeletePatientAccountRequestDto()
            {
                otherReason = string.Empty,
                selectedReason = string.Empty,
                LocationId = "KLAN",
                PatientMrnId = "KLAN-0000000001"
            };
            var request = new UserResetPasswordRequest { Id = 1 };

            _regionCodeHelperMock.Setup(x => x.VerifyRegionCodeHeader(It.IsAny<HttpRequest>()))
                .Returns(new GenericResponse<string>() { Result = "MYS", IsSuccess = true });

            _regionCodeHelperMock.Setup(x => x.GetUserIdByToken(It.IsAny<HttpRequest>()))
                .Returns("1");

            var userData = new Domain.V1.Entities.Users.User
            {
                Id = 1,
                UserName = "admin",
                Status = true,
                Gender = "Male",
                BirthDate = DateTime.UtcNow,
                ManagingOrganization = "1",
                Source = "Aurora",
                IsTempAccount = true,
                UserType = "Patient",
                Passcode = "1234",
                Language = 1,
                NotificationsEnabled = true,
                BioAuthenticationEnabled = true,
                SOSButtonEnabled = true,
                AppVersion = "v1",
                Password = "1234",
                IsMarketingConsentEnable = true,
                Salt = "salt",
                LocationEnable = true,
                IsDeleted = false,
                CreatedBy = "Admin",
                CreatedDate = DateTime.UtcNow,
                UpdatedBy = "Admin",  // Adding the missing property
                UpdatedDate = DateTime.UtcNow,// Assuming UpdatedDate is required as well
            };

            _userServiceMock.Setup(x => x.FindUserById(request.Id))
                .ReturnsAsync(userData);

            _userCommandServiceMock.Setup(x => x.DeletePatientAccountAsync(userData, deletePatientAccountRequestDto, "MYS"))
                .ReturnsAsync(false);

            var result = await _controller.DeletePatientAccount(deletePatientAccountRequestDto);

            var badResult = Assert.IsType<BadRequestObjectResult>(result);
            var response = Assert.IsType<GenericResponse<string>>(badResult.Value);
            Assert.False(response.HasError);
        }

        #endregion
        #region Enable Bio Matric Authentication
        [Fact]
        public async Task UpdateBiometricSetting_InvalidModelState_ReturnsBadRequest()
        {
            // Arrange
            _controller.ModelState.AddModelError("UserId", "Required");
            var request = new UpdateBiometricSettingRequest { EnableBiometric = true };
            _regionCodeHelperMock
                .Setup(helper => helper.VerifyRegionCodeHeader(It.IsAny<HttpRequest>()))
                .Returns((GenericResponse<string>)null);
            // Act
            var result = await _controller.UpdateBiometricSetting(request);
            // Assert
            var badRequestResult = Assert.IsType<BadRequestObjectResult>(result);
            var response = Assert.IsType<SerializableError>(badRequestResult.Value);
            Assert.NotEmpty(response);
        }
        [Fact]
        public async Task UpdateBiometricSetting_InvalidRegionCode_ReturnsBadRequest()
        {
            // Arrange
            var request = new UpdateBiometricSettingRequest { EnableBiometric = true };
            var regionError = new GenericResponse<string>
            {
                HasError = true,
                Message = "Invalid region code.",
                IsSuccess = false,
                MessageType = CommonConstants.ERROR,
                StatusCode = ResponseStatusCode.STATUS_BADREQUEST
            };
            _regionCodeHelperMock
                .Setup(helper => helper.VerifyRegionCodeHeader(It.IsAny<HttpRequest>()))
                .Returns(regionError);
            // Act
            var result = await _controller.UpdateBiometricSetting(request);
            // Assert
            var badRequestResult = Assert.IsType<BadRequestObjectResult>(result);
            var response = Assert.IsType<GenericResponse<string>>(badRequestResult.Value);
            Assert.Contains("Invalid region code", response.Message);
        }
        [Fact]
        public async Task UpdateBiometricSetting_FailedUpdate_ReturnsBadRequest()
        {
            // Arrange
            var request = new UpdateBiometricSettingRequest { EnableBiometric = true };
            _userCommandServiceMock
                .Setup(service => service.UpdateBiometricSettingAsync(It.IsAny<long>(), It.IsAny<bool>()))
                .ReturnsAsync(false);
            _regionCodeHelperMock
                .Setup(helper => helper.VerifyRegionCodeHeader(It.IsAny<HttpRequest>()))
                .Returns((GenericResponse<string>)null);
            var claims = new List<Claim>
    {
        new Claim("userId", "1")
    };
            var identity = new ClaimsIdentity(claims);
            var principal = new ClaimsPrincipal(identity);
            _controller.ControllerContext = new ControllerContext
            {
                HttpContext = new DefaultHttpContext { User = principal }
            };
            // Act
            var result = await _controller.UpdateBiometricSetting(request);
            // Assert
            var badRequestResult = Assert.IsType<BadRequestObjectResult>(result);
            var response = Assert.IsType<GenericResponse<string>>(badRequestResult.Value);
            Assert.False(response.IsSuccess);
            Assert.Equal(ResponseStatusCode.STATUS_BADREQUEST, response.StatusCode);
        }
        [Fact]
        public async Task UpdateBiometricSetting_DbConcurrencyException_ReturnsBadRequest()
        {
            // Arrange
            var request = new UpdateBiometricSettingRequest { EnableBiometric = true };
            _userCommandServiceMock
                .Setup(service => service.UpdateBiometricSettingAsync(It.IsAny<long>(), It.IsAny<bool>()))
                .ThrowsAsync(new DbUpdateConcurrencyException());
            _regionCodeHelperMock
                .Setup(helper => helper.VerifyRegionCodeHeader(It.IsAny<HttpRequest>()))
                .Returns((GenericResponse<string>)null);
            var claims = new List<Claim>
    {
        new Claim("userId", "1")
    };
            var identity = new ClaimsIdentity(claims);
            var principal = new ClaimsPrincipal(identity);
            _controller.ControllerContext = new ControllerContext
            {
                HttpContext = new DefaultHttpContext { User = principal }
            };
            // Act
            var result = await _controller.UpdateBiometricSetting(request);
            // Assert
            var badRequestResult = Assert.IsType<BadRequestObjectResult>(result);
            var response = Assert.IsType<GenericResponse<string>>(badRequestResult.Value);
            Assert.False(response.IsSuccess);
            Assert.Equal(CommonConstants.ERROR_DB_CONCURRENCY, response.Message);
        }
        [Fact]
        public async Task UpdateBiometricSetting_ValidRequest_ReturnsOk()
        {
            // Arrange
            var request = new UpdateBiometricSettingRequest
            {
                EnableBiometric = true,
            };
            _userCommandServiceMock
                .Setup(service => service.UpdateBiometricSettingAsync(It.IsAny<long>(), It.IsAny<bool>()))
                .ReturnsAsync(true);
            _regionCodeHelperMock
                .Setup(helper => helper.VerifyRegionCodeHeader(It.IsAny<HttpRequest>()))
                .Returns((GenericResponse<string>)null);
            var claims = new List<Claim>
    {
            new Claim("userId", "1")
    };
            var identity = new ClaimsIdentity(claims);
            var principal = new ClaimsPrincipal(identity);
            _controller.ControllerContext = new ControllerContext
            {
                HttpContext = new DefaultHttpContext { User = principal }
            };
            // Act
            var result = await _controller.UpdateBiometricSetting(request);
            // Assert
            var okResult = Assert.IsType<OkObjectResult>(result);
            var response = Assert.IsType<GenericResponse<string>>(okResult.Value);
            Assert.True(response.IsSuccess);
            Assert.False(response.HasError);
            Assert.Equal(ResponseStatusCode.STATUS_SUCCESS, response.StatusCode);
            Assert.Equal(CommonConstants.SUCCESS, response.MessageType);
            Assert.Equal("Biometric authentication enabled.", response.Message);
        }
        #endregion
        #region Create PassCode 
        [Fact]
        public async Task CreatePasscode_ShouldReturnBadRequest_WhenRegionCodeInvalid()
        {
            // Arrange
            var request = new CreatePasscodeRequest { Passcode = "123456", ConfirmPasscode = "123456" };
            _regionCodeHelperMock.Setup(x => x.VerifyRegionCodeHeader(It.IsAny<HttpRequest>()))
                .Returns(new GenericResponse<string> { HasError = true, Message = "Invalid region code" });
            // Act
            var result = await _controller.CreatePasscode(request);
            // Assert
            var badRequestResult = Assert.IsType<BadRequestObjectResult>(result);
            var response = Assert.IsType<GenericResponse<string>>(badRequestResult.Value);
            response.HasError.Should().BeTrue();
            badRequestResult.StatusCode.Should().Be((int)ResponseStatusCodes.BadRequest);
        }
        [Fact]
        public async Task CreatePasscode_ShouldReturnBadRequest_WhenModelStateInvalid()
        {
            // Arrange
            var request = new CreatePasscodeRequest { Passcode = "123456", ConfirmPasscode = "123456" };
            _regionCodeHelperMock.Setup(x => x.VerifyRegionCodeHeader(It.IsAny<HttpRequest>()))
                .Returns((GenericResponse<string>)null);
            _controller.ModelState.AddModelError("Passcode", "Required");
            // Act
            var result = await _controller.CreatePasscode(request);
            // Assert
            var badRequest = Assert.IsType<BadRequestObjectResult>(result);
            badRequest.StatusCode.Should().Be((int)ResponseStatusCodes.BadRequest);
            badRequest.Value.Should().BeOfType<SerializableError>();
        }
        [Fact]
        public async Task CreatePasscode_ShouldReturnUnauthorized_WhenUserIdMissingOrInvalid()
        {
            // Arrange
            var request = new CreatePasscodeRequest { Passcode = "123456", ConfirmPasscode = "123456" };
            _regionCodeHelperMock.Setup(x => x.VerifyRegionCodeHeader(It.IsAny<HttpRequest>()))
                .Returns((GenericResponse<string>)null);
            _controller.ControllerContext = new ControllerContext
            {
                HttpContext = new DefaultHttpContext
                {
                    User = new ClaimsPrincipal(new ClaimsIdentity()) // empty claims
                }
            };
            // Act
            var result = await _controller.CreatePasscode(request);
            // Assert
            var unauthorized = Assert.IsType<UnauthorizedObjectResult>(result);
            var response = Assert.IsType<GenericResponse<string>>(unauthorized.Value);
            response.StatusCode.Should().Be(ResponseStatus.STATUS_Unauthorized);
            response.Message.Should().Be(ResponseMessages.INVALID_USER_ID_FORMAT);
            response.IsSuccess.Should().BeFalse();
        }
        [Fact]
        public async Task CreatePasscode_ShouldReturnOk_WhenServiceReturnsSuccess()
        {
            // Arrange
            var request = new CreatePasscodeRequest { Passcode = "123456", ConfirmPasscode = "123456" };
            _regionCodeHelperMock.Setup(x => x.VerifyRegionCodeHeader(It.IsAny<HttpRequest>()))
                .Returns((GenericResponse<string>)null);
            var claims = new List<Claim> { new Claim(ClaimTypes.NameIdentifier, "1") };
            var identity = new ClaimsIdentity(claims, "TestAuth");
            var user = new ClaimsPrincipal(identity);
            _controller.ControllerContext = new ControllerContext
            {
                HttpContext = new DefaultHttpContext { User = user }
            };
            _userCommandServiceMock
                .Setup(s => s.CreatePasscodeAsync(request, 1))
                .ReturnsAsync(new GenericResponse<string> { IsSuccess = true, Result = "hashed-passcode" });
            // Act
            var result = await _controller.CreatePasscode(request);
            // Assert
            var okResult = Assert.IsType<OkObjectResult>(result);
            var response = Assert.IsType<GenericResponse<string>>(okResult.Value);
            response.IsSuccess.Should().BeTrue();
            response.Result.Should().Be("hashed-passcode");
        }
        [Fact]
        public async Task CreatePasscode_ShouldReturnBadRequest_WhenServiceReturnsFailure()
        {
            // Arrange
            var request = new CreatePasscodeRequest { Passcode = "123456", ConfirmPasscode = "123456" };
            _regionCodeHelperMock.Setup(x => x.VerifyRegionCodeHeader(It.IsAny<HttpRequest>()))
                .Returns((GenericResponse<string>)null);
            var claims = new List<Claim> { new Claim(ClaimTypes.NameIdentifier, "1") };
            var identity = new ClaimsIdentity(claims, "TestAuth");
            var user = new ClaimsPrincipal(identity);
            _controller.ControllerContext = new ControllerContext
            {
                HttpContext = new DefaultHttpContext { User = user }
            };
            _userCommandServiceMock
                .Setup(s => s.CreatePasscodeAsync(request, 1))
                .ReturnsAsync(new GenericResponse<string> { IsSuccess = false, Message = "Failed to create passcode" });
            // Act
            var result = await _controller.CreatePasscode(request);
            // Assert
            var badRequest = Assert.IsType<BadRequestObjectResult>(result);
            var response = Assert.IsType<GenericResponse<string>>(badRequest.Value);
            response.IsSuccess.Should().BeFalse();
            response.Message.Should().Be("Failed to create passcode");
        }
        #endregion
    }
}
