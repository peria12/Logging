﻿using Aurora.AdministrationService.API.Controllers.PasswordController;
using Aurora.AdministrationService.API.Models.RequestModels.password;
using Aurora.AdministrationService.API.Models.ResponseModels.Password;
using Aurora.AdministrationService.API.Services.IService.Password;
using Aurora.AdministrationService.CrossCutting.CommonModels;
using FluentAssertions;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Configuration;
using Moq;

namespace Aurora.AdministrationService.Tests.API.Controllers.PasswordReset
{
    public class PasswordResetControllerTests
    {
        private readonly Mock<IConfiguration> _configurationMock;
        private readonly Mock<IPasswordServices> _passwordServiceMock;
        private readonly PasswordResetController _controller;

        public PasswordResetControllerTests()
        {
            _configurationMock = new Mock<IConfiguration>();
            _passwordServiceMock = new Mock<IPasswordServices>();
            _controller = new PasswordResetController(_configurationMock.Object, _passwordServiceMock.Object);
            _controller.ControllerContext.HttpContext = new DefaultHttpContext();
        }

        [Fact]
        public async Task GetUserContactInfo_ValidUserId_ReturnsOkResult()
        {
            // Arrange
            var userId = "123";
            var response = new GenericResponse<UserContactInfoDto>
            {
                IsSuccess = true,
                Result = new UserContactInfoDto { Email = "test@example.com", PhoneNumber = "1234567890" }
            };

            _passwordServiceMock
                .Setup(service => service.GetUserContactInfoAsync(userId))
                .ReturnsAsync(response);

            // Act
            var result = await _controller.GetUserContactInfo(userId);

            // Assert
            var okResult = result as OkObjectResult;
            okResult.Should().NotBeNull();
            var responseResult = okResult?.Value as GenericResponse<UserContactInfoDto>;
            responseResult?.IsSuccess.Should().BeTrue();
            responseResult?.Result?.Email.Should().Be("test@example.com");
        }

        [Fact]
        public async Task GetUserContactInfo_InvalidUserId_ReturnsNotFoundResult()
        {
            // Arrange
            var userId = "999";
            var response = new GenericResponse<UserContactInfoDto>
            {
                IsSuccess = false,
                Message = "User not found"
            };

            _passwordServiceMock
                .Setup(service => service.GetUserContactInfoAsync(userId))
                .ReturnsAsync(response);

            // Act
            var result = await _controller.GetUserContactInfo(userId);

            // Assert
            var okResult = result as OkObjectResult;
            okResult.Should().NotBeNull();
            var responseResult = okResult?.Value as GenericResponse<UserContactInfoDto>;
            responseResult?.IsSuccess.Should().BeFalse();
            responseResult?.Message.Should().Be("User not found");
        }

        [Fact]
        public async Task CreateResetPassword_ValidRequest_ReturnsOkResult()
        {
            // Arrange
            var model = new ResetPasswordRequestModel
            {
                UserId = "123",
                NewPassword = "NewPassword@123",
                ConfirmPassword = "NewPassword@123"
            };

            var response = new GenericResponse<string>
            {
                IsSuccess = true,
                Message = "Password reset successful"
            };

            _passwordServiceMock
                .Setup(service => service.ResetPassword(model.UserId, model.NewPassword, model.ConfirmPassword))
                .ReturnsAsync(response);

            // Act
            var result = await _controller.CreateResetPassword(model);

            // Assert
            var okResult = result as OkObjectResult;
            okResult.Should().NotBeNull();
            var responseResult = okResult?.Value as GenericResponse<string>;
            responseResult?.IsSuccess.Should().BeTrue();
            responseResult?.Message.Should().Be("Password reset successful");
        }

        [Fact]
        public async Task CreateResetPassword_PasswordMismatch_ReturnsBadRequest()
        {
            // Arrange
            var model = new ResetPasswordRequestModel
            {
                UserId = "123",
                NewPassword = "NewPassword@123",
                ConfirmPassword = "MismatchPassword@123"
            };

            var response = new GenericResponse<string>
            {
                IsSuccess = false,
                Message = "Passwords do not match"
            };

            _passwordServiceMock
                .Setup(service => service.ResetPassword(model.UserId, model.NewPassword, model.ConfirmPassword))
                .ReturnsAsync(response);

            // Act
            var result = await _controller.CreateResetPassword(model);

            // Assert
            var okResult = result as OkObjectResult;
            okResult.Should().NotBeNull();
            var responseResult = okResult?.Value as GenericResponse<string>;
            responseResult?.IsSuccess.Should().BeFalse();
            responseResult?.Message.Should().Be("Passwords do not match");
        }
    }
}
