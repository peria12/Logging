﻿using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using System.ComponentModel.Design;
using Aurora.AdministrationService.Domain.V1.Entities.Users;

namespace Aurora.AdministrationService.Domain.V1.Entities.Dependent
{
    [Table(name: "Dependent", Schema = "dbo")]
    public class Dependent : IAuditableEntity, IDeletableEntity
    {
        [Key]
        [DatabaseGenerated(DatabaseGeneratedOption.Identity)]
        public required long ID { get; set; }

        [Required]
        public required long UserID { get; set; }

        [Required]
        public required bool Status { get; set; }

        [Required]
        public required long DependentUserID { get; set; }

        [MaxLength(20)]
        public string? Source { get; set; }

        [MaxLength(50)]
        public string? RelationshipCategory { get; set; }

        [Required]
        [MaxLength(50)]
        public required string Relationship { get; set; }

        [Timestamp]
        public byte[] RecordVersion { get; set; } = default!;

        [Required]
        public required bool IsDeleted { get; set; }

        [MaxLength(50)]
        public string? CreatedBy { get; set; }

        [Required]
        public required DateTime CreatedDate { get; set; }

        [MaxLength(50)]
        public string? UpdatedBy { get; set; }

        public DateTime? UpdatedDate { get; set; }

        public virtual User? ParentUser { get; set; }

        public virtual User? DependentUser { get; set; }

    }
}
