using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using Aurora.AdministrationService.Domain.V1.Entities.Dependent;

namespace Aurora.AdministrationService.Domain.V1.Entities.Users
{
    [Table(name: "User", Schema = "dbo")]

    public class User : IAuditableEntity, IDeletableEntity
    {
        [Key]
        [DatabaseGenerated(DatabaseGeneratedOption.Identity)]
        public long Id { get; set; }
        [MaxLength(20)]
        public required string UserName { get; set; }
        [MaxLength(20)]
        public string? Nationality { get; set; }
        [MaxLength(600)]
        public string? UserPicture { get; set; }
        public required bool Status { get; set; }
        [MaxLength(20)]
        public string? Gender { get; set; }
        public DateTime? BirthDate { get; set; }
        [MaxLength(20)]
        public string? ManagingOrganization { get; set; }
        [MaxLength(20)]
        public string? Source { get; set; }
        public required bool IsTempAccount { get; set; }
        [MaxLength(50)]
        public string? DefaultLanding { get; set; }
        [MaxLength(20)]
        public required string UserType { get; set; }
        [MaxLength(100)]
        public string? Passcode { get; set; }
        public int? Language { get; set; }
        public required bool NotificationsEnabled { get; set; }
        public required bool BioAuthenticationEnabled { get; set; }
        public required bool SOSButtonEnabled { get; set; }
        [MaxLength(100)]
        public string? AppVersion { get; set; }
        [MaxLength(100)]
        public string? Password { get; set; }
        public bool? IsMarketingConsentEnable { get; set; }
        [MaxLength(20)]
        public string? Salt { get; set; }
        public bool? LocationEnable { get; set; }
        [Timestamp]
        public byte[] RecordVersion { get; set; } = Array.Empty<byte>();
        public required bool IsDeleted { get; set; }
        [MaxLength(50)]
        public required string? CreatedBy { get; set; }
        public required DateTime CreatedDate { get; set; }
        [MaxLength(50)]
        public required string? UpdatedBy { get; set; }
        public DateTime? UpdatedDate { get; set; }

        public virtual ICollection<Dependent.Dependent> ChildOrOtherUsers { get; set; } = new List<Dependent.Dependent>();

        public virtual ICollection<Dependent.Dependent> DependentUsers { get; set; } = new List<Dependent.Dependent>();
        public virtual ICollection<UserNames> UserNames { get; set; } = new List<UserNames>();
        public virtual ICollection<UserTelecom> UserTelecom { get; set; } = new List<UserTelecom>();
        public virtual ICollection<UserIdentifier> UserIdentifier { get; set; } = new List<UserIdentifier>();
        public virtual ICollection<ForgetPassword> ForgetPassword { get; set; } = new List<ForgetPassword>();
    }
}
