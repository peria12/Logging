using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace Aurora.AdministrationService.Domain.V1.Entities.Users
{
    [Table(name: "UserTelecom", Schema = "dbo")]

    public class UserTelecom : IAuditableEntity, IDeletableEntity
    {
        [Key]
        [DatabaseGenerated(DatabaseGeneratedOption.Identity)]
        public long Id { get; set; }
        public required long UserID { get; set; }
        [MaxLength(10)]
        public string? PhoneCountryCode { get; set; }
        [MaxLength(20)]
        public required string System { get; set; }
        public bool? Status { get; set; }
        public required DateTime CreatedDate { get; set; }
        [MaxLength(50)]
        public required string? CreatedBy { get; set; }
        [MaxLength(20)]
        public required string Use { get; set; }
        public DateTime? UpdatedDate { get; set; }
        public int? Rank { get; set; }
        [MaxLength(50)]
        public required string? UpdatedBy { get; set; }
        public DateTime? PeriodEnd { get; set; }
        public DateTime? PeriodStart { get; set; }
        [MaxLength(100)]
        public required string Value { get; set; }
        public required bool IsDeleted { get; set; }
        [Timestamp]
        public byte[] RecordVersion { get; set; } = Array.Empty<byte>();
        public virtual User? User { get; set; }
    }
}
