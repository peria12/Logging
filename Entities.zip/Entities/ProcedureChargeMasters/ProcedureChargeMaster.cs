using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace Aurora.AdministrationService.Domain.V1.Entities.ProcedureChargeMasters
{
    [Table(name: "ProcedureChargeMaster", Schema = "dbo")]

    public class ProcedureChargeMaster : IAuditableEntity, IDeletableEntity
    {
        [Key]
        [DatabaseGenerated(DatabaseGeneratedOption.Identity)]
        public long Id { get; set; }
        [MaxLength(50)]
        public string? MasterType { get; set; }
        [MaxLength(50)]
        public required string ItemCode { get; set; }
        [MaxLength(255)]
        public string? ItemDescription { get; set; }
        [MaxLength(20)]
        public string? ItemTypeCode { get; set; }
        [MaxLength(255)]
        public string? ItemTypeDescription { get; set; }
        [MaxLength(20)]
        public string? ProcedureCode { get; set; }
        [MaxLength(255)]
        public string? ProcedureDesc { get; set; }
        [MaxLength(20)]
        public string? FacilityCode { get; set; }
        [Timestamp]
        public byte[] RecordVersion { get; set; } = Array.Empty<byte>();
        public required bool IsDeleted { get; set; }
        [MaxLength(50)]
        public string? CreatedBy { get; set; }
        public required DateTime CreatedDate { get; set; }
        [MaxLength(50)]
        public string? UpdatedBy { get; set; }
        public DateTime? UpdatedDate { get; set; }
    }
}
