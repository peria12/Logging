using Aurora.AdministrationService.Domain.V1.Entities.PractitionerRoles;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace Aurora.AdministrationService.Domain.V1.Entities.Organizations
{
    [Table(name: "Organization", Schema = "dbo")]

    public class Organization : IAuditableEntity, IDeletableEntity
    {
        [Key]
        [DatabaseGenerated(DatabaseGeneratedOption.Identity)]
        public long Id { get; set; }
        public required string ResourceID { get; set; }
        public bool Status { get; set; }
        [MaxLength(20)]
        public string Type { get; set; }
        [MaxLength(50)]
        public string Name { get; set; }
        [MaxLength(50)]
        public string Alias { get; set; }
        public Guid PartOf { get; set; }
        [MaxLength(20)]
        public string Source { get; set; }
        [Timestamp]
        public byte[] RecordVersion { get; set; } = Array.Empty<byte>();
        public required bool IsDeleted { get; set; }
        [MaxLength(50)]
        public required string CreatedBy { get; set; }
        public required DateTime CreatedDate { get; set; }
        [MaxLength(50)]
        public string UpdatedBy { get; set; }
        public DateTime? UpdatedDate { get; set; }
        public virtual ICollection<OrganizationAddress> OrganizationAddress { get; set; } = new List<OrganizationAddress>();
        public virtual ICollection<OrganizationContact> OrganizationContact { get; set; } = new List<OrganizationContact>();
        public virtual ICollection<OrganizationTelecom> OrganizationTelecom { get; set; } = new List<OrganizationTelecom>();
        public virtual ICollection<PractitionerRole> PractitionerRole { get; set; } = new List<PractitionerRole>();

    }
}
