using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace Aurora.AdministrationService.Domain.V1.Entities.Organizations
{
    [Table(name: "OrganizationTelecom", Schema = "dbo")]

    public class OrganizationTelecom : IAuditableEntity, IDeletableEntity
    {
        [Key]
        [DatabaseGenerated(DatabaseGeneratedOption.Identity)]
        public long Id { get; set; }
        public required long OrganizationID { get; set; }
        [MaxLength(20)]
        public required string System { get; set; }
        [MaxLength(100)]
        public required string Value { get; set; }
        [MaxLength(20)]
        public required string Use { get; set; }
        public int Rank { get; set; }
        public DateTime PeriodStart { get; set; }
        public DateTime PeriodEnd { get; set; }
        [Timestamp]
        public byte[] RecordVersion { get; set; } = Array.Empty<byte>();
        public required bool IsDeleted { get; set; }
        [MaxLength(50)]
        public required string CreatedBy { get; set; }
        public required DateTime CreatedDate { get; set; }
        [MaxLength(50)]
        public string UpdatedBy { get; set; }
        public DateTime? UpdatedDate { get; set; }
        public virtual Organization? Organization { get; set; }
    }
}
