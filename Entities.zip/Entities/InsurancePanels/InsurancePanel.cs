﻿using System.ComponentModel.DataAnnotations.Schema;
using System.ComponentModel.DataAnnotations;

namespace Aurora.AdministrationService.Domain.V1.Entities.InsurancePanels
{
   [Table(name: "InsurancePanel", Schema = "dbo")]

    public class InsurancePanel : IAuditableEntity, IDeletableEntity
    {
        [Key]
        [DatabaseGenerated(DatabaseGeneratedOption.Identity)]
        public long Id { get; set; }
        [MaxLength(20)]
        public required string ResourceID { get; set; }
        [MaxLength(50)]
        public string DebtorName { get; set; }
         [MaxLength(500)]
        public string Logo { get; set; }
        public required bool Status { get; set; }
        [Timestamp]
        public byte[] RecordVersion { get; set; } = Array.Empty<byte>();
        public required bool IsDeleted { get; set; }
        [MaxLength(50)]
        public required string CreatedBy { get; set; }
        public required DateTime CreatedDate { get; set; }
        [MaxLength(50)]
        public string UpdatedBy { get; set; }
        public DateTime? UpdatedDate { get; set; }
        public virtual ICollection<InsurancePanelLocation> InsurancePanelLocation { get; set; } = new List<InsurancePanelLocation>();
    }
}

