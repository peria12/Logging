﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations.Schema;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Aurora.AdministrationService.Domain.V1.Entities.Contents;

namespace Aurora.AdministrationService.Domain.V1.Entities.InsurancePanels
{
    [Table(name: "InsurancePanelLocation", Schema = "dbo")]

    public class InsurancePanelLocation : IAuditableEntity, IDeletableEntity
    {
        [Key]
        [DatabaseGenerated(DatabaseGeneratedOption.Identity)]
        public long Id { get; set; }
        public required long InsurancePanelID { get; set; }
        [MaxLength(20)]
        public string LocationID { get; set; }
        [Timestamp]
        public byte[] RecordVersion { get; set; } = Array.Empty<byte>();
        public required bool IsDeleted { get; set; }
        [MaxLength(50)]
        public required string CreatedBy { get; set; }
        public required DateTime CreatedDate { get; set; }
        [MaxLength(50)]
        public string UpdatedBy { get; set; }
        public DateTime? UpdatedDate { get; set; }
        public virtual InsurancePanel? InsurancePanel { get; set; }
    }
}
