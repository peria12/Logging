using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace Aurora.AdministrationService.Domain.V1.Entities.DrugMasters
{
    [Table(name: "DrugMaster", Schema = "dbo")]

    public class DrugMaster : IAuditableEntity, IDeletableEntity
    {
        [Key]
        [DatabaseGenerated(DatabaseGeneratedOption.Identity)]
        public long ID { get; set; }
        [MaxLength(20)]
        public required string ResourceID { get; set; }
        [MaxLength(50)]
        public required string MasterType { get; set; }
        [MaxLength(50)]
        public required string ItemCode { get; set; }
        [MaxLength(255)]
        public string? ItemDescription { get; set; }
        [MaxLength(50)]
        public string? ItemTypeCode { get; set; }
        [MaxLength(255)]
        public string? ItemTypeDescription { get; set; }
        [MaxLength(50)]
        public required string MedicationCode { get; set; }
        [MaxLength(255)]
        public string? MedicationDescription { get; set; }
        [MaxLength(50)]
        public string? MedicationCategory { get; set; }
        [MaxLength(50)]
        public string? MedicationType { get; set; }
        [MaxLength(50)]
        public string? Strength { get; set; }
        [MaxLength(50)]
        public string? DrugForm { get; set; }
        [MaxLength(255)]
        public string? Caution { get; set; }
        [MaxLength(50)]
        public string? DosageUnit { get; set; }
        public double? DoseValue { get; set; }
        [MaxLength(100)]
        public string? FrequencyDesc { get; set; }
        public double? FrequencyValue { get; set; }
        [MaxLength(50)]
        public string? DurationUnit { get; set; }
        public int? DurationValue { get; set; }
        [MaxLength(50)]
        public string? Route { get; set; }
        [MaxLength(50)]
        public string? DrugFormGroup { get; set; }
        [MaxLength(500)]
        public string? Instructions { get; set; }
        public bool? IsSTATDrug { get; set; }
        public bool? IsAlertRequired { get; set; }
        public bool? IsPoisonDrug { get; set; }
        public bool? IsPsychotropicDrug { get; set; }
        public bool? IsDangerousDrug { get; set; }
        public bool? IsAnesthesiaDrug { get; set; }
        public bool? IsActive { get; set; }
        [MaxLength(100)]
        public string? FacilityCode { get; set; }
        [MaxLength(20)]
        public string? BrandShare { get; set; }
        [Timestamp]
        public required byte[] RecordVersion { get; set; } = Array.Empty<byte>();
        public required bool IsDeleted { get; set; }
        [MaxLength(50)]
        public string? CreatedBy { get; set; }
        public required DateTime CreatedDate { get; set; }
        [MaxLength(50)]
        public string? UpdatedBy { get; set; }
        public DateTime? UpdatedDate { get; set; }
    }
}
