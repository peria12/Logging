﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations.Schema;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Aurora.AdministrationService.Domain.V1.Entities.CountryMasters
{
    [Table(name: "CountryMaster", Schema = "dbo")]
    public class CountryMaster : IAuditableEntity, IDeletableEntity
    {
        [Key]
        [DatabaseGenerated(DatabaseGeneratedOption.Identity)]
        public long Id { get; set; }
        [MaxLength(20)]
        public required string ResourceId { get; set; }
        [MaxLength(10)]
        public string? Code { get; set; }
        [MaxLength(200)]
        public string? Definition { get; set; }
        [MaxLength(200)]
        public string? Display { get; set; }
        [MaxLength(50)]
        public string? Source { get; set; }
        [MaxLength(500)]
        public string? ImageUrl { get; set; }
        [MaxLength(100)]
        public string? Nationality { get; set; }
        [Timestamp]
        public byte[] RecordVersion { get; set; } = Array.Empty<byte>();
        public required bool IsDeleted { get; set; }
        [MaxLength(50)]
        public string? CreatedBy { get; set; }
        public required DateTime CreatedDate { get; set; }
        [MaxLength(50)]
        public string? UpdatedBy { get; set; }
        public DateTime? UpdatedDate { get; set; }
    }
}