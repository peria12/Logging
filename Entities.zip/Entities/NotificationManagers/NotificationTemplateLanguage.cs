using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace Aurora.AdministrationService.Domain.Entities
{
    [Table(name: "NotificationTemplateLanguage", Schema = "dbo")]

    public class NotificationTemplateLanguage : IAuditableEntity, IDeletableEntity
    {
        [Key]
        [DatabaseGenerated(DatabaseGeneratedOption.Identity)]
        public int Id { get; set; }
        [MaxLength(50)]
        public required string NotificationTemplateID { get; set; }
        public required bool Status { get; set; }
        [MaxLength(50)]
        public string LanguageID { get; set; }
        [MaxLength(100)]
        public string PushNotification { get; set; }
        [MaxLength(100)]
        public string SMS { get; set; }
        [MaxLength(100)]
        public string InApp { get; set; }
        [MaxLength(100)]
        public string Whatapp { get; set; }
        [MaxLength(100)]
        public string EmailSubject { get; set; }
        [MaxLength(100)]
        public string EmailBody { get; set; }
        [Timestamp]
        public byte[] RecordVersion { get; set; } = Array.Empty<byte>();
        public required bool IsDeleted { get; set; }
        [MaxLength(50)]
        public string CreatedBy { get; set; }
        public DateTime CreatedDate { get; set; }
        [MaxLength(50)]
        public string UpdatedBy { get; set; }
        public DateTime? UpdatedDate { get; set; }
    }
}
