using Aurora.AdministrationService.Domain.V1.Entities.Contents;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace Aurora.AdministrationService.Domain.Entities
{
    [Table(name: "NotificationManager", Schema = "dbo")]

    public class NotificationManager : IAuditableEntity, IDeletableEntity
    {
        public required long ID { get; set; }
        [MaxLength(100)]
        public string Module { get; set; }
        [MaxLength(50)]
        public string UserGroupID { get; set; }
        [MaxLength(20)]
        public string NotificationType { get; set; }
        public required bool Status { get; set; }
        [Timestamp]
        public byte[] RecordVersion { get; set; } = Array.Empty<byte>();
        public required bool IsDeleted { get; set; }
        [MaxLength(50)]
        public required string CreatedBy { get; set; }
        public required DateTime CreatedDate { get; set; }
        [MaxLength(50)]
        public string UpdatedBy { get; set; }
        public DateTime? UpdatedDate { get; set; }
    }
}
