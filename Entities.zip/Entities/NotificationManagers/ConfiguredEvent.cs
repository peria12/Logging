using Aurora.AdministrationService.Domain.V1.Entities.PaymentGateways;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace Aurora.AdministrationService.Domain.Entities
{
    [Table(name: "ConfiguredEvent", Schema = "dbo")]

    public class ConfiguredEvent : IAuditableEntity, IDeletableEntity
    {
        public required long ID { get; set; }
        [MaxLength(50)]
        public string NotificationManagerID { get; set; }
        [MaxLength(20)]
        public string Event { get; set; }
        [MaxLength(50)]
        public string NotificationTempletID { get; set; }
        public DateTime Time { get; set; }
        [MaxLength(50)]
        public string TimeDuration { get; set; }
        [MaxLength(50)]
        public string Due { get; set; }
        public required bool Status { get; set; }
        [Timestamp]
        public byte[] RecordVersion { get; set; } = Array.Empty<byte>();
        public required bool IsDeleted { get; set; }
        [MaxLength(50)]
        public required string CreatedBy { get; set; }
        public required DateTime CreatedDate { get; set; }
        [MaxLength(50)]
        public string UpdatedBy { get; set; }
        public DateTime? UpdatedDate { get; set; }
    }
}
