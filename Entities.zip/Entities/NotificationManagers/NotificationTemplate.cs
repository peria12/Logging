using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace Aurora.AdministrationService.Domain.Entities
{
    [Table(name: "NotificationTemplate", Schema = "dbo")]

    public class NotificationTemplate : IAuditableEntity, IDeletableEntity
    {
        public required long ID { get; set; }
        [MaxLength(50)]
        public string UniqueID { get; set; }
        public required bool Status { get; set; }
        [MaxLength(50)]
        public string Module { get; set; }
        [MaxLength(50)]
        public string UserGroup { get; set; }
        [Timestamp]
        public byte[] RecordVersion { get; set; } = Array.Empty<byte>();
        public required bool IsDeleted { get; set; }
        [MaxLength(50)]
        public string CreatedBy { get; set; }
        public DateTime CreatedDate { get; set; }
        [MaxLength(50)]
        public string UpdatedBy { get; set; }
        public DateTime? UpdatedDate { get; set; }
    }
}
