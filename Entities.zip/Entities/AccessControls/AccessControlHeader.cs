﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations.Schema;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Aurora.AdministrationService.Domain.V1.Entities.UserGroups;

namespace Aurora.AdministrationService.Domain.V1.Entities.AccessControls
{
    [Table(name: "AccessControlHeader", Schema = "dbo")]
    public class AccessControlHeader : IAuditableEntity, IDeletableEntity
    {
        [Key]
        [DatabaseGenerated(DatabaseGeneratedOption.Identity)]
        public long Id { get; set; }
        public required long AccessControlMasterID { get; set; }
        public required int RoleID { get; set; }
        [Timestamp]
        public byte[] RecordVersion { get; set; } = Array.Empty<byte>();
        public required bool IsDeleted { get; set; }
        [MaxLength(50)]
        public string? CreatedBy { get; set; }
        public required DateTime CreatedDate { get; set; }
        [MaxLength(50)]
        public string? UpdatedBy { get; set; }
        public DateTime? UpdatedDate { get; set; }
        public virtual Roles? Roles { get; set; }
        public virtual ICollection<AccessControlParameter> AccessControlParameters { get; set; } = new List<AccessControlParameter>();

        public virtual AccessControlMaster? AccessControlMaster { get; set; }

    }
}
