using Aurora.AdministrationService.Domain.Entities;
using Aurora.AdministrationService.Domain.V1.Entities.PractitionerRoles;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace Aurora.AdministrationService.Domain.V1.Entities
{
    [Table(name: "Agreement", Schema = "dbo")]

    public class Agreement : IAuditableEntity, IDeletableEntity
    {
        public required long ID { get; set; }
        [MaxLength(20)]
        public string? UniqueID { get; set; }
        public required bool Status { get; set; }
        public long? FrequencyID { get; set; }
        [Timestamp]
        public byte[] RecordVersion { get; set; } = Array.Empty<byte>();
        public required bool IsDeleted { get; set; }
        [MaxLength(50)]
        public required string CreatedBy { get; set; }
        public required DateTime CreatedDate { get; set; }
        [MaxLength(50)]
        public required string UpdatedBy { get; set; }
        public required DateTime? UpdatedDate { get; set; }
        public virtual FrequencyMaster? FrequencyMaster { get; set; }
        public virtual ICollection<AgreementLanguage> AgreementLanguage { get; set; } = new List<AgreementLanguage>();

    }
}
