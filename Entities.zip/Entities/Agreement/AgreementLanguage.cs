using Aurora.AdministrationService.Domain.V1.Entities.PractitionerRoles;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace Aurora.AdministrationService.Domain.V1.Entities
{
    [Table(name: "AgreementLanguage", Schema = "dbo")]

    public class AgreementLanguage : IAuditableEntity, IDeletableEntity
    {
        [Key]
        [DatabaseGenerated(DatabaseGeneratedOption.Identity)]
        public long Id { get; set; }
        public required long AgreementID { get; set; }
        public required bool Status { get; set; }
        [MaxLength(50)]
        public string? Name { get; set; }
        public long? LanguageID { get; set; }
        [MaxLength(100)]
        public string? Description { get; set; }
        [Timestamp]
        public byte[] RecordVersion { get; set; } = Array.Empty<byte>();
        public required bool IsDeleted { get; set; }
        [MaxLength(50)]
        public required string CreatedBy { get; set; }
        public required DateTime CreatedDate { get; set; }
        [MaxLength(50)]
        public required string UpdatedBy { get; set; }
        public required DateTime? UpdatedDate { get; set; }
        public virtual Agreement? Agreement { get; set; }
    }
}
