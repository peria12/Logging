using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace Aurora.AdministrationService.Domain.V1.Entities.PractitionerRoles
{
    [Table(name: "PractitionerRoleCode", Schema = "dbo")]

    public class PractitionerRoleCode : IAuditableEntity, IDeletableEntity
    {
        [Key]
        [DatabaseGenerated(DatabaseGeneratedOption.Identity)]
        public long Id { get; set; }
        public required long PractitionerRoleID { get; set; }
        [MaxLength(20)]
        public required string Code { get; set; }
        [Timestamp]
        public byte[] RecordVersion { get; set; } = Array.Empty<byte>();
        public required bool IsDeleted { get; set; }
        [MaxLength(50)]
        public required string CreatedBy { get; set; }
        public required DateTime CreatedDate { get; set; }
        [MaxLength(50)]
        public string UpdatedBy { get; set; }
        public DateTime? UpdatedDate { get; set; }
        public virtual PractitionerRole? PractitionerRole { get; set; }
        public virtual RoleMaster? RoleMaster { get; set; }
    }
}
