using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace Aurora.AdministrationService.Domain.V1.Entities.PractitionerRoles
{
    [Table(name: "PractitionerAvailability", Schema = "dbo")]

    public class PractitionerAvailability : IAuditableEntity, IDeletableEntity
    {
        [Key]
        [DatabaseGenerated(DatabaseGeneratedOption.Identity)]
        public long Id { get; set; }
        public long PractitionerRoleId { get; set; }
        [MaxLength(50)]
        public required long SlotsID { get; set; }
        public required DateTime ScheduleStartDate { get; set; }
        public required DateTime ScheduleEndDate { get; set; }
        [MaxLength(500)]
        public string? Instruction { get; set; }
        [Timestamp]
        public byte[] RecordVersion { get; set; } = Array.Empty<byte>();
        public required bool IsDeleted { get; set; }
        [MaxLength(50)]
        public required string CreatedBy { get; set; }
        public required DateTime CreatedDate { get; set; }
        [MaxLength(50)]
        public string UpdatedBy { get; set; }
        public DateTime? UpdatedDate { get; set; }
        public virtual ICollection<PractitionerAvailabilityDay> PractitionerAvailabilityDay { get; set; } = new List<PractitionerAvailabilityDay>();
        

    }
}
