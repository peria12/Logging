using Aurora.AdministrationService.Domain.V1.Entities.Organizations;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace Aurora.AdministrationService.Domain.V1.Entities.PractitionerRoles
{
    [Table(name: "PractitionerRoleIdentifier", Schema = "dbo")]

    public class PractitionerRoleIdentifier : IAuditableEntity, IDeletableEntity
    {
        [Key]
        [DatabaseGenerated(DatabaseGeneratedOption.Identity)]
        public long Id { get; set; }
        public required long PractitionerRoleID { get; set; }
        [MaxLength(20)]
        public string System { get; set; }
        [MaxLength(100)]
        public string Value { get; set; }
        [MaxLength(20)]
        public string IdentifierUse { get; set; }
        [MaxLength(20)]
        public string IdentifierType { get; set; }
        public DateTime PeriodStart { get; set; }
        public DateTime PeriodEnd { get; set; }
        [Timestamp]
        public byte[] RecordVersion { get; set; } = Array.Empty<byte>();
        public required bool IsDeleted { get; set; }
        [MaxLength(50)]
        public required string CreatedBy { get; set; }
        public required DateTime CreatedDate { get; set; }
        [MaxLength(50)]
        public string UpdatedBy { get; set; }
        public DateTime? UpdatedDate { get; set; }
        public virtual PractitionerRole? PractitionerRole { get; set; }
    }
}
