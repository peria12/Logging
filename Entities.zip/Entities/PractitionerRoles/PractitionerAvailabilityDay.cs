using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace Aurora.AdministrationService.Domain.V1.Entities.PractitionerRoles
{
    [Table(name: "PractitionerAvailabilityDay", Schema = "dbo")]

    public class PractitionerAvailabilityDay : IAuditableEntity, IDeletableEntity
    {
        [Key]
        [DatabaseGenerated(DatabaseGeneratedOption.Identity)]
        public long Id { get; set; }
        public required long PractitionerAvailabilityID { get; set; }
        [MaxLength(20)]
        public required string AvailabilityDay { get; set; }
        public TimeSpan StartTime { get; set; }
        public TimeSpan EndTime { get; set; }
        public bool AllDay { get; set; }
        [Timestamp]
        public byte[] RecordVersion { get; set; } = Array.Empty<byte>();
        public required bool IsDeleted { get; set; }
        [MaxLength(50)]
        public required string CreatedBy { get; set; }
        public required DateTime CreatedDate { get; set; }
        [MaxLength(50)]
        public string UpdatedBy { get; set; }
        public DateTime? UpdatedDate { get; set; }
        public virtual PractitionerAvailability? PractitionerAvailability { get; set; }
        public virtual ICollection<PractitionerAvailabilityBreak> PractitionerAvailabilityBreak { get; set; } = new List<PractitionerAvailabilityBreak>();
        public virtual ICollection<PractitionerAvailabilityOccurance> PractitionerAvailabilityOccurance { get; set; } = new List<PractitionerAvailabilityOccurance>();
    }
}
