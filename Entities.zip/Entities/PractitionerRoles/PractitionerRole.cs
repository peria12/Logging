using Aurora.AdministrationService.Domain.V1.Entities.Locations;
using Aurora.AdministrationService.Domain.V1.Entities.Organizations;
using Aurora.AdministrationService.Domain.V1.Entities.Practitioners;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace Aurora.AdministrationService.Domain.V1.Entities.PractitionerRoles
{
    [Table(name: "PractitionerRole", Schema = "dbo")]

    public class PractitionerRole : IAuditableEntity, IDeletableEntity
    {
        [Key]
        [DatabaseGenerated(DatabaseGeneratedOption.Identity)]
        public long Id { get; set; }
        public required Guid UUID { get; set; }
        public required string PractitionerID { get; set; }
        public long OrganizationID { get; set; }
        public DateTime PeriodStart { get; set; }
        [MaxLength(20)]
        public string? ResourceID { get; set; }
        [MaxLength(20)]
        public string? LocationID { get; set; }
        public DateTime PeriodEnd { get; set; }
        public bool Active { get; set; }
        [MaxLength(255)]
        public string AvailabilityExceptions { get; set; }
        [Timestamp]
        public byte[] RecordVersion { get; set; } = Array.Empty<byte>();
        public required bool IsDeleted { get; set; }
        [MaxLength(50)]
        public required string CreatedBy { get; set; }
        public required DateTime CreatedDate { get; set; }
        [MaxLength(50)]
        public string UpdatedBy { get; set; }
        public DateTime? UpdatedDate { get; set; }
        public virtual Practitioner? Practitioner { get; set; }
        public virtual Organization? Organization { get; set; }
        public virtual Location? Location { get; set; }

        public virtual ICollection<PractitionerRoleIdentifier> PractitionerRoleIdentifier { get; set; } = new List<PractitionerRoleIdentifier>();
        public virtual PractitionerRoleCode? PractitionerRoleCode { get; set; }
        public virtual PractitionerRoleSpecialty? PractitionerRoleSpecialty { get; set; }
        public virtual ICollection<PractitionerRoleLocation> PractitionerRoleLocation { get; set; } = new List<PractitionerRoleLocation>();
        public virtual ICollection<PractitionerRoleHealthcareService> PractitionerRoleHealthcareService { get; set; } = new List<PractitionerRoleHealthcareService>();
        public virtual ICollection<PractitionerRoleAvailableTime> PractitionerRoleAvailableTime { get; set; } = new List<PractitionerRoleAvailableTime>();
        public virtual ICollection<PractitionerRoleNotAvailable> PractitionerRoleNotAvailable { get; set; } = new List<PractitionerRoleNotAvailable>();
        public virtual ICollection<PractitionerAvailability> PractitionerAvailability { get; set; } = new List<PractitionerAvailability>();


    }
}
