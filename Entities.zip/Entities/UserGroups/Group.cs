﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations.Schema;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Aurora.AdministrationService.Domain.V1.Entities.UserGroups
{
    [Table(name: "Group", Schema = "dbo")]

    public class Group : IAuditableEntity, IDeletableEntity
    {
        
        [Key]
        [DatabaseGenerated(DatabaseGeneratedOption.Identity)]
        public int Id { get; set; }
        [MaxLength(20)]
        public required string Code { get; set; }
        [MaxLength(100)]
        public string? Definition { get; set; }
        [MaxLength(100)]
        public string? Display { get; set; }
        [MaxLength(50)]
        public required string GroupName { get; set; }
        public bool? IsObsolete { get; set; }
        [MaxLength(25)]
        public string? Source { get; set; }
        [MaxLength(50)]
        public required bool IsDeleted { get; set; }
        [MaxLength(50)]
        public string? CreatedBy { get; set; }
        public required DateTime CreatedDate { get; set; }
        [MaxLength(50)]
        public string? UpdatedBy { get; set; }
        public DateTime? UpdatedDate { get; set; }
        public virtual ICollection<GroupRoleMapping> GroupRoleMappings { get; set; } = new List<GroupRoleMapping>();
        public virtual ICollection<UserProfile> UserProfiles { get; set; } = new List<UserProfile>();
    }
}
