﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations.Schema;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Aurora.AdministrationService.Domain.V1.Entities.UserGroups
{
    [Table(name: "ResourceMapping", Schema = "dbo")]

    public class ResourceMapping : IAuditableEntity, IDeletableEntity
    {
       
        [Key]
        [DatabaseGenerated(DatabaseGeneratedOption.Identity)]
        public int Id { get; set; }
        public int? CategoryID { get; set; }
        [MaxLength(20)]
        public required string Code { get; set; }
        [MaxLength(200)]
        public string? ControllerAction { get; set; }
        [MaxLength(200)]
        public string? CSS { get; set; }
        [MaxLength(100)]
        public string? Definition { get; set; }
        [MaxLength(100)]
        public string? Display { get; set; }
        [MaxLength(100)]
        public string? ICON { get; set; }
        public bool? IsScreenRequired { get; set; }
        public int? ParentID { get; set; }
        [MaxLength(50)]
        public required string ResourceName { get; set; }
        public int? ResourceTypeID { get; set; }
        public int? SEQ { get; set; }
        [MaxLength(25)]
        public string? Source { get; set; }
        public int? SubCategoryID { get; set; }
        
        [MaxLength(200)]
        public string? URL { get; set; }
        public required bool IsDeleted { get; set; }
        [MaxLength(50)]
        public string? CreatedBy { get; set; }
        public required DateTime CreatedDate { get; set; }
        [MaxLength(50)]
        public string? UpdatedBy { get; set; }
        public DateTime? UpdatedDate { get; set; }

        public virtual ICollection<RoleResourceMapping> RoleResourceMappings { get; set; } = new List<RoleResourceMapping>();
        public virtual ICollection<ResourceMapping> ParentResourceMappings { get; set; } = new List<ResourceMapping>();
        public virtual ICollection<DependentResources> DependentResources { get; set; } = new List<DependentResources>();
        public virtual ResourceMapping? ParentResourceMapping { get; set; }
        public virtual ResourceType? ResourceType { get; set; }

    }
}
