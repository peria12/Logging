﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations.Schema;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Aurora.AdministrationService.Domain.V1.Entities.UserGroups
{
    [Table(name: "DependentResources", Schema = "dbo")]
    public class DependentResources : IAuditableEntity, IDeletableEntity
    {
        [Key]
        [DatabaseGenerated(DatabaseGeneratedOption.Identity)]
        public int Id { get; set; }
        public int? ParentID { get; set; }
        public required long DependentResourceID { get; set; }
        public int? ResourceMappingID { get; set; }
        [MaxLength(100)]
        public string? DependentResourceName { get; set; }
        public long? DependentResourceTypeID { get; set; }
        public required int ResourceID { get; set; }
        public required bool IsDeleted { get; set; }
        [MaxLength(50)]
        public string? CreatedBy { get; set; }
        public required DateTime CreatedDate { get; set; }
        [MaxLength(50)]
        public string? UpdatedBy { get; set; }
        public DateTime? UpdatedDate { get; set; }
        public virtual ResourceMapping? ResourceMapping { get; set; }

    }
}
