﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations.Schema;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Aurora.AdministrationService.Domain.V1.Entities.UserGroups
{
    [Table(name: "RoleResourceMapping", Schema = "dbo")]

    public class RoleResourceMapping : IAuditableEntity, IDeletableEntity
    {
        [MaxLength(20)]
        public required string Code { get; set; }
        
        [MaxLength(100)]
        public string? Definition { get; set; }
        [MaxLength(100)]
        public string? Display { get; set; }
        [Key]
        [DatabaseGenerated(DatabaseGeneratedOption.Identity)]
        public int Id { get; set; }
       
        public bool? IsEditAccess { get; set; }
        public required int ResourceID { get; set; }
        public required int RoleID { get; set; }
        [MaxLength(25)]
        public string? Source { get; set; }
        public required bool IsDeleted { get; set; }
        [MaxLength(50)]
        public string? CreatedBy { get; set; }
        public required DateTime CreatedDate { get; set; }
        [MaxLength(50)]
        public string? UpdatedBy { get; set; }
        public DateTime? UpdatedDate { get; set; }
        public virtual ResourceMapping? ResourceMapping { get; set; }
        public virtual Roles? Roles { get; set; }
    }
}
