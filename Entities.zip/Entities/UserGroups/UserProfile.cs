﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations.Schema;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Aurora.AdministrationService.Domain.V1.Entities.UserGroups
{
    [Table(name: "UserProfile", Schema = "dbo")]

    public class UserProfile : IAuditableEntity, IDeletableEntity
    {
        public DateTime? Birthdate { get; set; }
        [MaxLength(20)]
        public string? CityCode { get; set; }
        [MaxLength(20)]
        public string? CountryCode { get; set; }
        public int? DepartmentID { get; set; }
        public int? EmployeeID { get; set; }
        public int? EmployeeTypeID { get; set; }
        [MaxLength(150)]
        public string? FirstName { get; set; }
        public int? GroupID { get; set; }
        public int? HomePage { get; set; }
        [MaxLength(32)]
        public string? HouseNo { get; set; }
        public int? HouseNoCode { get; set; }
        [Key]
        [DatabaseGenerated(DatabaseGeneratedOption.Identity)]
        public int Id { get; set; }
        [MaxLength(150)]
        public string? LastName { get; set; }
        public int? MenuID { get; set; }
        [MaxLength(16)]
        public string? Mobile { get; set; }
        public int? MobileCode { get; set; }
        [MaxLength(32)]
        public string? OfficeNo { get; set; }
        public int? OfficeNoCode { get; set; }
        [MaxLength(25)]
        public string? PostCode { get; set; }
        [MaxLength(50)]
        public string? PrimaryEmailID { get; set; }
        public int? ReportingManagerID { get; set; }
        [MaxLength(50)]
        public string? SecondaryEmailID { get; set; }
        [MaxLength(50)]
        public string? SignatureFileName { get; set; }
        [MaxLength(20)]
        public string? StateCode { get; set; }
        [MaxLength(150)]
        public string? Street1 { get; set; }
        [MaxLength(50)]
        public string? Street2 { get; set; }
        [MaxLength(50)]
        public string? Street3 { get; set; }
        [MaxLength(50)]
        public string? Street4 { get; set; }
        public int? UserID { get; set; }
        [MaxLength(20)]
        public string? UserProfileCode { get; set; }
        public required bool IsDeleted { get; set; }
        [MaxLength(50)]
        public string? CreatedBy { get; set; }
        public required DateTime CreatedDate { get; set; }
        [MaxLength(50)]
        public string? UpdatedBy { get; set; }
        public DateTime? UpdatedDate { get; set; }
        public virtual Group? Group { get; set; }
    }
}
