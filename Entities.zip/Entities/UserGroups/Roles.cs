﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations.Schema;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Aurora.AdministrationService.Domain.V1.Entities.AccessControls;

namespace Aurora.AdministrationService.Domain.V1.Entities.UserGroups
{
    [Table(name: "Roles", Schema = "dbo")]

    public class Roles : IAuditableEntity, IDeletableEntity
    {
        
        [Key]
        [DatabaseGenerated(DatabaseGeneratedOption.Identity)]
        public int Id { get; set; }
        [MaxLength(20)]
        public required string Code { get; set; }
        [MaxLength(20)]
        public required string Location { get; set; }
        public bool? IsObsolete { get; set; }
        public int? MenuID { get; set; }
        [MaxLength(200)]
        public string? RoleDescription { get; set; }
        [MaxLength(50)]
        public required string RoleName { get; set; }
        [MaxLength(25)]
        public string? Source { get; set; }
        [MaxLength(50)]
        public required bool IsDeleted { get; set; }
        [MaxLength(50)]
        public string? CreatedBy { get; set; }
        public required DateTime CreatedDate { get; set; }
        [MaxLength(50)]
        public string? UpdatedBy { get; set; }
        public DateTime? UpdatedDate { get; set; }
        public virtual ICollection<GroupRoleMapping> GroupRoleMappings { get; set; } = new List<GroupRoleMapping>();
        public virtual ICollection<RoleResourceMapping> RoleResourceMappings { get; set; } = new List<RoleResourceMapping>();
        public virtual ICollection<AccessControlHeader> AccessControlHeaders { get; set; } = new List<AccessControlHeader>();
    }
}
