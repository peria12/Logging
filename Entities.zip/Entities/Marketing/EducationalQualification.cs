using Aurora.AdministrationService.Domain.V1.Entities.Organizations;
using Aurora.AdministrationService.Domain.V1.Entities.Practitioners;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace Aurora.AdministrationService.Domain.V1.Entities
{
    [Table(name: "EducationalQualification", Schema = "dbo")]

    public class EducationalQualification : IAuditableEntity, IDeletableEntity
    {
        [Key]
        [DatabaseGenerated(DatabaseGeneratedOption.Identity)]
        public required long Id { get; set; }
        public required long ManageDoctorProfileID { get; set; }
        [MaxLength(100)]
        public required string EducationalDegree { get; set; }
        public int? YearOfPassing { get; set; }
        [MaxLength(100)]
        public string? Institute { get; set; }
        public bool? Status { get; set; }
        public required bool IsDeleted { get; set; }
        [Timestamp]
        public byte[] RecordVersion { get; set; } = Array.Empty<byte>();
        public required DateTime CreatedDate { get; set; }
        [MaxLength(50)]
        public string? CreatedBy { get; set; }
        public DateTime? UpdatedDate { get; set; }
        [MaxLength(50)]
        public string? UpdatedBy { get; set; }
        public virtual ManageDoctorProfile? ManageDoctorProfile { get; set; }
    }
}
