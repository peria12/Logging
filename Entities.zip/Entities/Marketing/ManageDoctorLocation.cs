using Aurora.AdministrationService.Domain.V1.Entities.Practitioners;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace Aurora.AdministrationService.Domain.V1.Entities
{
    [Table(name: "ManageDoctorLocation", Schema = "dbo")]

    public class ManageDoctorLocation : IAuditableEntity, IDeletableEntity
    {
        [Key]
        [DatabaseGenerated(DatabaseGeneratedOption.Identity)]
        public required long Id { get; set; }
        public required long ManageDoctorProfileID { get; set; }
        [MaxLength(50)]
        public required string Location { get; set; }
        [Timestamp]
        public byte[] RecordVersion { get; set; } = Array.Empty<byte>();
        public bool? Status { get; set; }
        public required bool IsDeleted { get; set; }
        public required DateTime CreatedDate { get; set; }
        [MaxLength(50)]
        public string? CreatedBy { get; set; }
        public DateTime? UpdatedDate { get; set; }
        [MaxLength(50)]
        public string? UpdatedBy { get; set; }
        public virtual ManageDoctorProfile? ManageDoctorProfile { get; set; }
    }
}
