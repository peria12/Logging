using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace Aurora.AdministrationService.Domain.V1.Entities
{
    [Table(name: "Banner", Schema = "dbo")]

    public class Banner : IAuditableEntity, IDeletableEntity
    {
        public required long ID { get; set; }
        [MaxLength(100)]
        public required string Title { get; set; }
        [MaxLength(255)]
        public string? URL { get; set; }
        [MaxLength(500)]
        public string? ImageUrl { get; set; }
        public DateTime? StartDate { get; set; }
        public DateTime? EndDate { get; set; }
        public bool? Status { get; set; }
        [Timestamp]
        public byte[] RecordVersion { get; set; } = Array.Empty<byte>();
        public required bool IsDeleted { get; set; }
        [MaxLength(50)]
        public required string CreatedBy { get; set; }
        public required DateTime CreatedDate { get; set; }
        [MaxLength(50)]
        public string? UpdatedBy { get; set; }
        public required DateTime? UpdatedDate { get; set; }
    }
}
