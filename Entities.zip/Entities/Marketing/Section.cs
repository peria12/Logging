using Aurora.AdministrationService.Domain.V1.Entities.Practitioners;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace Aurora.AdministrationService.Domain.V1.Entities
{
    [Table(name: "Section", Schema = "dbo")]

    public class Section : IAuditableEntity, IDeletableEntity
    {
        public required long ID { get; set; }
        public required long ManageDoctorProfileID { get; set; }
        [MaxLength(100)]
        public string? Title { get; set; }
        [MaxLength(255)]
        public string? Description { get; set; }
        public bool? Status { get; set; }
        public required bool IsDeleted { get; set; }
        [Timestamp]
        public byte[] RecordVersion { get; set; } = Array.Empty<byte>();
        public required DateTime CreatedDate { get; set; }
        [MaxLength(50)]
        public string? CreatedBy { get; set; }
        public DateTime? UpdatedDate { get; set; }
        [MaxLength(50)]
        public string? UpdatedBy { get; set; }
        public virtual ManageDoctorProfile? ManageDoctorProfile { get; set; }
    }
}
