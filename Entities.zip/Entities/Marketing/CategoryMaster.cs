﻿using Microsoft.EntityFrameworkCore;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
namespace Aurora.AdministrationService.Domain.V1.Entities.Marketings
{
    [Table(name: "CategoryMaster", Schema = "dbo")]
    public class CategoryMaster : IAuditableEntity
    {
        [Key]
        [DatabaseGenerated(DatabaseGeneratedOption.Identity)]
        public required long ID { get; set; }
        [MaxLength(20)]
        public string? Code { get; set; }
        [MaxLength(200)]
        public string? Definition { get; set; }
        [Timestamp]
        public byte[] RecordVersion { get; set; } = Array.Empty<byte>();
        public required bool IsDeleted { get; set; }
        [MaxLength(50)]
        public required string CreatedBy { get; set; }
        public required DateTime CreatedDate { get; set; }
        [MaxLength(50)]
        public string? UpdatedBy { get; set; }
        public DateTime? UpdatedDate { get; set; }
        public virtual ICollection<WhatsHappening> WhatsHappening { get; set; } = new List<WhatsHappening>();
    }
}