using Aurora.AdministrationService.Domain.V1.Entities.Practitioners;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace Aurora.AdministrationService.Domain.V1.Entities
{
    [Table(name: "ManageRank", Schema = "dbo")]

    public class ManageRank : IAuditableEntity, IDeletableEntity
    {
        public required long ID { get; set; }
        public required long ManageDoctorProfileID { get; set; }
        public bool Status { get; set; }
        [Timestamp]
        public byte[] RecordVersion { get; set; } = Array.Empty<byte>();
        public required bool IsDeleted { get; set; }
        [MaxLength(50)]
        public required string CreatedBy { get; set; }
        public required DateTime CreatedDate { get; set; }
        [MaxLength(50)]
        public required string UpdatedBy { get; set; }
        public required DateTime? UpdatedDate { get; set; }
        public virtual ManageDoctorProfile? ManageDoctorProfile { get; set; }
    }
}
