using Aurora.AdministrationService.Domain.V1.Entities.Locations;
using Aurora.AdministrationService.Domain.V1.Entities.PractitionerRoles;
using Microsoft.EntityFrameworkCore;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace Aurora.AdministrationService.Domain.V1.Entities.Marketings
{
    [Table(name: "WhatsHappening", Schema = "dbo")]

    public class WhatsHappening : IAuditableEntity, IDeletableEntity
    {
        public required long ID { get; set; }
        [MaxLength(100)]
        public required string Title { get; set; }
        [MaxLength(255)]
        public string? URL { get; set; }
        public long CategoryID { get; set; }
        public long HospitalID { get; set; }
        public DateTime StartDate { get; set; }
        public DateTime EndDate { get; set; }
        [MaxLength(255)]
        public string? Image { get; set; }
        [MaxLength(255)]
        public string? Description { get; set; }
        public bool Status { get; set; }
        [Timestamp]
        public byte[] RecordVersion { get; set; } = Array.Empty<byte>();
        public required bool IsDeleted { get; set; }
        [MaxLength(50)]
        public required string CreatedBy { get; set; }
        public required DateTime CreatedDate { get; set; }
        [MaxLength(50)]
        public string? UpdatedBy { get; set; }
        public required DateTime? UpdatedDate { get; set; }
        public virtual Location? Location { get; set; }
        public virtual CategoryMaster? Category { get; set; }
    }
}
