using Aurora.AdministrationService.Domain.V1.Entities.Practitioners;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace Aurora.AdministrationService.Domain.V1.Entities
{
    [Table(name: "ExperienceDetails", Schema = "dbo")]

    public class ExperienceDetails : IAuditableEntity, IDeletableEntity
    {
        [Key]
        [DatabaseGenerated(DatabaseGeneratedOption.Identity)]
        public required long Id { get; set; }
        public required long ManageDoctorProfileID { get; set; }
        [MaxLength(100)]
        public string? Title { get; set; }
        [MaxLength(100)]
        public string? Designation { get; set; }
        [MaxLength(100)]
        public string? Location { get; set; }
        public bool? Status { get; set; }
        public bool? CurrentlyWorkingHere { get; set; }
        [MaxLength(100)]
        public string? Organization { get; set; }
        public DateTime? JobDurationFrom { get; set; }
        public DateTime? JobDurationTo { get; set; }
        public required bool IsDeleted { get; set; }
        [Timestamp]
        public byte[] RecordVersion { get; set; } = Array.Empty<byte>();
        public required DateTime CreatedDate { get; set; }
        [MaxLength(50)]
        public string? CreatedBy { get; set; }
        public DateTime? UpdatedDate { get; set; }
        [MaxLength(50)]
        public string? UpdatedBy { get; set; }
        public virtual ManageDoctorProfile? ManageDoctorProfile { get; set; }
    }
}
