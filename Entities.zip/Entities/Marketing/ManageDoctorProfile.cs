using Aurora.AdministrationService.Domain.V1.Entities.Practitioners;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace Aurora.AdministrationService.Domain.V1.Entities
{
    [Table(name: "ManageDoctorProfile", Schema = "dbo")]

    public class ManageDoctorProfile : IAuditableEntity, IDeletableEntity
    {
        [Key]
        [DatabaseGenerated(DatabaseGeneratedOption.Identity)]
        public required long Id { get; set; }
        public required long PractitionerID { get; set; }
        [MaxLength(50)]
        public string? Title { get; set; }
        [MaxLength(50)]
        public required string FirstName { get; set; }
        [MaxLength(50)]
        public string? MiddleName { get; set; }
        [MaxLength(50)]
        public required string LastName { get; set; }
        public int? GenderID { get; set; }
        [MaxLength(100)]
        public string? Designation { get; set; }
        [MaxLength(255)]
        public string? Description { get; set; }
        [MaxLength(50)]
        public string? Rank { get; set; }
        public bool? Status { get; set; }
        [Timestamp]
        public byte[] RecordVersion { get; set; } = Array.Empty<byte>();
        public required bool IsDeleted { get; set; }
        [MaxLength(50)]
        public string? CreatedBy { get; set; }
        public required DateTime CreatedDate { get; set; }
        [MaxLength(50)]
        public string? UpdatedBy { get; set; }
        public DateTime? UpdatedDate { get; set; }
        public virtual Practitioner? Practitioner { get; set; }

        public virtual ICollection<ManageDoctorSpeciality> ManageDoctorSpeciality { get; set; } = new List<ManageDoctorSpeciality>();
        public virtual ICollection<ManageDoctorLocation> ManageDoctorLocation { get; set; } = new List<ManageDoctorLocation>();
        public virtual ICollection<EducationalQualification> EducationalQualification { get; set; } = new List<EducationalQualification>();
        public virtual ICollection<ExperienceDetails> ExperienceDetails { get; set; } = new List<ExperienceDetails>();
        public virtual ICollection<Interest> Interest { get; set; } = new List<Interest>();
        public virtual ICollection<Publications> Publications { get; set; } = new List<Publications>();
        public virtual ICollection<Section> Section { get; set; } = new List<Section>();
        public virtual ICollection<ManageRank> ManageRank { get; set; } = new List<ManageRank>();
    }
}
