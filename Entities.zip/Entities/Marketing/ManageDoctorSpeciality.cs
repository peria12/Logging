using Aurora.AdministrationService.Domain.V1.Entities.Practitioners;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace Aurora.AdministrationService.Domain.V1.Entities
{
    [Table(name: "ManageDoctorSpeciality", Schema = "dbo")]

    public class ManageDoctorSpeciality : IAuditableEntity, IDeletableEntity
    {
        [Key]
        [DatabaseGenerated(DatabaseGeneratedOption.Identity)]
        public required long Id { get; set; }
        [MaxLength(50)]
        public required string Speciality { get; set; }
        public required long ManageDoctorProfileID { get; set; }
        public required bool IsDeleted { get; set; }
        public bool? Status { get; set; }
        [MaxLength(50)]
        public string? CreatedBy { get; set; }
        public required DateTime CreatedDate { get; set; }
        [MaxLength(50)]
        public string? UpdatedBy { get; set; }
        public DateTime? UpdatedDate { get; set; }
        [Timestamp]
        public byte[] RecordVersion { get; set; } = Array.Empty<byte>();
        public virtual ManageDoctorProfile? ManageDoctorProfile { get; set; }
    }
}
