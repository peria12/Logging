using Aurora.AdministrationService.Domain.V1.Entities.Contents;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace Aurora.AdministrationService.Domain.V1.Entities
{
    [Table(name: "FAQ", Schema = "dbo")]

    public class FAQ : IAuditableEntity, IDeletableEntity
    {
        public required long ID { get; set; }
        [MaxLength(20)]
        public string? UniqueID { get; set; }
        public required bool Status { get; set; }
        [MaxLength(20)]
        public required string Platforms { get; set; }
        [Timestamp]
        public byte[] RecordVersion { get; set; } = Array.Empty<byte>();
        public required bool IsDeleted { get; set; }
        [MaxLength(50)]
        public string? CreatedBy { get; set; }
        public required DateTime CreatedDate { get; set; }
        [MaxLength(50)]
        public string? UpdatedBy { get; set; }
        public DateTime? UpdatedDate { get; set; }
        public virtual ICollection<FAQLanguage> FAQLanguages { get; set; } = new List<FAQLanguage>();
        public virtual ICollection<FAQUserTypes> FAQUserTypes { get; set; } = new List<FAQUserTypes>();
    }
}
