using Aurora.AdministrationService.Domain.V1.Entities.Contents;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace Aurora.AdministrationService.Domain.V1.Entities
{
    [Table(name: "FAQLanguage", Schema = "dbo")]

    public class FAQLanguage : IAuditableEntity, IDeletableEntity
    {
        [Key]
        [DatabaseGenerated(DatabaseGeneratedOption.Identity)]
        public required long Id { get; set; }
        public required long FAQID { get; set; }
        public required bool Status { get; set; }
        [MaxLength(50)]
        public string? Header { get; set; }
        public int? LanguageID { get; set; }
        [MaxLength(100)]
        public string? Description { get; set; }
        [Timestamp]
        public byte[] RecordVersion { get; set; } = Array.Empty<byte>();
        public required bool IsDeleted { get; set; }
        [MaxLength(50)]
        public string? CreatedBy { get; set; }
        public required DateTime CreatedDate { get; set; }
        [MaxLength(50)]
        public string? UpdatedBy { get; set; }
        public DateTime? UpdatedDate { get; set; }
        public virtual FAQ? FAQ { get; set; }
    }
}
