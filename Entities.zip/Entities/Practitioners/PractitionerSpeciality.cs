using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace Aurora.AdministrationService.Domain.V1.Entities.Practitioners
{
    [Table(name: "PractitionerSpeciality", Schema = "dbo")]

    public class PractitionerSpeciality : IAuditableEntity, IDeletableEntity
    {
        [Key]
        [DatabaseGenerated(DatabaseGeneratedOption.Identity)]
        public long Id { get; set; }
        public long PractitionerID { get; set; }
        [MaxLength(50)]
        public string Specialty { get; set; }
        public required bool Status { get; set; }
        public int LocationID { get; set; }
        [Timestamp]
        public byte[] RecordVersion { get; set; } = Array.Empty<byte>();
        public required bool IsDeleted { get; set; }
        [MaxLength(50)]
        public required string CreatedBy { get; set; }
        public required DateTime CreatedDate { get; set; }
        public DateTime? UpdatedDate { get; set; }
        [MaxLength(50)]
        public required string UpdatedBy { get; set; }
        public virtual Practitioner? Practitioner { get; set; }
    }
}
