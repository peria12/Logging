using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace Aurora.AdministrationService.Domain.V1.Entities.Practitioners
{
    [Table(name: "PractitionerNames", Schema = "dbo")]

    public class PractitionerNames : AuditMetadata, IAuditableEntity, IDeletableEntity
    {
        [Key]
        [DatabaseGenerated(DatabaseGeneratedOption.Identity)]
        public long Id { get; set; }
        public required long PractitionerID { get; set; }
        [MaxLength(20)]
        public required string Use { get; set; }
        [MaxLength(50)]
        public string FamilyName { get; set; }
        [MaxLength(50)]
        public string GivenName { get; set; }
        [MaxLength(50)]
        public string MiddleName { get; set; }
        [MaxLength(20)]
        public string Prefix { get; set; }
        [MaxLength(20)]
        public string Suffix { get; set; }
        [MaxLength(20)]
        public string Language { get; set; }
        public DateTime PeriodStart { get; set; }
        public DateTime PeriodEnd { get; set; }
        public virtual Practitioner? Practitioner { get; set; }
    }
}
