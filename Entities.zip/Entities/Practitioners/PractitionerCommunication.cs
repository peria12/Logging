using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace Aurora.AdministrationService.Domain.V1.Entities.Practitioners
{
    [Table(name: "PractitionerCommunication", Schema = "dbo")]

    public class PractitionerCommunication : AuditMetadata, IAuditableEntity, IDeletableEntity
    {
        [Key]
        [DatabaseGenerated(DatabaseGeneratedOption.Identity)]
        public long Id { get; set; }
        public required long PractitionerID { get; set; }
        [MaxLength(20)]
        public string Language { get; set; }
        public bool Preferred { get; set; }        
        public virtual Practitioner? Practitioner { get; set; }
    }
}
