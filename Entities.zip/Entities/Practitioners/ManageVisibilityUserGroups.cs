﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Microsoft.EntityFrameworkCore;

namespace Aurora.AdministrationService.Domain.V1.Entities.Practitioners
{
    [Table(name: "ManageVisibilityUserGroups", Schema = "dbo")]
    [Comment("It will be the table which will store the Doctors Visibility  User Groups")]
    public class ManageVisibilityUserGroups: IAuditableEntity, IDeletableEntity
    {
        [Key]
        [DatabaseGenerated(DatabaseGeneratedOption.Identity)]
        [Comment("Unique identifier for the record.")]
        public long ID { get; set; } 

        [Comment("Foreign key referencing the ManageVisibility table.")]
        public required long ManageVisibilityID { get; set; }
        [MaxLength(20)]
        [Comment("Specifies the user group(s) that have access to the record.")]
        public required string UserGroups { get; set; }
        [Comment("Timestamp for tracking changes to the record.")]
        public byte[] RecordVersion { get; set; } = Array.Empty<byte>();
        [Comment("IsDelete is flag for soft delete")]
        public required bool IsDeleted { get; set; }
        [MaxLength(50)]
        [Comment("User who created the record.")]
        public string? CreatedBy { get; set; }
        [Comment("Date and time when the record was created.")]
        public required DateTime CreatedDate { get; set; }
        [MaxLength(50)]
        [Comment("User who created the record.")]
        public string? UpdatedBy { get; set; }
        [Comment("Date and time when the record was last updated.")]
        public DateTime? UpdatedDate { get; set; }
        public virtual ManageVisibility? ManageVisibility { get; set; } 

    }
}
