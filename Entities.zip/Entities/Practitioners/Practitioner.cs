using Aurora.AdministrationService.Domain.V1.Entities.Contents;
using Aurora.AdministrationService.Domain.V1.Entities.PractitionerNotifications;
using Aurora.AdministrationService.Domain.V1.Entities.PractitionerRoles;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace Aurora.AdministrationService.Domain.V1.Entities.Practitioners
{
    [Table(name: "Practitioner", Schema = "dbo")]

    public class Practitioner : IAuditableEntity, IDeletableEntity
    {
        [Key]
        [DatabaseGenerated(DatabaseGeneratedOption.Identity)]
        public long Id { get; set; }
        [MaxLength(20)]
        public required string ResourceID { get; set; }
        public required bool Status { get; set; }
        [MaxLength(20)]
        public string? Gender { get; set; }
        public DateTime BirthDate { get; set; }
        [MaxLength(20)]
        public string? Source { get; set; }
        [Timestamp]
        public byte[] RecordVersion { get; set; } = Array.Empty<byte>();
        public required bool IsDeleted { get; set; }
        [MaxLength(50)]
        public string? CreatedBy { get; set; }
        public required DateTime CreatedDate { get; set; }
        [MaxLength(50)]
        public string? UpdatedBy { get; set; }
        public DateTime? UpdatedDate { get; set; }
        public virtual ICollection<ManageDoctorProfile> ManageDoctorProfile { get; set; } = new List<ManageDoctorProfile>();
        public virtual ICollection<PractitionerAddresses> PractitionerAddresses { get; set; } = new List<PractitionerAddresses>();
        public virtual ICollection<PractitionerCommunication> PractitionerCommunication { get; set; } = new List<PractitionerCommunication>();
        public virtual ICollection<PractitionerIdentifier> PractitionerIdentifier { get; set; } = new List<PractitionerIdentifier>();
        public virtual ICollection<PractitionerLocation> PractitionerLocation { get; set; } = new List<PractitionerLocation>();
        public virtual ICollection<PractitionerNames> PractitionerNames { get; set; } = new List<PractitionerNames>();
        public virtual ICollection<PractitionerPhotos> PractitionerPhotos { get; set; } = new List<PractitionerPhotos>();
        public virtual ICollection<PractitionerQualification> PractitionerQualification { get; set; } = new List<PractitionerQualification>();
        public virtual ICollection<PractitionerSpeciality> PractitionerSpeciality { get; set; } = new List<PractitionerSpeciality>();
        public virtual ICollection<PractitionerTelecom> PractitionerTelecom { get; set; } = new List<PractitionerTelecom>();
        public virtual ICollection<PractitionerRole> PractitionerRole { get; set; } = new List<PractitionerRole>();
        public virtual ICollection<PractitionerNotAvailable> PractitionerNotAvailable { get; set; } = new List<PractitionerNotAvailable>();
        //public virtual ICollection<PractitionerNotification> PractitionerNotification { get; set; } = new List<PractitionerNotification>();
        public virtual ICollection<ManageVisibility> ManageVisibility { get; set; } = new List<ManageVisibility>();

    }
}
