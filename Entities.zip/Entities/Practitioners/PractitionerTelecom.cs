using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace Aurora.AdministrationService.Domain.V1.Entities.Practitioners
{
    [Table(name: "PractitionerTelecom", Schema = "dbo")]

    public class PractitionerTelecom : AuditMetadata, IAuditableEntity, IDeletableEntity
    {
        [Key]
        [DatabaseGenerated(DatabaseGeneratedOption.Identity)]
        public long Id { get; set; }
        public required long PractitionerID { get; set; }
        [MaxLength(20)]
        public required string System { get; set; }
        [MaxLength(100)]
        public required string Value { get; set; }
        [MaxLength(20)]
        public required string Use { get; set; }
        public int Rank { get; set; }
        public DateTime PeriodStart { get; set; }
        public DateTime PeriodEnd { get; set; }
        public virtual Practitioner? Practitioner { get; set; }
    }
}
