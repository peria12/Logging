using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace Aurora.AdministrationService.Domain.V1.Entities.Practitioners
{
    [Table(name: "PractitionerPhotos", Schema = "dbo")]

    public class PractitionerPhotos : IAuditableEntity, IDeletableEntity
    {
        [Key]
        [DatabaseGenerated(DatabaseGeneratedOption.Identity)]
        public long Id { get; set; }
        public required long PractitionerID { get; set; }
        [MaxLength(30)]
        public string ContentType { get; set; }
        [MaxLength(600)]
        public byte[] Data { get; set; }
        [MaxLength(255)]
        public string URL { get; set; }
        [MaxLength(20)]
        public string Size { get; set; }
        [MaxLength(600)]
        public string Hash { get; set; }
        [MaxLength(20)]
        public string Title { get; set; }
        public required bool Status { get; set; }
        public DateTime CreationDate { get; set; }
        [Timestamp]
        public byte[] RecordVersion { get; set; } = Array.Empty<byte>();
        public required bool IsDeleted { get; set; }
        [MaxLength(50)]
        public required string CreatedBy { get; set; }
        public required DateTime CreatedDate { get; set; }
        [MaxLength(50)]
        public string UpdatedBy { get; set; }
        public DateTime? UpdatedDate { get; set; }
        public virtual Practitioner? Practitioner { get; set; }
    }
}
