﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using Aurora.AdministrationService.Domain.V1.Entities.Locations;
using Microsoft.EntityFrameworkCore;

namespace Aurora.AdministrationService.Domain.V1.Entities.Practitioners
{
    [Table(name: "ManageVisibility", Schema = "dbo")]
    [Comment("It will be the table which will store the Doctors Visibility.")]
    public class ManageVisibility: IAuditableEntity, IDeletableEntity
    {
        [Key]
        [DatabaseGenerated(DatabaseGeneratedOption.Identity)]
        [Comment("Unique identifier for the visibility record.")]
        public long ID { get; set; } 
        [MaxLength(20)]
        [Comment("The location associated with the visibility settings.")]
        public required string LocationID { get; set; } 
        [MaxLength(20)]
        [Comment("Identifier of the practitioner whose visibility is being managed.")]
        public required string PractitionerID { get; set; }
        [Comment("Timestamp for tracking changes to the record.")]
        public byte[] RecordVersion { get; set; } = Array.Empty<byte>();
        [Comment("IsDelete is flag for soft delete")]
        public required bool IsDeleted { get; set; }
        [MaxLength(50)]
        [Comment("User who created the record.")]
        public string? CreatedBy { get; set; }
        [Comment("Date and time when the record was created.")]
        public required DateTime CreatedDate { get; set; }
        [MaxLength(50)]
        [Comment("User who created the record.")]
        public string? UpdatedBy { get; set; }
        [Comment("Date and time when the record was last updated.")]
        public DateTime? UpdatedDate { get; set; }

        public virtual Practitioner? Practitioner { get; set; }
        public virtual Location? Location { get; set; }
        public virtual ICollection<ManageVisibilityUserGroups> ManageVisibilityUserGroups { get; set; } = new List<ManageVisibilityUserGroups>();

    }
}
