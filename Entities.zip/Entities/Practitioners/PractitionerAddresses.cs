using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace Aurora.AdministrationService.Domain.V1.Entities.Practitioners
{
    [Table(name: "PractitionerAddresses", Schema = "dbo")]

    public class PractitionerAddresses : AuditMetadata, IAuditableEntity, IDeletableEntity
    {
        [Key]
        [DatabaseGenerated(DatabaseGeneratedOption.Identity)]
        public long Id { get; set; }
        [MaxLength(100)]
        public string Line1 { get; set; }
        public required long PractitionerID { get; set; }

        [MaxLength(20)]
        public required string Use { get; set; }

        [MaxLength(100)]
        public string Line4 { get; set; }
       
        [MaxLength(100)]
        public string Line2 { get; set; }

        [MaxLength(100)]
        public string Line3 { get; set; }
        
        public DateTime PeriodStart { get; set; }
        public DateTime PeriodEnd { get; set; }

        [MaxLength(20)]
        public string Type { get; set; }

        [MaxLength(50)]
        public string PostalCode { get; set; }

        [MaxLength(50)]
        public string District { get; set; }
       
        [MaxLength(50)]
        public string Country { get; set; }

        [MaxLength(50)]
        public string State { get; set; }

        [MaxLength(50)]
        public string City { get; set; }
      
       
        public virtual Practitioner? Practitioner { get; set; }
    }
}
