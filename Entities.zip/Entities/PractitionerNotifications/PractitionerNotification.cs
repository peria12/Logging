using Aurora.AdministrationService.Domain.V1.Entities.Practitioners;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace Aurora.AdministrationService.Domain.V1.Entities.PractitionerNotifications
{
    [Table(name: "PractitionerNotification", Schema = "dbo")]

    public class PractitionerNotification : IAuditableEntity, IDeletableEntity
    {
        [Key]
        [DatabaseGenerated(DatabaseGeneratedOption.Identity)]
        public Guid Id { get; set; }
        public Guid PractitionerID { get; set; }
        [MaxLength(20)]
        public string PractitionerNotificationType { get; set; }
        [MaxLength(50)]
        public string PractitionerNotificationTitle { get; set; }
        [MaxLength(100)]
        public string PractitionerNotificationAlertsText { get; set; }
        public DateTime PractitionerNotificationAlertDateTime { get; set; }
        public required bool IsRead { get; set; }
        [Timestamp]
        public byte[] RecordVersion { get; set; } = Array.Empty<byte>();
        public required bool IsDeleted { get; set; }
        [MaxLength(50)]
        public required string CreatedBy { get; set; }
        public required DateTime CreatedDate { get; set; }
        [MaxLength(50)]
        public string UpdatedBy { get; set; }
        public DateTime? UpdatedDate { get; set; }
        //public virtual Practitioner? Practitioner { get; set; }
    }
}
