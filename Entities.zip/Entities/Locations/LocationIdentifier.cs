using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace Aurora.AdministrationService.Domain.V1.Entities.Locations
{
    [Table(name: "LocationIdentifier", Schema = "dbo")]

    public class LocationIdentifier : IAuditableEntity, IDeletableEntity
    {
        [Key]
        [DatabaseGenerated(DatabaseGeneratedOption.Identity)]
        public long Id { get; set; }
        public required long LocationID { get; set; }
        [MaxLength(20)]
        public required string System { get; set; }
        [MaxLength(100)]
        public required string value { get; set; }
        [MaxLength(20)]
        public string IdentifierUse { get; set; }
        [MaxLength(20)]
        public string IdentifierType { get; set; }
        public DateTime PeriodStart { get; set; }
        public DateTime PeriodEnd { get; set; }
        [MaxLength(20)]
        public string Assigner { get; set; }
        public required bool Status { get; set; }
        [Timestamp]
        public byte[] RecordVersion { get; set; } = Array.Empty<byte>();
        public required bool IsDeleted { get; set; }
        [MaxLength(50)]
        public required string CreatedBy { get; set; }
        public required DateTime CreatedDate { get; set; }
        [MaxLength(50)]
        public string UpdatedBy { get; set; }
        public DateTime? UpdatedDate { get; set; }
        public virtual Location? Location { get; set; }
    }
}
