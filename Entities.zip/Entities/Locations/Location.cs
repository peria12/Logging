using Aurora.AdministrationService.Domain.V1.Entities.HealthcareService;
using Aurora.AdministrationService.Domain.V1.Entities.InsurancePanels;
using Aurora.AdministrationService.Domain.V1.Entities.Marketings;
using Aurora.AdministrationService.Domain.V1.Entities.PractitionerRoles;
using Aurora.AdministrationService.Domain.V1.Entities.Practitioners;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace Aurora.AdministrationService.Domain.V1.Entities.Locations
{
    [Table(name: "Location", Schema = "dbo")]

    public class Location : IAuditableEntity
    {
        [Key]
        [DatabaseGenerated(DatabaseGeneratedOption.Identity)]
        public long Id { get; set; }
        [MaxLength(20)]
        public required string ResourceID { get; set; }

        public required bool Status { get; set; }
        [MaxLength(20)]
        public string? OperationalStatus { get; set; }
        [MaxLength(50)]
        public required string Name { get; set; }
        [MaxLength(50)]
        public string? Alias { get; set; }
        [MaxLength(1000)]
        public string? Description { get; set; }
        [MaxLength(20)]
        public string? Mode { get; set; }
        [Column(TypeName = "decimal(10, 2)")]

        public decimal? Longitude { get; set; }
        [Column(TypeName = "decimal(10, 2)")]
        public decimal? Latitude { get; set; }
        [Column(TypeName = "decimal(10, 2)")]
        public decimal? Altitude { get; set; }
        [MaxLength(20)]
        public string? PhysicalType { get; set; }
        public Guid ManagingOrganization { get; set; }
        [MaxLength(20)]
        public string? PartOf { get; set; }
        [MaxLength(50)]
        public string? AvailabilityExceptions { get; set; }
        [MaxLength(20)]
        public string? Source { get; set; }
        [MaxLength(255)]
        public string? URL { get; set; }
        [Timestamp]
        public byte[] RecordVersion { get; set; } = Array.Empty<byte>();
        public bool? IsDeleted { get; set; }
        [MaxLength(50)]
        public required string CreatedBy { get; set; }
        public required DateTime CreatedDate { get; set; }
        [MaxLength(50)]
        public string? UpdatedBy { get; set; }
        public DateTime? UpdatedDate { get; set; }
        public virtual ICollection<LocationTelecom> LocationTelecom { get; set; } = new List<LocationTelecom>();
        public virtual ICollection<LocationAddress> LocationAddress { get; set; } = new List<LocationAddress>();
        public virtual ICollection<LocationHoursOfOperation> LocationHoursOfOperation { get; set; } = new List<LocationHoursOfOperation>();
        public virtual ICollection<LocationType> LocationType { get; set; } = new List<LocationType>();
        public virtual ICollection<LocationIdentifier> LocationIdentifier { get; set; } = new List<LocationIdentifier>();
        public virtual ICollection<LocationImage> LocationImage { get; set; } = new List<LocationImage>();
        public virtual ICollection<PractitionerRoleLocation> PractitionerRoleLocation { get; set; } = new List<PractitionerRoleLocation>();
        public virtual ICollection<WhatsHappening> WhatsHappening { get; set; } = new List<WhatsHappening>();
        public virtual ICollection<HealthcareServices> HealthcareServices { get; set; } = new List<HealthcareServices>();
        public virtual ICollection<ManageVisibility> ManageVisibility  { get; set; } = new List<ManageVisibility>();
        public virtual ICollection<PractitionerRole> PractitionerRole { get; set; } = new List<PractitionerRole>();


    }
}
