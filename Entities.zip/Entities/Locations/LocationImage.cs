using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace Aurora.AdministrationService.Domain.V1.Entities.Locations
{
    [Table(name: "LocationImage", Schema = "dbo")]

    public class LocationImage : IAuditableEntity, IDeletableEntity
    {
        public required long Id { get; set; }
        public required long LocationID { get; set; }
        [MaxLength(50)]
        public string? Category { get; set; }
        [MaxLength(50)]
        public string? FloorName { get; set; }
        [MaxLength(50)]
        public string? BuildingName { get; set; }
        [MaxLength(255)]
        public string? URL { get; set; }
        [Timestamp]
        public byte[] RecordVersion { get; set; } = Array.Empty<byte>();
        public bool IsDeleted { get; set; }
        [MaxLength(50)]
        public string CreatedBy { get; set; }
        public DateTime CreatedDate { get; set; }
        [MaxLength(50)]
        public string UpdatedBy { get; set; }
        public DateTime? UpdatedDate { get; set; }
        public virtual Location? Location { get; set; }
    }
}
