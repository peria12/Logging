﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations.Schema;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Aurora.AdministrationService.Domain.V1.Entities.Languade
{
    public class LanguageV1 : IAuditableEntity, IDeletableEntity
    {
        [Key]
        [DatabaseGenerated(DatabaseGeneratedOption.Identity)]
        public int Id { get; set; }

        [Required]
        [StringLength(10)]
        public string Code { get; set; }

        [Required]
        [StringLength(50)]
        public string Display { get; set; }

        [Required]
        [StringLength(300)]
        public string Definition { get; set; }

        [Required]
        public int OtherDescTypeID { get; set; }

        [Required]
        [StringLength(25)]
        public string Source { get; set; }

        /// <summary>
        /// This property is mapped to the SQL Server timestamp (rowversion).
        /// </summary>
        [Timestamp]
        public byte[] RecordVersion { get; set; }

        [Required]
        public bool IsDeleted { get; set; }

        [Required]
        [StringLength(50)]
        public string CreatedBy { get; set; }

        [Required]
        public DateTime CreatedDate { get; set; }

        [Required]
        [StringLength(50)]
        public string UpdatedBy { get; set; }

        public DateTime? UpdatedDate { get; set; }
    }
}
