using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace Aurora.AdministrationService.Domain.V1.Entities.ServiceChargeMasters
{
    [Table(name: "ServiceChargeMaster", Schema = "dbo")]

    public class ServiceChargeMaster : IAuditableEntity, IDeletableEntity
    {
        [Key]
        [DatabaseGenerated(DatabaseGeneratedOption.Identity)]
        public long ID { get; set; }
        [MaxLength(50)]
        public string? MasterType { get; set; }
        [MaxLength(50)]
        public required string ItemCode { get; set; }
        [MaxLength(255)]
        public string? ItemDescription { get; set; }
        [MaxLength(50)]
        public string? ItemTypeCode { get; set; }
        [MaxLength(255)]
        public string? ItemTypeDescription { get; set; }
        [MaxLength(20)]
        public required string TestCode { get; set; }
        [MaxLength(255)]
        public string? TestDescription { get; set; }
        [MaxLength(50)]
        public string? ServiceType { get; set; }
        [MaxLength(100)]
        public string? Category { get; set; }
        [MaxLength(100)]
        public string? Department { get; set; }
        public int? TurnAroundTime { get; set; }
        public bool? Restricted { get; set; }
        [MaxLength(200)]
        public string? TestMethodAvailable { get; set; }
        [MaxLength(20)]
        public string? FacilityCode { get; set; }
        [Timestamp]
        public required byte[] RecordVersion { get; set; } = Array.Empty<byte>();
        public required bool IsDeleted { get; set; }
        [MaxLength(50)]
        public string? CreatedBy { get; set; }
        public required DateTime CreatedDate { get; set; }
        [MaxLength(50)]
        public string? UpdatedBy { get; set; }
        public DateTime? UpdatedDate { get; set; }
    }
}
