using Aurora.AdministrationService.Domain.V1.Entities.Contents;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace Aurora.AdministrationService.Domain.V1.Entities.PaymentGateways
{
    [Table(name: "PaymentGatewayConfig", Schema = "dbo")]

    public class PaymentGatewayConfig : IAuditableEntity, IDeletableEntity
    {
        [Key]
        [DatabaseGenerated(DatabaseGeneratedOption.Identity)]
        public long Id { get; set; }
        public required long PaymentGatewayID { get; set; }
        [MaxLength(50)]
        public required string PaymentGatewayName { get; set; }
        [MaxLength(255)]
        public string URL { get; set; }
        public required bool UseCredentials { get; set; }
        
        [MaxLength(20)]
        public string UserID { get; set; }
        [MaxLength(20)]
        public string Password { get; set; }
        [MaxLength(50)]
        public string APIKey { get; set; }
        [Timestamp]
        public byte[] RecordVersion { get; set; } = Array.Empty<byte>();
        public required bool IsDeleted { get; set; }
        [MaxLength(50)]
        public required string CreatedBy { get; set; }
        public required DateTime CreatedDate { get; set; }
        [MaxLength(50)]
        public string UpdatedBy { get; set; }
        public DateTime? UpdatedDate { get; set; }
        public virtual PaymentGateway? PaymentGateway { get; set; }
    }
}
