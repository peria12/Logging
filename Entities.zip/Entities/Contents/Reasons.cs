using Aurora.AdministrationService.Domain.V1.Entities.HealthcareService;
using Microsoft.EntityFrameworkCore;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace Aurora.AdministrationService.Domain.V1.Entities.Contents
{
    [Table(name: "Reasons", Schema = "dbo")]
    [Comment("This table stores information about different reasons related to a certain context. Each reason is associated with a specific content and categorized by a reason type.\r\n")]
public class Reasons : IAuditableEntity, IDeletableEntity
{
        [Key]
        [DatabaseGenerated(DatabaseGeneratedOption.Identity)]
        [Comment("A unique identifier for each reason entry. This serves as the primary key of the table.")]
        public long Id { get; set; }
        [MaxLength(10)]
        [Comment("References the content associated with the reason. It links to another table containing content details.")]
        public required long ContentID { get; set; }
        [MaxLength(50)]
        [Comment("Describes the type or category of the reason (e.g., \"Complaint\", \"Suggestion\").")]
        public  string? ResonType { get; set; }
        [Comment("status of the record (e.g., Active, Inactive, Pending).")]
        public required bool Status { get; set; }
        [Timestamp]
        [Comment("This column stores a binary value that changes every time the row is updated. It's often used for concurrency checking to determine if the data in a row has been modified ")]
        public required byte[] RecordVersion { get; set; } = Array.Empty<byte>();
        [Comment("IsDelete is flag for soft delete")]
        public required bool IsDeleted { get; set; }
        [MaxLength(50)]
        [Comment("The user who created the content record.")]
        public string? CreatedBy { get; set; }
        [Comment("The date and time when the content record was created.")]
        public required DateTime CreatedDate { get; set; }
        [MaxLength(50)]
        [Comment("The user who updated the content record.")]
        public string? UpdatedBy { get; set; }
        [Comment("The date and time when the content record was updated.")]
        public DateTime? UpdatedDate { get; set; }
        public virtual Content? Content { get; set; }
    }
}
