﻿using Microsoft.EntityFrameworkCore;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace Aurora.AdministrationService.Domain.V1.Entities.Contents
{
    [Table(name: "ContentPlatform", Schema = "dbo")]
    [Comment("The ContentPlatform table stores information about  platform associations with respective content Id ")]

   public class ContentPlatform: IAuditableEntity, IDeletableEntity
    {
        [Key]
        [DatabaseGenerated(DatabaseGeneratedOption.Identity)]
        public long ID { get; set; }
        [Comment("References the Id of the content module ")]
        public required long ContentID { get; set; }
        [MaxLength(20)]
        [Comment(" ID of the platform associated with the content (e.g., web, mobile).")]
        public required string PlatformsID { get; set; }
        [Timestamp]
        [Comment("System-generated version of the record for concurrency control.")]
        public required byte[] RecordVersion { get; set; } = Array.Empty<byte>();
        [Comment("Indicates if the record is deleted (0 = No, 1 = Yes).")]
        public required bool IsDeleted { get; set; }
        [MaxLength(50)]
        [Comment("The user who created the record.")]
        public string? CreatedBy { get; set; }
        [Comment("The date and time when the record was created.")]
        public required DateTime CreatedDate { get; set; }
        [MaxLength(50)]
        [Comment("The user who last updated the record.")]
        public string? UpdatedBy { get; set; }
        [Comment("The date and time when the record was last updated.")]
        public DateTime? UpdatedDate { get; set; }
        [ForeignKey("ContentID")]
        public virtual Content? Content { get; set; }
    }
}
