using Aurora.AdministrationService.Domain.V1.Entities.HealthcareService;
using Microsoft.EntityFrameworkCore;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace Aurora.AdministrationService.Domain.V1.Entities.Contents
{
    [Table(name: "Content", Schema = "dbo")]
    [Comment("The Content table stores information about different content modules and their platform associations, managing details used across various modules.\r\n\r\n ")]

    public class Content : IAuditableEntity, IDeletableEntity
    {
        [Key]
        [DatabaseGenerated(DatabaseGeneratedOption.Identity)]
        [Comment("Unique identifier for each content entry.")]
        public required long Id { get; set; }
        [MaxLength(100)]
        [Comment("Name of the content module or type (e.g., \"Articles\", \"Videos\").")]
        public string? Module { get; set; }
        [MaxLength(255)]
        [Comment("The header or title for the content item.")]
        public string? Header { get; set; }
        
        [Comment("status of the record (e.g., Active, Inactive, Pending).")]
        public required bool Status { get; set; }
        [Timestamp]
        [Comment("Version of the record, used for concurrency control.  This column stores a binary value that changes every time the row is updated. It's often used for concurrency checking to determine if the data in a row has been modified since it was last read\r\n\r\n")]
        public required byte[] RecordVersion { get; set; } = Array.Empty<byte>();
        [Comment("IsDelete is flag for soft delete")]
        public required bool IsDeleted { get; set; }
        [MaxLength(50)]
        [Comment("The user who created the content record.")]
        public string? CreatedBy { get; set; }
        [Comment("The date and time when the content record was created.")]
        public required DateTime CreatedDate { get; set; }
        [MaxLength(50)]
        [Comment("The user who updated the content record.")]
        public string? UpdatedBy { get; set; }
        [Comment("The date and time when the content record was updated.")]
        public DateTime? UpdatedDate { get; set; }

        public virtual List<Reasons> Reasons { get; set; } = new List<Reasons>();
        public ICollection<ContentPlatform> ContentPlatform { get; set; } = new List<ContentPlatform>();

    }
}
