﻿using Aurora.AdministrationService.CrossCutting.Constants;
using Aurora.AdministrationService.Infrastructure;
using Microsoft.Extensions.Configuration;
using Moq;

namespace Aurora.AdministrationService.Tests.Infrastructure
{
    public class MigrationManagerTests
    {
        [Fact]
        public async Task ApplyMigrations_ThrowsException_WhenRegionCodeIsMissing()
        {
            // Arrange
            var mockConfig = new Mock<IConfiguration>();
            string regionCode = null!;
            mockConfig.Setup(x => x["AuroraRegionCode"]).Returns(regionCode);

            var mockProvider = new Mock<IServiceProvider>();
            mockProvider.Setup(x => x.GetService(typeof(IConfiguration))).Returns(mockConfig.Object);

            // Act & Assert
            var ex = await Assert.ThrowsAsync<Exception>(() => MigrationManager.ApplyMigrations(mockProvider.Object));
            Assert.Contains("Invalid Region Code", ex.Message);
        }

        [Fact]
        public void PrepareConnectionString_ReturnsFormattedConnection_WhenKeyVaultEnabled()
        {
            // Arrange
            var region = TestConstants.RegionLanguageIN;
            var connName = $"{AppConstants.ConnectionStringPrefix}{region}{AppConstants.MicroserviceCode}ConnectionString";
            var expectedConn = "Server=test;Database=demo;";

            var mockConfigSection = new Mock<IConfigurationSection>();
            mockConfigSection.Setup(x => x.Value).Returns(expectedConn);

            var mockConfig = new Mock<IConfiguration>();
            mockConfig.Setup(x => x["isKeyVaultConfigured"]).Returns("true");
            mockConfig.Setup(x => x.GetSection(connName)).Returns(mockConfigSection.Object);

            // Act
            var result = MigrationManager.PrepareConnectionString(region, mockConfig.Object);

            // Assert
            Assert.Contains("ApplicationIntent=readwrite", result);
        }

        [Fact]
        public void PrepareConnectionString_ThrowsException_WhenConfigSectionFails()
        {
            // Arrange
            var region = TestConstants.RegionLanguageEU;
            var connectionName = $"{AppConstants.ConnectionStringPrefix}{region}{AppConstants.MicroserviceCode}ConnectionString";

            var mockConfigSection = new Mock<IConfigurationSection>();
            mockConfigSection.Setup(x => x.Value).Throws(new InvalidOperationException("Config section failure"));

            var mockConfig = new Mock<IConfiguration>();
            mockConfig.Setup(x => x.GetSection(connectionName)).Returns(mockConfigSection.Object);

            // Act
            var exception = Assert.Throws<InvalidOperationException>(() =>
                MigrationManager.PrepareConnectionString(region, mockConfig.Object)
            );

            // Assert
            Assert.True(exception.Data.Contains("MigrationManager.PrepareConnectionString()"));
            Assert.Equal("Error occured while preparing database connection",
                         exception.Data["MigrationManager.PrepareConnectionString()"]);
        }

        [Fact]
        public async Task ApplyMigrations_ShouldThrowException_WhenRegionCodeIsMissing()
        {
            // Arrange
            var mockServiceProvider = new Mock<IServiceProvider>();
            var mockConfiguration = new Mock<IConfiguration>();

            mockConfiguration.Setup(c => c["AuroraRegionCode"]).Returns((string)null);
            mockServiceProvider.Setup(sp => sp.GetService(typeof(IConfiguration))).Returns(mockConfiguration.Object);

            // Act & Assert
            var exception = await Assert.ThrowsAsync<Exception>(() =>
                MigrationManager.ApplyMigrations(mockServiceProvider.Object)
            );

            Assert.Contains("MigrationManager: Invalid Region Code :", exception.Message);
        }
    }
}
