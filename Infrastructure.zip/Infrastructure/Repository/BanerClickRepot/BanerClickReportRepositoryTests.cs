﻿using Aurora.AdministrationService.Infrastructure;
using Microsoft.EntityFrameworkCore;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using FluentAssertions;
using Aurora.AdministrationService.Infrastructure.Repository.BannerClickReports;
using Aurora.AdministrationService.API.Models.Dto.Marketing.Banner;
using Moq;
using Aurora.AdministrationService.Domain.Old.Entities;

namespace Aurora.AdministrationService.Tests.Infrastructure.Repository.BanerClickRepot
{
    public class BanerClickReportRepositoryTests
    {
        public const string DefaultUser = "Patient";

        private readonly ReadWriteDbContext _context;
        private readonly BannerClickReportRepository _repository;

        public BanerClickReportRepositoryTests()
        {
            var options = new DbContextOptionsBuilder<ReadWriteDbContext>()
               .UseInMemoryDatabase(databaseName: Guid.NewGuid().ToString().Replace("-", "_"))
               .Options;

            _context = new ReadWriteDbContext(options);
            _repository = new BannerClickReportRepository(_context);

        }
        [Fact]
        public async Task AddBannerClickReport_ShouldAddReportAndReturnOne_WhenSuccessful()
        {
            // Arrange

            var report = new BannerClickReport
            {
                Id = 1,
                PatientId = 1,
                ReportDate= DateOnly.FromDateTime(DateTime.UtcNow),
                LastModifiedBy= "Admin",
                BannerId = 101,
            };

            // Act
            var result = await _repository.AddBannerClickReport(report);

            // Assert
            result.Should().Be(1);
            _context.BannerClickReports.Should().ContainSingle(r => r.BannerId == 101);
            var addedReport = _context.BannerClickReports.First();
            addedReport.DateCreated.Should().BeCloseTo(DateTime.UtcNow, TimeSpan.FromSeconds(1));
            addedReport.LastModifiedDate.Should().BeCloseTo(DateTime.UtcNow, TimeSpan.FromSeconds(1));
        }

        [Fact]
        public async Task AddBannerClickReport_ShouldReturnZero_WhenExceptionOccurs()
        {
            // Act
            var result = await _repository.AddBannerClickReport(It.IsAny<BannerClickReport>());

            // Assert
            result.Should().Be(0);
        }

        [Fact]
        public async Task GetImageMaintenanceDetail_ShouldReturnMatchingRecords_WhenScreenTypesMatch()
        {

            _context.AdminImageMaintenances.AddRange(
                new AdminImageMaintenance { Id = 1, ImageType = "image", ImageName = "test1", ScreenType = "Home" },
                new AdminImageMaintenance { Id = 2, ImageType = "image", ImageName = "test2", ScreenType = "Dashboard" }
            );
            await _context.SaveChangesAsync();

            var selectedScreenTypes = new[] { "Home" };

            // Act
            var result = await _repository.GetImageMaintenanceDetail(selectedScreenTypes);

            // Assert
            result.Should().NotBeNull();
            result.Should().HaveCount(1);
            result?.First().ScreenType.Should().Be("Home");
        }

        [Fact]
        public async Task GetImageMaintenanceDetail_ShouldReturnEmptyList_WhenNoScreenTypeMatches()
        {
            _context.AdminImageMaintenances.AddRange(
                new AdminImageMaintenance { Id = 1, ImageType="image", ImageName="test1", ScreenType = "Home" },
                new AdminImageMaintenance { Id = 2, ImageType = "image", ImageName = "test2", ScreenType = "Dashboard" }
            );
            await _context.SaveChangesAsync();

            var selectedScreenTypes = new[] { "Settings" };

            // Act
            var result = await _repository.GetImageMaintenanceDetail(selectedScreenTypes);

            // Assert
            result.Should().NotBeNull();
            result.Should().BeEmpty();
        }

    }
}
