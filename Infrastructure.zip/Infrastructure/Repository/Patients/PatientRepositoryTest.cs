﻿using Aurora.AdministrationService.Infrastructure.Repository;
using Aurora.AdministrationService.Infrastructure;
using Microsoft.EntityFrameworkCore;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Aurora.AdministrationService.CrossCutting.Extensions;
using Aurora.AdministrationService.Domain.Entities;
using FluentAssertions;
using FluentAssertions.Common;
using Moq;
using Aurora.AdministrationService.Domain.Old.Entities;

namespace Aurora.AdministrationService.Tests.Infrastructure.Repository.Patients
{
    public class PatientRepositoryTest
    {
        private readonly PatientRepository _repository;
        private readonly ReadWriteDbContext _context;

        /// <summary>
        /// Initializes a new instance of the <see cref=PatientRepositoryTests"/> class.
        /// Sets up an in-memory database and the repository instance for testing.
        /// </summary>
        public PatientRepositoryTest()
        {
            // Setup in-memory database for testing
            var options = new DbContextOptionsBuilder<ReadWriteDbContext>()
                .UseInMemoryDatabase(databaseName: Guid.NewGuid().ToString())
                .Options;

            _context = new ReadWriteDbContext(options);
            _repository = new PatientRepository(_context);

        }

        [Fact]
        public async Task GetPatientsAsync_ShouldReturnPaginatedPatients()
        {
            // Arrange
            _context.PatientUsers.AddRange(
                new PatientUser { Gender = "M", Email = "t@tes.com", PhoneNumber = "0987654321", PatientId = "1",Id = "1", Name = "John Doe" },
                new PatientUser { Gender = "M", Email = "t@tes.com", PhoneNumber = "0987654321", PatientId = "123", Id = "2", Name = "Jane Doe" },
                new PatientUser { Gender = "M", Email = "t@tes.com", PhoneNumber = "0987654321", PatientId = "1234", Id = "3", Name = "Alice" }
            );
            await _context.SaveChangesAsync();

            var paginationQuery = new PaginationQuery { PageNumber = 1, PageSize = 2 };

            // Act
            var result = await _repository.GetPatientsAsync(paginationQuery);

            // Assert
            result.Should().HaveCount(2); // Should return 2 patients based on pagination
        }
        [Fact]
        public async Task AddPatientAsync_ShouldAddPatient()
        {
            var newPatient = new PatientUser { Gender = "M", Email = "t@tes.com", PhoneNumber = "0987654321", PatientId = "12345", Id = "1", Name = "John Doe" };

            // Act
            await _repository.AddPatientAsync(newPatient);

            // Assert
            var addedPatient = await _context.PatientUsers.FirstOrDefaultAsync(x=>x.Id=="1");
            addedPatient.Should().NotBeNull();
            addedPatient.Name.Should().Be("John Doe");
        }
        [Fact]
        public async Task UpdatePatient_ShouldUpdatePatient()
        {
            // Arrange
            var patient = new PatientUser { Gender = "M", Email = "t@tes.com", PhoneNumber = "0987654321", PatientId = "234", Id = "1", Name = "John Doe" };
            _context.PatientUsers.Add(patient);
            await _context.SaveChangesAsync();
            _context.ChangeTracker.Clear();
            var updatedPatient = new PatientUser { Gender = "M", Email = "t@tes.com", PhoneNumber = "0987654321", PatientId = "234", Id = "1", Name = "John Updated" };

            // Act
            var result = await _repository.UpdatePatient(updatedPatient);

            // Assert
            result.Should().Be(1); // Should return 1 for the affected rows
            var updated = await _context.PatientUsers.FirstOrDefaultAsync(x => x.Id == "1");
            updated.Should().NotBeNull();
            updated.Name.Should().Be("John Updated");
        }
        

    }
}
