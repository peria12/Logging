﻿using Aurora.AdministrationService.CrossCutting.Extensions;
using Aurora.AdministrationService.Domain.Entities;
using Aurora.AdministrationService.Domain.Old.Entities;
using Aurora.AdministrationService.Infrastructure;
using Aurora.AdministrationService.Infrastructure.Repository;
using FluentAssertions;
using Microsoft.EntityFrameworkCore;

namespace Aurora.AdministrationService.Tests.Infrastructure.Repository.Doctor
{
    /// <summary>
    /// Unit tests for <see cref="DoctorRepository"/> class.
    /// </summary>
    public class DoctorRepositoryTests
    {
        private readonly DoctorRepository _repository;
        private readonly ReadWriteDbContext _context;

        /// <summary>
        /// Initializes a new instance of the <see cref="DoctorRepositoryTests"/> class.
        /// Sets up an in-memory database and the repository instance for testing.
        /// </summary>
        public DoctorRepositoryTests()
        {
            // Setup in-memory database for testing
            var options = new DbContextOptionsBuilder<ReadWriteDbContext>()
                .UseInMemoryDatabase(databaseName: "DoctorTestDB")
                .Options;

            _context = new ReadWriteDbContext(options);
            _context.Database.EnsureDeleted();
            _context.Database.EnsureCreated();
            _repository = new DoctorRepository(_context);
        }
        #region Get Specialities repository tests

        /// <summary>
        /// Verifies that the <see cref="DoctorRepository.GetDoctors"/> method returns paginated doctors.
        /// </summary>
        [Fact]
        public async Task GetDoctors_ShouldReturnPagedDoctors()
        {
            // Arrange
            for (int i = 1; i <= 5; i++)
            {
                await _context.AdminDoctorProfiles.AddAsync(new AdminDoctorProfile { DoctorProfileId = i, FirstName = $"Doctor {i}", LastName = "Test", ImageUrl = "testImageUrl" });
            }
            await _context.SaveChangesAsync();

            var paginationQuery = new PaginationQuery { PageNumber = 1, PageSize = 3, SortString = "DoctorProfileId", SortOrder = "desc" };

            // Act
            var result = await _repository.GetDoctors(paginationQuery);

            // Assert
            result.Should().HaveCount(3); // First page should have 3 doctors
        }

        /// <summary>
        /// Verifies that the <see cref="DoctorRepository.UpdateDoctorProfileAsync"/> method updates a doctor's profile.
        /// </summary>
        /// <returns></returns>
        [Fact]
        public async Task UpdateDoctorProfileAsync_ShouldUpdateDoctor()
        {
            // Arrange
            var doctorProfile = new AdminDoctorProfile { DoctorProfileId = 902, FirstName = "Old ServiceDeliveryLocationRoleTypeCode", LastName = "Last ServiceDeliveryLocationRoleTypeCode", ImageUrl = "testImageURL" };
            await _context.AdminDoctorProfiles.AddAsync(doctorProfile);
            await _context.SaveChangesAsync();

            doctorProfile.FirstName = "Updated ServiceDeliveryLocationRoleTypeCode";

            // Act
            var result = await _repository.UpdateDoctorProfileAsync(doctorProfile);

            // Assert
            result.Should().Be(1); // One record updated
            var updatedDoctor = await _context.AdminDoctorProfiles.FindAsync(902);
            updatedDoctor?.FirstName.Should().Be("Updated ServiceDeliveryLocationRoleTypeCode");
        }

        /// <summary>
        /// Verifies that the <see cref="DoctorRepository.GetDoctorProfileByIdAsync"/> method returns a doctor when one exists.
        /// </summary>
        [Fact]
        public async Task GetDoctorProfileByIdAsync_ShouldReturnDoctor_WhenDoctorExists()
        {
            // Arrange
            var doctorProfile = new AdminDoctorProfile { DoctorProfileId = 123, FirstName = "Doctor", LastName = "LastName", ImageUrl = "testImageUrl" };
            await _context.AdminDoctorProfiles.AddAsync(doctorProfile);
            await _context.SaveChangesAsync();

            // Act
            var result = await _repository.GetDoctorProfileByIdAsync(123);

            // Assert
            result.Should().NotBeNull();
            result?.FirstName.Should().Be("Doctor");
        }

        /// <summary>
        /// Verifies that the <see cref="DoctorRepository.GetDoctorProfileByIdAsync"/> method returns null when no doctor exists.
        /// </summary>
        [Fact]
        public async Task GetDoctorProfileByIdAsync_ShouldReturnNull_WhenDoctorDoesNotExist()
        {
            // Act
            var result = await _repository.GetDoctorProfileByIdAsync(999);

            // Assert
            result.Should().BeNull();
        }

        /// <summary>
        /// Verifies that the <see cref="DoctorRepository.GetLocations"/> method retrieves all available locations.
        /// </summary>
        [Fact]
        public async Task GetLocations_ShouldReturnLocations()
        {
            // Arrange
            var locations = new List<AdminLocation>
            {
                new AdminLocation { LocationId = 18928, Name = "Location 1" },
                new AdminLocation { LocationId = 18929, Name = "Location 2" }
            };

            await _context.AdminLocations.AddRangeAsync(locations);
            await _context.SaveChangesAsync();

            // Act
            var result = await _repository.GetLocations();

            // Assert
            result.Should().Contain(l => l.Name == "Location 1");
            result.Should().Contain(l => l.Name == "Location 2");
        }

        /// <summary>
        /// Verifies that the <see cref="DoctorRepository.GetSchedulesByDoctorProfileIdAsync"/> method retrieves schedules for a specific doctor when they exist.
        /// </summary>
        [Fact]
        public async Task GetSchedulesByDoctorProfileIdAsync_ShouldReturnSchedulesForDoctor_WhenSchedulesExist()
        {
            // Arrange
            var doctorId = 100;
            var schedules = new List<AdminDoctorSchedule>
            {
                new AdminDoctorSchedule { Actor = "TestActor", DoctorProfileId = doctorId, Active = true, PlanningHorizonStart = DateTime.Now.AddDays(-1), PlanningHorizonEnd = DateTime.Now.AddDays(1) },
                new AdminDoctorSchedule { Actor = "TestActor", DoctorProfileId = doctorId, Active = true, PlanningHorizonStart = DateTime.Now.AddDays(2), PlanningHorizonEnd = DateTime.Now.AddDays(4) }
            };

            await _context.AdminDoctorSchedules.AddRangeAsync(schedules);
            await _context.SaveChangesAsync();

            // Act
            var result = await _repository.GetSchedulesByDoctorProfileIdAsync(doctorId, null, null);

            // Assert
            result.Should().HaveCount(2);
        }

        /// <summary>
        /// Verifies that the <see cref="DoctorRepository.GetSchedulesByDoctorProfileIdAsync"/> method filters schedules based on the provided date range.
        /// </summary>
        [Fact]
        public async Task GetSchedulesByDoctorProfileIdAsync_ShouldReturnFilteredSchedules_WhenDateRangeIsProvided()
        {
            // Arrange
            var doctorId = 101;
            var schedules = new List<AdminDoctorSchedule>
            {
                new AdminDoctorSchedule { Actor = "testActor", DoctorProfileId = doctorId, Active = true, PlanningHorizonStart = DateTime.Now.AddDays(100), PlanningHorizonEnd = DateTime.Now.AddDays(-60) },
                new AdminDoctorSchedule { Actor = "testActor", DoctorProfileId = doctorId, Active = true, PlanningHorizonStart = DateTime.Now.AddDays(-100), PlanningHorizonEnd = DateTime.Now.AddDays(60) }
            };

            await _context.AdminDoctorSchedules.AddRangeAsync(schedules);
            await _context.SaveChangesAsync();

            // Act
            var result = await _repository.GetSchedulesByDoctorProfileIdAsync(doctorId, DateTime.Now, DateTime.Now.AddDays(3));

            // Assert
            result.Should().HaveCount(1); // Only 1 schedule is within the date range
        }

        /// <summary>
        /// Verifies that the <see cref="DoctorRepository.GetAllDoctors"/> method retrieves all doctors with their details.
        /// </summary>
        [Fact]
        public async Task GetAllDoctors_ShouldReturnAllDoctorsWithDetails()
        {
            // Arrange
            var doctors = new List<AdminDoctorProfile>
            {
                new AdminDoctorProfile
                {
                    DoctorProfileId = 901912, FirstName = "Doctor 1", ImageUrl = "imgUrl", LastName = "LastName",
                    AdminDoctorSpecialities = new List<AdminDoctorSpeciality> { new AdminDoctorSpeciality { Speciality = "Speciality 1" } },
                    AdminDoctorLocations = new List<AdminDoctorLocation> { new AdminDoctorLocation { Location = new AdminLocation { Name = "Location 1" } } }
                },
                new AdminDoctorProfile
                {
                    DoctorProfileId = 901913, FirstName = "Doctor 2", ImageUrl = "imgUrl2", LastName = "LastName",
                    AdminDoctorSpecialities = new List<AdminDoctorSpeciality> { new AdminDoctorSpeciality { Speciality = "Speciality 2" } },
                    AdminDoctorLocations = new List<AdminDoctorLocation> { new AdminDoctorLocation { Location = new AdminLocation { Name = "Location 2" } } }
                }
            };

            await _context.AdminDoctorProfiles.AddRangeAsync(doctors);
            await _context.SaveChangesAsync();

            // Act
            var result = await _repository.GetAllDoctors();

            // Assert
            // Assert specific DoctorProfileId
            var specificDoctor = result.FirstOrDefault(d => d.DoctorProfileId == 901912);
            specificDoctor.Should().NotBeNull();
            specificDoctor?.AdminDoctorSpecialities.Should().ContainSingle();
            specificDoctor?.AdminDoctorLocations.FirstOrDefault()?.Location.Name.Should().Be("Location 1");
        }

        /// <summary>
        /// GetSpeiciality shouldReturnSpecialites WhenSpecialitiesExists
        /// </summary>
        /// <returns></returns>
        [Fact]
        public async Task GetSpeiciality_ShouldReturnSpecialites_WhenSpecialitiesExists()
        {
            // Arrange
            var specialities = new AdminSpeciality { SpecialityId = 1, Code = "11", DisplayName = "Gyna", Description = "gynacelogist", IsActive = true };


            await _context.AdminSpecialities.AddAsync(specialities);
            await _context.SaveChangesAsync();

            // Act
            var result = await _repository.GetSpeiciality();

            // Assert
            result.Should().NotBeNull();
            result?[0].DisplayName.Should().Be("Gyna");
        }

        [Fact]
        public async Task GetSpeiciality_ShouldReturnNull_WhenSpecialitiesNotExists()
        {
            // Act
            var result = await _repository.GetSpeiciality();

            // Assert
            result.Should().BeEmpty();
        }


        #endregion


        [Fact]
        public async Task GetDoctorProfileByIdAsync_ShouldReturnDoctorProfile_WhenIdExists()
        {
            var doctorProfile = new AdminDoctorProfile { DoctorProfileId = 754, LastName = "D", ImageUrl = "image.jpg", FirstName = "Dr. John Doe" };
            _context.AdminDoctorProfiles.Add(doctorProfile);
            await _context.SaveChangesAsync();

            // Act
            var result = await _repository.GetDoctorProfileByIdAsync(754);

            // Assert
            result.Should().NotBeNull();
            result?.DoctorProfileId.Should().Be(754);
            result?.FirstName.Should().Be("Dr. John Doe");
        }

    }

}
