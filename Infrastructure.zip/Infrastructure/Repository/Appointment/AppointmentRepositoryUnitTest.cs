﻿using Aurora.AdministrationService.Infrastructure.Repository;
using Aurora.AdministrationService.Infrastructure;
using Microsoft.EntityFrameworkCore;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Aurora.AdministrationService.Infrastructure.IRepository;
using Aurora.AdministrationService.CrossCutting.Extensions;
using Aurora.AdministrationService.Domain.Entities;
using Moq;
using FluentAssertions;
using Microsoft.AspNetCore.Mvc;

namespace Aurora.AdministrationService.Tests.Infrastructure.Repository.Appointment
{
    public class AppointmentRepositoryUnitTest
    {
        private readonly IAppointmentRepository _repository;
        private readonly ReadWriteDbContext _context;

        /// <summary>
        /// Initializes a new instance of the <see cref=PatientRepositoryTests"/> class.
        /// Sets up an in-memory database and the repository instance for testing.
        /// </summary>
        public AppointmentRepositoryUnitTest()
        {
            // Setup in-memory database for testing
            var options = new DbContextOptionsBuilder<ReadWriteDbContext>()
                .UseInMemoryDatabase(databaseName: Guid.NewGuid().ToString())
                .Options;

            _context = new ReadWriteDbContext(options);
            _repository = new AppointmentRepository(_context);
           
        }

        [Fact]
        public async Task GetAppointments_ShouldReturnEmptyListWhenNoAppointmentsExist()
        {
            // Arrange

            var paginationQuery = new PaginationQuery { PageNumber = 1, PageSize = 10 };

            // Act
            var result = await _repository.GetAppointments(paginationQuery);

            // Assert
            result.Should().NotBeNull();
            result.Should().BeEmpty(); // No appointments should exist in the database
        }

    }
}
