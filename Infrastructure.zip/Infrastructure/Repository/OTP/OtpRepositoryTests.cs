﻿using Aurora.AdministrationService.Domain.Old.Entities;
using Aurora.AdministrationService.Infrastructure;
using Aurora.AdministrationService.Infrastructure.Repository.OTP;
using FluentAssertions;
using Microsoft.EntityFrameworkCore;

namespace Aurora.AdministrationService.Tests.Infrastructure.Repository.OTP
{
    public class OtpRepositoryTests
    {

        private readonly OtpRepository _repository;
        private readonly ReadWriteDbContext _context;

        public OtpRepositoryTests()
        {
            // Setup in-memory database for testing
            var options = new DbContextOptionsBuilder<ReadWriteDbContext>()
                .UseInMemoryDatabase(databaseName: Guid.NewGuid().ToString())
                .Options;

            _context = new ReadWriteDbContext(options);
            _repository = new OtpRepository(_context);

        }
        [Fact]
        public async Task GetOtpAttemptsInLast24HoursAsync_ShouldReturnCorrectCount()
        {
            // Arrange
            var userId = "user123";

            var otpEntries = new List<OtpEntry>
    {
        new OtpEntry { UserId = userId, CreatedBy = DateTime.UtcNow.AddHours(-1) }, // Within 24 hours
        new OtpEntry { UserId = userId, CreatedBy = DateTime.UtcNow.AddHours(-2) }, // Within 24 hours
        new OtpEntry { UserId = userId, CreatedBy = DateTime.UtcNow.AddHours(-25) } // Outside 24 hours
    };

            _context.OtpEntries.AddRange(otpEntries);
            await _context.SaveChangesAsync();

            // Act
            var result = await _repository.GetOtpAttemptsInLast24HoursAsync(userId);

            // Assert
            result.Should().Be(2); // Only 2 attempts should be within the last 24 hours
        }
        [Fact]
        public async Task GetOtpByUserId_ShouldReturnOtpEntriesWhenEmailProvided()
        {
            // Arrange
            var userId = "user123";
            var email = "user@example.com";
            var otpType = 1;

            var user = new AdminUser { Username = userId, Email = email  ,Password="test@12345", FirstName="John", LastName="James",Role="User" };
            var otpEntries = new List<OtpEntry>
    {
        new OtpEntry { UserId = userId, OtpType = otpType, IsUsed = false },
        new OtpEntry { UserId = userId, OtpType = otpType, IsUsed = false }
    };

            _context.AdminUsers.Add(user);
            _context.OtpEntries.AddRange(otpEntries);
            await _context.SaveChangesAsync();

            // Act
            var result = await _repository.GetOtpByUserId(userId, email, null, otpType);

            // Assert
            result.Should().NotBeNull();
            result.Should().HaveCount(2); // Should return both OTP entries for the given email
            result.All(x => x.UserId == userId).Should().BeTrue(); // Ensure all returned OTP entries are for the correct user
        }
        [Fact]
        public async Task GetOtpByUserId_ShouldReturnOtpEntriesWhenMobileNumberProvided()
        {
            // Arrange
            var userId = "user123";
            var mobileNo = "1234567890";
            var otpType = 1;

            var user = new AdminUser { Username = userId, PhoneNumber = mobileNo,Email="test@test.com",Password = "test@12345", FirstName = "John", LastName = "James", Role = "User" };
            var otpEntries = new List<OtpEntry>
    {
        new OtpEntry { UserId = userId, OtpType = otpType, IsUsed = false },
        new OtpEntry { UserId = userId, OtpType = otpType, IsUsed = false }
    };

            _context.AdminUsers.Add(user);
            _context.OtpEntries.AddRange(otpEntries);
            await _context.SaveChangesAsync();

            // Act
            var result = await _repository.GetOtpByUserId(userId, null, mobileNo, otpType);

            // Assert
            result.Should().NotBeNull();
            result.Should().HaveCount(2); // Should return both OTP entries for the given mobile number
            result.All(x => x.UserId == userId).Should().BeTrue(); // Ensure all returned OTP entries are for the correct user
        }
        [Fact]
        public async Task SaveOtpAsync_ShouldRemoveExistingOtpEntriesAndSaveNewOne()
        {
            // Arrange
            var userId = "user123";

            var existingOtp = new OtpEntry { UserId = userId, OtpType = 1, IsUsed = false };
            _context.OtpEntries.Add(existingOtp);
            await _context.SaveChangesAsync();

            var newOtp = new OtpEntry { UserId = userId, OtpType = 1, IsUsed = false };

            // Act
            await _repository.SaveOtpAsync(newOtp);

            // Assert
            var otpCount = await _context.OtpEntries.CountAsync();
            otpCount.Should().Be(1); // There should only be 1 OTP entry left for the user
            var otpEntry = await _context.OtpEntries.FirstOrDefaultAsync(o => o.UserId == userId);
            otpEntry.Should().BeEquivalentTo(newOtp); // The new OTP should be saved and the old OTP should be removed
        }

        [Fact]
        public async Task UpdateAttempt_ShouldUpdateOtpEntry()
        {
            // Arrange
            var userId = "user123";
            var otpEntry = new OtpEntry { UserId = userId, OtpType = 1, IsUsed = false };
            _context.OtpEntries.Add(otpEntry);
            await _context.SaveChangesAsync();

            otpEntry.IsUsed = true; // Update the OTP entry

            // Act
            await _repository.UpdateAttempt(otpEntry);

            // Assert
            var updatedOtpEntry = await _context.OtpEntries.FirstOrDefaultAsync(o => o.UserId == userId);
            updatedOtpEntry.Should().NotBeNull();
            updatedOtpEntry?.IsUsed.Should().BeTrue(); // Ensure the OTP entry's 'IsUsed' field is updated to true
        }

        [Fact]
        public void MarkOtpAsUsed_ShouldUpdateOtpAsUsed()
        {
            // Arrange
            var otpEntry = new OtpEntry { UserId = "user123", OtpType = 1, IsUsed = false };
            _context.OtpEntries.Add(otpEntry);
            _context.SaveChanges();

            // Act
            _repository.MarkOtpAsUsed(otpEntry);

            // Assert
            var updatedOtpEntry = _context.OtpEntries.FirstOrDefault(o => o.UserId == "user123");
            updatedOtpEntry.Should().NotBeNull();
            updatedOtpEntry?.IsUsed.Should().BeTrue();
        }

        [Fact]
        public void DeleteOtpAsUsed_ShouldRemoveOtpFromDatabase()
        {
            // Arrange
            var otpEntry = new OtpEntry { UserId = "user123", OtpType = 1, IsUsed = true };
            _context.OtpEntries.Add(otpEntry);
            _context.SaveChanges();

            // Act
            _repository.DeleteOtpAsUsed(otpEntry);

            // Assert
            var deletedOtpEntry = _context.OtpEntries.FirstOrDefault(o => o.UserId == "user123");
            deletedOtpEntry.Should().BeNull(); // Ensure the OTP entry has been deleted
        }


    }
}
