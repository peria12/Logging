﻿using Aurora.AdministrationService.Domain.Old.Entities;
using Aurora.AdministrationService.Infrastructure;
using Aurora.AdministrationService.Infrastructure.Repository.MarketingMainBanners;
using FluentAssertions;
using Microsoft.EntityFrameworkCore;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Xunit;

namespace Aurora.AdministrationService.Tests.Repositories
{
    /// <summary>
    /// Unit tests for <see cref="MarketingMainBannerRepository"/> class.
    /// </summary>
    public class MarketingMainBannerRepositoryTests
    {
        private readonly ReadWriteDbContext _context;
        private readonly MarketingMainBannerRepository _repository;

        /// <summary>
        /// Initializes a new instance of the <see cref="MarketingMainBannerRepositoryTests"/> class.
        /// Sets up the in-memory database and repository for testing.
        /// </summary>
        public MarketingMainBannerRepositoryTests()
        {
            // Set up the in-memory database for testing
            var options = new DbContextOptionsBuilder<ReadWriteDbContext>()
                .UseInMemoryDatabase(databaseName: "MarketingMainBannerTestDB")
                .Options;

            _context = new ReadWriteDbContext(options);
            _repository = new MarketingMainBannerRepository(_context);
        }

        /// <summary>
        /// Tests the <see cref="MarketingMainBannerRepository.GetMarketingMainBannersAsync"/> method.
        /// Verifies that the method returns a list of banners when banners exist in the database.
        /// </summary>
        [Fact]
        public async Task GetMarketingMainBannersAsync_ShouldReturnListOfBanners()
        {
            // Arrange
            var banners = new List<MarketingMainBanner>
            {
                new MarketingMainBanner { Id = 1, Title = "Banner 1", Url ="testUrl", ImageUrl = "http://example.com/banner1.jpg",CreatedBy=5,LastModifiedBy=5,LastModifiedDate=DateTime.Now,StartDate=DateTime.Now.AddDays(-5),EndDate=DateTime.Now.AddDays(1),IsActive=true },
                new MarketingMainBanner { Id = 2, Title = "Banner 2", Url = "testUrl", ImageUrl = "http://example.com/banner2.jpg", CreatedBy=5, LastModifiedBy=5,LastModifiedDate=DateTime.Now,StartDate=DateTime.Now.AddDays(-5),EndDate=DateTime.Now.AddDays(1),IsActive=true }
            };

            // Add banners to the in-memory database
            await _context.MarketingMainBanners.AddRangeAsync(banners);
            await _context.SaveChangesAsync();

            // Act
            var result = await _repository.GetMarketingMainBannersAsync();

            // Assert
            result.Should().HaveCount(2); // Ensure there are 2 banners
            result.Should().Contain(b => b.Title == "Banner 1"); // Validate banner titles
            result.Should().Contain(b => b.Title == "Banner 2");
        }

        /// <summary>
        /// Tests the <see cref="MarketingMainBannerRepository.GetMarketingMainBannersAsync"/> method.
        /// Verifies that the method returns an empty list when no banners exist in the database.
        /// </summary>
        [Fact]
        public async Task GetMarketingMainBannersAsync_ShouldReturnEmptyList_WhenNoBannersExist()
        {
            // Act
            var result = await _repository.GetMarketingMainBannersAsync();

            // Assert
            result.Should().BeEmpty(); // Validate that no banners exist
        }
    }
}
