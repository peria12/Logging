﻿using Aurora.AdministrationService.CrossCutting.Extensions;
using Aurora.AdministrationService.Domain.Entities;
using Aurora.AdministrationService.Infrastructure.Repository;
using Aurora.AdministrationService.Infrastructure;
using Microsoft.EntityFrameworkCore;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using FluentAssertions;
using Aurora.AdministrationService.Domain.Old.Entities;

namespace Aurora.AdministrationService.Tests.Infrastructure.Repository.Holiday
{
    public class HolidayRepositoryTests
    {
        private readonly HolidayRepository _repository;
        private readonly ReadWriteDbContext _context;
        public HolidayRepositoryTests()
        {
            var options = new DbContextOptionsBuilder<ReadWriteDbContext>()
                .UseInMemoryDatabase(Guid.NewGuid().ToString())
                .Options;

            _context = new ReadWriteDbContext(options);
            _context.Database.EnsureCreated();
            _repository = new HolidayRepository(_context);
        }
        [Fact]
        public async Task GetHolidays_ShouldReturnEmptyList_WhenNoRecordsExist()
        {
            // Arrange

            var pagination = new PaginationQuery { PageNumber = 1, PageSize = 2 };

            // Act
            var result = await _repository.GetHolidays(pagination);

            // Assert
            result.Should().BeEmpty();
        }
        [Fact]
        public async Task AddHolidayAsync_ShouldAddHolidaySuccessfully()
        {
            // Arrange

            var holiday = new AdminOrganizationHoliday
            {
                HolidayType ="holiday",
                HolidayName = "New Year's Day",
                HolidayDate = new DateOnly(2024, 1, 1),
                OrganizationId = 1
            };

            // Act
            var result = await _repository.AddHolidayAsync(holiday);

            // Assert
            result.Should().Be(1); // One record should be added
            var addedHoliday = await _context.AdminOrganizationHolidays.FirstOrDefaultAsync();
            addedHoliday.Should().NotBeNull();
            addedHoliday?.HolidayName.Should().Be("New Year's Day");
            addedHoliday?.CreatedAt.Should().BeCloseTo(DateTime.UtcNow, TimeSpan.FromSeconds(1));
        }

    }
}
