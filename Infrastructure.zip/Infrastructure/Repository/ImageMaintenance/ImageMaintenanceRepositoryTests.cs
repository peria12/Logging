﻿using Aurora.AdministrationService.Infrastructure.Repository;
using Aurora.AdministrationService.Infrastructure;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Aurora.PatientLifeCycleService.Infrastructure.Repository.ImageMaintenances;
using Microsoft.EntityFrameworkCore;
using Aurora.AdministrationService.Domain.Entities;
using Microsoft.Graph.SecurityNamespace;
using Aurora.AdministrationService.Tests.API.Services.ImageMaintenance;
using FluentAssertions;
using Azure;
using Aurora.AdministrationService.Domain.Old.Entities;

namespace Aurora.AdministrationService.Tests.Infrastructure.Repository.ImageMaintenance
{
    public class ImageMaintenanceRepositoryTests
    {
        private readonly ReadWriteDbContext _context;
        private readonly ImageMaintenanceRepository _repository;

        public ImageMaintenanceRepositoryTests()
        {
            // Setup in-memory database for testing
            var options = new DbContextOptionsBuilder<ReadWriteDbContext>()
                .UseInMemoryDatabase(databaseName: Guid.NewGuid().ToString())
                .Options;
            _context = new ReadWriteDbContext(options);
            _repository = new ImageMaintenanceRepository(_context);

            Environment.SetEnvironmentVariable("ASPNETCORE_ENVIRONMENT", "Testing");
        }

        #region Get ImageMaintenance repository tests

        [Fact]
        public async Task GetImageMaintenance_ShouldReturnSpecialites_WhenImagesExists()
        {
            // Arrange
            var searchRequest = MockData.GetImageMaintenanceSerachRequest();
            var image = MockData.CreateAdminImage();
            var admin = MockData.CreateAdminUser();
            var imageSourceTypeName = System.Enum.GetName(searchRequest.SelectedImageSourceType);

            await _context.AdminImageMaintenances.AddAsync(image);
            await _context.AdminUsers.AddAsync(admin);
            await _context.SaveChangesAsync();

            // Act
            var result = await _repository.GetImageMaintenanceSearch(imageSourceTypeName, searchRequest.SelectedScreenTypes, searchRequest.SelectedCreatedDate, true, false, true);

            // Assert
            result.Should().NotBeNull();
            result.Should().HaveCount(1);
        }

        [Fact]
        public async Task GetImageMaintenance_ShouldReturnNull_WhenImageNotExists()
        {
            // Act
            // Arrange
            var searchRequest = MockData.GetImageMaintenanceSerachRequest();
            var imageSourceTypeName = System.Enum.GetName(searchRequest.SelectedImageSourceType);

            var result = await _repository.GetImageMaintenanceSearch(imageSourceTypeName, searchRequest.SelectedScreenTypes, searchRequest.SelectedCreatedDate, true, false, true);

            // Assert
            result.Should().BeEmpty();
        }



        #endregion


        [Fact]
        public async Task DeleteImageMaintenanceAsync_ShouldDeleteImageMaintenanceWhenFound()
        {
            // Arrange

            var imageMaintenance = new AdminImageMaintenance
            {
                ImageName = "test1",
                ImageType = "Banner",
                ScreenType = "Home",
                Status = true,
                CreatedAt = DateTime.UtcNow,
                UpdatedAt = DateTime.UtcNow
            };

            _context.AdminImageMaintenances.Add(imageMaintenance);
            await _context.SaveChangesAsync();

            var imageMaintenanceId = imageMaintenance.Id;

            // Act
            var result = await _repository.DeleteImageMaintenanceAsync(imageMaintenanceId);

            // Assert
            result.Should().BeGreaterThan(0); // ImageMaintenance should be deleted
            var deletedImage = await _context.AdminImageMaintenances.FindAsync(imageMaintenanceId);
            deletedImage.Should().BeNull(); // The record should be deleted
        }
        [Fact]
        public async Task GetImageMaintenanceByIdAsync_ShouldReturnImageMaintenanceWhenFound()
        {
            // Arrange

            var imageMaintenance = new AdminImageMaintenance
            {
                ImageName = "test1",
                ImageType = "Banner",
                ScreenType = "Home",
                Status = true,
                CreatedAt = DateTime.UtcNow,
                UpdatedAt = DateTime.UtcNow
            };

            _context.AdminImageMaintenances.Add(imageMaintenance);
            await _context.SaveChangesAsync();

            var imageMaintenanceId = imageMaintenance.Id;

            // Act
            var result = await _repository.GetImageMaintenanceByIdAsync(imageMaintenanceId);

            // Assert
            result.Should().NotBeNull();
            result?.ImageType.Should().Be("Banner");
            result?.ScreenType.Should().Be("Home");
        }
        [Fact]
        public async Task GetImageMaintenanceSearch_ShouldReturnFilteredResultsBasedOnSearchCriteria()
        {
            // Arrange
            var user = new AdminUser
            {
                Active = true,
                AdminId = 1,
                CreatedBy = 1,
                DateCreated = DateTime.Now,
                Email = "test@test.com",
                FirstName = "john",
                LastLogin = DateTime.Now,
                LastModifiedBy = 1,
                LastModifiedDate = DateTime.Now,
                LastName = "K",
                OrganizationId = 1,
                Password = "test",
                PhoneNumber = "09876543210",
                RetryAttempt = 0,
                Role = "Admin",
                Status = true,
                Username = "john",
            };
            var imageMaintenances = new List<AdminImageMaintenance>
    {
        new AdminImageMaintenance { ImageType = "Banner",ImageName="image", ScreenType = "Home", Status = true, CreatedAt = new DateTime(2024, 1, 1) , CreatedByNavigation=user,UpdatedByNavigation=user },
        new AdminImageMaintenance { ImageType = "Banner",ImageName="image", ScreenType = "Product", Status = false, CreatedAt = new DateTime(2024, 1, 2) , CreatedByNavigation=user,UpdatedByNavigation=user},
        new AdminImageMaintenance { ImageType = "Banner",ImageName="image", ScreenType = "Product", Status = true, CreatedAt = new DateTime(2024, 1, 2) ,CreatedByNavigation=user,UpdatedByNavigation=user }
    };

            _context.AdminImageMaintenances.AddRange(imageMaintenances);
            await _context.SaveChangesAsync();

            var selectedScreenTypes = new List<string> { "Product" };
            var selectedCreatedDate = new DateTime(2024, 1, 2);
            var selectedStatus = true;
            var imageMaintenanceSourceType = "Banner";
            var isNeedAllRecords = false;
            var isNeedAllImageTypeRecords = false;

            // Act
            var result = await _repository.GetImageMaintenanceSearch(imageMaintenanceSourceType, selectedScreenTypes, selectedCreatedDate, isNeedAllRecords, selectedStatus, isNeedAllImageTypeRecords);

            // Assert
            result.Should().HaveCount(1); // One record matches the criteria
            result.Should().Contain(im => im.ImageType == "Banner");
            result.Should().Contain(im => im.ScreenType == "Product");
        }
        [Fact]
        public async Task GetImageMaintenanceDetail_ShouldReturnImageMaintenanceWhenMatchingSourceTypeAndScreenTypes()
        {
            // Arrange
            var user = new AdminUser {
            Active=true,
            AdminId=1,
            CreatedBy=1,
            DateCreated=DateTime.Now,
            Email="test@test.com",
            FirstName="john",
            LastLogin=DateTime.Now,
            LastModifiedBy=1,
            LastModifiedDate=DateTime.Now,
            LastName="K",
            OrganizationId=1,
            Password="test",
            PhoneNumber="09876543210",
            RetryAttempt=0,
            Role="Admin",
            Status=true,
            Username="john",
            };
            var imageMaintenances = new List<AdminImageMaintenance>
    {
        new AdminImageMaintenance { ImageType = "Banner",ImageName="image", ScreenType = "Home", Status = true, UpdatedByNavigation=user,CreatedByNavigation=user, },
        new AdminImageMaintenance { ImageType = "Banner",ImageName="image", ScreenType = "Home", Status = true, UpdatedByNavigation=user,CreatedByNavigation=user, }
    };

            _context.AdminImageMaintenances.AddRange(imageMaintenances);
            await _context.SaveChangesAsync();

            var selectedScreenTypes = new[] { "Home" };
            var imageMaintenanceSourceType = "Banner";

            // Act
            var result = await _repository.GetImageMaintenanceDetail(imageMaintenanceSourceType, selectedScreenTypes);

            // Assert
            result.Should().HaveCount(2); 
        }
        [Fact]
        public async Task UpdateImageMaintenanceStatus_ShouldReturnsuccess()
        {
            // Arrange
            var user = new AdminUser
            {
                Active = true,
                AdminId = 1,
                CreatedBy = 1,
                DateCreated = DateTime.Now,
                Email = "test@test.com",
                FirstName = "john",
                LastLogin = DateTime.Now,
                LastModifiedBy = 1,
                LastModifiedDate = DateTime.Now,
                LastName = "K",
                OrganizationId = 1,
                Password = "test",
                PhoneNumber = "09876543210",
                RetryAttempt = 0,
                Role = "Admin",
                Status = true,
                Username = "john",
            };
            var imageMaintenances = new List<AdminImageMaintenance>
            {
                new AdminImageMaintenance { Id=1, ImageType = "Banner",ImageName="image", ScreenType = "Home", Status = true, UpdatedByNavigation=user,CreatedByNavigation=user, },
                new AdminImageMaintenance { Id=2, ImageType = "Banner",ImageName="image", ScreenType = "Home", Status = true, UpdatedByNavigation=user,CreatedByNavigation=user, }
            };
            var expected = 1;
            _context.AdminImageMaintenances.AddRange(imageMaintenances);
            await _context.SaveChangesAsync();


            // Act
            var actual = await _repository.UpdateImageMaintenanceStatusAsync(1, true);

            // Assert
            Assert.Equal(expected, actual);
        }
        [Fact]
        public async Task UpdateImageMaintenanceStatus_ShouldReturnFalied_WhenInvalidIdPassed()
        {
            // Arrange
            var user = new AdminUser
            {
                Active = true,
                AdminId = 1,
                CreatedBy = 1,
                DateCreated = DateTime.Now,
                Email = "test@test.com",
                FirstName = "john",
                LastLogin = DateTime.Now,
                LastModifiedBy = 1,
                LastModifiedDate = DateTime.Now,
                LastName = "K",
                OrganizationId = 1,
                Password = "test",
                PhoneNumber = "09876543210",
                RetryAttempt = 0,
                Role = "Admin",
                Status = true,
                Username = "john",
            };
            var imageMaintenances = new List<AdminImageMaintenance>
            {
                new AdminImageMaintenance { Id=1, ImageType = "Banner",ImageName="image", ScreenType = "Home", Status = true, UpdatedByNavigation=user,CreatedByNavigation=user, },
                new AdminImageMaintenance { Id=2, ImageType = "Banner",ImageName="image", ScreenType = "Home", Status = true, UpdatedByNavigation=user,CreatedByNavigation=user, }
            };
            var expected = 0; 
            _context.AdminImageMaintenances.AddRange(imageMaintenances);
            await _context.SaveChangesAsync();


            // Act
            var actual = await _repository.UpdateImageMaintenanceStatusAsync(3, true);

            // Assert
            Assert.Equal(expected, actual);
        }
        [Fact]
        public async Task AddImageMaintenanceAsync_ShouldAddImageMaintenanceSuccessfully()
        {
            // Arrange
            var imageMaintenance = new AdminImageMaintenance
            {
                ImageName ="test1",
                ImageType = "Banner",
                ScreenType = "Home",
                Status = true,
                CreatedAt = DateTime.UtcNow,
                UpdatedAt = DateTime.UtcNow
            };

            // Act
            var result = await _repository.AddImageMaintenanceAsync(imageMaintenance);

            // Assert
            result.Should().BeGreaterThan(0); // Ensure a record was added
            var addedImage = await _context.AdminImageMaintenances.FirstOrDefaultAsync();
            addedImage.Should().NotBeNull();
            addedImage?.ImageType.Should().Be("Banner");
        }

    }
}
