﻿using Aurora.AdministrationService.Domain.Entities;
using Aurora.AdministrationService.Domain.Old.Entities;
using Aurora.AdministrationService.Infrastructure;
using Aurora.AdministrationService.Infrastructure.Repository.ImageMaintenances;
using FluentAssertions;
using Microsoft.EntityFrameworkCore;

namespace Aurora.AdministrationService.Tests.Infrastructure.Repository.ImageMaintenance
{
    public class LogoImageMaintenanceRepositoryTests
    {
        private readonly ReadWriteDbContext _context;
        private readonly LogoImageMaintenanceRepository _repository;
        private readonly byte[] _concurrencyStamp;
        public LogoImageMaintenanceRepositoryTests()
        {
            _concurrencyStamp = BitConverter.GetBytes(DateTime.UtcNow.Ticks);
            var options = new DbContextOptionsBuilder<ReadWriteDbContext>()
                .UseInMemoryDatabase(databaseName: "AdminImageMaintenanceTestDB")
                .Options;
            _context = new ReadWriteDbContext(options);
            _context.Database.EnsureDeleted();
            _context.Database.EnsureCreated();
            seedData();
            _repository = new LogoImageMaintenanceRepository(_context);
        }
        public void seedData()
        {
            _context.AdminOrganizations.Add(new AdminOrganization()
            {
                Active = true,
                Address = "Malasiya",
                City = "Bukit Rimau",
                Country = "Malasiya",
                CreatedBy = 1,
                DateCreated = DateTime.Now,
                Email = "info@test.com",
                ImageUrl = "image.jpg",
                LastModifiedBy = 1,
                LastModifiedDate = DateTime.Now,
                Latitude = 2.9971,
                Longitude = 101.6376,
                Name = "Columbia Asia",
                OrganizationId = 1,
                PhoneNumber = "32323232",
                State = "Malaysia",
                PostalCode = "40460",
                WebsiteUrl = "columbiaasia.com",
                Type = "Hospital",
            });
            _context.AdminUsers.Add(new AdminUser
            {
                LastModifiedBy = null,
                LastModifiedDate = DateTime.Now,
                Active = true,
                AdminId = 1,
                CreatedBy = 1,
                CreatedByNavigation = null,
                DateCreated = DateTime.UtcNow,
                Email = "test@test.com",
                FirstName = "admin",
                LastLogin = DateTime.UtcNow,
                LastLoginFailedTime = DateTime.UtcNow,
                LastName = "admin",
                OrganizationId = 1,
                Password = "admin",
                PhoneNumber = "0987654321",
                RetryAttempt = 1,
                Role = "admin",
                Status = true,
                Username = "admin",
            });
            _context.AdminLogoImageMaintenances.Add(new AdminLogoImageMaintenance
            {
                Id = 2,
                OrganizationId = 1,
                IsActive = true,
                ImageName = "logo",
                UpdatedBy = 1,
                ImageUrl = "logo.jpg",
                ConcurrencyStamp = _concurrencyStamp
            });
            _context.SaveChanges();
            _context.ChangeTracker.Clear();
        }

        [Fact]
        public async Task GetLogoImageSearch_ReturnsAllRecords_WhenIsNeedAllRecordsIsTrue()
        {
            // Arrang
            var concurrencyStamp = BitConverter.GetBytes(DateTime.UtcNow.Ticks);
            _context.AdminLogoImageMaintenances.Add(new AdminLogoImageMaintenance { Id = 1, OrganizationId = 1, IsActive = true, UpdatedBy = 1, ImageName = "logo", ImageUrl = "logo.jpg", ConcurrencyStamp = _concurrencyStamp });
            _context.SaveChanges();
            // Act
            var result = await _repository.GetLogoImageSearch(new List<string>(), true, true);

            // Assert
            result.Count.Should().Be(2);
        }

        [Fact]
        public async Task GetLogoImageSearch_FiltersBySelectedOrganizationIds()
        {
            // Arrange
            var _concurrencyStamp = BitConverter.GetBytes(DateTime.UtcNow.Ticks);
            _context.AdminLogoImageMaintenances.Add(new AdminLogoImageMaintenance { Id = 1, OrganizationId = 1, IsActive = true, UpdatedBy = 1, ImageName = "logo", ImageUrl = "logo.jpg", ConcurrencyStamp = _concurrencyStamp });
            _context.SaveChanges();
            // Act
            var result = await _repository.GetLogoImageSearch(new List<string> { "1" }, true, true);

            // Assert
            result.Count.Should().Be(2);
            result[0].OrganizationId.Should().Be(1);
        }

        [Fact]
        public async Task GetLogoImageByIdAsync_ReturnsCorrectRecord()
        {
            // Arrange
            var concurrencyStamp = BitConverter.GetBytes(DateTime.UtcNow.Ticks);
            var data = new List<AdminLogoImageMaintenance>
        {
            new AdminLogoImageMaintenance {Id = 1, OrganizationId = 1, IsActive = true, UpdatedBy=1,  ImageName = "logo", ImageUrl = "logo.jpg", ConcurrencyStamp = _concurrencyStamp}
        };
            _context.AdminLogoImageMaintenances.AddRange(data);
            _context.SaveChanges();

            // Act
            var result = await _repository.GetLogoImageByIdAsync(1);

            // Assert
            result.Should().NotBeNull();
            result.Id.Should().Be(1);
        }

        [Fact]
        public async Task GetLogoImageByIdAsync_ReturnsNull_WhenRecordNotFound()
        {
            // Arrange
            var data = new List<AdminLogoImageMaintenance>();
            _context.AdminLogoImageMaintenances.AddRange(data);
            _context.SaveChanges();

            // Act
            var result = await _repository.GetLogoImageByIdAsync(1);

            // Assert

            result.Should().BeNull();
        }

        [Fact]
        public async Task UpdateLogoImageAsync_UpdatesRecord()
        {
            // Arrange
            var concurrencyStamp = BitConverter.GetBytes(DateTime.UtcNow.Ticks);
            var imageMaintenance = new AdminLogoImageMaintenance { Id = 2, OrganizationId = 1, IsActive = true, UpdatedBy = 1, ImageName = "logo", ImageUrl = "logo.jpg", ConcurrencyStamp = _concurrencyStamp };

            // Act
            var result = await _repository.UpdateLogoImageAsync(imageMaintenance);

            // Assert
            result.Should().Be(1);

        }

        [Fact]
        public async Task UpdateLogoImageStatusAsync_UpdatesStatus()
        {
            // Arrange
            var concurrencyStamp = BitConverter.GetBytes(DateTime.UtcNow.Ticks);
            var imageMaintenance = new AdminLogoImageMaintenance { Id = 2, OrganizationId = 1, IsActive = true, ImageName = "logo", ImageUrl = "logo.jpg", UpdatedBy = 1, ConcurrencyStamp = _concurrencyStamp };
          
            // Act
            var result = await _repository.UpdateLogoImageStatusAsync(2, false);

            // Assert
            result.Should().Be(1);

        }

        [Fact]
        public async Task DeleteLogoImageAsync_DeletesRecord()
        {
            // Arrange
            // Act
            var result = await _repository.DeleteLogoImageAsync(2);

            // Assert
            result.Should().Be(1);
        }

        [Fact]
        public async Task AddLogoImageAsync_AddsRecord()
        {
            // Arrange
            var concurrencyStamp = BitConverter.GetBytes(DateTime.UtcNow.Ticks);
            var imageMaintenance = new AdminLogoImageMaintenance { Id = 3, OrganizationId = 1, IsActive = true, ImageName = "logo", ImageUrl = "logo.jpg", UpdatedBy = 1, ConcurrencyStamp = concurrencyStamp };
        

            // Act
            var result = await _repository.AddLogoImageAsync(imageMaintenance);

            // Assert
            result.Should().Be(1);
        }
    }
}
