﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Aurora.AdministrationService.Infrastructure.Repository;
using Aurora.AdministrationService.Infrastructure;
using Microsoft.EntityFrameworkCore;
using Moq;
using Aurora.AdministrationService.Domain.Old.Entities;


namespace Aurora.AdministrationService.Tests.Infrastructure.Repository.Location
{
    public class LocationRepositoryTest
    {
        private readonly Mock<ReadWriteDbContext> _mockContext;
        private readonly Mock<DbSet<AdminLocation>> _mockSet;

        public LocationRepositoryTest()
        {
            _mockContext = new Mock<ReadWriteDbContext>();
            _mockSet = new Mock<DbSet<AdminLocation>>();
            _mockContext.Setup(c => c.AdminLocations).Returns(_mockSet.Object);
        }

        [Fact]
        public async Task AddLocationAsync_ShouldAddAndSaveLocation()
        {
            // Arrange
            var options = new DbContextOptionsBuilder<ReadWriteDbContext>()
                .UseInMemoryDatabase(databaseName: "AddLocationTestDb") // Use in-memory DB
                .Options;

            using var context = new ReadWriteDbContext(options); // Real DbContext with in-memory DB
            var repository = new LocationRepository(context);

            var location = new AdminLocation { LocationId = 1, Name = "TestLocation" };

            // Act
            var result = await repository.AddLocationAsync(location);

            // Assert
            Assert.Equal(1, result); // Assert that the result is 1, indicating successful save
            Assert.Single(context.AdminLocations); // Assert that one location was added
            var savedLocation = await context.AdminLocations.FindAsync(1);
            Assert.NotNull(savedLocation); // Assert that the location is correctly saved in the context
            Assert.Equal("TestLocation", savedLocation.Name); // Assert that the location's name matches
        }
       

        [Fact]
        public async Task GetLocationByIdAsync_ShouldReturnLocation_WhenExists()
        {
            // Arrange

            // Use an in-memory database for testing
            var options = new DbContextOptionsBuilder<ReadWriteDbContext>()
                .UseInMemoryDatabase(databaseName: "GetLocationTestDb") // Use in-memory DB
                .Options;

            // Create the DbContext instance
            using var context = new ReadWriteDbContext(options);

            // Add a location to the in-memory database
            var location = new AdminLocation { LocationId = 1, Name = "NYC" };
            await context.AdminLocations.AddAsync(location);
            await context.SaveChangesAsync();

            // Create the repository using the real DbContext (not mocked)
            var repository = new LocationRepository(context);

            // Act
            var result = await repository.GetLocationByIdAsync(1);

            // Assert
            Assert.NotNull(result);
            Assert.Equal("NYC", result.Name); // Assert that the name is "NYC"
        }


        [Fact]
        public async Task GetLocationByIdAsync_ShouldReturnNull_WhenNotFound()
        {
            // Arrange
            var options = new DbContextOptionsBuilder<ReadWriteDbContext>()
              .UseInMemoryDatabase(databaseName: "AddLocationTestDb") // Use in-memory DB
              .Options;

            using var context = new ReadWriteDbContext(options); // Real DbContext with in-memory DB
            var repository = new LocationRepository(context);

            _mockSet.Setup(d => d.FindAsync(It.IsAny<object[]>()))
                    .ReturnsAsync((AdminLocation)null);

            // Act
            var result = await repository.GetLocationByIdAsync(999);

            // Assert
            Assert.Null(result);
        }

        [Fact]
        public async Task UpdateLocationAsync_ShouldUpdateAndSave()
        {
            // Arrange
            var options = new DbContextOptionsBuilder<ReadWriteDbContext>()
                .UseInMemoryDatabase(databaseName: "UpdateLocationTestDb")
                .Options;

            // Add the original location to the database
            using (var context = new ReadWriteDbContext(options))
            {
                context.AdminLocations.Add(new AdminLocation { LocationId = 1, Name = "OldName" });
                await context.SaveChangesAsync();
            }

            // Act - now update the location
            using (var context = new ReadWriteDbContext(options))
            {
                var repository = new LocationRepository(context);
                var updatedLocation = new AdminLocation { LocationId = 1, Name = "NewName" };

                var result = await repository.UpdateLocationAsync(updatedLocation);

                // Assert
                Assert.Equal(1, result);
            }

            // Optional: verify update
            using (var context = new ReadWriteDbContext(options))
            {
                var locationInDb = await context.AdminLocations.FindAsync(1);
                Assert.Equal("NewName", locationInDb.Name);
            }
        }

        [Fact]
        public async Task UpdateLocationAsync_ShouldThrow_WhenEntityDoesNotExist()
        {
            // Arrange
            var options = new DbContextOptionsBuilder<ReadWriteDbContext>()
                .UseInMemoryDatabase(databaseName: "UpdateFailsTestDb")
                .Options;

            using var context = new ReadWriteDbContext(options);
            var repository = new LocationRepository(context);

            var nonExistingLocation = new AdminLocation { LocationId = 999, Name = "Ghost" };

            // Act & Assert
            await Assert.ThrowsAsync<DbUpdateConcurrencyException>(() =>
                repository.UpdateLocationAsync(nonExistingLocation));
        }
    }
}
