﻿using Aurora.AdministrationService.Domain.Entities;
using Aurora.AdministrationService.Infrastructure.Repository.OTP;
using Aurora.AdministrationService.Infrastructure;
using Microsoft.EntityFrameworkCore;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Aurora.AdministrationService.Infrastructure.Repository.password;
using FluentAssertions;
using Aurora.AdministrationService.Domain.Old.Entities;

namespace Aurora.AdministrationService.Tests.Infrastructure.Repository.Password
{
    public class PasswordRepositoryTests
    {
        private readonly PasswordRepository _repository;
        private readonly ReadWriteDbContext _context;

        public PasswordRepositoryTests()
        {
            // Setup in-memory database for testing
            var options = new DbContextOptionsBuilder<ReadWriteDbContext>()
                .UseInMemoryDatabase(databaseName: Guid.NewGuid().ToString())
                .Options;

            _context = new ReadWriteDbContext(options);
            _repository = new PasswordRepository(_context);

        }
        [Fact]
        public async Task GetUserProfileByIdAsync_ShouldReturnUser_WhenUserIdIsProvided()
        {
            // Arrange
            var userId = "user123";
            var user = new AdminUser { Username = userId, Email = "user@example.com", PhoneNumber = "1234567890", FirstName = "John", LastName = "K", Role = "User", Password = "hashedpassword" };
            _context.AdminUsers.Add(user);
            await _context.SaveChangesAsync();

            // Act
            var result = await _repository.GetUserProfileByIdAsync(userId, "", "");

            // Assert
            result.Should().NotBeNull();
            result.Username.Should().Be(userId);
            result.Email.Should().Be("user@example.com");
        }
        [Fact]
        public async Task GetUserProfileByIdAsync_ShouldReturnUser_WhenEmailIsProvided()
        {
            // Arrange
            var email = "user@example.com";
            var user = new AdminUser { Username = "user123", Email = email, FirstName="John",LastName="K",Role="User",  PhoneNumber = "1234567890", Password = "hashedpassword" };
            _context.AdminUsers.Add(user);
            await _context.SaveChangesAsync();

            // Act
            var result = await _repository.GetUserProfileByIdAsync("", email, "");

            // Assert
            result.Should().NotBeNull();
            result.Email.Should().Be(email);
        }
        [Fact]
        public async Task GetUserProfileByIdAsync_ShouldReturnUser_WhenMobileNoIsProvided()
        {
            // Arrange
            var mobileNo = "1234567890";
            var user = new AdminUser { Username = "user123", Email = "user@example.com", FirstName = "John", LastName = "K", Role = "User", PhoneNumber = mobileNo, Password = "hashedpassword" };
            _context.AdminUsers.Add(user);
            await _context.SaveChangesAsync();

            // Act
            var result = await _repository.GetUserProfileByIdAsync("", "", mobileNo);

            // Assert
            result.Should().NotBeNull();
            result.PhoneNumber.Should().Be(mobileNo);
        }
        [Fact]
        public async Task GetUserProfileByIdAsync_ShouldReturnNull_WhenNoUserMatches()
        {
            // Arrange

            // Act
            var result = await _repository.GetUserProfileByIdAsync("nonexistentUser", "", "");

            // Assert
            result.Should().BeNull();
        }
        [Fact]
        public async Task UpdatePasswordAsync_ShouldUpdatePassword_WhenUserExists()
        {
            // Arrange
            var userId = "user123";
            var oldPassword = "oldpassword";
            var newPassword = "newpassword";
            var user = new AdminUser { Username = userId, AdminId=23232, Email = "user@example.com", PhoneNumber = "1234567890", FirstName = "John", LastName = "K", Role = "User", Password = oldPassword };
            _context.AdminUsers.Add(user);
            await _context.SaveChangesAsync();
            _context.ChangeTracker.Clear();
            // Act
            var result = await _repository.UpdatePasswordAsync(userId, newPassword);

            // Assert
            result.Should().BeTrue();
            var updatedUser = await _context.AdminUsers.FirstOrDefaultAsync(u => u.Username == userId);
            updatedUser.Should().NotBeNull();
            updatedUser.Password.Should().Be(newPassword); // Password should be updated
        }
        [Fact]
        public async Task UpdatePasswordAsync_ShouldReturnFalse_WhenUserDoesNotExist()
        {
            // Arrange
            var userId = "nonexistentUser";
            var newPassword = "newpassword";

            // Act
            var result = await _repository.UpdatePasswordAsync(userId, newPassword);

            // Assert
            result.Should().BeFalse(); // Should return false since the user doesn't exist
        }

    }
}
