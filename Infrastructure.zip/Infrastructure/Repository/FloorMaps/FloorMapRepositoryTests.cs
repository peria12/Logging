﻿using Aurora.AdministrationService.API.Services.Service;
using Aurora.AdministrationService.CrossCutting.Extensions;
using Aurora.AdministrationService.Infrastructure;
using Aurora.AdministrationService.Infrastructure.Repository;
using FluentAssertions;
using Microsoft.EntityFrameworkCore;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Aurora.AdministrationService.Domain.Old.Entities;

namespace Aurora.AdministrationService.Tests.Infrastructure.Repository.FloorMaps
{
    public class FloorMapRepositoryTests
    {
        private readonly FloorMapRepository _repository;
        private readonly ReadWriteDbContext _context;
        public  FloorMapRepositoryTests()
        {
            var options = new DbContextOptionsBuilder<ReadWriteDbContext>()
                .UseInMemoryDatabase(Guid.NewGuid().ToString())
                .Options;

            _context = new ReadWriteDbContext(options);
            _context.Database.EnsureCreated();
            _repository = new FloorMapRepository(_context);
        }

        [Fact]
        public async Task AddFloorMap_ShouldReturnOne_WhenFloorMapsAreAddedSuccessfully()
        {
            // Arrange
            var floorMaps = new List<FloorMap>
    {
        new FloorMap { ID = 1, BuildingName = "Floor 1",FloorImageUrl="img.png", LocationId = 1, IsActive = true, IsDeleted = false },
        new FloorMap { ID = 2, BuildingName = "Floor 2",FloorImageUrl="img.png", LocationId = 1, IsActive = true, IsDeleted = false }
    };

            // Act
            var result = await _repository.AddFloorMap(floorMaps);

            // Assert
            result.Should().Be(1);
            _context.FloorMap.Should().HaveCount(2);
        }
        [Fact]
        public async Task GetFloorMapById_ShouldReturnFloorMap_WhenIdExistsAndIsActive()
        {
            // Arrange
            var floorMap = new FloorMap { ID = 1, FloorImageUrl = "img.png", BuildingName = "Floor 1", IsActive = true, IsDeleted = false };
            _context.FloorMap.Add(floorMap);
            await _context.SaveChangesAsync();

            // Act
            var result = await _repository.GetFloorMapById(1);

            // Assert
            result.Should().NotBeNull();
            result?.ID.Should().Be(1);
            result?.BuildingName.Should().Be("Floor 1");
        }
        [Fact]
        public async Task GetFloorMapById_ShouldReturnNull_WhenFloorMapIsInactiveOrDeleted()
        {
            var floorMap = new FloorMap { ID = 1, FloorImageUrl = "img.png", BuildingName = "Floor 1", IsActive = false, IsDeleted = true };
            _context.FloorMap.Add(floorMap);
            await _context.SaveChangesAsync();

            // Act
            var result = await _repository.GetFloorMapById(1);

            // Assert
            result.Should().BeNull();
        }
        [Fact]
        public async Task UpdateFloorMap_ShouldUpdateFloorMapSuccessfully()
        {
            // Arrange
            var floorMap = new FloorMap { ID = 1, FloorImageUrl = "img.png", BuildingName = "Old ServiceDeliveryLocationRoleTypeCode", IsActive = true, IsDeleted = false };
            _context.FloorMap.Add(floorMap);
            await _context.SaveChangesAsync();

            // Act
            floorMap.BuildingName = "Updated ServiceDeliveryLocationRoleTypeCode";
            var result = await _repository.UpdateFloorMap(floorMap);

            // Assert
            result.Should().Be(1); // One record updated
            var updatedFloorMap = await _context.FloorMap.FindAsync(1);
            updatedFloorMap?.BuildingName.Should().Be("Updated ServiceDeliveryLocationRoleTypeCode");
        }
        [Fact]
        public async Task GetFloorMapList_ShouldReturnPaginatedFloorMaps()
        {
            // Arrange
            var floorMaps = new List<FloorMap>
    {
        new FloorMap { ID = 1, BuildingName = "Floor 1",FloorImageUrl="img.png", LocationId = 1, IsActive = true, IsDeleted = false },
        new FloorMap { ID = 2, BuildingName = "Floor 2",FloorImageUrl="img.png", LocationId = 1, IsActive = true, IsDeleted = false },
        new FloorMap { ID = 3, BuildingName = "Floor 3",FloorImageUrl="img.png", LocationId = 2, IsActive = true, IsDeleted = false }
    };
            _context.FloorMap.AddRange(floorMaps);
            await _context.SaveChangesAsync();

            var paginationQuery = new PaginationQuery { PageNumber = 1, PageSize = 2 };

            // Act
            var result = await _repository.GetFloorMapList(1, paginationQuery);

            // Assert
            result.Should().HaveCount(2);
            result.Should().Contain(f => f.ID == 1);
            result.Should().Contain(f => f.ID == 2);
        }
        [Fact]
        public async Task DeleteFloorMap_ShouldMarkFloorMapAsDeleted_WhenIdExists()
        {
            // Arrange
            var floorMap = new FloorMap { ID = 1, FloorImageUrl = "img.png", BuildingName = "Floor 1", IsActive = true, IsDeleted = false };
            _context.FloorMap.Add(floorMap);
            await _context.SaveChangesAsync();

            // Act
            var result = await _repository.DeleteFloorMap(1);

            // Assert
            result.Should().Be(1); // One record updated
            var deletedFloorMap = await _context.FloorMap.FindAsync(1);
            deletedFloorMap?.IsActive.Should().BeFalse();
            deletedFloorMap?.IsDeleted.Should().BeTrue();
        }


    }
}
