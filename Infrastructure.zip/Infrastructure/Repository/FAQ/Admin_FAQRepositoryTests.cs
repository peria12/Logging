using Aurora.AdministrationService.Infrastructure.Repository;
using Microsoft.EntityFrameworkCore;
using Moq;
using Xunit;
using System.Collections.Generic;
using System.Threading.Tasks;
using System.Linq;
using Aurora.AdministrationService.CrossCutting.Extensions;
using FluentAssertions;
using System.Reflection.PortableExecutable;
using Aurora.AdministrationService.Infrastructure;
using Aurora.AdministrationService.Domain.Old.Entities;

namespace Aurora.AdministrationService.Tests.Repositories.FAQ
{
    /// <summary>
    /// Unit tests for <see cref="Admin_FAQRepository"/> class.
    /// </summary>
    /// <remarks>
    /// These tests cover AddAdmin_FAQAsync, GetAdmin_FAQByIdAsync, UpdateAdmin_FAQAsync, UpdateAdmin_FAQStatusAsync, DeleteAdmin_FAQAsync, GetFaqsAsync, GetFaqsBySearchAsync methods.
    /// </remarks>
    public class Admin_FAQRepositoryTests
    {
        private readonly ReadWriteDbContext _context;
        private readonly Admin_FAQRepository _repository;

        public Admin_FAQRepositoryTests()
        {
            // Setup in-memory database for testing
            var options = new DbContextOptionsBuilder<ReadWriteDbContext>()
                .UseInMemoryDatabase(databaseName: "AdminFAQTestDB")
                .Options;
            _context = new ReadWriteDbContext(options);
            _repository = new Admin_FAQRepository(_context);
        }

        [Fact]
        public async Task AddAdmin_FAQAsync_ShouldAddFaq()
        {
            // Arrange
            var faq = new AdminFaq { Header = "Test FAQ", Description = "Test Description", IsActive = true };

            // Act
            var result = await _repository.AddAdmin_FAQAsync(faq);

            // Assert
            result.Should().BeGreaterThan(0); // One record added

            var count = await _context!.AdminFaqs!.CountAsync();
            count.Should().BeGreaterThan(0);
        }

        [Fact]
        public async Task GetAdmin_FAQByIdAsync_ShouldReturnFaq_WhenFaqExists()
        {
            // Arrange
            var faq = new AdminFaq { Id = 28938, Header = "Test FAQ" };
            await _context.AdminFaqs.AddAsync(faq);
            await _context.SaveChangesAsync();

            // Act
            var result = await _repository.GetAdmin_FAQByIdAsync(28938);

            // Assert
            result.Should().NotBeNull();
            result?.Header.Should().Be("Test FAQ");
        }

        [Fact]
        public async Task GetAdmin_FAQByIdAsync_ShouldReturnNull_WhenFaqDoesNotExist()
        {
            // Act
            var result = await _repository.GetAdmin_FAQByIdAsync(999);

            // Assert
            result.Should().BeNull();
        }

        [Fact]
        public async Task UpdateAdmin_FAQAsync_ShouldUpdateFaq()
        {
            // Arrange
            var faq = new AdminFaq { Id = 2190, Header = "Old Header" };
            await _context.AdminFaqs.AddAsync(faq);
            await _context.SaveChangesAsync();
            faq.Header = "Updated Header";

            // Act
            var result = await _repository.UpdateAdmin_FAQAsync(faq);

            // Assert
            result.Should().Be(1); // One record updated

            var faqResult = await _context!.AdminFaqs!.FirstOrDefaultAsync(x => x.Id == 2190);
            faqResult.Should().NotBeNull();
            faqResult!.Header.Should().Be("Updated Header");
        }

        [Fact]
        public async Task UpdateAdmin_FAQStatusAsync_ShouldUpdateStatus_WhenFaqExists()
        {
            // Arrange
            var faq = new AdminFaq { Id = 37837, IsActive = false, Header = "testHeader" };
            await _context.AdminFaqs.AddAsync(faq);
            await _context.SaveChangesAsync();

            // Act
            var result = await _repository.UpdateAdmin_FAQStatusAsync(37837, true);

            // Assert
            result.Should().Be(1); // One record updated

            var faqResult = await _context!.AdminFaqs!.FirstOrDefaultAsync(x => x.Id == 37837);
            faqResult.Should().NotBeNull();
            faqResult!.IsActive.Should().BeTrue();
        }

        [Fact]
        public async Task UpdateAdmin_FAQStatusAsync_ShouldReturnZero_WhenFaqDoesNotExist()
        {
            // Act
            var result = await _repository.UpdateAdmin_FAQStatusAsync(999, true);

            // Assert
            result.Should().Be(0); // No records updated
        }

        [Fact]
        public async Task DeleteAdmin_FAQAsync_ShouldDeleteFaq_WhenFaqExists()
        {
            // Arrange
            var faq = new AdminFaq { Id = 38938, Header = "testHeader" };
            await _context.AdminFaqs.AddAsync(faq);
            await _context.SaveChangesAsync();

            // Act
            var result = await _repository.DeleteAdmin_FAQAsync(38938);

            // Assert
            result.Should().Be(1); // One record deleted
            var deletedFaq = await _context.AdminFaqs.FirstOrDefaultAsync(x => x.Id == faq.Id);
            deletedFaq.Should().BeNull();
        }


        [Fact]
        public async Task DeleteAdmin_FAQAsync_ShouldReturnZero_WhenFaqDoesNotExist()
        {
            // Act
            var result = await _repository.DeleteAdmin_FAQAsync(999);

            // Assert
            result.Should().Be(0); // No records deleted
        }

        [Fact]
        public async Task GetFaqsAsync_ShouldReturnPagedFaqs()
        {
            // Arrange
            for (int i = 16; i <= 21; i++)
            {
                await _context.AdminFaqs.AddAsync(new AdminFaq { Id = i, Header = $"Header {i}" });
            }
            await _context.SaveChangesAsync();

            var paginationQuery = new PaginationQuery { PageNumber = 1, PageSize = 2 };

            // Act
            var result = await _repository.GetFaqsAsync(paginationQuery);

            // Assert
            result.Should().HaveCount(2); // Two records in the first page
        }

        [Fact]
        public async Task GetFaqsBySearchAsync_ShouldFilterFaqsBasedOnSearchCriteria()
        {
            // Arrange
            var faqs = new List<AdminFaq>
            {
                new AdminFaq { Header = "Header 1", Platforms = "Platform1", Users = "User1", IsActive = true },
                new AdminFaq { Header = "Header 2", Platforms = "Platform2", Users = "User2", IsActive = false }
            };

            await _context.AdminFaqs.AddRangeAsync(faqs);
            await _context.SaveChangesAsync();

            var selectedPlatforms = new List<string> { "Platform1" };
            var selectedUsers = new List<string> { "User1" };
            var headerText = "Header 1";
            var selectedStatus = true;

            // Act
            var result = await _repository.GetFaqsBySearchAsync(selectedPlatforms, selectedUsers, headerText, selectedStatus);

            // Assert
            result.Should().ContainSingle(); // Only one FAQ matches all criteria
            result.FirstOrDefault()?.Header.Should().Be("Header 1");
        }
    }
}
