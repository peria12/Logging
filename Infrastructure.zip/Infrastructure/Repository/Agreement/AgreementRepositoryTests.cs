﻿using Aurora.AdministrationService.Infrastructure.Repository;
using Microsoft.EntityFrameworkCore;
using FluentAssertions;
using Aurora.AdministrationService.Infrastructure;
using Aurora.AdministrationService.CrossCutting.Extensions;
using Aurora.AdministrationService.Domain.Old.Entities;

namespace Aurora.AdministrationService.Tests.Repositories.Agreements
{
    /// <summary>
    /// Unit tests for <see cref="AgreementRepository"/> class.
    /// </summary>
    public class AgreementRepositoryTests
    {
        private readonly ReadWriteDbContext _context;
        private readonly AgreementRepository _repository;

        /// <summary>
        /// Initializes a new instance of the <see cref="AgreementRepositoryTests"/> class.
        /// Sets up in-memory database and repository instance for testing.
        /// </summary>
        public AgreementRepositoryTests()
        {

            // Setup in-memory database for testing
            var options = new DbContextOptionsBuilder<ReadWriteDbContext>()
                .UseInMemoryDatabase(databaseName: Guid.NewGuid().ToString().Replace("-", "_"))
                .Options;

            _context = new ReadWriteDbContext(options);

            _repository = new AgreementRepository(_context);
        }

        /// <summary>
        /// Tests that <see cref="AgreementRepository.GetAgreementByIdAsync"/> returns an agreement
        /// when it exists in the database.
        /// </summary>
        [Fact]
        public async Task GetAgreementByIdAsync_ShouldReturnAgreement_WhenAgreementExists()
        {
            // Arrange: Seed the database with an agreement.
            var agreement = new Aurora.AdministrationService.Domain.Old.Entities.Agreement { Id = 222, Name = "Test Agreement", AgreementText = "Test Agreement Text", AgreementUniqueId = "TestUniuqID" };
            await _context.Agreements.AddAsync(agreement);
            await _context.SaveChangesAsync();

            // Act: Retrieve the agreement by ID.
            var result = await _repository.GetAgreementByIdAsync(222);

            // Assert: Verify the agreement is retrieved correctly.
            result.Should().NotBeNull();
            result.Should().BeEquivalentTo(agreement);
        }

        /// <summary>
        /// Tests that <see cref="AgreementRepository.GetAgreementByIdAsync"/> returns null
        /// when the agreement does not exist in the database.
        /// </summary>
        [Fact]
        public async Task GetAgreementByIdAsync_ShouldReturnNull_WhenAgreementDoesNotExist()
        {
            // Act: Try to retrieve an agreement that doesn't exist.
            var result = await _repository.GetAgreementByIdAsync(999);

            // Assert: Verify that no agreement is returned.
            result.Should().BeNull();
        }

        /// <summary>
        /// Tests that <see cref="AgreementRepository.AddAgreementAsync"/> adds an agreement successfully.
        /// </summary>
        [Fact]
        public async Task AddAgreementAsync_ShouldAddAgreement()
        {
            // Arrange: Create a new agreement.
            var newAgreement = new Aurora.AdministrationService.Domain.Old.Entities.Agreement { Name = "New Agreement", AgreementText = "Test Agreement Text", AgreementUniqueId = "TestUniuqID" };

            // Act: Add the new agreement to the database.
            await _repository.AddAgreementAsync(newAgreement);

            // Assert: Verify the agreement was added successfully.
            var addedAgreement = await _context.Agreements.FirstOrDefaultAsync(a => a.Name == "New Agreement");
            addedAgreement.Should().NotBeNull();
        }

        /// <summary>
        /// Tests that <see cref="AgreementRepository.DeleteAgreementAsync"/> deletes an agreement successfully.
        /// </summary>
        [Fact]
        public async Task DeleteAgreementAsync_ShouldDeleteAgreement_WhenAgreementExists()
        {
            // Arrange: Seed the database with an agreement to delete.
            var agreement = new Aurora.AdministrationService.Domain.Old.Entities.Agreement { Id = 111, Name = "Test Agreement", AgreementText = "Test Agreement Text", AgreementUniqueId = "TestUniuqID" };
            await _context.Agreements.AddAsync(agreement);
            await _context.SaveChangesAsync();

            // Act: Delete the agreement.
            var result = await _repository.DeleteAgreementAsync(111);

            // Assert: Verify the agreement was deleted.
            result.Should().Be(1); // 1 record deleted
            var deletedAgreement = await _context.Agreements.FindAsync(111);
            deletedAgreement.Should().BeNull();
        }

        /// <summary>
        /// Tests that <see cref="AgreementRepository.DeleteAgreementAsync"/> returns zero
        /// when the agreement does not exist.
        /// </summary>
        [Fact]
        public async Task DeleteAgreementAsync_ShouldReturnZero_WhenAgreementDoesNotExist()
        {
            // Act: Try to delete a non-existent agreement.
            var result = await _repository.DeleteAgreementAsync(999);

            // Assert: Verify that no records were deleted.
            result.Should().Be(0);
        }

        /// <summary>
        /// Tests that <see cref="AgreementRepository.GetAgreementsAsync"/> returns all agreements.
        /// </summary>
        [Fact]
        public async Task GetAgreementsAsync_ShouldReturnAllAgreements()
        {
            // Arrange: Seed the database with multiple agreements.
            var agreements = new List<Agreement>
            {
                new Aurora.AdministrationService.Domain.Old.Entities.Agreement { Id = 1, Name = "Agreement 1", AgreementText ="Test Agreement Text", AgreementUniqueId = "TestUniuqID" },
                new Aurora.AdministrationService.Domain.Old.Entities.Agreement { Id = 2, Name = "Agreement 2", AgreementText ="Test Agreement Text", AgreementUniqueId = "TestUniuqID" }
            };
            await _context.Agreements.AddRangeAsync(agreements);
            await _context.SaveChangesAsync();

            var paginationQuery = new PaginationQuery { PageNumber = 1, PageSize = 10 };

            // Act: Retrieve the agreements.
            var result = await _repository.GetAgreementsAsync(paginationQuery);

            // Assert: Verify all agreements were returned.
            result.Should().BeEquivalentTo(agreements);
        }




        [Fact]
        public async Task GetAgreementByLanguageAsync_ShouldReturnAgreement_WhenLanguageMatches()
        {
            // Arrange

            var agreement = new Agreement { AgreementUniqueId = "123", Language = "en", AgreementText = "English Agreement" };
            _context.Agreements.Add(agreement);
            await _context.SaveChangesAsync();

            // Act
            var result = await _repository.GetAgreementByLanguageAsync("123", "en");

            // Assert
            result.Should().NotBeNull();
            result?.AgreementUniqueId.Should().Be("123");
            result?.Language.Should().Be("en");
        }

        [Fact]
        public async Task GetAgreementByIdAsync_ShouldReturnAgreement_WhenExists()
        {
            // Arrange


            var agreement = new Agreement { Id = 1, AgreementUniqueId = "1", AgreementText = "Sample Agreement" };
            _context.Agreements.Add(agreement);
            await _context.SaveChangesAsync();

            // Act
            var result = await _repository.GetAgreementByIdAsync(1);

            // Assert
            result.Should().NotBeNull();
            result?.Id.Should().Be(1);
            result?.AgreementText.Should().Be("Sample Agreement");
        }

        [Fact]
        public async Task AddAgreementAsync_ShouldAddAgreementToDatabase()
        {

            var newAgreement = new Agreement { Id = 1, AgreementUniqueId = "4545", AgreementText = "Test Agreement" };

            // Act
            var rowsAffected = await _repository.AddAgreementAsync(newAgreement);

            // Assert
            rowsAffected.Should().Be(1);
            _context.Agreements.Should().ContainSingle(a => a.Id == 1 && a.AgreementText == "Test Agreement");
        }
        [Fact]
        public async Task UpdateAgreementAsync_ShouldUpdateExistingAgreement()
        {
            // Arrange

            var agreement = new Agreement { Id = 1, AgreementText = "Old Text", AgreementUniqueId = "4547" };
            _context.Agreements.Add(agreement);
            await _context.SaveChangesAsync();

            // Act
            agreement.AgreementText = "Updated Text";
            var rowsAffected = await _repository.UpdateAgreementAsync(agreement);

            // Assert
            rowsAffected.Should().Be(1);
            var updatedAgreement = _context.Agreements.FirstOrDefault(a => a.Id == 1);
            updatedAgreement.Should().NotBeNull();
            updatedAgreement?.AgreementText.Should().Be("Updated Text");
        }

        [Fact]
        public async Task DeleteAgreementAsync_ShouldRemoveAgreementFromDatabase()
        {
            // Arrange

            var agreement = new Agreement { Id = 4, AgreementUniqueId = "4", AgreementText = "delete test" };
            _context.Agreements.Add(agreement);
            await _context.SaveChangesAsync();

            // Act
            var rowsAffected = await _repository.DeleteAgreementAsync(4);

            // Assert
            rowsAffected.Should().Be(1);
            _context.Agreements.Should().BeEmpty();
        }

        [Fact]
        public async Task GetAgreementListAsync_ShouldReturnFilteredAgreementsByLanguage()
        {
            // Arrange

            _context.Agreements.AddRange(
                new Agreement { Id = 1, Language = "en", AgreementUniqueId = "23", AgreementText = "test" },
                new Agreement { Id = 2, Language = "fr", AgreementUniqueId = "24", AgreementText = "test" }
            );
            await _context.SaveChangesAsync();

            // Act
            var result = await _repository.GetAgreementListAsync("en");

            // Assert
            result.Should().NotBeNull();
            result.Should().HaveCount(1);
            result.First().Language.Should().Be("en");
        }

        [Fact]
        public async Task UpdateAgreementStatusAsync_ShouldUpdateIsActiveField()
        {
            // Arrange
            var agreement = new Agreement { AgreementUniqueId = "123", AgreementText = "sample", Language = "en", IsActive = false };
            _context.Agreements.Add(agreement);
            await _context.SaveChangesAsync();

            // Act
            var rowsAffected = await _repository.UpdateAgreementStatusAsync("123", "en", true);

            // Assert
            rowsAffected.Should().Be(1);
            var updatedAgreement = _context.Agreements.FirstOrDefault(a => a.AgreementUniqueId == "123" && a.Language == "en");
            updatedAgreement.Should().NotBeNull();
            updatedAgreement?.IsActive.Should().BeTrue();
        }

    }
}
