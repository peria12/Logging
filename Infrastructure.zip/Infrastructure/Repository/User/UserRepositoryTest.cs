﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Aurora.AdministrationService.Domain.Entities;
using Aurora.AdministrationService.Infrastructure.Repository;
using Aurora.AdministrationService.Infrastructure;
using Microsoft.EntityFrameworkCore;
using Aurora.AdministrationService.Domain.Old.Entities;

namespace Aurora.AdministrationService.Tests.Infrastructure.Repository.User
{
    public class UserRepositoryTest
    {
        [Fact]
        public async Task GetUser_ShouldReturnUser_WhenCredentialsAreValid()
        {
            // Arrange
            var options = new DbContextOptionsBuilder<ReadWriteDbContext>()
                .UseInMemoryDatabase("GetUser_Valid")
                .Options;

            var testUser = new AdminUser { Username = "admin", Password = "password123", Email="test@gmail.com", FirstName="Test", LastName="Test1", Role="Admin" };

            using (var context = new ReadWriteDbContext(options))
            {
                context.AdminUsers.Add(testUser);
                await context.SaveChangesAsync();
            }

            using (var context = new ReadWriteDbContext(options))
            {
                var repo = new UserRepository(context);
                var inputUser = new AdminUser { Username = "admin", Password = "password123" };

                // Act
                var result = await repo.GetUser(inputUser);

                // Assert
                Assert.NotNull(result);
                Assert.Equal("admin", result.Username);
            }
        }

        [Fact]
        public async Task GetUser_ShouldThrowException_WhenPasswordIsIncorrect()
        {
            // Arrange
            var options = new DbContextOptionsBuilder<ReadWriteDbContext>()
                .UseInMemoryDatabase("GetUser_InvalidPassword")
                .Options;

            var testUser = new AdminUser {Username = "admin", Password = "password123", Email = "test@gmail.com", FirstName = "Test", LastName = "Test1", Role = "Admin" };

            using (var context = new ReadWriteDbContext(options))
            {
                context.AdminUsers.Add(testUser);
                await context.SaveChangesAsync();
            }

            using (var context = new ReadWriteDbContext(options))
            {
                var repo = new UserRepository(context);
                var inputUser = new AdminUser { Username = "admin", Password = "wrongpassword" };

                // Act & Assert
                var exception = await Assert.ThrowsAsync<Exception>(() => repo.GetUser(inputUser));
                Assert.Equal("Invalid password. Retry Attempt Left ", exception.Message);
            }
        }

        [Fact]
        public async Task GetUser_ShouldReturnNull_WhenUserDoesNotExist()
        {
            // Arrange
            var options = new DbContextOptionsBuilder<ReadWriteDbContext>()
                .UseInMemoryDatabase("GetUser_NonExistent")
                .Options;

            using (var context = new ReadWriteDbContext(options))
            {
                var repo = new UserRepository(context);
                var inputUser = new AdminUser { Username = "admin", Password = "password123", Email = "test@gmail.com", FirstName = "Test", LastName = "Test1", Role = "Admin" };

                // Act
                var result = await repo.GetUser(inputUser);

                // Assert
                Assert.Null(result);
            }
        }
    }
}
