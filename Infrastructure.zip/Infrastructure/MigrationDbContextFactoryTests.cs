﻿using Aurora.AdministrationService.Infrastructure;
using FluentAssertions;

namespace Aurora.AdministrationService.Tests.Infrastructure
{
    public class MigrationDbContextFactoryTests
    {
        [Fact]
        public void CreateDbContext_ShouldReturnInstanceOfMigrationDbContext()
        {
            // Arrange
            var factory = new MigrationDbContextFactory();

            // Act
            var dbContext = factory.CreateDbContext(Array.Empty<string>());

            // Assert
            dbContext.Should().NotBeNull();
            dbContext.Should().BeOfType<MigrationDbContext>();
        }
    }
}
