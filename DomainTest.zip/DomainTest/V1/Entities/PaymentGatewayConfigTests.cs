﻿using Aurora.AdministrationService.Domain.V1.Entities.PaymentGateways;

namespace Aurora.AdministrationService.Tests.DomainTest.V1.Entities
{
    public class PaymentGatewayConfigTests
    {
        [Fact]
        public void Can_Create_PaymentGatewayConfig_With_Required_Fields()
        {
            // Arrange
            var now = DateTime.UtcNow;
            var config = new PaymentGatewayConfig
            {
                Id = 1,
                PaymentGatewayID = 10,
                PaymentGatewayName = "PayTM",
                URL = "https://paytm.com/api",
                UseCredentials = true,
                UserID = "testuser",
                Password = "testpass",
                APIKey = "apikey123",
                IsDeleted = false,
                CreatedBy = "admin",
                CreatedDate = now,
                UpdatedBy = "admin2",
                UpdatedDate = now
            };

            // Assert
            Assert.Equal(1, config.Id);
            Assert.Equal(10, config.PaymentGatewayID);
            Assert.Equal("PayTM", config.PaymentGatewayName);
            Assert.Equal("https://paytm.com/api", config.URL);
            Assert.True(config.UseCredentials);
            Assert.Equal("testuser", config.UserID);
            Assert.Equal("testpass", config.Password);
            Assert.Equal("apikey123", config.APIKey);
            Assert.False(config.IsDeleted);
            Assert.Equal("admin", config.CreatedBy);
            Assert.Equal(now, config.CreatedDate);
            Assert.Equal("admin2", config.UpdatedBy);
            Assert.Equal(now, config.UpdatedDate);
        }

        [Fact]
        public void RecordVersion_Should_Be_Empty_By_Default()
        {
            // Arrange
            var config = new PaymentGatewayConfig
            {
                Id = 2,
                PaymentGatewayID = 20,
                PaymentGatewayName = "Razorpay",
                UseCredentials = false,
                IsDeleted = false,
                CreatedBy = "tester",
                CreatedDate = DateTime.UtcNow
            };

            // Assert
            Assert.NotNull(config.RecordVersion);
            Assert.Empty(config.RecordVersion);
        }

        [Fact]
        public void Can_Link_To_PaymentGateway_Entity()
        {
            // Arrange
            var gateway = new PaymentGateway
            {
                Id = 1,
                CreatedBy = "sys",
                CreatedDate = DateTime.UtcNow,
                IsDeleted = false
            };

            var config = new PaymentGatewayConfig
            {
                Id = 3,
                PaymentGatewayID = 1,
                PaymentGatewayName = "Stripe",
                UseCredentials = true,
                CreatedBy = "sys",
                CreatedDate = DateTime.UtcNow,
                IsDeleted = false,
                PaymentGateway = gateway
            };

            // Assert
            Assert.NotNull(config.PaymentGateway);
            Assert.Equal(1, config.PaymentGateway.Id);
            Assert.Equal("sys", config.PaymentGateway.CreatedBy);
        }
    }
}
