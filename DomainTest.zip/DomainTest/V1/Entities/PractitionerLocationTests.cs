﻿using Aurora.AdministrationService.Domain.V1.Entities.Practitioners;

namespace Aurora.AdministrationService.Tests.DomainTest.V1.Entities
{
    public class PractitionerLocationTests
    {
        [Fact]
        public void Can_Create_PractitionerLocation_With_Required_Fields()
        {
            // Arrange
            var now = DateTime.UtcNow;
            var practitionerLocation = new PractitionerLocation
            {
                Id = 1,
                PractitionerID = 12345,
                LocationID = 101,
                Status = true,
                IsInternalDoctor = false,
                ContractStartDate = now.AddDays(1),
                ContractEndDate = now.AddDays(2),
                IsDeleted = false,
                CreatedBy = "admin",
                CreatedDate = now,
                UpdatedBy = "admin2",
                UpdatedDate = now.AddDays(1)
            };

            // Assert
            Assert.Equal(1, practitionerLocation.Id);
            Assert.Equal(12345, practitionerLocation.PractitionerID);
            Assert.Equal(101, practitionerLocation.LocationID);
            Assert.True(practitionerLocation.Status);
            Assert.False(practitionerLocation.IsInternalDoctor);
            Assert.Equal(now.AddDays(1), practitionerLocation.ContractStartDate);
            Assert.Equal(now.AddDays(2), practitionerLocation.ContractEndDate);
            Assert.False(practitionerLocation.IsDeleted);
            Assert.Equal("admin", practitionerLocation.CreatedBy);
            Assert.Equal(now, practitionerLocation.CreatedDate);
            Assert.Equal("admin2", practitionerLocation.UpdatedBy);
            Assert.Equal(now.AddDays(1), practitionerLocation.UpdatedDate);
        }

        [Fact]
        public void RecordVersion_Should_Be_Empty_By_Default()
        {
            // Arrange
            var practitionerLocation = new PractitionerLocation
            {
                Id = 1,
                PractitionerID = 12345,
                LocationID = 101,
                Status = true,
                IsInternalDoctor = false,
                ContractStartDate = DateTime.UtcNow.AddDays(1),
                ContractEndDate = DateTime.UtcNow.AddDays(2),
                IsDeleted = false,
                CreatedBy = "admin",
                CreatedDate = DateTime.UtcNow
            };

            // Assert
            Assert.NotNull(practitionerLocation.RecordVersion);
            Assert.Empty(practitionerLocation.RecordVersion);
        }
        
        [Fact]
        public void ContractEndDate_Should_Be_Greater_Than_ContractStartDate()
        {
            // Arrange
            var practitionerLocation = new PractitionerLocation
            {
                Id = 1,
                PractitionerID = 12345,
                LocationID = 101,
                Status = true,
                IsInternalDoctor = false,
                ContractStartDate = DateTime.UtcNow.AddDays(3),
                ContractEndDate = DateTime.UtcNow.AddDays(2), // End date is before start date
                IsDeleted = false,
                CreatedBy = "admin",
                CreatedDate = DateTime.UtcNow
            };

            // Act
            var isValid = practitionerLocation.ContractEndDate > practitionerLocation.ContractStartDate;

            // Assert
            Assert.False(isValid); // End date should be after start date
        }
    }
}
