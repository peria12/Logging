﻿using Aurora.AdministrationService.Domain.V1.Entities.Users;
using FluentAssertions;

namespace Aurora.AdministrationService.Tests.DomainTest.V1.Entities
{
    public class UserTelecomTests
    {
        [Fact]
        public void Should_Create_UserTelecom_With_Required_Fields()
        {
            // Arrange
            var now = DateTime.UtcNow;

            var telecom = new UserTelecom
            {
                UserID = 123,
                System = "phone",
                Use = "mobile",
                Value = "+11234567890",
                IsDeleted = false,
                CreatedBy = "admin",
                UpdatedBy = "admin",
                CreatedDate = now
            };

            // Act & Assert
            telecom.UserID.Should().Be(123);
            telecom.System.Should().Be("phone");
            telecom.Use.Should().Be("mobile");
            telecom.Value.Should().Be("+11234567890");
            telecom.IsDeleted.Should().BeFalse();
            telecom.CreatedBy.Should().Be("admin");
            telecom.UpdatedBy.Should().Be("admin");
            telecom.CreatedDate.Should().Be(now);
            telecom.RecordVersion.Should().NotBeNull().And.BeEmpty();
        }

        [Fact]
        public void Should_Assign_Optional_Fields_If_Provided()
        {
            // Arrange
            var start = new DateTime(2023, 1, 1);
            var end = new DateTime(2024, 1, 1);

            var telecom = new UserTelecom
            {
                UserID = 456,
                System = "email",
                Use = "work",
                Value = "test@example.com",
                PhoneCountryCode = "+91",
                Status = true,
                Rank = 1,
                PeriodStart = start,
                PeriodEnd = end,
                CreatedBy = "admin",
                CreatedDate = DateTime.UtcNow,
                UpdatedBy = "admin",
                IsDeleted = false,
                UpdatedDate = DateTime.UtcNow
            };

            // Assert
            telecom.PhoneCountryCode.Should().Be("+91");
            telecom.Status.Should().BeTrue();
            telecom.Rank.Should().Be(1);
            telecom.PeriodStart.Should().Be(start);
            telecom.PeriodEnd.Should().Be(end);
            telecom.UpdatedDate.Should().NotBeNull();
        }

        [Fact]
        public void Should_Allow_Null_For_Optional_Fields()
        {
            // Arrange
            var telecom = new UserTelecom
            {
                UserID = 789,
                System = "email",
                Use = "home",
                Value = "abc@example.com",
                IsDeleted = false,
                CreatedBy = "system",
                CreatedDate = DateTime.UtcNow,
                UpdatedBy = "system"
            };

            // Assert
            telecom.PhoneCountryCode.Should().BeNull();
            telecom.Status.Should().BeNull();
            telecom.Rank.Should().BeNull();
            telecom.PeriodStart.Should().BeNull();
            telecom.PeriodEnd.Should().BeNull();
            telecom.UpdatedDate.Should().BeNull();
        }

        [Fact]
        public void Should_Associate_With_User_When_Set()
        {
            // Arrange
            var user = new User
            {
                UserName = "john_doe",
                Status = true,
                IsTempAccount = false,
                UserType = "Practitioner",
                NotificationsEnabled = true,
                BioAuthenticationEnabled = true,
                SOSButtonEnabled = true,
                IsDeleted = false,
                CreatedBy = "admin",
                CreatedDate = DateTime.UtcNow,
                UpdatedBy = "admin"
            };

            var telecom = new UserTelecom
            {
                UserID = user.Id,
                System = "phone",
                Use = "home",
                Value = "1234567890",
                CreatedBy = "admin",
                UpdatedBy = "admin",
                CreatedDate = DateTime.UtcNow,
                IsDeleted = false,
                User = user
            };

            // Assert
            telecom.User.Should().NotBeNull();
            telecom.User.Should().BeOfType<User>();
            telecom.User!.UserName.Should().Be("john_doe");
        }
    }
}
