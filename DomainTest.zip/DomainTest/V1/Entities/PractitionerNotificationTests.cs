﻿using Aurora.AdministrationService.Domain.V1.Entities.PractitionerNotifications;

namespace Aurora.AdministrationService.Tests.DomainTest.V1.Entities
{
    public class PractitionerNotificationTests
    {
        [Fact]
        public void Can_Create_PractitionerNotification_With_Required_Fields()
        {
            // Arrange
            var now = DateTime.UtcNow;
            var notification = new PractitionerNotification
            {
                Id = Guid.NewGuid(),
                PractitionerID = Guid.NewGuid(),
                PractitionerNotificationType = "Reminder",
                PractitionerNotificationTitle = "Test Notification",
                PractitionerNotificationAlertsText = "You have a new appointment.",
                PractitionerNotificationAlertDateTime = now,
                IsRead = false,
                IsDeleted = false,
                CreatedBy = "admin",
                CreatedDate = now,
                UpdatedBy = "admin2",
                UpdatedDate = now
            };

            // Assert           
            Assert.Equal("Reminder", notification.PractitionerNotificationType);
            Assert.Equal("Test Notification", notification.PractitionerNotificationTitle);
            Assert.Equal("You have a new appointment.", notification.PractitionerNotificationAlertsText);
            Assert.Equal(now, notification.PractitionerNotificationAlertDateTime);
            Assert.False(notification.IsRead);
            Assert.False(notification.IsDeleted);
            Assert.Equal("admin", notification.CreatedBy);
            Assert.Equal(now, notification.CreatedDate);
            Assert.Equal("admin2", notification.UpdatedBy);
            Assert.Equal(now, notification.UpdatedDate);
        }

        [Fact]
        public void RecordVersion_Should_Be_Empty_By_Default()
        {
            // Arrange
            var notification = new PractitionerNotification
            {
                Id = Guid.NewGuid(),
                PractitionerID = Guid.NewGuid(),
                PractitionerNotificationType = "Reminder",
                PractitionerNotificationTitle = "Test Notification",
                PractitionerNotificationAlertsText = "You have a new appointment.",
                PractitionerNotificationAlertDateTime = DateTime.UtcNow,
                IsRead = false,
                IsDeleted = false,
                CreatedBy = "admin",
                CreatedDate = DateTime.UtcNow
            };

            // Assert
            Assert.NotNull(notification.RecordVersion);
            Assert.Empty(notification.RecordVersion);
        }        
    }
}
