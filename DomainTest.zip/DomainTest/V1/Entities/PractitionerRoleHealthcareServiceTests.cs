﻿using Aurora.AdministrationService.Domain.V1.Entities.PractitionerRoles;

namespace Aurora.AdministrationService.Tests.DomainTest.V1.Entities
{
    public class PractitionerRoleHealthcareServiceTests
    {
        [Fact]
        public void Can_Create_PractitionerRoleHealthcareService_With_Required_Fields()
        {
            // Arrange
            var now = DateTime.UtcNow;
            var healthcareService = new PractitionerRoleHealthcareService
            {
                Id = 1,
                PractitionerRoleID = 12345,
                HealthcareServiceID = 67890,
                IsDeleted = false,
                CreatedBy = "admin",
                CreatedDate = now,
                UpdatedBy = "admin2",
                UpdatedDate = now
            };

            // Assert
            Assert.Equal(1, healthcareService.Id);
            Assert.Equal(12345, healthcareService.PractitionerRoleID);
            Assert.Equal(67890, healthcareService.HealthcareServiceID);
            Assert.False(healthcareService.IsDeleted);
            Assert.Equal("admin", healthcareService.CreatedBy);
            Assert.Equal(now, healthcareService.CreatedDate);
            Assert.Equal("admin2", healthcareService.UpdatedBy);
            Assert.Equal(now, healthcareService.UpdatedDate);
        }

        [Fact]
        public void RecordVersion_Should_Be_Empty_By_Default()
        {
            // Arrange
            var healthcareService = new PractitionerRoleHealthcareService
            {
                Id = 1,
                PractitionerRoleID = 12345,
                HealthcareServiceID = 67890,
                IsDeleted = false,
                CreatedBy = "admin",
                CreatedDate = DateTime.UtcNow
            };

            // Assert
            Assert.NotNull(healthcareService.RecordVersion);
            Assert.Empty(healthcareService.RecordVersion);
        }       
    }
}
