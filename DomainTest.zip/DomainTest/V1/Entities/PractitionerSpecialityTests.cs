﻿using Aurora.AdministrationService.Domain.V1.Entities.Practitioners;
using System.ComponentModel.DataAnnotations;

namespace Aurora.AdministrationService.Tests.DomainTest.V1.Entities
{
    public class PractitionerSpecialityTests
    {
        [Fact]
        public void Can_Create_PractitionerSpeciality_With_Required_Fields()
        {
            // Arrange
            var now = DateTime.UtcNow;
            var practitionerSpeciality = new PractitionerSpeciality
            {
                Id = 1,
                PractitionerID = 12345,
                Specialty = "Cardiology",
                Status = true,
                LocationID = 101,
                IsDeleted = false,
                CreatedBy = "admin",
                CreatedDate = now,
                UpdatedBy = "admin2",
                UpdatedDate = now.AddDays(1)
            };

            // Assert
            Assert.Equal(1, practitionerSpeciality.Id);
            Assert.Equal(12345, practitionerSpeciality.PractitionerID);
            Assert.Equal("Cardiology", practitionerSpeciality.Specialty);
            Assert.True(practitionerSpeciality.Status);
            Assert.Equal(101, practitionerSpeciality.LocationID);
            Assert.False(practitionerSpeciality.IsDeleted);
            Assert.Equal("admin", practitionerSpeciality.CreatedBy);
            Assert.Equal(now, practitionerSpeciality.CreatedDate);
            Assert.Equal("admin2", practitionerSpeciality.UpdatedBy);
            Assert.Equal(now.AddDays(1), practitionerSpeciality.UpdatedDate);
        }

        [Fact]
        public void RecordVersion_Should_Be_Empty_By_Default()
        {
            // Arrange
            var practitionerSpeciality = new PractitionerSpeciality
            {
                Id = 1,
                PractitionerID = 12345,
                Specialty = "Cardiology",
                Status = true,
                LocationID = 101,
                IsDeleted = false,
                CreatedBy = "admin",
                UpdatedBy = "admin",    
                CreatedDate = DateTime.UtcNow
            };

            // Assert
            Assert.NotNull(practitionerSpeciality.RecordVersion);
            Assert.Empty(practitionerSpeciality.RecordVersion);
        }       

        [Fact]
        public void Specialty_Should_Not_Exceed_MaxLength()
        {
            // Arrange
            var practitionerSpeciality = new PractitionerSpeciality
            {
                Id = 1,
                PractitionerID = 12345,
                Specialty = new string('A', 51), // Specialty exceeds the max length of 50
                Status = true,
                LocationID = 101,
                IsDeleted = false,
                CreatedBy = "Admin",
                UpdatedBy = "Admin",
                CreatedDate = DateTime.UtcNow,
            };

            var context = new ValidationContext(practitionerSpeciality, serviceProvider: null, items: null);
            var results = new List<ValidationResult>();

            // Act
            var isValid = Validator.TryValidateObject(practitionerSpeciality, context, results, true);

            // Assert
            Assert.False(isValid);
            Assert.Contains(results, r => r.MemberNames.Contains(nameof(PractitionerSpeciality.Specialty)));
        }       
    }
}
