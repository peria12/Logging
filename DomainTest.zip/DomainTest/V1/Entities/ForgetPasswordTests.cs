﻿using Aurora.AdministrationService.Domain.V1.Entities.Users;
using FluentAssertions;

namespace Aurora.AdministrationService.Tests.DomainTest.V1.Entities
{
    public class ForgetPasswordTests
    {
        [Fact]
        public void Should_Create_ForgetPassword_With_Required_Fields()
        {
            // Arrange
            var now = DateTime.UtcNow;

            var forgetPassword = new ForgetPassword
            {
                IsDeleted = false,
                CreatedBy = "admin",
                CreatedDate = now
            };

            // Assert
            forgetPassword.IsDeleted.Should().BeFalse();
            forgetPassword.CreatedBy.Should().Be("admin");
            forgetPassword.CreatedDate.Should().Be(now);
            forgetPassword.RecordVersion.Should().NotBeNull().And.BeEmpty();
        }

        [Fact]
        public void Should_Allow_Optional_Fields_To_Be_Null()
        {
            // Arrange
            var forgetPassword = new ForgetPassword
            {
                IsDeleted = true,
                CreatedBy = "system",
                CreatedDate = DateTime.UtcNow
            };

            // Assert
            forgetPassword.UserID.Should().BeNull();
            forgetPassword.RequestedDate.Should().BeNull();
            forgetPassword.UpdatedBy.Should().BeNull();
            forgetPassword.UpdatedDate.Should().BeNull();
            forgetPassword.User.Should().BeNull();
        }

        [Fact]
        public void Should_Set_Optional_Fields_When_Provided()
        {
            // Arrange
            var requestedDate = DateTime.UtcNow.AddHours(-1);
            var updatedDate = DateTime.UtcNow;

            var forgetPassword = new ForgetPassword
            {
                UserID = 123,
                RequestedDate = requestedDate,
                UpdatedBy = "admin",
                UpdatedDate = updatedDate,
                IsDeleted = false,
                CreatedBy = "admin",
                CreatedDate = DateTime.UtcNow
            };

            // Assert
            forgetPassword.UserID.Should().Be(123);
            forgetPassword.RequestedDate.Should().Be(requestedDate);
            forgetPassword.UpdatedBy.Should().Be("admin");
            forgetPassword.UpdatedDate.Should().Be(updatedDate);
        }

        [Fact]
        public void Should_Associate_With_User_When_Set()
        {
            // Arrange
            var user = new User
            {
                UserName = "forgot_user",
                Status = true,
                IsTempAccount = false,
                UserType = "Practitioner",
                NotificationsEnabled = true,
                BioAuthenticationEnabled = false,
                SOSButtonEnabled = false,
                IsDeleted = false,
                CreatedBy = "admin",
                CreatedDate = DateTime.UtcNow,
                UpdatedBy = "admin"
            };

            var forgetPassword = new ForgetPassword
            {
                UserID = user.Id,
                IsDeleted = false,
                CreatedBy = "admin",
                CreatedDate = DateTime.UtcNow,
                UpdatedBy = "admin",
                User = user
            };

            // Assert
            forgetPassword.User.Should().NotBeNull();
            forgetPassword.User!.UserName.Should().Be("forgot_user");
        }
    }
}
