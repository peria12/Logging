﻿using Aurora.AdministrationService.Domain.V1.Entities;

namespace Aurora.AdministrationService.Tests.DomainTest.V1.Entities
{
    public class ManageRankTests
    {
        [Fact]
        public void Can_Create_ManageRank_With_Required_Fields()
        {
            // Arrange
            var now = DateTime.UtcNow;
            var manageRank = new ManageRank
            {
                ID = 1,
                ManageDoctorProfileID = 1001,
                Status = true,
                IsDeleted = false,
                CreatedBy = "AdminUser",
                CreatedDate = now,
                UpdatedBy = "AdminUser",
                UpdatedDate = now,
                RecordVersion = new byte[] { 0x01, 0x02 }
            };

            // Assert
            Assert.Equal(1, manageRank.ID);
            Assert.Equal(1001, manageRank.ManageDoctorProfileID);
            Assert.True(manageRank.Status);
            Assert.False(manageRank.IsDeleted);
            Assert.Equal("AdminUser", manageRank.CreatedBy);
            Assert.Equal(now, manageRank.CreatedDate);
            Assert.Equal("AdminUser", manageRank.UpdatedBy);
            Assert.Equal(now, manageRank.UpdatedDate);
            Assert.Equal(new byte[] { 0x01, 0x02 }, manageRank.RecordVersion);
            Assert.Null(manageRank.ManageDoctorProfile);
        }       

        [Fact]
        public void RecordVersion_Can_Be_Empty_Or_Set()
        {
            // Arrange
            var emptyVersion = new ManageRank
            {
                ID = 3,
                ManageDoctorProfileID = 1010,
                Status = true,
                IsDeleted = false,
                CreatedBy = "Tester",
                CreatedDate = DateTime.UtcNow,
                UpdatedBy = "Tester",
                UpdatedDate = DateTime.UtcNow
            };

            var setVersion = new ManageRank
            {
                ID = 4,
                ManageDoctorProfileID = 2020,
                Status = true,
                IsDeleted = false,
                CreatedBy = "Tester",
                CreatedDate = DateTime.UtcNow,
                UpdatedBy = "Tester",
                UpdatedDate = DateTime.UtcNow,
                RecordVersion = new byte[] { 1, 2, 3 }
            };

            // Assert
            Assert.Empty(emptyVersion.RecordVersion);
            Assert.Equal(new byte[] { 1, 2, 3 }, setVersion.RecordVersion);
        }
    }
}
