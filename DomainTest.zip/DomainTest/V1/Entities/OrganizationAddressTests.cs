﻿using Aurora.AdministrationService.Domain.V1.Entities.Organizations;

namespace Aurora.AdministrationService.Tests.DomainTest.V1.Entities
{
    public class OrganizationAddressTests
    {
        [Fact]
        public void Can_Create_OrganizationAddress_With_Required_Fields()
        {
            // Arrange
            var now = DateTime.UtcNow;
            var orgAddress = new OrganizationAddress
            {
                Id = 1,
                OrganizationID = 1234,
                Use = "home",
                Type = "physical",
                Line1 = "123 Main Street",
                Line2 = "Suite 100",
                Line3 = "Block A",
                Line4 = "Near Central Park",
                City = "Metropolis",
                State = "New York",
                District = "Central",
                PostalCode = "10001",
                Country = "USA",
                PeriodStart = now.AddYears(-1),
                PeriodEnd = now.AddYears(1),
                RecordVersion = new byte[] { 0x01, 0x02 },
                IsDeleted = false,
                CreatedBy = "System",
                CreatedDate = now,
                UpdatedBy = "System",
                UpdatedDate = now
            };

            // Assert
            Assert.Equal(1, orgAddress.Id);
            Assert.Equal(1234, orgAddress.OrganizationID);
            Assert.Equal("home", orgAddress.Use);
            Assert.Equal("physical", orgAddress.Type);
            Assert.Equal("123 Main Street", orgAddress.Line1);
            Assert.Equal("Suite 100", orgAddress.Line2);
            Assert.Equal("Block A", orgAddress.Line3);
            Assert.Equal("Near Central Park", orgAddress.Line4);
            Assert.Equal("Metropolis", orgAddress.City);
            Assert.Equal("New York", orgAddress.State);
            Assert.Equal("Central", orgAddress.District);
            Assert.Equal("10001", orgAddress.PostalCode);
            Assert.Equal("USA", orgAddress.Country);
            Assert.False(orgAddress.IsDeleted);
            Assert.Equal("System", orgAddress.CreatedBy);
            Assert.Equal(now, orgAddress.CreatedDate);
            Assert.Equal("System", orgAddress.UpdatedBy);
            Assert.Equal(now, orgAddress.UpdatedDate);
            Assert.Equal(new byte[] { 0x01, 0x02 }, orgAddress.RecordVersion);
        }
       
        [Fact]
        public void RecordVersion_Defaults_To_Empty_ByteArray()
        {
            // Arrange
            var address = new OrganizationAddress
            {
                Id = 2,
                OrganizationID = 2000,
                Use = "temp",
                CreatedBy = "Tester",
                CreatedDate = DateTime.UtcNow,
                IsDeleted = false
            };

            // Assert
            Assert.NotNull(address.RecordVersion);
            Assert.Empty(address.RecordVersion);
        }
    }
    
}
