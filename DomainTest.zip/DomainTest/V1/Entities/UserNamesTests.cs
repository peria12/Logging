﻿using Aurora.AdministrationService.Domain.V1.Entities.Users;
using FluentAssertions;

namespace Aurora.AdministrationService.Tests.DomainTest.V1.Entities
{
    public class UserNamesTests
    {
        [Fact]
        public void Should_Create_UserNames_With_Required_Fields()
        {
            // Arrange
            var now = DateTime.UtcNow;

            var userName = new UserNames
            {
                UserID = 1001,
                IsDeleted = false,
                CreatedBy = "admin",
                CreatedDate = now,
                UpdatedBy = "admin"
            };

            // Act & Assert
            userName.UserID.Should().Be(1001);
            userName.IsDeleted.Should().BeFalse();
            userName.CreatedBy.Should().Be("admin");
            userName.UpdatedBy.Should().Be("admin");
            userName.CreatedDate.Should().Be(now);
            userName.RecordVersion.Should().NotBeNull().And.BeEmpty();
        }

        [Fact]
        public void Should_Assign_Optional_Fields_If_Provided()
        {
            // Arrange
            var start = new DateTime(2020, 1, 1);
            var end = new DateTime(2025, 12, 31);

            var userName = new UserNames
            {
                UserID = 1002,
                NameUse = "official",
                Status = true,
                FamilyName = "Doe",
                GivenName = "John",
                MiddleName = "X",
                Prefix = "Mr.",
                Suffix = "Jr.",
                PeriodStart = start,
                PeriodEnd = end,
                IsDeleted = false,
                CreatedBy = "admin",
                CreatedDate = DateTime.UtcNow,
                UpdatedBy = "system"
            };

            // Assert
            userName.NameUse.Should().Be("official");
            userName.Status.Should().BeTrue();
            userName.FamilyName.Should().Be("Doe");
            userName.GivenName.Should().Be("John");
            userName.MiddleName.Should().Be("X");
            userName.Prefix.Should().Be("Mr.");
            userName.Suffix.Should().Be("Jr.");
            userName.PeriodStart.Should().Be(start);
            userName.PeriodEnd.Should().Be(end);
        }

        [Fact]
        public void Should_Allow_Null_Optional_Fields()
        {
            // Arrange
            var userName = new UserNames
            {
                UserID = 1003,
                IsDeleted = true,
                CreatedBy = "admin",
                CreatedDate = DateTime.UtcNow,
                UpdatedBy = "admin"
            };

            // Act & Assert
            userName.NameUse.Should().BeNull();
            userName.Status.Should().BeNull();
            userName.FamilyName.Should().BeNull();
            userName.GivenName.Should().BeNull();
            userName.MiddleName.Should().BeNull();
            userName.Prefix.Should().BeNull();
            userName.Suffix.Should().BeNull();
            userName.PeriodStart.Should().BeNull();
            userName.PeriodEnd.Should().BeNull();
        }

        [Fact]
        public void Should_Associate_With_User_Entity_When_Set()
        {
            // Arrange
            var user = new User
            {
                UserName = "jane_doe",
                Status = true,
                IsTempAccount = false,
                UserType = "Practitioner",
                NotificationsEnabled = true,
                BioAuthenticationEnabled = true,
                SOSButtonEnabled = true,
                IsDeleted = false,
                CreatedBy = "admin",
                CreatedDate = DateTime.UtcNow,
                UpdatedBy = "admin"
            };

            var userName = new UserNames
            {
                UserID = user.Id,
                IsDeleted = false,
                CreatedBy = "admin",
                CreatedDate = DateTime.UtcNow,
                UpdatedBy = "admin",
                User = user
            };

            // Act & Assert
            userName.User.Should().NotBeNull();
            userName.User.Should().BeOfType<User>();
            userName.User!.UserName.Should().Be("jane_doe");
        }
    }
}
