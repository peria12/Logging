﻿using Aurora.AdministrationService.Domain.V1.Entities.Locations;

namespace Aurora.AdministrationService.Tests.DomainTest.V1.Entities
{
    public class LocationHoursOfOperationTests
    {
        [Fact]
        public void Can_Create_LocationHoursOfOperation_With_Required_Fields()
        {
            // Arrange
            var now = DateTime.UtcNow;
            var entity = new LocationHoursOfOperation
            {
                Id = 1,
                LocationID = 1001,
                DaysOfWeek = "Monday",
                AllDay = false,
                OpeningTime = new TimeSpan(8, 0, 0),
                ClosingTime = new TimeSpan(17, 0, 0),
                Status = true,
                IsDeleted = false,
                CreatedBy = "Admin",
                CreatedDate = now
            };

            // Assert
            Assert.Equal(1, entity.Id);
            Assert.Equal(1001, entity.LocationID);
            Assert.Equal("Monday", entity.DaysOfWeek);
            Assert.False(entity.AllDay);
            Assert.Equal(new TimeSpan(8, 0, 0), entity.OpeningTime);
            Assert.Equal(new TimeSpan(17, 0, 0), entity.ClosingTime);
            Assert.True(entity.Status);
            Assert.False(entity.IsDeleted);
            Assert.Equal("Admin", entity.CreatedBy);
            Assert.Equal(now, entity.CreatedDate);
            Assert.Empty(entity.RecordVersion); // default
            Assert.Null(entity.UpdatedBy);
            Assert.Null(entity.UpdatedDate);
            Assert.Null(entity.Location);
        }

        [Fact]
        public void Can_Update_LocationHoursOfOperation_Properties()
        {
            // Arrange
            var entity = new LocationHoursOfOperation
            {
                Id = 2,
                LocationID = 1002,
                DaysOfWeek = "Tuesday",
                AllDay = true,
                OpeningTime = TimeSpan.Zero,
                ClosingTime = TimeSpan.Zero,
                Status = true,
                IsDeleted = false,
                CreatedBy = "System",
                CreatedDate = DateTime.UtcNow
            };

            // Act
            entity.DaysOfWeek = "Wednesday";
            entity.AllDay = false;
            entity.OpeningTime = new TimeSpan(9, 0, 0);
            entity.ClosingTime = new TimeSpan(18, 0, 0);
            entity.UpdatedBy = "Updater";
            entity.UpdatedDate = DateTime.UtcNow;
            entity.RecordVersion = new byte[] { 1, 2, 3 };

            // Assert
            Assert.Equal("Wednesday", entity.DaysOfWeek);
            Assert.False(entity.AllDay);
            Assert.Equal(new TimeSpan(9, 0, 0), entity.OpeningTime);
            Assert.Equal(new TimeSpan(18, 0, 0), entity.ClosingTime);
            Assert.Equal("Updater", entity.UpdatedBy);
            Assert.NotNull(entity.UpdatedDate);
            Assert.Equal(new byte[] { 1, 2, 3 }, entity.RecordVersion);
        }
    }
     
}
