﻿using Aurora.AdministrationService.Domain.V1.Entities.Users;
using FluentAssertions;

namespace Aurora.AdministrationService.Tests.DomainTest.V1.Entities
{
    public class UserIdentifierTests
    {
        [Fact]
        public void Should_Create_UserIdentifier_With_Required_Fields()
        {
            // Arrange
            var now = DateTime.UtcNow;

            var identifier = new UserIdentifier
            {
                UserID = 101,
                System = "passport",
                Value = "X1234567",
                Status = true,
                IsDeleted = false,
                CreatedBy = "admin",
                CreatedDate = now,
                UpdatedBy = "admin"
            };

            // Act & Assert
            identifier.UserID.Should().Be(101);
            identifier.System.Should().Be("passport");
            identifier.Value.Should().Be("X1234567");
            identifier.Status.Should().BeTrue();
            identifier.IsDeleted.Should().BeFalse();
            identifier.CreatedBy.Should().Be("admin");
            identifier.UpdatedBy.Should().Be("admin");
            identifier.CreatedDate.Should().Be(now);
            identifier.RecordVersion.Should().NotBeNull().And.BeEmpty();
        }

        [Fact]
        public void Should_Assign_Optional_Fields_When_Provided()
        {
            // Arrange
            var start = new DateTime(2022, 5, 1);
            var end = new DateTime(2025, 5, 1);

            var identifier = new UserIdentifier
            {
                UserID = 102,
                System = "nationalid",
                Value = "NID-98765",
                Status = true,
                IdentifierUse = "official",
                IdentifierType = "NID",
                PeriodStart = start,
                PeriodEnd = end,
                IsDeleted = false,
                CreatedBy = "system",
                CreatedDate = DateTime.UtcNow,
                UpdatedBy = "system"
            };

            // Assert
            identifier.IdentifierUse.Should().Be("official");
            identifier.IdentifierType.Should().Be("NID");
            identifier.PeriodStart.Should().Be(start);
            identifier.PeriodEnd.Should().Be(end);
        }

        [Fact]
        public void Should_Allow_Null_For_Optional_Fields()
        {
            // Arrange
            var identifier = new UserIdentifier
            {
                UserID = 103,
                System = "insurance",
                Value = "INS-445566",
                Status = false,
                IsDeleted = true,
                CreatedBy = "admin",
                CreatedDate = DateTime.UtcNow,
                UpdatedBy = "admin"
            };

            // Assert
            identifier.IdentifierUse.Should().BeNull();
            identifier.IdentifierType.Should().BeNull();
            identifier.PeriodStart.Should().BeNull();
            identifier.PeriodEnd.Should().BeNull();
            identifier.UpdatedDate.Should().BeNull();
        }

        [Fact]
        public void Should_Associate_With_User_When_Set()
        {
            // Arrange
            var user = new User
            {
                UserName = "test_user",
                Status = true,
                IsTempAccount = false,
                UserType = "Admin",
                NotificationsEnabled = true,
                BioAuthenticationEnabled = true,
                SOSButtonEnabled = false,
                IsDeleted = false,
                CreatedBy = "creator",
                CreatedDate = DateTime.UtcNow,
                UpdatedBy = "creator"
            };

            var identifier = new UserIdentifier
            {
                UserID = user.Id,
                System = "license",
                Value = "LIC-7777",
                Status = true,
                IsDeleted = false,
                CreatedBy = "admin",
                CreatedDate = DateTime.UtcNow,
                UpdatedBy = "admin",
                User = user
            };

            // Assert
            identifier.User.Should().NotBeNull();
            identifier.User!.UserName.Should().Be("test_user");
        }
    }
}
