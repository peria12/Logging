﻿using Aurora.AdministrationService.Domain.V1.Entities.Locations;

namespace Aurora.AdministrationService.Tests.DomainTest.V1.Entities
{
    public class LocationIdentifierTests
    {
        [Fact]
        public void Can_Create_LocationIdentifier_With_Required_Fields()
        {
            // Arrange
            var now = DateTime.UtcNow;
            var identifier = new LocationIdentifier
            {
                Id = 1,
                LocationID = 101,
                System = "EMR",
                value = "LOC-001",
                Status = true,
                IsDeleted = false,
                CreatedBy = "Admin",
                CreatedDate = now,              
            };

            // Assert
            Assert.Equal(1, identifier.Id);
            Assert.Equal(101, identifier.LocationID);
            Assert.Equal("EMR", identifier.System);
            Assert.Equal("LOC-001", identifier.value);
            Assert.True(identifier.Status);
            Assert.False(identifier.IsDeleted);
            Assert.Equal("Admin", identifier.CreatedBy);
            Assert.Equal(now, identifier.CreatedDate);            
            Assert.Null(identifier.IdentifierType);
            Assert.Null(identifier.IdentifierUse);
            Assert.Null(identifier.UpdatedBy);
            Assert.Null(identifier.UpdatedDate);
            Assert.Null(identifier.Assigner);
            Assert.Null(identifier.Location);
            Assert.Empty(identifier.RecordVersion);
        }

        [Fact]
        public void Can_Update_LocationIdentifier_Optional_Fields()
        {
            // Arrange
            var identifier = new LocationIdentifier
            {
                Id = 2,
                LocationID = 202,
                System = "HRIS",
                value = "LOC-999",
                Status = false,
                IsDeleted = true,
                CreatedBy = "Creator",
                CreatedDate = DateTime.UtcNow,
                PeriodStart = DateTime.UtcNow.AddYears(-1),
                PeriodEnd = DateTime.UtcNow.AddYears(1)
            };

            // Act
            identifier.IdentifierUse = "official";
            identifier.IdentifierType = "site-code";
            identifier.Assigner = "HQ";
            identifier.UpdatedBy = "Editor";
            identifier.UpdatedDate = DateTime.UtcNow;
            identifier.RecordVersion = new byte[] { 10, 20 };

            // Assert
            Assert.Equal("official", identifier.IdentifierUse);
            Assert.Equal("site-code", identifier.IdentifierType);
            Assert.Equal("HQ", identifier.Assigner);
            Assert.Equal("Editor", identifier.UpdatedBy);
            Assert.NotNull(identifier.UpdatedDate);
            Assert.Equal(new byte[] { 10, 20 }, identifier.RecordVersion);
        }
    }
}
