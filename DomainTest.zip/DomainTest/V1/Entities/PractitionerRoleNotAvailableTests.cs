﻿using Aurora.AdministrationService.Domain.V1.Entities.PractitionerRoles;

namespace Aurora.AdministrationService.Tests.DomainTest.V1.Entities
{
    public class PractitionerRoleNotAvailableTests
    {
        [Fact]
        public void Can_Create_PractitionerRoleNotAvailable_With_Required_Fields()
        {
            // Arrange
            var now = DateTime.UtcNow;
            var practitionerRoleNotAvailable = new PractitionerRoleNotAvailable
            {
                Id = 1,
                PractitionerRoleID = 12345,
                Description = "Not available for a specific time",
                NotAvailableStartTime = now.AddDays(1),
                NotAvailableEndTime = now.AddDays(2),
                IsDeleted = false,
                CreatedBy = "admin",
                CreatedDate = now,
                UpdatedBy = "admin2",
                UpdatedDate = now.AddDays(1)
            };

            // Assert
            Assert.Equal(1, practitionerRoleNotAvailable.Id);
            Assert.Equal(12345, practitionerRoleNotAvailable.PractitionerRoleID);
            Assert.Equal("Not available for a specific time", practitionerRoleNotAvailable.Description);
            Assert.Equal(now.AddDays(1), practitionerRoleNotAvailable.NotAvailableStartTime);
            Assert.Equal(now.AddDays(2), practitionerRoleNotAvailable.NotAvailableEndTime);
            Assert.False(practitionerRoleNotAvailable.IsDeleted);
            Assert.Equal("admin", practitionerRoleNotAvailable.CreatedBy);
            Assert.Equal(now, practitionerRoleNotAvailable.CreatedDate);
            Assert.Equal("admin2", practitionerRoleNotAvailable.UpdatedBy);
            Assert.Equal(now.AddDays(1), practitionerRoleNotAvailable.UpdatedDate);
        }

        [Fact]
        public void RecordVersion_Should_Be_Empty_By_Default()
        {
            // Arrange
            var practitionerRoleNotAvailable = new PractitionerRoleNotAvailable
            {
                Id = 1,
                PractitionerRoleID = 12345,
                Description = "Not available for a specific time",
                NotAvailableStartTime = DateTime.UtcNow.AddDays(1),
                NotAvailableEndTime = DateTime.UtcNow.AddDays(2),
                IsDeleted = false,
                CreatedBy = "admin",
                CreatedDate = DateTime.UtcNow
            };

            // Assert
            Assert.NotNull(practitionerRoleNotAvailable.RecordVersion);
            Assert.Empty(practitionerRoleNotAvailable.RecordVersion);
        }       

        [Fact]
        public void NotAvailableEndTime_Should_Be_Greater_Than_NotAvailableStartTime()
        {
            // Arrange
            var practitionerRoleNotAvailable = new PractitionerRoleNotAvailable
            {
                Id = 1,
                PractitionerRoleID = 12345,
                Description = "Not available for a specific time",
                NotAvailableStartTime = DateTime.UtcNow.AddDays(3),
                NotAvailableEndTime = DateTime.UtcNow.AddDays(2), // End time is before Start time
                IsDeleted = false,
                CreatedBy = "admin",
                CreatedDate = DateTime.UtcNow
            };

            // Act
            var isValid = practitionerRoleNotAvailable.NotAvailableEndTime > practitionerRoleNotAvailable.NotAvailableStartTime;

            // Assert
            Assert.False(isValid); // End time should be after start time
        }
    }
}
