﻿using Aurora.AdministrationService.Domain.V1.Entities.Users;
using FluentAssertions;

namespace Aurora.AdministrationService.Tests.DomainTest.V1.Entities
{
    public class UserTests
    {
        [Fact]
        public void Should_Create_User_With_Required_Fields()
        {
            // Arrange
            var user = new User
            {
                UserName = "john_doe",
                Status = true,
                IsTempAccount = false,
                UserType = "Practitioner",
                NotificationsEnabled = true,
                BioAuthenticationEnabled = true,
                SOSButtonEnabled = true,
                IsDeleted = false,
                CreatedBy = "admin",
                CreatedDate = DateTime.UtcNow,
                UpdatedBy = "admin"
            };

            // Act & Assert
            user.UserName.Should().Be("john_doe");
            user.Status.Should().BeTrue();
            user.IsTempAccount.Should().BeFalse();
            user.UserType.Should().Be("Practitioner");
            user.NotificationsEnabled.Should().BeTrue();
            user.BioAuthenticationEnabled.Should().BeTrue();
            user.SOSButtonEnabled.Should().BeTrue();
            user.IsDeleted.Should().BeFalse();
            user.CreatedBy.Should().Be("admin");
            user.UpdatedBy.Should().Be("admin");
            user.RecordVersion.Should().NotBeNull().And.BeEmpty();
        }

        [Fact]
        public void Should_Initialize_Collections_By_Default()
        {
            // Arrange
            var user = new User
            {
                UserName = "john_doe",
                Status = true,
                IsTempAccount = false,
                UserType = "Admin",
                NotificationsEnabled = true,
                BioAuthenticationEnabled = false,
                SOSButtonEnabled = false,
                IsDeleted = false,
                CreatedBy = "admin",
                CreatedDate = DateTime.UtcNow,
                UpdatedBy = "admin"
            };

            // Assert
            user.ChildOrOtherUsers.Should().NotBeNull();
            user.DependentUsers.Should().NotBeNull();
            user.UserNames.Should().NotBeNull();
            user.UserTelecom.Should().NotBeNull();
            user.UserIdentifier.Should().NotBeNull();
            user.ForgetPassword.Should().NotBeNull();

            user.ChildOrOtherUsers.Should().BeEmpty();
            user.DependentUsers.Should().BeEmpty();
        }

        [Fact]
        public void Should_Assign_Optional_Fields_If_Provided()
        {
            // Arrange
            var user = new User
            {
                UserName = "jane_doe",
                Status = true,
                IsTempAccount = false,
                UserType = "Patient",
                NotificationsEnabled = true,
                BioAuthenticationEnabled = true,
                SOSButtonEnabled = true,
                IsDeleted = false,
                CreatedBy = "admin",
                CreatedDate = DateTime.UtcNow,
                UpdatedBy = "admin",

                Nationality = "Indian",
                Gender = "Female",
                BirthDate = new DateTime(1990, 5, 1),
                ManagingOrganization = "Org1",
                Source = "App",
                DefaultLanding = "Dashboard",
                Passcode = "1234",
                Language = 1,
                AppVersion = "1.0.1",
                Password = "encrypted",
                Salt = "salt",
                LocationEnable = true,
                IsMarketingConsentEnable = true
            };

            // Assert
            user.Nationality.Should().Be("Indian");
            user.Gender.Should().Be("Female");
            user.BirthDate.Should().Be(new DateTime(1990, 5, 1));
            user.ManagingOrganization.Should().Be("Org1");
            user.Source.Should().Be("App");
            user.DefaultLanding.Should().Be("Dashboard");
            user.Passcode.Should().Be("1234");
            user.Language.Should().Be(1);
            user.AppVersion.Should().Be("1.0.1");
            user.Password.Should().Be("encrypted");
            user.Salt.Should().Be("salt");
            user.LocationEnable.Should().BeTrue();
            user.IsMarketingConsentEnable.Should().BeTrue();
        }
    }
}
