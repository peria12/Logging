﻿using Aurora.AdministrationService.Domain.V1.Entities.PaymentGateways;

namespace Aurora.AdministrationService.Tests.DomainTest.V1.Entities
{
    public class PaymentGatewayTests
    {
        [Fact]
        public void Can_Create_PaymentGateway_With_Required_Fields()
        {
            // Arrange
            var now = DateTime.UtcNow;
            var gateway = new PaymentGateway
            {
                Id = 1,
                OrganisationID = "ORG123",
                RegionCode = "REG01",
                IsDeleted = false,
                CreatedBy = "admin",
                CreatedDate = now,
                UpdatedBy = "admin_updated",
                UpdatedDate = now,
            };

            // Assert
            Assert.Equal(1, gateway.Id);
            Assert.Equal("ORG123", gateway.OrganisationID);
            Assert.Equal("REG01", gateway.RegionCode);
            Assert.False(gateway.IsDeleted);
            Assert.Equal("admin", gateway.CreatedBy);
            Assert.Equal(now, gateway.CreatedDate);
            Assert.Equal("admin_updated", gateway.UpdatedBy);
            Assert.Equal(now, gateway.UpdatedDate);
            Assert.NotNull(gateway.PaymentGatewayConfig);
            Assert.Empty(gateway.PaymentGatewayConfig);
        }

        [Fact]
        public void RecordVersion_Defaults_To_Empty_ByteArray()
        {
            // Arrange
            var gateway = new PaymentGateway
            {
                Id = 2,
                CreatedBy = "test",
                CreatedDate = DateTime.UtcNow,
                IsDeleted = false
            };

            // Assert
            Assert.NotNull(gateway.RecordVersion);
            Assert.Empty(gateway.RecordVersion);
        }
    }   
}
