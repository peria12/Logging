﻿using Aurora.AdministrationService.Domain.V1.Entities.PractitionerRoles;

namespace Aurora.AdministrationService.Tests.DomainTest.V1.Entities
{
    public class PractitionerRoleIdentifierTests
    {
        [Fact]
        public void Can_Create_PractitionerRoleIdentifier_With_Required_Fields()
        {
            // Arrange
            var now = DateTime.UtcNow;
            var practitionerRoleIdentifier = new PractitionerRoleIdentifier
            {
                Id = 1,
                PractitionerRoleID = 12345,
                System = "System1",
                Value = "Value1",
                IdentifierUse = "Use1",
                IdentifierType = "Type1",
                PeriodStart = now,
                PeriodEnd = now.AddYears(1),
                IsDeleted = false,
                CreatedBy = "admin",
                CreatedDate = now,
                UpdatedBy = "admin2",
                UpdatedDate = now
            };

            // Assert
            Assert.Equal(1, practitionerRoleIdentifier.Id);
            Assert.Equal(12345, practitionerRoleIdentifier.PractitionerRoleID);
            Assert.Equal("System1", practitionerRoleIdentifier.System);
            Assert.Equal("Value1", practitionerRoleIdentifier.Value);
            Assert.Equal("Use1", practitionerRoleIdentifier.IdentifierUse);
            Assert.Equal("Type1", practitionerRoleIdentifier.IdentifierType);
            Assert.Equal(now, practitionerRoleIdentifier.PeriodStart);
            Assert.Equal(now.AddYears(1), practitionerRoleIdentifier.PeriodEnd);
            Assert.False(practitionerRoleIdentifier.IsDeleted);
            Assert.Equal("admin", practitionerRoleIdentifier.CreatedBy);
            Assert.Equal(now, practitionerRoleIdentifier.CreatedDate);
            Assert.Equal("admin2", practitionerRoleIdentifier.UpdatedBy);
            Assert.Equal(now, practitionerRoleIdentifier.UpdatedDate);
        }

        [Fact]
        public void RecordVersion_Should_Be_Empty_By_Default()
        {
            // Arrange
            var practitionerRoleIdentifier = new PractitionerRoleIdentifier
            {
                Id = 1,
                PractitionerRoleID = 12345,
                System = "System1",
                Value = "Value1",
                IdentifierUse = "Use1",
                IdentifierType = "Type1",
                PeriodStart = DateTime.UtcNow,
                PeriodEnd = DateTime.UtcNow.AddYears(1),
                IsDeleted = false,
                CreatedBy = "admin",
                CreatedDate = DateTime.UtcNow
            };

            // Assert
            Assert.NotNull(practitionerRoleIdentifier.RecordVersion);
            Assert.Empty(practitionerRoleIdentifier.RecordVersion);
        }
    }
}
