﻿using Aurora.AdministrationService.Domain.V1.Entities.PractitionerRoles;

namespace Aurora.AdministrationService.Tests.DomainTest.V1.Entities
{
    public class PractitionerRoleAvailableTimeTests
    {
        [Fact]
        public void Can_Create_PractitionerRoleAvailableTime_With_Required_Fields()
        {
            // Arrange
            var now = DateTime.UtcNow;
            var availableTime = new PractitionerRoleAvailableTime
            {
                Id = 1,
                PractitionerRoleID = 12345,
                DaysOfWeek = "Monday, Wednesday, Friday",
                AllDay = true,
                AvailableStartTime = TimeSpan.FromHours(9),  // 09:00 AM
                AvailableEndTime = TimeSpan.FromHours(17),  // 05:00 PM
                IsDeleted = false,
                CreatedBy = "admin",
                CreatedDate = now,
                UpdatedBy = "admin2",
                UpdatedDate = now
            };

            // Assert
            Assert.Equal(1, availableTime.Id);
            Assert.Equal(12345, availableTime.PractitionerRoleID);
            Assert.Equal("Monday, Wednesday, Friday", availableTime.DaysOfWeek);
            Assert.True(availableTime.AllDay);
            Assert.Equal(TimeSpan.FromHours(9), availableTime.AvailableStartTime);
            Assert.Equal(TimeSpan.FromHours(17), availableTime.AvailableEndTime);
            Assert.False(availableTime.IsDeleted);
            Assert.Equal("admin", availableTime.CreatedBy);
            Assert.Equal(now, availableTime.CreatedDate);
            Assert.Equal("admin2", availableTime.UpdatedBy);
            Assert.Equal(now, availableTime.UpdatedDate);
        }

        [Fact]
        public void RecordVersion_Should_Be_Empty_By_Default()
        {
            // Arrange
            var availableTime = new PractitionerRoleAvailableTime
            {
                Id = 1,
                PractitionerRoleID = 12345,
                DaysOfWeek = "Monday, Wednesday, Friday",
                AllDay = true,
                AvailableStartTime = TimeSpan.FromHours(9),
                AvailableEndTime = TimeSpan.FromHours(17),
                IsDeleted = false,
                CreatedBy = "admin",
                CreatedDate = DateTime.UtcNow
            };

            // Assert
            Assert.NotNull(availableTime.RecordVersion);
            Assert.Empty(availableTime.RecordVersion);
        }       
    }
}
