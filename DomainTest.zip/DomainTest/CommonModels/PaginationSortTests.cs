﻿using Aurora.AdministrationService.Domain.CommonModels;

namespace Aurora.AdministrationService.Tests.DomainTest.CommonModels
{
    public class PaginationSortTests
    {
        [Fact]
        public void Can_Create_PaginationSort_With_Default_Values()
        {
            // Act
            var pagination = new PaginationSort();

            // Assert - check default values
            Assert.Equal(1, pagination.PageNumber);
            Assert.Equal(10, pagination.PageSize);
            Assert.Equal("Id", pagination.SortBy);
            Assert.False(pagination.SortDescending);
            Assert.Equal(0, pagination.TotalCount);
            Assert.Equal(0, pagination.CurrentPage);
        }

        [Fact]
        public void Can_Set_And_Get_All_Properties()
        {
            // Arrange
            var pagination = new PaginationSort
            {
                PageNumber = 2,
                PageSize = 25,
                SortBy = "Name",
                SortDescending = true,
                TotalCount = 100,
                CurrentPage = 2
            };

            // Assert - check assigned values
            Assert.Equal(2, pagination.PageNumber);
            Assert.Equal(25, pagination.PageSize);
            Assert.Equal("Name", pagination.SortBy);
            Assert.True(pagination.SortDescending);
            Assert.Equal(100, pagination.TotalCount);
            Assert.Equal(2, pagination.CurrentPage);
        }
    }
}
