﻿using Aurora.AdministrationService.Domain.CommonModels;
using Microsoft.EntityFrameworkCore;

namespace Aurora.AdministrationService.Tests.DomainTest.CommonModels
{
    public class PaginatedListTests
    {
        private class TestDbContext : DbContext
        {
            public DbSet<DummyEntity> DummyEntities { get; set; }

            public TestDbContext(DbContextOptions<TestDbContext> options)
                : base(options)
            {
            }
        }

        private class DummyEntity
        {
            public int Id { get; set; }
            public string Name { get; set; }
        }

        [Fact]
        public async Task CreateAsync_Returns_CorrectPaginationData()
        {
            // Arrange
            var options = new DbContextOptionsBuilder<TestDbContext>()
                .UseInMemoryDatabase(databaseName: "PaginatedListTestDb")
                .Options;

            using (var context = new TestDbContext(options))
            {
                context.DummyEntities.AddRange(Enumerable.Range(1, 25)
                    .Select(i => new DummyEntity { Id = i, Name = $"Name {i}" }));
                await context.SaveChangesAsync();
            }

            using (var context = new TestDbContext(options))
            {
                var source = context.DummyEntities.OrderBy(e => e.Id).AsQueryable();

                int pageIndex = 2;
                int pageSize = 10;

                // Act
                var paginatedList = await PaginatedList<DummyEntity>.CreateAsync(source, pageIndex, pageSize);

                // Assert
                Assert.Equal(pageIndex, paginatedList.PageIndex);
                Assert.Equal(3, paginatedList.TotalPages); // 25 items, 10 per page => 3 pages
                Assert.True(paginatedList.HasPreviousPage);
                Assert.True(paginatedList.HasNextPage);
                Assert.Equal(10, paginatedList.Count);
                Assert.Equal("Name 11", paginatedList.First().Name); // Second page, starts from item 11
            }
        }

        [Fact]
        public async Task CreateAsync_FirstPage_HasNoPreviousPage()
        {
            var options = new DbContextOptionsBuilder<TestDbContext>()
                .UseInMemoryDatabase("FirstPageTestDb")
                .Options;

            using (var context = new TestDbContext(options))
            {
                context.DummyEntities.AddRange(Enumerable.Range(1, 5)
                    .Select(i => new DummyEntity { Id = i, Name = $"Test {i}" }));
                await context.SaveChangesAsync();
            }

            using (var context = new TestDbContext(options))
            {
                var result = await PaginatedList<DummyEntity>.CreateAsync(context.DummyEntities, 1, 2);

                Assert.False(result.HasPreviousPage);
                Assert.True(result.HasNextPage);
                Assert.Equal(1, result.PageIndex);
                Assert.Equal(3, result.TotalPages);
                Assert.Equal(2, result.Count);
            }
        }

        [Fact]
        public async Task CreateAsync_LastPage_HasNoNextPage()
        {
            var options = new DbContextOptionsBuilder<TestDbContext>()
                .UseInMemoryDatabase("LastPageTestDb")
                .Options;

            using (var context = new TestDbContext(options))
            {
                context.DummyEntities.AddRange(Enumerable.Range(1, 5)
                    .Select(i => new DummyEntity { Id = i, Name = $"EndTest {i}" }));
                await context.SaveChangesAsync();
            }

            using (var context = new TestDbContext(options))
            {
                var result = await PaginatedList<DummyEntity>.CreateAsync(context.DummyEntities, 3, 2);

                Assert.True(result.HasPreviousPage);
                Assert.False(result.HasNextPage);
            }
        }

        [Fact]
        public async Task CreateAsync_EmptySource_ReturnsEmptyList()
        {
            var options = new DbContextOptionsBuilder<TestDbContext>()
                .UseInMemoryDatabase("EmptyDb")
                .Options;

            using (var context = new TestDbContext(options))
            {
                var result = await PaginatedList<DummyEntity>.CreateAsync(context.DummyEntities, 1, 10);

                Assert.Empty(result);
                Assert.Equal(1, result.PageIndex);
                Assert.Equal(0, result.TotalPages);
                Assert.False(result.HasPreviousPage);
                Assert.False(result.HasNextPage);
            }
        }
    }
}

