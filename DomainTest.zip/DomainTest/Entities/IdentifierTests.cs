﻿using Aurora.AdministrationService.Domain.Entities;
using Aurora.AdministrationService.Domain.Old.Entities;

namespace Aurora.AdministrationService.Tests.DomainTest.Entities
{
    public class IdentifierTests
    {
        [Fact]
        public void Can_Initialize_Identifier_With_Valid_Values()
        {
            // Arrange
            var now = DateTime.UtcNow;

            var identifier = new Identifier
            {
                IdentifierId = 1001,
                PatientId = "PAT123",
                IdentifierType = "MRN",
                IdentifierValue = "MRN-0001",
                IsActive = true,
                CreatedAt = now,
                UpdatedAt = now,
                Patient = new PatientUser { PatientId = "PAT123" } // Using your real class
            };

            // Assert
            Assert.Equal(1001, identifier.IdentifierId);
            Assert.Equal("PAT123", identifier.PatientId);
            Assert.Equal("MRN", identifier.IdentifierType);
            Assert.Equal("MRN-0001", identifier.IdentifierValue);
            Assert.True(identifier.IsActive);
            Assert.Equal(now, identifier.CreatedAt);
            Assert.Equal(now, identifier.UpdatedAt);
            Assert.NotNull(identifier.Patient);
            Assert.Equal("PAT123", identifier.Patient.PatientId);
        }

        [Fact]
        public void Can_Have_Null_UpdatedAt()
        {
            // Arrange
            var identifier = new Identifier
            {
                IdentifierId = 1002,
                PatientId = "PAT456",
                IdentifierType = "Aadhar",
                IdentifierValue = "1234-5678-9012",
                IsActive = false,
                CreatedAt = DateTime.UtcNow,
                UpdatedAt = null,
                Patient = new PatientUser { PatientId = "PAT456" }
            };

            // Assert
            Assert.Null(identifier.UpdatedAt);
        }
    }
}
