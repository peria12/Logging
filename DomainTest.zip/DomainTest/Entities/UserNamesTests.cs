﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using Aurora.AdministrationService.Domain.V1.Entities.Users;
using FluentAssertions;
using Xunit;

namespace Aurora.AdministrationService.Tests.DomainTest.Entities
{
    public class UserNamesTests
    {
        [Fact]
        public void UserNames_Should_Initialize_Required_And_Optional_Fields_Correctly()
        {
            // Arrange
            var userNames = new UserNames
            {
                UserID = 12345,
                NameUse = "official",
                Status = true,
                FamilyName = "Doe",
                GivenName = "John",
                MiddleName = "A.",
                Prefix = "Mr.",
                Suffix = "Jr.",
                PeriodStart = DateTime.UtcNow,
                IsDeleted = false,
                CreatedBy = "admin",
                CreatedDate = DateTime.UtcNow,
                UpdatedBy = "admin",
                UpdatedDate = DateTime.UtcNow
            };

            // Act & Assert: Ensure required fields are properly initialized
            userNames.UserID.Should().Be(12345);
            userNames.NameUse.Should().Be("official");
            userNames.Status.Should().Be(true);
            userNames.FamilyName.Should().Be("Doe");
            userNames.GivenName.Should().Be("John");
            userNames.MiddleName.Should().Be("A.");
            userNames.Prefix.Should().Be("Mr.");
            userNames.Suffix.Should().Be("Jr.");
            userNames.PeriodStart.Should().BeAfter(DateTime.MinValue);
            userNames.IsDeleted.Should().Be(false);
            userNames.CreatedBy.Should().Be("admin");
            userNames.CreatedDate.Should().BeAfter(DateTime.MinValue);
            userNames.UpdatedBy.Should().Be("admin");
            userNames.UpdatedDate.Should().BeAfter(DateTime.MinValue);

            // Assert: Ensure optional fields are left as null by default
            userNames.PeriodEnd.Should().BeNull();
            userNames.RecordVersion.Should().BeEmpty();
        }

        [Fact]
        public void UserNames_ShouldHaveValidMaxLengthForProperties()
        {
            // Arrange
            var userNames = new UserNames
            {
                UserID = 12345,
                NameUse = new string('a', 21), // Exceeds max length of 20
                FamilyName = new string('a', 51), // Exceeds max length of 50
                GivenName = new string('a', 51), // Exceeds max length of 50
                MiddleName = new string('a', 51), // Exceeds max length of 50
                Prefix = new string('a', 21), // Exceeds max length of 20
                Suffix = new string('a', 21), // Exceeds max length of 20
                CreatedBy = new string('a', 51), // Exceeds max length of 50
                UpdatedBy = new string('a', 51), // Exceeds max length of 50
                Status = true,
                CreatedDate = DateTime.Now,
                IsDeleted = false,
                PeriodStart = DateTime.Now
            };

            // Act
            var validationResults = new List<ValidationResult>();
            var isValid = Validator.TryValidateObject(userNames, new ValidationContext(userNames), validationResults, true);

            // Assert
            isValid.Should().BeFalse();
            validationResults.Should().Contain(v => v.MemberNames.Contains("NameUse"));
            validationResults.Should().Contain(v => v.MemberNames.Contains("FamilyName"));
            validationResults.Should().Contain(v => v.MemberNames.Contains("GivenName"));
            validationResults.Should().Contain(v => v.MemberNames.Contains("MiddleName"));
            validationResults.Should().Contain(v => v.MemberNames.Contains("Prefix"));
            validationResults.Should().Contain(v => v.MemberNames.Contains("Suffix"));
            validationResults.Should().Contain(v => v.MemberNames.Contains("CreatedBy"));
            validationResults.Should().Contain(v => v.MemberNames.Contains("UpdatedBy"));
        }
    }
}
