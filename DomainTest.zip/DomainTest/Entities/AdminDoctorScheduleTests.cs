﻿using Aurora.AdministrationService.Domain.Entities;
using Aurora.AdministrationService.Domain.Old.Entities;

namespace Aurora.AdministrationService.Tests.DomainTest.Entities
{
    public class AdminDoctorScheduleTests
    {
        [Fact]
        public void Can_Create_AdminDoctorSchedule_And_Assign_Properties()
        {
            // Arrange
            var now = DateTime.UtcNow;

            var schedule = new AdminDoctorSchedule
            {
                ScheduleId = 1,
                DoctorProfileId = 101,
                Identifier = "SCHD-001",
                Active = true,
                ServiceCategory = "General",
                ServiceType = "Consultation",
                Specialty = "Cardiology",
                Actor = "Doctor",
                PlanningHorizonStart = now,
                PlanningHorizonEnd = now.AddDays(30),
                Comment = "Available in morning only",
                CreatedAt = now,
                UpdatedAt = now,
                AvailableDate = new DateOnly(2025, 04, 15),
                DoctorProfile = new AdminDoctorProfile()
            };

            // Act - add a schedule exception
            schedule.ScheduleExceptions.Add(new ScheduleException());

            // Assert
            Assert.Equal(1, schedule.ScheduleId);
            Assert.Equal(101, schedule.DoctorProfileId);
            Assert.Equal("SCHD-001", schedule.Identifier);
            Assert.True(schedule.Active);
            Assert.Equal("General", schedule.ServiceCategory);
            Assert.Equal("Consultation", schedule.ServiceType);
            Assert.Equal("Cardiology", schedule.Specialty);
            Assert.Equal("Doctor", schedule.Actor);
            Assert.Equal(now, schedule.PlanningHorizonStart);
            Assert.Equal(now.AddDays(30), schedule.PlanningHorizonEnd);
            Assert.Equal("Available in morning only", schedule.Comment);
            Assert.Equal(now, schedule.CreatedAt);
            Assert.Equal(now, schedule.UpdatedAt);
            Assert.Equal(new DateOnly(2025, 04, 15), schedule.AvailableDate);

            Assert.NotNull(schedule.DoctorProfile);
            Assert.Single(schedule.ScheduleExceptions);
        }
    }
}
