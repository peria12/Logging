﻿using Aurora.AdministrationService.Domain.Old.Entities;

namespace Aurora.AdministrationService.Tests.DomainTest.Entities
{
    public class AdminDoctorSpecialityTests
    {
        [Fact]
        public void Can_Create_And_Assign_AdminDoctorSpeciality_Properties()
        {
            // Arrange
            var currentTime = DateTime.UtcNow;
            var certificationDate = new DateOnly(2022, 12, 25);

            var speciality = new AdminDoctorSpeciality
            {
                DoctorSpecialityId = 1,
                DoctorProfileId = 101,
                Speciality = "Cardiology",
                CertificationDate = certificationDate,
                IsActive = true,
                DateCreated = currentTime,
                CreatedBy = 5,
                LastModifiedBy = 10,
                LastModifiedDate = currentTime,
                DoctorProfile = new AdminDoctorProfile { DoctorProfileId = 101 },
                CreatedByNavigation = new AdminUser { AdminId = 5 },
                LastModifiedByNavigation = new AdminUser { AdminId = 10 },
                AppointmentSlots = new List<AppointmentSlot>
                {
                    new AppointmentSlot { SlotId = 1 },
                    new AppointmentSlot { SlotId = 2 }
                }
            };

            // Assert
            Assert.Equal(1, speciality.DoctorSpecialityId);
            Assert.Equal(101, speciality.DoctorProfileId);
            Assert.Equal("Cardiology", speciality.Speciality);
            Assert.Equal(certificationDate, speciality.CertificationDate);
            Assert.True(speciality.IsActive);
            Assert.Equal(currentTime, speciality.DateCreated);
            Assert.Equal(5, speciality.CreatedBy);
            Assert.Equal(10, speciality.LastModifiedBy);
            Assert.Equal(currentTime, speciality.LastModifiedDate);

            Assert.NotNull(speciality.DoctorProfile);
            Assert.Equal(101, speciality.DoctorProfile.DoctorProfileId);

            Assert.NotNull(speciality.CreatedByNavigation);
            Assert.Equal(5, speciality.CreatedByNavigation.AdminId);

            Assert.NotNull(speciality.LastModifiedByNavigation);
            Assert.Equal(10, speciality.LastModifiedByNavigation.AdminId);

            Assert.NotNull(speciality.AppointmentSlots);
            Assert.Equal(2, speciality.AppointmentSlots.Count);
        }
    }
}
