﻿using Aurora.AdministrationService.Domain.Entities;

namespace Aurora.AdministrationService.Tests.DomainTest.Entities
{
    public class NotificationManagerTests
    {
        [Fact]
        public void Can_Create_NotificationManager_With_All_Properties()
        {
            // Arrange
            var createdDate = DateTime.UtcNow;
            var updatedDate = createdDate.AddHours(1);

            var notificationManager = new NotificationManager
            {
                ID = 1,
                Module = "AdminModule",
                UserGroupID = "GroupA",
                NotificationType = "Email",
                Status = true,
                RecordVersion = new byte[] { 0x01, 0x02 },
                IsDeleted = false,
                CreatedBy = "admin",
                CreatedDate = createdDate,
                UpdatedBy = "editor",
                UpdatedDate = updatedDate
            };

            // Assert
            Assert.Equal(1, notificationManager.ID);
            Assert.Equal("AdminModule", notificationManager.Module);
            Assert.Equal("GroupA", notificationManager.UserGroupID);
            Assert.Equal("Email", notificationManager.NotificationType);
            Assert.True(notificationManager.Status);
            Assert.Equal(new byte[] { 0x01, 0x02 }, notificationManager.RecordVersion);
            Assert.False(notificationManager.IsDeleted);
            Assert.Equal("admin", notificationManager.CreatedBy);
            Assert.Equal(createdDate, notificationManager.CreatedDate);
            Assert.Equal("editor", notificationManager.UpdatedBy);
            Assert.Equal(updatedDate, notificationManager.UpdatedDate);
        }

        [Fact]
        public void Can_Create_NotificationManager_With_Minimum_Required_Fields()
        {
            // Arrange
            var createdDate = DateTime.UtcNow;

            var notificationManager = new NotificationManager
            {
                ID = 2,
                Module = "UserModule",
                UserGroupID = "GroupB",
                NotificationType = "SMS",
                Status = false,
                IsDeleted = true,
                CreatedBy = "admin",
                CreatedDate = createdDate
            };

            // Assert
            Assert.Equal(2, notificationManager.ID);
            Assert.Equal("UserModule", notificationManager.Module);
            Assert.Equal("GroupB", notificationManager.UserGroupID);
            Assert.Equal("SMS", notificationManager.NotificationType);
            Assert.False(notificationManager.Status);
            Assert.True(notificationManager.IsDeleted);
            Assert.Equal("admin", notificationManager.CreatedBy);
            Assert.Equal(createdDate, notificationManager.CreatedDate);
        }
    }
}
