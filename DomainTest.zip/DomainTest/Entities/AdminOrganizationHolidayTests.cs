﻿using Aurora.AdministrationService.Domain.Entities;
using Aurora.AdministrationService.Domain.Old.Entities;

namespace Aurora.AdministrationService.Tests.DomainTest.Entities
{
    public class AdminOrganizationHolidayTests
    {
        [Fact]
        public void Can_Create_And_Assign_AdminOrganizationHoliday_Properties()
        {
            // Arrange
            var holidayDate = new DateOnly(2025, 12, 25);
            var startTime = new TimeOnly(9, 0);
            var endTime = new TimeOnly(17, 0);
            var createdAt = DateTime.UtcNow;
            var updatedAt = DateTime.UtcNow;

            var holiday = new AdminOrganizationHoliday
            {
                HolidayScheduleId = 1,
                OrganizationId = 1001,
                HolidayName = "Christmas",
                HolidayDate = holidayDate,
                IsRecurring = true,
                HolidayType = "Public",
                StartTime = startTime,
                EndTime = endTime,
                Comment = "Annual holiday",
                CreatedAt = createdAt,
                UpdatedAt = updatedAt,
                Organization = new AdminOrganization
                {
                    OrganizationId = 1001,
                    Name = "HealthCare Org"
                }
            };

            // Assert
            Assert.Equal(1, holiday.HolidayScheduleId);
            Assert.Equal(1001, holiday.OrganizationId);
            Assert.Equal("Christmas", holiday.HolidayName);
            Assert.Equal(holidayDate, holiday.HolidayDate);
            Assert.True(holiday.IsRecurring);
            Assert.Equal("Public", holiday.HolidayType);
            Assert.Equal(startTime, holiday.StartTime);
            Assert.Equal(endTime, holiday.EndTime);
            Assert.Equal("Annual holiday", holiday.Comment);
            Assert.Equal(createdAt, holiday.CreatedAt);
            Assert.Equal(updatedAt, holiday.UpdatedAt);

            Assert.NotNull(holiday.Organization);
            Assert.Equal(1001, holiday.Organization.OrganizationId);
            Assert.Equal("HealthCare Org", holiday.Organization.Name);
        }
    }
}
