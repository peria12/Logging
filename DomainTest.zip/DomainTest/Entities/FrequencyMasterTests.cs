﻿using Aurora.AdministrationService.Domain.Entities;

namespace Aurora.AdministrationService.Tests.DomainTest.Entities
{
    public class FrequencyMasterTests
    {
        [Fact]
        public void Can_Initialize_FrequencyMaster_With_Valid_Data()
        {
            // Arrange
            var now = DateTime.UtcNow;

            var frequency = new FrequencyMaster
            {
                Id = 1,
                Description = "Every 6 hours",
                FacilityCode = "HSP001",
                FrequencyValue = 6,
                IsFreeText = false,
                IsDeleted = false,
                CreatedBy = "admin",
                CreatedDate = now,
                UpdatedBy = "supervisor",
                UpdatedDate = now
            };

            // Assert
            Assert.Equal(1, frequency.Id);
            Assert.Equal("Every 6 hours", frequency.Description);
            Assert.Equal("HSP001", frequency.FacilityCode);
            Assert.Equal(6, frequency.FrequencyValue);
            Assert.False(frequency.IsFreeText);
            Assert.False(frequency.IsDeleted);
            Assert.Equal("admin", frequency.CreatedBy);
            Assert.Equal(now, frequency.CreatedDate);
            Assert.Equal("supervisor", frequency.UpdatedBy);
            Assert.Equal(now, frequency.UpdatedDate);
        }

        [Fact]
        public void FrequencyMaster_Can_Have_Null_UpdatedBy_And_UpdatedDate()
        {
            // Arrange
            var frequency = new FrequencyMaster
            {
                Id = 2,
                Description = "Once Daily",
                FacilityCode = "FAC123",
                FrequencyValue = 1,
                IsFreeText = true,
                IsDeleted = true,
                CreatedBy = "creator",
                CreatedDate = DateTime.UtcNow,
                UpdatedBy = null,
                UpdatedDate = null
            };

            // Assert
            Assert.Null(frequency.UpdatedBy);
            Assert.Null(frequency.UpdatedDate);
        }

        [Fact]
        public void Required_Properties_Should_Throw_When_Not_Set()
        {
            // Arrange & Act
            var frequency = new FrequencyMaster
            {
                Description = "",
                FacilityCode = "",
                FrequencyValue = 0,
                IsFreeText = false,
                IsDeleted = true,
                CreatedBy = "system",
                CreatedDate = DateTime.UtcNow
            };

            // Assert
            Assert.NotNull(frequency.CreatedBy);
            Assert.NotEqual(default, frequency.CreatedDate);
        }
    }
}
