﻿using Aurora.AdministrationService.Domain.V1.Entities;
using FluentAssertions;
using System.ComponentModel.DataAnnotations;
namespace Aurora.AdministrationService.Tests.DomainTest.Entities
{
    public class AgreementLanguageValidationTests
    {
        private static List<ValidationResult> ValidateModel(AgreementLanguage model)
        {
            var results = new List<ValidationResult>();
            var context = new ValidationContext(model, null, null);
            Validator.TryValidateObject(model, context, results, true);
            return results;
        }

        [Fact]
        public void AgreementLanguage_ShouldBeValid_WhenAllRequiredFieldsAreSet()
        {
            var model = new AgreementLanguage
            {
                AgreementID = 1,
                Status = true,
                IsDeleted = false,
                CreatedBy = "admin",
                CreatedDate = DateTime.UtcNow,
                UpdatedBy = "admin",
                UpdatedDate = DateTime.UtcNow
            };

            var results = ValidateModel(model);

            results.Should().BeEmpty(); // No validation errors expected
        }

        [Fact]
        public void AgreementLanguage_ShouldFailValidation_WhenCreatedByExceedsMaxLength()
        {
            var model = new AgreementLanguage
            {
                AgreementID = 1,
                Status = true,
                IsDeleted = false,
                CreatedBy = new string('A', 51), // 51 chars
                CreatedDate = DateTime.UtcNow,
                UpdatedBy = "admin",
                UpdatedDate = DateTime.UtcNow
            };

            var results = ValidateModel(model);

            results.Should().ContainSingle(v => v.MemberNames.Contains("CreatedBy"));
        }

        [Fact]
        public void AgreementLanguage_ShouldFailValidation_WhenNameExceedsMaxLength()
        {
            var model = new AgreementLanguage
            {
                AgreementID = 1,
                Status = true,
                IsDeleted = false,
                CreatedBy = "admin",
                CreatedDate = DateTime.UtcNow,
                UpdatedBy = "admin",
                UpdatedDate = DateTime.UtcNow,
                Name = new string('N', 51) // MaxLength = 50
            };

            var results = ValidateModel(model);

            results.Should().ContainSingle(v => v.MemberNames.Contains("Name"));
        }

        [Fact]
        public void AgreementLanguage_ShouldFailValidation_WhenDescriptionExceedsMaxLength()
        {
            var model = new AgreementLanguage
            {
                AgreementID = 1,
                Status = true,
                IsDeleted = false,
                CreatedBy = "admin",
                CreatedDate = DateTime.UtcNow,
                UpdatedBy = "admin",
                UpdatedDate = DateTime.UtcNow,
                Description = new string('D', 101) // MaxLength = 100
            };

            var results = ValidateModel(model);

            results.Should().ContainSingle(v => v.MemberNames.Contains("Description"));
        }
    }
}