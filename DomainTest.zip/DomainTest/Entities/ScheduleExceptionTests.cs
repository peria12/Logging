﻿using Aurora.AdministrationService.Domain.Entities;
using Aurora.AdministrationService.Domain.Old.Entities;

namespace Aurora.AdministrationService.Tests.DomainTest.Entities
{
    public class ScheduleExceptionTests
    {
        [Fact]
        public void Can_Create_ScheduleException_With_All_Properties()
        {
            // Arrange
            var schedule = new AdminDoctorSchedule { ScheduleId = 1 };

            var exception = new ScheduleException
            {
                Id = 10,
                ScheduleId = 1,
                ExceptionType = "Block",
                ReasonCode = "RC01",
                ReasonDescription = "Doctor unavailable",              
                Status = "Active",
                CreatedBy = 1001,
                DateCreated = DateTime.UtcNow,
                LastModifiedBy = 1002,
                LastModifiedDate = DateTime.UtcNow.AddHours(1),
                AdditionalData = "{\"note\":\"emergency\"}",
                Schedule = schedule
            };

            // Assert
            Assert.Equal(10, exception.Id);
            Assert.Equal(1, exception.ScheduleId);
            Assert.Equal("Block", exception.ExceptionType);
            Assert.Equal("RC01", exception.ReasonCode);
            Assert.Equal("Doctor unavailable", exception.ReasonDescription);           
            Assert.Equal("Active", exception.Status);
            Assert.Equal(1001, exception.CreatedBy);
            Assert.NotNull(exception.DateCreated);
            Assert.Equal(1002, exception.LastModifiedBy);
            Assert.NotNull(exception.LastModifiedDate);
            Assert.Equal("{\"note\":\"emergency\"}", exception.AdditionalData);
            Assert.NotNull(exception.Schedule);
            Assert.Equal(1, exception.Schedule.ScheduleId);
        }

        [Fact]
        public void Can_Create_ScheduleException_With_Minimum_Data()
        {
            // Arrange
            var schedule = new AdminDoctorSchedule { ScheduleId = 2 };

            var exception = new ScheduleException
            {
                Id = 11,
                ScheduleId = 2,
                Schedule = schedule
            };

            // Assert
            Assert.Equal(11, exception.Id);
            Assert.Equal(2, exception.ScheduleId);
            Assert.Null(exception.ExceptionType);
            Assert.Null(exception.ReasonCode);
            Assert.Null(exception.ReasonDescription);
            Assert.Null(exception.StartDateTime);
            Assert.Null(exception.EndDateTime);
            Assert.Null(exception.Status);
            Assert.Null(exception.CreatedBy);
            Assert.Null(exception.DateCreated);
            Assert.Null(exception.LastModifiedBy);
            Assert.Null(exception.LastModifiedDate);
            Assert.Null(exception.AdditionalData);
            Assert.NotNull(exception.Schedule);
        }

        [Fact]
        public void Can_Update_ScheduleException_Properties()
        {
            // Arrange
            var exception = new ScheduleException
            {
                Id = 12,
                ScheduleId = 3,
                Schedule = new AdminDoctorSchedule { ScheduleId = 3 }
            };

            // Act
            exception.ExceptionType = "Holiday";
            exception.ReasonCode = "RC02";
            exception.Status = "Inactive";

            // Assert
            Assert.Equal("Holiday", exception.ExceptionType);
            Assert.Equal("RC02", exception.ReasonCode);
            Assert.Equal("Inactive", exception.Status);
        }

        [Fact]
        public void Schedule_Should_Not_Be_Null_By_Default()
        {
            // Arrange
            var exception = new ScheduleException
            {
                Schedule = new AdminDoctorSchedule()
            };

            // Assert
            Assert.NotNull(exception.Schedule);
        }
    }
}
