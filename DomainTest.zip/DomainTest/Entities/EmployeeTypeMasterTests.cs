﻿using Aurora.AdministrationService.Domain.Entities;
using Aurora.AdministrationService.Domain.Old.Entities;

namespace Aurora.AdministrationService.Tests.DomainTest.Entities
{
    public class EmployeeTypeMasterTests
    {
        [Fact]
        public void Can_Create_EmployeeTypeMaster_With_All_Properties()
        {
            // Arrange
            var createdDate = DateTime.UtcNow;
            var updatedDate = createdDate.AddHours(2);

            var entity = new EmployeeTypeMaster
            {
                Id = 1,
                EmployeeTypeCode = "FT",
                EmployeeTypeName = "Full Time",
                IsDeleted = false,
                CreatedBy = "admin",
                CreatedDate = createdDate,
                UpdatedBy = "system",
                UpdatedDate = updatedDate,
                FacilityCode = "HOSP001"
            };

            // Assert
            Assert.Equal(1, entity.Id);
            Assert.Equal("FT", entity.EmployeeTypeCode);
            Assert.Equal("Full Time", entity.EmployeeTypeName);
            Assert.False(entity.IsDeleted);
            Assert.Equal("admin", entity.CreatedBy);
            Assert.Equal(createdDate, entity.CreatedDate);
            Assert.Equal("system", entity.UpdatedBy);
            Assert.Equal(updatedDate, entity.UpdatedDate);
            Assert.Equal("HOSP001", entity.FacilityCode);
        }

        [Fact]
        public void Can_Handle_Nullable_Fields()
        {
            // Arrange
            var createdDate = DateTime.UtcNow;

            var entity = new EmployeeTypeMaster
            {
                Id = 2,
                EmployeeTypeCode = "PT",
                EmployeeTypeName = "Part Time",
                IsDeleted = true,
                CreatedBy = "hruser",
                CreatedDate = createdDate,
                UpdatedBy = null,
                UpdatedDate = null,
                FacilityCode = "CLINIC001"
            };

            // Assert
            Assert.Equal(2, entity.Id);
            Assert.Equal("PT", entity.EmployeeTypeCode);
            Assert.Equal("Part Time", entity.EmployeeTypeName);
            Assert.True(entity.IsDeleted);
            Assert.Equal("hruser", entity.CreatedBy);
            Assert.Equal(createdDate, entity.CreatedDate);
            Assert.Null(entity.UpdatedBy);
            Assert.Null(entity.UpdatedDate);
            Assert.Equal("CLINIC001", entity.FacilityCode);
        }
    }
}
