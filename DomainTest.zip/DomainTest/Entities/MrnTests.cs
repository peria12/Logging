﻿using Aurora.AdministrationService.Domain.Entities;
using Aurora.AdministrationService.Domain.Old.Entities;

namespace Aurora.AdministrationService.Tests.DomainTest.Entities
{
    public class MrnTests
    {
        [Fact]
        public void Can_Create_Mrn_With_All_Properties()
        {
            // Arrange
            var createdAt = DateTime.UtcNow;
            var updatedAt = createdAt.AddHours(1);

            var mockHospital = new AdminOrganization
            {
                OrganizationId = 10,
                Name = "Apollo Hospital"
            };

            var mockUser = new User
            {
                Id = 13,
                Name = "Rajendiran"
            };

            var mrn = new Mrn
            {
                Id = 1,
                Mrnnumber = "MRN10001",
                UserId = "USR001",
                HospitalId = 10,
                HospitalName = "Apollo Hospital",
                CreatedBy = "admin",
                UpdatedBy = "editor",
                CreatedAt = createdAt,
                UpdatedAt = updatedAt,
                IsDeleted = false,
                IsActive = true,
                Hospital = mockHospital,
                User = mockUser
            };

            // Assert
            Assert.Equal(1, mrn.Id);
            Assert.Equal("MRN10001", mrn.Mrnnumber);
            Assert.Equal("USR001", mrn.UserId);
            Assert.Equal(10, mrn.HospitalId);
            Assert.Equal("Apollo Hospital", mrn.HospitalName);
            Assert.Equal("admin", mrn.CreatedBy);
            Assert.Equal("editor", mrn.UpdatedBy);
            Assert.Equal(createdAt, mrn.CreatedAt);
            Assert.Equal(updatedAt, mrn.UpdatedAt);
            Assert.False(mrn.IsDeleted);
            Assert.True(mrn.IsActive);
            Assert.NotNull(mrn.Hospital);
            Assert.Equal("Apollo Hospital", mrn.Hospital.Name);
            Assert.NotNull(mrn.User);
            Assert.Equal("Rajendiran", mrn.User.Name);
        }

        [Fact]
        public void Can_Create_Mrn_With_Minimum_Required_Fields()
        {
            // Arrange
            var mrn = new Mrn
            {
                Id = 2,
                Mrnnumber = "MRN10002",
                UserId = "USR002",
                HospitalId = 20,
                CreatedAt = DateTime.UtcNow,
                IsDeleted = true,
                IsActive = false,
                Hospital = new AdminOrganization(),
                User = new User()
            };

            // Assert
            Assert.Equal(2, mrn.Id);
            Assert.Equal("MRN10002", mrn.Mrnnumber);
            Assert.Equal("USR002", mrn.UserId);
            Assert.Equal(20, mrn.HospitalId);
            Assert.True(mrn.IsDeleted);
            Assert.False(mrn.IsActive);
            Assert.NotNull(mrn.Hospital);
            Assert.NotNull(mrn.User);
        }
    }
}
