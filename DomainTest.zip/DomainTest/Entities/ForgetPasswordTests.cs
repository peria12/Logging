﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using Aurora.AdministrationService.Domain.V1.Entities.Users;
using FluentAssertions;
using Xunit;

namespace Aurora.AdministrationService.Tests.DomainTest.Entities
{
    public class ForgetPasswordTests
    {
        [Fact]
        public void ForgetPassword_Should_Initialize_Required_Fields_Correctly()
        {
            // Arrange
            var forgetPassword = new ForgetPassword
            {
                UserID = 123,
                RequestedDate = DateTime.UtcNow,
                IsDeleted = false,
                CreatedBy = "admin",
                CreatedDate = DateTime.UtcNow
            };

            // Act & Assert: Ensure required fields are properly initialized
            forgetPassword.UserID.Should().Be(123);
            forgetPassword.RequestedDate.Should().BeCloseTo(DateTime.UtcNow, TimeSpan.FromSeconds(1));
            forgetPassword.IsDeleted.Should().BeFalse();
            forgetPassword.CreatedBy.Should().NotBeNullOrEmpty();
            forgetPassword.CreatedDate.Should().BeCloseTo(DateTime.UtcNow, TimeSpan.FromSeconds(1));

            // Assert: Ensure optional fields are left as null by default
            forgetPassword.UpdatedBy.Should().BeNull();
            forgetPassword.UpdatedDate.Should().BeNull();
            forgetPassword.RecordVersion.Should().BeEmpty();
        }

        [Fact]
        public void ForgetPassword_ShouldHaveValidMaxLengthForProperties()
        {
            // Arrange
            var forgetPassword = new ForgetPassword
            {
                UserID = 123,
                RequestedDate = DateTime.UtcNow,
                IsDeleted = false,
                CreatedBy = new string('a', 51), // Exceeding MaxLength 50
                UpdatedBy = new string('a', 51), // Exceeding MaxLength 50
                CreatedDate = DateTime.UtcNow
            };

            // Act
            var validationResults = new List<ValidationResult>();
            var isValid = Validator.TryValidateObject(forgetPassword, new ValidationContext(forgetPassword), validationResults, true);

            // Assert
            isValid.Should().BeFalse();
            validationResults.Should().Contain(v => v.MemberNames.Contains("CreatedBy"));
            validationResults.Should().Contain(v => v.MemberNames.Contains("UpdatedBy"));
        }
    }
}
