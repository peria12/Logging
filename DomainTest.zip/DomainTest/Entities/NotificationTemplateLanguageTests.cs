﻿using Aurora.AdministrationService.Domain.Entities;

namespace Aurora.AdministrationService.Tests.DomainTest.Entities
{
    public class NotificationTemplateLanguageTests
    {
        [Fact]
        public void Can_Create_NotificationTemplateLanguage_With_All_Properties()
        {
            // Arrange
            var createdDate = DateTime.UtcNow;
            var updatedDate = createdDate.AddHours(1);

            var notificationTemplateLanguage = new NotificationTemplateLanguage
            {
                Id = 1,
                NotificationTemplateID = "Template1",
                Status = true,
                LanguageID = "en-US",
                PushNotification = "Push notification content",
                SMS = "SMS content",
                InApp = "In-app content",
                Whatapp = "WhatsApp content",
                EmailSubject = "Email subject",
                EmailBody = "Email body content",
                RecordVersion = new byte[] { 0x01, 0x02 },
                IsDeleted = false,
                CreatedBy = "admin",
                CreatedDate = createdDate,
                UpdatedBy = "editor",
                UpdatedDate = updatedDate
            };

            // Assert
            Assert.Equal(1, notificationTemplateLanguage.Id);
            Assert.Equal("Template1", notificationTemplateLanguage.NotificationTemplateID);
            Assert.True(notificationTemplateLanguage.Status);
            Assert.Equal("en-US", notificationTemplateLanguage.LanguageID);
            Assert.Equal("Push notification content", notificationTemplateLanguage.PushNotification);
            Assert.Equal("SMS content", notificationTemplateLanguage.SMS);
            Assert.Equal("In-app content", notificationTemplateLanguage.InApp);
            Assert.Equal("WhatsApp content", notificationTemplateLanguage.Whatapp);
            Assert.Equal("Email subject", notificationTemplateLanguage.EmailSubject);
            Assert.Equal("Email body content", notificationTemplateLanguage.EmailBody);
            Assert.Equal(new byte[] { 0x01, 0x02 }, notificationTemplateLanguage.RecordVersion);
            Assert.False(notificationTemplateLanguage.IsDeleted);
            Assert.Equal("admin", notificationTemplateLanguage.CreatedBy);
            Assert.Equal(createdDate, notificationTemplateLanguage.CreatedDate);
            Assert.Equal("editor", notificationTemplateLanguage.UpdatedBy);
            Assert.Equal(updatedDate, notificationTemplateLanguage.UpdatedDate);
        }

        [Fact]
        public void Can_Create_NotificationTemplateLanguage_With_Minimum_Required_Fields()
        {
            // Arrange
            var createdDate = DateTime.UtcNow;

            var notificationTemplateLanguage = new NotificationTemplateLanguage
            {
                Id = 2,
                NotificationTemplateID = "Template2",
                Status = false,
                LanguageID = "fr-FR",
                IsDeleted = true,
                CreatedBy = "admin",
                CreatedDate = createdDate
            };

            // Assert
            Assert.Equal(2, notificationTemplateLanguage.Id);
            Assert.Equal("Template2", notificationTemplateLanguage.NotificationTemplateID);
            Assert.False(notificationTemplateLanguage.Status);
            Assert.Equal("fr-FR", notificationTemplateLanguage.LanguageID);
            Assert.True(notificationTemplateLanguage.IsDeleted);
            Assert.Equal("admin", notificationTemplateLanguage.CreatedBy);
            Assert.Equal(createdDate, notificationTemplateLanguage.CreatedDate);
        }
    }
}
