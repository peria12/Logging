﻿using Aurora.AdministrationService.Domain.Entities;
using Aurora.AdministrationService.Domain.Old.Entities;

namespace Aurora.AdministrationService.Tests.DomainTest.Entities
{
    public class AdminDoctorProfileTests
    {
        [Fact]
        public void Can_Create_AdminDoctorProfile_And_Assign_Properties()
        {
            // Arrange
            var now = DateTime.UtcNow;

            var doctorProfile = new AdminDoctorProfile
            {
                DoctorProfileId = 1,
                Identifier = "DR123",
                FirstName = "John",
                LastName = "Doe",
                MiddleName = "M",
                Gender = "Male",
                DateOfBirth = new DateOnly(1985, 05, 10),
                PhoneNumber = "1234567890",
                Email = "john.doe@example.com",
                Address = "123 Main St",
                City = "New York",
                State = "NY",
                PostalCode = "10001",
                Country = "USA",
                OrganizationId = 101,
                Active = true,
                DateCreated = now,
                CreatedBy = 1001,
                LastModifiedBy = 1002,
                LastModifiedDate = now,
                ImageUrl = "https://example.com/profile.jpg",
                NextAvailability = new DateOnly(2025, 05, 01),
                CreatedByNavigation = new AdminUser(),
                LastModifiedByNavigation = new AdminUser(),
                Organization = new AdminOrganization()
            };

            // Add navigation collections
            doctorProfile.AdminDoctorLocations.Add(new AdminDoctorLocation());
            doctorProfile.AdminDoctorSchedules.Add(new AdminDoctorSchedule());
            doctorProfile.AdminDoctorSpecialities.Add(new AdminDoctorSpeciality());
            doctorProfile.Languages.Add(new Language());
            doctorProfile.PatientDoctorAppointments.Add(new PatientDoctorAppointment());

            // Assert
            Assert.Equal(1, doctorProfile.DoctorProfileId);
            Assert.Equal("DR123", doctorProfile.Identifier);
            Assert.Equal("John", doctorProfile.FirstName);
            Assert.Equal("Doe", doctorProfile.LastName);
            Assert.Equal("M", doctorProfile.MiddleName);
            Assert.Equal("Male", doctorProfile.Gender);
            Assert.Equal(new DateOnly(1985, 05, 10), doctorProfile.DateOfBirth);
            Assert.Equal("1234567890", doctorProfile.PhoneNumber);
            Assert.Equal("john.doe@example.com", doctorProfile.Email);
            Assert.Equal("123 Main St", doctorProfile.Address);
            Assert.Equal("New York", doctorProfile.City);
            Assert.Equal("NY", doctorProfile.State);
            Assert.Equal("10001", doctorProfile.PostalCode);
            Assert.Equal("USA", doctorProfile.Country);
            Assert.Equal(101, doctorProfile.OrganizationId);
            Assert.True(doctorProfile.Active);
            Assert.Equal(now, doctorProfile.DateCreated);
            Assert.Equal(1001, doctorProfile.CreatedBy);
            Assert.Equal(1002, doctorProfile.LastModifiedBy);
            Assert.Equal(now, doctorProfile.LastModifiedDate);
            Assert.Equal("https://example.com/profile.jpg", doctorProfile.ImageUrl);
            Assert.Equal(new DateOnly(2025, 05, 01), doctorProfile.NextAvailability);

            Assert.NotNull(doctorProfile.CreatedByNavigation);
            Assert.NotNull(doctorProfile.LastModifiedByNavigation);
            Assert.NotNull(doctorProfile.Organization);

            Assert.Single(doctorProfile.AdminDoctorLocations);
            Assert.Single(doctorProfile.AdminDoctorSchedules);
            Assert.Single(doctorProfile.AdminDoctorSpecialities);
            Assert.Single(doctorProfile.Languages);
            Assert.Single(doctorProfile.PatientDoctorAppointments);
        }
    }
}
