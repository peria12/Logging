﻿using Aurora.AdministrationService.Domain.Entities;
using Aurora.AdministrationService.Domain.Old.Entities;

namespace Aurora.AdministrationService.Tests.DomainTest.Entities
{
    public class PatientDoctorAppointmentTests
    {
        [Fact]
        public void Can_Create_PatientDoctorAppointment_With_All_Properties()
        {
            // Arrange
            var appointment = new PatientDoctorAppointment
            {
                AppointmentId = 1,
                DoctorProfileId = 101,
                SlotId = 202,
                VisitType = "New",
                PaymentMethod = "Credit Card",
                StartDateTime = new DateTime(2023, 5, 1, 10, 30, 0, DateTimeKind.Local), // Set Kind to Local
                EndDateTime = new DateTime(2023, 5, 1, 11, 0, 0, DateTimeKind.Local), // Set Kind to Local
                SlotType = "Morning",
                Status = "Scheduled",
                ReasonCode = "Consultation",
                Notes = "Patient needs to bring reports",
                Description = "Follow-up visit",
                CreatedBy = 1,
                LastModifiedBy = 2,
                CheckInTime = new DateTime(2023, 5, 1, 10, 25, 0, DateTimeKind.Local), // Set Kind to Local
                IsBlacklisted = false,
                PatientId = "P123",
                AppointmentLocationId = 301,
                AppointmentLocation = new AdminLocation { LocationId = 301, Name = "Room 101" },
                DoctorProfile = new AdminDoctorProfile { DoctorProfileId = 101, FirstName = "Dr. Smith" },
                Patient = new User { UserId = "P123", Name = "John Doe" },
                Slot = new AppointmentSlot { SlotId = 202, SlotStart = new DateTime(2023, 5, 1, 10, 0, 0, DateTimeKind.Local) } // Set Kind to Local
            };

            // Assert
            Assert.Equal(1, appointment.AppointmentId);
            Assert.Equal(101, appointment.DoctorProfileId);
            Assert.Equal(202, appointment.SlotId);
            Assert.Equal("New", appointment.VisitType);
            Assert.Equal("Credit Card", appointment.PaymentMethod);
            Assert.Equal(new DateTime(2023, 5, 1, 10, 30, 0, DateTimeKind.Local), appointment.StartDateTime);
            Assert.Equal(new DateTime(2023, 5, 1, 11, 0, 0, DateTimeKind.Local), appointment.EndDateTime);
            Assert.Equal("Morning", appointment.SlotType);
            Assert.Equal("Scheduled", appointment.Status);
            Assert.Equal("Consultation", appointment.ReasonCode);
            Assert.Equal("Patient needs to bring reports", appointment.Notes);
            Assert.Equal("Follow-up visit", appointment.Description);
            Assert.Equal(1, appointment.CreatedBy);
            Assert.Equal(2, appointment.LastModifiedBy);
            Assert.Equal(new DateTime(2023, 5, 1, 10, 25, 0, DateTimeKind.Local), appointment.CheckInTime);
            Assert.False(appointment.IsBlacklisted);
            Assert.Equal("P123", appointment.PatientId);
            Assert.Equal(301, appointment.AppointmentLocationId);
            Assert.NotNull(appointment.AppointmentLocation);
            Assert.Equal(301, appointment.AppointmentLocation.LocationId);
            Assert.NotNull(appointment.DoctorProfile);
            Assert.Equal(101, appointment.DoctorProfile.DoctorProfileId);
            Assert.NotNull(appointment.Patient);
            Assert.Equal("P123", appointment.Patient.UserId);
            Assert.NotNull(appointment.Slot);
            Assert.Equal(202, appointment.Slot.SlotId);
        }
      
    }
}
