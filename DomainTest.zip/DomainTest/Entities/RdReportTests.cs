﻿using Aurora.AdministrationService.Domain.Entities;
using Aurora.AdministrationService.Domain.Old.Entities;

namespace Aurora.AdministrationService.Tests.DomainTest.Entities
{
    public class RdReportTests
    {
        [Fact]
        public void Can_Create_RdReport_With_All_Properties()
        {
            // Arrange
            var caption = new FdCaption(); // Assuming default constructor is fine
            var mainMenus = new List<FdMainMenu> { new FdMainMenu(), new FdMainMenu() };

            var report = new RdReport
            {
                Id = 1,
                ReportName = "Monthly Summary",
                FormId = 101,
                CaptionId = 5,
                Rdlfile = "report1.rdl",
                ReportModuleId = 3,
                IsDeleted = false,
                CreatedBy = "admin",
                CreatedDate = DateTime.UtcNow,
                UpdatedBy = "admin2",
                UpdatedDate = DateTime.UtcNow.AddDays(1),
                FacilityCode = "FAC001",
                Caption = caption,
                FdMainMenus = mainMenus
            };

            // Assert
            Assert.Equal(1, report.Id);
            Assert.Equal("Monthly Summary", report.ReportName);
            Assert.Equal(101, report.FormId);
            Assert.Equal(5, report.CaptionId);
            Assert.Equal("report1.rdl", report.Rdlfile);
            Assert.Equal(3, report.ReportModuleId);
            Assert.False(report.IsDeleted);
            Assert.Equal("admin", report.CreatedBy);
            Assert.Equal("admin2", report.UpdatedBy);
            Assert.Equal("FAC001", report.FacilityCode);
            Assert.NotNull(report.Caption);
            Assert.Equal(2, report.FdMainMenus.Count);
        }

        [Fact]
        public void Can_Create_RdReport_With_Required_Fields_Only()
        {
            // Arrange
            var report = new RdReport
            {
                Id = 2,
                ReportName = "Basic Report",
                CaptionId = 2,
                ReportModuleId = 1,
                IsDeleted = false,
                CreatedBy = "user1",
                CreatedDate = DateTime.UtcNow,
                FacilityCode = "FAC002",
                Caption = new FdCaption()
            };

            // Assert
            Assert.Equal(2, report.Id);
            Assert.Equal("Basic Report", report.ReportName);
            Assert.Null(report.FormId);
            Assert.Null(report.Rdlfile);
            Assert.Null(report.UpdatedBy);
            Assert.Null(report.UpdatedDate);
            Assert.Empty(report.FdMainMenus);
        }

        [Fact]
        public void FdMainMenus_Should_Be_Initialized_As_Empty_List_By_Default()
        {
            // Arrange
            var report = new RdReport();

            // Assert
            Assert.NotNull(report.FdMainMenus);
            Assert.Empty(report.FdMainMenus);
        }

        [Fact]
        public void Can_Update_RdReport_Optional_Fields()
        {
            // Arrange
            var report = new RdReport
            {
                Id = 3,
                ReportName = "Initial Report",
                CaptionId = 10,
                ReportModuleId = 4,
                IsDeleted = false,
                CreatedBy = "creator",
                CreatedDate = DateTime.UtcNow,
                FacilityCode = "FAC100",
                Caption = new FdCaption()
            };

            // Act
            report.FormId = 200;
            report.Rdlfile = "updated.rdl";
            report.UpdatedBy = "editor";
            report.UpdatedDate = DateTime.UtcNow;

            // Assert
            Assert.Equal(200, report.FormId);
            Assert.Equal("updated.rdl", report.Rdlfile);
            Assert.Equal("editor", report.UpdatedBy);
            Assert.NotNull(report.UpdatedDate);
        }

        [Fact]
        public void Can_Set_Caption_And_FdMainMenus()
        {
            // Arrange
            var caption = new FdCaption();
            var menuList = new List<FdMainMenu> { new FdMainMenu { }, new FdMainMenu { } };

            var report = new RdReport
            {
                Caption = caption,
                FdMainMenus = menuList
            };

            // Assert
            Assert.Equal(caption, report.Caption);
            Assert.Equal(2, report.FdMainMenus.Count);
        }
    }
}
