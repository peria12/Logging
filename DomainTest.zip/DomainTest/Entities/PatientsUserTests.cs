﻿using Aurora.AdministrationService.Domain.Entities;
using Aurora.AdministrationService.Domain.Old.Entities;

namespace Aurora.AdministrationService.Tests.DomainTest.Entities
{
    public class PatientsUserTests
    {
        [Fact]
        public void Can_Create_PatientUser_With_All_Properties()
        {
            // Arrange
            var patientUser = new PatientsUser
            {
                PatientId = 1,
                Name = "John Doe",
                ImageUrl = "http://example.com/image.jpg",
                Gender = "Male",
                PhoneNumber = "123-456-7890",
                Email = "johndoe@example.com",
                CreatedAt = DateTime.Now,
                UpdatedAt = DateTime.Now.AddMinutes(10),
                Address = "123 Main St",
                City = "Sample City",
                State = "Sample State",
                PostalCode = "12345",
                Country = "Sample Country",
                MaritalStatus = "Single",
                Nationality = "Country X",
                Active = true,
                PreferredName = "Johnny",
                CreatedBy = "Admin",
                UpdatedBy = "Admin"
            };

            // Assert
            Assert.Equal(1, patientUser.PatientId);
            Assert.Equal("John Doe", patientUser.Name);
            Assert.Equal("http://example.com/image.jpg", patientUser.ImageUrl);
            Assert.Equal("Male", patientUser.Gender);
            Assert.Equal("123-456-7890", patientUser.PhoneNumber);
            Assert.Equal("johndoe@example.com", patientUser.Email);
            Assert.NotNull(patientUser.UpdatedAt);
            Assert.Equal("123 Main St", patientUser.Address);
            Assert.Equal("Sample City", patientUser.City);
            Assert.Equal("Sample State", patientUser.State);
            Assert.Equal("12345", patientUser.PostalCode);
            Assert.Equal("Sample Country", patientUser.Country);
            Assert.Equal("Single", patientUser.MaritalStatus);
            Assert.Equal("Country X", patientUser.Nationality);
            Assert.True(patientUser.Active.HasValue && patientUser.Active.Value);
            Assert.Equal("Johnny", patientUser.PreferredName);
            Assert.Equal("Admin", patientUser.CreatedBy);
            Assert.Equal("Admin", patientUser.UpdatedBy);
        }

        [Fact]
        public void Can_Create_PatientUser_With_Null_Optional_Properties()
        {
            // Arrange
            var patientUser = new PatientsUser
            {
                PatientId = 2,
                Name = "Jane Smith",
                Gender = "Female",
                PhoneNumber = "987-654-3210",
                Email = "janesmith@example.com",
                CreatedAt = DateTime.Now,
                UpdatedAt = null, // Optional property
                DateOfBirth = null, // Optional property
                Address = null, // Optional property
                City = null, // Optional property
                State = null, // Optional property
                PostalCode = null, // Optional property
                Country = null, // Optional property
                MaritalStatus = null, // Optional property
                Nationality = null, // Optional property
                Active = null, // Nullable bool
                PreferredName = null, // Optional property
                CreatedBy = "Admin",
                UpdatedBy = null // Optional property
            };

            // Assert
            Assert.Equal(2, patientUser.PatientId);
            Assert.Equal("Jane Smith", patientUser.Name);
            Assert.Null(patientUser.ImageUrl);
            Assert.Equal("Female", patientUser.Gender);
            Assert.Equal("987-654-3210", patientUser.PhoneNumber);
            Assert.Equal("janesmith@example.com", patientUser.Email);
            Assert.Null(patientUser.UpdatedAt);
            Assert.Null(patientUser.DateOfBirth);
            Assert.Null(patientUser.Address);
            Assert.Null(patientUser.City);
            Assert.Null(patientUser.State);
            Assert.Null(patientUser.PostalCode);
            Assert.Null(patientUser.Country);
            Assert.Null(patientUser.MaritalStatus);
            Assert.Null(patientUser.Nationality);
            Assert.Null(patientUser.Active);
            Assert.Null(patientUser.PreferredName);
            Assert.Equal("Admin", patientUser.CreatedBy);
            Assert.Null(patientUser.UpdatedBy);
        }

        [Fact]
        public void Can_Create_PatientUser_With_Required_Properties_Only()
        {
            // Arrange
            var patientUser = new PatientsUser
            {
                PatientId = 3,
                Name = "Alice Johnson",
                Gender = "Female",
                PhoneNumber = "321-654-9870",
                Email = "alicejohnson@example.com",
                CreatedAt = DateTime.Now,
                CreatedBy = "Admin"
            };

            // Assert
            Assert.Equal(3, patientUser.PatientId);
            Assert.Equal("Alice Johnson", patientUser.Name);
            Assert.Equal("Female", patientUser.Gender);
            Assert.Equal("321-654-9870", patientUser.PhoneNumber);
            Assert.Equal("alicejohnson@example.com", patientUser.Email);
            Assert.Equal("Admin", patientUser.CreatedBy);
            Assert.Null(patientUser.UpdatedAt); // Optional property
            Assert.Null(patientUser.DateOfBirth); // Optional property
            Assert.Null(patientUser.Address); // Optional property
        }

        [Fact]
        public void Can_Create_PatientUser_With_DateOfBirth_Null()
        {
            // Arrange
            var patientUser = new PatientsUser
            {
                PatientId = 4,
                Name = "Robert Brown",
                Gender = "Male",
                PhoneNumber = "456-789-0123",
                Email = "robertbrown@example.com",
                CreatedAt = DateTime.Now,
                DateOfBirth = null // DateOfBirth can be null
            };

            // Assert
            Assert.Equal(4, patientUser.PatientId);
            Assert.Equal("Robert Brown", patientUser.Name);
            Assert.Null(patientUser.DateOfBirth);
        }

        [Fact]
        public void Can_Create_PatientUser_With_Active_Flag_As_Null()
        {
            // Arrange
            var patientUser = new PatientsUser
            {
                PatientId = 5,
                Name = "Eva Green",
                Gender = "Female",
                PhoneNumber = "555-123-4567",
                Email = "evagreen@example.com",
                CreatedAt = DateTime.Now,
                Active = null // Active can be null
            };

            // Assert
            Assert.Equal(5, patientUser.PatientId);
            Assert.Equal("Eva Green", patientUser.Name);
            Assert.Null(patientUser.Active);
        }
    }
}
