﻿using Aurora.AdministrationService.Domain.Entities;
using Aurora.AdministrationService.Domain.Old.Entities;

namespace Aurora.AdministrationService.Tests.DomainTest.Entities
{
    public class LanguageTests
    {
        [Fact]
        public void Can_Create_Language_With_Valid_Values()
        {
            // Arrange
            var language = new Language
            {
                LanguageId = 1,
                LanguageCode = "en",
                LanguageName = "English",
                Region = "US",
                DoctorProfileId = 101,
                DoctorProfile = new AdminDoctorProfile() // You can mock this if needed
            };

            // Assert
            Assert.Equal(1, language.LanguageId);
            Assert.Equal("en", language.LanguageCode);
            Assert.Equal("English", language.LanguageName);
            Assert.Equal("US", language.Region);
            Assert.Equal(101, language.DoctorProfileId);
            Assert.NotNull(language.DoctorProfile);
        }

        [Fact]
        public void Can_Create_Language_With_Minimum_Values()
        {
            // Arrange
            var language = new Language
            {
                LanguageId = 2,
                LanguageCode = "fr",
                LanguageName = "French"
                // Region, DoctorProfileId, and DoctorProfile left null
            };

            // Assert
            Assert.Equal(2, language.LanguageId);
            Assert.Equal("fr", language.LanguageCode);
            Assert.Equal("French", language.LanguageName);
            Assert.Null(language.Region);
            Assert.Null(language.DoctorProfileId);
            Assert.Null(language.DoctorProfile);
        }
    }
}
