﻿using Aurora.AdministrationService.Domain.Entities;
using Aurora.AdministrationService.Domain.Old.Entities;

namespace Aurora.AdministrationService.Tests.DomainTest.Entities
{
    public class AdminSpecialityTests
    {
        [Fact]
        public void Can_Create_And_Assign_AdminSpeciality_Properties()
        {
            // Arrange
            var dateCreated = DateTime.UtcNow;
            var lastModifiedDate = DateTime.UtcNow;

            var speciality = new AdminSpeciality
            {
                SpecialityId = 101,
                Code = "CARD",
                DisplayName = "Cardiology",
                Description = "Heart related speciality",
                IsActive = true,
                DateCreated = dateCreated,
                CreatedBy = 1,
                LastModifiedBy = 2,
                LastModifiedDate = lastModifiedDate,
                CreatedByNavigation = new AdminUser
                {
                    AdminId = 1,
                    Username = "creator"
                },
                LastModifiedByNavigation = new AdminUser
                {
                    AdminId = 2,
                    Username = "modifier"
                }
            };

            // Assert
            Assert.Equal(101, speciality.SpecialityId);
            Assert.Equal("CARD", speciality.Code);
            Assert.Equal("Cardiology", speciality.DisplayName);
            Assert.Equal("Heart related speciality", speciality.Description);
            Assert.True(speciality.IsActive);
            Assert.Equal(dateCreated, speciality.DateCreated);
            Assert.Equal(1, speciality.CreatedBy);
            Assert.Equal(2, speciality.LastModifiedBy);
            Assert.Equal(lastModifiedDate, speciality.LastModifiedDate);

            Assert.NotNull(speciality.CreatedByNavigation);
            Assert.Equal(1, speciality.CreatedByNavigation.AdminId);
            Assert.Equal("creator", speciality.CreatedByNavigation.Username);

            Assert.NotNull(speciality.LastModifiedByNavigation);
            Assert.Equal(2, speciality.LastModifiedByNavigation.AdminId);
            Assert.Equal("modifier", speciality.LastModifiedByNavigation.Username);
        }
    }
}
