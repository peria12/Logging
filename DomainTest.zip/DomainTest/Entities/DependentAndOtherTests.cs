﻿using Aurora.AdministrationService.Domain.Entities;
using Aurora.AdministrationService.Domain.Old.Entities;

namespace Aurora.AdministrationService.Tests.DomainTest.Entities
{
    public class DependentAndOtherTests
    {
        [Fact]
        public void Can_Create_And_Assign_DependentAndOther_Properties()
        {
            // Arrange
            var now = DateTime.UtcNow;

            var patient = new PatientUser
            {
                PatientId = "P123"
            };

            var relation = new PatientUser
            {
                PatientId = "P456"
            };

            var dependent = new DependentAndOther
            {
                DependentId = 1,
                PatientId = "P123",
                RelationId = "P456",
                RelationshipCode = "FTHR",
                ContactNumber = "1234567890",
                CreatedAt = now,
                UpdatedAt = now.AddMinutes(30),
                CreatedBy = "System",
                Patient = patient,
                Relation = relation
            };

            // Assert
            Assert.Equal(1, dependent.DependentId);
            Assert.Equal("P123", dependent.PatientId);
            Assert.Equal("P456", dependent.RelationId);
            Assert.Equal("FTHR", dependent.RelationshipCode);
            Assert.Equal("1234567890", dependent.ContactNumber);
            Assert.Equal(now, dependent.CreatedAt);
            Assert.Equal(now.AddMinutes(30), dependent.UpdatedAt);
            Assert.Equal("System", dependent.CreatedBy);
            Assert.Equal(patient, dependent.Patient);
            Assert.Equal(relation, dependent.Relation);
        }

        [Fact]
        public void Can_Handle_Optional_Values_As_Null()
        {
            // Arrange
            var dependent = new DependentAndOther
            {
                DependentId = 2,
                PatientId = "P789",
                RelationId = "P654",
                RelationshipCode = null,
                ContactNumber = null,
                CreatedAt = null,
                UpdatedAt = null,
                CreatedBy = null,
                Patient = new PatientUser { PatientId = "P789" },
                Relation = new PatientUser { PatientId = "P654" }
            };

            // Assert
            Assert.Null(dependent.RelationshipCode);
            Assert.Null(dependent.ContactNumber);
            Assert.Null(dependent.CreatedAt);
            Assert.Null(dependent.UpdatedAt);
            Assert.Null(dependent.CreatedBy);
        }
    }
}
