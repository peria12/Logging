﻿using Aurora.AdministrationService.Domain.Entities;

namespace Aurora.AdministrationService.Tests.DomainTest.Entities
{
    public class NotificationTemplateTests
    {
        [Fact]
        public void Can_Create_NotificationTemplate_With_All_Properties()
        {
            // Arrange
            var createdDate = DateTime.UtcNow;
            var updatedDate = createdDate.AddHours(1);

            var notificationTemplate = new NotificationTemplate
            {
                ID = 1,
                UniqueID = "Template1",
                Status = true,
                Module = "AdminModule",
                UserGroup = "GroupA",
                RecordVersion = new byte[] { 0x01, 0x02 },
                IsDeleted = false,
                CreatedBy = "admin",
                CreatedDate = createdDate,
                UpdatedBy = "editor",
                UpdatedDate = updatedDate
            };

            // Assert
            Assert.Equal(1, notificationTemplate.ID);
            Assert.Equal("Template1", notificationTemplate.UniqueID);
            Assert.True(notificationTemplate.Status);
            Assert.Equal("AdminModule", notificationTemplate.Module);
            Assert.Equal("GroupA", notificationTemplate.UserGroup);
            Assert.Equal(new byte[] { 0x01, 0x02 }, notificationTemplate.RecordVersion);
            Assert.False(notificationTemplate.IsDeleted);
            Assert.Equal("admin", notificationTemplate.CreatedBy);
            Assert.Equal(createdDate, notificationTemplate.CreatedDate);
            Assert.Equal("editor", notificationTemplate.UpdatedBy);
            Assert.Equal(updatedDate, notificationTemplate.UpdatedDate);
        }

        [Fact]
        public void Can_Create_NotificationTemplate_With_Minimum_Required_Fields()
        {
            // Arrange
            var createdDate = DateTime.UtcNow;

            var notificationTemplate = new NotificationTemplate
            {
                ID = 2,
                UniqueID = "Template2",
                Status = false,
                Module = "UserModule",
                UserGroup = "GroupB",
                IsDeleted = true,
                CreatedBy = "admin",
                CreatedDate = createdDate
            };

            // Assert
            Assert.Equal(2, notificationTemplate.ID);
            Assert.Equal("Template2", notificationTemplate.UniqueID);
            Assert.False(notificationTemplate.Status);
            Assert.Equal("UserModule", notificationTemplate.Module);
            Assert.Equal("GroupB", notificationTemplate.UserGroup);
            Assert.True(notificationTemplate.IsDeleted);
            Assert.Equal("admin", notificationTemplate.CreatedBy);
            Assert.Equal(createdDate, notificationTemplate.CreatedDate);
        }       
    }
}
