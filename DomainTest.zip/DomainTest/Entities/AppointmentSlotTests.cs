﻿using Aurora.AdministrationService.Domain.Old.Entities;

namespace Aurora.AdministrationService.Tests.DomainTest.Entities
{
    public class AppointmentSlotTests
    {
        [Fact]
        public void Can_Create_And_Assign_AppointmentSlot_Properties()
        {
            // Arrange
            var start = new DateTime(2025, 4, 13, 9, 0, 0);
            var end = new DateTime(2025, 4, 13, 9, 30, 0);

            var appointmentSlot = new AppointmentSlot
            {
                SlotId = 1,
                SlotStart = start,
                SlotEnd = end,
                Period = "Morning",
                Status = "Available",
                ServiceCategory = "General Medicine",
                ServiceType = "Consultation",
                DoctorSpecialityId = 1001,
                DoctorProfileId = 2002,
                DoctorSpeciality = new AdminDoctorSpeciality
                {
                    DoctorSpecialityId = 1001,
                    Speciality = "Cardiology",
                    IsActive = true
                },
                PatientDoctorAppointments = new List<PatientDoctorAppointment>
                {
                    new PatientDoctorAppointment { AppointmentId = 1 },
                    new PatientDoctorAppointment { AppointmentId = 2 }
                }
            };

            // Assert
            Assert.Equal(1, appointmentSlot.SlotId);
            Assert.Equal(start, appointmentSlot.SlotStart);
            Assert.Equal(end, appointmentSlot.SlotEnd);
            Assert.Equal("Morning", appointmentSlot.Period);
            Assert.Equal("Available", appointmentSlot.Status);
            Assert.Equal("General Medicine", appointmentSlot.ServiceCategory);
            Assert.Equal("Consultation", appointmentSlot.ServiceType);
            Assert.Equal(1001, appointmentSlot.DoctorSpecialityId);
            Assert.Equal(2002, appointmentSlot.DoctorProfileId);

            Assert.NotNull(appointmentSlot.DoctorSpeciality);
            Assert.Equal("Cardiology", appointmentSlot.DoctorSpeciality.Speciality);
            Assert.True(appointmentSlot.DoctorSpeciality.IsActive);

            Assert.NotNull(appointmentSlot.PatientDoctorAppointments);
            Assert.Equal(2, appointmentSlot.PatientDoctorAppointments.Count);
        }

        [Fact]
        public void Can_Handle_Nullable_Fields()
        {
            // Arrange
            var appointmentSlot = new AppointmentSlot
            {
                SlotId = 2,
                SlotStart = DateTime.UtcNow,
                SlotEnd = DateTime.UtcNow.AddMinutes(30),
                Period = "Evening",
                Status = "Booked"
                // Leaving ServiceCategory, ServiceType, DoctorSpecialityId, DoctorProfileId null
            };

            // Assert
            Assert.Null(appointmentSlot.ServiceCategory);
            Assert.Null(appointmentSlot.ServiceType);
            Assert.Null(appointmentSlot.DoctorSpecialityId);
            Assert.Null(appointmentSlot.DoctorProfileId);
            Assert.Null(appointmentSlot.DoctorSpeciality);
            Assert.Empty(appointmentSlot.PatientDoctorAppointments);
        }
    }
}
