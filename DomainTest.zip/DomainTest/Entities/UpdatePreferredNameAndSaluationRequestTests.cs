﻿using Aurora.AdministrationService.API.Models.Dto.Users.UserNames;
using Aurora.AdministrationService.CrossCutting.Constants;
using FluentAssertions;
using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Aurora.AdministrationService.Tests.DomainTest.Entities
{
 public class UpdatePreferredNameAndSalutationRequestTests
    {
        [Theory]
        [InlineData("John", "Mr")]  // Valid case
        [InlineData("Jane", "Ms")]  // Valid case
        public void UpdatePreferredNameAndSalutationRequest_Should_Be_Valid(string preferredName, string salutation)
        {
            // Arrange
            var request = new UpdatePreferredNameAndSaluationRequest
            {
                PreferredName = preferredName,
                Salutation = salutation
            };

            // Act
            var validationResults = ValidateModel(request);

            // Assert
            validationResults.Should().BeEmpty(); // No validation errors expected
        }

        [Theory]
        [InlineData("John", "")]        // Salutation is empty
        [InlineData("John", "Dr1")]     // Salutation contains numbers
        [InlineData("John", "Dr@")]     // Salutation contains special characters
        public void UpdatePreferredNameAndSalutationRequest_Should_Have_Invalid_Salutation(string preferredName, string salutation)
        {
            // Arrange
            var request = new UpdatePreferredNameAndSaluationRequest
            {
                PreferredName = preferredName,
                Salutation = salutation
            };

            // Act
            var validationResults = ValidateModel(request);

            // Assert
            validationResults.Should().Contain(x => 
                x.ErrorMessage == CommonConstants.VALIDATION_SALUTATION 
                || x.ErrorMessage == CommonConstants.VALIDATION_SALUTATION_MIN
                || x.ErrorMessage == CommonConstants.VALIDATION_SALUTATION_INVALID);
        }

        private static List<ValidationResult> ValidateModel(object model)
        {
            var validationResults = new List<ValidationResult>();
            var validationContext = new ValidationContext(model, null, null);
            Validator.TryValidateObject(model, validationContext, validationResults, true);
            return validationResults;
        }
    }
}
