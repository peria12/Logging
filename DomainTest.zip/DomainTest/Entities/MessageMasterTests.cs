﻿using Aurora.AdministrationService.Domain.Entities;
using Aurora.AdministrationService.Domain.Old.Entities;

namespace Aurora.AdministrationService.Tests.DomainTest.Entities
{
    public class MessageMasterTests
    {
        [Fact]
        public void Can_Create_MessageMaster_With_All_Values()
        {
            // Arrange
            var createdDate = DateTime.UtcNow;
            var updatedDate = createdDate.AddHours(1);

            var messageMaster = new MessageMaster
            {
                Id = 1,
                EnUs = "Save successful",
                Description = "Generic success message",
                IsActive = true,
                IsDeleted = false,
                CreatedBy = "admin",
                CreatedDate = createdDate,
                UpdatedBy = "editor",
                UpdatedDate = updatedDate,
                DefaultMessage = "Operation completed",
                MessageType = 1,
                FacilityCode = "FAC001",
                FdMainMenus = new List<FdMainMenu> { new FdMainMenu { Id = 100, MenuName = "Dashboard", FacilityCode = "FAC001" } }
            };

            // Assert
            Assert.Equal(1, messageMaster.Id);
            Assert.Equal("Save successful", messageMaster.EnUs);
            Assert.Equal("Generic success message", messageMaster.Description);
            Assert.True(messageMaster.IsActive);
            Assert.False(messageMaster.IsDeleted);
            Assert.Equal("admin", messageMaster.CreatedBy);
            Assert.Equal(createdDate, messageMaster.CreatedDate);
            Assert.Equal("editor", messageMaster.UpdatedBy);
            Assert.Equal(updatedDate, messageMaster.UpdatedDate);
            Assert.Equal("Operation completed", messageMaster.DefaultMessage);
            Assert.Equal((byte)1, messageMaster.MessageType);
            Assert.Equal("FAC001", messageMaster.FacilityCode);
            Assert.Single(messageMaster.FdMainMenus);
        }

        [Fact]
        public void Can_Create_MessageMaster_With_Minimum_Values()
        {
            // Arrange
            var messageMaster = new MessageMaster
            {
                Id = 2,
                IsActive = false,
                IsDeleted = true,
                CreatedBy = "system",
                CreatedDate = DateTime.UtcNow,
                DefaultMessage = "Default fallback message",
                MessageType = 0,
                FacilityCode = "FAC002"
                // Optional fields left as null/default
            };

            // Assert
            Assert.Equal(2, messageMaster.Id);
            Assert.Null(messageMaster.EnUs);
            Assert.Null(messageMaster.Description);
            Assert.False(messageMaster.IsActive);
            Assert.True(messageMaster.IsDeleted);
            Assert.Equal("system", messageMaster.CreatedBy);
            Assert.NotEqual(default, messageMaster.CreatedDate);
            Assert.Null(messageMaster.UpdatedBy);
            Assert.Null(messageMaster.UpdatedDate);
            Assert.Equal("Default fallback message", messageMaster.DefaultMessage);
            Assert.Equal((byte)0, messageMaster.MessageType);
            Assert.Equal("FAC002", messageMaster.FacilityCode);
            Assert.Empty(messageMaster.FdMainMenus);
        }
    }
}
