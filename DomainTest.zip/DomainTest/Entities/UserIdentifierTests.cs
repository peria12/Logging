﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using FluentAssertions;
using Xunit;
using Aurora.AdministrationService.Domain.V1.Entities.Users;

namespace Aurora.AdministrationService.Tests.DomainTest.Entities
{
    public class UserIdentifierTests
    {
        [Fact]
        public void UserIdentifier_Should_Initialize_Required_And_Optional_Fields_Correctly()
        {
            // Arrange
            var userIdentifier = new UserIdentifier
            {
                UserID = 1,
                System = "SystemA",
                Status = true,
                Value = "1234567890",
                IsDeleted = false,
                CreatedBy = "admin",
                CreatedDate = DateTime.UtcNow,
                UpdatedBy = "admin",
            };

            // Act & Assert: Ensure required fields are properly initialized
            userIdentifier.UserID.Should().Be(1);
            userIdentifier.System.Should().NotBeNullOrEmpty();
            userIdentifier.Status.Should().BeTrue();
            userIdentifier.Value.Should().NotBeNullOrEmpty();
            userIdentifier.IsDeleted.Should().BeFalse();
            userIdentifier.CreatedBy.Should().NotBeNullOrEmpty();
            userIdentifier.CreatedDate.Should().BeAfter(DateTime.MinValue);
            userIdentifier.UpdatedBy.Should().NotBeNullOrEmpty();

            // Assert: Ensure optional fields are left as null by default
            userIdentifier.IdentifierUse.Should().BeNull();
            userIdentifier.IdentifierType.Should().BeNull();
            userIdentifier.PeriodStart.Should().BeNull();
            userIdentifier.PeriodEnd.Should().BeNull();
            userIdentifier.UpdatedDate.Should().BeNull();
            userIdentifier.RecordVersion.Should().BeEmpty();
        }

        [Fact]
        public void UserIdentifier_ShouldHaveValidMaxLengthForProperties()
        {
            // Arrange
            var userIdentifier = new UserIdentifier
            {
                UserID =1,
                System = new string('a', 21), // Exceeds max length of 20
                Value = new string('a', 101), // Exceeds max length of 100
                IdentifierUse = new string('a', 21), // Exceeds max length of 20
                IdentifierType = new string('a', 21), // Exceeds max length of 20
                CreatedBy = new string('a', 51), // Exceeds max length of 50
                UpdatedBy = new string('a', 51), // Exceeds max length of 50
                Status = true,
                CreatedDate = DateTime.Now,
                IsDeleted = false
            };

            // Act
            var validationResults = new List<ValidationResult>();
            var isValid = Validator.TryValidateObject(userIdentifier, new ValidationContext(userIdentifier), validationResults, true);

            // Assert
            isValid.Should().BeFalse();
            validationResults.Should().Contain(v => v.MemberNames.Contains("System"));
            validationResults.Should().Contain(v => v.MemberNames.Contains("Value"));
            validationResults.Should().Contain(v => v.MemberNames.Contains("IdentifierUse"));
            validationResults.Should().Contain(v => v.MemberNames.Contains("IdentifierType"));
            validationResults.Should().Contain(v => v.MemberNames.Contains("CreatedBy"));
            validationResults.Should().Contain(v => v.MemberNames.Contains("UpdatedBy"));
        }
    }
}
