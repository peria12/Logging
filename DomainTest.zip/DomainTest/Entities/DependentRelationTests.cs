﻿using Aurora.AdministrationService.Domain.Entities;
using Aurora.AdministrationService.Domain.Old.Entities;

namespace Aurora.AdministrationService.Tests.DomainTest.Entities
{
    public class DependentRelationTests
    {
        [Fact]
        public void Can_Create_DependentRelation_With_All_Properties()
        {
            // Arrange
            var now = DateTime.UtcNow;

            var relation = new DependentRelation
            {
                DependentId = 101,
                PatientId = "P123",
                RelationId = 202,
                RelationshipCode = "MOTHER",
                ContactNumber = "9876543210",
                CreatedAt = now,
                UpdatedAt = now.AddMinutes(10),
                CreatedBy = "admin",
                UpdatedBy = "system"
            };

            // Assert
            Assert.Equal(101, relation.DependentId);
            Assert.Equal("P123", relation.PatientId);
            Assert.Equal(202, relation.RelationId);
            Assert.Equal("MOTHER", relation.RelationshipCode);
            Assert.Equal("9876543210", relation.ContactNumber);
            Assert.Equal(now, relation.CreatedAt);
            Assert.Equal(now.AddMinutes(10), relation.UpdatedAt);
            Assert.Equal("admin", relation.CreatedBy);
            Assert.Equal("system", relation.UpdatedBy);
        }

        [Fact]
        public void Can_Handle_Null_Optional_Fields()
        {
            // Arrange
            var now = DateTime.UtcNow;

            var relation = new DependentRelation
            {
                DependentId = 102,
                PatientId = "P456",
                RelationId = 303,
                RelationshipCode = "BROTHER",
                ContactNumber = null,
                CreatedAt = now,
                UpdatedAt = null,
                CreatedBy = null,
                UpdatedBy = null
            };

            // Assert
            Assert.Equal("P456", relation.PatientId);
            Assert.Equal("BROTHER", relation.RelationshipCode);
            Assert.Null(relation.ContactNumber);
            Assert.Null(relation.UpdatedAt);
            Assert.Null(relation.CreatedBy);
            Assert.Null(relation.UpdatedBy);
        }
    }
}
