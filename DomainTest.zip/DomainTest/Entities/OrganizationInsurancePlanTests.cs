﻿using Aurora.AdministrationService.Domain.Entities;
using Aurora.AdministrationService.Domain.Old.Entities;

namespace Aurora.AdministrationService.Tests.DomainTest.Entities
{
    public class OrganizationInsurancePlanTests
    {
        [Fact]
        public void Can_Create_OrganizationInsurancePlan_With_All_Properties()
        {
            // Arrange
            var organizationInsurancePlan = new OrganizationInsurancePlan
            {
                OrganizationInsurancePlanId = 1,
                OrganizationId = 1001,
                InsurancePlanId = 2002,
                CoverageArea = "North Region",
                Network = "Network A",
                PeriodStart = new DateOnly(2023, 1, 1),
                PeriodEnd = new DateOnly(2023, 12, 31),
                Status = "Active",
                InsurancePlan = new InsuranceCoverage { /* Add appropriate values for InsuranceCoverage */ },
                Organization = new AdminOrganization { /* Add appropriate values for AdminOrganization */ }
            };

            // Assert
            Assert.Equal(1, organizationInsurancePlan.OrganizationInsurancePlanId);
            Assert.Equal(1001, organizationInsurancePlan.OrganizationId);
            Assert.Equal(2002, organizationInsurancePlan.InsurancePlanId);
            Assert.Equal("North Region", organizationInsurancePlan.CoverageArea);
            Assert.Equal("Network A", organizationInsurancePlan.Network);
            Assert.Equal(new DateOnly(2023, 1, 1), organizationInsurancePlan.PeriodStart);
            Assert.Equal(new DateOnly(2023, 12, 31), organizationInsurancePlan.PeriodEnd);
            Assert.Equal("Active", organizationInsurancePlan.Status);
        }

        [Fact]
        public void Can_Create_OrganizationInsurancePlan_With_Minimum_Required_Fields()
        {
            // Arrange
            var organizationInsurancePlan = new OrganizationInsurancePlan
            {
                OrganizationInsurancePlanId = 2,
                Status = "Inactive"
            };

            // Assert
            Assert.Equal(2, organizationInsurancePlan.OrganizationInsurancePlanId);
            Assert.Equal("Inactive", organizationInsurancePlan.Status);
        }
    }
}
