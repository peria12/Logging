﻿using Aurora.AdministrationService.Domain.Entities;
using Aurora.AdministrationService.Domain.Old.Entities;

namespace Aurora.AdministrationService.Tests.DomainTest.Entities
{
    public class FdModuleTests
    {
        [Fact]
        public void Can_Initialize_FdModule_With_Properties()
        {
            // Arrange
            var caption = new FdCaption
            {
                Id = 1,
                EnUs = "Patient Module",
                CreatedBy = "admin",
                CreatedDate = DateTime.UtcNow,
                FacilityCode = "FAC001"
            };

            var module = new FdModule
            {
                Id = 101,
                CaptionId = caption.Id,
                ModuleName = "Patient Management",
                MainMenuId = 10,
                ModuleType = 2,
                FacilityCode = "FAC001",
                Caption = caption
            };

            // Assert
            Assert.Equal(101, module.Id);
            Assert.Equal(1, module.CaptionId);
            Assert.Equal("Patient Management", module.ModuleName);
            Assert.Equal((byte)2, module.ModuleType);
            Assert.Equal("FAC001", module.FacilityCode);
            Assert.Equal(caption, module.Caption);
        }

        [Fact]
        public void FdModule_Should_Initialize_Empty_FdForms_Collection()
        {
            // Act
            var module = new FdModule();

            // Assert
            Assert.NotNull(module.FdForms);
            Assert.Empty(module.FdForms);
        }

        [Fact]
        public void Can_Add_Form_To_FdForms_Collection()
        {
            // Arrange
            var form = new FdForm
            {
                Id = 501,
                FormName = "Registration Form",
                FacilityCode = "FAC001"
            };

            var module = new FdModule
            {
                Id = 102,
                FacilityCode = "FAC001"
            };

            // Act
            module.FdForms.Add(form);

            // Assert
            Assert.Single(module.FdForms);
            Assert.Contains(form, module.FdForms);
        }
    }
}
