﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using FluentAssertions;
using Xunit;
using Aurora.AdministrationService.Domain.V1.Entities.ProcedureChargeMasters;

namespace Aurora.AdministrationService.Tests.DomainTest.Entities
{
    public class ProcedureChargeMasterTests
    {
        [Fact]
        public void ProcedureChargeMaster_Should_Initialize_Required_And_Optional_Fields_Correctly()
        {
            // Arrange
            var chargeMaster = new ProcedureChargeMaster
            {
                MasterType = "TestType",
                ItemCode = "ITEM123",
                ItemDescription = "Test Item Description",
                ItemTypeCode = "ITC001",
                ItemTypeDescription = "Item Type Desc",
                ProcedureCode = "PROC123",
                ProcedureDesc = "Procedure Description",
                FacilityCode = "FAC123",
                IsDeleted = false,
                CreatedBy = "admin",
                CreatedDate = DateTime.UtcNow
            };

            // Act & Assert
            chargeMaster.MasterType.Should().NotBeNullOrEmpty();
            chargeMaster.ItemCode.Should().NotBeNullOrEmpty();
            chargeMaster.ItemDescription.Should().NotBeNullOrEmpty();
            chargeMaster.ItemTypeCode.Should().NotBeNullOrEmpty();
            chargeMaster.ItemTypeDescription.Should().NotBeNullOrEmpty();
            chargeMaster.ProcedureCode.Should().NotBeNullOrEmpty();
            chargeMaster.ProcedureDesc.Should().NotBeNullOrEmpty();
            chargeMaster.FacilityCode.Should().NotBeNullOrEmpty();
            chargeMaster.IsDeleted.Should().BeFalse();
            chargeMaster.CreatedBy.Should().NotBeNullOrEmpty();
            chargeMaster.CreatedDate.Should().BeAfter(DateTime.MinValue);
            chargeMaster.RecordVersion.Should().BeEmpty();
            chargeMaster.UpdatedBy.Should().BeNull();
            chargeMaster.UpdatedDate.Should().BeNull();
        }

        [Fact]
        public void ProcedureChargeMaster_ShouldHaveValidMaxLengthForProperties()
        {
            // Arrange
            var chargeMaster = new ProcedureChargeMaster
            {
                MasterType = new string('a', 51),
                ItemCode = new string('a', 51),
                ItemDescription = new string('a', 256),
                ItemTypeCode = new string('a', 21),
                ItemTypeDescription = new string('a', 256),
                ProcedureCode = new string('a', 21),
                ProcedureDesc = new string('a', 256),
                FacilityCode = new string('a', 101),
                CreatedBy = new string('a', 51),
                UpdatedBy = new string('a', 51),
                IsDeleted = false,
                CreatedDate = DateTime.Now
            };

            // Act
            var validationResults = new List<ValidationResult>();
            var isValid = Validator.TryValidateObject(chargeMaster, new ValidationContext(chargeMaster), validationResults, true);

            // Assert
            isValid.Should().BeFalse();
            validationResults.Should().Contain(v => v.MemberNames.Contains("MasterType"));
            validationResults.Should().Contain(v => v.MemberNames.Contains("ItemCode"));
            validationResults.Should().Contain(v => v.MemberNames.Contains("ItemDescription"));
            validationResults.Should().Contain(v => v.MemberNames.Contains("ItemTypeCode"));
            validationResults.Should().Contain(v => v.MemberNames.Contains("ItemTypeDescription"));
            validationResults.Should().Contain(v => v.MemberNames.Contains("ProcedureCode"));
            validationResults.Should().Contain(v => v.MemberNames.Contains("ProcedureDesc"));
            validationResults.Should().Contain(v => v.MemberNames.Contains("FacilityCode"));
            validationResults.Should().Contain(v => v.MemberNames.Contains("CreatedBy"));
            validationResults.Should().Contain(v => v.MemberNames.Contains("UpdatedBy"));
        }
    }
}
