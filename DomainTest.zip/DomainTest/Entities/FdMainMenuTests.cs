﻿using Aurora.AdministrationService.Domain.Entities;
using Aurora.AdministrationService.Domain.Old.Entities;

namespace Aurora.AdministrationService.Tests.DomainTest.Entities
{
    public class FdMainMenuTests
    {
        [Fact]
        public void Can_Initialize_FdMainMenu_With_Properties()
        {
            // Arrange
            var caption = new FdCaption { Id = 1, EnUs = "Dashboard", CreatedBy = "admin", CreatedDate = DateTime.UtcNow, FacilityCode = "FAC001" };
            var form = new FdForm { Id = 100, FormName = "MainForm", FacilityCode = "FAC001" };
            var report = new RdReport { Id = 200, ReportName = "Report1" };
            var tooltip = new MessageMaster { Id = 300, Description = "Click here" };

            var menu = new FdMainMenu
            {
                Id = 1,
                MenuName = "MainMenu",
                CaptionId = 1,
                ParentId = null,
                MenuDescription = "Main Menu Description",
                InvokeId = 100,
                ToolTipId = 300,
                ShortcutKeys = "Ctrl+M",
                MenuIconPath = "/icons/main.png",
                InvokeTypeIdentifier = 1,
                IsEmrd = true,
                MenuIconFileName = "main.png",
                IsFullScreen = true,
                IconId = 400,
                IsActive = true,
                FacilityCode = "FAC001",
                Caption = caption,
                Invoke = form,
                InvokeNavigation = report,
                ToolTip = tooltip
            };

            // Assert
            Assert.Equal(1, menu.Id);
            Assert.Equal("MainMenu", menu.MenuName);
            Assert.Equal(1, menu.CaptionId);
            Assert.Null(menu.ParentId);
            Assert.Equal("Main Menu Description", menu.MenuDescription);
            Assert.Equal(100, menu.InvokeId);
            Assert.Equal(300, menu.ToolTipId);
            Assert.Equal("Ctrl+M", menu.ShortcutKeys);
            Assert.Equal("/icons/main.png", menu.MenuIconPath);
            Assert.True(menu.IsEmrd);
            Assert.Equal("main.png", menu.MenuIconFileName);
            Assert.True(menu.IsFullScreen);
            Assert.Equal(400, menu.IconId);
            Assert.True(menu.IsActive);
            Assert.Equal("FAC001", menu.FacilityCode);
            Assert.Equal(caption, menu.Caption);
            Assert.Equal(form, menu.Invoke);
            Assert.Equal(report, menu.InvokeNavigation);
            Assert.Equal(tooltip, menu.ToolTip);
        }

        [Fact]
        public void FdMainMenu_Should_Initialize_Empty_InverseParent_Collection()
        {
            // Act
            var menu = new FdMainMenu();

            // Assert
            Assert.NotNull(menu.InverseParent);
            Assert.Empty(menu.InverseParent);
        }

        [Fact]
        public void Can_Set_Parent_Menu()
        {
            // Arrange
            var parentMenu = new FdMainMenu { Id = 10, MenuName = "ParentMenu", FacilityCode = "FAC001" };
            var childMenu = new FdMainMenu { Id = 11, MenuName = "ChildMenu", FacilityCode = "FAC001", Parent = parentMenu };

            // Assert
            Assert.Equal(parentMenu, childMenu.Parent);
            Assert.Equal("ParentMenu", childMenu.Parent?.MenuName);
        }
    }
}
