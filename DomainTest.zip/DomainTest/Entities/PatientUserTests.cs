﻿using Aurora.AdministrationService.Domain.Entities;
using Aurora.AdministrationService.Domain.Old.Entities;

namespace Aurora.AdministrationService.Tests.DomainTest.Entities
{
    public class PatientUserTests
    {
        [Fact]
        public void Can_Create_PatientUser_With_All_Properties()
        {
            // Arrange
            var patientUser = new PatientUser
            {
                PatientId = "P001",
                Name = "John Doe",
                ImageUrl = "http://example.com/image.jpg",
                Id = "123",
                Gender = "Male",
                PhoneNumber = "123-456-7890",
                Email = "johndoe@example.com",
                CreatedAt = DateTime.Now,
                UpdatedAt = DateTime.Now.AddMinutes(10),
                Username = "johndoe",
                Password = "password123",
                IdentifierIc = "IC123",
                IdentifierPassport = "Passport123",
                IdentifierMrn = "MRN123",
                FirstName = "John",
                LastName = "Doe",
                MiddleName = "M",
                Address = "123 Main St",
                City = "Sample City",
                State = "Sample State",
                PostalCode = "12345",
                Country = "Sample Country",
                MaritalStatus = "Single",
                Language = "English",
                Nationality = "Country X",
                Religion = "Religion Y",
                Ethnicity = "Ethnicity Z",
                BirthPlace = "City A",
                Active = true,
                PreferredName = "Johnny",
                CreatedBy = "Admin",
                UpdatedBy = "Admin",
                Salutation = "Mr.",
                PassportIssuedCountry = "Country X",
                PassportNumber = "PN123456",
            };

            // Assert
            Assert.Equal("P001", patientUser.PatientId);
            Assert.Equal("John Doe", patientUser.Name);
            Assert.Equal("http://example.com/image.jpg", patientUser.ImageUrl);
            Assert.Equal("123", patientUser.Id);
            Assert.Equal("Male", patientUser.Gender);
            Assert.Equal("123-456-7890", patientUser.PhoneNumber);
            Assert.Equal("johndoe@example.com", patientUser.Email);
            Assert.NotNull(patientUser.UpdatedAt);
            Assert.Equal("johndoe", patientUser.Username);
            Assert.Equal("password123", patientUser.Password);
            Assert.Equal("IC123", patientUser.IdentifierIc);
            Assert.Equal("Passport123", patientUser.IdentifierPassport);
            Assert.Equal("MRN123", patientUser.IdentifierMrn);
            Assert.Equal("John", patientUser.FirstName);
            Assert.Equal("Doe", patientUser.LastName);
            Assert.Equal("M", patientUser.MiddleName);
            Assert.Equal("123 Main St", patientUser.Address);
            Assert.Equal("Sample City", patientUser.City);
            Assert.Equal("Sample State", patientUser.State);
            Assert.Equal("12345", patientUser.PostalCode);
            Assert.Equal("Sample Country", patientUser.Country);
            Assert.Equal("Single", patientUser.MaritalStatus);
            Assert.Equal("English", patientUser.Language);
            Assert.Equal("Country X", patientUser.Nationality);
            Assert.Equal("Religion Y", patientUser.Religion);
            Assert.Equal("Ethnicity Z", patientUser.Ethnicity);
            Assert.Equal("City A", patientUser.BirthPlace);
            Assert.True(patientUser.Active.HasValue && patientUser.Active.Value);
            Assert.Equal("Johnny", patientUser.PreferredName);
            Assert.Equal("Admin", patientUser.CreatedBy);
            Assert.Equal("Admin", patientUser.UpdatedBy);
            Assert.Equal("Mr.", patientUser.Salutation);
            Assert.Equal("Country X", patientUser.PassportIssuedCountry);
            Assert.Equal("PN123456", patientUser.PassportNumber);
        }

        [Fact]
        public void Can_Create_PatientUser_With_Null_Optional_Properties()
        {
            // Arrange
            var patientUser = new PatientUser
            {
                PatientId = "P002",
                Name = "Jane Smith",
                Gender = "Female",
                PhoneNumber = "987-654-3210",
                Email = "janesmith@example.com",
                CreatedAt = DateTime.Now,
                UpdatedAt = null,
                Username = null,
                Password = null,
                IdentifierIc = null,
                IdentifierPassport = null,
                IdentifierMrn = null,
                FirstName = "Jane",
                LastName = "Smith",
                MiddleName = null,
                DateOfBirth = null,
                Address = null,
                City = null,
                State = null,
                PostalCode = null,
                Country = null,
                MaritalStatus = null,
                Language = null,
                Nationality = null,
                Religion = null,
                Ethnicity = null,
                BirthPlace = null,
                Active = null,
                PreferredName = null,
                CreatedBy = null,
                UpdatedBy = null,
                Salutation = null,
                PassportIssuedCountry = null,
                PassportNumber = null
            };

            // Assert
            Assert.Equal("P002", patientUser.PatientId);
            Assert.Equal("Jane Smith", patientUser.Name);
            Assert.Null(patientUser.ImageUrl);
            Assert.Null(patientUser.Id);
            Assert.Equal("Female", patientUser.Gender);
            Assert.Equal("987-654-3210", patientUser.PhoneNumber);
            Assert.Equal("janesmith@example.com", patientUser.Email);
            Assert.Null(patientUser.UpdatedAt);
            Assert.Null(patientUser.Username);
            Assert.Null(patientUser.Password);
            Assert.Null(patientUser.IdentifierIc);
            Assert.Null(patientUser.IdentifierPassport);
            Assert.Null(patientUser.IdentifierMrn);
            Assert.Equal("Jane", patientUser.FirstName);
            Assert.Equal("Smith", patientUser.LastName);
            Assert.Null(patientUser.MiddleName);
            Assert.Null(patientUser.DateOfBirth);
            Assert.Null(patientUser.Address);
            Assert.Null(patientUser.City);
            Assert.Null(patientUser.State);
            Assert.Null(patientUser.PostalCode);
            Assert.Null(patientUser.Country);
            Assert.Null(patientUser.MaritalStatus);
            Assert.Null(patientUser.Language);
            Assert.Null(patientUser.Nationality);
            Assert.Null(patientUser.Religion);
            Assert.Null(patientUser.Ethnicity);
            Assert.Null(patientUser.BirthPlace);
            Assert.Null(patientUser.Active);
            Assert.Null(patientUser.PreferredName);
            Assert.Null(patientUser.CreatedBy);
            Assert.Null(patientUser.UpdatedBy);
            Assert.Null(patientUser.Salutation);
            Assert.Null(patientUser.PassportIssuedCountry);
            Assert.Null(patientUser.PassportNumber);
        }

        [Fact]
        public void Can_Create_PatientUser_With_Required_Properties_Only()
        {
            // Arrange
            var patientUser = new PatientUser
            {
                PatientId = "P003",
                Name = "Alice Johnson",
                Gender = "Female",
                PhoneNumber = "321-654-9870",
                Email = "alicejohnson@example.com",
                CreatedAt = DateTime.Now
            };

            // Assert
            Assert.Equal("P003", patientUser.PatientId);
            Assert.Equal("Alice Johnson", patientUser.Name);
            Assert.Equal("Female", patientUser.Gender);
            Assert.Equal("321-654-9870", patientUser.PhoneNumber);
            Assert.Equal("alicejohnson@example.com", patientUser.Email);
            Assert.Null(patientUser.UpdatedAt); // Optional
            Assert.Null(patientUser.Username); // Optional
            Assert.Null(patientUser.Password); // Optional
        }

        [Fact]
        public void Can_Create_PatientUser_With_DateOfBirth_Null()
        {
            // Arrange
            var patientUser = new PatientUser
            {
                PatientId = "P004",
                Name = "Robert Brown",
                Gender = "Male",
                PhoneNumber = "456-789-0123",
                Email = "robertbrown@example.com",
                CreatedAt = DateTime.Now,
                DateOfBirth = null
            };

            // Assert
            Assert.Equal("P004", patientUser.PatientId);
            Assert.Equal("Robert Brown", patientUser.Name);
            Assert.Null(patientUser.DateOfBirth);
        }
    }
}
