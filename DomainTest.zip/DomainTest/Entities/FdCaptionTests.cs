﻿using Aurora.AdministrationService.Domain.Entities;
using Aurora.AdministrationService.Domain.Old.Entities;

namespace Aurora.AdministrationService.Tests.DomainTest.Entities
{
    public class FdCaptionTests
    {
        [Fact]
        public void Can_Initialize_FdCaption_With_All_Properties()
        {
            // Arrange
            var createdDate = DateTime.UtcNow;
            var updatedDate = createdDate.AddHours(2);

            var caption = new FdCaption
            {
                Id = 1,
                EnUs = "Dashboard",
                IsDeleted = false,
                CreatedBy = "admin",
                CreatedDate = createdDate,
                UpdatedBy = "admin",
                UpdatedDate = updatedDate,
                FacilityCode = "FAC001"
            };

            // Assert
            Assert.Equal(1, caption.Id);
            Assert.Equal("Dashboard", caption.EnUs);
            Assert.False(caption.IsDeleted);
            Assert.Equal("admin", caption.CreatedBy);
            Assert.Equal(createdDate, caption.CreatedDate);
            Assert.Equal("admin", caption.UpdatedBy);
            Assert.Equal(updatedDate, caption.UpdatedDate);
            Assert.Equal("FAC001", caption.FacilityCode);
        }

        [Fact]
        public void FdCaption_Should_Initialize_Empty_Collections_By_Default()
        {
            // Act
            var caption = new FdCaption();

            // Assert
            Assert.NotNull(caption.FdForms);
            Assert.Empty(caption.FdForms);

            Assert.NotNull(caption.FdMainMenus);
            Assert.Empty(caption.FdMainMenus);

            Assert.NotNull(caption.FdModules);
            Assert.Empty(caption.FdModules);

            Assert.NotNull(caption.RdReports);
            Assert.Empty(caption.RdReports);
        }

        [Fact]
        public void Can_Handle_Nullable_Fields()
        {
            // Arrange
            var createdDate = DateTime.UtcNow;

            var caption = new FdCaption
            {
                Id = 2,
                EnUs = null,
                IsDeleted = true,
                CreatedBy = "testuser",
                CreatedDate = createdDate,
                UpdatedBy = null,
                UpdatedDate = null,
                FacilityCode = "FAC999"
            };

            // Assert
            Assert.Equal(2, caption.Id);
            Assert.Null(caption.EnUs);
            Assert.True(caption.IsDeleted);
            Assert.Equal("testuser", caption.CreatedBy);
            Assert.Equal(createdDate, caption.CreatedDate);
            Assert.Null(caption.UpdatedBy);
            Assert.Null(caption.UpdatedDate);
            Assert.Equal("FAC999", caption.FacilityCode);
        }
    }
}
