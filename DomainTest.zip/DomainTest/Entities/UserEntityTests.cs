﻿using Aurora.AdministrationService.Domain.Entities;
using Aurora.AdministrationService.Domain.Old.Entities;

namespace Aurora.AdministrationService.Tests.DomainTest.Entities
{
    public class UserEntityTests
    {
        [Fact]
        public void Can_Create_User_With_All_Properties()
        {
            // Arrange
            var now = DateTime.UtcNow;
            var user = new User
            {
                Id = 1,
                Gender = "Male",
                RegistrationDate = now,
                MyKadMyKidMyPr = "MY123456789",
                CmndPassportNumberBirthCertificate = "CMBP123456",
                NomorKtpNomorPassporNomorSimNomorSuratLahir = "KTPSIM001",
                PassportNumber = "P123456",
                PassportIssueCountry = "Malaysia",
                Passcode = "passcode123",
                PhoneNumber = "0123456789",
                Email = "test@example.com",
                Country = "Malaysia",
                ProfileImage = "image.jpg",
                UserType = true,
                Password = "securePassword",
                LocationEnable = true,
                Name = "Raj",
                PreferredName = "Raju",
                NotificationEnabled = true,
                SosbuttonEnabled = true,
                BioAuthenticationEnabled = false,
                UserId = "USER001",
                RetryAttempt = 1,
                LastLoginFailedTime = now.AddMinutes(-10),
                Status = true,
                Nationality = "Malaysian"
            };

            // Assert
            Assert.Equal(1, user.Id);
            Assert.Equal("Male", user.Gender);
            Assert.Equal("Malaysia", user.Country);
            Assert.Equal("Raju", user.PreferredName);
            Assert.True(user.NotificationEnabled);
            Assert.True(user.SosbuttonEnabled);
            Assert.False(user.BioAuthenticationEnabled);
            Assert.Equal("USER001", user.UserId);
            Assert.Equal(1, user.RetryAttempt);
            Assert.Equal("Malaysian", user.Nationality);
            Assert.NotNull(user.Mrns);
            Assert.NotNull(user.PatientDoctorAppointments);
        }

        [Fact]
        public void Can_Create_User_With_Minimum_Required_Fields()
        {
            // Arrange
            var user = new User
            {
                Id = 2,
                UserId = "USER002"
            };

            // Assert
            Assert.Equal(2, user.Id);
            Assert.Equal("USER002", user.UserId);
            Assert.Null(user.Gender);
            Assert.Null(user.Email);
            Assert.NotNull(user.Mrns);
            Assert.NotNull(user.PatientDoctorAppointments);
        }

        [Fact]
        public void Collections_Should_Be_Initialized_By_Default()
        {
            // Arrange
            var user = new User();

            // Assert
            Assert.NotNull(user.Mrns);
            Assert.IsType<List<Mrn>>(user.Mrns);

            Assert.NotNull(user.PatientDoctorAppointments);
            Assert.IsType<List<PatientDoctorAppointment>>(user.PatientDoctorAppointments);
        }

        [Fact]
        public void Can_Update_User_Properties()
        {
            // Arrange
            var user = new User { Id = 3, UserId = "USER003" };

            // Act
            user.Email = "updated@example.com";
            user.PhoneNumber = "0987654321";
            user.LocationEnable = false;
            user.BioAuthenticationEnabled = true;

            // Assert
            Assert.Equal("updated@example.com", user.Email);
            Assert.Equal("0987654321", user.PhoneNumber);
            Assert.False(user.LocationEnable.Value);
            Assert.True(user.BioAuthenticationEnabled.Value);
        }
    }
}
