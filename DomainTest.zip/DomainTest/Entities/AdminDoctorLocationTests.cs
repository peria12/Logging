﻿using Aurora.AdministrationService.Domain.Entities;
using Aurora.AdministrationService.Domain.Old.Entities;

namespace Aurora.AdministrationService.Tests.DomainTest.Entities
{
    public class AdminDoctorLocationTests
    {
        [Fact]
        public void Can_Create_AdminDoctorLocation_And_Assign_Properties()
        {
            // Arrange
            var doctorLocation = new AdminDoctorLocation
            {
                DoctorLocationId = 1,
                DoctorProfileId = 1001,
                LocationId = 2001,
                Role = "Consultant",
                StartDate = new DateOnly(2023, 01, 01),
                EndDate = new DateOnly(2024, 01, 01),
                IsActive = true,
                DateCreated = DateTime.UtcNow,
                CreatedBy = 10,
                LastModifiedBy = 20,
                LastModifiedDate = DateTime.UtcNow,
                DoctorProfile = new AdminDoctorProfile(),
                Location = new AdminLocation(),
                CreatedByNavigation = new AdminUser(),
                LastModifiedByNavigation = new AdminUser()
            };

            // Assert
            Assert.Equal(1, doctorLocation.DoctorLocationId);
            Assert.Equal(1001, doctorLocation.DoctorProfileId);
            Assert.Equal(2001, doctorLocation.LocationId);
            Assert.Equal("Consultant", doctorLocation.Role);
            Assert.Equal(new DateOnly(2023, 01, 01), doctorLocation.StartDate);
            Assert.Equal(new DateOnly(2024, 01, 01), doctorLocation.EndDate);
            Assert.True(doctorLocation.IsActive);
            Assert.Equal(10, doctorLocation.CreatedBy);
            Assert.Equal(20, doctorLocation.LastModifiedBy);
            Assert.NotNull(doctorLocation.LastModifiedDate);

            Assert.NotNull(doctorLocation.DoctorProfile);
            Assert.NotNull(doctorLocation.Location);
            Assert.NotNull(doctorLocation.CreatedByNavigation);
            Assert.NotNull(doctorLocation.LastModifiedByNavigation);
        }
    }
}
