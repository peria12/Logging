﻿using Aurora.AdministrationService.Domain.Old.Entities;

namespace Aurora.AdministrationService.Tests.DomainTest.Entities
{
    public class InsuranceCoverageTests
    {
        [Fact]
        public void Can_Create_InsuranceCoverage_With_Valid_Values()
        {
            // Arrange
            var now = DateTime.UtcNow;

            var coverage = new InsuranceCoverage
            {
                CoverageId = 1,
                Name = "Basic Plan",
                Status = "Active",
                Type = "Health",
                SubscriberId = 101,
                SubscriberRelationship = "Self",
                BeneficiaryId = 202,
                PeriodStartDate = new DateTime(2024, 1, 1),
                PeriodEndDate = new DateTime(2025, 1, 1),
                PayorOrganizationId = 5,
                PolicyHolderId = 6,
                ContractId = 7,
                Network = "In-Network",
                ClassType = "Gold",
                ClassValue = "G1",
                OrderIndex = 1,
                CreatedBy = 99,
                DateCreated = now,
                LastModifiedBy = 100,
                LastModifiedDate = now,
                OrganizationInsurancePlans = new List<OrganizationInsurancePlan>
                {
                    new OrganizationInsurancePlan()
                }
            };

            // Assert
            Assert.Equal(1, coverage.CoverageId);
            Assert.Equal("Basic Plan", coverage.Name);
            Assert.Equal("Active", coverage.Status);
            Assert.Equal("Health", coverage.Type);
            Assert.Equal(101, coverage.SubscriberId);
            Assert.Equal("Self", coverage.SubscriberRelationship);
            Assert.Equal(202, coverage.BeneficiaryId);
            Assert.Equal(new DateTime(2024, 1, 1), coverage.PeriodStartDate);
            Assert.Equal(new DateTime(2025, 1, 1), coverage.PeriodEndDate);
            Assert.Equal(5, coverage.PayorOrganizationId);
            Assert.Equal(6, coverage.PolicyHolderId);
            Assert.Equal(7, coverage.ContractId);
            Assert.Equal("In-Network", coverage.Network);
            Assert.Equal("Gold", coverage.ClassType);
            Assert.Equal("G1", coverage.ClassValue);
            Assert.Equal(1, coverage.OrderIndex);
            Assert.Equal(99, coverage.CreatedBy);
            Assert.Equal(now, coverage.DateCreated);
            Assert.Equal(100, coverage.LastModifiedBy);
            Assert.Equal(now, coverage.LastModifiedDate);
            Assert.Single(coverage.OrganizationInsurancePlans);
        }

        [Fact]
        public void Can_Create_InsuranceCoverage_With_Minimum_Values()
        {
            // Arrange
            var coverage = new InsuranceCoverage
            {
                CoverageId = 2,
                Status = "Inactive",
                SubscriberId = 501,
                BeneficiaryId = 502
                // Optional fields left null
            };

            // Assert
            Assert.Equal(2, coverage.CoverageId);
            Assert.Null(coverage.Name);
            Assert.Equal("Inactive", coverage.Status);
            Assert.Null(coverage.Type);
            Assert.Equal(501, coverage.SubscriberId);
            Assert.Null(coverage.SubscriberRelationship);
            Assert.Equal(502, coverage.BeneficiaryId);
            Assert.Null(coverage.PeriodStartDate);
            Assert.Null(coverage.PeriodEndDate);
            Assert.Null(coverage.PayorOrganizationId);
            Assert.Null(coverage.PolicyHolderId);
            Assert.Null(coverage.ContractId);
            Assert.Null(coverage.Network);
            Assert.Null(coverage.ClassType);
            Assert.Null(coverage.ClassValue);
            Assert.Null(coverage.OrderIndex);
            Assert.Null(coverage.CreatedBy);
            Assert.Null(coverage.DateCreated);
            Assert.Null(coverage.LastModifiedBy);
            Assert.Null(coverage.LastModifiedDate);
            Assert.Empty(coverage.OrganizationInsurancePlans);
        }
    }
}
