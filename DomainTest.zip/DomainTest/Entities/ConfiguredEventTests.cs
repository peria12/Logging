﻿using Aurora.AdministrationService.Domain.Entities;

namespace Aurora.AdministrationService.Tests.DomainTest.Entities
{
    public class ConfiguredEventTests
    {
        [Fact]
        public void Can_Create_And_Assign_ConfiguredEvent_Properties()
        {
            // Arrange
            var now = DateTime.UtcNow;
            var configuredEvent = new ConfiguredEvent
            {
                ID = 1001,
                NotificationManagerID = "Notif-001",
                Event = "UserSignup",
                NotificationTempletID = "Temp-001",
                Time = now,
                TimeDuration = "15m",
                Due = "Before",
                Status = true,
                IsDeleted = false,
                CreatedBy = "Admin",
                CreatedDate = now,
                UpdatedBy = "Editor",
                UpdatedDate = now.AddHours(1),
                RecordVersion = new byte[] { 1, 2, 3 }
            };

            // Assert
            Assert.Equal(1001, configuredEvent.ID);
            Assert.Equal("Notif-001", configuredEvent.NotificationManagerID);
            Assert.Equal("UserSignup", configuredEvent.Event);
            Assert.Equal("Temp-001", configuredEvent.NotificationTempletID);
            Assert.Equal(now, configuredEvent.Time);
            Assert.Equal("15m", configuredEvent.TimeDuration);
            Assert.Equal("Before", configuredEvent.Due);
            Assert.True(configuredEvent.Status);
            Assert.False(configuredEvent.IsDeleted);
            Assert.Equal("Admin", configuredEvent.CreatedBy);
            Assert.Equal(now, configuredEvent.CreatedDate);
            Assert.Equal("Editor", configuredEvent.UpdatedBy);
            Assert.Equal(now.AddHours(1), configuredEvent.UpdatedDate);
            Assert.Equal(new byte[] { 1, 2, 3 }, configuredEvent.RecordVersion);
        }

        [Fact]
        public void Can_Handle_Optional_And_Default_Values()
        {
            // Arrange
            var now = DateTime.UtcNow;
            var configuredEvent = new ConfiguredEvent
            {
                ID = 2002,
                NotificationManagerID = "Notif-002",
                Event = "AppointmentCreated",
                NotificationTempletID = "Temp-002",
                Time = now,
                TimeDuration = "30m",
                Due = "After",
                Status = false,
                IsDeleted = true,
                CreatedBy = "System",
                CreatedDate = now
                // UpdatedBy and UpdatedDate left null
            };

            // Assert
            Assert.Null(configuredEvent.UpdatedBy);
            Assert.Null(configuredEvent.UpdatedDate);
            Assert.NotNull(configuredEvent.RecordVersion);
            Assert.Empty(configuredEvent.RecordVersion); // Default empty byte array
        }
    }
}
