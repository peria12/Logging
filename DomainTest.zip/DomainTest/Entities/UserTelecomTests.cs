﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using Aurora.AdministrationService.Domain.V1.Entities.Users;
using FluentAssertions;
using Xunit;

namespace Aurora.AdministrationService.Tests.DomainTest.Entities
{
    public class UserTelecomTests
    {
        [Fact]
        public void UserTelecom_Should_Initialize_Required_And_Optional_Fields_Correctly()
        {
            // Arrange
            var userTelecom = new UserTelecom
            {
                UserID = 12345,
                System = "phone",
                Status = true,
                Value = "123-456-7890",
                Use = "mobile",
                Rank = 1,
                PeriodStart = DateTime.UtcNow,
                IsDeleted = false,
                CreatedBy = "admin",
                CreatedDate = DateTime.UtcNow,
                UpdatedBy = "admin",
                UpdatedDate = DateTime.UtcNow
            };

            // Act & Assert: Ensure required fields are properly initialized
            userTelecom.UserID.Should().Be(12345);
            userTelecom.System.Should().Be("phone");
            userTelecom.Status.Should().Be(true);
            userTelecom.Value.Should().Be("123-456-7890");
            userTelecom.Use.Should().Be("mobile");
            userTelecom.Rank.Should().Be(1);
            userTelecom.PeriodStart.Should().BeAfter(DateTime.MinValue);
            userTelecom.IsDeleted.Should().Be(false);
            userTelecom.CreatedBy.Should().Be("admin");
            userTelecom.CreatedDate.Should().BeAfter(DateTime.MinValue);
            userTelecom.UpdatedBy.Should().Be("admin");
            userTelecom.UpdatedDate.Should().BeAfter(DateTime.MinValue);

            // Assert: Ensure optional fields are left as null by default
            userTelecom.PeriodEnd.Should().BeNull();
            userTelecom.RecordVersion.Should().BeEmpty();
        }

        [Fact]
        public void UserTelecom_ShouldHaveValidMaxLengthForProperties()
        {
            // Arrange
            var userTelecom = new UserTelecom
            {
                UserID = 12345,
                System = new string('a', 21), // Exceeds max length of 20
                Value = new string('a', 101), // Exceeds max length of 100
                Use = new string('a', 21), // Exceeds max length of 20
                CreatedBy = new string('a', 51), // Exceeds max length of 50
                UpdatedBy = new string('a', 51), // Exceeds max length of 50
                Status = true,
                CreatedDate = DateTime.Now,
                IsDeleted = false,
                PeriodStart = DateTime.Now
            };

            // Act
            var validationResults = new List<ValidationResult>();
            var isValid = Validator.TryValidateObject(userTelecom, new ValidationContext(userTelecom), validationResults, true);

            // Assert
            isValid.Should().BeFalse();
            validationResults.Should().Contain(v => v.MemberNames.Contains("System"));
            validationResults.Should().Contain(v => v.MemberNames.Contains("Value"));
            validationResults.Should().Contain(v => v.MemberNames.Contains("Use"));
            validationResults.Should().Contain(v => v.MemberNames.Contains("CreatedBy"));
            validationResults.Should().Contain(v => v.MemberNames.Contains("UpdatedBy"));
        }
    }
}
