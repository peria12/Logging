﻿using Aurora.AdministrationService.Domain.Entities;
using Aurora.AdministrationService.Domain.Old.Entities;

namespace Aurora.AdministrationService.Tests.DomainTest.Entities
{
    public class FloorMapTests
    {
        [Fact]
        public void Can_Initialize_FloorMap_With_Required_Properties()
        {
            // Arrange
            var now = DateTime.UtcNow;

            var floorMap = new FloorMap
            {
                ID = 1,
                FloorImageUrl = "https://hospital.com/images/floor1.png",
                LocationId = 100,
                HospitalId = 200,
                BuildingName = "Main Block",
                FloorLevel = 1,
                CreatedBy = 10,
                UpdatedBy = 11,
                CreatedAt = now,
                UpdatedAt = now,
                IsDeleted = false,
                IsActive = true
            };

            // Assert
            Assert.Equal(1, floorMap.ID);
            Assert.Equal("https://hospital.com/images/floor1.png", floorMap.FloorImageUrl);
            Assert.Equal(100, floorMap.LocationId);
            Assert.Equal(200, floorMap.HospitalId);
            Assert.Equal("Main Block", floorMap.BuildingName);
            Assert.Equal(1, floorMap.FloorLevel);
            Assert.Equal(10, floorMap.CreatedBy);
            Assert.Equal(11, floorMap.UpdatedBy);
            Assert.Equal(now, floorMap.CreatedAt);
            Assert.Equal(now, floorMap.UpdatedAt);
            Assert.False(floorMap.IsDeleted);
            Assert.True(floorMap.IsActive);
        }

        [Fact]
        public void Can_Set_FloorMap_As_Deleted_And_Inactive()
        {
            // Arrange
            var floorMap = new FloorMap
            {
                IsDeleted = true,
                IsActive = false
            };

            // Assert
            Assert.True(floorMap.IsDeleted);
            Assert.False(floorMap.IsActive);
        }

        [Fact]
        public void BuildingName_Should_Be_Nullable()
        {
            // Arrange
            var floorMap = new FloorMap
            {
                BuildingName = null
            };

            // Assert
            Assert.Null(floorMap.BuildingName);
        }

        [Fact]
        public void CreatedAt_And_UpdatedAt_Should_Be_Nullable()
        {
            // Arrange
            var floorMap = new FloorMap
            {
                CreatedAt = null,
                UpdatedAt = null
            };

            // Assert
            Assert.Null(floorMap.CreatedAt);
            Assert.Null(floorMap.UpdatedAt);
        }
    }
}
