﻿using Aurora.AdministrationService.Domain.Entities;
using Aurora.AdministrationService.Domain.Old.Entities;

namespace Aurora.AdministrationService.Tests.DomainTest.Entities
{
    public class FdFormTests
    {
        [Fact]
        public void Can_Initialize_FdForm_With_All_Properties()
        {
            // Arrange
            var createdDate = DateTime.UtcNow;

            var caption = new FdCaption
            {
                Id = 1,
                EnUs = "Dashboard",
                IsDeleted = false,
                CreatedBy = "admin",
                CreatedDate = createdDate,
                FacilityCode = "FAC001"
            };

            var module = new FdModule
            {
                Id = 2,
                ModuleName = "Module1"
            };

            var form = new FdForm
            {
                Id = 1,
                ModuleId = 2,
                CaptionId = 1,
                FormName = "Form1",
                FormType = 1,
                FdxFileName = "file1.fdx",
                FacilityCode = "FAC001",
                Caption = caption,
                Module = module
            };

            // Assert
            Assert.Equal(1, form.Id);
            Assert.Equal(2, form.ModuleId);
            Assert.Equal(1, form.CaptionId);
            Assert.Equal("Form1", form.FormName);
            Assert.Equal("file1.fdx", form.FdxFileName);
            Assert.Equal("FAC001", form.FacilityCode);
            Assert.NotNull(form.Caption);
            Assert.NotNull(form.Module);
            Assert.Equal("Module1", form.Module.ModuleName);
        }

        [Fact]
        public void FdForm_Should_Initialize_Empty_Collections_By_Default()
        {
            // Act
            var form = new FdForm();

            // Assert
            Assert.NotNull(form.FdMainMenus);
            Assert.Empty(form.FdMainMenus);
        }

        [Fact]
        public void Can_Handle_Nullable_Fields()
        {
            // Arrange
            var createdDate = DateTime.UtcNow;

            var caption = new FdCaption
            {
                Id = 1,
                EnUs = "Dashboard",
                IsDeleted = false,
                CreatedBy = "admin",
                CreatedDate = createdDate,
                FacilityCode = "FAC001"
            };

            var module = new FdModule
            {
                Id = 2,
                ModuleName = "Module1"
            };

            var form = new FdForm
            {
                Id = 1,
                ModuleId = 2,
                CaptionId = 1,
                FormName = null,
                FormType = null,
                FdxFileName = null,
                FacilityCode = "FAC001",
                Caption = caption,
                Module = module
            };

            // Assert
            Assert.Equal(1, form.Id);
            Assert.Equal(2, form.ModuleId);
            Assert.Equal(1, form.CaptionId);
            Assert.Null(form.FormName);
            Assert.Null(form.FormType);
            Assert.Null(form.FdxFileName);
            Assert.Equal("FAC001", form.FacilityCode);
            Assert.NotNull(form.Caption);
            Assert.NotNull(form.Module);
        }
    }
}

