﻿using Aurora.AdministrationService.Domain.Entities;
using Aurora.AdministrationService.Domain.Old.Entities;

namespace Aurora.AdministrationService.Tests.DomainTest.Entities
{
    public class WhatsHappeningTests
    {
        [Fact]
        public void Can_Create_WhatsHappening_With_All_Properties()
        {
            // Arrange
            var now = DateTime.UtcNow;
            var entity = new WhatsHappening
            {
                Id = 1,
                Name = "Blood Donation Drive",
                Description = "Join us for a community blood donation event.",
                ImageUrl = "image1.jpg",
                Url = "https://events.org/blooddrive",
                Category = "Health",             
                IsActive = true,
                DateCreated = now,
                CreatedBy = 101,
                LastModifiedBy = 102,
                LastModifiedDate = now.AddHours(1),
                OrganizationId = 5,
                Organization = new AdminOrganization { OrganizationId = 5, Name = "Red Cross Org" }
            };

            // Assert
            Assert.Equal(1, entity.Id);
            Assert.Equal("Blood Donation Drive", entity.Name);
            Assert.Equal("Join us for a community blood donation event.", entity.Description);
            Assert.Equal("image1.jpg", entity.ImageUrl);
            Assert.Equal("https://events.org/blooddrive", entity.Url);
            Assert.Equal("Health", entity.Category);            
            Assert.True(entity.IsActive);
            Assert.Equal(now, entity.DateCreated);
            Assert.Equal(101, entity.CreatedBy);
            Assert.Equal(102, entity.LastModifiedBy);
            Assert.Equal(now.AddHours(1), entity.LastModifiedDate);
            Assert.Equal(5, entity.OrganizationId);
            Assert.NotNull(entity.Organization);
            Assert.Equal("Red Cross Org", entity.Organization.Name);
        }

        [Fact]
        public void Can_Create_WhatsHappening_With_Minimum_Required_Fields()
        {
            // Arrange
            var entity = new WhatsHappening
            {
                Id = 2,
                Name = "Free Health Check",
                Description = "Get a free health screening.",
                Category = "Health",
                StartDate = DateTime.Today,
                EndDate = DateTime.Today.AddDays(1),
                IsActive = false,
                DateCreated = DateTime.UtcNow
            };

            // Assert
            Assert.Equal(2, entity.Id);
            Assert.Equal("Free Health Check", entity.Name);
            Assert.Null(entity.ImageUrl);
            Assert.Null(entity.Url);
            Assert.Null(entity.CreatedBy);
            Assert.Null(entity.LastModifiedBy);
            Assert.Null(entity.LastModifiedDate);
            Assert.Null(entity.OrganizationId);
            Assert.Null(entity.Organization);
        }

        [Fact]
        public void Can_Update_WhatsHappening_Properties()
        {
            // Arrange
            var entity = new WhatsHappening
            {
                Id = 3,
                Name = "Initial Name",
                Description = "Initial Description",
                Category = "General",
                StartDate = DateTime.Today,
                EndDate = DateTime.Today.AddDays(1),
                DateCreated = DateTime.UtcNow
            };

            // Act
            entity.Name = "Updated Name";
            entity.Description = "Updated Description";
            entity.ImageUrl = "new-image.png";
            entity.Url = "https://updated-event.com";
            entity.IsActive = true;
            entity.LastModifiedDate = DateTime.UtcNow;

            // Assert
            Assert.Equal("Updated Name", entity.Name);
            Assert.Equal("Updated Description", entity.Description);
            Assert.Equal("new-image.png", entity.ImageUrl);
            Assert.Equal("https://updated-event.com", entity.Url);
            Assert.True(entity.IsActive);
            Assert.NotNull(entity.LastModifiedDate);
        }
    }
}
