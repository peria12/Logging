﻿using Aurora.AdministrationService.API.Models.Dto.Agreement;
using FluentAssertions;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Aurora.AdministrationService.Tests.API.Dto.Agreement
{
    public class AgreementDtoTests
    {
       
        [Fact]
        public void AgreementDto_ShouldAllowNullableAgreementText()
        {
            // Act
            var dto = new AgreementDto { AgreementText = null };

            // Assert
            dto.AgreementText.Should().BeNull();
        }

        [Fact]
        public void AgreementDto_ShouldSetAndGetValuesCorrectly()
        {
            // Arrange
            var dto = new AgreementDto
            {
                AgreementUniqueId = "AG12345",
                Language = "EN",
                Frequency = "Monthly",
                Name = "Service Agreement",
                AgreementText = "This is the agreement text."
            };

            // Assert
            dto.AgreementUniqueId.Should().Be("AG12345");
            dto.Language.Should().Be("EN");
            dto.Frequency.Should().Be("Monthly");
            dto.Name.Should().Be("Service Agreement");
            dto.AgreementText.Should().Be("This is the agreement text.");
        }
    }
}

