﻿using Aurora.AdministrationService.API.Models.Dto.HealthcareServices;
using Aurora.AdministrationService.CrossCutting.Constants;
using FluentAssertions;
using System.ComponentModel.DataAnnotations;

namespace Aurora.AdministrationService.Tests.API.Dto.Agreement
{
    public class HealthcareServicesKeyWordsDtoTests
    {
         [Fact]
        public void HealthcareServicesKeyWordsDtoTests_Should_Have_Valid_Keyword()
        {
            // Arrange
            var dto = new HealthcareServicesKeyWordsDto
            {
                Keyword = "ValidKeyword"
            };

            // Act
            var validationContext = new ValidationContext(dto);
            var validationResults = new System.Collections.Generic.List<ValidationResult>();

            var isValid = Validator.TryValidateObject(dto, validationContext, validationResults, true);

            // Assert
            isValid.Should().BeTrue();
            validationResults.Should().BeEmpty();
        }

         [Fact]
        public void HealthcareServicesKeyWordsDtoTests_Should_Invalidate_If_Keyword_Exceeds_MaxLength()
        {
            // Arrange
            var dto = new HealthcareServicesKeyWordsDto
            {
                Keyword = new string('a', 51) // 51 characters, exceeds the max length of 50
            };

            // Act
            var validationContext = new ValidationContext(dto);
            var validationResults = new System.Collections.Generic.List<ValidationResult>();

            var isValid = Validator.TryValidateObject(dto, validationContext, validationResults, true);

            // Assert
            isValid.Should().BeFalse();
            validationResults.Should().ContainSingle(vr => vr.ErrorMessage == AppConstants.Maximum50Character);
        }
    }
}

