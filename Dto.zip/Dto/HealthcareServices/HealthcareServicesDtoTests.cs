﻿using Aurora.AdministrationService.API.Models.Dto.HealthcareServices;
using FluentAssertions;
using System.ComponentModel.DataAnnotations;
using Aurora.AdministrationService.CrossCutting.Constants;

namespace Aurora.AdministrationService.Tests.API.Dto.HealthcareServices
{
    public class HealthcareServicesDtoTests
    {
        [Fact]
        public void HealthcareServicesDto_Name_Should_Have_MaxLength_Validation()
        {
            // Arrange
            var healthcareServicesDto = new HealthcareServicesDto
            {
                Name = new string('a', 101) // Name exceeds 100 characters
            };

            // Act
            var validationContext = new ValidationContext(healthcareServicesDto);
            var validationResults = new System.Collections.Generic.List<ValidationResult>();

            var isValid = Validator.TryValidateObject(healthcareServicesDto, validationContext, validationResults, true);

            // Assert
            isValid.Should().BeFalse();
            validationResults.Should().ContainSingle(vr => vr.ErrorMessage == AppConstants.Maximum100Character);
        }
       
        [Fact]
        public void HealthcareServicesDto_Should_Have_Valid_Properties()
        {
            // Arrange
            var healthcareServicesDto = new HealthcareServicesDto
            {
                Name = "Test Healthcare Service",
                LaymanDescription = "This is a test description.",
                Location = "Test Location",
                Status=true,
            };

            // Act and Assert
            healthcareServicesDto.Name.Should().Be("Test Healthcare Service");
            healthcareServicesDto.LaymanDescription.Should().Be("This is a test description.");
            healthcareServicesDto.Location.Should().Be("Test Location");
            healthcareServicesDto.Status.Should().Be(true);
        }
    }
}

