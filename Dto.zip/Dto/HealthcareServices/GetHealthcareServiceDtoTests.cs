﻿using Aurora.AdministrationService.API.Models.Dto.HealthcareServices;
using FluentAssertions;

namespace Aurora.AdministrationService.Tests.API.Dto.HealthcareServices
{
    public class GetHealthcareServiceDtoTests
    {
        [Fact]
        public void GetHealthcareServiceDto_ShouldInstantiateWithCorrectValues()
        {
            // Arrange
            var healthcareServiceKeyWords = new GetHealthcareServiceKeyWordsDto
            {
                Id = 1,
                Keyword = "Keyword 1",
                RecordVersion = new byte[] { 1, 2, 3 }
            };

            // Act
            var healthcareService = new GetHealthcareServiceDto
            {
                Id = 1,
                Name = "Health Service 1",
                LaymanDescription = "Description 1",
                Location = "Location 1",
                Status = true,
                RecordVersion = new byte[] { 1, 2, 3 },
                HealthcareServicesKeyWords = healthcareServiceKeyWords
            };

            // Assert
            healthcareService.Id.Should().Be(1);
            healthcareService.Name.Should().Be("Health Service 1");
            healthcareService.LaymanDescription.Should().Be("Description 1");
            healthcareService.Location.Should().Be("Location 1");
            healthcareService.Status.Should().Be(true);
            healthcareService.RecordVersion.Should().Equal(new byte[] { 1, 2, 3 });
            healthcareService.HealthcareServicesKeyWords.Should().NotBeNull();
            healthcareService.HealthcareServicesKeyWords.Id.Should().Be(1);
            healthcareService.HealthcareServicesKeyWords.Keyword.Should().Be("Keyword 1");
            healthcareService.HealthcareServicesKeyWords.RecordVersion.Should().Equal(new byte[] { 1, 2, 3 });
        }

        [Fact]
        public void GetHealthcareServiceDto_ShouldHaveDefaultEmptyRecordVersion()
        {
            // Act
            var healthcareService = new GetHealthcareServiceDto();

            // Assert
            healthcareService.RecordVersion.Should().BeEmpty();
        }

        [Fact]
        public void GetHealthcareServiceKeyWordsDto_ShouldHaveDefaultEmptyRecordVersion()
        {
            // Act
            var healthcareServiceKeyWords = new GetHealthcareServiceKeyWordsDto();

            // Assert
            healthcareServiceKeyWords.RecordVersion.Should().BeEmpty();
        }
    }
}

