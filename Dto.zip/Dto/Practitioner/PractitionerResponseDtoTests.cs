﻿using Aurora.AdministrationService.API.Models.ResponseModels.Practitioners;
using Aurora.AdministrationService.API.Models.ResponseModels.V1.AdminDoctor.Practitioners;
using FluentAssertions;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Aurora.AdministrationService.Tests.API.Dto.Practitioner
{
    public class PractitionerResponseDtoTests
    {
        [Fact]
        public void PractitionerProfileResponseDto_ShouldInitializeWithDefaultValues()
        {
            // Act
            var dto = new PractitionerProfileResponseDto();

            // Assert
            dto.ResourceType.Should().Be("Practitioner");
            dto.Id.Should().Be(0);
            dto.Prefix.Should().BeNull();
            dto.Sufix.Should().BeNull();
            dto.FirstName.Should().BeNull();
            dto.MiddleName.Should().BeNull();
            dto.LastName.Should().BeNull();
            dto.PhotoUrl.Should().BeNull();
            dto.Language.Should().BeNull();
            dto.Qualifications.Should().BeNull();
            dto.YearOfPassing.Should().Be(0);
            dto.Institute.Should().BeNull();
            dto.About.Should().BeNull();
            dto.PractitionerRoles.Should().NotBeNull().And.BeEmpty();
        }

        [Fact]
        public void PractitionerProfileResponseDto_ShouldSetAndGetValuesCorrectly()
        {
            // Arrange
            var dto = new PractitionerProfileResponseDto
            {
                Id = 123,
                Prefix = "Dr.",
                Sufix = "MD",
                FirstName = "John",
                MiddleName = "A.",
                LastName = "Doe",
                PhotoUrl = "https://example.com/photo.jpg",
                Language = "English",
                Qualifications = "MBBS, MD",
                YearOfPassing = 2005,
                Institute = "Harvard Medical School",
                About = "Experienced practitioner.",
                PractitionerRoles = new List<PractitionerRoleResponse> { new PractitionerRoleResponse() }
            };

            // Assert
            dto.Id.Should().Be(123);
            dto.Prefix.Should().Be("Dr.");
            dto.Sufix.Should().Be("MD");
            dto.FirstName.Should().Be("John");
            dto.MiddleName.Should().Be("A.");
            dto.LastName.Should().Be("Doe");
            dto.PhotoUrl.Should().Be("https://example.com/photo.jpg");
            dto.Language.Should().Be("English");
            dto.Qualifications.Should().Be("MBBS, MD");
            dto.YearOfPassing.Should().Be(2005);
            dto.Institute.Should().Be("Harvard Medical School");
            dto.About.Should().Be("Experienced practitioner.");
            dto.PractitionerRoles.Should().HaveCount(1);
        }
    }
}
