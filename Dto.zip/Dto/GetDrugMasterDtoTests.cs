﻿using Aurora.AdministrationService.API.Models.Dto.DrugMasters;
using FluentAssertions;

namespace Aurora.AdministrationService.Tests.API.Dto
{
    public class GetDrugMasterDtoTests
    {
        [Fact]
        public void GetDrugMasterDto_Should_Set_Properties_Correctly()
        {
            // Arrange
            var dto = new GetDrugMasterDto
            {
                ID = 1,
                ResourceID = "RES123",
                MasterType = "Type1",
                ItemCode = "Item123",
                ItemDescription = "Sample Item",
                ItemTypeCode = "ITC123",
                ItemTypeDescription = "Item Type Desc",
                MedicationCode = "MED001",
                MedicationDescription = "Medication Desc",
                MedicationCategory = "CategoryA",
                MedicationType = "TypeB",
                Strength = "500mg",
                DrugForm = "Tablet",
                Caution = "Handle with care",
                DosageUnit = "mg",
                DoseValue = 10.5m,
                FrequencyDesc = "Twice a day",
                FrequencyValue = 2.0m,
                DurationUnit = "Days",
                DurationValue = 7,
                Route = "Oral",
                DrugFormGroup = "GroupA",
                Instructions = "Take with food",
                IsSTATDrug = true,
                IsAlertRequired = false,
                IsPoisonDrug = false,
                IsPsychotropicDrug = true,
                IsDangerousDrug = false,
                IsAnesthesiaDrug = false,
                IsActive = true,
                FacilityCode = "FAC001",
                BrandShare = "BrandX",
                RecordVersion = new byte[] { 1, 2, 3 },
                IsDeleted = true
            };

            // Assert
            dto.ID.Should().Be(1);
            dto.ResourceID.Should().Be("RES123");
            dto.MasterType.Should().Be("Type1");
            dto.ItemCode.Should().Be("Item123");
            dto.ItemDescription.Should().Be("Sample Item");
            dto.ItemTypeCode.Should().Be("ITC123");
            dto.ItemTypeDescription.Should().Be("Item Type Desc");
            dto.MedicationCode.Should().Be("MED001");
            dto.MedicationDescription.Should().Be("Medication Desc");
            dto.MedicationCategory.Should().Be("CategoryA");
            dto.MedicationType.Should().Be("TypeB");
            dto.Strength.Should().Be("500mg");
            dto.DrugForm.Should().Be("Tablet");
            dto.Caution.Should().Be("Handle with care");
            dto.DosageUnit.Should().Be("mg");
            dto.DoseValue.Should().Be(10.5m);
            dto.FrequencyDesc.Should().Be("Twice a day");
            dto.FrequencyValue.Should().Be(2.0m);
            dto.DurationUnit.Should().Be("Days");
            dto.DurationValue.Should().Be(7);
            dto.Route.Should().Be("Oral");
            dto.DrugFormGroup.Should().Be("GroupA");
            dto.Instructions.Should().Be("Take with food");
            dto.IsSTATDrug.Should().BeTrue();
            dto.IsAlertRequired.Should().BeFalse();
            dto.IsPoisonDrug.Should().BeFalse();
            dto.IsPsychotropicDrug.Should().BeTrue();
            dto.IsDangerousDrug.Should().BeFalse();
            dto.IsAnesthesiaDrug.Should().BeFalse();
            dto.IsActive.Should().BeTrue();
            dto.FacilityCode.Should().Be("FAC001");
            dto.BrandShare.Should().Be("BrandX");
            dto.RecordVersion.Should().NotBeNull().And.Equal(1, 2, 3);
            dto.IsDeleted.Should().BeTrue();
        }
    }
}