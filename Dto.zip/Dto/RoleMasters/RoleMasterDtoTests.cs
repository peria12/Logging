﻿using Aurora.AdministrationService.API.Models.Dto.PractitionerRoles.RoleMasters;

namespace Aurora.AdministrationService.Tests.API.Dto.RoleMasters
{
    public class RoleMasterDtoTests
    {
        [Fact]
        public void RoleMasterDto_Initialization()
        {
            //Arrange
            var roleMasterCode = "test";
            var roleMasterDefinition = "Definition";
            var roleMasterSource = "Source";

            //Act
            var roleMasterDto = new RoleMasterDto(roleMasterCode, roleMasterDefinition, roleMasterSource);
           
            //Assert
            Assert.Equal(roleMasterCode, roleMasterDto.Code);
            Assert.Equal(roleMasterDefinition, roleMasterDto.Definition);
            Assert.Equal(roleMasterSource, roleMasterDto.Source);
        }
    }
}
