﻿using System.ComponentModel.DataAnnotations;
using Aurora.AdministrationService.API.Models.Dto.ServiceChargeMasters;
using FluentAssertions;

namespace Aurora.AdministrationService.Tests.API.Dto
{
    public class ServiceChargeMasterDtoTests
    {
        [Fact]
        public void ServiceChargeMasterDto_Should_HaveValidProperties()
        {
            var dto = new ServiceChargeMasterDto
            {
                MasterType = "Type1",
                ItemCode = "Item123",
                ItemDescription = "Sample Item Description",
                ItemTypeCode = "ITC123",
                ItemTypeDescription = "Item Type Desc",
                TestCode = "TEST001",
                TestDescription = "Test Desc",
                ServiceType = "Lab",
                Category = "Blood Test",
                Department = "Pathology",
                TurnAroundTime = 48,
                Restricted = true,
                TestMethodAvailable = "PCR, Rapid Test",
                FacilityCode = "FAC001",
                SourceAppId = 1001,
                Title = "Service Charge Master",
                EventAction = "Create",
                RequestedDate = DateTime.UtcNow,
                RegionCode = "MYS",
                LanguageCode = "EN",
                LocationCode = "LOC001",
                AcknowledgementID = "ACK123456"
            };

            dto.MasterType.Should().NotBeNullOrEmpty().And.Match(s => s.Length <= 50);
            dto.ItemCode.Should().NotBeNullOrEmpty().And.Match(s => s.Length <= 50);
            dto.ItemDescription.Should().NotBeNullOrEmpty().And.Match(s => s.Length <= 255);
            dto.TestCode.Should().NotBeNullOrEmpty().And.Match(s => s.Length <= 20);
            dto.ServiceType.Should().NotBeNullOrEmpty().And.Match(s => s.Length <= 50);
            dto.Category.Should().NotBeNullOrEmpty().And.Match(s => s.Length <= 100);
            dto.Department.Should().NotBeNullOrEmpty().And.Match(s => s.Length <= 100);
        }

        [Fact]
        public void ServiceChargeMasterDto_Validation_Should_Fail_When_Fields_Exceed_MaxLength()
        {
            var dto = new ServiceChargeMasterDto { ItemCode = new string('A', 51), TestCode = "Test101" };
            var validationResults = ValidateModel(dto);

            validationResults.Should().ContainSingle().Which.ErrorMessage.Should().Contain("Maximum 50 characters");
        }

        private static ValidationResult[] ValidateModel(object model)
        {
            var context = new ValidationContext(model, null, null);
            var results = new List<ValidationResult>();
            Validator.TryValidateObject(model, context, results, true);
            return results.ToArray();
        }

        [Fact]
        public void ServiceChargeMasterDto_ParameterizedConstructor_Should_SetPropertiesCorrectly()
        {
            // Arrange
            var parameters = new ServiceChargeMasterParams
            {
                MasterType = "LabTest",
                ItemCode = "ITM001",
                ItemDescription = "Blood Test",
                ItemTypeCode = "ITC001",
                ItemTypeDescription = "Lab Item",
                TestCode = "TST001",
                TestDescription = "Complete Blood Count",
                ServiceType = "Pathology",
                Category = "Diagnostic",
                Department = "Hematology",
                TurnAroundTime = 24,
                Restricted = true,
                TestMethodAvailable = "PCR",
                FacilityCode = "FAC123"
            };

            // Act
            var dto = new ServiceChargeMasterDto(parameters);

            // Assert
            dto.MasterType.Should().Be(parameters.MasterType);
            dto.ItemCode.Should().Be(parameters.ItemCode);
            dto.ItemDescription.Should().Be(parameters.ItemDescription);
            dto.ItemTypeCode.Should().Be(parameters.ItemTypeCode);
            dto.ItemTypeDescription.Should().Be(parameters.ItemTypeDescription);
            dto.TestCode.Should().Be(parameters.TestCode);
            dto.TestDescription.Should().Be(parameters.TestDescription);
            dto.ServiceType.Should().Be(parameters.ServiceType);
            dto.Category.Should().Be(parameters.Category);
            dto.Department.Should().Be(parameters.Department);
            dto.TurnAroundTime.Should().Be(parameters.TurnAroundTime);
            dto.Restricted.Should().Be(parameters.Restricted);
            dto.TestMethodAvailable.Should().Be(parameters.TestMethodAvailable);
            dto.FacilityCode.Should().Be(parameters.FacilityCode);
        }
    }
}