﻿using Aurora.AdministrationService.API.Models.Dto.ManageVisibility;
using Aurora.AdministrationService.API.Models.ResponseModels.Schedules;
namespace Aurora.AdministrationService.Tests.API.Dto.ManageVisibility
{
    public class PractitionerVisibilityResponseDtoTests
    {
        [Fact]
        public void Should_Create_Instance_With_Valid_Values()
        {
            // Arrange
            var expectedId = "123";
            var expectedFamilyName = "Doe";
            var expectedGivenName = "John";
            var expectedMiddleName = "A.";
            var expectedPrefix = "Dr.";
            var expectedPhotoUrl = "http://example.com/photo.jpg";

            var manageVisibilityId = 12345L;
            var locationId = "Location123";
            var practitionerId = "Practitioner123";
            var userGroups = new List<GetAllUserGroupsResponse>
            {
                new GetAllUserGroupsResponse { Id = 10, GroupName = "G1" },
                new GetAllUserGroupsResponse { Id = 11, GroupName = "G2" }
            };


            var manageVisibilityDetails = new List<ManageVisibilityResponseDto>
        {
            new ManageVisibilityResponseDto
            {
                // You can set properties of ManageVisibilityResponseDto as per your model
               ManageVisibilityId = manageVisibilityId,
                LocationID = locationId,
                PractitionerID = practitionerId,
                UserGroups = userGroups
            }
        };

            var dto = new PractitionerVisibilityResponseDto
            {
                Id = expectedId,
                FamilyName = expectedFamilyName,
                GivenName = expectedGivenName,
                MiddleName = expectedMiddleName,
                Prefix = expectedPrefix,
                PhotoUrl = expectedPhotoUrl,
                PractitionerVisibilityDtl = manageVisibilityDetails
            };

            // Act & Assert
            Assert.Equal(expectedId, dto.Id);
            Assert.Equal(expectedFamilyName, dto.FamilyName);
            Assert.Equal(expectedGivenName, dto.GivenName);
            Assert.Equal(expectedMiddleName, dto.MiddleName);
            Assert.Equal(expectedPrefix, dto.Prefix);
            Assert.Equal(expectedPhotoUrl, dto.PhotoUrl);
            Assert.Single(dto.PractitionerVisibilityDtl);  // Verify list count
            Assert.Equal(12345L, dto.PractitionerVisibilityDtl[0].ManageVisibilityId);  // Assuming ManageVisibilityResponseDto has an Id
        }

        [Fact]
        public void Should_Handle_Empty_ManageVisibilityDtl_List()
        {
            // Arrange
            var dto = new PractitionerVisibilityResponseDto
            {
                Id = "123",
                FamilyName = "Doe",
                GivenName = "John",
                MiddleName = "A.",
                Prefix = "Dr.",
                PhotoUrl = "http://example.com/photo.jpg",
                PractitionerVisibilityDtl = new List<ManageVisibilityResponseDto>()
            };

            // Act & Assert
            Assert.Empty(dto.PractitionerVisibilityDtl);  // Verify the list is empty
        }
              
        [Fact]
        public void Should_Handle_Null_Values_Gracefully()
        {
            // Arrange
            var dto = new PractitionerVisibilityResponseDto
            {
                Id = null,
                FamilyName = null,
                GivenName = null,
                MiddleName = null,
                Prefix = null,
                PhotoUrl = null,
                PractitionerVisibilityDtl = null
            };

            // Act & Assert
            Assert.Null(dto.Id);
            Assert.Null(dto.FamilyName);
            Assert.Null(dto.GivenName);
            Assert.Null(dto.MiddleName);
            Assert.Null(dto.Prefix);
            Assert.Null(dto.PhotoUrl);
            Assert.Null(dto.PractitionerVisibilityDtl); // Should be null
        }

    }

}
