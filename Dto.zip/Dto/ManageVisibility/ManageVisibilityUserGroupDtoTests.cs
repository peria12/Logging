﻿using Aurora.AdministrationService.API.Models.Dto.ManageVisibility;
namespace ManageVisibilityDtoTests
{
    public class ManageVisibilityUserGroupDtoTests
    {
        [Fact]
        public void ManageVisibilityUserGroupDto_Should_Set_And_Get_Properties()
        {
            // Arrange
            var id = 12345L;
            var manageVisibilityId = 67890L;
            var userGroups = "Group1";
            var recordVersion = new byte[] { 1, 2, 3, 4 };
            var isDeleted = true;

            // Act
            var dto = new ManageVisibilityUserGroupDto
            {
                ID = id,
                ManageVisibilityID = manageVisibilityId,
                UserGroups = userGroups,
                RecordVersion = recordVersion,
                IsDeleted = isDeleted
            };

            // Assert
            Assert.Equal(id, dto.ID);
            Assert.Equal(manageVisibilityId, dto.ManageVisibilityID);
            Assert.Equal(userGroups, dto.UserGroups);
            Assert.Equal(recordVersion, dto.RecordVersion);
            Assert.Equal(isDeleted, dto.IsDeleted);
        }

    }
}