﻿using Aurora.AdministrationService.API.Models.Dto.ManageVisibility;

namespace ManageVisibilityDtoTests
{
public class ManageVisibilityDtoTests
{
    [Fact]
    public void ManageVisibilityDto_Should_Create_Valid_Object()
    {
        // Arrange
        var manageVisibilityDto = new ManageVisibilityDto
        {
            ManageVisibilityId = 1,
            LocationID = "Location123",
            PractitionerID = "Practitioner456"
        };

        // Act & Assert
        Assert.NotNull(manageVisibilityDto);
        Assert.Equal(1, manageVisibilityDto.ManageVisibilityId);
        Assert.Equal("Location123", manageVisibilityDto.LocationID);
        Assert.Equal("Practitioner456", manageVisibilityDto.PractitionerID);
    }

    [Fact]
    public void ManageVisibilityDto_Should_Fail_If_LocationID_Is_Null()
    {
        // Arrange
        var manageVisibilityDto = new ManageVisibilityDto
        {
            ManageVisibilityId = 1,
            LocationID = null,
            PractitionerID = "Practitioner456"
        };

        // Act & Assert
        Assert.Throws<ArgumentNullException>(() =>
            ValidateManageVisibilityDto(manageVisibilityDto)
        );
    }

    [Fact]
    public void ManageVisibilityDto_Should_Fail_If_PractitionerID_Is_Null()
    {
        // Arrange
        var manageVisibilityDto = new ManageVisibilityDto
        {
            ManageVisibilityId = 1,
            LocationID = "Location123",
            PractitionerID = null
        };

        // Act & Assert
        Assert.Throws<ArgumentNullException>(() =>
            ValidateManageVisibilityDto(manageVisibilityDto)
        );
    }

   
    private static void ValidateManageVisibilityDto(ManageVisibilityDto manageVisibilityDto)
    {
        if (string.IsNullOrEmpty(manageVisibilityDto.LocationID))
            throw new ArgumentNullException(nameof(manageVisibilityDto));

        if (string.IsNullOrEmpty(manageVisibilityDto.PractitionerID))
            throw new ArgumentNullException(nameof(manageVisibilityDto));

        // Add other validation checks as necessary.
    }
}

}