﻿using System.ComponentModel.DataAnnotations;
using Aurora.AdministrationService.API.Models.Dto.ManageVisibility;

namespace ManageVisibilityDtoTests
{
    public class ManageVisibilityRequestDtoTests
    {
        [Fact]
        public void ManageVisibilityRequestDto_Should_Set_And_Get_Properties()
        {
            // Arrange
            var manageVisibilityId = 12345L;
            var locationId = "Location123";
            var practitionerId = "Practitioner123";
            var userGroups = new List<string> { "Group1", "Group2" };
            var action = "A";

            // Act
            var dto = new ManageVisibilityRequestDto
            {
                ManageVisibilityId = manageVisibilityId,
                LocationID = locationId,
                PractitionerID = practitionerId,
                UserGroups = userGroups,
                Action = action
            };

            // Assert
            Assert.Equal(manageVisibilityId, dto.ManageVisibilityId);
            Assert.Equal(locationId, dto.LocationID);
            Assert.Equal(practitionerId, dto.PractitionerID);
            Assert.Equal(userGroups, dto.UserGroups);
            Assert.Equal(action, dto.Action);
        }

       
        [Fact]
        public void ManageVisibilityRequestDto_Should_Throw_Exception_When_Action_Exceeds_MaxLength()
        {
            // Arrange
            var dto = new ManageVisibilityRequestDto
            {
                ManageVisibilityId = 12345L,
                LocationID = "Location123",
                PractitionerID = "Practitioner123",
                UserGroups = new List<string> { "Group1", "Group2" },
                Action = "AB" // Exceeds the MaxLength of 1
            };

            // Act
            var validationResults = new List<ValidationResult>();
            var validationContext = new ValidationContext(dto, null, null);
            Validator.TryValidateObject(dto, validationContext, validationResults, true);

            // Assert
            Assert.Single(validationResults);
            Assert.Equal("The field Action must be a string or array type with a maximum length of '1'.", validationResults[0].ErrorMessage);
        }
    }
}