﻿using System;
using Aurora.AdministrationService.API.Models.Dto.ManageVisibility;
using Xunit;

namespace ManageVisibilityDtoTests
{
    public class OpManageVisibilityDtoTests
    {
        [Fact]
        public void OpManageVisibilityDto_Should_Set_And_Get_Properties()
        {
            // Arrange
            var manageVisibilityId = 12345L;
            var locationId = "Location123";
            var practitionerId = "Practitioner123";
            var isDeleted = true;
            var recordVersion = new byte[] { 1, 2, 3, 4 };

            // Act
            var dto = new OpManageVisibilityDto
            {
                ManageVisibilityId = manageVisibilityId,
                LocationID = locationId,
                PractitionerID = practitionerId,
                IsDeleted = isDeleted,
                RecordVersion = recordVersion
            };

            // Assert
            Assert.Equal(manageVisibilityId, dto.ManageVisibilityId);
            Assert.Equal(locationId, dto.LocationID);
            Assert.Equal(practitionerId, dto.PractitionerID);
            Assert.Equal(isDeleted, dto.IsDeleted);
            Assert.Equal(recordVersion, dto.RecordVersion);
        }

        

    }
}