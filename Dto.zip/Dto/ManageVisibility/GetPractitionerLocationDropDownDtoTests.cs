﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Aurora.AdministrationService.API.Models.Dto.ManageVisibility;

namespace Aurora.AdministrationService.Tests.API.Dto.ManageVisibility
{
    public class GetPractitionerLocationDropDownDtoTests
    {
        [Fact]
        public void Should_Create_Instance_With_Valid_Values()
        {
            // Arrange
            long expectedId = 1;
            string expectedResourceID = "Resource123";
            string expectedName = "Test Location";
            string expectedAlias = "Alias123";

            // Act
            var dto = new GetPractitionerLocationDropDownDto
            {
                Id = expectedId,
                ResourceID = expectedResourceID,
                Name = expectedName,
                Alias = expectedAlias
            };

            // Assert
            Assert.Equal(expectedId, dto.Id);
            Assert.Equal(expectedResourceID, dto.ResourceID);
            Assert.Equal(expectedName, dto.Name);
            Assert.Equal(expectedAlias, dto.Alias);
        }

    }

}
