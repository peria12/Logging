﻿using Aurora.AdministrationService.API.Models.Dto.ManageVisibility;
using Aurora.AdministrationService.API.Models.ResponseModels.Schedules;
namespace ManageVisibilityDtoTests
{
    public class ManageVisibilityResponseDtoTests
    {
        [Fact]
        public void ManageVisibilityResponseDto_Should_Set_And_Get_Properties()
        {
            // Arrange
            var manageVisibilityId = 12345L;
            var locationId = "Location123";
            var practitionerId = "Practitioner123";
            var userGroups = new List<GetAllUserGroupsResponse>
            {
                new GetAllUserGroupsResponse { Id = 10, GroupName = "G1" },
                new GetAllUserGroupsResponse { Id = 11, GroupName = "G2" }
            };

            // Act
            var dto = new ManageVisibilityResponseDto
            {
                ManageVisibilityId = manageVisibilityId,
                LocationID = locationId,
                PractitionerID = practitionerId,
                UserGroups = userGroups
            };

            // Assert
            Assert.Equal(manageVisibilityId, dto.ManageVisibilityId);
            Assert.Equal(locationId, dto.LocationID);
            Assert.Equal(practitionerId, dto.PractitionerID);
            Assert.Equal(userGroups, dto.UserGroups);
        }

    }
}