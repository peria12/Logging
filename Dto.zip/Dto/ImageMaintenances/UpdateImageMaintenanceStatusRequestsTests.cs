﻿using Aurora.AdministrationService.API.Models.Dto.ImageMaintenance;
namespace Aurora.AdministrationService.Tests.API.Dto.ImageMaintenances
{
    public class UpdateImageMaintenanceStatusRequestsTests
    {
        [Fact]
        public void Should_Have_Default_Values_When_Initialized()
        {
            // Act
            var request = new UpdateImageMaintenanceStatusRequests() { Id=0,Status=false};

            // Assert
            Assert.Equal(0, request.Id); // Default value for int is 0
            Assert.False(request.Status); // Default value for bool is false
        }

        [Fact]
        public void Should_Allow_Properties_To_Be_Set()
        {
            // Arrange
            var request = new UpdateImageMaintenanceStatusRequests
            {
                Id = 1,
                Status = true
            };

            // Assert
            Assert.Equal(1, request.Id); // Assert Id is correctly set
            Assert.True(request.Status); // Assert Status is correctly set to true
        }

    }
}

