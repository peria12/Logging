﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Aurora.AdministrationService.API.Models.Dto.ImageMaintenance;
using System;
using Xunit;


namespace Aurora.AdministrationService.Tests.API.Dto.ImageMaintenances
{
    public class ImageMaintenanceDetailDtoTests
    {
        [Fact]
        public void Should_Have_Default_Values_When_Initialized()
        {
            // Act
            var dto = new ImageMaintenanceDetailDto();

            // Assert
            Assert.Equal(0, dto.Id); // Default value for long is 0
            Assert.Null(dto.ScreenType); // Default value for string is empty string (but not null due to null! initialization)
            Assert.Null(dto.Header); // Default value for string is empty string (but not null due to null! initialization)
            Assert.Null(dto.ImageURL); // Default value for string is empty string (but not null due to null! initialization)
            Assert.Null(dto.Description); // Default value for string is empty string (but not null due to null! initialization)
            Assert.Null(dto.UpdatedAt); // Default value for nullable DateTime is null
            Assert.Equal(default(DateTime), dto.CreatedAt); // Default value for DateTime is 1/1/0001 12:00:00 AM
            Assert.Null(dto.UpdatedBy); // Default value for string is empty
            Assert.False(dto.IsActive); // Default value for bool is false
            Assert.Null(dto.LastUpdatedBy); // Default value for string is empty
        }

        [Fact]
        public void Should_Allow_Properties_To_Be_Set()
        {
            // Arrange
            var dto = new ImageMaintenanceDetailDto
            {
                Id = 1,
                ScreenType = "Home",
                Header = "Header Text",
                ImageURL = "http://image.url",
                Description = "Description Text",
                UpdatedAt = DateTime.Now,
                CreatedAt = DateTime.Now,
                UpdatedBy = "Admin",
                IsActive = true,
                LastUpdatedBy = "Admin2"
            };

            // Assert
            Assert.Equal(1, dto.Id);
            Assert.Equal("Home", dto.ScreenType);
            Assert.Equal("Header Text", dto.Header);
            Assert.Equal("http://image.url", dto.ImageURL);
            Assert.Equal("Description Text", dto.Description);
            Assert.NotNull(dto.UpdatedAt); // Ensure UpdatedAt is set
            Assert.NotEqual(default(DateTime), dto.CreatedAt); // Ensure CreatedAt is set
            Assert.Equal("Admin", dto.UpdatedBy);
            Assert.True(dto.IsActive);
            Assert.Equal("Admin2", dto.LastUpdatedBy);
        }

        [Fact]
        public void Should_Initialize_UpdatedAt_As_Null_When_Not_Provided()
        {
            // Arrange
            var dto = new ImageMaintenanceDetailDto
            {
                Id = 1,
                ScreenType = "Home",
                Header = "Header Text",
                ImageURL = "http://image.url",
                Description = "Description Text",
                CreatedAt = DateTime.Now,
                IsActive = true,
                LastUpdatedBy = "Admin2"
            };

            // Assert
            Assert.Null(dto.UpdatedAt); // Should be null if not explicitly set
        }

        [Fact]
        public void Should_Allow_UpdatedAt_To_Be_Set()
        {
            // Arrange
            var dto = new ImageMaintenanceDetailDto
            {
                Id = 1,
                ScreenType = "Home",
                Header = "Header Text",
                ImageURL = "http://image.url",
                Description = "Description Text",
                UpdatedAt = DateTime.Now,
                CreatedAt = DateTime.Now,
                UpdatedBy = "Admin",
                IsActive = true,
                LastUpdatedBy = "Admin2"
            };

            // Assert
            Assert.NotNull(dto.UpdatedAt); // Should not be null if explicitly set
        }


    }
}
