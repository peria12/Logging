﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Aurora.AdministrationService.API.Models.Dto.ImageMaintenance;
using Aurora.AdministrationService.API.Enum.ImageMaintenance;
using System;
using System.Collections.Generic;
using Xunit;

namespace Aurora.AdministrationService.Tests.API.Dto.ImageMaintenances

    {
        public class ImageMaintenanceSearchRequestTests
        {
            [Fact]
            public void Should_Have_Default_Values_When_Initialized()
            {
                // Act
                var request = new ImageMaintenanceSearchRequest();

                // Assert
                Assert.Equal(default(ImageMaintenanceSourceType), request.SelectedImageSourceType); // Default enum value is the first item in the enum (usually 0)
                Assert.Empty(request.SelectedScreenTypes); // Default value for list is empty
                Assert.Null(request.SelectedCreatedDate); // Default value for nullable DateTime is null
                Assert.Null(request.SelectedStatus); // Default value for string is null
                Assert.Null(request.PageNumber); // Default value for nullable int is null
                Assert.Null(request.PageSize); // Default value for nullable int is null
            }

            [Fact]
            public void Should_Allow_Properties_To_Be_Set()
            {
                // Arrange
                var request = new ImageMaintenanceSearchRequest
                {
                    SelectedImageSourceType = ImageMaintenanceSourceType.All, // Example enum value
                    SelectedScreenTypes = new List<string> { "Home", "Profile" },
                    SelectedCreatedDate = DateTime.Now,
                    SelectedStatus = "Active",
                    PageNumber = 1,
                    PageSize = 10
                };

                // Assert
                Assert.Equal(ImageMaintenanceSourceType.All, request.SelectedImageSourceType);
                Assert.Equal(2, request.SelectedScreenTypes.Count); // Should have 2 elements in the list
                Assert.Equal("Home", request.SelectedScreenTypes[0]);
                Assert.Equal("Profile", request.SelectedScreenTypes[1]);
                Assert.NotNull(request.SelectedCreatedDate); // Ensure the value is set
                Assert.Equal("Active", request.SelectedStatus);
                Assert.Equal(1, request.PageNumber);
                Assert.Equal(10, request.PageSize);
            }

            [Fact]
            public void Should_Initialize_SelectedScreenTypes_As_Empty_List_When_Constructor_Is_Called()
            {
                // Act
                var request = new ImageMaintenanceSearchRequest();

                // Assert
                Assert.NotNull(request.SelectedScreenTypes); // Should be initialized as an empty list
                Assert.Empty(request.SelectedScreenTypes); // Should be empty initially
            }

            [Fact]
            public void Should_Allow_Empty_SelectedScreenTypes_To_Be_Set()
            {
                // Arrange
                var request = new ImageMaintenanceSearchRequest
                {
                    SelectedScreenTypes = new List<string>() // Explicitly setting an empty list
                };

                // Assert
                Assert.NotNull(request.SelectedScreenTypes); // Should not be null
                Assert.Empty(request.SelectedScreenTypes); // Should be empty
            }

            [Fact]
            public void Should_Allow_SelectedCreatedDate_To_Be_Set()
            {
                // Arrange
                var request = new ImageMaintenanceSearchRequest
                {
                    SelectedCreatedDate = DateTime.Now
                };

                // Assert
                Assert.NotNull(request.SelectedCreatedDate); // Should be set to a valid DateTime
            }

            [Fact]
            public void Should_Allow_SelectedStatus_To_Be_Set()
            {
                // Arrange
                var request = new ImageMaintenanceSearchRequest
                {
                    SelectedStatus = "Inactive"
                };

                // Assert
                Assert.Equal("Inactive", request.SelectedStatus); // Should be set to the provided status
            }

            [Fact]
            public void Should_Allow_PageNumber_To_Be_Set()
            {
                // Arrange
                var request = new ImageMaintenanceSearchRequest
                {
                    PageNumber = 2
                };

                // Assert
                Assert.Equal(2, request.PageNumber); // Should be set to the provided page number
            }

            [Fact]
            public void Should_Allow_PageSize_To_Be_Set()
            {
                // Arrange
                var request = new ImageMaintenanceSearchRequest
                {
                    PageSize = 20
                };

                // Assert
                Assert.Equal(20, request.PageSize); // Should be set to the provided page size
            }

            [Fact]
            public void Should_Allow_Nullable_Properties_To_Be_Null()
            {
                // Arrange
                var request = new ImageMaintenanceSearchRequest
                {
                    SelectedCreatedDate = null,
                    PageNumber = null,
                    PageSize = null
                };

                // Assert
                Assert.Null(request.SelectedCreatedDate); // Nullable DateTime should be null
                Assert.Null(request.PageNumber); // Nullable int should be null
                Assert.Null(request.PageSize); // Nullable int should be null
            }

          
        }
    }
