﻿using Aurora.AdministrationService.API.Models.Dto.ImageMaintenance;

namespace Aurora.AdministrationService.Tests.API.Dto.ImageMaintenancesusing
{
    public class UpdateImageMaintainanceRequestsTests
    {
        [Fact]
        public void Should_Have_Default_Values_When_Initialized()
        {
            // Act
            var request = new UpdateImageMaintainanceRequests() { Description="",Header="",ScreenType=""};

            // Assert
            Assert.Empty(request.ScreenType); // Default value for string is empty string (but not null due to null! initialization)
            Assert.Empty(request.Header); // Default value for string is empty string (but not null due to null! initialization)
            Assert.Null(request.ImageURL); // Default value for nullable string is null
            Assert.Null(request.Status); // Default value for nullable bool is null
            Assert.Empty(request.Description); // Default value for string is empty string (but not null due to null! initialization)
        }

        [Fact]
        public void Should_Allow_Properties_To_Be_Set()
        {
            // Arrange
            var request = new UpdateImageMaintainanceRequests
            {
                ScreenType = "Home",
                Header = "Header Text",
                ImageURL = "http://image.url",
                Status = true,
                Description = "Description Text"
            };

            // Assert
            Assert.Equal("Home", request.ScreenType);
            Assert.Equal("Header Text", request.Header);
            Assert.Equal("http://image.url", request.ImageURL);
            Assert.True(request.Status.HasValue && request.Status.Value); // Ensure Status is true
            Assert.Equal("Description Text", request.Description);
        }

        [Fact]
        public void Should_Allow_ImageURL_To_Be_Null()
        {
            // Arrange
            var request = new UpdateImageMaintainanceRequests
            {
                ScreenType = "Home",
                Header = "Header Text",
                Description = "Description Text",
                ImageURL = null // Explicitly setting it to null
            };

            // Assert
            Assert.Null(request.ImageURL); // ImageURL can be null
        }

        [Fact]
        public void Should_Allow_Status_To_Be_Null()
        {
            // Arrange
            var request = new UpdateImageMaintainanceRequests
            {
                ScreenType = "Home",
                Header = "Header Text",
                Description = "Description Text",
                Status = null // Explicitly setting it to null
            };

            // Assert
            Assert.Null(request.Status); // Status can be null
        }
    }
}

