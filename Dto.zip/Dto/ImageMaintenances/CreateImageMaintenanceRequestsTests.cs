﻿using Aurora.AdministrationService.API.Models.Dto.ImageMaintenance;
using Aurora.AdministrationService.CrossCutting.Constants;
using System.ComponentModel.DataAnnotations;
namespace Aurora.AdministrationService.Tests.API.Dto.ImageMaintenances;
public class CreateImageMaintenanceRequestsTests
{
    [Fact]
    public void Should_Have_ValidationError_When_Header_Exceeds_MaxLength()
    {
        // Arrange
        var request = new AdministrationService.API.Models.RequestModels.ImageMaintenance.CreateImageMaintenanceRequest
        {
            ScreenType = "Home",
            Header = new string('A', 256), // 256 characters, exceeding the max length of 255
            Description = "Valid description"
        };

        // Act
        var validationResults = ValidateModel(request);

        // Assert
        Assert.Contains(validationResults, v => v.ErrorMessage == AppConstants.Maximum255Character);
    }

    [Fact]
    public void Should_Have_ValidationError_When_Header_Has_Special_Characters()
    {
        // Arrange
        var request = new AdministrationService.API.Models.RequestModels.ImageMaintenance.CreateImageMaintenanceRequest
        {
            ScreenType = "Home",
            Header = "Header@123", // Special character '@' should fail
            Description = "Valid description",
            Status= true

        };

        // Act
        var validationResults = ValidateModel(request);

        // Assert
        Assert.Contains(validationResults, v => v.ErrorMessage == AppConstants.SpecialCharacterNotAllow);
    }

    [Fact]
    public void Should_Have_ValidationError_When_Description_Exceeds_MaxLength()
    {
        // Arrange
        var request = new AdministrationService.API.Models.RequestModels.ImageMaintenance.CreateImageMaintenanceRequest
        {
            ScreenType = "Home",
            Header = "ValidHeader",
            Description = new string('A', 1001), // 1001 characters, exceeding the max length of 1000
        };

        // Act
        var validationResults = ValidateModel(request);

        // Assert
        Assert.Contains(validationResults, v => v.ErrorMessage == AppConstants.Maximum1000Character);
    }

    [Fact]
    public void Should_Have_ValidationError_When_Description_Has_Special_Characters()
    {
        // Arrange
        var request = new AdministrationService.API.Models.RequestModels.ImageMaintenance.CreateImageMaintenanceRequest
        {
            ScreenType = "Home",
            Header = "ValidHeader",
            Description = "Invalid!Description", // Special character '!' should fail
        };

        // Act
        var validationResults = ValidateModel(request);

        // Assert
        Assert.Contains(validationResults, v => v.ErrorMessage == AppConstants.SpecialCharacterNotAllow);
    }

    [Fact]
    public void Should_Have_ValidationError_When_ImageURL_Exceeds_MaxLength()
    {
        // Arrange
        var request = new AdministrationService.API.Models.RequestModels.ImageMaintenance.CreateImageMaintenanceRequest
        {
            ScreenType = "Home",
            Header = "ValidHeader",
            Description = "Valid description",
            ImageURL = new string('A', 501) // Exceeding max length of 500
        };

        // Act
        var validationResults = ValidateModel(request);

        // Assert
        Assert.Contains(validationResults, v => v.ErrorMessage == AppConstants.Maximum500Character);
    }

    
    private static List<ValidationResult> ValidateModel(object model)
    {
        var validationResults = new List<ValidationResult>();
        var context = new ValidationContext(model);
        Validator.TryValidateObject(model, context, validationResults, true);
        return validationResults;
    }
}
