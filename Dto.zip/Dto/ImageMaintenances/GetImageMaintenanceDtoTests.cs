﻿using Aurora.AdministrationService.API.Models.Dto.ImageMaintenance;

namespace Aurora.AdministrationService.Tests.API.Dto.ImageMaintenances
{
    public class GetImageMaintenanceDtoTests
    {
       
        [Fact]
        public void Should_Allow_Properties_To_Be_Set()
        {
            // Arrange
            var dto = new GetImageMaintenanceDto
            {
                Id = 1,
                ScreenType = 2,
                Status = true,
                Header = "Header Text",
                Description = "Description Text",
                ImageURL = "http://image.url",
                RecordVersion = new byte[] { 1, 2, 3 },
                IsDeleted = false,
                CreatedBy = "Admin",
                CreatedDate = DateTime.Now,
                UpdatedBy = "Admin2",
                UpdatedDate = DateTime.Now
            };

            // Assert
            Assert.Equal(1, dto.Id);
            Assert.Equal(2, dto.ScreenType);
            Assert.True(dto.Status);
            Assert.Equal("Header Text", dto.Header);
            Assert.Equal("Description Text", dto.Description);
            Assert.Equal("http://image.url", dto.ImageURL);
            Assert.Equal(new byte[] { 1, 2, 3 }, dto.RecordVersion);
            Assert.False(dto.IsDeleted);
            Assert.Equal("Admin", dto.CreatedBy);
            Assert.NotEqual(default(DateTime), dto.CreatedDate); // Ensure CreatedDate is set
            Assert.Equal("Admin2", dto.UpdatedBy);
            Assert.NotNull(dto.UpdatedDate); // Ensure UpdatedDate is set
        }

        [Fact]
        public void Should_Initialize_UpdatedDate_As_Null_When_Not_Provided()
        {
            // Arrange
            var dto = new GetImageMaintenanceDto
            {
                Id = 1,
                ScreenType = 1,
                Status = true,
                Header = "Header",
                Description = "Description",
                ImageURL = "http://image.url",
                RecordVersion = new byte[] { 1 },
                IsDeleted = false,
                CreatedBy = "Admin",
                CreatedDate = DateTime.Now,
                UpdatedBy = "Admin"
            };

            // Assert
            Assert.Null(dto.UpdatedDate); // Should be null if not set
        }

        [Fact]
        public void Should_Allow_Nullable_UpdatedDate_To_Be_Set()
        {
            // Arrange
            var dto = new GetImageMaintenanceDto
            {
                Id = 1,
                ScreenType = 1,
                Status = true,
                Header = "Header",
                Description = "Description",
                ImageURL = "http://image.url",
                RecordVersion = new byte[] { 1 },
                IsDeleted = false,
                CreatedBy = "Admin",
                CreatedDate = DateTime.Now,
                UpdatedBy = "Admin",
                UpdatedDate = DateTime.Now
            };

            // Assert
            Assert.NotNull(dto.UpdatedDate); // Should be set to a valid DateTime
        }

       
    }
}
