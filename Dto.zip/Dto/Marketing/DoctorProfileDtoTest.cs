﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Aurora.AdministrationService.API.Models.Dto.Marketing.DoctorProfile.Summary;
using Microsoft.Graph;

namespace Aurora.AdministrationService.Tests.API.Dto.Marketing
{
    public class DoctorProfileDtoTest
    {
        [Fact]
        public void MyClass_DefaultValues_ShouldBeCorrect()
        {
            // Arrange
            var myObject = new DoctorProfileDto
            {
                ID = 1,
                Name = "AAA",
                Speciality = "Doctor, Patient",
                Rank = "2",
                Locations = "Hyderabad, Chennai",
                Organization = "HealthCare, Doctor",
                SpokenLanguage = "Tamil, Teugu",
                UpdatedBy = "David",
                UpdatedDate = Convert.ToDateTime("2025-03-30T12:44:32.1943553Z"),
                UpdatedDateStr = "12",
                Status = true,
                StatusStr = "1,2",
            };

            long ID = 1;
            string Name = "AAA";
            string Speciality = "Doctor, Patient";
            string Rank = "2";
            string Locations = "Hyderabad, Chennai";
            string Organization ="HealthCare, Doctor";
            string SpokenLanguage = "Tamil, Teugu";
            string UpdatedBy = "David";
            DateTime UpdatedDate = Convert.ToDateTime("2025-03-30T12:44:32.1943553Z");
            string UpdatedDateStr = "12";
            bool? Status = true;
            string StatusStr = "1,2";

            // Act
            myObject.ID = 1;
            myObject.Name = "AAA";
            myObject.Speciality = "Doctor, Patient";
            myObject.Rank = "2";
            myObject.Locations = "Hyderabad, Chennai";
            myObject.Organization = "HealthCare, Doctor";
            myObject.SpokenLanguage = "Tamil, Teugu";
            myObject.UpdatedBy = "David";
            myObject.UpdatedDate = Convert.ToDateTime("2025-03-30T12:44:32.1943553Z");
            myObject.UpdatedDateStr = "12";
            myObject.Status = true;
            myObject.StatusStr = "1,2";

            // Assert
            Assert.Equal(ID, myObject.ID);
            Assert.Equal(Name, myObject.Name);
            Assert.Equal(Speciality, myObject.Speciality);
            Assert.Equal(Rank, myObject.Rank = "2");
            Assert.Equal(Locations, myObject.Locations = "Hyderabad, Chennai");
            Assert.Equal(Organization, myObject.Organization = "HealthCare, Doctor");
            Assert.Equal(SpokenLanguage, myObject.SpokenLanguage = "Tamil, Teugu");
            Assert.Equal(UpdatedBy, myObject.UpdatedBy = "David");
            Assert.Equal(UpdatedDate, myObject.UpdatedDate = Convert.ToDateTime("2025-03-30T12:44:32.1943553Z"));
            Assert.Equal(UpdatedDateStr, myObject.UpdatedDateStr = "12");
            Assert.Equal(Status, myObject.Status = true);
            Assert.Equal(StatusStr, myObject.StatusStr = "1,2");
        }
    }
}
