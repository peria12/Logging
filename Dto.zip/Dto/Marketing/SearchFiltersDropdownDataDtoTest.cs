﻿using System;
using System.Collections.Generic;
using System.Diagnostics.Metrics;
using System.Drawing.Printing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Aurora.AdministrationService.API.Models.Dto.InsurancePanels;
using Aurora.AdministrationService.API.Models.Dto.Marketing.DoctorProfile.Summary;
using Aurora.AdministrationService.Tests.API.CommonMock;
using Microsoft.AspNetCore.Mvc.Rendering;
using Microsoft.Graph;

namespace Aurora.AdministrationService.Tests.API.Dto.Marketing
{
    public class SearchFiltersDropdownDataDtoTest
    {
        [Fact]
        public void MyClass_DefaultValues_ShouldBeCorrect()
        {
            List<SelectListItem> SpecialtyMasterList = new List<SelectListItem> { new SelectListItem { Value = "1", Text = "Dermotaligy" }, new SelectListItem { Value = "2", Text = "Neurologist" } };
            List<SelectListItem> LocationMasterList = new List<SelectListItem> { new SelectListItem { Value = "1", Text = "Delhi" }, new SelectListItem { Value = "2", Text = "Bangalore" } };
            List<SelectListItem> OrganizationMasterList = new List<SelectListItem> { new SelectListItem { Value = "1", Text = "Surgery" }, new SelectListItem { Value = "2", Text = "Psychiatry" } };
            List<SelectListItem> SpokenLanguageMasterList = new List<SelectListItem> { new SelectListItem { Value = "1", Text = "English" }, new SelectListItem { Value = "2", Text = "Hindi" } };
            
            var myObject = new SearchFiltersDropdownDataDto
            {
                SpecialtyMasterList = SpecialtyMasterList,
                LocationMasterList= LocationMasterList,
                OrganizationMasterList= OrganizationMasterList,
                SpokenLanguageMasterList = SpokenLanguageMasterList
            };
            // Assert
            Assert.Equal(SpecialtyMasterList, myObject.SpecialtyMasterList);
            Assert.Equal(LocationMasterList, myObject.LocationMasterList);
            Assert.Equal(OrganizationMasterList, myObject.OrganizationMasterList);
            Assert.Equal(SpokenLanguageMasterList, myObject.SpokenLanguageMasterList);
        }
    }
}