﻿using Aurora.AdministrationService.API.Models.Dto.WhatHappenings;
using FluentAssertions;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Aurora.AdministrationService.Tests.API.Dto.WhatsHappening
{
    public class GetCategoryListDtoTest
    {
        [Fact]
        public void GetCategoryListDto_ShouldInitializePropertiesCorrectly()
        {
            // Arrange
            var id = 1L;
            var code = "CAT001";
            var definition = "Category Definition";
            var recordVersion = new byte[] { 1, 2, 3, 4 };
            var isDeleted = false;
            var createdBy = "TestUser";
            var createdDate = DateTime.UtcNow;
            var updatedBy = "UpdatedUser";
            var updatedDate = DateTime.UtcNow.AddDays(1);

            // Act
            var dto = new GetCategoryListDto
            {
                ID = id,
                Code = code,
                Definition = definition,
                RecordVersion = recordVersion,
                IsDeleted = isDeleted,
                CreatedBy = createdBy,
                CreatedDate = createdDate,
                UpdatedBy = updatedBy,
                UpdatedDate = updatedDate
            };

            // Assert
            dto.ID.Should().Be(id);
            dto.Code.Should().Be(code);
            dto.Definition.Should().Be(definition);
            dto.RecordVersion.Should().BeEquivalentTo(recordVersion);
            dto.IsDeleted.Should().Be(isDeleted);
            dto.CreatedBy.Should().Be(createdBy);
            dto.CreatedDate.Should().BeCloseTo(createdDate, TimeSpan.FromMilliseconds(100));
            dto.UpdatedBy.Should().Be(updatedBy);
            dto.UpdatedDate.Should().BeCloseTo(updatedDate, TimeSpan.FromMilliseconds(100));
        }

        [Fact]
        public void GetCategoryListDto_ShouldHaveDefaultValues()
        {
            // Act
            var dto = new GetCategoryListDto
            {
                ID = 1,
                IsDeleted = false,
                CreatedBy = "TestUser",
                CreatedDate = DateTime.UtcNow
            };

            // Assert
            dto.Code.Should().BeNull();
            dto.Definition.Should().BeNull();
            dto.RecordVersion.Should().BeEmpty();
            dto.UpdatedBy.Should().BeNull();
            dto.UpdatedDate.Should().BeNull();
        }

    }
}
