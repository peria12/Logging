﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Aurora.AdministrationService.API.Models.Dto.Marketing.DoctorProfile.Summary;

namespace Aurora.AdministrationService.Tests.API.Dto.Marketing
{
    public class DoctorProfileSearchFilterDtoTest
    {
        [Fact]
        public void MyClass_DefaultValues_ShouldBeCorrect()
        {
            // Arrange
            var myObject = new DoctorProfileSearchFilterDto
            {
                Name = "David",
                Speciality = "Doctor, Patient",
                Rank = "1",
                Locations = "Hyderabad, Chennai",
                Organization = "HealthCare, Medical",
                SpokenLanguage = "Hindi, Tamil",
                Status = true,
                PageNumber = 1,
                PageSize = 10,
            };

            string Name = "David";
            string Speciality = "Doctor, Patient";
            string Rank = "1";
            string Locations = "Hyderabad, Chennai";
            string Organization = "HealthCare, Medical";
            string SpokenLanguage = "Hindi, Tamil";
            bool Status = true;
            int PageNumber = 1;
            int PageSize = 10;

            // Act
            myObject.Name = "David";
            myObject.Speciality = "Doctor, Patient";
            myObject.Rank = "1";
            myObject.Locations = "Hyderabad, Chennai";
            myObject.Organization = "HealthCare, Medical";
            myObject.SpokenLanguage = "Hindi, Tamil";
            myObject.Status = true;
            myObject.PageNumber = 1;
            myObject.PageSize = 10;

            // Assert
            Assert.Equal(Name, myObject.Name = "David");
            Assert.Equal(Speciality, myObject.Speciality = "Doctor, Patient");
            Assert.Equal(Rank, myObject.Rank = "1");
            Assert.Equal(Locations, myObject.Locations = "Hyderabad, Chennai");
            Assert.Equal(Organization, myObject.Organization = "HealthCare, Medical");
            Assert.Equal(SpokenLanguage, myObject.SpokenLanguage = "Hindi, Tamil");
            Assert.Equal(Status, myObject.Status = true);
            Assert.Equal(PageNumber, myObject.PageNumber = 1);
            Assert.Equal(PageSize, myObject.PageSize = 10);
        }
    }
}
