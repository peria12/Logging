﻿using Aurora.AdministrationService.API.Models.Dto.DrugMasters;
using FluentAssertions;
using System.ComponentModel.DataAnnotations;

namespace Aurora.AdministrationService.Tests.API.Dto
{
    public class DrugMasterDtoTests
    {
        [Fact]
        public void DrugMasterDto_Should_HaveValidProperties()
        {
            var dto = new DrugMasterDto
            {
                ResourceID = "RES1234567890",
                MasterType = "Type1",
                ItemCode = "Item123",
                ItemDescription = "Sample Item Description",
                ItemTypeCode = "ITC123",
                ItemTypeDescription = "Item Type Desc",
                MedicationCode = "MED001",
                MedicationDescription = "Medication Desc",
                MedicationCategory = "CategoryA",
                MedicationType = "TypeB",
                Strength = "500mg",
                DrugForm = "Tablet",
                Caution = "Handle with care",
                DosageUnit = "mg",
                DoseValue = 10.5m,
                FrequencyDesc = "Twice a day",
                FrequencyValue = 2.0m,
                DurationUnit = "Days",
                DurationValue = 7,
                Route = "Oral",
                DrugFormGroup = "GroupA",
                Instructions = "Take with food",
                IsSTATDrug = true,
                IsAlertRequired = false,
                IsPoisonDrug = false,
                IsPsychotropicDrug = true,
                IsDangerousDrug = false,
                IsAnesthesiaDrug = false,
                FacilityCode = "FAC001",
                BrandShare = "BrandX",
                SourceAppId = 1001,
                Title = "Drug Master Title",
                EventAction = "Create",
                RequestedDate = DateTime.UtcNow,
                RegionCode = "MYS",
                LanguageCode = "EN",
                LocationCode = "LOC001",
                AcknowledgementID = "ACK123456"
            };

            dto.ResourceID.Should().NotBeNullOrEmpty().And.Match(s => s.Length <= 20);
            dto.MasterType.Should().NotBeNullOrEmpty().And.Match(s => s.Length <= 50);
            dto.ItemCode.Should().NotBeNullOrEmpty().And.Match(s => s.Length <= 50);
            dto.ItemDescription.Should().NotBeNullOrEmpty().And.Match(s => s.Length <= 255);
            dto.DoseValue.Should().BeGreaterThan(0);
            dto.FrequencyValue.Should().BeGreaterThan(0);
        }

        [Fact]
        public void DrugMasterDto_Validation_Should_Fail_When_Fields_Exceed_MaxLength()
        {
            var dto = new DrugMasterDto { ResourceID = new string('A', 21), MasterType = "Drug", ItemCode = "IT006", MedicationCode = "ME006" };
            var validationResults = ValidateModel(dto);

            // Updated expected message to match actual validation message
            validationResults.Should().ContainSingle().Which.ErrorMessage.Should().Contain("Maximum 20 characters");
        }

        private static ValidationResult[] ValidateModel(object model)
        {
            var context = new ValidationContext(model, null, null);
            var results = new List<ValidationResult>();
            Validator.TryValidateObject(model, context, results, true);
            return results.ToArray();
        }

        [Fact]
        public void DrugMasterDto_ParameterizedConstructor_Should_SetPropertiesCorrectly()
        {
            // Arrange
            var parameters = new DrugMasterParams
            {
                ResourceID = "RES123",
                MasterType = "MasterType1",
                ItemCode = "ITEM001",
                ItemDescription = "Sample Item",
                ItemTypeCode = "ITC001",
                ItemTypeDescription = "Item Type Desc",
                MedicationCode = "MED001",
                MedicationDescription = "Medication Desc",
                MedicationCategory = "Category A",
                MedicationType = "Type X",
                Strength = "500mg",
                DrugForm = "Tablet",
                Caution = "Take with food",
                DosageUnit = "mg",
                DoseValue = 2.5m,
                FrequencyDesc = "Twice a day",
                FrequencyValue = 12m,
                DurationUnit = "Days",
                DurationValue = 7,
                Route = "Oral",
                DrugFormGroup = "Group A",
                Instructions = "Before meals",
                IsSTATDrug = true,
                IsAlertRequired = false,
                IsPoisonDrug = false,
                IsPsychotropicDrug = false,
                IsDangerousDrug = false,
                IsAnesthesiaDrug = true,
                FacilityCode = "FAC001",
                BrandShare = "BrandX"
            };

            // Act
            var dto = new DrugMasterDto(parameters);

            // Assert
            dto.ResourceID.Should().Be(parameters.ResourceID);
            dto.MasterType.Should().Be(parameters.MasterType);
            dto.ItemCode.Should().Be(parameters.ItemCode);
            dto.ItemDescription.Should().Be(parameters.ItemDescription);
            dto.ItemTypeCode.Should().Be(parameters.ItemTypeCode);
            dto.ItemTypeDescription.Should().Be(parameters.ItemTypeDescription);
            dto.MedicationCode.Should().Be(parameters.MedicationCode);
            dto.MedicationDescription.Should().Be(parameters.MedicationDescription);
            dto.MedicationCategory.Should().Be(parameters.MedicationCategory);
            dto.MedicationType.Should().Be(parameters.MedicationType);
            dto.Strength.Should().Be(parameters.Strength);
            dto.DrugForm.Should().Be(parameters.DrugForm);
            dto.Caution.Should().Be(parameters.Caution);
            dto.DosageUnit.Should().Be(parameters.DosageUnit);
            dto.DoseValue.Should().Be(parameters.DoseValue);
            dto.FrequencyDesc.Should().Be(parameters.FrequencyDesc);
            dto.FrequencyValue.Should().Be(parameters.FrequencyValue);
            dto.DurationUnit.Should().Be(parameters.DurationUnit);
            dto.DurationValue.Should().Be(parameters.DurationValue);
            dto.Route.Should().Be(parameters.Route);
            dto.DrugFormGroup.Should().Be(parameters.DrugFormGroup);
            dto.Instructions.Should().Be(parameters.Instructions);
            dto.IsSTATDrug.Should().Be(parameters.IsSTATDrug);
            dto.IsAlertRequired.Should().Be(parameters.IsAlertRequired);
            dto.IsPoisonDrug.Should().Be(parameters.IsPoisonDrug);
            dto.IsPsychotropicDrug.Should().Be(parameters.IsPsychotropicDrug);
            dto.IsDangerousDrug.Should().Be(parameters.IsDangerousDrug);
            dto.IsAnesthesiaDrug.Should().Be(parameters.IsAnesthesiaDrug);
            dto.FacilityCode.Should().Be(parameters.FacilityCode);
            dto.BrandShare.Should().Be(parameters.BrandShare);
        }
    }
}