﻿using Aurora.AdministrationService.API.Models.ResponseModels.V1.AdminSpeciality;
using FluentAssertions;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Aurora.AdministrationService.Tests.API.Dto.Speciality
{
    public class SpecialityResponseDtoTests
    {
        [Fact]
        public void SpecialtyResponseDto_ShouldAllowNullDefinition()
        {
            // Act
            var dto = new SpecialtyResponseDto { HealthcareServiceName = null };

            // Assert
            dto.HealthcareServiceName.Should().BeNull();
        }

        [Fact]
        public void SpecialtyResponseDto_ShouldSetAndGetDefinitionCorrectly()
        {
            // Arrange
            var dto = new SpecialtyResponseDto { HealthcareServiceName = "Specialty-Definition" };

            // Assert
            dto.HealthcareServiceName.Should().Be("Specialty-Definition");
        }
    }
}
