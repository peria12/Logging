﻿using Aurora.AdministrationService.API.Models.Dto.Doctor;
using FluentAssertions;

namespace Aurora.AdministrationService.Tests.API.Dto.DoctorProfile
{
    public class DoctorListDtoTests
    {
        [Fact]
        public void DoctorListDto_DefaultValues_ShouldBeCorrect()
        {
            // Arrange
            var doctor = new DoctorListDto
            {
                ID = 1,
                ResourceID = "DOC123",
                GivenName = "John",
                FamilyName = "Doe",
                MiddleName = "A",
                Name = "Dr. John Doe",
                Email = "john.doe@email.com",
                Phone = "1234567890",
                UpdatedBy = "admin",
                UpdatedDate = DateTime.UtcNow,
                Identifiers = new List<PractitionerIdentifierDto>
                {
                    new PractitionerIdentifierDto { ID = "1", AssigningAuthority = "Dermatology", TypeCode = "TEST123" }
                },
                Locations = new List<PractitionerLocationDto>
                {
                    new PractitionerLocationDto { ID = 1, Value = "New York" }
                },
                Organizations = new List<PractitionerOrganizationDto>
                {
                    new PractitionerOrganizationDto { ID = 1, Value = "Health Corp" }
                },
                Specialties = new List<PractitionerSpecialtyDto>
                {
                    new PractitionerSpecialtyDto { ID = 1, Value = "Cardiology" }
                }
            };

            // Act & Assert
            doctor.ID.Should().Be(1);
            doctor.ResourceID.Should().Be("DOC123");
            doctor.GivenName.Should().Be("John");
            doctor.FamilyName.Should().Be("Doe");
            doctor.MiddleName.Should().Be("A");
            doctor.Name.Should().Be("Dr. John Doe");
            doctor.Email.Should().Be("john.doe@email.com");
            doctor.Phone.Should().Be("1234567890");
            doctor.UpdatedBy.Should().Be("admin");
            doctor.UpdatedDate.Should().BeCloseTo(DateTime.UtcNow, TimeSpan.FromSeconds(1));

            doctor.Identifiers.Should().HaveCount(1);
            doctor.Identifiers[0].ID.Should().Be("1");
            doctor.Identifiers[0].AssigningAuthority.Should().Be("Dermatology");
            doctor.Identifiers[0].TypeCode.Should().Be("TEST123");

            doctor.Locations.Should().HaveCount(1);
            doctor.Locations[0].ID.Should().Be(1);
            doctor.Locations[0].Value.Should().Be("New York");

            doctor.Organizations.Should().HaveCount(1);
            doctor.Organizations[0].ID.Should().Be(1);
            doctor.Organizations[0].Value.Should().Be("Health Corp");

            doctor.Specialties.Should().HaveCount(1);
            doctor.Specialties[0].ID.Should().Be(1);
            doctor.Specialties[0].Value.Should().Be("Cardiology");
        }
    }
}
