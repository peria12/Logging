﻿using Aurora.AdministrationService.API.Models.RequestModels.CreateAdmin_FAQ;
using FluentAssertions;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Aurora.AdministrationService.Tests.API.Dto.Faq
{
    public class UpdateFaqRequestDtoTests
    {
        [Fact]
        public void UpdateAdminFAQRequestDTO_ShouldInitializeWithDefaultValues()
        {
            // Act
            var dto = new UpdateAdmin_FAQRequestDTO();

            // Assert
            dto.Id.Should().Be(0);
            dto.IsActive.Should().BeFalse();
        }

        [Fact]
        public void UpdateAdminFAQRequestDTO_ShouldSetAndGetValuesCorrectly()
        {
            // Arrange
            var dto = new UpdateAdmin_FAQRequestDTO
            {
                Id = 10,
                IsActive = true
            };

            // Assert
            dto.Id.Should().Be(10);
            dto.IsActive.Should().BeTrue();
        }
    }
}
