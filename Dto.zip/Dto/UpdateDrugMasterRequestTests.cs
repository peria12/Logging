﻿using System.ComponentModel.DataAnnotations;
using Aurora.AdministrationService.API.Models.Dto.DrugMasters;
using FluentAssertions;

namespace Aurora.AdministrationService.Tests.API.Dto
{
    public class UpdateDrugMasterRequestTests
    {
        [Fact]
        public void UpdateDrugMasterRequest_Should_SetPropertiesCorrectly()
        {
            // Arrange
            var expectedID = 1001L;
            var expectedResourceID = "RES12345";
            var expectedMasterType = "Medication";
            var expectedItemCode = "DRG001";
            var expectedItemDescription = "Pain Reliever";
            var expectedItemTypeCode = "ITC002";
            var expectedItemTypeDescription = "Tablet";
            var expectedMedicationCode = "MED123";
            var expectedMedicationDescription = "Ibuprofen 200mg";
            var expectedMedicationCategory = "NSAID";
            var expectedMedicationType = "Oral";
            var expectedStrength = "200mg";
            var expectedDrugForm = "Tablet";
            var expectedCaution = "Avoid alcohol";
            var expectedDosageUnit = "mg";
            var expectedDoseValue = 200.0m;
            var expectedFrequencyDesc = "Twice a day";
            var expectedFrequencyValue = 2.0m;
            var expectedDurationUnit = "Days";
            var expectedDurationValue = 5;
            var expectedRoute = "Oral";
            var expectedDrugFormGroup = "Painkillers";
            var expectedInstructions = "Take with food";
            var expectedIsSTATDrug = false;
            var expectedIsAlertRequired = false;
            var expectedIsPoisonDrug = false;
            var expectedIsPsychotropicDrug = false;
            var expectedIsDangerousDrug = false;
            var expectedIsAnesthesiaDrug = false;
            var expectedFacilityCode = "FAC987";
            var expectedBrandShare = "Generic";
            var expectedRecordVersion = new byte[] { 1, 2, 3, 4 };

            // Act
            var dto = new UpdateDrugMasterRequest
            {
                ID = expectedID,
                ResourceID = expectedResourceID,
                MasterType = expectedMasterType,
                ItemCode = expectedItemCode,
                ItemDescription = expectedItemDescription,
                ItemTypeCode = expectedItemTypeCode,
                ItemTypeDescription = expectedItemTypeDescription,
                MedicationCode = expectedMedicationCode,
                MedicationDescription = expectedMedicationDescription,
                MedicationCategory = expectedMedicationCategory,
                MedicationType = expectedMedicationType,
                Strength = expectedStrength,
                DrugForm = expectedDrugForm,
                Caution = expectedCaution,
                DosageUnit = expectedDosageUnit,
                DoseValue = expectedDoseValue,
                FrequencyDesc = expectedFrequencyDesc,
                FrequencyValue = expectedFrequencyValue,
                DurationUnit = expectedDurationUnit,
                DurationValue = expectedDurationValue,
                Route = expectedRoute,
                DrugFormGroup = expectedDrugFormGroup,
                Instructions = expectedInstructions,
                IsSTATDrug = expectedIsSTATDrug,
                IsAlertRequired = expectedIsAlertRequired,
                IsPoisonDrug = expectedIsPoisonDrug,
                IsPsychotropicDrug = expectedIsPsychotropicDrug,
                IsDangerousDrug = expectedIsDangerousDrug,
                IsAnesthesiaDrug = expectedIsAnesthesiaDrug,
                FacilityCode = expectedFacilityCode,
                BrandShare = expectedBrandShare,
                RecordVersion = expectedRecordVersion
            };

            // Assert
            dto.ID.Should().Be(expectedID);
            dto.ResourceID.Should().Be(expectedResourceID);
            dto.MasterType.Should().Be(expectedMasterType);
            dto.ItemCode.Should().Be(expectedItemCode);
            dto.ItemDescription.Should().Be(expectedItemDescription);
            dto.ItemTypeCode.Should().Be(expectedItemTypeCode);
            dto.ItemTypeDescription.Should().Be(expectedItemTypeDescription);
            dto.MedicationCode.Should().Be(expectedMedicationCode);
            dto.MedicationDescription.Should().Be(expectedMedicationDescription);
            dto.MedicationCategory.Should().Be(expectedMedicationCategory);
            dto.MedicationType.Should().Be(expectedMedicationType);
            dto.Strength.Should().Be(expectedStrength);
            dto.DrugForm.Should().Be(expectedDrugForm);
            dto.Caution.Should().Be(expectedCaution);
            dto.DosageUnit.Should().Be(expectedDosageUnit);
            dto.DoseValue.Should().Be(expectedDoseValue);
            dto.FrequencyDesc.Should().Be(expectedFrequencyDesc);
            dto.FrequencyValue.Should().Be(expectedFrequencyValue);
            dto.DurationUnit.Should().Be(expectedDurationUnit);
            dto.DurationValue.Should().Be(expectedDurationValue);
            dto.Route.Should().Be(expectedRoute);
            dto.DrugFormGroup.Should().Be(expectedDrugFormGroup);
            dto.Instructions.Should().Be(expectedInstructions);
            dto.IsSTATDrug.Should().Be(expectedIsSTATDrug);
            dto.IsAlertRequired.Should().Be(expectedIsAlertRequired);
            dto.IsPoisonDrug.Should().Be(expectedIsPoisonDrug);
            dto.IsPsychotropicDrug.Should().Be(expectedIsPsychotropicDrug);
            dto.IsDangerousDrug.Should().Be(expectedIsDangerousDrug);
            dto.IsAnesthesiaDrug.Should().Be(expectedIsAnesthesiaDrug);
            dto.FacilityCode.Should().Be(expectedFacilityCode);
            dto.BrandShare.Should().Be(expectedBrandShare);
            dto.RecordVersion.Should().BeEquivalentTo(expectedRecordVersion);
        }

        [Fact]
        public void UpdateDrugMasterRequest_RecordVersion_Should_Have_Timestamp_Attribute()
        {
            // Arrange & Act
            var propertyInfo = typeof(UpdateDrugMasterRequest).GetProperty(nameof(UpdateDrugMasterRequest.RecordVersion));
            var attributes = propertyInfo?.GetCustomAttributes(typeof(TimestampAttribute), false);

            // Assert
            (attributes?.Length > 0).Should().BeTrue("RecordVersion should have the [Timestamp] attribute.");
        }
    }
}