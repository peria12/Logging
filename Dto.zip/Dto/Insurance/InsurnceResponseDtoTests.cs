﻿using Aurora.AdministrationService.API.Models.ResponseModels.V1.AdminInsurance;
using FluentAssertions;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Aurora.AdministrationService.Tests.API.Dto.Insurance
{
    public class InsurnceResponseDtoTests
    {
        [Fact]
        public void InsuranceResponseDto_ShouldInitializeWithDefaultValues()
        {
            // Act
            var dto = new InsuranceResponseDto();

            // Assert
            dto.Id.Should().Be(0);
            dto.DebtorName.Should().Be(string.Empty);
            dto.Logo.Should().Be(string.Empty);
        }

        [Fact]
        public void InsuranceResponseDto_ShouldSetAndGetValuesCorrectly()
        {
            // Arrange
            var dto = new InsuranceResponseDto
            {
                Id = 123,
                DebtorName = "Insurance Company",
                Logo = "https://example.com/logo.png"
            };

            // Assert
            dto.Id.Should().Be(123);
            dto.DebtorName.Should().Be("Insurance Company");
            dto.Logo.Should().Be("https://example.com/logo.png");
        }
    }
}
