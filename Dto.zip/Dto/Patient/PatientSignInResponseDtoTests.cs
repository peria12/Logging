﻿using Aurora.AdministrationService.API.Models.Dto.Patients;
using FluentAssertions;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Aurora.AdministrationService.Tests.API.Dto.Patient
{
    public class PatientSignInResponseDtoTests
    {
        [Fact]
        public void PatientSignInResponseDto_ShouldInitializeCorrectly()
        {
            // Act
            var dto = new PatientSignInResponseDto
            {
                UniqueId = "UID12345",
                Token = "SampleToken",
                BirthOfDate = new DateTime(1990, 1, 1),
                Gender = "Male",
                Name = "John Doe",
                RetryAttempt = 2,
                LastFailedLoginAttempt = DateTime.UtcNow.AddMinutes(-30)
            };

            // Assert
            dto.UniqueId.Should().Be("UID12345");
            dto.Token.Should().Be("SampleToken");
            dto.BirthOfDate.Should().Be(new DateTime(1990, 1, 1));
            dto.Gender.Should().Be("Male");
            dto.Name.Should().Be("John Doe");
            dto.RetryAttempt.Should().Be(2);
            dto.LastFailedLoginAttempt.Should().BeCloseTo(DateTime.UtcNow.AddMinutes(-30), TimeSpan.FromSeconds(1));
        }

        [Fact]
        public void PatientSignInResponseDto_ShouldAllowNullValuesForOptionalProperties()
        {
            // Act
            var dto = new PatientSignInResponseDto
            {
                UniqueId = "UID12345",
                Token = "SampleToken",
                BirthOfDate = null,
                Gender = null,
                Name = null,
                RetryAttempt = null,
                LastFailedLoginAttempt = null
            };

            // Assert
            dto.BirthOfDate.Should().BeNull();
            dto.Gender.Should().BeNull();
            dto.Name.Should().BeNull();
            dto.RetryAttempt.Should().BeNull();
            dto.LastFailedLoginAttempt.Should().BeNull();
        }
    }
}
