﻿using Aurora.AdministrationService.API.Models.Dto.Users;
using FluentAssertions;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Aurora.AdministrationService.Tests.API.Dto.Users
{
    public class LoginSuccessResponseDtoTests
    {
        [Fact]
        public void LoginSuccessResponseDto_ShouldInitializeWithDefaultValues()
        {
            // Act
            var dto = new LoginSuccessResponseDto();

            // Assert
            dto.Id.Should().Be(0L);
            dto.UniqueId.Should().BeEmpty();
            dto.UserName.Should().BeEmpty();
            dto.UserType.Should().BeEmpty();
            dto.BirthOfDate.Should().BeNull();
            dto.Gender.Should().BeNull();
            dto.Name.Should().BeEmpty();
            dto.Token.Should().BeEmpty();
        }

        [Fact]
        public void LoginSuccessResponseDto_ShouldSetAndGetValuesCorrectly()
        {
            // Arrange
            var dto = new LoginSuccessResponseDto
            {
                Id = 789,
                UniqueId = "UID12345",
                UserName = "TestUser",
                UserType = "Admin",
                BirthOfDate = new DateTime(1995, 5, 10),
                Gender = "Male",
                Name = "John Doe",
                Token = "AuthToken789"
            };

            // Assert
            dto.Id.Should().Be(789);
            dto.UniqueId.Should().Be("UID12345");
            dto.UserName.Should().Be("TestUser");
            dto.UserType.Should().Be("Admin");
            dto.BirthOfDate.Should().Be(new DateTime(1995, 5, 10));
            dto.Gender.Should().Be("Male");
            dto.Name.Should().Be("John Doe");
            dto.Token.Should().Be("AuthToken789");
        }
    }
}
