﻿using Aurora.AdministrationService.API.Models.Dto.Users;
using FluentAssertions;

namespace Aurora.AdministrationService.Tests.API.Dto.Users
{
    public class UserDtoTests
    {
        [Fact]
        public void UserDto_Initialization()
        {
            //Arrange
            var userUserName = string.Empty;
            var userStatus = true;
            var userGender = string.Empty;
            var userBirthDate = DateTime.UtcNow;
            var userManagingOrganization = string.Empty;
            var userSource = string.Empty;
            var userIsTempAccount = true;
            var userUserType = string.Empty;
            var userPasscode = string.Empty;
            var userLanguage = 0;
            var userNotificationsEnabled = true;
            var userBioAuthenticationEnabled = true;
            var userSOSButtonEnabled = true;
            var userAppVersion = string.Empty;
            var userPassword = string.Empty;
            var userIsMarketingConsentEnable = true;
            var userSalt = string.Empty;
            var userLocationEnable = true;
            //Act

            var userDto = new UserDto(
                userUserName,
                userStatus,
                userGender,
                userBirthDate,
                userManagingOrganization,
                userSource,
                userIsTempAccount,
                userUserType,
                userPasscode,
                userLanguage,
                userNotificationsEnabled,
                userBioAuthenticationEnabled,
                userSOSButtonEnabled,
                userAppVersion,
                userPassword,
                userIsMarketingConsentEnable,
                userSalt,
                userLocationEnable
            );

            //Assert
            Assert.Equal(userUserName, userDto.UserName);
            Assert.Equal(userStatus, userDto.Status);
            Assert.Equal(userGender, userDto.Gender);
            Assert.Equal(userBirthDate, userDto.BirthDate);
            Assert.Equal(userManagingOrganization, userDto.ManagingOrganization);
            Assert.Equal(userSource, userDto.Source);
            Assert.Equal(userIsTempAccount, userDto.IsTempAccount);
            Assert.Equal(userUserType, userDto.UserType);
            Assert.Equal(userPasscode, userDto.Passcode);
            Assert.Equal(userLanguage, userDto.Language);
            Assert.Equal(userNotificationsEnabled, userDto.NotificationsEnabled);
            Assert.Equal(userBioAuthenticationEnabled, userDto.BioAuthenticationEnabled);
            Assert.Equal(userSOSButtonEnabled, userDto.SOSButtonEnabled);
            Assert.Equal(userAppVersion, userDto.AppVersion);
            Assert.Equal(userPassword, userDto.Password);
            Assert.Equal(userIsMarketingConsentEnable, userDto.IsMarketingConsentEnable);
            Assert.Equal(userSalt, userDto.Salt);
            Assert.Equal(userLocationEnable, userDto.LocationEnable);
        }


        [Fact]
        public void UserVerificationRequest_ShouldInitializeWithNullValues()
        {
            // Act
            var request = new UserVerificationRequest();

            // Assert
            request.UserId.Should().BeNull();
            request.PassportNo.Should().BeNull();
        }

        [Fact]
        public void UserVerificationRequest_ShouldSetAndGetValuesCorrectly()
        {
            // Arrange
            var request = new UserVerificationRequest
            {
                UserId = "User123",
                PassportNo = "P12345678"
            };

            // Assert
            request.UserId.Should().Be("User123");
            request.PassportNo.Should().Be("P12345678");
        }
    }
}
