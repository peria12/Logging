﻿using Aurora.AdministrationService.API.Models.Dto.Users;
using FluentAssertions;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Aurora.AdministrationService.Tests.API.Dto.Users
{
    public class UserPersonalInformationDtoTests
    {
        [Fact]
        public void UserPersonalInformation_ShouldInitializeWithDefaultValues()
        {
            // Act
            var dto = new UserPersonalInformation();

            // Assert
            dto.Id.Should().Be(0);
            dto.UniqueId.Should().BeNull();
            dto.FullName.Should().BeNull();
            dto.Salutation.Should().BeNull();
            dto.PreferredName.Should().BeNull();
            dto.CountryCode.Should().BeNull();
            dto.MobileNumber.Should().BeNull();
            dto.EmailId.Should().BeNull();
            dto.DOB.Should().BeNull();
            dto.Gender.Should().BeNull();
            dto.ProfileImage.Should().BeNull();
            dto.Passcode.Should().BeNull();
            dto.NotificationEnabled.Should().BeNull();
            dto.Language.Should().BeNull();
            dto.SosbuttonEnabled.Should().BeNull();
        }

        [Fact]
        public void UserPersonalInformation_ShouldSetAndGetValuesCorrectly()
        {
            // Arrange
            var dto = new UserPersonalInformation
            {
                Id = 101,
                UniqueId = "UID12345",
                FullName = "John Doe",
                Salutation = "Mr.",
                PreferredName = "Johnny",
                CountryCode = "+1",
                MobileNumber = "1234567890",
                EmailId = "john.doe@example.com",
                DOB = "1990-05-10",
                Gender = "Male",
                ProfileImage = "https://example.com/profile.jpg",
                Passcode = "secure123",
                NotificationEnabled = true,
                Language = "English",
                SosbuttonEnabled = false
            };

            // Assert
            dto.Id.Should().Be(101);
            dto.UniqueId.Should().Be("UID12345");
            dto.FullName.Should().Be("John Doe");
            dto.Salutation.Should().Be("Mr.");
            dto.PreferredName.Should().Be("Johnny");
            dto.CountryCode.Should().Be("+1");
            dto.MobileNumber.Should().Be("1234567890");
            dto.EmailId.Should().Be("john.doe@example.com");
            dto.DOB.Should().Be("1990-05-10");
            dto.Gender.Should().Be("Male");
            dto.ProfileImage.Should().Be("https://example.com/profile.jpg");
            dto.Passcode.Should().Be("secure123");
            dto.NotificationEnabled.Should().BeTrue();
            dto.Language.Should().Be("English");
            dto.SosbuttonEnabled.Should().BeFalse();
        }
    }
}
