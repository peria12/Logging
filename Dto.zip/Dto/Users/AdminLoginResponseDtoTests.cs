﻿using Aurora.AdministrationService.API.Models.Dto.Users;
using FluentAssertions;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Aurora.AdministrationService.Tests.API.Dto.Users
{
    public class AdminLoginSuccessResponseDtoTests
    {
        [Fact]
        public void AdminLoginSuccessResponseDto_ShouldInitializeWithDefaultValues()
        {
            // Act
            var dto = new AdminLoginSuccessResponseDto();

            // Assert
            dto.Id.Should().Be(0L);
            dto.UserName.Should().BeEmpty();
            dto.UserType.Should().BeEmpty();
            dto.Token.Should().BeEmpty();
        }

        [Fact]
        public void AdminLoginSuccessResponseDto_ShouldSetAndGetValuesCorrectly()
        {
            // Arrange
            var dto = new AdminLoginSuccessResponseDto
            {
                Id = 123,
                UserName = "AdminUser",
                UserType = "SuperAdmin",
                Token = "sampleToken123"
            };

            // Assert
            dto.Id.Should().Be(123);
            dto.UserName.Should().Be("AdminUser");
            dto.UserType.Should().Be("SuperAdmin");
            dto.Token.Should().Be("sampleToken123");
        }
    }
}
