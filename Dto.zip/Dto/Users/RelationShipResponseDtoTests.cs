﻿using Aurora.AdministrationService.API.Models.Dto.Users;
using FluentAssertions;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Aurora.AdministrationService.Tests.API.Dto.Users
{
    public class RelationShipResponseDtoTests
    {
        [Fact]
        public void RelationShipsResponseDto_ShouldInitializeWithRequiredProperty()
        {
            // Act
            var dto = new RelationShipsResponseDto { RelationShips = new string[] { "Parent", "Sibling" } };

            // Assert
            dto.RelationShips.Should().NotBeNull().And.HaveCount(2);
            dto.RelationShips.Should().Contain(new[] { "Parent", "Sibling" });
        }

        [Fact]
        public void RelationShipsResponseDto_ShouldAllowEmptyArray()
        {
            // Act
            var dto = new RelationShipsResponseDto { RelationShips = new string[] { } };

            // Assert
            dto.RelationShips.Should().NotBeNull().And.BeEmpty();
        }
    }
}
