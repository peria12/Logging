﻿using Aurora.AdministrationService.API.Models.Dto.Users;
using FluentAssertions;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Aurora.AdministrationService.Tests.API.Dto.Users
{
    public class SalutationResponseDtoTests
    {
        [Fact]
        public void SalutationsResponseDto_ShouldInitializeWithRequiredProperty()
        {
            // Act
            var dto = new SalutationsResponseDto { Salutations = new string[] { "Mr.", "Ms." } };

            // Assert
            dto.Salutations.Should().NotBeNull().And.HaveCount(2);
            dto.Salutations.Should().Contain(new[] { "Mr.", "Ms." });
        }

        [Fact]
        public void SalutationsResponseDto_ShouldAllowEmptyArray()
        {
            // Act
            var dto = new SalutationsResponseDto { Salutations = new string[] { } };

            // Assert
            dto.Salutations.Should().NotBeNull().And.BeEmpty();
        }
    }
}
