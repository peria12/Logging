﻿using Aurora.AdministrationService.API.Models.Dto.Users;
using FluentAssertions;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Aurora.AdministrationService.Tests.API.Dto.Users
{
    public class AdminSignInResponseDtoTests
    {
        [Fact]
        public void AdminSignInResponseDto_ShouldInitializeWithDefaultValues()
        {
            // Act
            var dto = new AdminSignInResponseDto();

            // Assert
            dto.Id.Should().Be(0L);
            dto.UserName.Should().BeEmpty();
            dto.UserType.Should().BeEmpty();
            dto.Password.Should().BeEmpty();
            dto.Token.Should().BeEmpty();
        }

        [Fact]
        public void AdminSignInResponseDto_ShouldSetAndGetValuesCorrectly()
        {
            // Arrange
            var dto = new AdminSignInResponseDto
            {
                Id = 456,
                UserName = "AdminUser",
                UserType = "Admin",
                Password = "SecurePass123",
                Token = "AuthToken456"
            };

            // Assert
            dto.Id.Should().Be(456);
            dto.UserName.Should().Be("AdminUser");
            dto.UserType.Should().Be("Admin");
            dto.Password.Should().Be("SecurePass123");
            dto.Token.Should().Be("AuthToken456");
        }

        [Fact]
        public void UserSignInResponseDto_ShouldInitializeWithDefaultValues()
        {
            // Act
            var dto = new UserSignInResponseDto();

            // Assert
            dto.Id.Should().Be(0L);
            dto.UniqueId.Should().BeEmpty();
            dto.UserName.Should().BeEmpty();
            dto.UserType.Should().BeEmpty();
            dto.Password.Should().BeEmpty();
            dto.BirthOfDate.Should().BeNull();
            dto.Gender.Should().BeNull();
            dto.Name.Should().BeEmpty();
        }

        [Fact]
        public void UserSignInResponseDto_ShouldSetAndGetValuesCorrectly()
        {
            // Arrange
            var dto = new UserSignInResponseDto
            {
                Id = 555,
                UniqueId = "UID78910",
                UserName = "TestUser",
                UserType = "User",
                Password = "SecurePassword123",
                BirthOfDate = new DateTime(2000, 1, 1),
                Gender = "Female",
                Name = "Jane Doe"
            };

            // Assert
            dto.Id.Should().Be(555);
            dto.UniqueId.Should().Be("UID78910");
            dto.UserName.Should().Be("TestUser");
            dto.UserType.Should().Be("User");
            dto.Password.Should().Be("SecurePassword123");
            dto.BirthOfDate.Should().Be(new DateTime(2000, 1, 1));
            dto.Gender.Should().Be("Female");
            dto.Name.Should().Be("Jane Doe");
        }

    }
}
