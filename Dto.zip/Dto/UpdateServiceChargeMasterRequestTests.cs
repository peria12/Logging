﻿using Aurora.AdministrationService.API.Models.Dto.ServiceChargeMasters;
using FluentAssertions;

namespace Aurora.AdministrationService.Tests.API.Dto.ServiceChargeMasters
{
    public class UpdateServiceChargeMasterRequestTests
    {
        [Fact]
        public void UpdateServiceChargeMasterRequest_Should_SetPropertiesCorrectly()
        {
            // Arrange
            var expectedId = 1001L;
            var expectedMasterType = "LabTest";
            var expectedItemCode = "ITM001";
            var expectedItemDescription = "Blood Test";
            var expectedItemTypeCode = "ITC001";
            var expectedItemTypeDescription = "Lab Item";
            var expectedTestCode = "TST001";
            var expectedTestDescription = "Complete Blood Count";
            var expectedServiceType = "Pathology";
            var expectedCategory = "Diagnostic";
            var expectedDepartment = "Hematology";
            var expectedTurnAroundTime = 24;
            var expectedRestricted = true;
            var expectedTestMethodAvailable = "PCR";
            var expectedFacilityCode = "FAC123";
            var expectedRecordVersion = new byte[] { 1, 2, 3, 4 };

            // Act
            var dto = new UpdateServiceChargeMasterRequest
            {
                ID = expectedId,
                MasterType = expectedMasterType,
                ItemCode = expectedItemCode,
                ItemDescription = expectedItemDescription,
                ItemTypeCode = expectedItemTypeCode,
                ItemTypeDescription = expectedItemTypeDescription,
                TestCode = expectedTestCode,
                TestDescription = expectedTestDescription,
                ServiceType = expectedServiceType,
                Category = expectedCategory,
                Department = expectedDepartment,
                TurnAroundTime = expectedTurnAroundTime,
                Restricted = expectedRestricted,
                TestMethodAvailable = expectedTestMethodAvailable,
                FacilityCode = expectedFacilityCode,
                RecordVersion = expectedRecordVersion
            };

            // Assert
            dto.ID.Should().Be(expectedId);
            dto.MasterType.Should().Be(expectedMasterType);
            dto.ItemCode.Should().Be(expectedItemCode);
            dto.ItemDescription.Should().Be(expectedItemDescription);
            dto.ItemTypeCode.Should().Be(expectedItemTypeCode);
            dto.ItemTypeDescription.Should().Be(expectedItemTypeDescription);
            dto.TestCode.Should().Be(expectedTestCode);
            dto.TestDescription.Should().Be(expectedTestDescription);
            dto.ServiceType.Should().Be(expectedServiceType);
            dto.Category.Should().Be(expectedCategory);
            dto.Department.Should().Be(expectedDepartment);
            dto.TurnAroundTime.Should().Be(expectedTurnAroundTime);
            dto.Restricted.Should().Be(expectedRestricted);
            dto.TestMethodAvailable.Should().Be(expectedTestMethodAvailable);
            dto.FacilityCode.Should().Be(expectedFacilityCode);
            dto.RecordVersion.Should().BeEquivalentTo(expectedRecordVersion);
        }

        [Fact]
        public void UpdateServiceChargeMasterRequest_Should_Have_Required_Properties()
        {
            // Arrange & Act
            var properties = typeof(UpdateServiceChargeMasterRequest).GetProperties();

            // Assert
            properties.Should().Contain(p => p.Name == nameof(UpdateServiceChargeMasterRequest.ItemCode) && p.CanWrite,
                "ItemCode should be a required writable property.");

            properties.Should().Contain(p => p.Name == nameof(UpdateServiceChargeMasterRequest.TestCode) && p.CanWrite,
                "TestCode should be a required writable property.");

            properties.Should().Contain(p => p.Name == nameof(UpdateServiceChargeMasterRequest.RecordVersion) && p.CanWrite,
                "RecordVersion should be a required writable property.");
        }
    }
}
