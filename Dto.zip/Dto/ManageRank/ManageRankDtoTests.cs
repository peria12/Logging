﻿using Aurora.AdministrationService.API.Models.Dto.Marketing.DoctorProfile.Manage;
using FluentAssertions;
namespace Aurora.AdministrationService.Tests.API.Dto.ManageRank
{
    public class ManageRankDtoTests
    {
        [Fact]
        public void UpdateRankDTO_ShouldSetAndGetValuesCorrectly()
        {
            // Arrange
            var dto = new ManageRankDto
            {
                Id = 10,
                Rank = "1",
                RecordVersion = new byte[8] { byte.MinValue, byte.MinValue, byte.MinValue, byte.MinValue, byte.MinValue, byte.MinValue, byte.MinValue, byte.MaxValue }
            };

            // Assert
            dto.Id.Should().Be(10);
            dto.Rank.Should().Be("1");
        }
    }
}
