﻿using Aurora.AdministrationService.API.Models.Dto.InsurancePanelLocations;
using Aurora.AdministrationService.API.Models.Dto.InsurancePanels;
using Aurora.AdministrationService.CrossCutting.Constants;
using FluentAssertions;
using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Aurora.AdministrationService.Tests.API.Dto.InsurancePanels
{
    public class InsurancePanelLocationTest
    {
       
        [Fact]
        public void InsurancePanelLocationDto_ShouldSetAndGetValuesCorrectly()
        {
            // Arrange
            var dto = new InsurancePanelLocationDto
            {
                Id = 1,
                InsurancePanelID = 12345,
                LocationID = "LOC001"
            };

            // Assert
            dto.Id.Should().Be(1);
            dto.InsurancePanelID.Should().Be(12345);
            dto.LocationID.Should().Be("LOC001");
        }

        [Fact]
        public void InsurancePanelLocationDto_Constructor_ShouldSetValuesCorrectly()
        {
            // Act
            var dto = new InsurancePanelLocationDto(12345, "LOC001") { InsurancePanelID = 12345 };

            // Assert
            dto.InsurancePanelID.Should().Be(12345);
            dto.LocationID.Should().Be("LOC001");
        }

        

        [Fact]
        public void InsurancePanelDto_ParameterizedConstructor_ShouldSetValuesCorrectly()
        {
            // Act
            var dto = new InsurancePanelDto ("RES123", "Debtor 1", true) { ResourceID = "RES123", DebtorName= "Debtor 1", Status= true };

            // Assert
            dto.ResourceID.Should().Be("RES123");
            dto.DebtorName.Should().Be("Debtor 1");
            dto.Status.Should().BeTrue();
        }

        
        [Fact]
        public void InsurancePanelDto_MaxLengthValidation_ShouldFailForExceedingLength()
        {
            // Arrange
            var dto = new InsurancePanelDto
            {
                Status= true,
                ResourceID = new string('A', 51), // Exceeds max length
                DebtorName = new string('B', 51) // Exceeds max length
            };

            var validationContext = new ValidationContext(dto);
            var validationResults = new List<ValidationResult>();

            // Act
            var isValid = Validator.TryValidateObject(dto, validationContext, validationResults, true);

            // Assert
            isValid.Should().BeFalse();
            validationResults.Any(v => v.ErrorMessage == AppConstants.Maximum50Character).Should().BeTrue();
        }



    }
}
