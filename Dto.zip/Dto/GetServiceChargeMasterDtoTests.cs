﻿using Aurora.AdministrationService.API.Models.Dto.ServiceChargeMasters;
using FluentAssertions;

namespace Aurora.AdministrationService.Tests.Dto
{
    public class GetServiceChargeMasterDtoTests
    {
        [Fact]
        public void GetServiceChargeMasterDto_ShouldInitializeWithDefaultValues()
        {
            // Act
            var dto = new GetServiceChargeMasterDto
            {
                ID = 1,
                MasterType = "Type1",
                ItemCode = "Item123",
                ItemDescription = "Test Item",
                ItemTypeCode = "TypeCode1",
                ItemTypeDescription = "Type Desc",
                TestCode = "Test456",
                TestDescription = "Test Description",
                ServiceType = "Lab",
                Category = "Blood Test",
                Department = "Pathology",
                TurnAroundTime = 24,
                Restricted = true,
                TestMethodAvailable = "PCR",
                FacilityCode = "FAC001",
                IsDeleted = false,
                CreatedBy = "Admin",
                CreatedDate = DateTime.UtcNow,
                UpdatedBy = "Editor",
                UpdatedDate = DateTime.UtcNow.AddHours(1)
            };

            // Assert
            dto.ID.Should().Be(1);
            dto.MasterType.Should().Be("Type1");
            dto.ItemCode.Should().Be("Item123");
            dto.ItemDescription.Should().Be("Test Item");
            dto.ItemTypeCode.Should().Be("TypeCode1");
            dto.ItemTypeDescription.Should().Be("Type Desc");
            dto.TestCode.Should().Be("Test456");
            dto.TestDescription.Should().Be("Test Description");
            dto.ServiceType.Should().Be("Lab");
            dto.Category.Should().Be("Blood Test");
            dto.Department.Should().Be("Pathology");
            dto.TurnAroundTime.Should().Be(24);
            dto.Restricted.Should().BeTrue();
            dto.TestMethodAvailable.Should().Be("PCR");
            dto.FacilityCode.Should().Be("FAC001");
            dto.IsDeleted.Should().BeFalse();
            dto.CreatedBy.Should().Be("Admin");
            dto.CreatedDate.Should().BeCloseTo(DateTime.UtcNow, TimeSpan.FromSeconds(1));
            dto.UpdatedBy.Should().Be("Editor");
            dto.UpdatedDate.Should().BeCloseTo(DateTime.UtcNow.AddHours(1), TimeSpan.FromSeconds(1));
            dto.RecordVersion.Should().NotBeNull().And.BeEmpty();
        }
    }
}
