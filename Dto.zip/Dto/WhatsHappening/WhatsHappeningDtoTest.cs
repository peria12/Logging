﻿using Aurora.AdministrationService.API.Models.ResponseModels.WhatsHappening;
using FluentAssertions;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Aurora.AdministrationService.Tests.API.Dto.WhatsHappening
{
    public class WhatsHappeningDtoTest
    {
        [Fact]
        public void WhatsHappeningDto_ShouldInitializeCorrectly()
        {
            // Act
            var dto = new WhatsHappeningDTO
            {
                Id = 1,
                Name = "Event Name",
                Description = "Event Description",
                ImageUrl = "https://example.com/image.jpg",
                Url = "https://example.com",
                Category = "Health",
                StartDate = DateTime.UtcNow,
                EndDate = DateTime.UtcNow.AddDays(5),
                IsActive = true,
                DateCreated = DateTime.UtcNow,
                CreatedBy = 123,
                LastModifiedBy = 456,
                LastModifiedDate = DateTime.UtcNow.AddDays(-1),
                OrganizationId = 789,
                OrganizationName = "Example Org"
            };

            // Assert
            dto.Id.Should().Be(1);
            dto.Name.Should().Be("Event Name");
            dto.Description.Should().Be("Event Description");
            dto.ImageUrl.Should().Be("https://example.com/image.jpg");
            dto.Url.Should().Be("https://example.com");
            dto.Category.Should().Be("Health");
            dto.IsActive.Should().BeTrue();
            dto.StartDate.Should().BeCloseTo(DateTime.UtcNow, TimeSpan.FromSeconds(1));
            dto.EndDate.Should().BeCloseTo(DateTime.UtcNow.AddDays(5), TimeSpan.FromSeconds(1));
            dto.DateCreated.Should().BeCloseTo(DateTime.UtcNow, TimeSpan.FromSeconds(1));
            dto.CreatedBy.Should().Be(123);
            dto.LastModifiedBy.Should().Be(456);
            dto.LastModifiedDate.Should().BeCloseTo(DateTime.UtcNow.AddDays(-1), TimeSpan.FromSeconds(1));
            dto.OrganizationId.Should().Be(789);
            dto.OrganizationName.Should().Be("Example Org");
        }

        [Fact]
        public void WhatsHappeningDto_ShouldAllowNullablePropertiesToBeNull()
        {
            // Act
            var dto = new WhatsHappeningDTO
            {
                Id = 1,
                Name = "Event Name",
                Description = "Event Description",
                ImageUrl = null,
                Url = null,
                Category = "Health",
                StartDate = DateTime.UtcNow,
                EndDate = DateTime.UtcNow.AddDays(5),
                IsActive = true,
                DateCreated = DateTime.UtcNow,
                CreatedBy = null,
                LastModifiedBy = null,
                LastModifiedDate = null,
                OrganizationId = 789,
                OrganizationName = null
            };

            // Assert
            dto.ImageUrl.Should().BeNull();
            dto.Url.Should().BeNull();
            dto.CreatedBy.Should().BeNull();
            dto.LastModifiedBy.Should().BeNull();
            dto.LastModifiedDate.Should().BeNull();
            dto.OrganizationName.Should().BeNull();
        }
    }
}
