﻿using Aurora.AdministrationService.API.Models.ResponseModels.WhatsHappening;
using FluentAssertions;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Aurora.AdministrationService.Tests.API.Dto.WhatsHappening
{
    public class WhatsHappeningDetailDtoTests
    {
        [Fact]
        public void WhatsHappeningDetailDto_ShouldInitializeCorrectly()
        {
            // Act
            var dto = new WhatsHappeningDetailDto
            {
                Id = 1,
                Title = "Event Name",
                Description = "Event Description",
                ImageUrl = "https://example.com/image.jpg",
                Url = "https://example.com",
                CategoryId = 2,
                Category = "Pack",
                StartDate = DateTime.UtcNow,
                EndDate = DateTime.UtcNow.AddDays(5),
                Status = true,
                LocationId = 100,
                LocationName = "Main Hall",
                RecordVersion = new byte[] { 1, 2, 3 }
            };

            // Assert
            dto.Id.Should().Be(1);
            dto.Title.Should().Be("Event Name");
            dto.Description.Should().Be("Event Description");
            dto.ImageUrl.Should().Be("https://example.com/image.jpg");
            dto.Url.Should().Be("https://example.com");
            dto.CategoryId.Should().Be(2);
            dto.Category.Should().Be("Pack");
            dto.Status.Should().BeTrue();
            dto.StartDate.Should().BeCloseTo(DateTime.UtcNow, TimeSpan.FromSeconds(1));
            dto.EndDate.Should().BeCloseTo(DateTime.UtcNow.AddDays(5), TimeSpan.FromSeconds(1));
            dto.LocationId.Should().Be(100);
            dto.LocationName.Should().Be("Main Hall");
            dto.RecordVersion.Should().NotBeNull().And.HaveCount(3);
        }

        [Fact]
        public void WhatsHappeningDetailDto_ShouldAllowNullablePropertiesToBeNull()
        {
            // Act
            var dto = new WhatsHappeningDetailDto
            {
                Id = 1,
                Title = "Event Name",
                Description = "Event Description",
                ImageUrl = null,
                Url = null,
                CategoryId = 2,
                Category = "Pack",
                StartDate = DateTime.UtcNow,
                EndDate = DateTime.UtcNow.AddDays(5),
                Status = true,
                LocationId = 100,
                LocationName = null,
                RecordVersion = null
            };

            // Assert
            dto.ImageUrl.Should().BeNull();
            dto.Url.Should().BeNull();
            dto.LocationName.Should().BeNull();
            dto.RecordVersion.Should().BeNull();
        }
    }
}
