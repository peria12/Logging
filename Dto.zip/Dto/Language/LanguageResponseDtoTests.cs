﻿using Aurora.AdministrationService.API.Models.ResponseModels.V1.AdminDoctor;
using FluentAssertions;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Aurora.AdministrationService.Tests.API.Dto.Language
{
    public class LanguageResponseDtoTests
    {
        [Fact]
        public void LanguageResponseDto_ShouldInitializeWithDefaultValues()
        {
            // Act
            var dto = new LanguageResponseDto();

            // Assert
            dto.Language.Should().BeNull();
            dto.IsDeleted.Should().BeFalse();
        }

        [Fact]
        public void LanguageResponseDto_ShouldSetAndGetValuesCorrectly()
        {
            // Arrange
            var dto = new LanguageResponseDto
            {
                Language = "English",
                IsDeleted = false
            };

            // Assert
            dto.Language.Should().Be("English");
            dto.IsDeleted.Should().Be(false);
        }
    }
}
