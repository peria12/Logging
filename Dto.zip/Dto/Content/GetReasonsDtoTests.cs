﻿using Aurora.AdministrationService.API.Models.Dto.Content;
using Aurora.AdministrationService.API.Models.ResponseModels.V1.AdminInsurance;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Aurora.AdministrationService.Tests.API.Dto.ContentDto
{
    public class GetReasonsDtoTests
    {
        [Fact]
        public void MyClass_Properties_SetAndGet()
        {
            // Arrange
            var expectedBytes1 = new byte[] { 1, 2, 3 };
            var expectedBytes2 = new byte[] { 4, 5, 6 };
            var myObject = new GetReasonsDto
            {
                ContentID = 789,
                ResonType = new List<string> { "Reason 1", "Reason 2" },
                RecordVersionReason = new List<byte[]> { expectedBytes1, expectedBytes2 },
            };            
            long contentIdValue = 456;
            List<string> resonTypeValue = new List<string> { "TestReasion1", "Reason 2" };            

            // Act          
            myObject.ContentID = contentIdValue;
            myObject.ResonType = resonTypeValue;         

            // Assert           
            Assert.Equal(contentIdValue, myObject.ContentID);
            Assert.Equal(resonTypeValue, myObject.ResonType);        
        }      
    }
}
