﻿using Aurora.AdministrationService.API.Models.Dto.Content;

namespace Aurora.AdministrationService.Tests.API.Dto.Content
{
   public class ContentSearchResponseTests
    {
        [Fact]
        public void MyClass_DefaultValues_ShouldBeCorrect()
        {
            // Arrange
            var myObject = new ContentSearchResponse
            {
                Module = "Appionment",
                PlatformIDs = new List<string> { "Patient"},
                Id=1,
                Header="Header",
                UpdatedBy="admin",
                UpdatedDate = Convert.ToDateTime("2025-03-30T12:44:32.1943553Z")

            };
            string moduleTypeValue = "Appionment";
            List<string> PlatformTypeValue = new List<string> { "Patient" };
            string heaertext = "HEader";
            string updatedBy = "Admin";
            DateTime UpdatedDate = Convert.ToDateTime("2025-03-30T12:44:32.1943553Z");


            //Act
            myObject.Module = moduleTypeValue;
            myObject.PlatformIDs = PlatformTypeValue;
            myObject.Header = heaertext;
            myObject.UpdatedBy= updatedBy;
            myObject.UpdatedDate = UpdatedDate;

            //Assert
            Assert.Equal(moduleTypeValue, myObject.Module);
            Assert.Equal(PlatformTypeValue, myObject.PlatformIDs);
            Assert.Equal(updatedBy, myObject.UpdatedBy);
        }
    }
}
