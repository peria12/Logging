﻿using Aurora.AdministrationService.API.Models.Dto.Content;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Aurora.AdministrationService.Tests.API.Dto.ContentDto
{
  public  class GetReasonsDetailDtoTests
    {
        //[Fact]
        //public void MyClass_Properties_SetAndGet()
        //{
        //    // Arrange
        //    var myObject = new GetReasonsDetailDto
        //    {
        //        ContentID = 789,
        //        ResonType = new List<string> { "Reason 1", "Reason 2" },

        //    };
        //    long contentIdValue = 456;
        //    List<string> resonTypeValue = new List<string> { "TestReasion1", "TestReason2" };

        //    // Act          
        //    myObject.ContentID = contentIdValue;
        //    myObject.ResonType = resonTypeValue;

        //    // Assert           
        //    Assert.Equal(contentIdValue, myObject.ContentID);
        //    Assert.Equal(resonTypeValue, myObject.ResonType);
        //}
    }
}
