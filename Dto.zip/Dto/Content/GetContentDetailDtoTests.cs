﻿using Aurora.AdministrationService.API.Models.Dto.Content;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Aurora.AdministrationService.Tests.API.Dto.ContentDto
{
    public class GetContentDetailDtoTests
    {
        //[Fact]
        //public void MyClass_DefaultValues_ShouldBeCorrect()
        //{
        //    // Arrange
        //    var expectedBytes1 = new byte[] { 1, 2, 3 };
        //    var expectedBytes2 = new byte[] { 4, 5, 6 };
        //    var myObject = new GetContentDetailDto
        //    {
        //        ContentID = 1,
        //        IsDeleted = false,
        //        Status = true,
        //        Header = "Test",
        //        Module = "Appionment",
        //        PlatformsID = "patientapp",
        //        Id = 1,           

        //        RecordVersion = new byte[8] { byte.MinValue, byte.MinValue, byte.MinValue, byte.MinValue, byte.MinValue, byte.MinValue, byte.MinValue, byte.MaxValue },
        //        RecordVersionReason = new List<byte[]> { expectedBytes1, expectedBytes2 },
        //        ResonType = new List<string> { "Reason 1", "Reason 2" }
        //    };
        //    long idValue = 1;
        //    long contentIdValue = 1;
        //    List <string> resonTypeValue = new List<string>{ "TestReasion1", "Reason 2" };
        //    string moduleTypeValue = "Appionment";
        //    string PlatformTypeValue = "Patient";
        //    string HeaderTypeValue = "HeaderTest";
        //    bool isDeletedValue = false;
        //    bool starus = false;
        //    byte[] recordVersionValue = { 0x01, 0x02, 0x03 };

        //    // Act
        //    myObject.Id = idValue;
        //    myObject.ContentID = contentIdValue;
        //    myObject.ResonType = resonTypeValue;
        //    myObject.Module = moduleTypeValue;
        //    myObject.PlatformsID = PlatformTypeValue;
        //    myObject.RecordVersion = recordVersionValue;
        //    myObject.Header = HeaderTypeValue;
        //    myObject.IsDeleted = isDeletedValue;
        //    myObject.Status = starus;

        //    // Assert
        //    Assert.Equal(1, myObject.Id);
        //    Assert.Equal(1, myObject.ContentID);
        //    Assert.Equal(resonTypeValue, myObject.ResonType);
        //    Assert.Equal(recordVersionValue, myObject.RecordVersion);
        //    Assert.Equal(moduleTypeValue, myObject.Module);
        //    Assert.Equal(PlatformTypeValue, myObject.PlatformsID);
        //    Assert.Equal(HeaderTypeValue, myObject.Header);
        //    Assert.False(myObject.Status); // Required bool is false by default if not set
        //    Assert.False(myObject.IsDeleted);
        //}
    }
}
