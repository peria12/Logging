﻿using Aurora.AdministrationService.API.Models.Dto.Content;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Aurora.AdministrationService.Tests.API.Dto.Content
{
   public class ContentSearchRequestTests
    {
        [Fact]
        public void MyClass_DefaultValues_ShouldBeCorrect()
        {
            // Arrange
            var myObject = new ContentSearchRequest
            {
                SelectedModule = "Appionment",
                SelectedPlatformsID = "Patient"
            };
            string moduleTypeValue = "Appionment";
            string PlatformTypeValue = "Patient";

            myObject.SelectedModule = moduleTypeValue;
            myObject.SelectedPlatformsID = PlatformTypeValue;

            //Assert
            Assert.Equal(moduleTypeValue, myObject.SelectedModule);
            Assert.Equal(PlatformTypeValue, myObject.SelectedPlatformsID);
        }
    }
}
