﻿using Aurora.AdministrationService.API.Models.Dto.Content;

namespace Aurora.AdministrationService.Tests.API.Dto.ContentDto
{
    public class UpdateContentRequestDtoTests
    {
        [Fact]
        public void Should_Create_Valid_UpdateContentRequestDto_Object()
        {
            // Arrange
            var recordVersion = new byte[] { 1, 2, 3 };
            var reasonRecordVersion = new byte[] { 10, 20 };

            var updateDto = new UpdateContentRequestDto
            {
                Module = "Healthcare",
                Header = "Updated Header",
                
                RecordVersion = recordVersion,
               
                UpdateReasonDto = new List<UpdateReasonsDto>
                {
                    new UpdateReasonsDto
                    {
                        Id = 1001,
                        ResonType = "Medical Update",
                        RecordVersion = reasonRecordVersion,
                        IsDeleted = false
                    }
                },
                UpdateContentPlatformDto = new List<UpdateContentPlatformDto>
                {
                    new UpdateContentPlatformDto
                    {
                        ID = 2001,
                        PlatformsID = "WEB",
                        RecordVersion = recordVersion,
                        IsDeleted = false
                    }
                }

            };

            // Assert
            Assert.Equal("Healthcare", updateDto.Module);
            Assert.Equal("Updated Header", updateDto.Header);
            Assert.Equal(recordVersion, updateDto.RecordVersion);
            Assert.NotNull(updateDto.UpdateReasonDto);
            Assert.Single(updateDto.UpdateReasonDto);
            Assert.Equal(1001, updateDto.UpdateReasonDto[0].Id);
            Assert.Equal("Medical Update", updateDto.UpdateReasonDto[0].ResonType);
            Assert.Equal(reasonRecordVersion, updateDto.UpdateReasonDto[0].RecordVersion);
            Assert.False(updateDto.UpdateReasonDto[0].IsDeleted);
        }
    }
}
