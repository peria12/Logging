﻿using System.IdentityModel.Tokens.Jwt;
using System.Security.Claims;
using Aurora.AdministrationService.API.Middleware;
using Aurora.AdministrationService.CrossCutting.Constants;
using FluentAssertions;
using Microsoft.AspNetCore.Builder;
using Microsoft.AspNetCore.Http;
using Microsoft.Extensions.Primitives;
using Moq;

namespace Aurora.AdministrationService.Tests.Middleware
{
    public class AdTokenMiddlewareTests
    {
        private readonly Mock<RequestDelegate> _nextMock;
        private readonly AdTokenMiddleware _middleware;
        private readonly DefaultHttpContext _httpContext;

        public AdTokenMiddlewareTests()
        {
            _nextMock = new Mock<RequestDelegate>();
            _middleware = new AdTokenMiddleware(_nextMock.Object);
            _httpContext = new DefaultHttpContext();
        }

        [Fact]
        public async Task InvokeAsync_WithValidToken_ShouldSetUserAndCallNext()
        {
            var token = GenerateJwtToken();
            _httpContext.Request.Headers[CommonConstants.Auth] = new StringValues($"Bearer {token}");

            await _middleware.InvokeAsync(_httpContext);

            _httpContext.User.Identity.Should().NotBeNull();
            _httpContext.User.Claims.Should().NotBeEmpty();
            _nextMock.Verify(next => next(_httpContext), Times.Once);
        }

        [Fact]
        public async Task InvokeAsync_WithExpiredToken_ShouldReturnUnauthorized()
        {
            var token = GenerateJwtToken(expired: true);
            _httpContext.Request.Headers[CommonConstants.Auth] = new StringValues($"Bearer {token}");

            await _middleware.InvokeAsync(_httpContext);

            _httpContext.Response.StatusCode.Should().Be(StatusCodes.Status401Unauthorized);
            _nextMock.Verify(next => next(_httpContext), Times.Never);
        }

        [Fact]
        public async Task InvokeAsync_WithInvalidToken_ShouldReturnUnauthorized()
        {
            _httpContext.Request.Headers[CommonConstants.Auth] = new StringValues("Bearer invalidtoken");

            await _middleware.InvokeAsync(_httpContext);

            _httpContext.Response.StatusCode.Should().Be(StatusCodes.Status401Unauthorized);
            _nextMock.Verify(next => next(_httpContext), Times.Never);
        }

        [Fact]
        public async Task InvokeAsync_WithoutAuthHeader_ShouldCallNext()
        {
            await _middleware.InvokeAsync(_httpContext);

            _nextMock.Verify(next => next(_httpContext), Times.Once);
        }

        private string GenerateJwtToken(bool expired = false)
        {
            var expiration = expired ? DateTime.UtcNow.AddMinutes(-10) : DateTime.UtcNow.AddMinutes(30);
            var securityToken = new JwtSecurityToken(
                claims: new[] { new Claim(JwtRegisteredClaimNames.Exp, new DateTimeOffset(expiration).ToUnixTimeSeconds().ToString()) }
            );
            return new JwtSecurityTokenHandler().WriteToken(securityToken);
        }

        [Fact]
        public void UseAdTokenMiddleware_ShouldRegisterMiddleware()
        {
            // Arrange
            var mockBuilder = new Mock<IApplicationBuilder>();

            // Setup UseMiddleware to return the builder again
            mockBuilder
                .Setup(x => x.Use(It.IsAny<Func<RequestDelegate, RequestDelegate>>()))
                .Returns(mockBuilder.Object);

            // Act
            var result = AdTokenMiddlewareExtensions.UseAdTokenMiddleware(mockBuilder.Object);

            // Assert
            Assert.NotNull(result);
            Assert.Equal(mockBuilder.Object, result);
            mockBuilder.Verify(x => x.Use(It.IsAny<Func<RequestDelegate, RequestDelegate>>()), Times.Once);
        }
    }
}
