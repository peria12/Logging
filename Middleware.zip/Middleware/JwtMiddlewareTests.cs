﻿using System.IdentityModel.Tokens.Jwt;
using System.Reflection;
using System.Security.Claims;
using System.Text;
using Aurora.AdministrationService.API.Middleware;
using Microsoft.AspNetCore.Builder;
using Microsoft.AspNetCore.Http;
using Microsoft.Extensions.Configuration;
using Microsoft.IdentityModel.Tokens;
using Moq;

namespace Aurora.AdministrationService.Tests.Middleware
{
    public class JwtMiddlewareTests
    {
        private const string SecretKey = "ThisIsASecretKeyForJwtTesting123!";

        private static IConfiguration GetMockConfiguration()
        {
            var configMock = new Mock<IConfiguration>();
            configMock.Setup(c => c.GetSection("JwtSecretKey").Value).Returns(SecretKey);
            return configMock.Object;
        }

        private static string GenerateJwtToken()
        {
            var tokenHandler = new JwtSecurityTokenHandler();
            var key = Encoding.ASCII.GetBytes(SecretKey);

            var tokenDescriptor = new SecurityTokenDescriptor
            {
                Subject = new ClaimsIdentity(new[] { new Claim(ClaimTypes.Name, "testuser") }),
                Expires = DateTime.UtcNow.AddMinutes(5),
                SigningCredentials = new SigningCredentials(new SymmetricSecurityKey(key), SecurityAlgorithms.HmacSha256Signature)
            };

            var token = tokenHandler.CreateToken(tokenDescriptor);
            return tokenHandler.WriteToken(token);
        }

        [Fact]
        public async Task Invoke_ShouldAttachUser_WhenTokenIsValid()
        {
            // Arrange
            var token = GenerateJwtToken();
            var context = new DefaultHttpContext();
            context.Request.Headers.Authorization = $"Bearer {token}";
            context.Response.Body = new MemoryStream();

            var configuration = GetMockConfiguration();
            var middleware = new JwtMiddleware((ctx) => Task.CompletedTask, configuration);

            // Act
            await middleware.Invoke(context);

            // Assert
            Assert.NotNull(context.User);
            Assert.True(context.User.Identity.IsAuthenticated);
            Assert.Equal("testuser", context.User.Identity.Name);
        }

        [Fact]
        public async Task Invoke_ShouldSkipAttachUser_WhenNoToken()
        {
            // Arrange
            var context = new DefaultHttpContext();
            context.Response.Body = new MemoryStream();

            var configuration = GetMockConfiguration();
            var middleware = new JwtMiddleware((ctx) => Task.CompletedTask, configuration);

            // Act
            await middleware.Invoke(context);

            // Assert
            Assert.NotNull(context.User); // Default user still exists
            Assert.False(context.User.Identity.IsAuthenticated);
        }

        [Fact]
        public async Task AttachUserToContext_ShouldAttachPrincipal_WhenTokenIsValid()
        {
            // Arrange
            var token = GenerateJwtToken(); // Assume this generates a valid token using the same secret
            var context = new DefaultHttpContext();
            context.Response.Body = new MemoryStream();

            var configuration = GetMockConfiguration(); // This mocks IConfiguration and sets "JwtSecretKey"
            var middleware = new JwtMiddleware((ctx) => Task.CompletedTask, configuration);

            // Access private method via reflection
            var method = typeof(JwtMiddleware).GetMethod("AttachUserToContext", BindingFlags.NonPublic | BindingFlags.Instance);
            Assert.NotNull(method);

            // Act
            var task = (Task)method.Invoke(middleware, new object[] { context, token });
            await task;

            // Assert
            Assert.NotNull(context.User);
            Assert.True(context.User.Identity.IsAuthenticated);
            Assert.Equal("testuser", context.User.Identity.Name);
        }

        [Fact]
        public void UseJwtMiddleware_ShouldAddJwtMiddlewareToPipeline()
        {
            // Arrange
            var appBuilderMock = new Mock<IApplicationBuilder>();

            // Setup the mock to return the appBuilder itself when Use() is called
            appBuilderMock.Setup(ab => ab.Use(It.IsAny<Func<RequestDelegate, RequestDelegate>>()))
                          .Returns(appBuilderMock.Object);

            // Act
            var result = JwtMiddlewareExtensions.UseJwtMiddleware(appBuilderMock.Object);

            // Assert that UseMiddleware<JwtMiddleware>() is called once
            appBuilderMock.Verify(ab => ab.Use(It.Is<Func<RequestDelegate, RequestDelegate>>(f => f != null)), Times.Once);

            // Assert that the result is the same IApplicationBuilder instance
            Assert.Equal(appBuilderMock.Object, result);
        }

        [Fact]
        public async Task AttachUserToContext_ShouldReturnUnauthorized_WhenTokenIsInvalid()
        {
            // Arrange
            var token = "invalid-token"; // Simulate an invalid token
            var httpContext = new DefaultHttpContext();
            var memoryStream = new MemoryStream();
            httpContext.Response.Body = memoryStream;

            var configMock = new Mock<IConfiguration>();
            configMock.Setup(c => c.GetSection("JwtSecretKey").Value).Returns("ThisIsASecretKeyForJwtTesting123!");

            var middleware = new JwtMiddleware((ctx) => Task.CompletedTask, configMock.Object);

            // Create a mock for the ValidateToken method to throw SecurityTokenException
            var tokenHandlerMock = new Mock<JwtSecurityTokenHandler>();
            tokenHandlerMock.Setup(th => th.ValidateToken(It.IsAny<string>(), It.IsAny<TokenValidationParameters>(), out It.Ref<SecurityToken>.IsAny))
                .Throws(new SecurityTokenException("Invalid token"));

            // Act
            var method = typeof(JwtMiddleware).GetMethod("AttachUserToContext", BindingFlags.NonPublic | BindingFlags.Instance);
            await (Task)method.Invoke(middleware, new object[] { httpContext, token });

            // Assert
            Assert.Equal(StatusCodes.Status500InternalServerError, httpContext.Response.StatusCode);
            memoryStream.Seek(0, SeekOrigin.Begin);
            var responseMessage = new StreamReader(memoryStream).ReadToEnd();
            Assert.Equal("An error occurred while processing the token.", responseMessage);
        }
    }
   
}
