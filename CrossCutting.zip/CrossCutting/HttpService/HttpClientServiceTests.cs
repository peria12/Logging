﻿using System.Net;
using System.Net.Http;
using System.Security.Claims;
using System.Text;
using System.Threading;
using System.Threading.Tasks;
using Aurora.AdministrationService.CrossCutting.Constants;
using Aurora.AdministrationService.CrossCutting.HttpService;
using Aurora.AdministrationService.CrossCutting.Logging.Interface;
using FluentAssertions;
using Microsoft.AspNetCore.Http;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.Logging;
using Moq;
using Moq.Protected;
using Xunit;
using System.Collections.Generic;

namespace Aurora.AdministrationService.Tests.CrossCutting.HttpService
{
    public class HttpClientServiceTests
    {
        private readonly Mock<IHttpClientFactory> _httpClientFactoryMock;
        private readonly Mock<IHttpContextAccessor> _httpContextAccessorMock;
        private readonly Mock<IConfiguration> _configurationMock;
        private readonly Mock<ILogger<HttpClientService>> _loggerMock;
        private readonly Mock<ICustomLogger> _customLoggerMock;
        private readonly HttpClientService _httpClientService;

        private readonly DefaultHttpContext _httpContext;

        public HttpClientServiceTests()
        {
            _httpClientFactoryMock = new Mock<IHttpClientFactory>();
            _httpContextAccessorMock = new Mock<IHttpContextAccessor>();
            _configurationMock = new Mock<IConfiguration>();
            _loggerMock = new Mock<ILogger<HttpClientService>>();
            _customLoggerMock = new Mock<ICustomLogger>();

            _httpContext = new DefaultHttpContext();
            _httpContext.User = new ClaimsPrincipal(new ClaimsIdentity(new Claim[]
            {
                new Claim(AppConstants.Preferred_Username, "testuser")
            }));
            _httpContext.Request.Headers[CommonConstants.HeaderRegionCode] = "IN";
            _httpContext.Request.Headers["Authorization"] = "Bearer dummy"; // NOSONAR

            _httpContextAccessorMock.Setup(_ => _.HttpContext).Returns(_httpContext);

            _configurationMock.Setup(c => c[CommonConstants.AdminServiceAPIClientId]).Returns("clientId");
            _configurationMock.Setup(c => c[CommonConstants.AdminServiceAPIClientSecret]).Returns("clientSecret");
            _configurationMock.Setup(c => c[CommonConstants.TenantId]).Returns("tenantId");
            _configurationMock.Setup(c => c["TenantID"]).Returns("tenantId");
            _configurationMock.Setup(c => c["Care21UserName"]).Returns("user");
            _configurationMock.Setup(c => c["Care21Password"]).Returns("pass");

            // FIX: Setup mock for HttpClientTimeout using GetSection instead of GetValue<T>
            var timeoutSectionMock = new Mock<IConfigurationSection>();
            timeoutSectionMock.Setup(x => x.Value).Returns("30");
            _configurationMock.Setup(c => c.GetSection("HttpClientTimeout")).Returns(timeoutSectionMock.Object);

            _httpClientService = new HttpClientService(
                _httpContextAccessorMock.Object,
                _configurationMock.Object,
                _loggerMock.Object,
                _httpClientFactoryMock.Object,
                _customLoggerMock.Object);
        }

        private static HttpClient CreateMockHttpClient(string responseContent)
        {
            var handlerMock = new Mock<HttpMessageHandler>(MockBehavior.Strict);
            handlerMock.Protected()
                .Setup<Task<HttpResponseMessage>>("SendAsync",
                    ItExpr.IsAny<HttpRequestMessage>(),
                    ItExpr.IsAny<CancellationToken>())
                .ReturnsAsync(new HttpResponseMessage
                {
                    StatusCode = HttpStatusCode.OK,
                    Content = new StringContent(responseContent)
                });

            return new HttpClient(handlerMock.Object);
        }

        [Fact]
        public async Task PostAsyncCall_ShouldReturnHttpResponseMessage()
        {
            var httpClient = CreateMockHttpClient("{\"result\":\"success\"}");
            _httpClientFactoryMock.Setup(x => x.CreateClient(It.IsAny<string>())).Returns(httpClient);

            var result = await _httpClientService.PostAsyncCall("http://test.com", new { id = 1 }, "api://scope");

            result.StatusCode.Should().Be(HttpStatusCode.OK);
            var content = await result.Content.ReadAsStringAsync();
            content.Should().Contain("success");
        }

        [Fact]
        public async Task PutAsyncCall_ShouldReturnHttpResponseMessage()
        {
            var httpClient = CreateMockHttpClient("{\"updated\":true}");
            _httpClientFactoryMock.Setup(x => x.CreateClient(It.IsAny<string>())).Returns(httpClient);

            var result = await _httpClientService.PutAsyncCall("http://test.com", new { name = "test" }, "api://scope");

            result.StatusCode.Should().Be(HttpStatusCode.OK);
            var content = await result.Content.ReadAsStringAsync();
            content.Should().Contain("updated");
        }

        [Fact]
        public async Task GetAsyncCall_ShouldReturnHttpResponseMessage()
        {
            var httpClient = CreateMockHttpClient("{\"data\":\"value\"}");
            _httpClientFactoryMock.Setup(x => x.CreateClient(It.IsAny<string>())).Returns(httpClient);

            var result = await _httpClientService.GetAsyncCall("http://test.com", "api://scope");

            result.StatusCode.Should().Be(HttpStatusCode.OK);
            var content = await result.Content.ReadAsStringAsync();
            content.Should().Contain("value");
        }

        [Fact]
        public async Task Aurora_PostAsyncCall_ShouldReturnHttpResponseMessage()
        {
            var httpClient = CreateMockHttpClient("{\"ok\":1}");
            _httpClientFactoryMock.Setup(x => x.CreateClient(It.IsAny<string>())).Returns(httpClient);

            var result = await _httpClientService.Aurora_PostAsyncCall("http://test.com", new { id = 123 });

            result.StatusCode.Should().Be(HttpStatusCode.OK);
            var content = await result.Content.ReadAsStringAsync();
            content.Should().Contain("ok");
        }

        [Fact]
        public async Task DeleteAsyncCall_ShouldReturnHttpResponseMessage()
        {
            var httpClient = CreateMockHttpClient("{\"deleted\":true}");
            _httpClientFactoryMock.Setup(x => x.CreateClient(It.IsAny<string>())).Returns(httpClient);

            var result = await _httpClientService.DeleteAsyncCall("http://test.com", "api://scope");

            result.StatusCode.Should().Be(HttpStatusCode.OK);
            var content = await result.Content.ReadAsStringAsync();
            content.Should().Contain("deleted");
        }

        [Fact]
        public async Task GetAccessTokenByClientCredentials_ShouldReturnToken()
        {
            string tokenJson = "{\"access_token\":\"abc123\"}";
            var httpClient = CreateMockHttpClient(tokenJson);
            _httpClientFactoryMock.Setup(x => x.CreateClient(It.IsAny<string>())).Returns(httpClient);

            var tokenMethod = typeof(HttpClientService)
                .GetMethod("GetAccessTokenByClientCredentials", System.Reflection.BindingFlags.NonPublic | System.Reflection.BindingFlags.Instance);

            var task = (Task<string>)tokenMethod.Invoke(_httpClientService, new object[] { "api://scope" });
            var result = await task;

            result.Should().Be("abc123");
        }

        [Fact]
        public async Task GetAccessTokenByOnBehalfOfUser_ShouldReturnToken()
        {
            string tokenJson = "{\"access_token\":\"userToken123\"}";
            var httpClient = CreateMockHttpClient(tokenJson);
            _httpClientFactoryMock.Setup(x => x.CreateClient(It.IsAny<string>())).Returns(httpClient);

            var method = typeof(HttpClientService)
                .GetMethod("GetAccessTokenByOnBehalfOfUser", System.Reflection.BindingFlags.NonPublic | System.Reflection.BindingFlags.Instance);

            var task = (Task<string>)method.Invoke(_httpClientService, new object[] { "api://scope" });
            var result = await task;

            result.Should().Be("userToken123");
        }
    }
}
