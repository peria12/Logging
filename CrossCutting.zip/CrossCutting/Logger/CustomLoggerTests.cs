﻿#nullable enable
using System.Text;
using Aurora.AdministrationService.CrossCutting.Logging;
using Microsoft.AspNetCore.Http;
using Microsoft.Extensions.Logging;
using Moq;
using Newtonsoft.Json;

namespace Aurora.AdministrationService.Tests.CrossCutting.Logger
{
    public class CustomLoggerTests
    {
        private readonly Mock<ILogger<CustomLogger>> _mockLogger;
        private readonly Mock<IHttpContextAccessor> _mockContextAccessor;
        private readonly CustomLogger _customLogger;

        public CustomLoggerTests()
        {
            _mockLogger = new Mock<ILogger<CustomLogger>>();
            _mockContextAccessor = CustomLoggerTests.MockHttpContextAccessor();
            _customLogger = new CustomLogger(_mockLogger.Object, _mockContextAccessor.Object);
        }
        public static Mock<IHttpContextAccessor> MockHttpContextAccessor()
        {
            Mock<IHttpContextAccessor> httpContextProcessor = new();
            DefaultHttpContext context = new();
            context.Request.Headers[TestConstants.HeaderRegionCode] = TestConstants.FakeRegionCode;
            context.Request.Headers[TestConstants.HeaderFacilityCode] = TestConstants.FakeFacilityCode;
            context.Request.Headers[TestConstants.HeaderLanguageCode] = TestConstants.FakeLanguageCode;
            httpContextProcessor.Setup(_ => _.HttpContext).Returns(context);
            return httpContextProcessor;
        }

        [Fact]
        public void LogAsCustomInfo_ValidData_LogsInformation()
        {
            // Arrange
            var data = new Dictionary<string, dynamic> { { "Key", "Value" } };
            var methodName = "Fact";
            _mockContextAccessor.Setup(d => d.HttpContext).Returns((HttpContext?)null);
            // Act
            _customLogger.LogAsCustomInfo(data, false, methodName);

            // Assert
            _mockLogger.Verify(
                x => x.Log(
                    LogLevel.Information,
                    It.IsAny<EventId>(),
                    It.Is<It.IsAnyType>((c, v) => c != null && c.ToString()!.Contains("Sensitive: NO,")),
                    null,
                   It.IsAny<Func<It.IsAnyType, Exception?, string>>()
                ),
                Times.Once
            );

        }

        [Fact]
        public void LogAsCustomInfo_WithSensitiveData_LogsInformation()
        {
            // Arrange
            var data = new Dictionary<string, dynamic> { { "Key", "Value" } };
            var methodName = "Fact";
            // Act
            _customLogger.LogAsCustomInfo(data, true, methodName);

            // Assert
            _mockLogger.Verify(
                x => x.Log(
                    LogLevel.Information,
                    It.IsAny<EventId>(),
                     It.Is<It.IsAnyType>((c, v) => c != null && c.ToString()!.Contains("Sensitive: YES,")),
                    null,
                    It.IsAny<Func<It.IsAnyType, Exception?, string>>()
                ),
                Times.Once
            );
        }

        [Fact]
        public void LogAsCustomInfo_EmptyData_LogsInformation()
        {
            // Arrange
            var data = new Dictionary<string, dynamic>();
            var methodName = "Fact";

            // Act
            _customLogger.LogAsCustomInfo(data, false, methodName);

            // Assert
            _mockLogger.Verify(
                x => x.Log(
                    LogLevel.Information,
                    It.IsAny<EventId>(),
                    It.Is<It.IsAnyType>((c, v) => c != null && c.ToString()!.Contains("")),
                    null,
                    It.IsAny<Func<It.IsAnyType, Exception?, string>>()
                ),
                Times.Once
            );
        }
        [Fact]
        public void LogInformation_ValidHeaders_LogsInformationWithHeaders()
        {
            // Arrange
            var headers = new HeaderDictionary
    {
        { "HeaderKey1", "HeaderValue1" },
        { "HeaderKey2", "HeaderValue2" }
    };

            var context = new DefaultHttpContext();
            foreach (var header in headers)
            {
                context.Request.Headers.Append(header.Key, header.Value);
            }
            _mockContextAccessor.Setup(x => x.HttpContext).Returns(context);

            var data = new Dictionary<string, dynamic> { { "Key", "Value" } };
            var serializedValue = JsonConvert.SerializeObject(data, Formatting.Indented);
            var methodName = "MCare21.BillingService.CrossCutting.Logging.CustomLogger";

            // Act
            _customLogger.LogAsCustomInfo(data, false, methodName);

            // Assert: Verify the logger was called with the expected log level
            _mockLogger.Verify(
    x => x.Log(
        LogLevel.Information,
        It.IsAny<EventId>(),
        It.Is<It.IsAnyType>((c, v) => c != null && c.ToString()!.Contains("Key") && c.ToString()!.Contains("Value")),
        null,
        It.IsAny<Func<It.IsAnyType, Exception?, string>>()
    ),
    Times.Once
);

        }


        [Fact]
        public void LogInformation_MissingHeaders_LogsInformationWithDefaultValues()
        {
            // Arrange
            var context = new DefaultHttpContext(); // Empty context with no headers.
            _mockContextAccessor.Setup(x => x.HttpContext).Returns(context);

            var data = new Dictionary<string, dynamic> { { "Key", "Value" } };
            var serializedValue = JsonConvert.SerializeObject(data, Formatting.Indented);
            var methodName = "MCare21.BillingService.CrossCutting.Logging.CustomLogger";

            // Act
            _customLogger.LogAsCustomInfo(data, false, methodName);

            // Assert: Verify that the logger was called
            _mockLogger.Verify(
                x => x.Log(
                    LogLevel.Information,
                    It.IsAny<EventId>(),
                    It.Is<It.IsAnyType>((c, v) => c != null && c.ToString()!.Contains("Key") && c.ToString()!.Contains("Value")),
                    null,
                    It.IsAny<Func<It.IsAnyType, Exception?, string>>()
                ),
                Times.Once
            );

            // Optionally: Verify that the correct serialized value is logged
            _mockLogger.Verify(
                x => x.Log(
                    LogLevel.Information,
                    It.IsAny<EventId>(),
                    It.Is<It.IsAnyType>((v, t) => v != null && v.ToString()!.Contains(serializedValue)),
                    null,
                    It.IsAny<Func<It.IsAnyType, Exception?, string>>()
                ),
                Times.Once
            );
        }

        [Fact]
        public void LogAsCustomInfo_DynamicValidData_LogsInformation()
        {
            // Arrange
            var data = new { Key = "Value" };
            var methodName = "Fact";
            _mockContextAccessor.Setup(d => d.HttpContext).Returns((HttpContext?)null);
            // Act
            _customLogger.LogAsCustomInfo(data, false, methodName);

            // Assert
            _mockLogger.Verify(
                x => x.Log(
                    LogLevel.Information,
                    It.IsAny<EventId>(),
                    It.Is<It.IsAnyType>((v, t) => v != null && v.ToString()!.Contains("Sensitive: NO,")),
                    null,
                    It.IsAny<Func<It.IsAnyType, Exception?, string>>()
                ),
                Times.Once
            );
        }
    }
}
