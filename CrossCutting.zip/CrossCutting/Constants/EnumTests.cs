﻿using Aurora.AdministrationService.CrossCutting.Constants;
using FluentAssertions;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Aurora.AdministrationService.Tests.CrossCutting.Constants
{
    public class EnumTests
    {
        [Fact]
        public void ResponseStatusCodes_ShouldHaveExpectedValues()
        {
            ((int)ResponseStatusCodes.Success).Should().Be(200);
            ((int)ResponseStatusCodes.Failed).Should().Be(500);
            ((int)ResponseStatusCodes.Errored).Should().Be(600);
            ((int)ResponseStatusCodes.RecordNotFound).Should().Be(405);
            ((int)ResponseStatusCodes.Success_Create).Should().Be(201);
            ((int)ResponseStatusCodes.BadRequest).Should().Be(400);
            ((int)ResponseStatusCodes.Unauthorized).Should().Be(401);
            ((int)ResponseStatusCodes.Forbidden).Should().Be(403);
            ((int)ResponseStatusCodes.NotFound).Should().Be(404);
            ((int)ResponseStatusCodes.RequestTimeout).Should().Be(408);
            ((int)ResponseStatusCodes.Conflict).Should().Be(409);
            ((int)ResponseStatusCodes.InternalServerError).Should().Be(500);
            ((int)ResponseStatusCodes.ServiceUnavailable).Should().Be(503);
        }

        [Fact]
        public void WhatshappeningCategoryList_ShouldHaveExpectedValues()
        {
            ((int)WhatshappeningCategoryList.All).Should().Be(0);
            ((int)WhatshappeningCategoryList.Packages).Should().Be(1);
            ((int)WhatshappeningCategoryList.Events).Should().Be(2);
            ((int)WhatshappeningCategoryList.Articles).Should().Be(3);
            ((int)WhatshappeningCategoryList.News).Should().Be(4);
        }

        [Fact]
        public void Source_ShouldContainAurora()
        {
            Enum.IsDefined(typeof(Source), "Aurora").Should().BeTrue();
        }

        [Fact]
        public void WeekNumber_ShouldHaveExpectedValues()
        {
            ((int)WeekNumber.First).Should().Be(1);
            ((int)WeekNumber.Second).Should().Be(2);
            ((int)WeekNumber.Third).Should().Be(3);
            ((int)WeekNumber.Fourth).Should().Be(4);
            ((int)WeekNumber.Fifth).Should().Be(5);
            ((int)WeekNumber.Sixth).Should().Be(6);
        }
    }
}
