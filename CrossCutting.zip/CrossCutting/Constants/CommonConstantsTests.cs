﻿using Aurora.AdministrationService.CrossCutting.Constants;
using FluentAssertions;
using Microsoft.Graph;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Aurora.AdministrationService.Tests.CrossCutting.Constants
{
    public class CommonConstantsTests
    {
        [Fact]
        public void HeaderConstants_ShouldBeCorrect()
        {
            CommonConstants.HeaderRegionCode.Should().Be("RegionCode");
            CommonConstants.HeaderRegionCodeDescription.Should().Be("Region code header");
            CommonConstants.HeaderCorrelationId.Should().Be("X-Correlation-ID");
        }

        [Fact]
        public void AzureAdConstants_ShouldBeCorrect()
        {
            CommonConstants.GrantType.Should().Be("grant_type");
            CommonConstants.GrantTypePassword.Should().Be("password");
            CommonConstants.ClientId.Should().Be("ClientID:Aurora-AdministrationService");
            CommonConstants.ClientSecret.Should().Be("client_secret");
            CommonConstants.ScopeOpenId.Should().Be("openid offline_access User.Read");
            CommonConstants.Auth.Should().Be("Authorization");
            CommonConstants.Bearer.Should().Be("Bearer ");
        }

        [Fact]
        public void PaginationConstants_ShouldBeCorrect()
        {
            CommonConstants.PAGINATION_ASCENDING.Should().Be("asc");
            CommonConstants.PAGINATION_DESCENDING.Should().Be("desc");
            CommonConstants.DEFAULT_SORT.Should().Be("id");
            CommonConstants.INVALID_PAGE_NUMBER.Should().Be("INVALID_PAGE_NUMBER");
        }

        [Fact]
        public void ErrorCodes_ShouldBeCorrect()
        {
            CommonConstants.ERROR_CODE_VALUE.Should().Be("ERR-ADMINISTRATION-MS");
            CommonConstants.ERROR_HTTP_REQUEST_EXCEPTION.Should().Be("ERROR_HTTP_REQUEST_EXCEPTION");
            CommonConstants.ERROR_TIMEOUT_EXCEPTION.Should().Be("ERROR_TIMEOUT_EXCEPTION");
        }

        [Fact]
        public void AppointmentConstants_ShouldBeCorrect()
        {
            CommonConstants.AvailableDoctor.Should().Be("Available");
            CommonConstants.NotAvailableDoctor.Should().Be("NotAvailable");
            CommonConstants.YourBooking.Should().Be("YourBooking");
        }

        [Fact]
        public void FileUploadExtensions_ShouldBeCorrect()
        {
            CommonConstants.ExtPng.Should().Be(".png");
            CommonConstants.ExtJpg.Should().Be(".jpg");
            CommonConstants.ImageTypeJpg.Should().Be("imagetype/jpeg");
        }

        [Fact]
        public void ScheduleValidationMessages_ShouldBeCorrect()
        {
            CommonConstants.ValidationMessages.REQUESTCANNOTBENULL.Should().Be("Request cannot be null.");
            CommonConstants.ValidationMessages.SCHEDULESTARTDATEMUSTBEBEFORESCHEDULEENDDATE
                .Should().Be("ScheduleStartDate must be before ScheduleEndDate.");
        }

        [Fact]
        public void ModuleTypes_ShouldBeCorrect()
        {
            CommonConstants.ModuleTypes.Logos.Should().Be("Logos");
            CommonConstants.ModuleTypes.SplashScreen.Should().Be("SplashScreens");
            CommonConstants.ModuleTypes.WhatsHappening.Should().Be("WhatsHappening");
        }

        [Fact]
        public void FileUploadCredentials_ShouldBeCorrect()
        {
            CommonConstants.FileUploadCredentails.NetworkFolder.Should().Be("FileUploadCredentails:NetworkFolder");
            CommonConstants.FileUploadCredentails.BlobPassword.Should().Be("FileUploadCredentails-Password");
        }

        private static readonly string[] ExpectedPlatforms =
        {
        "Patient App",
        "Doctor App",
        "Patient Portal",
        "Other Portal"
        };
        [Fact]
        public void AllowedPlatforms_ShouldContainExpectedValues()
        {
            CommonConstants.AllowedPlatforms.Should().Contain(ExpectedPlatforms);
        }
        [Fact]
        public void DynamicScheduleMessage_ShouldReturnFormattedText()
        {
            var message = CommonConstants.ValidationMessages.DayStartTimeMustBeBeforeDayEndTime("08:00", "18:00", "Monday");
            message.Should().Be("DayStartTime (08:00) must be before DayEndTime (18:00) for Monday.");
        }
    }

    public class ResponseStatusCodeAndScheduleConfigTests
    {
        [Fact]
        public void ResponseStatusCode_ShouldContainExpectedHttpStatusCodes()
        {
            ResponseStatusCode.STATUS_SUCCESS.Should().Be("200");
            ResponseStatusCode.STATUS_SUCCESS_UPDATED.Should().Be("202");
            ResponseStatusCode.STATUS_BADREQUEST.Should().Be("400");
            ResponseStatusCode.STATUS_UNAUTHORIZED.Should().Be("401");
            ResponseStatusCode.STATUS_FORBIDDEN.Should().Be("403");
            ResponseStatusCode.STATUS_NOTFOUND.Should().Be("404");
            ResponseStatusCode.STATUS_REQUESTTIMEOUT.Should().Be("408");
            ResponseStatusCode.STATUS_CONFLICT.Should().Be("409");
            ResponseStatusCode.STATUS_INTERNAL_SERVER_ERROR.Should().Be("500");
            ResponseStatusCode.STATUS_SERVICE_UNAVAILABLE.Should().Be("503");
        }

        [Fact]
        public void ScheduleConfig_BookableInterval_ShouldBeOneDay()
        {
            ScheduleConfig.BookableInterval.Should().Be(TimeSpan.FromDays(1));
        }

        [Fact]
        public void ScheduleConfig_NonBookableInterval_ShouldBeFortyEightHours()
        {
            ScheduleConfig.NonBookableInterval.Should().Be(TimeSpan.FromHours(48));
        }
    }
}
