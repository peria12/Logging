﻿using Aurora.AdministrationService.CrossCutting.Constants;
using FluentAssertions;
using Xunit;

namespace Aurora.AdministrationService.Tests.CrossCutting.Constants
{
    public class AppConstantsTests
    {
        [Fact]
        public void MicroserviceCode_ShouldBe_ADM()
        {
            AppConstants.MicroserviceCode.Should().Be("ADM");
        }

        [Fact]
        public void ConnectionStringPrefix_ShouldBe_Aurora()
        {
            AppConstants.ConnectionStringPrefix.Should().Be("Aurora-");
        }

        [Fact]
        public void RecordVersion_ShouldBe_CorrectValue()
        {
            AppConstants.RecordVersion.Should().Be("RecordVersion");
        }

        [Fact]
        public void User_ShouldBe_Admin()
        {
            AppConstants.User.Should().Be("Admin");
        }

        [Theory]
        [InlineData(AppConstants.Maximum9Character, "Maximum 9 characters")]
        [InlineData(AppConstants.Maximum10Character, "Maximum 10 characters")]
        [InlineData(AppConstants.Maximum50Character, "Maximum 50 characters")]
        [InlineData(AppConstants.Maximum30Character, "Maximum 30 characters")]
        [InlineData(AppConstants.Maximum20Character, "Maximum 20 characters")]
        [InlineData(AppConstants.Maximum40Character, "Maximum 40 characters")]
        [InlineData(AppConstants.Maximum160Character, "Maximum 160 characters")]
        [InlineData(AppConstants.Maximum100Character, "Maximum 100 characters")]
        [InlineData(AppConstants.Maximum200Character, "Maximum 200 characters")]
        [InlineData(AppConstants.Maximum255Character, "Maximum 255 characters")]
        [InlineData(AppConstants.Maximum500Character, "Maximum 500 characters")]
        [InlineData(AppConstants.Maximum600Character, "Maximum 600 characters")]
        [InlineData(AppConstants.Maximum1000Character, "Maximum 1000 characters")]
        public void MaximumCharacterConstants_ShouldHaveCorrectValues(string actual, string expected)
        {
            actual.Should().Be(expected);
        }

        [Theory]
        [InlineData(AppConstants.CodeValidationPattern, @"^[a-zA-Z0-9]+([.-]?[a-zA-Z0-9]*)*[.-]?$")]
        [InlineData(AppConstants.EWSDecimalValidationPattern, @"^\d+(\.\d{1})?$")]
        [InlineData(AppConstants.NumberValidationPattern, @"[0-9]")]
        [InlineData(AppConstants.RegexHexColorCode, @"^#(?:[0-9a-fA-F]{3}){1,2}([0-9a-fA-F]{2})?$")]
        [InlineData(AppConstants.SpecialCharacterNotAllow, @"^[^\W_][\w\W]*$")]
        public void PatternValidationConstants_ShouldHaveCorrectValues(string actual, string expected)
        {
            actual.Should().Be(expected);
        }

        [Fact]
        public void CommunicationBaseConstants_ShouldHaveCorrectValues()
        {
            AppConstants.CommunicationBaseConstants.AppointmentServiceBaseUrl.Should().Be("AppointmentServiceBaseUrl");
            AppConstants.CommunicationBaseConstants.AppointmentService.Should().Be("AppointmentService");
            AppConstants.CommunicationBaseConstants.GetDoctorSlotsBYId_Url.Should().Be("/api/Slot/GetDoctorSlotsBYId");
        }
    }
}
