﻿using Aurora.AdministrationService.CrossCutting.Extensions;
using FluentAssertions;

namespace Aurora.AdministrationService.Tests.CrossCutting
{
    public class FilterWithPropsTests
    {
        private class TestEntity
        {
            public int Id { get; set; }
            public string Name { get; set; }
            public NestedEntity Nested { get; set; }
            public List<SubEntity> SubEntities { get; set; }
            public int? NullableNumber { get; set; }
        }

        private class NestedEntity
        {
            public string NestedProperty { get; set; }
        }

        private class SubEntity
        {
            public string SubName { get; set; }
        }

        [Fact]
        public async Task ApplyQueryParameters_NoFilters_ReturnsOriginalQuery()
        {
            // Arrange
            var query = new List<TestEntity>
            {
                new TestEntity { Id = 1, Name = "John" }
            }.AsQueryable();

            var parameters = new PaginationQuery { Filters = null };

            // Act
            var result = await query.ApplyQueryParameters(parameters);

            // Assert
            result.Should().BeEquivalentTo(query);
        }

        [Fact]
        public async Task ApplyQueryParameters_FilterOnSimpleProperty_ReturnsFilteredQuery()
        {
            // Arrange
            var query = new List<TestEntity>
            {
                new TestEntity { Id = 1, Name = "John" },
                new TestEntity { Id = 2, Name = "Jane" }
            }.AsQueryable();

            var parameters = new PaginationQuery
            {
                Filters = new Dictionary<string, string> { { "Name", "John" } }
            };

            // Act
            var result = await query.ApplyQueryParameters(parameters);

            // Assert
            result.Should().HaveCount(1);
            result.First().Name.Should().Be("John");
        }

        [Fact]
        public async Task ApplyQueryParameters_FilterOnNestedProperty_ReturnsFilteredQuery()
        {
            // Arrange
            var query = new List<TestEntity>
            {
                new TestEntity { Id = 1, Nested = new NestedEntity { NestedProperty = "TestValue" } },
                new TestEntity { Id = 2, Nested = new NestedEntity { NestedProperty = "OtherValue" } }
            }.AsQueryable();

            var parameters = new PaginationQuery
            {
                Filters = new Dictionary<string, string> { { "Nested.NestedProperty", "TestValue" } }
            };

            // Act
            var result = await query.ApplyQueryParameters(parameters);

            // Assert
            result.Should().HaveCount(1);
            result.Should().NotBeNullOrEmpty();
            result.First().Nested?.NestedProperty.Should().NotBeNull();
            result.First().Nested?.NestedProperty.Should().Be("TestValue");
        }

        [Fact]
        public async Task ApplyQueryParameters_FilterOnCollectionProperty_ReturnsFilteredQuery()
        {
            // Arrange
            var query = new List<TestEntity>
            {
                new TestEntity
                {
                    Id = 1,
                    SubEntities = new List<SubEntity>
                    {
                        new SubEntity { SubName = "Match" }
                    }
                },
                new TestEntity
                {
                    Id = 2,
                    SubEntities = new List<SubEntity>
                    {
                        new SubEntity { SubName = "NoMatch" }
                    }
                }
            }.AsQueryable();

            var parameters = new PaginationQuery
            {
                Filters = new Dictionary<string, string> { { "SubEntities.SubName", "Match" } }
            };

            // Act
            var result = await query.ApplyQueryParameters(parameters);

            // Assert
            result.Should().HaveCount(2);
            result.First().Id.Should().Be(1);
        }

        [Fact]
        public async Task ApplyQueryParameters_FilterOnNullableProperty_ReturnsFilteredQuery()
        {
            // Arrange
            var query = new List<TestEntity>
            {
                new TestEntity { Id = 1, NullableNumber = 5 },
                new TestEntity { Id = 2, NullableNumber = null }
            }.AsQueryable();

            var parameters = new PaginationQuery
            {
                Filters = new Dictionary<string, string> { { "NullableNumber", "5" } }
            };

            // Act
            var result = await query.ApplyQueryParameters(parameters);

            // Assert
            result.Should().HaveCount(1);
            result.First().NullableNumber.Should().Be(5);
        }

        [Fact]
        public async Task ApplyQueryParameters_FilterOnStringProperty_UsesContains()
        {
            // Arrange
            var query = new List<TestEntity>
            {
                new TestEntity { Id = 1, Name = "John Doe" },
                new TestEntity { Id = 2, Name = "Jane Smith" }
            }.AsQueryable();

            var parameters = new PaginationQuery
            {
                Filters = new Dictionary<string, string> { { "Name", "John" } }
            };

            // Act
            var result = await query.ApplyQueryParameters(parameters);

            // Assert
            result.Should().HaveCount(1);
            result.First().Name.Should().Be("John Doe");
        }

        [Fact]
        public async Task ApplyQueryParameters_InvalidPropertyName_SkipsFilter()
        {
            // Arrange
            var query = new List<TestEntity>
            {
                new TestEntity { Id = 1, Name = "John" }
            }.AsQueryable();

            var parameters = new PaginationQuery
            {
                Filters = new Dictionary<string, string> { { "Name", "John" } }
            };

            // Act
            var result = await query.ApplyQueryParameters(parameters);

            // Assert
            result.Should().HaveCount(1);
        }
    }
}