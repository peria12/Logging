﻿using Aurora.AdministrationService.CrossCutting.Extensions;
using FluentAssertions;

namespace Aurora.AdministrationService.Tests.CrossCutting.Extensions
{
    public class StringExtensionTests
    {
        private class SampleDto
        {
            public string Name { get; set; }
            public string Description { get; set; }
            public int Age { get; set; } // Non-string property
            public string NullValue { get; set; }
        }

        [Theory]
        [InlineData("  John  ", "  Developer  ", "John", "Developer")]
        [InlineData("Alice", "Engineer", "Alice", "Engineer")]
        [InlineData("   ", "   ", "", "")]
        public void TrimStringProperties_Should_Trim_All_String_Properties(
            string nameInput, string descriptionInput, string expectedName, string expectedDescription)
        {
            // Arrange
            var dto = new SampleDto
            {
                Name = nameInput,
                Description = descriptionInput,
                Age = 30
            };

            // Act
            var result = dto.TrimStringProperties<SampleDto>();

            // Assert
            result.Should().NotBeNull();
            result.Name.Should().Be(expectedName);
            result.Description.Should().Be(expectedDescription);
            result.Age.Should().Be(30); // ensure non-string property is untouched
        }

        [Fact]
        public void TrimStringProperties_Should_Handle_Null_String_Properties()
        {
            // Arrange
            var dto = new SampleDto
            {
                Name = null,
                Description = "   Something  ",
                NullValue = null
            };

            // Act
            var result = dto.TrimStringProperties<SampleDto>();

            // Assert
            result.Name.Should().BeNull();
            result.Description.Should().Be("Something");
            result.NullValue.Should().BeNull();
        }
    }
}
