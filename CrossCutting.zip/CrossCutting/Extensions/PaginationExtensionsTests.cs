﻿using System.Reflection;
using Aurora.AdministrationService.CrossCutting.Constants;
using Aurora.AdministrationService.CrossCutting.Extensions;
using FluentAssertions;

namespace Aurora.AdministrationService.Tests.CrossCutting.Extensions;

public class PaginationExtensionsTests
{
    private class TestEntity
    {
        public int Id { get; set; }
        public string Name { get; set; }
    }
    public class Parent
    {
        public string ParentName { get; set; }
        public List<Child> Children { get; set; }
    }

    public class Child
    {
        public string Name { get; set; }
    }
    [Fact]
    public void PagingBySort_ValidSorting_ReturnsSortedData()
    {
        var query = new PaginationQuery { PageNumber = 1, PageSize = 10, SortString = "Id", SortOrder = "desc" };
        var data = new List<TestEntity>
        {
            new TestEntity { Id = 1, Name = "A" },
            new TestEntity { Id = 2, Name = "B" }
        }.AsQueryable();

        var result = data.PagingBySort(query);

        result.Records.Should().HaveCount(2);
        result.Records.First().Id.Should().Be(2);
    }

    [Fact]
    public void PagingByFilterAndSort_FilterAndSortApplied_ReturnsFilteredAndSortedData()
    {
        var query = new PaginationQuery { PageNumber = 1, PageSize = 10, GlobalFilterString = "A" };
        var data = new List<TestEntity>
        {
            new TestEntity { Id = 1, Name = "A" },
            new TestEntity { Id = 2, Name = "B" }
        }.AsQueryable();

        var filterColumns = new List<FilterColumn> { new FilterColumn { Column = "Name" } };
        var result = data.PagingByFilterAndSort(filterColumns, query);

        result.Records.Should().HaveCount(1);
        result.Records.First().Name.Should().Be("A");
    }

    [Fact]
    public void PagingByFilterAndSort_EmptyList_ReturnsEmptyResult()
    {
        var query = new PaginationQuery { PageNumber = 1, PageSize = 10 };
        var data = new List<TestEntity>().AsQueryable();
        var filterColumns = new List<FilterColumn>();

        var result = data.PagingByFilterAndSort(filterColumns, query);
        result.Records.Should().BeEmpty();
        result.TotalCount.Should().Be(0);
    }

    public static IEnumerable<object[]> GetValidFilterTestData()
    {
        yield return new object[] { "123", typeof(int), true };
        yield return new object[] { "abc", typeof(int), false };
        yield return new object[] { "true", typeof(bool), true };
        yield return new object[] { "false", typeof(bool), true };
        yield return new object[] { "xyz", typeof(string), true };
        yield return new object[] { "12.34", typeof(decimal), true };
        yield return new object[] { "badData", typeof(decimal), false };
    }

    [Fact]
    public void PagingBySort_InvalidPageParams_ThrowsException()
    {
        var query = new PaginationQuery { PageNumber = 0, PageSize = 10 }; // Invalid PageNumber
        var data = new List<TestEntity>().AsQueryable();

        Action act = () => data.PagingBySort(query);

        act.Should().Throw<Exception>()
           .WithMessage(CommonConstants.INVALID_PAGE_NUMBER);
    }

    [Fact]
    public void IsValidPageParams_ShouldReturnFalse_WhenPageNumberIsLessThanOne()
    {
        // Arrange
         MethodInfo _isValidPageParamsMethod = typeof(PaginationExtensions)
        .GetMethod("IsValidPageParams", BindingFlags.NonPublic | BindingFlags.Static);
          var query = new PaginationQuery { PageNumber = 0, PageSize = 10 };

        // Act
        var result = _isValidPageParamsMethod.Invoke(null, new object[] { query });

        // Assert
        var (isValid, errorMessage) = ((bool, string))result!;
        Assert.False(isValid);
        Assert.Equal(CommonConstants.INVALID_PAGE_NUMBER, errorMessage);
    }

    [Fact]
    public void IsValidPageParams_ShouldReturnFalse_WhenPageSizeIsLessThanOne()
    {
        // Arrange
        MethodInfo _isValidPageParamsMethod = typeof(PaginationExtensions)
      .GetMethod("IsValidPageParams", BindingFlags.NonPublic | BindingFlags.Static);
        var query = new PaginationQuery { PageNumber = 1, PageSize = 0 };

        // Act
        var result = _isValidPageParamsMethod.Invoke(null, new object[] { query });

        // Assert
        var (isValid, errorMessage) = ((bool, string))result!;
        Assert.False(isValid);
        Assert.Equal(CommonConstants.INVALID_PAGE_SIZE, errorMessage);
    }

    [Fact]
    public void IsValidPageParams_ShouldReturnTrue_WhenPageParamsAreValid()
    {
        // Arrange
        MethodInfo _isValidPageParamsMethod = typeof(PaginationExtensions)
      .GetMethod("IsValidPageParams", BindingFlags.NonPublic | BindingFlags.Static);
        var query = new PaginationQuery { PageNumber = 2, PageSize = 25 };

        // Act
        var result = _isValidPageParamsMethod.Invoke(null, new object[] { query });

        // Assert
        var (isValid, errorMessage) = ((bool, string))result!;
        Assert.True(isValid);
        Assert.Equal(string.Empty, errorMessage);
    }

    [Fact]
    public void PagingByFilterAndSort_ShouldThrowException_WhenPageNumberIsInvalid()
    {
        // Arrange
        var data = GetTestData().AsQueryable();
        var query = new PaginationQuery { PageNumber = 0, PageSize = 5 };
        var filters = new List<FilterColumn>();

        // Act & Assert
        var ex = Assert.Throws<ArgumentException>(() => data.PagingByFilterAndSort(filters, query));
        Assert.Equal(CommonConstants.INVALID_PAGE_NUMBER, ex.Message);
    }

    [Fact]
    public void PagingByFilterAndSort_ShouldThrowException_WhenPageSizeIsInvalid()
    {
        // Arrange
        var data = GetTestData().AsQueryable();
        var query = new PaginationQuery { PageNumber = 1, PageSize = 0 };
        var filters = new List<FilterColumn>();

        // Act & Assert
        var ex = Assert.Throws<ArgumentException>(() => data.PagingByFilterAndSort(filters, query));
        Assert.Equal(CommonConstants.INVALID_PAGE_SIZE, ex.Message);
    }

    [Fact]
    public void PagingByFilterAndSort_ShouldReturnPagedData_WhenValidParams()
    {
        // Arrange
        var data = GetTestData().AsQueryable();
        var query = new PaginationQuery { PageNumber = 2, PageSize = 3 };
        var filters = new List<FilterColumn>();

        // Act
        var result = data.PagingByFilterAndSort(filters, query);

        // Assert
        Assert.Equal(3, result.Records.Count()); // page 2 with size 3
        Assert.Equal(10, result.TotalCount);
        Assert.Equal(7, result.Records.First().Id); // Should start from 4
    }

    [Fact]
    public void PagingByFilterAndSort_ShouldReturnEmptyResult_WhenListIsEmpty()
    {
        // Arrange
        var data = new List<TestEntity>().AsQueryable();
        var query = new PaginationQuery { PageNumber = 1, PageSize = 5 };
        var filters = new List<FilterColumn>();

        // Act
        var result = data.PagingByFilterAndSort(filters, query);

        // Assert
        Assert.Empty(result.Records);
        Assert.Equal(0, result.TotalCount);
    }

    private static List<TestEntity> GetTestData()
    {
        return Enumerable.Range(1, 10).Select(i => new TestEntity
        {
            Id = i,
            Name = $"Name {i}"
        }).ToList();
    }

    [Fact]
    public void FilterList_ShouldFilterResults_ByGlobalFilter()
    {
        // Arrange
        var data = new List<TestEntity>
        {
            new TestEntity { Name = "Alice", Id = 30 },
            new TestEntity { Name = "Bob", Id = 25 },
            new TestEntity { Name = "Charlie", Id = 35 }
        }.AsQueryable();

        var query = new PaginationQuery
        {
            GlobalFilterString = "li"
        };

        var filterColumns = new List<FilterColumn>
        {
            new FilterColumn { Column = "Name" }
        };

        // Use reflection to invoke private static method
        var method = typeof(PaginationExtensions) // Replace with the class name where FilterList is defined
            .GetMethod("FilterList", BindingFlags.NonPublic | BindingFlags.Static)
            ?.MakeGenericMethod(typeof(TestEntity));

        Assert.NotNull(method);

        var result = method.Invoke(null, new object[] { data, filterColumns, query }) as IQueryable<TestEntity>;

        // Act
        var list = result.ToList();

        // Assert
        Assert.Equal(2, list.Count);
        Assert.Contains(list, x => x.Name == "Alice");
        Assert.Contains(list, x => x.Name == "Charlie");
    }

    [Fact]
    public void FilterList_ShouldReturnAll_WhenGlobalFilterEmpty()
    {
        // Arrange
        var data = new List<TestEntity>
        {
            new TestEntity { Name = "Alice", Id = 30 },
            new TestEntity { Name = "Bob", Id = 25 },
            new TestEntity { Name = "Charlie", Id = 35 }
        }.AsQueryable();

        var query = new PaginationQuery
        {
            GlobalFilterString = "   " // whitespace
        };

        var filterColumns = new List<FilterColumn>
        {
            new FilterColumn { Column = "Name" }
        };

        var method = typeof(PaginationExtensions)
            .GetMethod("FilterList", BindingFlags.NonPublic | BindingFlags.Static)
            ?.MakeGenericMethod(typeof(TestEntity));

        Assert.NotNull(method);

        var result = method.Invoke(null, new object[] { data, filterColumns, query }) as IQueryable<TestEntity>;

        // Act
        var list = result.ToList();

        // Assert
        Assert.Equal(3, list.Count);
    }

    [Fact]
    public void FilterList_ShouldThrow_WhenPropertyNotFound()
    {
        // Arrange
        var data = new List<TestEntity>
        {
            new TestEntity { Name = "Alice", Id = 30 }
        }.AsQueryable();

        var query = new PaginationQuery
        {
            GlobalFilterString = "Alice"
        };

        var filterColumns = new List<FilterColumn>
        {
            new FilterColumn { Column = "NonExistentProperty" }
        };

        var method = typeof(PaginationExtensions)
            .GetMethod("FilterList", BindingFlags.NonPublic | BindingFlags.Static)
            ?.MakeGenericMethod(typeof(TestEntity));

        Assert.NotNull(method);

        // Act & Assert
        var ex = Assert.Throws<TargetInvocationException>(() =>
        {
            method.Invoke(null, new object[] { data, filterColumns, query });
        });

        Assert.Contains("Property 'NonExistentProperty' not found", ex.InnerException.Message);
    }

    [Fact]
    public void FilterList_ShouldFilterOnNestedCollectionProperty()
    {
        // Arrange: a list of Parent objects with children
        var data = new List<Parent>
        {
            new Parent
            {
                ParentName = "John",
                Children = new List<Child> { new Child { Name = "Alice" }, new Child { Name = "Eve" } }
            },
            new Parent
            {
                ParentName = "Jane",
                Children = new List<Child> { new Child { Name = "Bob" } }
            }
        }.AsQueryable();

        var query = new PaginationQuery
        {
            GlobalFilterString = "Alice"
        };

        var filterColumns = new List<FilterColumn>
        {
            new FilterColumn { Column = "Children.Name" }
        };

        // Use reflection to invoke the private static method
        var method = typeof(PaginationExtensions) // Replace with actual class name
            .GetMethod("FilterList", BindingFlags.NonPublic | BindingFlags.Static)
            ?.MakeGenericMethod(typeof(Parent));

        Assert.NotNull(method);

        var result = method.Invoke(null, new object[] { data, filterColumns, query }) as IQueryable<Parent>;

        // Act
        var list = result.ToList();

        // Assert
        Assert.Single(list);
        Assert.Equal("John", list[0].ParentName);
    }
}