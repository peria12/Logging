﻿using Aurora.AdministrationService.CrossCutting.Extensions;
using FluentAssertions;
using System.Collections.Generic;
using Xunit;

namespace Aurora.AdministrationService.Tests.CrossCutting.Extensions
{
    public class JsonSerializerExtensionsTests
    {
        [Fact]
        public void SerializeWithCamelCase_ShouldSerializeObjectWithCamelCase()
        {
            // Arrange
            var testObject = new { FirstName = "John", LastName = "Doe" };

            // Act
            var jsonResult = testObject.SerializeWithCamelCase();

            // Assert
            jsonResult.Should().Be("{\"firstName\":\"John\",\"lastName\":\"Doe\"}");
        }

        [Fact]
        public void SerializeWithCamelCase_ShouldHandleNullValues()
        {
            // Arrange
            object testObject = default!;

            // Act
            var jsonResult = testObject.SerializeWithCamelCase();

            // Assert
            jsonResult.Should().Be("null");
        }

        [Fact]
        public void SerializeWithCamelCase_ShouldSerializeListWithCamelCase()
        {
            // Arrange
            var testList = new List<object>
            {
                new { FirstName = "Alice", LastName = "Smith" },
                new { FirstName = "Bob", LastName = "Johnson" }
            };

            // Act
            var jsonResult = testList.SerializeWithCamelCase();

            // Assert
            jsonResult.Should().Be("[{\"firstName\":\"Alice\",\"lastName\":\"Smith\"},{\"firstName\":\"Bob\",\"lastName\":\"Johnson\"}]");
        }

        [Fact]
        public void SerializeWithCamelCase_ShouldSerializeEmptyObject()
        {
            // Arrange
            var testObject = new { };

            // Act
            var jsonResult = testObject.SerializeWithCamelCase();

            // Assert
            jsonResult.Should().Be("{}");
        }

        [Fact]
        public void SerializeWithCamelCase_ShouldSerializePrimitiveTypes()
        {
            // Arrange
            int number = 42;
            string text = "Hello";
            bool booleanValue = true;

            // Act
            var numberJson = number.SerializeWithCamelCase();
            var textJson = text.SerializeWithCamelCase();
            var booleanJson = booleanValue.SerializeWithCamelCase();

            // Assert
            numberJson.Should().Be("42");
            textJson.Should().Be("\"Hello\"");
            booleanJson.Should().Be("true");
        }
    }
}
