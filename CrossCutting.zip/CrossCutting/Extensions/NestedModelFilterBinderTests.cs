﻿using Aurora.AdministrationService.CrossCutting.Extensions;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc.ModelBinding;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Primitives;
using System.Collections.Generic;
using System.Threading.Tasks;
using Xunit;
using FluentAssertions;

namespace Aurora.AdministrationService.Tests.CrossCutting.Extensions
{
    public class NestedModelFilterBinderTests
    {
        [Fact]
        public async Task BindModelAsync_ShouldReturnFailedResult_WhenModelTypeIsInvalid()
        {
            // Arrange
            var binder = new NestedModelFilterBinder();
            var httpContext = new DefaultHttpContext();
            var actionContext = new ActionContext(httpContext, new Microsoft.AspNetCore.Routing.RouteData(), new Microsoft.AspNetCore.Mvc.Abstractions.ActionDescriptor());

            var bindingContext = new DefaultModelBindingContext
            {
                ModelMetadata = new EmptyModelMetadataProvider().GetMetadataForType(typeof(string)), // Invalid type
                ModelState = new ModelStateDictionary(),
                ActionContext = actionContext
            };

            // Act
            await binder.BindModelAsync(bindingContext);

            // Assert
            bindingContext.Result.IsModelSet.Should().BeFalse();
        }

        [Fact]
        public async Task BindModelAsync_ShouldReturnEmptyDictionary_WhenNoMatchingKeysArePresent()
        {
            // Arrange
            var binder = new NestedModelFilterBinder();
            var httpContext = new DefaultHttpContext();
            httpContext.Request.Query = new QueryCollection(new Dictionary<string, StringValues>()); // Ensure Query is initialized
            var actionContext = new ActionContext(httpContext, new Microsoft.AspNetCore.Routing.RouteData(), new Microsoft.AspNetCore.Mvc.Abstractions.ActionDescriptor());

            var bindingContext = new DefaultModelBindingContext
            {
                ModelMetadata = new EmptyModelMetadataProvider().GetMetadataForType(typeof(Dictionary<string, string>)),
                ModelState = new ModelStateDictionary(),
                ActionContext = actionContext
            };

            // Act
            await binder.BindModelAsync(bindingContext);

            // Assert
            bindingContext.Result.IsModelSet.Should().BeTrue();
            bindingContext.Result.Model.Should().BeEquivalentTo(new Dictionary<string, string>());
        }

        [Fact]
        public async Task BindModelAsync_ShouldExtractNestedKeysCorrectly()
        {
            // Arrange
            var binder = new NestedModelFilterBinder();
            var httpContext = new DefaultHttpContext();
            var queryData = new Dictionary<string, StringValues>
            {
                { "Filters.Name", "John" },
                { "Filters.Age", "30" },
                { "UnrelatedKey", "ShouldBeIgnored" }
            };
            httpContext.Request.Query = new QueryCollection(queryData); // Ensure Query is initialized
            var actionContext = new ActionContext(httpContext, new Microsoft.AspNetCore.Routing.RouteData(), new Microsoft.AspNetCore.Mvc.Abstractions.ActionDescriptor());

            var bindingContext = new DefaultModelBindingContext
            {
                ModelMetadata = new EmptyModelMetadataProvider().GetMetadataForType(typeof(Dictionary<string, string>)),
                ModelState = new ModelStateDictionary(),
                ActionContext = actionContext
            };

            // Act
            await binder.BindModelAsync(bindingContext);

            // Assert
            bindingContext.Result.IsModelSet.Should().BeTrue();
            var result = bindingContext.Result.Model as Dictionary<string, string>;
            result.Should().NotBeNull();
            result.Should().HaveCount(2);
            result.Should().ContainKey("Name").And.ContainValue("John");
            result.Should().ContainKey("Age").And.ContainValue("30");
        }
    }
}
