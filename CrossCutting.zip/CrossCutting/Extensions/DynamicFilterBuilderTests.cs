﻿using Aurora.AdministrationService.CrossCutting.Extensions;
using System.Linq.Expressions;
#nullable enable
namespace Aurora.AdministrationService.Tests.CrossCutting.Extensions;

public class TestEntity
{
    public int Id { get; set; }
    public string Name { get; set; }
    public int Age { get; set; }
}
public class DummyEntity
{
    public int Age { get; set; }
    public string Name { get; set; }
}

public class DynamicFilterBuilderTests
{
    [Fact]
    public void And_ShouldBuildCorrectExpression()
    {
        var builder = new DynamicFilterBuilder<TestEntity>();
        builder.And("Age", FilterOperator.GreaterThan, 25);

        Expression<Func<TestEntity, bool>> expression = builder.Build();
        Assert.NotNull(expression);
    }

    [Fact]
    public void Or_ShouldBuildCorrectExpression()
    {
        var builder = new DynamicFilterBuilder<TestEntity>();
        builder.Or("Age", FilterOperator.LessThan, 30);

        Expression<Func<TestEntity, bool>> expression = builder.Build();
        Assert.NotNull(expression);
    }

    [Fact]
    public void And_MultipleConditions_ShouldCombineWithAnd()
    {
        var builder = new DynamicFilterBuilder<TestEntity>();
        builder.And("Age", FilterOperator.GreaterThan, 25)
               .And("Name", FilterOperator.Equals, "John");

        Expression<Func<TestEntity, bool>> expression = builder.Build();
        Assert.NotNull(expression);
    }

    [Fact]
    public void Or_MultipleConditions_ShouldCombineWithOr()
    {
        var builder = new DynamicFilterBuilder<TestEntity>();
        builder.Or("Age", FilterOperator.LessThan, 30)
               .Or("Name", FilterOperator.Equals, "Doe");

        Expression<Func<TestEntity, bool>> expression = builder.Build();
        Assert.NotNull(expression);
    }

    [Fact]
    public void And_EmptyBuilder_ShouldThrowException()
    {
        var builder = new DynamicFilterBuilder<TestEntity>();
        Assert.Throws<Exception>(() => builder.And(_ => { }));
    }

    [Fact]
    public void Or_EmptyBuilder_ShouldThrowException()
    {
        var builder = new DynamicFilterBuilder<TestEntity>();
        Assert.Throws<Exception>(() => builder.Or(_ => { }));
    }

    [Fact]
    public void And_StringOperatorValue_ShouldBuildCorrectExpression()
    {
        var builder = new DynamicFilterBuilder<DummyEntity>();

        builder.And(nameof(DummyEntity.Age), FilterOperator.GreaterThan, 30);
        var func = builder.Compile();

        var result = func(new DummyEntity { Age = 35 });
        Assert.True(result);

        result = func(new DummyEntity { Age = 25 });
        Assert.False(result);
    }

    [Fact]
    public void Or_StringOperatorValue_ShouldBuildCorrectExpression()
    {
        var builder = new DynamicFilterBuilder<DummyEntity>();

        builder.Or(nameof(DummyEntity.Age), FilterOperator.LessThan, 20);
        builder.Or(nameof(DummyEntity.Age), FilterOperator.GreaterThan, 60);

        var func = builder.Compile();

        Assert.True(func(new DummyEntity { Age = 15 }));
        Assert.True(func(new DummyEntity { Age = 65 }));
        Assert.False(func(new DummyEntity { Age = 40 }));
    }

    [Fact]
    public void And_ActionBuilder_ShouldCombineWithAndAlso()
    {
        var builder = new DynamicFilterBuilder<DummyEntity>();

        builder.And(b =>
        {
            b.And(nameof(DummyEntity.Age), FilterOperator.GreaterThan, 20);
            b.And(nameof(DummyEntity.Age), FilterOperator.LessThan, 50);
        });

        var func = builder.Compile();

        Assert.True(func(new DummyEntity { Age = 30 }));
        Assert.False(func(new DummyEntity { Age = 55 }));
    }

    [Fact]
    public void Or_ActionBuilder_ShouldCombineWithOrElse()
    {
        var builder = new DynamicFilterBuilder<DummyEntity>();

        builder.Or(b =>
        {
            b.Or(nameof(DummyEntity.Age), FilterOperator.LessThan, 18);
            b.Or(nameof(DummyEntity.Age), FilterOperator.GreaterThan, 65);
        });

        var func = builder.Compile();

        Assert.True(func(new DummyEntity { Age = 10 }));
        Assert.True(func(new DummyEntity { Age = 70 }));
        Assert.False(func(new DummyEntity { Age = 30 }));
    }

    [Fact]
    public void And_WithNoExpressionInAction_ShouldThrowException()
    {
        var builder = new DynamicFilterBuilder<DummyEntity>();

        var ex = Assert.Throws<Exception>(() =>
        {
            builder.And(b => { /* no expression */ });
        });

        Assert.Equal("Empty builder", ex.Message);
    }

    [Fact]
    public void Or_WithNoExpressionInAction_ShouldThrowException()
    {
        var builder = new DynamicFilterBuilder<DummyEntity>();

        var ex = Assert.Throws<Exception>(() =>
        {
            builder.Or(b => { /* no expression */ });
        });

        Assert.Equal("Empty builder", ex.Message);
    }

    [Fact]
    public void Build_ShouldReturnValidExpressionTree()
    {
        var builder = new DynamicFilterBuilder<DummyEntity>();

        builder.And(nameof(DummyEntity.Age), FilterOperator.GreaterThan, 25);
        var expr = builder.Build();

        Assert.NotNull(expr);
        Assert.IsAssignableFrom<Expression<Func<DummyEntity, bool>>>(expr);
    }

    [Fact]
    public void Compile_ShouldReturnValidDelegate()
    {
        var builder = new DynamicFilterBuilder<DummyEntity>();

        builder.And(nameof(DummyEntity.Age), FilterOperator.GreaterThan, 25);
        var predicate = builder.Compile();

        var result = predicate(new DummyEntity { Age = 30 });
        Assert.True(result);
    }
}
