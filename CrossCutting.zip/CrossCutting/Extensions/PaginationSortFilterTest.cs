﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Linq.Expressions;
using System.Reflection;
using System.Text;
using System.Threading.Tasks;
using Aurora.AdministrationService.CrossCutting.Extensions;
using Microsoft.Graph;

namespace Aurora.AdministrationService.Tests.CrossCutting
{
    public class PaginationSortFilterTest
    {
        public class SampleEntity
        {
            public string Name { get; set; }
            public int Age { get; set; }
        }
        public class Address
        {
            public string City { get; set; }
        }

        public class Person
        {
            public string Name { get; set; }
            public Address Address { get; set; }
        }

        private static ConstantExpression GetConstantExpression(object value) =>Expression.Constant(value);

        private static MemberExpression CallGetNestedProperty(Expression param, string propertyPath)
        {
            var method = typeof(PaginationSortFilter)
                .GetMethod("GetNestedProperty", BindingFlags.NonPublic | BindingFlags.Static);

            return (MemberExpression)method.Invoke(null, new object[] { param, propertyPath });
        }

        private static Expression CallPrivateMethod(string methodName, params object[] args)
        {
            var method = typeof(PaginationSortFilter).GetMethod(methodName, BindingFlags.NonPublic | BindingFlags.Static);
            return (Expression)method.Invoke(null, args);
        }
        [Fact]
        public void GetFilter_ShouldReturnEqualExpression_ForEqualsOperator()
        {
            // Arrange
            var parameter = Expression.Parameter(typeof(SampleEntity), "x");
            string property = "Name";
            FilterOperator op = FilterOperator.Equals;
            object value = "Test";

            // Act
            var method = typeof(PaginationSortFilter)
                .GetMethod("GetFilter", BindingFlags.NonPublic | BindingFlags.Static);

            var expression = method?.Invoke(null, new object[] { parameter, property, op, value }) as Expression;

            // Assert
            Assert.NotNull(expression);
            Assert.Contains("Test", expression.ToString());
        }

        [Fact]
        public void CreateFilter_EqualsOperator_ShouldReturnEqualExpression()
        {
            // Arrange
            var parameter = Expression.Parameter(typeof(SampleEntity), "x");
            var prop = Expression.Property(parameter, nameof(SampleEntity.Name));
            var constant = Expression.Constant("John");
            var op = FilterOperator.Equals;

            var method = typeof(PaginationSortFilter).GetMethod(
                "CreateFilter",
                BindingFlags.NonPublic | BindingFlags.Static
            );

            // Act
            var result = method?.Invoke(null, new object[] { prop, op, constant });

            // Assert
            Assert.NotNull(result);
        }

        [Fact]
        public void CreateFilter_GreaterThanOperator_ShouldReturnGreaterThanExpression()
        {
            // Arrange
            var parameter = Expression.Parameter(typeof(SampleEntity), "x");
            var prop = Expression.Property(parameter, nameof(SampleEntity.Age));
            var constant = Expression.Constant(30);
            var op = FilterOperator.GreaterThan;

            var method = typeof(PaginationSortFilter).GetMethod(
                "CreateFilter",
                BindingFlags.NonPublic | BindingFlags.Static
            );

            // Act
            var result = method?.Invoke(null, new object[] { prop, op, constant });

            // Assert
            Assert.NotNull(result);
        }

        [Fact]
        public void CreateFilter_InvalidOperator_ShouldThrowNotImplementedException()
        {
            // Arrange
            var parameter = Expression.Parameter(typeof(SampleEntity), "x");
            var prop = Expression.Property(parameter, nameof(SampleEntity.Name));
            var constant = Expression.Constant("test");
            var op = (FilterOperator)999; // Invalid enum

            var method = typeof(PaginationSortFilter).GetMethod(
                "CreateFilter",
                BindingFlags.NonPublic | BindingFlags.Static
            );

            // Act & Assert
            var ex = Assert.Throws<TargetInvocationException>(() =>
                method?.Invoke(null, new object[] { prop, op, constant })
            );

            Assert.IsType<NotImplementedException>(ex.InnerException);
        }

        // Helper to invoke private static method using reflection
        private static Expression CallRobustEquals(Type entityType, string propertyName, object value)
        {
            var parameter = Expression.Parameter(entityType, "x");
            var prop = Expression.Property(parameter, propertyName);
            var constant = Expression.Constant(value);

            var method = typeof(PaginationSortFilter).GetMethod(
                "RobustEquals",
                BindingFlags.NonPublic | BindingFlags.Static
            );

            return (Expression)method.Invoke(null, new object[] { prop, constant });
        }

        // Test entity for property access
        public class TestEntity
        {
            public int Age { get; set; }
            public string Name { get; set; }
            public bool IsActive { get; set; }
            public DateTime CreatedOn { get; set; }
            public decimal? Amount { get; set; }

            public List<string> Tags { get; set; }
            public Dictionary<string, string> Metadata { get; set; }
        }

        [Fact]
        public void RobustEquals_ShouldGenerateEqualityExpression_ForInt()
        {
            // Act
            var expression = CallRobustEquals(typeof(TestEntity), "Age", "25");

            // Assert
            Assert.NotNull(expression);
            Assert.IsAssignableFrom<BinaryExpression>(expression);
            Assert.Contains("Age", expression.ToString());
            Assert.Contains("25", expression.ToString());
        }

        [Fact]
        public void RobustEquals_ShouldGenerateEqualityExpression_ForBool()
        {
            var expression = CallRobustEquals(typeof(TestEntity), "IsActive", "true");

            Assert.NotNull(expression);
            Assert.Contains("IsActive", expression.ToString());
            Assert.IsAssignableFrom<BinaryExpression>(expression);
            Assert.Contains("True", expression.ToString());
        }

        [Fact]
        public void RobustEquals_ShouldGenerateEqualityExpression_ForDateTime()
        {
            var expression = CallRobustEquals(typeof(TestEntity), "CreatedOn", "2023-01-01");

            Assert.NotNull(expression);
            Assert.Contains("CreatedOn", expression.ToString());
            Assert.IsAssignableFrom<BinaryExpression>(expression);
            Assert.Contains("2023", expression.ToString());
        }

        [Fact]
        public void RobustEquals_ShouldGenerateEqualityExpression_ForDecimalNullable()
        {
            var expression = CallRobustEquals(typeof(TestEntity), "Amount", "123.45");

            Assert.NotNull(expression);
            Assert.Contains("Amount", expression.ToString());
            Assert.IsAssignableFrom<BinaryExpression>(expression);
            Assert.Contains("123.45", expression.ToString());
        }

        [Fact]
        public void RobustEquals_ShouldFallbackToDefaultEquality_IfTypeNotHandled()
        {
            // Simulate unknown/invalid parsing value for decimal
            var parameter = Expression.Parameter(typeof(TestEntity), "x");
            var prop = Expression.Property(parameter, "Amount");
            var constant = Expression.Constant("123.45");

            var method = typeof(PaginationSortFilter).GetMethod("RobustEquals",
                BindingFlags.NonPublic | BindingFlags.Static);

            var expression = method.Invoke(null, [prop, constant]);

            Assert.NotNull(expression);
            Assert.IsAssignableFrom<BinaryExpression>(expression);
        }

        private static MemberExpression GetPropertyExpression(Type type, string propertyName)
        {
            var param = Expression.Parameter(type, "x");
            return Expression.Property(param, propertyName);
        }

        private static Expression CallPrivateRobustEqualsMethod(string methodName, MemberExpression propExpr, object value)
        {
            var method = typeof(PaginationSortFilter).GetMethod(
                methodName,
                BindingFlags.NonPublic | BindingFlags.Static);

            return (Expression)method.Invoke(null, new object[] { propExpr, value });
        }

        [Fact]
        public void RobustEqualsBool_ShouldReturnEqualityExpression()
        {
            var prop = GetPropertyExpression(typeof(TestEntity), "IsActive");
            var expression = CallPrivateRobustEqualsMethod("RobustEqualsBool", prop, true);

            Assert.NotNull(expression);
            Assert.IsAssignableFrom<BinaryExpression>(expression);
            Assert.Contains("IsActive", expression.ToString());
        }

        [Fact]
        public void RobustEqualsINT16_ShouldReturnEqualityExpression()
        {
            var prop = GetPropertyExpression(typeof(TestEntity), "Age");
            var expression = CallPrivateRobustEqualsMethod("RobustEqualsINT16", prop, (short)42);

            Assert.NotNull(expression);
            Assert.IsAssignableFrom<BinaryExpression>(expression);
            Assert.Contains("Age", expression.ToString());
            Assert.Contains("42", expression.ToString());
        }

        [Fact]
        public void RobustEqualsByte_ShouldReturnEqualityExpression()
        {
            var prop = GetPropertyExpression(typeof(TestEntity), "Age");
            var expression = CallPrivateRobustEqualsMethod("RobustEqualsByte", prop, (short)7); // Notice: byteval is passed as short

            Assert.NotNull(expression);
            Assert.IsAssignableFrom<BinaryExpression>(expression);
            Assert.Contains("Age", expression.ToString());
            Assert.Contains("7", expression.ToString());
        }
        [Fact]
        public void RobustContainsIgnoreCase_ShouldReturnValidMethodCallExpression()
        {
            // Arrange
            var param = Expression.Parameter(typeof(TestEntity), "x");
            var property = Expression.Property(param, nameof(TestEntity.Name));
            var constant = Expression.Constant("test");

            var method = typeof(PaginationSortFilter).GetMethod("RobustContainsIgnoreCase",
                BindingFlags.NonPublic | BindingFlags.Static);

            // Act
            var result = (Expression)method.Invoke(null, new object[] { property, constant });

            // Assert
            Assert.NotNull(result);
            Assert.IsAssignableFrom<MethodCallExpression>(result); 

            var methodCall = (MethodCallExpression)result;
            Assert.Equal(nameof(string.Contains), methodCall.Method.Name);
            Assert.Equal(2, methodCall.Arguments.Count); // "value" and "StringComparison"

            Assert.Contains("Name", result.ToString());
            Assert.Contains("OrdinalIgnoreCase", result.ToString());
        }

        [Fact]
        public void RobustEndsWith_ShouldGenerateMethodCallExpression()
        {
            var prop = GetPropertyExpression(typeof(TestEntity), "Name");
            var constant = GetConstantExpression("Test");

            var result = CallPrivateMethod("RobustEndsWith", prop, constant);

            Assert.IsAssignableFrom<MethodCallExpression>(result);
            Assert.Contains("EndsWith", result.ToString());
            Assert.Contains("Test", result.ToString());
        }

        [Fact]
        public void RobustStartsWith_ShouldGenerateMethodCallExpression()
        {
            var prop = GetPropertyExpression(typeof(TestEntity), "Name");
            var constant = GetConstantExpression("Hello");

            var result = CallPrivateMethod("RobustStartsWith", prop, constant);

            Assert.IsAssignableFrom<MethodCallExpression>(result);
            Assert.Contains("StartsWith", result.ToString());
            Assert.Contains("Hello", result.ToString());
        }

        [Fact]
        public void RobustIsEmpty_ShouldCallIsNullOrEmptyMethod()
        {
            var prop = GetPropertyExpression(typeof(TestEntity), "Name");
            var constant = GetConstantExpression("");

            var result = CallPrivateMethod("RobustIsEmpty", prop, constant);

            Assert.IsAssignableFrom<MethodCallExpression>(result);
            Assert.Contains("IsNullOrEmpty", result.ToString());
        }

        [Fact]
        public void RobustIsNotEmpty_ShouldNegateIsNullOrEmptyMethodCall()
        {
            var prop = GetPropertyExpression(typeof(TestEntity), "Name");
            var constant = GetConstantExpression("NotEmpty");

            var result = CallPrivateMethod("RobustIsNotEmpty", prop, constant);

            Assert.IsAssignableFrom<UnaryExpression>(result); // Because it's Expression.Not(...)
            Assert.Contains("IsNullOrEmpty", result.ToString());
        }

        [Fact]
        public void GetContainsMethodCallExpression_ShouldWorkForString()
        {
            var prop = GetPropertyExpression(typeof(TestEntity), "Name");
            var constant = GetConstantExpression("search");

            var result = CallPrivateMethod("GetContainsMethodCallExpression", prop, constant);

            Assert.IsAssignableFrom<MethodCallExpression>(result);
            Assert.Contains("Contains", result.ToString());
        }

        [Fact]
        public void GetContainsMethodCallExpression_ShouldWorkForList()
        {
            var prop = GetPropertyExpression(typeof(TestEntity), "Tags");
            var constant = GetConstantExpression("tag1");

            var result = CallPrivateMethod("GetContainsMethodCallExpression", prop, constant);

            Assert.IsAssignableFrom<MethodCallExpression>(result);
            Assert.Contains("Contains", result.ToString());
        }

        [Fact]
        public void GetContainsMethodCallExpression_ShouldWorkForDictionary()
        {
            var prop = GetPropertyExpression(typeof(TestEntity), "Metadata");
            var constant = GetConstantExpression("key1");

            var result = CallPrivateMethod("GetContainsMethodCallExpression", prop, constant);

            Assert.IsAssignableFrom<BinaryExpression>(result); // Expression.Or
            Assert.Contains("ContainsKey", result.ToString());
            Assert.Contains("ContainsValue", result.ToString());
        }

        [Fact]
        public void GetPredicate_ShouldGenerate_EqualityExpression_For_Int()
        {
            // Act
            var predicate = PaginationSortFilter.GetPredicate<TestEntity>("Age", FilterOperator.Equals, 30);

            // Assert
            Assert.NotNull(predicate);

            var func = predicate.Compile();
            var result = func(new TestEntity { Age = 30 });

            Assert.True(result);
        }

        [Fact]
        public void GetPredicate_ShouldGenerate_ContainsExpression_For_String()
        {
            var predicate = PaginationSortFilter.GetPredicate<TestEntity>("Name", FilterOperator.Contains, "test");

            Assert.NotNull(predicate);

            var func = predicate.Compile();

            // "demo string" does not contain "test"
            var result = func(new TestEntity { Name = "demo string" });
            Assert.False(result);

            // "test case" does contain "test"
            result = func(new TestEntity { Name = "test case" });
            Assert.True(result);
        }

        [Fact]
        public void GetPredicate_ShouldGenerate_NotEqualsExpression()
        {
            var predicate = PaginationSortFilter.GetPredicate<TestEntity>("Age", FilterOperator.DoesntEqual, 25);
            Assert.NotNull(predicate);

            var compiled = predicate.Compile();
            Assert.True(compiled(new TestEntity { Age = 30 }));
            Assert.False(compiled(new TestEntity { Age = 25 }));
        }

        [Fact]
        public void GetPredicate_ShouldThrowException_For_InvalidProperty()
        {
            Assert.Throws<ArgumentException>(() =>
            {
                var _ = PaginationSortFilter.GetPredicate<TestEntity>("InvalidProp", FilterOperator.Equals, "foo");
            });
        }
        [Fact]
        public void GetNestedProperty_ShouldReturn_SimpleProperty()
        {
            var param = Expression.Parameter(typeof(Person), "x");

            var result = CallGetNestedProperty(param, "Name");

            Assert.NotNull(result);
            Assert.Equal("Name", result.Member.Name);
        }

        [Fact]
        public void GetNestedProperty_ShouldReturn_NestedProperty()
        {
            var param = Expression.Parameter(typeof(Person), "x");

            var result = CallGetNestedProperty(param, "Address.City");

            Assert.NotNull(result);
            Assert.Equal("City", result.Member.Name);
            Assert.Contains("Address.City", result.ToString());
        }

        [Fact]
        public void PrepareConstant_ShouldReturnSame_WhenStringType()
        {
            var constant = Expression.Constant("hello");

            var result = CallPrepareConstant(constant);

            Assert.Same(constant, result); // should return the same instance
        }
        private static Expression CallPrepareConstant(ConstantExpression constant)
        {
            var method = typeof(PaginationSortFilter).GetMethod("PrepareConstant", BindingFlags.NonPublic | BindingFlags.Static);
            return (Expression)method.Invoke(null, new object[] { constant });
        }

        [Fact]
        public void PrepareConstant_ShouldCallToString_WhenNotString()
        {
            var constant = Expression.Constant(123); // int, not string

            var result = CallPrepareConstant(constant);

            Assert.NotNull(result);
            Assert.IsAssignableFrom<MethodCallExpression>(result);

            var methodCall = (MethodCallExpression)result;
            Assert.Equal("ToString", methodCall.Method.Name);
        }
    }
}
