﻿using Aurora.AdministrationService.CrossCutting.CommonModels;
using FluentAssertions;

namespace Aurora.AdministrationService.Tests.CrossCutting.CommonModels
{
    public class ResponseMessageTests
    {
        [Theory]
        [InlineData("DUPLICATE_LEAVE_NOTALLOWED", "Duplicate Leave found")]
        [InlineData("STATUS_INVALID_DateValidation", "Start time must be before end time.")]
        [InlineData("SUCCESS_VALUE", "SUCCESS")]
        [InlineData("STATUS_INVALID_ID_PARAM_REQUEST", "The field must be greather than 0 ")]
        [InlineData("STATUS_INVALID_REQUEST", "Invalid Request Parameter")]
        [InlineData("STATUS_SUCCESS", "Success")]
        [InlineData("STATUS_ALREADY_REGISTERED", "Device Already Registered")]
        [InlineData("STATUS_ALREADY_ACTIVATED", "Device Already Activated")]
        [InlineData("STATUS_INPROGRESS", "In Progress")]
        [InlineData("STATUS_NODEVICE_FOUND", "No Device Found")]
        [InlineData("STATUS_INVALIED_TOKEN", "Invalid Token")]
        [InlineData("STATUS_FAILED", "Failed")]
        [InlineData("STATUS_REGISTRATION_FAILED", "Registration Failed")]
        [InlineData("STATUS_SERVER_ERROR", "Internal Server Error, Please Try Later")]
        [InlineData("STATUS_MESSAGE_SENDING_ERROR", "Message Sending Error")]
        [InlineData("STATUS_HOSPITALS_NOT_FOUND", "No Hospital Found")]
        [InlineData("STATUS_NODATA", "Record Not Found")]
        [InlineData("STATUS_DATA_FOUND", "Record Found")]
        [InlineData("STATUS_DATA_ADDED", "Record Added Successfully")]
        [InlineData("STATUS_DATA_UPDATED", "Record Updated Successfully")]
        [InlineData("STATUS_DATA_DELETED", "Record Deleted Successfully")]
        [InlineData("STATUS_DATA_ADD_FAIL", "Record Not Added")]
        [InlineData("STATUS_RECORDS_LOADED", "Records Loaded Successfully.")]
        [InlineData("STATUS_BAD_REQUEST", "One or more validation errors occurred.")]
        [InlineData("STATUS_RECORD_LOADED", "Record Loaded Successfully.")]
        [InlineData("ACCOUNT_ALREADY_EXITS", "Account already exits!")]
        [InlineData("WE_GOT_YOU", "We got you! Since you have already registered with Columbia Asia, click Continue to set up your account.")]
        // 👉 Add ALL other constants here in the same format...

        public void ResponseMessageConstants_ShouldHaveExpectedValues(string constantName, string expectedValue)
        {
            var actualValue = typeof(ResponseMessage).GetField(constantName).GetValue(null)?.ToString();
            actualValue.Should().Be(expectedValue);
        }
    }

    public class ResponseStatusTests
    {
        [Fact]
        public void ResponseStatusConstants_ShouldHaveExpectedValues()
        {
            ResponseStatus.STATUS_SUCCESS.Should().Be("200");
            ResponseStatus.STATUS_BadRequest.Should().Be("400");
            ResponseStatus.STATUS_InternalServerError.Should().Be("500");
        }
    

        [Fact]
        public void StringValidation_WithInt_ShouldReturnTrimmedString()
        {
            string result = ValidationMessage.StringValidation(123);
            result.Should().Be("123");
        }

        [Fact]
        public void TrimStringProperties_ShouldTrimAllStringProperties()
        {
            var testObject = new TestClass
            {
                Name = "  John Doe  ",
                Description = "  Sample Description  ",
                Id = 42
            };

            var result = testObject.TrimStringProperties<TestClass>();

            result.Name.Should().Be("John Doe");
            result.Description.Should().Be("Sample Description");
            result.Id.Should().Be(42); // Non-string properties should remain unchanged
        }

        private class TestClass
        {
            public string Name { get; set; }
            public string Description { get; set; }
            public int Id { get; set; }
        }
    }

    public class LanguageCodeTests
    {
        [Fact]
        public void LanguageCodes_ShouldHaveExpectedValues()
        {
            LanguageCode.MALAYSIA_LANG_CODE.Should().Be("EN");
            LanguageCode.VIETNAM_LANG_CODE.Should().Be("VT");
            LanguageCode.INDONESIA_LANG_CODE.Should().Be("ID");
        }
    }

    public class RegionCodeTests
    {
        private static readonly string[] ExpectedRegionCodes = { "MYS", "VNM", "IDN" };

        [Fact]
        public void RegionCodes_ShouldHaveExpectedValues()
        {
            RegionCode.MALAYSIA_REGION_CODE.Should().Be("MYS");
            RegionCode.VIETNAM_REGION_CODE.Should().Be("VNM");
            RegionCode.INDONESIA_REGION_CODE.Should().Be("IDN");
        }

        [Fact]
        public void AllowedRegionCodes_ShouldContainExpectedValues()
        {
            RegionCode.AllowedRegionCodes.Should().Contain(ExpectedRegionCodes);
        }
    }
}