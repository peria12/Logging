﻿using Aurora.AdministrationService.CrossCutting.ExceptionHandling;
using Microsoft.AspNetCore.Http;
using Moq;
using System;
using System.Collections.Generic;
using System.Net;
using System.Threading.Tasks;
using Xunit;
using FluentAssertions;
using Aurora.AdministrationService.CrossCutting.Constants;
using System.Net.Http;

namespace Aurora.AdministrationService.Tests.CrossCutting.ExceptionHandlingTests
{

    /// <summary>
    /// Unit tests for <see cref="ExceptionHandlingMiddleware"/> class.
    /// </summary>
    /// <remarks>
    /// These tests cover possible usecases for exception handling middlerware.
    /// </remarks>
    public class ExceptionHandlingMiddlewareTests
    {
        private readonly Mock<RequestDelegate> _nextMock;
        private readonly ExceptionHandlingMiddleware _middleware;
        private readonly DefaultHttpContext _context;

        public ExceptionHandlingMiddlewareTests()
        {
            _nextMock = new Mock<RequestDelegate>();
            _middleware = new ExceptionHandlingMiddleware(_nextMock.Object);
            _context = new DefaultHttpContext();
        }

        [Fact]
        public async Task InvokeAsync_NoException_ShouldCallNext()
        {
            // Arrange
            _nextMock.Setup(x => x(It.IsAny<HttpContext>())).Returns(Task.CompletedTask);

            // Act
            await _middleware.InvokeAsync(_context);

            // Assert
            _nextMock.Verify(x => x(It.IsAny<HttpContext>()), Times.Once);
        }

        [Fact]
        public async Task InvokeAsync_ShouldHandle_UnauthorizedException()
        {
            // Arrange
            _context.Response.StatusCode = StatusCodes.Status401Unauthorized;
            var exception = new UnauthorizedAccessException("401:Unauthorized");
            _nextMock.Setup(x => x(It.IsAny<HttpContext>())).ThrowsAsync(exception);

            // Act
            await _middleware.InvokeAsync(_context);

            // Assert
            _context.Response.ContentType.Should().Be("application/json");
            _context.Response.StatusCode.Should().Be(StatusCodes.Status401Unauthorized);
        }

        [Fact]
        public async Task InvokeAsync_ShouldHandle_InternalServerException()
        {
            // Arrange
            _context.Response.StatusCode = StatusCodes.Status500InternalServerError;
            var exception = new Exception("500:Internal Server Error");
            _nextMock.Setup(x => x(It.IsAny<HttpContext>())).ThrowsAsync(exception);

            // Act
            await _middleware.InvokeAsync(_context);

            // Assert
            _context.Response.ContentType.Should().Be("application/json");
            _context.Response.StatusCode.Should().Be((int)HttpStatusCode.InternalServerError);
        }

        [Fact]
        public async Task InvokeAsync_ShouldHandle_TimeoutException()
        {
            // Arrange
            _context.Response.StatusCode = StatusCodes.Status408RequestTimeout;
            var exception = new TimeoutException("408:Request Timeout");
            _nextMock.Setup(x => x(It.IsAny<HttpContext>())).ThrowsAsync(exception);

            // Act
            await _middleware.InvokeAsync(_context);

            // Assert
            _context.Response.ContentType.Should().Be("application/json");
            _context.Response.StatusCode.Should().Be(StatusCodes.Status408RequestTimeout);
        }

        [Fact]
        public async Task InvokeAsync_ShouldHandle_HttpRequestException_503()
        {
            // Arrange
            _context.Response.StatusCode = StatusCodes.Status503ServiceUnavailable;
            var exception = new HttpRequestException("503:Service Unavailable");
            _nextMock.Setup(x => x(It.IsAny<HttpContext>())).ThrowsAsync(exception);

            // Act
            await _middleware.InvokeAsync(_context);

            // Assert
            _context.Response.ContentType.Should().Be("application/json");
            _context.Response.StatusCode.Should().Be(StatusCodes.Status503ServiceUnavailable);
        }

        [Fact]
        public async Task InvokeAsync_ShouldHandle_ArgumentException_400()
        {
            // Arrange
            _context.Response.StatusCode = StatusCodes.Status504GatewayTimeout;
            var exception = new ArgumentException("400:BadRequest");
            _nextMock.Setup(x => x(It.IsAny<HttpContext>())).ThrowsAsync(exception);

            // Act
            await _middleware.InvokeAsync(_context);

            // Assert
            _context.Response.ContentType.Should().Be("application/json");
            _context.Response.StatusCode.Should().Be(StatusCodes.Status400BadRequest);
        }

        [Fact]
        public async Task InvokeAsync_ShouldHandle_KeyNotFoundException_404()
        {
            // Arrange
            _context.Response.StatusCode = StatusCodes.Status404NotFound;
            var exception = new KeyNotFoundException("404:NotFound");
            _nextMock.Setup(x => x(It.IsAny<HttpContext>())).ThrowsAsync(exception);

            // Act
            await _middleware.InvokeAsync(_context);

            // Assert
            _context.Response.ContentType.Should().Be("application/json");
            _context.Response.StatusCode.Should().Be(StatusCodes.Status404NotFound);
        }

        [Fact]
        public async Task InvokeAsync_ShouldHandle_InvalidOperationException_409()
        {
            // Arrange
            _context.Response.StatusCode = StatusCodes.Status409Conflict;
            var exception = new InvalidOperationException("409:Conflict");
            _nextMock.Setup(x => x(It.IsAny<HttpContext>())).ThrowsAsync(exception);

            // Act
            await _middleware.InvokeAsync(_context);

            // Assert
            _context.Response.ContentType.Should().Be("application/json");
            _context.Response.StatusCode.Should().Be(StatusCodes.Status409Conflict);
        }

        [Fact]
        public async Task InvokeAsync_ShouldHandle_NotImplementedException_501()
        {
            // Arrange
            _context.Response.StatusCode = StatusCodes.Status501NotImplemented;
            var exception = new NotImplementedException("501:NotImplemented");
            _nextMock.Setup(x => x(It.IsAny<HttpContext>())).ThrowsAsync(exception);

            // Act
            await _middleware.InvokeAsync(_context);

            // Assert
            _context.Response.ContentType.Should().Be("application/json");
            _context.Response.StatusCode.Should().Be(StatusCodes.Status501NotImplemented);
        }


        // Using Theory to test different status codes
        [Theory]
        [InlineData(HttpStatusCode.Unauthorized)]
        [InlineData(HttpStatusCode.Forbidden)]
        [InlineData(HttpStatusCode.NotFound)]
        [InlineData(HttpStatusCode.MethodNotAllowed)]
        [InlineData(HttpStatusCode.Conflict)]
        [InlineData(HttpStatusCode.Locked)]
        [InlineData(HttpStatusCode.TooManyRequests)]
        public async Task InvokeAsync_ShouldHandleError_WhenStatusCodeIsSet(HttpStatusCode statusCode)
        {
            // Arrange
            _context.Request.Headers[CommonConstants.HeaderCorrelationId] = "test-correlation-id";
            _context.Response.StatusCode = (int)statusCode;

            // Act
            await _middleware.InvokeAsync(_context);

            // Assert
            _context.Response.StatusCode.Should().Be((int)statusCode);
        }

        [Theory]
        [InlineData(typeof(TimeoutException), HttpStatusCode.RequestTimeout)]
        [InlineData(typeof(UnauthorizedAccessException), HttpStatusCode.Unauthorized)]
        [InlineData(typeof(HttpRequestException), HttpStatusCode.ServiceUnavailable)]
        [InlineData(typeof(ArgumentException), HttpStatusCode.BadRequest)]
        [InlineData(typeof(KeyNotFoundException), HttpStatusCode.NotFound)]
        [InlineData(typeof(InvalidOperationException), HttpStatusCode.Conflict)]
        [InlineData(typeof(NotImplementedException), HttpStatusCode.NotImplemented)]
        public async Task InvokeAsync_ShouldHandleException_WhenExceptionIsThrown(Type exceptionType, HttpStatusCode expectedStatusCode)
        {
            // Arrange
            var exception = (Exception)Activator.CreateInstance(exceptionType, "Test message");
            _context.Request.Headers[CommonConstants.HeaderCorrelationId] = "test-correlation-id";
            _context.Response.StatusCode = (int)expectedStatusCode;

            // Act
            await _middleware.InvokeAsync(_context);

            // Assert
            _context.Response.StatusCode.Should().Be((int)expectedStatusCode);
        }
    }
}