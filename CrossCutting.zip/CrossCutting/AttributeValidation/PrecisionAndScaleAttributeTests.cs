﻿using Aurora.AdministrationService.CrossCutting.AttributeValidation;

namespace Aurora.AdministrationService.Tests.CrossCutting.AttributeValidation;

public class PrecisionAndScaleAttributeTests
{
    public static IEnumerable<object[]> GetPrecisionAndScaleTestData()
    {
        yield return new object[] { 5, 2, "123.45", true };
        yield return new object[] { 5, 2, "12345.67", false };
        yield return new object[] { 5, 2, "12.345", false };
        yield return new object[] { 5, 2, "-123.4", true };
        yield return new object[] { 5, 2, "abcd", false };
    }

    [Theory]
    [MemberData(nameof(GetPrecisionAndScaleTestData))]
    public void PrecisionAndScaleAttribute_ShouldValidateCorrectly(int precision, int scale, string input, bool expected)
    {
        var attribute = new PrecisionAndScaleAttribute(precision, scale);
        var isValid = attribute.IsValid(input);
        Assert.Equal(expected, isValid);
    }
}
