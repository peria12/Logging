﻿using Aurora.AdministrationService.Domain.V1.Entities.PractitionerRoles;

namespace Aurora.AdministrationService.Tests.API.CommonMock
{
    public static class PractitionerRoleMock
    {
        public static PractitionerRole GetPractitionerRole()
        {
            return new PractitionerRole
            {
                Id = 10,
                UUID = Guid.NewGuid(),
                PractitionerID = "RES123",  // Should match a Practitioner.ResourceID
                OrganizationID = 1,
                PeriodStart = DateTime.UtcNow,
                PeriodEnd = DateTime.UtcNow,
                ResourceID = "ROLE001",
                LocationID = "KLAN",
                Active = true,
                AvailabilityExceptions = "Unavailable on weekends",
                RecordVersion = [1, 2, 3],
                IsDeleted = false,
                CreatedBy = "TestUser",
                CreatedDate = DateTime.UtcNow.AddDays(-100),
                UpdatedBy = "AdminUser",
                UpdatedDate = DateTime.UtcNow.AddDays(-10),
            };
        }
    }
}
