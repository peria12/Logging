﻿using Aurora.AdministrationService.Domain.V1.Entities.HealthcareService;
namespace Aurora.AdministrationService.Tests.API.CommonMock
{
    public static class HealthCareServiceKeywordsMock
    {
        public static HealthcareServicesKeyWords GetHealthcareServicesKeyWords()
        {
            return new HealthcareServicesKeyWords
            {
                ID = 1,
                HealthcareServicesID = 1,
                Keyword = "brain",
                RecordVersion = new byte[] { 1, 2, 3, 4 },
                IsDeleted = false,
                CreatedBy = "TestUser",
                CreatedDate = DateTime.UtcNow.AddDays(-10),
                UpdatedBy = "AdminUser",
                UpdatedDate = DateTime.UtcNow
            };
        }
    }
}