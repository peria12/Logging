﻿using Aurora.AdministrationService.API.Models.Dto.V1.Agreement;
using Aurora.AdministrationService.API.Models.Dto.V1.FAQ;
using Aurora.AdministrationService.API.Models.RequestModels.V1.Agreement;
using Aurora.AdministrationService.API.Models.RequestModels.V1.Faq;
using Aurora.AdministrationService.API.Models.ResponseModels.V1.AdminDoctor;
using Aurora.AdministrationService.Domain.V1.Entities;

namespace Aurora.AdministrationService.Tests.API.CommonMock;

public static class DTO
{
    public static AgreementDto GetAgreementDto()
    {
        return new AgreementDto()
        {
            Description = "test",
            FrequencyID = 1,
            LanguageID = 1,
            Name = "test",
            UniqueId = "test"
        };
    }
    public static AgreementDto GetUpdateAgreementsRequest()
    {
        return new UpdateAgreementsRequest()
        {
            RecordVersion = new byte[] { 1 },
            Description = "test",
            FrequencyID = 1,
            LanguageID = 1,
            Name = "test",
            UniqueId = "test"
        };
    }
    public static UpdateAgreementsStatusRequest GetUpdateAgreementsStatusRequest()
    {
        return new UpdateAgreementsStatusRequest()
        {
            Status = true
        };
    }
    public static LanguageResponseDto GetLanguageResponseDto()
    {
        return new LanguageResponseDto()
        {
            IsDeleted = false,
            Language = "test"
        };
    }
    public static Agreement GetAgreement()
    {
        return new()
        {
            CreatedBy = "test",
            CreatedDate = DateTime.Now,
            ID = 1,
            IsDeleted = false,
            Status = true,
            UpdatedBy = "test",
            UpdatedDate = DateTime.Now,
            RecordVersion = new byte[] { 1 }
        };
    }
    public static AgreementLanguage GetAgreementLanguage()
    {
        return new()
        {
            AgreementID = 1,
            CreatedBy = "test",
            CreatedDate = DateTime.Now,
            IsDeleted = false,
            Status = true,
            UpdatedBy = "test",
            UpdatedDate = DateTime.Now,
            RecordVersion = new byte[] { 1 }
        };
    }

    public static FaqDto GetFaqDto()
    {
        return new FaqDto()
        {
            Header = "testHeader",
            Description = "testDescription",
            Platforms = "testPlatform",
            Status = true,
            UserType = "testUserType"
        };
    }

    public static FAQ GetFaq()
    {
        return new FAQ { ID = 1, Platforms = "Platform1", RecordVersion = [1], Status = true, IsDeleted = false, CreatedDate = DateTime.UtcNow };
    }

    public static FAQLanguage GetFaqLanguage()
    {
        return new FAQLanguage { Id = 1, Status = true, FAQID = 1, LanguageID = 1,  CreatedDate = DateTime.UtcNow, IsDeleted = false };
    }

    public static FAQUserTypes GetFaqUserTypes()
    {
        return new FAQUserTypes { Id = 1, FAQID = 1, UserType = "Admin", CreatedDate = DateTime.UtcNow, IsDeleted = false };
    }

    public static UpdateFaqRequest GetUpdateFaqsRequest()
    {
        return new UpdateFaqRequest()
        {
            RecordVersion = [1],
            Description = "test",
            LanguageID = 1,
            Header = "testHeader",
            Platforms = "testPlatforms",
            Status = true,
            UserType = "testUserType"
        };
    }
}
