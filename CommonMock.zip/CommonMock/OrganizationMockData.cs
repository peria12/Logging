﻿using Aurora.AdministrationService.Domain.V1.Entities.Organizations;

namespace Aurora.AdministrationService.Tests.API.CommonMock
{
    public static class OrganizationMockData
    {
        public static List<Organization> GetOrganizationFakeData()
        {
            List<Organization> list =
            [
               new Organization
               {
                    Id = 1,
                    ResourceID = "123",
                    Name = "Org1",
                    Status = true,
                    Type = "Hospital",
                    Alias = "O1",
                    PartOf = Guid.NewGuid(),
                    Source = "System",
                    IsDeleted = false,
                    CreatedBy = "Admin",
                    CreatedDate = DateTime.UtcNow,
                    UpdatedBy = "Admin",  // Adding the missing property
                    UpdatedDate = DateTime.UtcNow, // Assuming UpdatedDate is required as well
               },
               new Organization
               {
                    Id = 2,
                    ResourceID = "123",
                    Name = "Org2",
                    Status = true,
                    Type = "Clinic",
                    Alias = "O2",
                    PartOf = Guid.NewGuid(),
                    Source = "User",
                    IsDeleted = false,
                    CreatedBy = "Admin",
                    CreatedDate = DateTime.UtcNow,
                    UpdatedBy = "Admin",  // Adding the missing property
                    UpdatedDate = DateTime.UtcNow, // Assuming UpdatedDate is required as well
               }
            ];
            return list;
        }

        public static Organization GetOrganizationMockData() => new()
        {
            Id = 1,
            ResourceID = "123",
            Name = "Org1",
            Status = true,
            Type = "Hospital",
            Alias = "O1",
            PartOf = Guid.NewGuid(),
            Source = "System",
            IsDeleted = false,
            CreatedBy = "Admin",
            CreatedDate = DateTime.UtcNow,
            UpdatedBy = "Admin",  // Adding the missing property
            UpdatedDate = DateTime.UtcNow, // Assuming UpdatedDate is required as well
        };
    }
}
