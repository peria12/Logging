﻿using Aurora.AdministrationService.Domain.V1.Entities.Locations;
namespace Aurora.AdministrationService.Tests.API.CommonMock
{
    public static class LocationMock
    {
        public static Location GetLocation()
        {
            return new Location
            {
                Id = 1,
                ResourceID = "KLAN",
                Status = true,
                Name = "Main Hospital",
                CreatedBy = "Admin",
                CreatedDate = DateTime.Now
            };
        }
    }
}