﻿using Aurora.AdministrationService.Domain.V1.Entities.HealthcareService;
namespace Aurora.AdministrationService.Tests.API.CommonMock
{
    public static class HealthCareServicesMock
    {
        public static HealthcareServices GetHealthcareServices()
        {
            return new HealthcareServices
            {
                ID = 1,
                Name = "Neur",
                LaymanDescription = "brain related speciality",
                Location = "KLAN",
                Status = true,
                RecordVersion = new byte[] { 1, 2, 3, 4, 5 },
                IsDeleted = false,
                CreatedBy = "TestUser",
                CreatedDate = DateTime.UtcNow.AddDays(-10),
                UpdatedBy = "AdminUser",
                UpdatedDate = DateTime.UtcNow
            };
        }
    }
}
