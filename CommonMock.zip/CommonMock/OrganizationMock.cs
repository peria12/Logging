﻿using Aurora.AdministrationService.Domain.V1.Entities.Organizations;

namespace Aurora.AdministrationService.Tests.API.CommonMock
{
    public static class OrganizationMock
    {
        public static Organization GetOrganization()
        {
            return new Organization
            {
                Id = 1,
                ResourceID = "ORG12345",
                Alias = "Test",
                Name = "Columbia Asia",
                Source = "Aurora",
                Type = "Test1",
                IsDeleted = false,
                CreatedBy = "Admin",
                CreatedDate = DateTime.Now,
                UpdatedBy = "Admin"
            };
        }
    }
}
