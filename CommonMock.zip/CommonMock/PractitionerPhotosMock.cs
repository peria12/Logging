﻿using Aurora.AdministrationService.Domain.V1.Entities.Practitioners;

namespace Aurora.AdministrationService.Tests.API.CommonMock
{
    public static class PractitionerPhotosMock
    {
        public static PractitionerPhotos GetPractitionerPhotos()
        {
            return new PractitionerPhotos
            {
                Id = 1,
                PractitionerID = 1,
                Status = true,
                IsDeleted = false,
                CreatedBy = "Admin",
                CreatedDate = DateTime.Now,
                ContentType = "Json",
                Data = Array.Empty<byte>(),
                Hash = "Test",
                Size = "100",
                Title = "Test1",
                URL = "www.photo.com",
                UpdatedBy = "Admin",
                CreationDate = DateTime.UtcNow
            };
        }
    }
}
