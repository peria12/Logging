﻿using Aurora.AdministrationService.Domain.V1.Entities.Practitioners;
namespace Aurora.AdministrationService.Tests.API.CommonMock
{
    public static class PractitionerMock
    {
        public static Practitioner GetPractitioner()
        {
            return new Practitioner
            {
                Id = 1,
                ResourceID = "RES123",
                Status = true,
                Gender = "male",
                BirthDate = DateTime.UtcNow,
                Source = "TestSystem",
                RecordVersion = new byte[] { 1, 2, 3, 4 },
                IsDeleted = false,
                CreatedBy = "TestUser",
                CreatedDate = DateTime.UtcNow.AddDays(-10),
                UpdatedBy = "AdminUser",
                UpdatedDate = DateTime.UtcNow
            };
        }
    }
}