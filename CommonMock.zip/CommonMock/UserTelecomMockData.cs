﻿using Aurora.AdministrationService.Domain.V1.Entities.Users;

namespace Aurora.AdministrationService.Tests.API.CommonMock
{
    public static class UserTelecomMockData
    {
        public static List<UserTelecom> GetUserTelecomFakeData()
        {
            List<UserTelecom> list =
            [
               new UserTelecom
               {
                   Id = 1,
                   UserID = 1000,
                   Status = true,
                   System = "OtherSystem",
                   Value = "1234567890",
                   CreatedBy = "Admin",
                   CreatedDate = DateTime.UtcNow,
                   IsDeleted=false,
                   UpdatedBy = "Admin",
                   Use = "Test Use",
                   PeriodStart = DateTime.UtcNow,
                   PeriodEnd = DateTime.UtcNow,
                   Rank = 1,
                   UpdatedDate = DateTime.UtcNow,
               },
               new UserTelecom
               {
                    Id = 2,
                    UserID = 1001,
                   Status = true,
                   System = "OtherSystem1",
                   Value = "12345678910",
                   CreatedBy = "Admin",
                   CreatedDate = DateTime.UtcNow,
                   IsDeleted=false,
                   UpdatedBy = "Admin",
                   Use = "Test Use",
                   PeriodStart = DateTime.UtcNow,
                   PeriodEnd = DateTime.UtcNow,
                   Rank = 2,
                   UpdatedDate = DateTime.UtcNow,
               }
            ];
            return list;
        }
    }
}
