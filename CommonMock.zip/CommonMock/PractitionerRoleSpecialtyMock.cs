﻿using Aurora.AdministrationService.Domain.V1.Entities.PractitionerRoles;

namespace Aurora.AdministrationService.Tests.API.CommonMock
{
    public static class PractitionerRoleSpecialtyMock
    {
        public static PractitionerRoleSpecialty GetPractitionerRoleSpecialty()
        {
            return new PractitionerRoleSpecialty
            {
                Id = 100,
                PractitionerRoleID = 10, // This should correspond to an existing PractitionerRole ID
                Specialty = "Neur", // Example specialty
                RecordVersion = [1, 2, 3, 4],
                IsDeleted = false,
                CreatedBy = "TestUser",
                CreatedDate = DateTime.UtcNow.AddMonths(-3),
                UpdatedBy = "AdminUser",
                UpdatedDate = DateTime.UtcNow.AddMonths(-1)
            };
        }
    }
}
