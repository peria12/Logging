﻿using Aurora.AdministrationService.Domain.V1.Entities.Practitioners;

namespace Aurora.AdministrationService.Tests.API.CommonMock
{
    public static class PractitionerNamesMock
    {
        public static PractitionerNames GetPractitionerNames()
        {
            return new PractitionerNames
            {
                Id = 1,
                PractitionerID = 1,
                Use = "official",
                FamilyName = "Doe",
                GivenName = "John",
                MiddleName = "Michael",
                Prefix = "Dr.",
                Suffix = "MD",
                Language = "English",
                PeriodStart = DateTime.Now,
                PeriodEnd = DateTime.Now,
                CreatedBy = "Test",
                CreatedDate = DateTime.UtcNow.AddMonths(-3),
                UpdatedBy = "Test",
                IsDeleted = false,
                Status = true
            };
        }
    }
}
