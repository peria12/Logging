﻿using Aurora.AdministrationService.Domain.V1.Entities;
namespace Aurora.AdministrationService.Tests.API.CommonMock
{
    public static class ManageDoctorProfileMock
    {
        public static ManageDoctorProfile GetManageDoctorProfile()
        {
            return new ManageDoctorProfile
            {
                Id = 1,
                PractitionerID = 1,
                FirstName = "John",
                LastName = "Doe",
                Rank = "A",
                IsDeleted = false,
                CreatedDate = DateTime.Now,
                CreatedBy = "Admin"
            };
        }
    }
}