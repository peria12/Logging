﻿using Aurora.AdministrationService.Domain.V1.Entities.Users;

namespace Aurora.AdministrationService.Tests.API.CommonMock
{
    public static class UsersMockData
    {
        public static User GetUserFakeData()
        {
            return new User
            {
                Id = 1,
                UserName = "admin",
                Password = "hashedpwd",
                Salt = "salt123",
                CreatedBy = "System",
                CreatedDate = System.DateTime.UtcNow,
                UpdatedBy = "System",
                IsDeleted = false,
                NotificationsEnabled = true,
                BioAuthenticationEnabled = true,
                SOSButtonEnabled = true,
                UserType = "Admin",
                Status = true,
                IsTempAccount = false
            };
        }
    }
}
