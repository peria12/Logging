﻿using Aurora.AdministrationService.API.Models.ResponseModels.MarketingMainBanner;
using Aurora.AdministrationService.API.Resources;
using Aurora.AdministrationService.CrossCutting.CommonModels;
using Aurora.AdministrationService.Domain.Old.Entities;
using Aurora.AdministrationService.Infrastructure.IRepository.MarketingMainBanners;
using AutoMapper;
using FluentAssertions;
using Moq;

namespace Aurora.AdministrationService.Tests.API.Services.MarketingMainBannerService
{
    /// <summary>
    /// Unit test class for the MarketingMainBannerService.
    /// Contains tests for various scenarios to validate the service's functionality.
    /// </summary>
    public class MarketingMainBannerServiceTests
    {
        private readonly AdministrationService.API.Services.Service.Old.MarketingMainBanner.MarketingMainBannerService _service;
        private readonly Mock<IMarketingMainBannerRepository> _marketingMainBannerRepositoryMock;
        private readonly Mock<IMapper> _mapperMock;

        /// <summary>
        /// Constructor to initialize mocks and the service instance.
        /// </summary>
        public MarketingMainBannerServiceTests()
        {
            _marketingMainBannerRepositoryMock = new Mock<IMarketingMainBannerRepository>();
            _mapperMock = new Mock<IMapper>();
            _service = new Aurora.AdministrationService.API.Services.Service.Old.MarketingMainBanner.MarketingMainBannerService(_marketingMainBannerRepositoryMock.Object, _mapperMock.Object);
        }

        /// <summary>
        /// Test to verify that GetMarketingMainBanners returns a successful response when the repository provides data.
        /// </summary>
        [Fact]
        public async Task GetMarketingMainBanners_ShouldReturnSuccess_WhenRepositoryReturnsData()
        {
            // Arrange: Set up fake data and mock repository and mapper responses.
            var fakeBannerEntities = new List<MarketingMainBanner> { new MarketingMainBanner() };
            var fakeBannerDtos = new List<MarketingMainBannerDTO> { new MarketingMainBannerDTO() };

            _marketingMainBannerRepositoryMock.Setup(repo => repo.GetMarketingMainBannersAsync())
                .ReturnsAsync(fakeBannerEntities);

            _mapperMock.Setup(mapper => mapper.Map<List<MarketingMainBannerDTO>>(fakeBannerEntities))
                .Returns(fakeBannerDtos);

            // Act: Call the method being tested.
            var result = await _service.GetMarketingMainBanners();

            // Assert: Verify the response matches the expected output.
            result.Should().NotBeNull();
            result.HasError.Should().BeFalse();
            result.IsSuccess.Should().BeTrue();
            result.Results.Should().BeEquivalentTo(fakeBannerDtos);
            result.StatusCode.Should().Be(ResponseStatus.STATUS_SUCCESS);
        }

        /// <summary>
        /// Test to verify that GetMarketingMainBanners returns an internal server error response when an exception occurs.
        /// </summary>
        [Fact]
        public async Task GetMarketingMainBanners_ShouldReturnInternalServerError_WhenExceptionIsThrown()
        {
            // Arrange: Simulate an exception being thrown by the repository.
            _marketingMainBannerRepositoryMock.Setup(repo => repo.GetMarketingMainBannersAsync())
                .ThrowsAsync(new Exception("Test Exception"));

            // Act: Call the method being tested.
            var result = await _service.GetMarketingMainBanners();

            // Assert: Verify the response indicates an error occurred.
            result.Should().NotBeNull();
            result.HasError.Should().BeTrue();
            result.IsSuccess.Should().BeFalse();
            result.StatusCode.Should().Be(ResponseStatus.STATUS_InternalServerError);
            result.Results.Should().BeNull();
            result.Message.Should().Be(Resource.LogMessage);
        }

        /// <summary>
        /// Test to verify that GetMarketingMainBanners returns a success response with an empty list when no data is available.
        /// </summary>
        [Fact]
        public async Task GetMarketingMainBanners_ShouldReturnSuccessWithEmptyList_WhenRepositoryReturnsEmptyList()
        {
            // Arrange: Set up the repository to return an empty list.
            var emptyBannerEntities = new List<MarketingMainBanner>();
            var emptyBannerDtos = new List<MarketingMainBannerDTO>();

            _marketingMainBannerRepositoryMock.Setup(repo => repo.GetMarketingMainBannersAsync())
                .ReturnsAsync(emptyBannerEntities);

            _mapperMock.Setup(mapper => mapper.Map<List<MarketingMainBannerDTO>>(emptyBannerEntities))
                .Returns(emptyBannerDtos);

            // Act: Call the method being tested.
            var result = await _service.GetMarketingMainBanners();

            // Assert: Verify the response is successful and contains an empty list.
            result.Should().NotBeNull();
            result.HasError.Should().BeFalse();
            result.IsSuccess.Should().BeTrue();
            result.Results.Should().BeEquivalentTo(emptyBannerDtos);
            result.StatusCode.Should().Be(ResponseStatus.STATUS_SUCCESS);
        }
    }
}
