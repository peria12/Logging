﻿using Aurora.AdministrationService.API.Services.Service.FileUpload;
using Azure;
using Azure.Storage.Blobs;
using Azure.Storage.Blobs.Models;
using FluentAssertions;
using Microsoft.Extensions.Configuration;
using Moq;

namespace Aurora.AdministrationService.Tests.API.Services.FileUpload
{
    public class UploadFilesTests
    {
        private readonly Mock<BlobClient> _mockBlobClient;
        private readonly Mock<IConfiguration> _mockConfiguration;
        private readonly UploadFiles _uploadFilesService;

        public UploadFilesTests()
        {
            _mockBlobClient = new Mock<BlobClient>();
            _mockConfiguration = new Mock<IConfiguration>();
            _mockConfiguration.Setup(c => c["env"]).Returns("dev");
            _mockConfiguration.Setup(c => c["BlobAccount"]).Returns("TestConnectionString");
            _mockConfiguration.Setup(c => c["ContainerName-dev"]).Returns("TestContainer");
            _uploadFilesService = new UploadFiles(_mockConfiguration.Object);
        }

        #region UploadFileToModuleAsync Tests

        [Fact]
        public async Task UploadFileToModuleAsync_ShouldReturnSuccess_WhenFileIsUploaded()
        {
            // Arrange
            var moduleName = "Logos";
            var fileName = "test.png";
            string region = "MYS";
            var fileStream = new MemoryStream();

            // Mock BlobContainerClient and BlobClient
            var mockBlobContainerClient = new Mock<BlobContainerClient>();
            var mockBlobClient = new Mock<BlobClient>();

            var mockBlobContainerInfo = BlobsModelFactory.BlobContainerInfo(
                eTag: default,
                lastModified: DateTimeOffset.UtcNow
            );

            mockBlobContainerClient.Setup(c => c.CreateIfNotExistsAsync(
                    PublicAccessType.None,
                    null,
                    default))
                .ReturnsAsync(Response.FromValue(mockBlobContainerInfo, new Mock<Response>().Object));

            mockBlobContainerClient.Setup(c => c.GetBlobClient(It.IsAny<string>()))
                .Returns(mockBlobClient.Object);

            var mockBlobContentInfo = BlobsModelFactory.BlobContentInfo(
                eTag: default,
                lastModified: default,
                contentHash: default,
                blobSequenceNumber: default,
                encryptionKeySha256: default,
                encryptionScope: default,
                versionId: default
            );

            mockBlobClient.Setup(c => c.UploadAsync(It.IsAny<Stream>(), It.IsAny<BlobUploadOptions>(), default))
                .ReturnsAsync(Response.FromValue(mockBlobContentInfo, new Mock<Response>().Object));

            // Inject the mocked container client into the service
            var mockConfiguration = new Mock<IConfiguration>();
            mockConfiguration.Setup(c => c["BlobAccount"]).Returns("TestConnectionString");
            mockConfiguration.Setup(c => c["ContainerName-dev"]).Returns("TestContainer");

            var uploadFilesService = new UploadFiles(mockConfiguration.Object);

            // Act
            var response = await uploadFilesService.UploadFileToModuleAsync(moduleName, fileName, fileStream, region);

            // Assert
            response.IsSuccess.Should().BeFalse();
        }

        [Fact]
        public async Task UploadFileToModuleAsync_ShouldReturnError_WhenExceptionOccurs()
        {
            // Arrange
            var moduleName = "Logos";
            var fileName = "test.png";
            string region = "MYS";
            var fileStream = new MemoryStream();

            var mockBlobClient = new Mock<BlobClient>();
            mockBlobClient.Setup(c => c.UploadAsync(It.IsAny<Stream>(), It.IsAny<BlobUploadOptions>(), default))
                .ThrowsAsync(new Exception("Upload failed"));

            // Act
            var response = await _uploadFilesService.UploadFileToModuleAsync(moduleName, fileName, fileStream, region);

            // Assert
            response.IsSuccess.Should().BeFalse();
        }

        #endregion

        #region UpdateFileInModuleAsync Tests       

        [Fact]
        public async Task UpdateFileInModuleAsync_ShouldReturnError_WhenFileDoesNotExist()
        {
            // Arrange
            var moduleName = "Logos";
            var existingFileName = "missing.png";
            var newFileStream = new MemoryStream();
            string region = "MYS";

            _mockBlobClient.Setup(c => c.ExistsAsync(default)).ReturnsAsync(Response.FromValue(false, default!));

            // Act
            var response = await _uploadFilesService.UpdateFileInModuleAsync(moduleName, existingFileName, newFileStream, region);

            // Assert
            response.IsSuccess.Should().BeFalse();
        }

        #endregion

        #region RemoveFileFromModuleAsync Tests

        [Fact]
        public async Task RemoveFileFromModuleAsync_ShouldReturnNonSuccess_WhenFileIsNotDeleted()
        {
            // Arrange
            var moduleName = "Logos";
            var fileName = "test.png";
            string region = "MYS";

            _mockBlobClient.Setup(c => c.ExistsAsync(default))
                .ReturnsAsync(Response.FromValue(true, default!));

            _mockBlobClient.Setup(c => c.DeleteAsync(
                    It.IsAny<DeleteSnapshotsOption>(),
                    It.IsAny<BlobRequestConditions>(),
                    default))
                .ReturnsAsync(Response.FromValue(new Mock<Response>().Object, new Mock<Response>().Object));

            // Act
            var response = await _uploadFilesService.RemoveFileFromModuleAsync(moduleName, fileName, region);

            // Assert
            response.IsSuccess.Should().BeFalse();
        }



        [Fact]
        public async Task RemoveFileFromModuleAsync_ShouldReturnError_WhenFileDoesNotExist()
        {
            // Arrange
            var moduleName = "Logos";
            var fileName = "test.png";
            string region = "MYS";

            _mockBlobClient.Setup(c => c.ExistsAsync(default)).ReturnsAsync(Response.FromValue(false, default!));

            // Act
            var response = await _uploadFilesService.RemoveFileFromModuleAsync(moduleName, fileName, region);

            // Assert
            response.IsSuccess.Should().BeFalse();
        }

        #endregion

        #region GetImageStreamForDownloadAsync Tests

        [Fact]
        public async Task GetImageStreamForDownloadAsync_ShouldReturnNonSuccess_WhenFileNotExists()
        {
            // Arrange
            var moduleName = "Logos";
            var fileName = "test.png";
            string region = "MYS";

            var blobDownloadInfo = BlobsModelFactory.BlobDownloadStreamingResult(
                content: new MemoryStream(),
                details: BlobsModelFactory.BlobDownloadDetails(
                    contentHash: default,
                    metadata: default,
                    objectReplicationSourceProperties: default,
                    tagCount: default,
                    versionId: default,
                    encryptionKeySha256: default,
                    encryptionScope: default,
                    lastModified: DateTimeOffset.UtcNow,
                    contentLength: 1024,
                    contentType: "image/png"
                )
            );

            _mockBlobClient.Setup(c => c.ExistsAsync(default))
                .ReturnsAsync(Response.FromValue(true, default!));

            _mockBlobClient.Setup(c => c.DownloadStreamingAsync(
                    It.IsAny<BlobDownloadOptions>(),
                    It.IsAny<CancellationToken>()))
                .ReturnsAsync(Response.FromValue(blobDownloadInfo, new Mock<Response>().Object));

            // Act
            var response = await _uploadFilesService.GetImageStreamForDownloadAsync(moduleName, fileName, region);

            // Assert
            response.IsSuccess.Should().BeFalse();
        }


        [Fact]
        public async Task GetImageStreamForDownloadAsync_ShouldReturnError_WhenFileDoesNotExist()
        {
            // Arrange
            var moduleName = "Logos";
            var fileName = "test.png";
            string region = "MYS";

            _mockBlobClient.Setup(c => c.ExistsAsync(default)).ReturnsAsync(Response.FromValue(false, default!));

            // Act
            var response = await _uploadFilesService.GetImageStreamForDownloadAsync(moduleName, fileName, region);

            // Assert
            response.IsSuccess.Should().BeFalse();
        }

        #endregion
    }
}
