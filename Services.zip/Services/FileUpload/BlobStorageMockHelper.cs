﻿using System.Diagnostics.CodeAnalysis;
using Azure;
using Azure.Storage.Blobs;
using Azure.Storage.Blobs.Models;
using Moq;

namespace Aurora.AdministrationService.Tests.API.Services.FileUpload
{
    /// <summary>
    /// Provides helper methods to create mock instances of Azure Blob Storage clients for unit testing.
    /// </summary>
    public static class BlobStorageMockHelper
    {
        /// <summary>
        /// Creates a mock instance of <see cref="BlobContainerClient"/> to simulate interactions with Azure Blob Storage.
        /// </summary>
        /// <param name="existingBlobs">A list of existing blob names (optional).</param>
        /// <param name="blobStreams">A dictionary mapping blob names to their corresponding stream data (optional).</param>
        /// <returns>A mock instance of <see cref="BlobContainerClient"/>.</returns>
        public static Mock<BlobContainerClient> CreateMockBlobContainerClient(
            List<string> existingBlobs = null,
            Dictionary<string, Stream> blobStreams = null)

        {
            existingBlobs ??= new List<string>();
            blobStreams ??= new Dictionary<string, Stream>();

            var mockBlobContainerClient = new Mock<BlobContainerClient>();

            // Setup GetBlobClient to return a mock BlobClient
            mockBlobContainerClient
                .Setup(c => c.GetBlobClient(It.IsAny<string>()))
                .Returns<string>(blobName =>
                {
                    if (!existingBlobs.Contains(blobName))
                        existingBlobs.Add(blobName);

                    return CreateMockBlobClient(blobName, blobStreams).Object;
                });

            // Setup GetBlobsAsync to simulate listing blobs in the container
            mockBlobContainerClient
                .Setup(c => c.GetBlobsAsync(It.IsAny<BlobTraits>(), It.IsAny<BlobStates>(), null, It.IsAny<CancellationToken>()))
                .Returns(AsyncPageable<BlobItem>.FromPages(
                    new[]
                    {
                        Page<BlobItem>.FromValues(
                            existingBlobs.ConvertAll(name => BlobsModelFactory.BlobItem(name)),
                            continuationToken: null,
                            response: default!
                        )
                    }
                ));

            return mockBlobContainerClient;
        }

        /// <summary>
        /// Creates a mock instance of <see cref="BlobClient"/> to simulate interactions with individual blobs.
        /// </summary>
        /// <param name="blobName">The name of the blob.</param>
        /// <param name="blobStreams">A dictionary mapping blob names to their corresponding stream data.</param>
        /// <returns>A mock instance of <see cref="BlobClient"/>.</returns>
        private static Mock<BlobClient> CreateMockBlobClient(string blobName, Dictionary<string, Stream> blobStreams)
        {
            var mockBlobClient = new Mock<BlobClient>();

            // Setup ExistsAsync to check if a blob exists
            mockBlobClient
                .Setup(c => c.ExistsAsync(It.IsAny<CancellationToken>()))
                .ReturnsAsync(Response.FromValue(blobStreams.ContainsKey(blobName), default!));

            // Setup UploadAsync to simulate blob upload operation
            mockBlobClient
                .Setup(c => c.UploadAsync(It.IsAny<Stream>(), It.IsAny<bool>(), It.IsAny<CancellationToken>()))
                .ReturnsAsync(() =>
                {
                    blobStreams[blobName] = new MemoryStream(); // Store mock stream
                    return Response.FromValue(BlobsModelFactory.BlobContentInfo(
                        eTag: new ETag("mock-etag"),
                        lastModified: DateTimeOffset.UtcNow,
                        contentHash: null,
                        blobSequenceNumber: 0,
                        encryptionKeySha256: null,
                        encryptionScope: null
                    ), default!); // Use default! instead of null
                });

            // Setup DeleteAsync to simulate blob deletion
            mockBlobClient
                .Setup(c => c.DeleteAsync(It.IsAny<DeleteSnapshotsOption>(), null, It.IsAny<CancellationToken>()))
                .Returns(() =>
                {
                    blobStreams.Remove(blobName); // Directly remove without ContainsKey check
                    return Task.CompletedTask;
                });


            // Setup Uri to return a mock URL for the blob
            mockBlobClient
                .Setup(c => c.Uri)
                .Returns(new Uri($"https://mock.blob.core.windows.net/container/{blobName}"));

            return mockBlobClient;
        }
    }
}
