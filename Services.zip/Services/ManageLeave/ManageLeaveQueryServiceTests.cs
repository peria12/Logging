﻿using Aurora.AdministrationService.API.Models.RequestModels.Leaves;
using Aurora.AdministrationService.API.Models.RequestModels.ManageLeaveDto;
using Aurora.AdministrationService.API.Services.Service.ManageLeaves;
using Aurora.AdministrationService.Domain.V1.Entities.PractitionerRoles;
using Aurora.AdministrationService.Domain.V1.Entities.Practitioners;
using Aurora.AdministrationService.Infrastructure;
using FluentAssertions;
using Microsoft.EntityFrameworkCore;

namespace Aurora.AdministrationService.Tests.API.Services.Schedule
{
    public class ManageQueryServiceTests
    {
        private readonly ReadOnlyDbContext _mockDbContext;
        private readonly ManageLeaveQueryService _scheduleQueryService;
        public ManageQueryServiceTests()
        {
            // Set up in-memory database
            var options = new DbContextOptionsBuilder<ReadOnlyDbContext>()
                .UseInMemoryDatabase(databaseName: Guid.NewGuid().ToString())
                .Options;

            _mockDbContext = new ReadOnlyDbContext(options);
            // Set up the mock for HealthcareServices DbSet
            var hcs1 = new Domain.V1.Entities.HealthcareService.HealthcareServices { ID = 1, Name = "Service 1", Location = "Location 1", CreatedBy = "Admin", IsDeleted = false, CreatedDate = DateTime.UtcNow, RecordVersion = Array.Empty<byte>(), Status = true };
            var hcs2 = new Domain.V1.Entities.HealthcareService.HealthcareServices { ID = 2, Name = "Service 2", Location = "Location 2", CreatedBy = "Admin", IsDeleted = false, CreatedDate = DateTime.UtcNow, RecordVersion = Array.Empty<byte>(), Status = true };
            var hcs3 = new Domain.V1.Entities.HealthcareService.HealthcareServices { ID = 3, Name = "Service 3", Location = "Location 3", CreatedBy = "Admin", IsDeleted = true, CreatedDate = DateTime.UtcNow, RecordVersion = Array.Empty<byte>(), Status = true };

            _mockDbContext.HealthcareServices.Add(hcs1);
            _mockDbContext.HealthcareServices.Add(hcs2);
            _mockDbContext.HealthcareServices.Add(hcs3);
            _mockDbContext.SaveChanges();

            // Initialize the service
            _scheduleQueryService = new ManageLeaveQueryService(_mockDbContext);
            SeedDatabase();
        }

        private void SeedDatabase()
        {
            var practitioner = new Practitioner
            {
                Id = 11,
                ResourceID = "123",
                Status = true,
                Gender = "Male",
                BirthDate = new DateTime(1985, 5, 10, 1, 1, 1, DateTimeKind.Utc),
                Source = "Internal",
                IsDeleted = false,
                CreatedBy = "Admin",
                CreatedDate = DateTime.UtcNow,
                UpdatedBy = "Admin",
                UpdatedDate = DateTime.UtcNow
            };
            _mockDbContext.Practitioners.Add(practitioner);

            var location = new Domain.V1.Entities.Locations.Location
            {
                Id = 1,
                ResourceID = "KLAN",
                Status = true,
                OperationalStatus = "Operational",
                Name = "Main Office",
                Alias = "HQ",
                Description = "Main office for healthcare services",
                Mode = "In-person",
                Longitude = -74.0060m,
                Latitude = 40.7128m,
                Altitude = 33.0m,
                PhysicalType = "Building",
                ManagingOrganization = Guid.NewGuid(),
                PartOf = "Healthcare System A",
                AvailabilityExceptions = "Closed on public holidays",
                Source = "Internal",
                URL = "https://www.example.com",
                IsDeleted = false,
                CreatedBy = "Admin",
                CreatedDate = DateTime.UtcNow,
                UpdatedBy = "Admin",
                UpdatedDate = DateTime.UtcNow
            };
            _mockDbContext.Locations.Add(location);

            var healthcareService = new Domain.V1.Entities.HealthcareService.HealthcareServices
            {
                ID = 11,
                Name = "Cardio",
                LaymanDescription = "Cardiology-Specialists for heart",
                Location = "Main Office",
                Status = true,
                RecordVersion = Array.Empty<byte>(),
                IsDeleted = false,
                CreatedBy = "Admin",
                CreatedDate = DateTime.UtcNow,
                UpdatedBy = "Admin",
                UpdatedDate = DateTime.UtcNow
            };

            _mockDbContext.HealthcareServices.Add(healthcareService);

            var practitionerRole = new PractitionerRole
            {
                Id = 1,
                UUID = Guid.NewGuid(),
                PractitionerID = practitioner.ResourceID,
                LocationID = location.ResourceID,
                OrganizationID = 123,
                PeriodStart = DateTime.UtcNow,
                PeriodEnd = DateTime.UtcNow.AddYears(1),
                Active = true,
                AvailabilityExceptions = "None",
                IsDeleted = false,
                CreatedBy = "Admin",
                CreatedDate = DateTime.UtcNow,
                UpdatedBy = "Admin",
                UpdatedDate = DateTime.UtcNow,
                Practitioner = practitioner,
                Location = location
            };

            _mockDbContext.PractitionerRoles.Add(practitionerRole);

            // Adding PractitionerRoleSpecialty data
            var practitionerRoleSpecialty = new PractitionerRoleSpecialty
            {
                Id = 1,
                PractitionerRoleID = practitionerRole.Id,
                Specialty = "Cardio",
                RecordVersion = Array.Empty<byte>(),
                IsDeleted = false,
                CreatedBy = "Admin",
                CreatedDate = DateTime.UtcNow,
                UpdatedBy = "Admin",
                UpdatedDate = DateTime.UtcNow
            };

            _mockDbContext.PractitionerRoleSpecialty.Add(practitionerRoleSpecialty);

            // Link HealthcareService to PractitionerRoleSpecialty (if needed)
            practitionerRoleSpecialty.HealthcareService = healthcareService;

            var practitionerAvailability1 = new PractitionerAvailability
            {
                Id = 1,
                PractitionerRoleId = 1,
                SlotsID = 1,
                ScheduleStartDate = new DateTime(2025, 01, 01, 0, 0, 0, DateTimeKind.Utc),
                ScheduleEndDate = DateTime.Today.AddDays(7),
                Instruction = "General availability",
                IsDeleted = false,
                CreatedBy = "Admin",
                CreatedDate = DateTime.UtcNow,
                UpdatedBy = "Admin",
                UpdatedDate = DateTime.UtcNow
            };
            _mockDbContext.PractitionerAvailabilities.Add(practitionerAvailability1);

            var availabilityDay1 = new PractitionerAvailabilityDay
            {
                Id = 1,
                PractitionerAvailabilityID = practitionerAvailability1.Id,
                AvailabilityDay = "Monday",
                StartTime = new TimeSpan(9, 30, 0),
                EndTime = new TimeSpan(12, 30, 0),
                AllDay = false,
                IsDeleted = false,
                CreatedBy = "Admin",
                CreatedDate = DateTime.UtcNow,
                UpdatedBy = "Admin",
                UpdatedDate = DateTime.UtcNow
            };
            var availabilityDay2 = new PractitionerAvailabilityDay
            {
                Id = 2,
                PractitionerAvailabilityID = practitionerAvailability1.Id,
                AvailabilityDay = "Tuesday",
                StartTime = new TimeSpan(9, 30, 0),
                EndTime = new TimeSpan(15, 30, 0),
                AllDay = false,
                IsDeleted = false,
                CreatedBy = "Admin",
                CreatedDate = DateTime.UtcNow,
                UpdatedBy = "Admin",
                UpdatedDate = DateTime.UtcNow
            };
            _mockDbContext.PractitionerAvailabilityDays.Add(availabilityDay1);
            _mockDbContext.PractitionerAvailabilityDays.Add(availabilityDay2);

            var availabilityOccurance1 = new PractitionerAvailabilityOccurance
            {
                Id = 1,
                PractitionerAvailabilityDayID = availabilityDay1.Id,
                OccuranceType = "First",
                IsDeleted = false,
                CreatedBy = "Admin",
                CreatedDate = DateTime.UtcNow,
                UpdatedBy = "Admin",
                UpdatedDate = DateTime.UtcNow
            };

            var availabilityOccurance2 = new PractitionerAvailabilityOccurance
            {
                Id = 2,
                PractitionerAvailabilityDayID = availabilityDay2.Id,
                OccuranceType = "Fifth",
                IsDeleted = false,
                CreatedBy = "Admin",
                CreatedDate = DateTime.UtcNow,
                UpdatedBy = "Admin",
                UpdatedDate = DateTime.UtcNow
            };
            var availabilityOccurance3 = new PractitionerAvailabilityOccurance
            {
                Id = 3,
                PractitionerAvailabilityDayID = availabilityDay2.Id,
                OccuranceType = "All",
                IsDeleted = false,
                CreatedBy = "Admin",
                CreatedDate = DateTime.UtcNow,
                UpdatedBy = "Admin",
                UpdatedDate = DateTime.UtcNow
            };
            var availabilityOccurance4 = new PractitionerAvailabilityOccurance
            {
                Id = 4,
                PractitionerAvailabilityDayID = availabilityDay1.Id,
                OccuranceType = "All",
                IsDeleted = false,
                CreatedBy = "Admin",
                CreatedDate = DateTime.UtcNow,
                UpdatedBy = "Admin",
                UpdatedDate = DateTime.UtcNow
            };
            _mockDbContext.PractitionerAvailabilityOccurances.Add(availabilityOccurance1);
            _mockDbContext.PractitionerAvailabilityOccurances.Add(availabilityOccurance2);
            _mockDbContext.PractitionerAvailabilityOccurances.Add(availabilityOccurance3);
            _mockDbContext.PractitionerAvailabilityOccurances.Add(availabilityOccurance4);

            var availabilityBreak = new PractitionerAvailabilityBreak
            {
                Id = 1,
                PractitionerAvailabilityDayID = availabilityDay1.Id,
                BreakTitle = "Lunch Break",
                StartTime = new TimeSpan(12, 0, 0),
                EndTime = new TimeSpan(12, 30, 0),
                IsDeleted = false,
                CreatedBy = "Admin",
                CreatedDate = DateTime.UtcNow,
                UpdatedBy = "Admin",
                UpdatedDate = DateTime.UtcNow
            };
            _mockDbContext.PractitionerAvailabilityBreaks.Add(availabilityBreak);

            var availabilityBreak1 = new PractitionerAvailabilityBreak
            {
                Id = 11,
                PractitionerAvailabilityDayID = availabilityDay2.Id,
                BreakTitle = "Coffee Break",
                StartTime = new TimeSpan(12, 0, 0),
                EndTime = new TimeSpan(12, 30, 0),
                IsDeleted = false,
                CreatedBy = "Admin",
                CreatedDate = DateTime.UtcNow,
                UpdatedBy = "Admin",
                UpdatedDate = DateTime.UtcNow
            };
            _mockDbContext.PractitionerAvailabilityBreaks.Add(availabilityBreak1);

            // Adding Practitioner Not Available Slots
            var practitionerNotAvailable1 = new PractitionerNotAvailable
            {
                Id = 11,
                PractitionerID = practitioner.Id,
                StartDateTime = new DateTime(2025, 03, 11, 0, 0, 0, DateTimeKind.Utc),
                EndDateTime = new DateTime(2025, 03, 15, 0, 0, 0, DateTimeKind.Utc),
                Description = "Emergency",
                IsworkingDay = false,
                IsDeleted = false,
                CreatedBy = "Admin",
                CreatedDate = DateTime.UtcNow,
                UpdatedBy = "Admin",
                UpdatedDate = DateTime.UtcNow
            };
            var practitionerNotAvailable2 = new PractitionerNotAvailable
            {
                Id = 12,
                PractitionerID = practitioner.Id,
                StartDateTime = new DateTime(2025, 03, 17, 12, 0, 0, DateTimeKind.Utc),
                EndDateTime = new DateTime(2025, 03, 17, 12, 30, 0, DateTimeKind.Utc),
                Description = "Lunch Break",
                IsworkingDay = true,
                IsDeleted = false,
                CreatedBy = "Admin",
                CreatedDate = DateTime.UtcNow,
                UpdatedBy = "Admin",
                UpdatedDate = DateTime.UtcNow
            };
            _mockDbContext.PractitionerNotAvailables.Add(practitionerNotAvailable1);
            _mockDbContext.PractitionerNotAvailables.Add(practitionerNotAvailable2);

            var practitionerIdentifier = new PractitionerIdentifier
            {
                PractitionerID = 11,

                Value = "ABC",
                Id = 3,
                IdentifierUse = "test",
                IdentifierType = "Test",
                PeriodEnd = DateTime.Now,
                PeriodStart = DateTime.Now,
                Status = true,
                CreatedBy = "admin",
                UpdatedBy = "admin",
                CreatedDate = DateTime.Now,
                System = "test",
                IsDeleted = false
            };

            _mockDbContext.PractitionerIdentifiers.Add(practitionerIdentifier);
            _mockDbContext.SaveChanges();
        }



        [Fact]
        public void GetScheduleLeaveAsync_ReturnsEmptyList_WhenNoManageLeaveFound()
        {
            // Arrange
            // _scheduleQueryService.Clear(); // No schedules


            // Act
            var result = _scheduleQueryService.GetManageLeaveService(3, "ABC123");

            // Assert
            result.Should().NotBeNull();
            result.Should().BeEmpty();
        }

        [Fact]
        public void GetScheduleLeaveAsync_ReturnsList_WhenManageLeaveFound()
        {
            // Act
            var result = _scheduleQueryService.GetManageLeaveService(11, "KLAN");

            // Assert
            result.Should().NotBeNull(); 
            Assert.Single(result);
            Assert.Equal("Lunch Break", result[0].Description);
            Assert.False(result[0].IsWorkingDay);
        }
        [Fact]
        public void GetHasValidPractitionerIdentifierAsync_ReturnsList_WhenManageLeaveFound()
        {
            var leavesRequestDto = new ManageLeavesRequestDto
            {
                practitionerId = 1,
            };

            // Act
            var result = _scheduleQueryService.HasValidPractitionerIdentifier(leavesRequestDto);

            // Assert
            result.Should().NotBeNull();
        }
        [Fact]
        public async Task IsDuplicateLeaveAsync_ShouldReturnFalse_WhenCreateRequestIsNull()
        {
            // Act
            var result = await _scheduleQueryService.IsDuplicateLeaveAsync(null);

            // Assert
            Assert.False(result);
        }
        [Fact]
        public async Task IsDuplicateLeaveAsync_ShouldReturnTrue_WhenOverlappingLeavesExist()
        {
            // Arrange
            var request = new ManageLeavesRequestDto
            {
                practitionerId = 3,
                newTimeOff = new List<TimeOffAddRequestDto>
            {
                new TimeOffAddRequestDto
                {

                    IsWorkingDay= true,
                   StartDateTime = new DateTime(2025, 03, 12, 1, 0, 0, DateTimeKind.Utc),
                   EndDateTime = new DateTime(2025, 03, 12, 3, 0, 0, DateTimeKind.Utc),
                   Description="test",
                },
                new TimeOffAddRequestDto
                {

                    IsWorkingDay= true,
                   StartDateTime = new DateTime(2025, 03, 12, 4, 0, 0, DateTimeKind.Utc),
                   EndDateTime = new DateTime(2025, 03, 12, 5, 0, 0, DateTimeKind.Utc),
                   Description="test",
                }
            }
            };

            // Act
            var result = await _scheduleQueryService.IsDuplicateLeaveAsync(request);

            // Assert
            result.Should().BeFalse();
        }
    }
}