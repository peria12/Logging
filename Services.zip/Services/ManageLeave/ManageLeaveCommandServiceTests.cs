﻿using Aurora.AdministrationService.API.Enum;
using Aurora.AdministrationService.API.Models.RequestModels.Leaves;
using Aurora.AdministrationService.API.Models.RequestModels.ManageLeaveDto;
using Aurora.AdministrationService.API.Services.IService.AzureBus;
using Aurora.AdministrationService.API.Services.Service.Schedule;
using Aurora.AdministrationService.CrossCutting.CommonModels;
using Aurora.AdministrationService.CrossCutting.Constants;
using Aurora.AdministrationService.Domain.V1.Entities.Contents;
using Aurora.AdministrationService.Domain.V1.Entities.PractitionerRoles;
using Aurora.AdministrationService.Infrastructure;
using FluentAssertions;
using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Diagnostics;
using Microsoft.EntityFrameworkCore.Infrastructure;
using Microsoft.EntityFrameworkCore.Storage;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.Logging;
using Moq;

namespace Aurora.AdministrationService.Tests.API.Services.Schedule
{
    public class ManageLeaveCommandServiceTests
    {
        private readonly Mock<ReadWriteDbContext> _readWriteDbContextMock;
        private readonly ManageLeaveCommandService _service;
        private readonly Mock<IAzureBusCommandServices> _azureBusCommandServicesMock;
        private readonly Mock<IConfiguration> _mockConfiguration;
        private readonly Mock<ILogger<ManageLeaveCommandService>> _loggerMock;
        private readonly ReadWriteDbContext _context;

        public ManageLeaveCommandServiceTests()
        {
            // Initialize the mocks
            _readWriteDbContextMock = new Mock<ReadWriteDbContext>();
            _azureBusCommandServicesMock = new Mock<IAzureBusCommandServices>();
            _mockConfiguration = new Mock<IConfiguration>();
            _loggerMock = new Mock<ILogger<ManageLeaveCommandService>>();

            // Setup in-memory ready only database for testing
            DbContextOptions<ReadWriteDbContext> options = new DbContextOptionsBuilder<ReadWriteDbContext>()
              .UseInMemoryDatabase(databaseName: "ScheduleTestDB").Options;

            _readWriteDbContextMock = new(options);

            // Initialize the service being tested
            _service = new ManageLeaveCommandService(
               _context,
               _azureBusCommandServicesMock.Object,
               _mockConfiguration.Object,
               _loggerMock.Object);
        }
        [Fact]
        public async Task CreateManageLeaveAsync_ShouldReturnFalse_WhenRequestIsInvalid()
        {
            // Arrange
            var options = new DbContextOptionsBuilder<ReadWriteDbContext>()
    .UseInMemoryDatabase(databaseName: Guid.NewGuid().ToString())
    .ConfigureWarnings(b => b.Ignore(InMemoryEventId.TransactionIgnoredWarning)).Options;

            await using var context = new ReadWriteDbContext(options);
            var service = new ManageLeaveCommandService(context, _azureBusCommandServicesMock.Object, _mockConfiguration.Object, _loggerMock.Object);
            // Arrange
            var request = new ManageLeavesRequestDto
            {
                practitionerId = 1,
                newTimeOff = new List<TimeOffAddRequestDto>(), // Still testing the invalid case (empty list)
                Action = "Create",
                Type = "Leave",
                LocationResourceId = "loc-001",
                NewOverrides = string.Empty,
                RemovedOverrides = string.Empty,
                PractitionerIdentifiers = new List<PractitionerIdentifierRequestDto>()
            };

            // Act
            var result = await service.CreateManageLeaveAsync(request);

            // Assert
            result.result.Should().BeFalse();
            result.message.Should().Be(CommonConstants.DUPLICATE_NOTALLOWED);
        }
        [Fact]
        public async Task CreateManageLeaveAsync_ShouldReturnFalse_WhenDateRangeInvalid()
        {
            // Arrange
            var options = new DbContextOptionsBuilder<ReadWriteDbContext>()
    .UseInMemoryDatabase(databaseName: Guid.NewGuid().ToString())
    .ConfigureWarnings(b => b.Ignore(InMemoryEventId.TransactionIgnoredWarning)).Options;

            await using var context = new ReadWriteDbContext(options);
            var service = new ManageLeaveCommandService(context, _azureBusCommandServicesMock.Object, _mockConfiguration.Object, _loggerMock.Object);
            var request = new ManageLeavesRequestDto
            {
                practitionerId = 1,
                newTimeOff = new List<TimeOffAddRequestDto>
        {
            new TimeOffAddRequestDto
            {

                StartDateTime = DateTime.UtcNow.AddDays(1),
                EndDateTime = DateTime.UtcNow, // Invalid: Start > End
                Description = "Invalid Leave",
                IsWorkingDay = false
            }
        }
            };

            // Act
            var result = await service.CreateManageLeaveAsync(request);

            // Assert
            result.result.Should().BeTrue();
        }
        [Fact]
        public async Task CreateManageLeaveAsync_ShouldReturnSuccess_WhenValidRequest()
        {
            // Arrange
            var options = new DbContextOptionsBuilder<ReadWriteDbContext>()
  .UseInMemoryDatabase(databaseName: Guid.NewGuid().ToString())
  .ConfigureWarnings(b => b.Ignore(InMemoryEventId.TransactionIgnoredWarning)).Options;

            await using var context = new ReadWriteDbContext(options);
            var service = new ManageLeaveCommandService(context, _azureBusCommandServicesMock.Object, _mockConfiguration.Object, _loggerMock.Object);
            var request = new ManageLeavesRequestDto
            {
                practitionerId = 1,
                PractitionerIdentifiers = new List<PractitionerIdentifierRequestDto>
                {
                    new PractitionerIdentifierRequestDto
                    {
                        IdentifierType="test",
                        IdentifierUse="test",
                        PeriodEnd=DateTime.UtcNow,
                        PeriodStart=DateTime.UtcNow,
                        System="test",
                        Value="demo"
                    }
                },
                newTimeOff = new List<TimeOffAddRequestDto>
        {
            new TimeOffAddRequestDto
            {

                StartDateTime = DateTime.UtcNow,
                EndDateTime = DateTime.UtcNow.AddDays(1),
                Description = "Personal Leave",
                IsWorkingDay = false
            }
        }
            };

            _readWriteDbContextMock.Setup(x => x.PractitionerNotAvailables.AddRangeAsync(It.IsAny<IEnumerable<PractitionerNotAvailable>>(), default));
            _readWriteDbContextMock.Setup(x => x.SaveChangesAsync(default)).ReturnsAsync(1);

            // Act
            var result = await service.CreateManageLeaveAsync(request);

            // Assert
            result.result.Should().BeTrue();
            result.message.Should().Be(CommonConstants.SUCCESS);
        }
        [Fact]
        public async Task CreateManageLeaveAsync_ShouldReturnFailure_WhenSaveChangesFails()
        {
            // Arrange
            var request = new ManageLeavesRequestDto
            {
                practitionerId = 1,
                PractitionerIdentifiers = new List<PractitionerIdentifierRequestDto>
                {
                    new PractitionerIdentifierRequestDto
                    {
                        IdentifierType="test",
                        IdentifierUse="test",
                        PeriodEnd=DateTime.UtcNow,
                        PeriodStart=DateTime.UtcNow,
                        System="test",
                        Value="demo"
                    }
                },
                newTimeOff = new List<TimeOffAddRequestDto>
        {
            new TimeOffAddRequestDto
            {

                StartDateTime = DateTime.UtcNow,
                EndDateTime = DateTime.UtcNow.AddDays(1),
                Description = "Personal Leave",
                IsWorkingDay = false
            }
        }
            };

            var dbContextMock = new Mock<ReadWriteDbContext>(
                new DbContextOptionsBuilder<ReadWriteDbContext>()
                    .UseInMemoryDatabase(Guid.NewGuid().ToString())
                    .Options);

            var dbFacadeMock = new Mock<DatabaseFacade>(dbContextMock.Object);
            var transactionMock = new Mock<IDbContextTransaction>();
            dbFacadeMock.Setup(f => f.BeginTransactionAsync(default))
                        .ReturnsAsync(transactionMock.Object);

            dbContextMock.SetupGet(x => x.Database).Returns(dbFacadeMock.Object);
            dbContextMock.Setup(x => x.SaveChangesAsync(default)).ThrowsAsync(new Exception("Save failure"));

            var service = new ManageLeaveCommandService(
                dbContextMock.Object,
                _azureBusCommandServicesMock.Object,
                _mockConfiguration.Object, _loggerMock.Object
                );

            // Act
            var result = await service.CreateManageLeaveAsync(request);

            // Assert
            result.result.Should().BeFalse();
            result.message.Should().Be(CommonConstants.Failed);
            transactionMock.Verify(x => x.RollbackAsync(It.IsAny<CancellationToken>()), Times.Once);
        }


        [Fact]
        public async Task UpdateManageLeaveAsync_NullRequest_ReturnsFalse()
        {
            var options = new DbContextOptionsBuilder<ReadWriteDbContext>()
       .UseInMemoryDatabase(databaseName: Guid.NewGuid().ToString())
         .ConfigureWarnings(b => b.Ignore(InMemoryEventId.TransactionIgnoredWarning)).Options;

            await using var context = new ReadWriteDbContext(options);
            var service = new ScheduleCommandService(context, _azureBusCommandServicesMock.Object, _mockConfiguration.Object);
            var result = await service.UpdateScheduleLeaveAsync(null);
            result.result.Should().BeFalse();
            result.message.Should().Be(CommonConstants.DUPLICATE_NOTALLOWED);
        }


        [Fact]
        public async Task UpdateManageLeaveAsync_InvalidRequest_ReturnsFalse()
        {
            var options = new DbContextOptionsBuilder<ReadWriteDbContext>()
       .UseInMemoryDatabase(databaseName: Guid.NewGuid().ToString())
         .ConfigureWarnings(b => b.Ignore(InMemoryEventId.TransactionIgnoredWarning)).Options;

            await using var context = new ReadWriteDbContext(options);
            var service = new ScheduleCommandService(context, _azureBusCommandServicesMock.Object, _mockConfiguration.Object);
            var request = new ScheduleLeavesRequestDto { practitionerId = 1 }; // Assuming IsValidRequest returns false for this
            var result = await service.UpdateScheduleLeaveAsync(request);
            result.result.Should().BeFalse();
            result.message.Should().Be(CommonConstants.DUPLICATE_NOTALLOWED);
        }
        [Fact]
        public async Task UpdateManageLeaveAsync_ExceptionThrown_ReturnsFalse()
        {
            var options = new DbContextOptionsBuilder<ReadWriteDbContext>()
       .UseInMemoryDatabase(databaseName: Guid.NewGuid().ToString())
         .ConfigureWarnings(b => b.Ignore(InMemoryEventId.TransactionIgnoredWarning)).Options;

            await using var context = new ReadWriteDbContext(options);
            var service = new ScheduleCommandService(context, _azureBusCommandServicesMock.Object, _mockConfiguration.Object);
            _readWriteDbContextMock.Setup(m => m.SaveChangesAsync(default)).ThrowsAsync(new Exception("Test Exception"));

            var request = new ScheduleLeavesRequestDto
            {
                practitionerId = 1,
                removeTimeOff = new List<TimeOffUpdateRequestDto>(),
                newTimeOff = new List<TimeOffAddRequestDto>()
            };

            var result = await service.UpdateScheduleLeaveAsync(request);

            result.result.Should().BeFalse();
        }


        [Fact]
        public async Task UpdateManageLeaveAsync_ValidRequest_RemovesExistingLeave()
        {
            var options = new DbContextOptionsBuilder<ReadWriteDbContext>()
      .UseInMemoryDatabase(databaseName: Guid.NewGuid().ToString())
        .ConfigureWarnings(b => b.Ignore(InMemoryEventId.TransactionIgnoredWarning)).Options;

            await using var context = new ReadWriteDbContext(options);
            var service = new ScheduleCommandService(context, _azureBusCommandServicesMock.Object, _mockConfiguration.Object);
            // Arrange
            var now = DateTime.UtcNow;

            var request = new ManageLeavesRequestDto
            {
                practitionerId = 1,
                newTimeOff = new List<TimeOffAddRequestDto>
        {
            new TimeOffAddRequestDto
            {
                StartDateTime = now,
                EndDateTime = now.AddDays(1),
                Description = "Personal Leave",
                IsWorkingDay = true
            }
        },
                removeTimeOff = new List<TimeOffUpdateRequestDto>
        {
            new TimeOffUpdateRequestDto
            {
                StartDateTime = now,
                EndDateTime = now.AddHours(1),
                IsDelete = true,
                Description="Test demo"


            }
        }
            };

            var existingLeave = new PractitionerNotAvailable
            {
                PractitionerID = 1,
                StartDateTime = request.removeTimeOff.First().StartDateTime,
                EndDateTime = request.removeTimeOff.First().EndDateTime,
                IsDeleted = false,
                Description = "test",
                IsworkingDay = true,
                CreatedBy = "admin",
                UpdatedBy = "admin",
                UpdatedDate = DateTime.UtcNow,
                CreatedDate = DateTime.UtcNow,
            };
            context.PractitionerNotAvailables.Add(existingLeave);
            await context.SaveChangesAsync();
            // Act
            var result = await service.UpdateScheduleLeaveAsync(request);

            // Assert
            result.result.Should().BeTrue();

            existingLeave.IsDeleted.Should().BeTrue();
        }
        [Fact]
        public async Task UpdateManageLeaveAsync_Should_Add_New_Leaves_When_Request_Is_Valid()
        {
            var options = new DbContextOptionsBuilder<ReadWriteDbContext>()
       .UseInMemoryDatabase(databaseName: Guid.NewGuid().ToString())
         .ConfigureWarnings(b => b.Ignore(InMemoryEventId.TransactionIgnoredWarning)).Options;

            await using var context = new ReadWriteDbContext(options);
            var service = new ScheduleCommandService(context, _azureBusCommandServicesMock.Object, _mockConfiguration.Object);
            var practitionerId = 1;
            var newLeaves = new List<TimeOffAddRequestDto>
            {
                new TimeOffAddRequestDto
                {
                    StartDateTime = DateTime.UtcNow.AddDays(1),
                    EndDateTime = DateTime.UtcNow.AddDays(1).AddHours(2),
                    Description = "Leave for conference",
                    IsWorkingDay = false
                }
            };

            var request = new ScheduleLeavesRequestDto
            {
                Action = "Add",
                Type = "Leave",
                practitionerId = practitionerId,
                LocationResourceId = "LOC001",
                newTimeOff = newLeaves,
                removeTimeOff = new List<TimeOffUpdateRequestDto>(),
                NewOverrides = "",
                RemovedOverrides = "",
                PractitionerIdentifiers = new List<PractitionerIdentifierRequestDto>()
            };

            _readWriteDbContextMock.Setup(x => x.PractitionerNotAvailables.AddRangeAsync(It.IsAny<IEnumerable<PractitionerNotAvailable>>(), default));
            _readWriteDbContextMock.Setup(m => m.SaveChangesAsync(default)).ReturnsAsync(1);

            var result = await service.UpdateScheduleLeaveAsync(request);

            result.result.Should().BeTrue();
            result.message.Should().Be(CommonConstants.SUCCESS);
        }
        [Fact]
        public async Task UpdateManageLeaveAsync_ValidRequest_ExceptionExistingLeave()
        {

            // Arrange
            var options = new DbContextOptionsBuilder<ReadWriteDbContext>()
       .UseInMemoryDatabase(databaseName: Guid.NewGuid().ToString())
         .ConfigureWarnings(b => b.Ignore(InMemoryEventId.TransactionIgnoredWarning)).Options;

            await using var context = new ReadWriteDbContext(options);
            var service = new ScheduleCommandService(context, _azureBusCommandServicesMock.Object, _mockConfiguration.Object);
            var now = DateTime.UtcNow;

            var request = new ScheduleLeavesRequestDto
            {
                practitionerId = 1,
                newTimeOff = new List<TimeOffAddRequestDto>
        {
            new TimeOffAddRequestDto
            {
                StartDateTime = now,
                EndDateTime = now.AddDays(1),
                Description = "Personal Leave",
                IsWorkingDay = true
            }
        },
                removeTimeOff = new List<TimeOffUpdateRequestDto>
        {
            new TimeOffUpdateRequestDto
            {
                StartDateTime = now,
                EndDateTime = now.AddHours(1)

            }
        }
            };

            var existingLeave = new PractitionerNotAvailable
            {
                PractitionerID = 1,
                StartDateTime = request.removeTimeOff.First().StartDateTime,
                EndDateTime = request.removeTimeOff.First().EndDateTime,
                IsDeleted = false,
                Description = "test",
                IsworkingDay = true,
                CreatedBy = "admin",
                UpdatedBy = "admin",
                UpdatedDate = DateTime.UtcNow,
                CreatedDate = DateTime.UtcNow,
            };
            _readWriteDbContextMock.Setup(x => x.PractitionerNotAvailables.AddRangeAsync(It.IsAny<IEnumerable<PractitionerNotAvailable>>(), default));
            _readWriteDbContextMock.Setup(m => m.SaveChangesAsync(default)).ReturnsAsync(1);

            var result = await service.UpdateScheduleLeaveAsync(request);


            // Assert
            result.result.Should().BeTrue();

            existingLeave.IsDeleted.Should().BeFalse();
        }
        [Fact]
        public async Task UpdateManageLeaveAsync_Should_Add_Multiple_Leaves_When_Request_Valid()
        {
            var options = new DbContextOptionsBuilder<ReadWriteDbContext>()
                .UseInMemoryDatabase(databaseName: Guid.NewGuid().ToString())
                .ConfigureWarnings(x => x.Ignore(InMemoryEventId.TransactionIgnoredWarning)) // 👈 fix
                .Options;

            await using var context = new ReadWriteDbContext(options);
            var service = new ManageLeaveCommandService(context, _azureBusCommandServicesMock.Object, _mockConfiguration.Object, _loggerMock.Object);

            var newLeaves = new List<TimeOffAddRequestDto>
    {
        new TimeOffAddRequestDto
        {
            StartDateTime = DateTime.UtcNow.AddDays(1),
            EndDateTime = DateTime.UtcNow.AddDays(2),
            Description = "Leave 1",
            IsWorkingDay = false
        },
        new TimeOffAddRequestDto
        {
            StartDateTime = DateTime.UtcNow.AddDays(3),
            EndDateTime = DateTime.UtcNow.AddDays(4),
            Description = "Leave 2",
            IsWorkingDay = false
        }
    };

            var request = new ManageLeavesRequestDto
            {
                practitionerId = 1,
                newTimeOff = newLeaves
            };

            // Act
            var result = await service.UpdateManageLeaveAsync(request);

            // Assert
            result.result.Should().BeTrue();
            var addedLeaves = await context.PractitionerNotAvailables.ToListAsync();
            addedLeaves.Should().HaveCount(2);
        }
        [Fact]
        public async Task UpdateScheduleLeaveAsync_ValidRequest_RemovesExistingLeave()
        {
            var options = new DbContextOptionsBuilder<ReadWriteDbContext>()
       .UseInMemoryDatabase(databaseName: Guid.NewGuid().ToString())
         .ConfigureWarnings(b => b.Ignore(InMemoryEventId.TransactionIgnoredWarning)).Options;

            await using var context = new ReadWriteDbContext(options);
            var service = new ManageLeaveCommandService(context, _azureBusCommandServicesMock.Object, _mockConfiguration.Object, _loggerMock.Object);
            // Arrange
            var now = DateTime.UtcNow;

            var request = new ManageLeavesRequestDto
            {
                practitionerId = 1,
                newTimeOff = new List<TimeOffAddRequestDto>
        {
            new TimeOffAddRequestDto
            {
                StartDateTime = now,
                EndDateTime = now.AddDays(1),
                Description = "Personal Leave",
                IsWorkingDay = true
            }
        },
                removeTimeOff = new List<TimeOffUpdateRequestDto>
        {
            new TimeOffUpdateRequestDto
            {
                StartDateTime = now,
                EndDateTime = now.AddHours(1),
                IsDelete = true,
                Description="Test demo"


            }
        }
            };

            var existingLeave = new PractitionerNotAvailable
            {
                PractitionerID = 1,
                StartDateTime = request.removeTimeOff.First().StartDateTime,
                EndDateTime = request.removeTimeOff.First().EndDateTime,
                IsDeleted = false,
                Description = "test",
                IsworkingDay = true,
                CreatedBy = "admin",
                UpdatedBy = "admin",
                UpdatedDate = DateTime.UtcNow,
                CreatedDate = DateTime.UtcNow,
            };
            context.PractitionerNotAvailables.Add(existingLeave);
            await context.SaveChangesAsync();
            // Act
            var result = await service.UpdateManageLeaveAsync(request);

            // Assert
            result.result.Should().BeTrue();

            existingLeave.IsDeleted.Should().BeTrue();
        }
        [Fact]
        public async Task UpdateManageLeaveAsync_WhenSaveChangesFails_ReturnsFalseAndRollsBack()
        {
            // Arrange
            var options = new DbContextOptionsBuilder<ReadWriteDbContext>()
                .UseInMemoryDatabase(databaseName: Guid.NewGuid().ToString())
                .ConfigureWarnings(b => b.Ignore(InMemoryEventId.TransactionIgnoredWarning))
                .Options;

            await using var context = new ReadWriteDbContext(options);

            var service = new ManageLeaveCommandService(
                context,
                _azureBusCommandServicesMock.Object,
                _mockConfiguration.Object, _loggerMock.Object);

            var malformedLeave = new TimeOffAddRequestDto
            {
                StartDateTime = DateTime.UtcNow,
                EndDateTime = DateTime.UtcNow.AddHours(1),
                Description = null, // This is required in your model, will cause exception
                IsWorkingDay = true
            };

            var request = new ManageLeavesRequestDto
            {
                practitionerId = 1,
                newTimeOff = new List<TimeOffAddRequestDto> { malformedLeave },
                removeTimeOff = new List<TimeOffUpdateRequestDto>()
            };

            // Act
            var result = await service.UpdateManageLeaveAsync(request);

            // Assert
            result.result.Should().BeFalse();
            result.message.Should().Be(CommonConstants.Failed);
        }

        [Fact]
        public async Task ScheduleLeaveTimeOffServiceBusConnect_ValidInput_SendsPayloadAndReturnsSuccess()
        {
            // Arrange
            var newLeaves = new List<PractitionerNotAvailable>
    {
        new PractitionerNotAvailable
        {
            PractitionerID = 1,
            StartDateTime = DateTime.UtcNow.AddHours(2),
            EndDateTime = DateTime.UtcNow.AddHours(4),
            IsDeleted = false,
            Description = "demo",
            UpdatedBy = "admin",
            UpdatedDate = DateTime.Now,
            IsworkingDay = false,
            CreatedBy = "admin",
            CreatedDate = DateTime.Now
        }
    };

            var removedLeaves = new List<PractitionerNotAvailable>
    {
        new PractitionerNotAvailable
        {
            PractitionerID = 1,
            StartDateTime = DateTime.UtcNow.AddHours(2),
            EndDateTime = DateTime.UtcNow.AddHours(4),
            IsDeleted = false,
            Description = "demo",
            UpdatedBy = "admin",
            UpdatedDate = DateTime.Now,
            IsworkingDay = false,
            CreatedBy = "admin",
            CreatedDate = DateTime.Now
        }
    };

            var practitionerIdentifiers = new List<PractitionerIdentifierRequestDto>
    {
        new PractitionerIdentifierRequestDto
        {
            IdentifierType = "test",
            IdentifierUse = "test",
            PeriodEnd = DateTime.UtcNow,
            PeriodStart = DateTime.UtcNow,
            System = "test",
            Value = "demo"
        }
    };

            // Mock configuration to return expected key
            _mockConfiguration
                .Setup(x => x[$"{CommonConstants.ServiceBusSection}:{CommonConstants.ScheduleLeaveTimeOffBusKey}"])
                .Returns("dummy-service-bus-key");

            // Mock the service bus call
            _azureBusCommandServicesMock
                .Setup(bus => bus.SendData(It.IsAny<ManageLeavesRequestDto>(), It.IsAny<string>(), It.IsAny<string>()))
                .ReturnsAsync(new GenericResponse<string> { IsSuccess = true, Result = "OK" });

            // Act
            var result = await _service.ManageLeaveTimeOffServiceBusConnect(newLeaves, removedLeaves, practitionerIdentifiers, "dummy-location-id", EventAction.Update);

            // Assert
            Assert.Equal(1, result); // Check that success count is 1
            _azureBusCommandServicesMock.Verify(
                x => x.SendData(It.IsAny<ManageLeavesRequestDto>(), RegionCode.MALAYSIA_REGION_CODE, "dummy-service-bus-key"),
                Times.Once); // Verify the service bus was called exactly once
        }
    }
}