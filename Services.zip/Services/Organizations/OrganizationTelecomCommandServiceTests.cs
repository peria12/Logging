﻿using Aurora.AdministrationService.API.Models.RequestModels.OrganizationTelecoms;
using Aurora.AdministrationService.API.Services.Service.OrganizationTelecoms;
using Aurora.AdministrationService.Domain.V1.Entities.Organizations;
using Aurora.AdministrationService.Infrastructure;
using AutoMapper;
using Microsoft.EntityFrameworkCore;
using Moq;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Aurora.AdministrationService.Tests.API.Services.Organizations
{
    public class OrganizationTelecomCommandServiceTests
    {
        private readonly Mock<ReadWriteDbContext> _readWriteDbContextMock;
        private readonly Mock<ReadOnlyDbContext> _readOnlyDbContextMock;
        private readonly Mock<IMapper> _mapperMock;
        private OrganizationTelecomCommandService _organizationTelecomCommandService;
        private readonly Mock<OrganizationTelecomQueryService> _organizationTelecomQueryService;

        public OrganizationTelecomCommandServiceTests()
        {
            // Initialize the mocks
            _mapperMock = new Mock<IMapper>();
            _readWriteDbContextMock = new Mock<ReadWriteDbContext>();
            _readOnlyDbContextMock = new Mock<ReadOnlyDbContext>();
            _organizationTelecomQueryService = new Mock<OrganizationTelecomQueryService>();


            // Setup in-memory ready only database for testing
            DbContextOptions<ReadWriteDbContext> options = new DbContextOptionsBuilder<ReadWriteDbContext>()
              .UseInMemoryDatabase(databaseName: "AdminOrganizationTelecomTestDB").Options;

            _readWriteDbContextMock = new(options);

            // Initialize the service being tested
            _organizationTelecomCommandService = new OrganizationTelecomCommandService(_readWriteDbContextMock.Object, _mapperMock.Object);
        }

        [Fact]
        public async Task CreateOrganizationTelecomAsync_ShouldReturnTrue_WhenOrganizationTelecomIsCreatedSuccessfully()
        {
            // Arrange
            var newOrganizationTelecom = new CreateOrganizationTelecomRequest
            {
                Id = 1,
                Value = "1234567",
                PeriodStart = DateTime.UtcNow,
                PeriodEnd = DateTime.UtcNow,
                Rank = 1,
                System = "Home",
                Use = "Home",
                OrganizationID = 1
            };

            // Mock AutoMapper to return a OrganizationTelecom entity
            var organizationTelecomId = 1;
            var organizationTelecomEntity = new OrganizationTelecom
            { 
                Id = 1, 
                Value = "1234567", 
                PeriodStart = DateTime.UtcNow, 
                PeriodEnd = DateTime.UtcNow, 
                IsDeleted = false, 
                CreatedBy = "Admin", 
                CreatedDate = DateTime.UtcNow, 
                Rank = 1, 
                System = "Home", 
                Use = "Home", 
                OrganizationID = 1 
            };


            // Mock AutoMapper to return the OrganizationTelecom entity
            _mapperMock.Setup(m => m.Map<OrganizationTelecom>(newOrganizationTelecom)).Returns(organizationTelecomEntity);

            // Mock DbContext to simulate saving the entity without actually hitting the database
            _readWriteDbContextMock.Setup(db => db.OrganizationTelecoms.Add(It.IsAny<OrganizationTelecom>()));

            // Act
            var result = await _organizationTelecomCommandService.CreateOrganizationTelecomAsync(newOrganizationTelecom);

            // Assert
            Assert.True(result);
            _readWriteDbContextMock.Verify(db => db.OrganizationTelecoms.Add(It.Is<OrganizationTelecom>(l => l.System == "Home")), Times.Once);
        }


        [Fact]
        public async Task CreateOrganizationTelecomAsync_ShouldReturnFalse_WhenExceptionOccurs()
        {
            // Arrange
            var newOrganizationTelecom = new CreateOrganizationTelecomRequest
            {
                Id = 1,
                Value = "1234567",
                PeriodStart = DateTime.UtcNow,
                PeriodEnd = DateTime.UtcNow,
                Rank = 1,
                System = "Home",
                Use = "Home",
                OrganizationID = 1
            };

            // Mock AutoMapper to return a OrganizationTelecom entity
            var organizationTelecomId = 1;
            var organizationTelecomEntity = new OrganizationTelecom
            {
                Id = 1,
                Value = "1234567",
                PeriodStart = DateTime.UtcNow,
                PeriodEnd = DateTime.UtcNow,
                IsDeleted = false,
                CreatedBy = "Admin",
                CreatedDate = DateTime.UtcNow,
                Rank = 1,
                System = "Home",
                Use = "Home",
                OrganizationID = 1
            };

            //Setup
            _mapperMock.Setup(m => m.Map<OrganizationTelecom>(newOrganizationTelecom)).Returns(organizationTelecomEntity);

            // Act
            var result = await _organizationTelecomCommandService.CreateOrganizationTelecomAsync(newOrganizationTelecom);

            // Assert
            Assert.False(result);
        }
        [Fact]
        public async Task Test_UpdateOrganizationTelecom_Returns_Success()
        {
            //Arrange
            DbContextOptions<ReadWriteDbContext> options = new DbContextOptionsBuilder<ReadWriteDbContext>()
               .UseInMemoryDatabase(databaseName: "UpdateOrganizationTelecom").Options;

            byte[] concurrencyToken = new byte[8] { byte.MinValue, byte.MinValue, byte.MinValue, byte.MinValue, byte.MinValue, byte.MinValue, byte.MinValue, byte.MaxValue };
            var organizationTelecom = new OrganizationTelecom
            {
                Id = 1,
                Value = "1234567",
                PeriodStart = DateTime.UtcNow,
                PeriodEnd = DateTime.UtcNow,
                IsDeleted = false,
                CreatedBy = "Admin",
                CreatedDate = DateTime.UtcNow,
                Rank = 1,
                System = "Home",
                Use = "Home",
                OrganizationID = 1,
                UpdatedBy = "Admin",  // Adding the missing property
                UpdatedDate = DateTime.UtcNow,// Assuming UpdatedDate is required as well
                RecordVersion = concurrencyToken
            };


            //Arrange
            using ReadWriteDbContext dbContext = new(options);
            dbContext.OrganizationTelecoms.Add(organizationTelecom);
            await dbContext.SaveChangesAsync();


            UpdateOrganizationTelecomRequest updateModel = new UpdateOrganizationTelecomRequest
            {
                Id = 1,
                Value = "1234567",
                PeriodStart = DateTime.UtcNow,
                PeriodEnd = DateTime.UtcNow,
                Rank = 1,
                System = "Home",
                Use = "Home",
                OrganizationID = 1
            };

            //updateModel.ID = 1;
            updateModel.RecordVersion = organizationTelecom.RecordVersion;

            _organizationTelecomCommandService = new OrganizationTelecomCommandService(dbContext, _mapperMock.Object);

            // Act
            bool result = await _organizationTelecomCommandService.UpdateOrganizationTelecomAsync(updateModel, organizationTelecom);

            Assert.True(result);
        }
        [Fact]
        public async Task Test_DeleteOrganizationTelecom_Returns_Success()
        {
            //Arrange
            DbContextOptions<ReadWriteDbContext> options = new DbContextOptionsBuilder<ReadWriteDbContext>()
               .UseInMemoryDatabase(databaseName: "DeleteOrganizationTelecom").Options;

            byte[] concurrencyToken = new byte[8] { byte.MinValue, byte.MinValue, byte.MinValue, byte.MinValue, byte.MinValue, byte.MinValue, byte.MinValue, byte.MaxValue };
            var organizationTelecom = new OrganizationTelecom
            {
                Id = 1,
                Value = "1234567",
                PeriodStart = DateTime.UtcNow,
                PeriodEnd = DateTime.UtcNow,
                IsDeleted = false,
                CreatedBy = "Admin",
                CreatedDate = DateTime.UtcNow,
                Rank = 1,
                System = "Home",
                Use = "Home",
                OrganizationID = 1,
                UpdatedBy = "Admin",  // Adding the missing property
                UpdatedDate = DateTime.UtcNow,// Assuming UpdatedDate is required as well
                RecordVersion = concurrencyToken
            };



            //Arrange
            using ReadWriteDbContext dbContext = new(options);
            dbContext.OrganizationTelecoms.Add(organizationTelecom);
            await dbContext.SaveChangesAsync();

            _organizationTelecomCommandService = new OrganizationTelecomCommandService(dbContext, _mapperMock.Object);

            // Act
            bool result = await _organizationTelecomCommandService.DeleteOrganizationTelecomByIdAsync(concurrencyToken, organizationTelecom);

            Assert.True(result);
        }
    }
}
