﻿using Aurora.AdministrationService.API.Models.RequestModels.Doctors;
using Aurora.AdministrationService.API.Models.RequestModels.Organizations;
using Aurora.AdministrationService.API.Models.ResponseModels.Organizations;
using Aurora.AdministrationService.API.Models.ResponseModels.OrganizationTelecoms;
using Aurora.AdministrationService.API.Services.IService.Organizations;
using Aurora.AdministrationService.API.Services.Service.Organizations;
using Aurora.AdministrationService.Domain.Entities;
using Aurora.AdministrationService.Domain.V1.Entities.Organizations;
using Aurora.AdministrationService.Infrastructure;
using AutoMapper;
using Microsoft.EntityFrameworkCore;
using Moq;

namespace Aurora.AdministrationService.Tests.API.Services.Organizations
{
    public class OrganizationCommandServiceTests
    {
        private readonly Mock<ReadWriteDbContext> _readWriteDbContextMock;
        private readonly Mock<ReadOnlyDbContext> _readOnlyDbContextMock;
        private readonly Mock<IMapper> _mapperMock;
        private OrganizationCommandService _organizationCommandService;
        private readonly Mock<OrganizationQueryService> _organizationQueryService;

        public OrganizationCommandServiceTests()
        {
            // Initialize the mocks
            _mapperMock = new Mock<IMapper>();
            _readWriteDbContextMock = new Mock<ReadWriteDbContext>();
            _readOnlyDbContextMock = new Mock<ReadOnlyDbContext>();
            _organizationQueryService = new Mock<OrganizationQueryService>();


            // Setup in-memory ready only database for testing
            DbContextOptions<ReadWriteDbContext> options = new DbContextOptionsBuilder<ReadWriteDbContext>()
              .UseInMemoryDatabase(databaseName: "AdminOrganizationTestDB").Options;

            _readWriteDbContextMock = new(options);

            // Initialize the service being tested
            _organizationCommandService = new OrganizationCommandService(_readWriteDbContextMock.Object, _mapperMock.Object);
        }

        [Fact]
        public async Task CreateOrganizationAsync_ShouldReturnTrue_WhenOrganizationIsCreatedSuccessfully()
        {
            // Arrange
            var newOrganization = new CreateOrganizationRequest
            {
                // Initialize with sample data
                Id = 1,
                ResourceID = new Guid(),
                Alias = "test",
                Name = "test",
                PartOf = new Guid(),
                Status = true,
                Type = "Hospital"
            };

            // Mock AutoMapper to return a Organization entity
            var organizationId = 1;
            var organizationEntity = new Organization
            {
                Id = organizationId,
                ResourceID = "123",
                Name = "test",
                CreatedBy = "Admin",
                IsDeleted = false,
                CreatedDate = DateTime.UtcNow,
            };


            // Mock AutoMapper to return the Organization entity
            _mapperMock.Setup(m => m.Map<Organization>(newOrganization)).Returns(organizationEntity);

            // Mock DbContext to simulate saving the entity without actually hitting the database
            _readWriteDbContextMock.Setup(db => db.Organizations.Add(It.IsAny<Organization>()));

            // Act
            var result = await _organizationCommandService.CreateOrganizationAsync(newOrganization);

            // Assert
            Assert.True(result);
            _readWriteDbContextMock.Verify(db => db.Organizations.Add(It.Is<Organization>(l => l.Name == "test")), Times.Once);
        }


        [Fact]
        public async Task CreateOrganizationAsync_ShouldReturnFalse_WhenExceptionOccurs()
        {
            // Arrange
            var newOrganization = new CreateOrganizationRequest
            {
                Id = 1,
                ResourceID = new Guid(),
                Alias = "test",
                Name = "test",
                PartOf = new Guid(),
                Status = true,
                Type = "Hospital"
            };

            // Mock AutoMapper to return a Organization entity
            var organizationId = 1;
            var organizationEntity = new Organization
            {
                Id = 1,
                ResourceID = "123",
                Alias = "test",
                Name = "test",
                PartOf = new Guid(),
                Status = true,
                Type = "Hospital",
                CreatedBy = "Admin",
                CreatedDate = DateTime.UtcNow,
                IsDeleted = true

            };

            //Setup
            _mapperMock.Setup(m => m.Map<Organization>(newOrganization)).Returns(organizationEntity);

            // Act
            var result = await _organizationCommandService.CreateOrganizationAsync(newOrganization);

            // Assert
            Assert.False(result);
        }
        [Fact]
        public async Task Test_UpdateOrganization_Returns_Success()
        {
            //Arrange
            DbContextOptions<ReadWriteDbContext> options = new DbContextOptionsBuilder<ReadWriteDbContext>()
               .UseInMemoryDatabase(databaseName: "UpdateOrganization").Options;

            byte[] concurrencyToken = new byte[8] { byte.MinValue, byte.MinValue, byte.MinValue, byte.MinValue, byte.MinValue, byte.MinValue, byte.MinValue, byte.MaxValue };
            var organization = new Organization
            {
                Id = 1,
                ResourceID = "123",
                Name = "Org1",
                Status = true,
                Type = "Hospital",
                Alias = "O1",
                PartOf = Guid.NewGuid(),
                Source = "System",
                IsDeleted = false,
                CreatedBy = "Admin",
                CreatedDate = DateTime.UtcNow,
                UpdatedBy = "Admin",  // Adding the missing property
                UpdatedDate = DateTime.UtcNow,// Assuming UpdatedDate is required as well
                RecordVersion = concurrencyToken
            };


            //Arrange
            using ReadWriteDbContext dbContext = new(options);
            dbContext.Organizations.Add(organization);
            await dbContext.SaveChangesAsync();


            UpdateOrganizationRequest updateModel = new UpdateOrganizationRequest
            {
                Id = 1,
                ResourceID = Guid.NewGuid(),
                Name = "Org1",
                Status = true,
                Type = "Hospital",
                Alias = "O1",
                PartOf = Guid.NewGuid(),
                Source = "System",
            };

            //updateModel.ID = 1;
            updateModel.RecordVersion = organization.RecordVersion;

            _organizationCommandService = new OrganizationCommandService(dbContext, _mapperMock.Object);

            // Act
            bool result = await _organizationCommandService.UpdateOrganizationAsync(updateModel, organization);

            Assert.True(result);
        }
        [Fact]
        public async Task Test_DeleteOrganization_Returns_Success()
        {
            //Arrange
            DbContextOptions<ReadWriteDbContext> options = new DbContextOptionsBuilder<ReadWriteDbContext>()
               .UseInMemoryDatabase(databaseName: "DeleteOrganization").Options;

            byte[] concurrencyToken = new byte[8] { byte.MinValue, byte.MinValue, byte.MinValue, byte.MinValue, byte.MinValue, byte.MinValue, byte.MinValue, byte.MaxValue };
            var organization = new Organization
            {
                Id = 1,
                ResourceID = "123",
                Name = "Org1",
                Status = true,
                Type = "Hospital",
                Alias = "O1",
                PartOf = Guid.NewGuid(),
                Source = "System",
                IsDeleted = false,
                CreatedBy = "Admin",
                CreatedDate = DateTime.UtcNow,
                UpdatedBy = "Admin",  // Adding the missing property
                UpdatedDate = DateTime.UtcNow,// Assuming UpdatedDate is required as well
                RecordVersion = concurrencyToken
            };


            //Arrange
            using ReadWriteDbContext dbContext = new(options);
            dbContext.Organizations.Add(organization);
            await dbContext.SaveChangesAsync();

            _organizationCommandService = new OrganizationCommandService(dbContext, _mapperMock.Object);

            // Act
            bool result = await _organizationCommandService.DeleteOrganizationByIdAsync(concurrencyToken, organization);

            Assert.True(result);
        }
    }
}