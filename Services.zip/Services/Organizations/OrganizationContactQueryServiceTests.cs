﻿using Aurora.AdministrationService.CrossCutting.CommonModels;
using Aurora.AdministrationService.Domain.V1.Entities.Organizations;
using Aurora.AdministrationService.Infrastructure;
using AutoMapper;
using Microsoft.EntityFrameworkCore;
using Moq;
using Aurora.AdministrationService.API.Models.ResponseModels.OrganizationContacts;
using Aurora.AdministrationService.API.Services.Service.OrganizationContacts;

namespace Aurora.AdministrationService.Tests.API.Services.Organizations
{
    public class OrganizationContactQueryServiceTests
    {
        private readonly Mock<ReadOnlyDbContext> _readOnlyDbContextMock;
        private readonly Mock<IMapper> _mapperMock;
        private readonly OrganizationContactQueryService _OrganizationContactQueryService;
        private Mock<DbSet<OrganizationContact>> _mockDbSet;

        public OrganizationContactQueryServiceTests()
        {
            //Initialize mock
            _readOnlyDbContextMock = new Mock<ReadOnlyDbContext>();
            _mapperMock = new Mock<IMapper>();

            // Setup in-memory ready only database for testing
            DbContextOptions<ReadOnlyDbContext> options = new DbContextOptionsBuilder<ReadOnlyDbContext>()
              .UseInMemoryDatabase(databaseName: "OrganizationContactTestDB").Options;

            _readOnlyDbContextMock = new(options);

            _mockDbSet = new Mock<DbSet<OrganizationContact>>();

            var data = new List<OrganizationContact>
            {
               new OrganizationContact { Id=1, Address="Pulkit", Name="test",  IsDeleted=false, CreatedBy="Admin", CreatedDate=DateTime.UtcNow, Telecom="1", OrganizationID=1 },
               new OrganizationContact { Id=2, Address="Pulkit", Name="test",  IsDeleted=false, CreatedBy="Admin", CreatedDate=DateTime.UtcNow, Telecom="1", OrganizationID=1 },
            }.AsQueryable();


            //Setup
            _mockDbSet.As<IQueryable<OrganizationContact>>().Setup(m => m.Provider).Returns(data.Provider);
            _mockDbSet.As<IQueryable<OrganizationContact>>().Setup(m => m.Expression).Returns(data.Expression);
            _mockDbSet.As<IQueryable<OrganizationContact>>().Setup(m => m.ElementType).Returns(data.ElementType);
            _mockDbSet.As<IQueryable<OrganizationContact>>().Setup(m => m.GetEnumerator()).Returns(data.GetEnumerator());
            _readOnlyDbContextMock.Setup(c => c.OrganizationContacts).Returns(_mockDbSet.Object);

            // Create the service instance
            _OrganizationContactQueryService = new OrganizationContactQueryService(_readOnlyDbContextMock.Object, _mapperMock.Object);
        }

        [Fact]
        public async Task GetOrganizationContactById_LogoExists_ReturnsLogoDetailDto()
        {
            // Arrange
            var organizationContactId = 1;
            var organizationContact = new OrganizationContact { Id = 1, Address = "Pulkit", Name = "test", IsDeleted = false, CreatedBy = "Admin", CreatedDate = DateTime.UtcNow, Telecom = "1", OrganizationID = 1 };

            var organizationContactDto = new GetOrganizationContactDetailDto
            { Id = 1, Address = "Pulkit", Name = "test", IsDeleted = false, Telecom = "1", OrganizationID = 1 };

            _readOnlyDbContextMock.Setup(db => db.OrganizationContacts.FindAsync(organizationContactId))
                .ReturnsAsync(organizationContact);

            _mapperMock.Setup(m => m.Map<GetOrganizationContactDetailDto>(organizationContact))
                .Returns(organizationContactDto);

            // Act
            var result = await _OrganizationContactQueryService.GetOrganizationContactById(organizationContactId);

            // Assert
            Assert.NotNull(result);
            Assert.Equal(organizationContactId, result.Id);
            Assert.Equal("Pulkit", result.Address);
        }

        [Fact]
        public async Task GetOrganizationContactById_organizationContactNotFound_ReturnsNull()
        {
            //Arrange
            var organizationContactId = 1;

            _readOnlyDbContextMock.Setup(db => db.OrganizationContacts.FindAsync(organizationContactId))
                .ReturnsAsync((OrganizationContact)null);

            //Act
            var result = await _OrganizationContactQueryService.GetOrganizationContactById(organizationContactId);

            //Assert
            Assert.Null(result);
        }

        [Fact]
        public async Task GetOrganizationContactById_organizationContactExists_BindingError_ReturnsNull()
        {
            // Arrange
            var organizationContactId = 1;
            var organizationContact = new OrganizationContact
            { Id = 1, Address = "Pulkit", Name = "test", IsDeleted = false, CreatedBy = "Admin", CreatedDate = DateTime.UtcNow, Telecom = "1", OrganizationID = 1 };
            _readOnlyDbContextMock.Setup(db => db.OrganizationContacts.FindAsync(organizationContactId))
                .ReturnsAsync(organizationContact);

            _mapperMock.Setup(m => m.Map<GetOrganizationContactDetailDto>(organizationContact))
                .Throws(new AutoMapperMappingException("Error mapping entity to DTO"));

            // Act & Assert
            var exception = await Assert.ThrowsAsync<AutoMapperMappingException>(
                () => _OrganizationContactQueryService.GetOrganizationContactById(organizationContactId)
            );

            Assert.Equal("Error mapping entity to DTO", exception.Message);
        }

        [Fact]
        public async Task FindOrganizationContactById_organizationContactExists_ReturnsorganizationContact()
        {
            // Arrange
            var organizationContactId = 1;
            var organizationContact = new OrganizationContact
            { Id = 1, Address = "Pulkit", Name = "test", IsDeleted = false, CreatedBy = "Admin", CreatedDate = DateTime.UtcNow, Telecom = "1", OrganizationID = 1 };

            // Mock the FindAsync method to return the organizationContact
            _readOnlyDbContextMock.Setup(db => db.OrganizationContacts.FindAsync(organizationContactId))
                .ReturnsAsync(organizationContact);

            // Act
            var result = await _OrganizationContactQueryService.FindOrganizationContactById(organizationContactId);

            // Assert
            Assert.NotNull(result);
            Assert.Equal(organizationContactId, result.Id);
            Assert.Equal(1, result.OrganizationID);
            Assert.Equal("Pulkit", result.Address);
        }

        [Fact]
        public async Task FindOrganizationContactById_organizationContactNotFound_ReturnsNull()
        {
            // Arrange
            var organizationContactId = 1;

            // Mock the FindAsync method to return null (organizationContact not found)
            _readOnlyDbContextMock.Setup(db => db.OrganizationContacts.FindAsync(organizationContactId))
                .ReturnsAsync((OrganizationContact)null);

            // Act
            var result = await _OrganizationContactQueryService.FindOrganizationContactById(organizationContactId);

            // Assert
            Assert.Null(result);
        }

        [Fact]
        public void GetOrganizationContactList_ReturnsCorrectOrganizationContactList()
        {
            // Act
            var result = _OrganizationContactQueryService.GetOrganizationContactList();

            // Assert
            Assert.NotNull(result);
            Assert.Equal(2, result.Count); // Verifying that 3 items are returned

            // Verifying that the returned items are mapped correctly
            Assert.Contains(result, r => r.Id == 1 && r.OrganizationID == 1);
            Assert.Contains(result, r => r.Id == 2 && r.OrganizationID == 1);
        }

        [Fact]
        public async Task IsOrganizationContactAlreadyExist_ShouldReturnTrue_WhenorganizationContactExists()
        {
            // Arrange
            var organizationContactId = 1;
            var organizationContact = new OrganizationContact
            { Id = 1, Address = "Pulkit", Name = "test", IsDeleted = false, CreatedBy = "Admin", CreatedDate = DateTime.UtcNow, Telecom = "1", OrganizationID = 1 };

            // Mock the FindAsync method to return the organizationContact
            _readOnlyDbContextMock.Setup(db => db.OrganizationContacts.FindAsync(organizationContactId))
                .ReturnsAsync(organizationContact);

            // Act
            var result = await _OrganizationContactQueryService.IsOrganizationContactAlreadyExist(organizationContactId);

            // Assert
            Assert.True(result.result);
            Assert.Equal(ResponseMessage.STATUS_DATA_FOUND, result.message);
        }

        [Fact]
        public async Task IsOrganizationContactAlreadyExist_ShouldReturnFalse_WhenorganizationContactDoesNotExist()
        {
            // Arrange
            var organizationContactId = 3;

            // Act
            var result = await _OrganizationContactQueryService.IsOrganizationContactAlreadyExist(organizationContactId);

            // Assert
            Assert.False(result.result);
            Assert.Equal(ResponseMessage.STATUS_NODATA, result.message);
        }
    }
}

