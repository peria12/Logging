﻿using Aurora.AdministrationService.API.Enum;
using Aurora.AdministrationService.API.Models.ResponseModels.Organizations;
using Aurora.AdministrationService.API.Resources;
using Aurora.AdministrationService.API.Services.Service.Organizations;
using Aurora.AdministrationService.CrossCutting.CommonModels;
using Aurora.AdministrationService.Domain.Old.Entities;
using Aurora.AdministrationService.Infrastructure.IRepository;
using Aurora.AdministrationService.Infrastructure.IRepository.Organizations;
using AutoMapper;
using FluentAssertions;
using Microsoft.Extensions.DependencyInjection;
using Moq;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Aurora.AdministrationService.Tests.API.Services.Organizations
{
    public  class OrganizationServiceTests
    {
        private readonly Mock<IOrganizationRepository> _mockOrganizationRepository;
        private readonly Mock<IMapper> _mockMapper;
        private readonly OrganizationService _organizationService;
        public OrganizationServiceTests()
        {
            _mockOrganizationRepository = new Mock<IOrganizationRepository>();
            _mockMapper = new Mock<IMapper>();

            // Create instance of OrganizationService
            _organizationService = new OrganizationService(
                _mockOrganizationRepository.Object,
                _mockMapper.Object
            );
        }
        [Fact]
        public async Task GetAllOrganizations_ShouldReturnSuccessResult_WhenOrganizationsExist()
        {
            // Arrange
            var organizations = new List<AdminOrganization>
            {
                new AdminOrganization { Name = "Hospital A", Latitude = 40.7128, Longitude = -74.0060, City = "New York", State = "NY", ImageUrl = "imgA", WebsiteUrl = "urlA", PhoneNumber = "1234567890" },
                new AdminOrganization { Name = "Hospital B", Latitude = 34.0522, Longitude = -118.2437, City = "Los Angeles", State = "CA", ImageUrl = "imgB", WebsiteUrl = "urlB", PhoneNumber = "0987654321" },
                new AdminOrganization { Name = "Hospital C", Latitude = 37.7749, Longitude = -122.4194, City = "San Francisco", State = "CA", ImageUrl = "imgC", WebsiteUrl = "urlC", PhoneNumber = "9876543210" }
            };
            var organizationResponse = new List<OrganizationResponseDTO>
            {
                new OrganizationResponseDTO { Name = "Hospital A", City = "New York" },
                new OrganizationResponseDTO { Name = "Hospital B", City = "Los Angeles" },
                new OrganizationResponseDTO { Name = "Hospital C", City = "San Francisco" }
            };
            _mockOrganizationRepository
                .Setup(repo => repo.GetAllOrganizationsAsync())
                .ReturnsAsync(organizations);

            // Mock the mapper to return the organizations list
            _mockMapper
                .Setup(m => m.Map<List<OrganizationResponseDTO>>(It.IsAny<List<AdminOrganization>>()))
                .Returns(organizationResponse);
            // Act
            var result = await _organizationService.GetAllOrganizationsAsync();

            // Assert
            result.Should().NotBeNull();
            result.HasError.Should().BeFalse();
            result.IsSuccess.Should().BeTrue();
            result.StatusCode.Should().Be(((int)ResponceStatusCode.Success).ToString());
            result.Results.Should().HaveCount(3); // Two states (NY and CA)
            result.Results.First().City.Should().Be("New York");
        }
        [Fact]
        public async Task GetAllOrganizations_ShouldReturnEmptyResult_WhenNoOrganizationsExist()
        {
            // Arrange
            _mockOrganizationRepository
                .Setup(repo => repo.GetAllOrganizationsAsync())
                .ReturnsAsync(new List<AdminOrganization>());

            // Act
            var result = await _organizationService.GetAllOrganizationsAsync();

            // Assert
            result.Should().NotBeNull();
            result.HasError.Should().BeFalse();
            result.IsSuccess.Should().BeTrue();
            result.StatusCode.Should().Be(((int)ResponceStatusCode.NotFound).ToString());
            result.Results.Should().BeEmpty();
        }
        [Fact]
        public async Task GetAllOrganizations_ShouldReturnError_WhenExceptionThrown()
        {
            // Arrange
            _mockOrganizationRepository
                .Setup(repo => repo.GetAllOrganizationsAsync())
                .ThrowsAsync(new Exception(Resource.LogMessage));

            // Act
            var result = await _organizationService.GetAllOrganizationsAsync();

            // Assert
            result.Should().NotBeNull();
            result.HasError.Should().BeTrue();
            result.IsSuccess.Should().BeFalse();
            result.StatusCode.Should().Be(ResponseStatus.STATUS_InternalServerError);
            result.Message.Should().Be(Resource.LogMessage);
        }

    }
}
