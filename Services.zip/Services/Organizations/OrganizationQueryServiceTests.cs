﻿using Aurora.AdministrationService.API.Enum;
using Aurora.AdministrationService.API.Models.ResponseModels.Organizations;
using Aurora.AdministrationService.API.Services.Service.Organizations;
using Aurora.AdministrationService.CrossCutting.CommonModels;
using Aurora.AdministrationService.Domain.V1.Entities.Organizations;
using Aurora.AdministrationService.Infrastructure;
using Aurora.AdministrationService.Tests.API.CommonMock;
using AutoMapper;
using FluentAssertions;
using Microsoft.EntityFrameworkCore;
using Moq;

namespace Aurora.AdministrationService.Tests.API.Services.Organizations
{
    public class OrganizationQueryServiceTests
    {
        private readonly OrganizationQueryService _organizationQueryService;
        private readonly DbContextOptions<ReadOnlyDbContext> _options;
        private readonly Mock<IMapper> _mapperMock;

        public OrganizationQueryServiceTests()
        {
            // Use a unique database name for each test to avoid shared state
            _options = new DbContextOptionsBuilder<ReadOnlyDbContext>()
                .UseInMemoryDatabase(databaseName: Guid.NewGuid().ToString()) // Unique name
                .Options;

            // Create a context that uses the InMemoryDatabase
            var context = new ReadOnlyDbContext(_options);
            _mapperMock = new Mock<IMapper>();

            // Initialize the service with the context and mapper mock
            _organizationQueryService = new OrganizationQueryService(context, _mapperMock.Object);
        }

        [Fact]
        public async Task GetOrganisationMasterList_ReturnsEmptyList_WhenNoOrganizationsExist()
        {
            // Arrange: No organizations are added to the in-memory database

            // Act: Call the method to get the organization master list
            var result = _organizationQueryService.GetOrganizationMasterList();

            // Assert: Verify that the result is empty and has the correct status
            Assert.False(result.HasError);
            Assert.True(result.IsSuccess);
            Assert.Equal(ResponceStatusCode.RecordNotFound.ToString(), result.StatusCode);
            Assert.Equal(ResponseMessage.STATUS_NODATA, result.Message);
            Assert.Empty(result.Results);
        }

        [Fact]
        public async Task GetOrganisationMasterList_ReturnsListOfOrganizations_WhenOrganizationsExist()
        {
            // Arrange: Add organizations to the in-memory database with all required properties
            using (var context = new ReadOnlyDbContext(_options))
            {
                context.Organizations.AddRange(
                    new Organization
                    {
                        Id = 1,
                        ResourceID = "123",
                        Name = "Org1",
                        Status = true,
                        Type = "Hospital",
                        Alias = "O1",
                        PartOf = Guid.NewGuid(),
                        Source = "System",
                        IsDeleted = false,
                        CreatedBy = "Admin",
                        CreatedDate = DateTime.UtcNow,
                        UpdatedBy = "Admin",  // Adding the missing property
                        UpdatedDate = DateTime.UtcNow, // Assuming UpdatedDate is required as well
                    },
                    new Organization
                    {
                        Id = 2,
                        ResourceID = "123",
                        Name = "Org2",
                        Status = true,
                        Type = "Clinic",
                        Alias = "O2",
                        PartOf = Guid.NewGuid(),
                        Source = "User",
                        IsDeleted = false,
                        CreatedBy = "Admin",
                        CreatedDate = DateTime.UtcNow,
                        UpdatedBy = "Admin",  // Adding the missing property
                        UpdatedDate = DateTime.UtcNow, // Assuming UpdatedDate is required as well

                    }
                );
                context.SaveChanges();
            }

            // Act: Call the method to get the organization master list
            var result = _organizationQueryService.GetOrganizationMasterList();

            // Assert: Verify that the result contains organizations and has the correct status
            Assert.False(result.HasError);
            Assert.True(result.IsSuccess);
            Assert.Equal(ResponseStatus.STATUS_SUCCESS, result.StatusCode);
            Assert.NotEmpty(result.Results);
        }

        [Fact]
        public async Task IsOrganizationAlreadyExist_ShouldReturnTrue_WhenOrganizationExists()
        {
            // Arrange
            var organizationId = 1;
            var organization = new Organization
            {
                Id = organizationId,
                Name = "Test Organization",
                CreatedBy = "user1",
                CreatedDate = DateTime.UtcNow,
                IsDeleted = false,
                ResourceID = "123",
                Alias = "test",
                PartOf = Guid.NewGuid(),
                Source = "source",
                Status = true,
                UpdatedBy = "user1",
                UpdatedDate = DateTime.UtcNow,
                Type = "type"
            };
            using (var context = new ReadOnlyDbContext(_options))
            {
                context.Organizations.Add(organization);
                await context.SaveChangesAsync();
            }

            // Act
            var result = await _organizationQueryService.IsOrganizationAlreadyExist(organizationId);

            // Assert
            Assert.True(result.result);
            Assert.Equal(ResponseMessage.STATUS_DATA_FOUND, result.message);  // Assuming ResponseMessage.STATUS_DATA_FOUND
        }

        [Fact]
        public async Task IsOrganizationAlreadyExist_ShouldReturnFalse_WhenOrganizationDoesNotExist()
        {
            // Arrange
            var organizationId = 1;

            // Act
            var result = await _organizationQueryService.IsOrganizationAlreadyExist(organizationId);

            // Assert
            Assert.False(result.result);
            Assert.Equal(ResponseMessage.STATUS_NODATA, result.message);  // Assuming ResponseMessage.STATUS_NODATA
        }

        [Fact]
        public async Task GetOrganizationById_ShouldReturnMappedDto_WhenOrganizationExists()
        {
            // Arrange
            var organizationId = 1;
            var organization = new Organization
            {
                Id = organizationId,
                Name = "Test Organization",
                CreatedBy = "user1",
                CreatedDate = DateTime.UtcNow,
                IsDeleted = false,
                ResourceID = "123",
                Alias = "test",
                PartOf = Guid.NewGuid(),
                Source = "source",
                Status = true,
                UpdatedBy = "user1",
                UpdatedDate = DateTime.UtcNow,
                Type = "type"
            };

            using (var context = new ReadOnlyDbContext(_options))
            {
                context.Organizations.Add(organization);
                await context.SaveChangesAsync();
            }


            _mapperMock.Setup(m => m.Map<GetOrganizationDetailDto>(It.IsAny<Organization>())).Returns(new GetOrganizationDetailDto { Id = organizationId, Name = "Test Organization" });

            // Act
            var result = await _organizationQueryService.GetOrganizationById(organizationId);

            // Assert
            Assert.NotNull(result);
            Assert.Equal(organizationId, result.Id);
            Assert.Equal("Test Organization", result.Name);
        }

        [Fact]
        public async Task GetOrganizationById_ShouldReturnNull_WhenOrganizationDoesNotExist()
        {
            // Arrange
            var organizationId = 1;

            // Act
            var result = await _organizationQueryService.GetOrganizationById(organizationId);

            // Assert
            Assert.Null(result);
        }

        [Fact]
        public async Task GetOrganizationList_ShouldReturnListOfOrganizations()
        {
            // Arrange
            var organizations = new List<Organization>
            {
                new Organization
                    {
                        Id = 1,
                        Name = "Org1",
                        CreatedBy = "user1",
                        CreatedDate = DateTime.UtcNow,
                        IsDeleted = false,
                        ResourceID = "123",
                        Alias = "test",
                        PartOf = Guid.NewGuid(),
                        Source = "source",
                        Status = true,
                        UpdatedBy = "user1",
                        UpdatedDate = DateTime.UtcNow,
                         Type = "type"
                    },
                 new Organization
                    {
                        Id = 2,
                        Name = "Org2",
                        CreatedBy = "user1",
                        CreatedDate = DateTime.UtcNow,
                        IsDeleted = false,
                        ResourceID = "123",
                        Alias = "test",
                        PartOf = Guid.NewGuid(),
                        Source = "source",
                        Status = true,
                        UpdatedBy = "user1",
                        UpdatedDate = DateTime.UtcNow,
                         Type = "type"
                    }
            };

            using (var context = new ReadOnlyDbContext(_options))
            {
                context.Organizations.AddRange(organizations);
                await context.SaveChangesAsync();
            }

            // Act
            var result = _organizationQueryService.GetOrganizationList();

            // Assert
            Assert.NotNull(result);
            Assert.Equal(2, result.Count);
            Assert.Equal("Org1", result[0].Name);
            Assert.Equal("Org2", result[1].Name);
        }

        [Fact]
        public async Task GetOrganizationMasterList_ShouldReturnMasterListOfOrganizations()
        {
            // Arrange
            var organizations = OrganizationMockData.GetOrganizationFakeData();

            using (var context = new ReadOnlyDbContext(_options))
            {
                context.Organizations.AddRange(organizations);
                await context.SaveChangesAsync();
            }

            // Act
            var result = _organizationQueryService.GetOrganizationMasterList();

            // Assert
            Assert.NotNull(result);
            Assert.Equal(2, result?.Results?.Count());
        }

        [Fact]
        public async Task FindOrganizationById_ExistingId_ReturnsOrganization()
        {
            // Arrange
            var organization = OrganizationMockData.GetOrganizationMockData();
            using (var context = new ReadOnlyDbContext(_options))
            {
                context.Organizations.AddRange(organization);
                await context.SaveChangesAsync();
            }

            // Act
            var result = await _organizationQueryService.FindOrganizationById(1);

            // Assert
            result.Should().NotBeNull();
            result.Id.Should().Be(1);
            result.IsDeleted.Should().Be(false);
            result.Name.Should().Be("Org1");
        }

        [Fact]
        public async Task FindOrganizationById_NonExistingId_ReturnsNull()
        {
            // Act
            var result = await _organizationQueryService.FindOrganizationById(999);

            // Assert
            result.Should().BeNull();
        }
    }

}
