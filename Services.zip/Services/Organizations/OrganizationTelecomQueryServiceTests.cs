﻿using Aurora.AdministrationService.API.Models.ResponseModels.OrganizationTelecoms;
using Aurora.AdministrationService.API.Services.Service.OrganizationTelecoms;
using Aurora.AdministrationService.CrossCutting.CommonModels;
using Aurora.AdministrationService.Domain.V1.Entities.Organizations;
using Aurora.AdministrationService.Infrastructure;
using AutoMapper;
using Microsoft.EntityFrameworkCore;
using Moq;

namespace Aurora.AdministrationService.Tests.API.Services.Organizations
{
    public class OrganizationTelecomQueryServiceTests
    {
        private readonly Mock<ReadOnlyDbContext> _readOnlyDbContextMock;
        private readonly Mock<IMapper> _mapperMock;
        private readonly OrganizationTelecomQueryService _OrganizationTelecomQueryService;
        private Mock<DbSet<OrganizationTelecom>> _mockDbSet;

        public OrganizationTelecomQueryServiceTests()
        {
            //Initialize mock
            _readOnlyDbContextMock = new Mock<ReadOnlyDbContext>();
            _mapperMock = new Mock<IMapper>();

            // Setup in-memory ready only database for testing
            DbContextOptions<ReadOnlyDbContext> options = new DbContextOptionsBuilder<ReadOnlyDbContext>()
              .UseInMemoryDatabase(databaseName: "OrganizationTelecomTestDB").Options;

            _readOnlyDbContextMock = new(options);

            _mockDbSet = new Mock<DbSet<OrganizationTelecom>>();

            var data = new List<OrganizationTelecom>
            {
               getOrganizationTelecomDto(1),
               getOrganizationTelecomDto(2),
            }.AsQueryable(); 


            //Setup
            _mockDbSet.As<IQueryable<OrganizationTelecom>>().Setup(m => m.Provider).Returns(data.Provider);
            _mockDbSet.As<IQueryable<OrganizationTelecom>>().Setup(m => m.Expression).Returns(data.Expression);
            _mockDbSet.As<IQueryable<OrganizationTelecom>>().Setup(m => m.ElementType).Returns(data.ElementType);
            _mockDbSet.As<IQueryable<OrganizationTelecom>>().Setup(m => m.GetEnumerator()).Returns(data.GetEnumerator());
            _readOnlyDbContextMock.Setup(c => c.OrganizationTelecoms).Returns(_mockDbSet.Object);

            // Create the service instance
            _OrganizationTelecomQueryService = new OrganizationTelecomQueryService(_readOnlyDbContextMock.Object, _mapperMock.Object);
        }
        private OrganizationTelecom getOrganizationTelecomDto(int id=1)
        {
            return new OrganizationTelecom { Id = id, Value = "1234567", PeriodStart = DateTime.UtcNow, PeriodEnd = DateTime.UtcNow, IsDeleted = false, CreatedBy = "Admin", CreatedDate = DateTime.UtcNow, Rank = 1, System = "Home", Use = "Home", OrganizationID = 1 };
        }
        private GetOrganizationTelecomDetailDto getOrganizationTelecomDetailDto()
        {
            return new GetOrganizationTelecomDetailDto { Id = 1, Value = "1234567", PeriodStart = DateTime.UtcNow, PeriodEnd = DateTime.UtcNow, IsDeleted = false, Rank = 1, System = "Home", Use = "Home", OrganizationID = 1 };
        }
        [Fact]
        public async Task GetOrganizationTelecomById_LogoExists_ReturnsLogoDetailDto()
        {
            // Arrange
            var organizationTelecomId = 1;
            var organizationTelecom = getOrganizationTelecomDto();

            var organizationTelecomDto = getOrganizationTelecomDetailDto();

            _readOnlyDbContextMock.Setup(db => db.OrganizationTelecoms.FindAsync(organizationTelecomId))
                .ReturnsAsync(organizationTelecom);

            _mapperMock.Setup(m => m.Map<GetOrganizationTelecomDetailDto>(organizationTelecom))
                .Returns(organizationTelecomDto);

            // Act
            var result = await _OrganizationTelecomQueryService.GetOrganizationTelecomById(organizationTelecomId);

            // Assert
            Assert.NotNull(result);
            Assert.Equal(organizationTelecomId, result.Id);
            Assert.Equal("1234567", result.Value);
        }

        [Fact]
        public async Task GetOrganizationTelecomById_organizationTelecomNotFound_ReturnsNull()
        {
            //Arrange
            var organizationTelecomId = 1;

            _readOnlyDbContextMock.Setup(db => db.OrganizationTelecoms.FindAsync(organizationTelecomId))
                .ReturnsAsync((OrganizationTelecom)null);

            //Act
            var result = await _OrganizationTelecomQueryService.GetOrganizationTelecomById(organizationTelecomId);

            //Assert
            Assert.Null(result);
        }

        [Fact]
        public async Task GetOrganizationTelecomById_organizationTelecomExists_BindingError_ReturnsNull()
        {
            // Arrange
            var organizationTelecomId = 1;
            var organizationTelecom = getOrganizationTelecomDto();
            _readOnlyDbContextMock.Setup(db => db.OrganizationTelecoms.FindAsync(organizationTelecomId))
                .ReturnsAsync(organizationTelecom);

            _mapperMock.Setup(m => m.Map<GetOrganizationTelecomDetailDto>(organizationTelecom))
                .Throws(new AutoMapperMappingException("Error mapping entity to DTO"));

            // Act & Assert
            var exception = await Assert.ThrowsAsync<AutoMapperMappingException>(
                () => _OrganizationTelecomQueryService.GetOrganizationTelecomById(organizationTelecomId)
            );

            Assert.Equal("Error mapping entity to DTO", exception.Message);
        }

        [Fact]
        public async Task FindOrganizationTelecomById_organizationTelecomExists_ReturnsorganizationTelecom()
        {
            // Arrange
            var organizationTelecomId = 1;
            var organizationTelecom = getOrganizationTelecomDto();

            // Mock the FindAsync method to return the organizationTelecom
            _readOnlyDbContextMock.Setup(db => db.OrganizationTelecoms.FindAsync(organizationTelecomId))
                .ReturnsAsync(organizationTelecom);

            // Act
            var result = await _OrganizationTelecomQueryService.FindOrganizationTelecomById(organizationTelecomId);

            // Assert
            Assert.NotNull(result);
            Assert.Equal(organizationTelecomId, result.Id);
            Assert.Equal(1, result.OrganizationID);
            Assert.Equal("1234567", result.Value);
        }

        [Fact]
        public async Task FindOrganizationTelecomById_organizationTelecomNotFound_ReturnsNull()
        {
            // Arrange
            var organizationTelecomId = 1;

            // Mock the FindAsync method to return null (organizationTelecom not found)
            _readOnlyDbContextMock.Setup(db => db.OrganizationTelecoms.FindAsync(organizationTelecomId))
                .ReturnsAsync((OrganizationTelecom)null);

            // Act
            var result = await _OrganizationTelecomQueryService.FindOrganizationTelecomById(organizationTelecomId);

            // Assert
            Assert.Null(result);
        }

        [Fact]
        public void GetOrganizationTelecomList_ReturnsCorrectOrganizationTelecomList()
        {
            // Act
            var result = _OrganizationTelecomQueryService.GetOrganizationTelecomList();

            // Assert
            Assert.NotNull(result);
            Assert.Equal(2, result.Count); // Verifying that 3 items are returned

            // Verifying that the returned items are mapped correctly
            Assert.Contains(result, r => r.Id == 1 && r.OrganizationID == 1);
            Assert.Contains(result, r => r.Id == 2 && r.OrganizationID == 1);
        }

        [Fact]
        public async Task IsOrganizationTelecomAlreadyExist_ShouldReturnTrue_WhenorganizationTelecomExists()
        {
            // Arrange
            var organizationTelecomId = 1;
            var organizationTelecom = getOrganizationTelecomDto();

            // Mock the FindAsync method to return the organizationTelecom
            _readOnlyDbContextMock.Setup(db => db.OrganizationTelecoms.FindAsync(organizationTelecomId))
                .ReturnsAsync(organizationTelecom);

            // Act
            var result = await _OrganizationTelecomQueryService.IsOrganizationTelecomAlreadyExist(organizationTelecomId);

            // Assert
            Assert.True(result.result);
            Assert.Equal(ResponseMessage.STATUS_DATA_FOUND, result.message);
        }

        [Fact]
        public async Task IsOrganizationTelecomAlreadyExist_ShouldReturnFalse_WhenorganizationTelecomDoesNotExist()
        {
            // Arrange
            var organizationTelecomId = 3;

            // Act
            var result = await _OrganizationTelecomQueryService.IsOrganizationTelecomAlreadyExist(organizationTelecomId);

            // Assert
            Assert.False(result.result);
            Assert.Equal(ResponseMessage.STATUS_NODATA, result.message);
        }
    }
}
