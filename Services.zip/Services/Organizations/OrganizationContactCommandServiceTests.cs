﻿using Aurora.AdministrationService.API.Models.RequestModels.OrganizationContacts;
using Aurora.AdministrationService.API.Services.Service.OrganizationContacts;
using Aurora.AdministrationService.Domain.V1.Entities.Organizations;
using Aurora.AdministrationService.Infrastructure;
using AutoMapper;
using Microsoft.EntityFrameworkCore;
using Moq;

namespace Aurora.AdministrationService.Tests.API.Services.Organizations
{
    public class OrganizationContactCommandServiceTests
    {
        private readonly Mock<ReadWriteDbContext> _readWriteDbContextMock;
        private readonly Mock<ReadOnlyDbContext> _readOnlyDbContextMock;
        private readonly Mock<IMapper> _mapperMock;
        private OrganizationContactCommandService _organizationContactCommandService;
        private readonly Mock<OrganizationContactQueryService> _organizationContactQueryService;

        public OrganizationContactCommandServiceTests()
        {
            // Initialize the mocks
            _mapperMock = new Mock<IMapper>();
            _readWriteDbContextMock = new Mock<ReadWriteDbContext>();
            _readOnlyDbContextMock = new Mock<ReadOnlyDbContext>();
            _organizationContactQueryService = new Mock<OrganizationContactQueryService>();


            // Setup in-memory ready only database for testing
            DbContextOptions<ReadWriteDbContext> options = new DbContextOptionsBuilder<ReadWriteDbContext>()
              .UseInMemoryDatabase(databaseName: "AdminOrganizationContactTestDB").Options;

            _readWriteDbContextMock = new(options);

            // Initialize the service being tested
            _organizationContactCommandService = new OrganizationContactCommandService(_readWriteDbContextMock.Object, _mapperMock.Object);
        }

        [Fact]
        public async Task CreateOrganizationContactAsync_ShouldReturnTrue_WhenOrganizationContactIsCreatedSuccessfully()
        {
            // Arrange
            var newOrganizationContact = new CreateOrganizationContactRequest
            {
                Id = 1,
                Address = "Pulkit",
                Name = "test",
                Telecom = "1",
                OrganizationID = 1
            };

            // Mock AutoMapper to return a OrganizationContact entity
            var organizationContactId = 1;
            var organizationContactEntity = new OrganizationContact
            {
                Id = 1,
                Address = "Pulkit",
                Name = "test",
                IsDeleted = false,
                CreatedBy = "Admin",
                CreatedDate = DateTime.UtcNow,
                Telecom = "1",
                OrganizationID = 1
            };


            // Mock AutoMapper to return the OrganizationContact entity
            _mapperMock.Setup(m => m.Map<OrganizationContact>(newOrganizationContact)).Returns(organizationContactEntity);

            // Mock DbContext to simulate saving the entity without actually hitting the database
            _readWriteDbContextMock.Setup(db => db.OrganizationContacts.Add(It.IsAny<OrganizationContact>()));

            // Act
            var result = await _organizationContactCommandService.CreateOrganizationContactAsync(newOrganizationContact);

            // Assert
            Assert.True(result);
            _readWriteDbContextMock.Verify(db => db.OrganizationContacts.Add(It.Is<OrganizationContact>(l => l.Address == "Pulkit")), Times.Once);
        }


        [Fact]
        public async Task CreateOrganizationContactAsync_ShouldReturnFalse_WhenExceptionOccurs()
        {
            // Arrange
            var newOrganizationContact = new CreateOrganizationContactRequest
            {
                Id = 1,
                Address = "Pulkit",
                Name = "test",
                Telecom = "1",
                OrganizationID = 1
            };

            // Mock AutoMapper to return a OrganizationContact entity
            var organizationContactId = 1;
            var organizationContactEntity = new OrganizationContact
            {
                Id = 1,
                Address = "Pulkit",
                Name = "test",
                IsDeleted = false,
                CreatedBy = "Admin",
                CreatedDate = DateTime.UtcNow,
                Telecom = "1",
                OrganizationID = 1
            };

            //Setup
            _mapperMock.Setup(m => m.Map<OrganizationContact>(newOrganizationContact)).Returns(organizationContactEntity);

            // Act
            var result = await _organizationContactCommandService.CreateOrganizationContactAsync(newOrganizationContact);

            // Assert
            Assert.False(result);
        }
        [Fact]
        public async Task Test_UpdateOrganizationContact_Returns_Success()
        {
            //Arrange
            DbContextOptions<ReadWriteDbContext> options = new DbContextOptionsBuilder<ReadWriteDbContext>()
               .UseInMemoryDatabase(databaseName: "UpdateOrganizationContact").Options;

            byte[] concurrencyToken = new byte[8] { byte.MinValue, byte.MinValue, byte.MinValue, byte.MinValue, byte.MinValue, byte.MinValue, byte.MinValue, byte.MaxValue };
            var organizationContact = new OrganizationContact
            {
                Id = 1,
                Address = "Pulkit",
                Name = "test",
                IsDeleted = false,
                CreatedBy = "Admin",
                CreatedDate = DateTime.UtcNow,
                Telecom = "1",
                Purpose = "1",
                OrganizationID = 1,
                UpdatedBy = "Admin",  // Adding the missing property
                UpdatedDate = DateTime.UtcNow,// Assuming UpdatedDate is required as well
                RecordVersion = concurrencyToken
            };


            //Arrange
            using ReadWriteDbContext dbContext = new(options);
            dbContext.OrganizationContacts.Add(organizationContact);
            await dbContext.SaveChangesAsync();


            UpdateOrganizationContactRequest updateModel = new UpdateOrganizationContactRequest
            {
                Id = 1,
                Address = "Pulkit",
                Name = "test",
                Telecom = "1",
                OrganizationID = 1
            };

            //updateModel.ID = 1;
            updateModel.RecordVersion = organizationContact.RecordVersion;

            _organizationContactCommandService = new OrganizationContactCommandService(dbContext, _mapperMock.Object);

            // Act
            bool result = await _organizationContactCommandService.UpdateOrganizationContactAsync(updateModel, organizationContact);

            Assert.True(result);
        }
        [Fact]
        public async Task Test_DeleteOrganizationContact_Returns_Success()
        {
            //Arrange
            DbContextOptions<ReadWriteDbContext> options = new DbContextOptionsBuilder<ReadWriteDbContext>()
               .UseInMemoryDatabase(databaseName: "DeleteOrganizationContact").Options;

            byte[] concurrencyToken = new byte[8] { byte.MinValue, byte.MinValue, byte.MinValue, byte.MinValue, byte.MinValue, byte.MinValue, byte.MinValue, byte.MaxValue };
            var organizationContact = new OrganizationContact
            {
                Id = 1,
                Address = "Pulkit",
                Name = "test",
                IsDeleted = false,
                CreatedBy = "Admin",
                CreatedDate = DateTime.UtcNow,
                Telecom = "1",
                Purpose = "1",
                OrganizationID = 1,
                UpdatedBy = "Admin",  // Adding the missing property
                UpdatedDate = DateTime.UtcNow,// Assuming UpdatedDate is required as well
                RecordVersion = concurrencyToken
            };



            //Arrange
            using ReadWriteDbContext dbContext = new(options);
            dbContext.OrganizationContacts.Add(organizationContact);
            await dbContext.SaveChangesAsync();

            _organizationContactCommandService = new OrganizationContactCommandService(dbContext, _mapperMock.Object);

            // Act
            bool result = await _organizationContactCommandService.DeleteOrganizationContactByIdAsync(concurrencyToken, organizationContact);

            Assert.True(result);
        }
    }
}
