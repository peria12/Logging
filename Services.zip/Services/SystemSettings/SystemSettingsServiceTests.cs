using Aurora.AdministrationService.API.Enum;
using Aurora.AdministrationService.API.Resources;
using Aurora.AdministrationService.API.Services.Service.Old.SystemSettings;
using Aurora.AdministrationService.Domain.Old.Entities;
using Aurora.AdministrationService.Tests.API.Controllers.SystemSettings;
using Aurora.PatientWebAdmin.Infrastructure.IRepository;
using AutoMapper;
using FluentAssertions;
using Moq;

namespace Aurora.AdministrationService.Tests.API.Services.SystemSettings
{
    /// <summary>
    /// Test cases for System Settings
    /// </summary>
    public class SystemSettingsServiceTests
    {
        private readonly Mock<ISystemSettingsRepository> _systemSettingsRepositoryMock;
        private readonly SystemSettingsService _systemSettingsService;
        private readonly Mock<IMapper> _mapperMock;

        public SystemSettingsServiceTests()
        {
            _systemSettingsRepositoryMock = new Mock<ISystemSettingsRepository>();
            _mapperMock = new Mock<IMapper>();
            _systemSettingsService = new SystemSettingsService(_systemSettingsRepositoryMock.Object, _mapperMock.Object);
        }


        /// <summary>
        /// Get System Module when return sucess Response
        /// </summary>
        /// <returns>Task representing the asynchronous operation</returns>
        [Fact]
        public async Task GetSystemModulesAsync_ShouldReturnSucessResponse()
        {
            // Arrange
            var moduleList = MockData.GetModules();

            _systemSettingsRepositoryMock.Setup(repo => repo.GetSystemModulesAsync()).ReturnsAsync(moduleList);
            
            // Act
            var response = await _systemSettingsService.GetSystemModulesAsync();

            // Assert
            response.IsSuccess.Should().BeTrue();
            response.HasError.Should().BeFalse();
            response.StatusCode.Should().Be(((int)ResponceStatusCode.Success).ToString());
        }

        [Fact]
        public async Task GetSystemModulesAsync_ReturnsSuccess_WhenModulesAreFound()
        {
            // Arrange
            var expectedResponse = new List<SystemSettingsDto>()
            { 
               new SystemSettingsDto { ModuleName = "Module 1", IsNewlyUpdated=false },
               new SystemSettingsDto { ModuleName = "Module 2", IsNewlyUpdated=false}
            };

            // Mock the repository method to return the expected modules
            _systemSettingsRepositoryMock.Setup(repo => repo.GetSystemModulesAsync())
                .ReturnsAsync(expectedResponse);

            // Act
            var result = await _systemSettingsService.GetSystemModulesAsync();

            // Assert
            result.HasError.Should().BeFalse(); // Assert that HasError is false
            result.IsSuccess.Should().BeTrue(); // Assert that IsSuccess is true
            result.StatusCode.Should().Be("200"); // Assert that StatusCode is 200
            result.Result.Should().BeEquivalentTo(expectedResponse); // Assert that the result is equivalent to the expected modules
            result.Message.Should().BeNull(); // Assert that the message is null in the success case
        }

        [Fact]
        public async Task GetSystemModulesAsync_ReturnsError_WhenExceptionOccurs()
        {
            // Arrange
            var exceptionMessage = "Database error";
            _systemSettingsRepositoryMock.Setup(repo => repo.GetSystemModulesAsync())
                .ThrowsAsync(new Exception(exceptionMessage));

            // Act
            var result = await _systemSettingsService.GetSystemModulesAsync();

            // Assert
            result.HasError.Should().BeTrue(); // Assert that HasError is true
            result.IsSuccess.Should().BeFalse(); // Assert that IsSuccess is false
            result.StatusCode.Should().Be("500"); // Assert that StatusCode is 500
            result.Result.Should().BeNull(); // Assert that Result is null in the error case
            result.Message.Should().Be(Resource.LogMessage); // Assert that the error message is as expected
 
        }
    }
}
