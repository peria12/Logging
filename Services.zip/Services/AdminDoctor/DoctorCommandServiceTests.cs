﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Aurora.AdministrationService.API.Models.RequestModels.V1.AdminDoctor;
using Aurora.AdministrationService.API.Services.Service.AdminDoctor;
using Aurora.AdministrationService.Domain.V1.Entities.PractitionerRoles;
using Aurora.AdministrationService.Domain.V1.Entities.Practitioners;
using Aurora.AdministrationService.Infrastructure;
using AutoMapper;
using FluentAssertions;
using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Diagnostics;
using Microsoft.EntityFrameworkCore.Infrastructure;
using Microsoft.EntityFrameworkCore.Storage;
using Microsoft.Extensions.Logging;
using Moq;
using Xunit;

namespace Aurora.AdministrationService.Tests.API.Services.AdminDoctor
{
    public class DoctorCommandServiceTests
    {
        private static DoctorCommandService CreateService(ReadWriteDbContext context) => new(context);

        private static UpdatePractitionerInfoRequest GetMockRequest(byte[] version)
        {
            return new UpdatePractitionerInfoRequest
            {
                PractitionerId = 1,
                PractitionerInfo = new PractitionerInfoDto
                {
                    RecordVersion = version,
                    PractitionerNames = new PractitionerNamesDto
                    {
                        FamilyName = "Smith",
                        GivenName = "John",
                        MiddleName = "A.",
                        RecordVersion = version
                    },
                    PractitionerTelecom = new List<PractitionerTelecomInfo>
                    {
                        new PractitionerTelecomInfo { Email = "john@example.com", RecordVersion = version },
                        new PractitionerTelecomInfo { PhoneNumber = "1234567890", RecordVersion = version }
                    },
                    Roles = new List<PractitionerRoleDto>
                    {
                        new PractitionerRoleDto
                        {
                            practitionerRoleCodeInfo = new PractitionerRoleCodeInfo
                            {
                                Code = "Doctor",
                                RecordVersion = version
                            }
                        }
                    },
                    PractitionerIdentifer = new List<PractitionerIdentifer>
                    {
                        new PractitionerIdentifer
                        {
                             IdentifierType="Test",
                             System="Test",
                             Value="Sample"
                        }
                    },
                    PractitionerLocations = new List<PractitionerLocationInfoDto>
                    {
                        new PractitionerLocationInfoDto
                        {
                            LocationId= 1,Location="BTIS",City="Delhi",IsDeleted=false,Name="Test Location",OrganizationId=9,PractitionerId="PRACT456",PractitionerRoleId=10
                        }
                    }
                }
            };
        }

        private static DbContextOptions<ReadWriteDbContext> GetDbContextOptions()
        {
            return new DbContextOptionsBuilder<ReadWriteDbContext>()
                .UseInMemoryDatabase(Guid.NewGuid().ToString())
                .ConfigureWarnings(w => w.Ignore(InMemoryEventId.TransactionIgnoredWarning))
                .Options;
        }

        [Fact]
        public async Task UpdatePractitionerInfo_ShouldReturnTrue_WhenValidDataIsProvided()
        {
            var version = new byte[] { 1, 2, 3 };
            using var context = new ReadWriteDbContext(GetDbContextOptions());

            context.Practitioners.Add(new Practitioner { Id = 1, RecordVersion = version, ResourceID = "RES001", CreatedDate = DateTime.UtcNow, IsDeleted = false, Status = true });
            context.PractitionerName.Add(new PractitionerNames { PractitionerID = 1, RecordVersion = version, Use = "RES001", CreatedBy = "Admin", CreatedDate = DateTime.UtcNow, IsDeleted = false, Status = true, FamilyName = "test", GivenName = "test", Language = "EU", MiddleName = "test", Prefix = "test", Suffix = "test" });
            context.PractitionerTelecoms.AddRange(
                new PractitionerTelecom { PractitionerID = 1, System = "Email", RecordVersion = version, Use = "test", Value = "test", CreatedBy = "Admin", CreatedDate = DateTime.UtcNow, IsDeleted = false, Status = true },
                new PractitionerTelecom { PractitionerID = 1, System = "Phone", RecordVersion = version, Use = "test", Value = "test", CreatedBy = "Admin", CreatedDate = DateTime.UtcNow, IsDeleted = false, Status = true });
            context.PractitionerRoles.Add(new PractitionerRole { Id = 10, PractitionerID = "1", CreatedBy = "Admin", CreatedDate = DateTime.UtcNow, IsDeleted = false, UUID = Guid.Empty, UpdatedBy = "Admin", AvailabilityExceptions = "test" });
            context.PractitionerRoleCodes.Add(new PractitionerRoleCode { PractitionerRoleID = 10, RecordVersion = version, CreatedBy = "Admin", CreatedDate = DateTime.UtcNow, IsDeleted = false, Code = "test", UpdatedBy = "Admin" });
            await context.SaveChangesAsync();

            var result = await CreateService(context).UpdatePractitionerInfo(GetMockRequest(version));

            result.Should().BeTrue();
        }

        [Fact]
        public async Task UpdatePractitionerInfo_ShouldReturnTrue_WhenValidDataIsProvidedSoftDeleteLocation()
        {
            var version = new byte[] { 1, 2, 3 };
            using var context = new ReadWriteDbContext(GetDbContextOptions());

            context.Practitioners.Add(new Practitioner { Id = 1, RecordVersion = version, ResourceID = "RES001", CreatedDate = DateTime.UtcNow, IsDeleted = false, Status = true });
            context.PractitionerName.Add(new PractitionerNames { PractitionerID = 1, RecordVersion = version, Use = "RES001", CreatedBy = "Admin", CreatedDate = DateTime.UtcNow, IsDeleted = false, Status = true, FamilyName = "test", GivenName = "test", Language = "EU", MiddleName = "test", Prefix = "test", Suffix = "test" });
            context.PractitionerTelecoms.AddRange(
                new PractitionerTelecom { PractitionerID = 1, System = "Email", RecordVersion = version, Use = "test", Value = "test", CreatedBy = "Admin", CreatedDate = DateTime.UtcNow, IsDeleted = false, Status = true },
                new PractitionerTelecom { PractitionerID = 1, System = "Phone", RecordVersion = version, Use = "test", Value = "test", CreatedBy = "Admin", CreatedDate = DateTime.UtcNow, IsDeleted = false, Status = true });
            context.PractitionerRoles.Add(new PractitionerRole { Id = 10, PractitionerID = "1", CreatedBy = "Admin", CreatedDate = DateTime.UtcNow, IsDeleted = false, UUID = Guid.Empty, UpdatedBy = "Admin", AvailabilityExceptions = "test" });
            context.PractitionerRoleCodes.Add(new PractitionerRoleCode { PractitionerRoleID = 10, RecordVersion = version, CreatedBy = "Admin", CreatedDate = DateTime.UtcNow, IsDeleted = false, Code = "test", UpdatedBy = "Admin" });
            await context.SaveChangesAsync();

            var request = GetMockRequest(version);
            request.PractitionerInfo.PractitionerLocations.Add(new PractitionerLocationInfoDto
            {
                LocationId = 1,
                Location = "BTIS",
                City = "Delhi",
                IsDeleted = true,
                Name = "Test Location",
                OrganizationId = 9,
                PractitionerId = "PRACT456",
                PractitionerRoleId = 10
            });
            var result = await CreateService(context).UpdatePractitionerInfo(request);

            result.Should().BeTrue();
        }

        [Fact]
        public async Task UpdatePractitionerInfo_ShouldSoftDeleteRoleSpecialty_WhenExists()
        {
            // Arrange
            var version = new byte[] { 1, 2, 3 };
            var practitionerRoleId = 10;

            using var context = new ReadWriteDbContext(GetDbContextOptions());

            // Seed base practitioner and role
            context.Practitioners.Add(new Practitioner
            {
                Id = 1,
                RecordVersion = version,
                ResourceID = "RES001",
                CreatedDate = DateTime.UtcNow,
                IsDeleted = false,
                Status = true
            });

            context.PractitionerRoles.Add(new PractitionerRole
            {
                Id = practitionerRoleId,
                PractitionerID = "1",
                CreatedBy = "Admin",
                CreatedDate = DateTime.UtcNow,
                IsDeleted = false,
                UUID = Guid.NewGuid(),
                UpdatedBy = "Admin",
                AvailabilityExceptions = "N/A"
            });

            // Add PractitionerRoleSpecialty to simulate an existing one
            context.PractitionerRoleSpecialty.Add(new PractitionerRoleSpecialty
            {
                Id = 99,
                PractitionerRoleID = practitionerRoleId,
                Specialty = "General Medicine", // Set the Specialty property here
                CreatedBy = "Admin",
                CreatedDate = DateTime.UtcNow,
                IsDeleted = false,
                UpdatedBy = "Admin", // Make sure UpdatedBy is set here
                UpdatedDate = null
            });

            await context.SaveChangesAsync();

            // Mock request
            var request = GetMockRequest(version);
            request.PractitionerInfo.PractitionerLocations.Add(new PractitionerLocationInfoDto
            {
                LocationId = 1,
                Location = "SomeLocation",
                City = "SomeCity",
                IsDeleted = true,
                Name = "Test Location",
                OrganizationId = 1,
                PractitionerId = "1",
                PractitionerRoleId = practitionerRoleId
            });

            // Act
            var result = await CreateService(context).UpdatePractitionerInfo(request);

            // Assert
            result.Should().BeTrue();

            var updatedSpecialty = await context.PractitionerRoleSpecialty
                .FirstOrDefaultAsync(x => x.PractitionerRoleID == practitionerRoleId);

            updatedSpecialty.Should().NotBeNull();
            updatedSpecialty!.IsDeleted.Should().BeTrue();
            updatedSpecialty.UpdatedBy.Should().NotBeNullOrEmpty();
            updatedSpecialty.UpdatedDate.Should().NotBeNull();
        }

        [Fact]
        public async Task UpdatePractitionerInfo_ShouldUpdate_WhenValidRequestProvided()
        {
            // Arrange
            var version = BitConverter.GetBytes(DateTime.UtcNow.Ticks);
            var request = GetMockRequest(version);
            var options = GetDbContextOptions();

            using (var context = new ReadWriteDbContext(options))
            {
                // Seed practitioner to simulate existing data
                context.Practitioners.Add(new Practitioner
                {
                    Id = request.PractitionerId,
                    RecordVersion = version,
                    CreatedDate = DateTime.UtcNow,
                    IsDeleted = false,
                    ResourceID = "test123",
                    Status = true,
                    
                });

                await context.SaveChangesAsync();
            }

            using (var context = new ReadWriteDbContext(options))
            {
                var service = CreateService(context);

                // Act
                var response = await service.UpdatePractitionerInfo(request);

                // Assert
                response.Should().BeTrue();

                var updatedPractitioner = await context.Practitioners.FindAsync(request.PractitionerId);
                updatedPractitioner.Should().NotBeNull();
                updatedPractitioner.RecordVersion.Should().NotBeNull(); // or check other updated fields
            }
        }

        [Fact]
        public async Task UpdatePractitionerInfo_ShouldRollback_WhenExceptionOccurs()
        {
            // Arrange
            var options = new DbContextOptionsBuilder<ReadWriteDbContext>()
                .UseInMemoryDatabase(Guid.NewGuid().ToString())
                .Options;

            using var context = new ReadWriteDbContext(options);
            var service = new DoctorCommandService(context);

            var request = DoctorCommandServiceTests.GetMockRequest(version: new byte[1]);

            // Inject invalid state to force exception during update
            request.PractitionerInfo.PractitionerNames = null;

            // Act
            Func<Task> action = async () =>
            {
                await service.UpdatePractitionerInfo(request);
            };

            // Assert
            await action.Should().ThrowAsync<Exception>();

            // Optional: verify that no data was committed
            var count = await context.Practitioners.CountAsync();
            count.Should().Be(0);
        }

        [Fact]
        public async Task UpdatePractitionerInfo_ShouldReturnTrue_WhenValidDataIsProvidedAddNewLocation()
        {
            var version = new byte[] { 1, 2, 3 };
            using var context = new ReadWriteDbContext(GetDbContextOptions());

            context.Practitioners.Add(new Practitioner { Id = 1, RecordVersion = version, ResourceID = "RES001", CreatedDate = DateTime.UtcNow, IsDeleted = false, Status = true });
            context.PractitionerName.Add(new PractitionerNames { PractitionerID = 1, RecordVersion = version, Use = "RES001", CreatedBy = "Admin", CreatedDate = DateTime.UtcNow, IsDeleted = false, Status = true, FamilyName = "test", GivenName = "test", Language = "EU", MiddleName = "test", Prefix = "test", Suffix = "test" });
            context.PractitionerTelecoms.AddRange(
                new PractitionerTelecom { PractitionerID = 1, System = "Email", RecordVersion = version, Use = "test", Value = "test", CreatedBy = "Admin", CreatedDate = DateTime.UtcNow, IsDeleted = false, Status = true },
                new PractitionerTelecom { PractitionerID = 1, System = "Phone", RecordVersion = version, Use = "test", Value = "test", CreatedBy = "Admin", CreatedDate = DateTime.UtcNow, IsDeleted = false, Status = true });
            context.PractitionerRoles.Add(new PractitionerRole { Id = 10, PractitionerID = "1", CreatedBy = "Admin", CreatedDate = DateTime.UtcNow, IsDeleted = false, UUID = Guid.Empty, UpdatedBy = "Admin", AvailabilityExceptions = "test" });
            context.PractitionerRoleCodes.Add(new PractitionerRoleCode { PractitionerRoleID = 10, RecordVersion = version, CreatedBy = "Admin", CreatedDate = DateTime.UtcNow, IsDeleted = false, Code = "test", UpdatedBy = "Admin" });
            await context.SaveChangesAsync();

            var request = GetMockRequest(version);
            request.PractitionerInfo.PractitionerLocations.Add(new PractitionerLocationInfoDto
            {
                LocationId = 1,
                Location = "BTIS",
                City = "Delhi",
                IsDeleted = false,
                Name = "Test Location",
                OrganizationId = 9,
                PractitionerId = "PRACT456",
                PractitionerRoleId = 0
            });
            var result = await CreateService(context).UpdatePractitionerInfo(request);

            result.Should().BeTrue();
        }

        [Fact]
        public async Task UpdatePractitionerInfo_ShouldReturnFalse_WhenPractitionerNotFound()
        {
            using var context = new ReadWriteDbContext(GetDbContextOptions());

            var version = new byte[] { 1, 2, 3 };
            var result = await CreateService(context).UpdatePractitionerInfo(GetMockRequest(version));

            result.Should().BeFalse();
        }

        [Fact]
        public async Task UpdatePractitionerInfo_ShouldWork_WhenNameIsNull()
        {
            var version = new byte[] { 1, 2, 3 };
            using var context = new ReadWriteDbContext(GetDbContextOptions());

            context.Practitioners.Add(new Practitioner { Id = 1, RecordVersion = version, ResourceID = "RES001", CreatedDate = DateTime.UtcNow, IsDeleted = false, Status = true });
            await context.SaveChangesAsync();

            var result = await CreateService(context).UpdatePractitionerInfo(GetMockRequest(version));
            result.Should().BeTrue();
        }

        [Fact]
        public async Task UpdatePractitionerInfo_ShouldWork_WhenOnlyEmailExists()
        {
            var version = new byte[] { 1, 2, 3 };
            using var context = new ReadWriteDbContext(GetDbContextOptions());

            context.Practitioners.Add(new Practitioner { Id = 1, RecordVersion = version, ResourceID = "RES001", CreatedDate = DateTime.UtcNow, IsDeleted = false, Status = true });
            context.PractitionerName.Add(new PractitionerNames { PractitionerID = 1, RecordVersion = version, Use = "test", CreatedBy = "Admin", CreatedDate = DateTime.UtcNow, IsDeleted = false, Status = true, FamilyName = "test", GivenName = "test", Language = "EU", MiddleName = "test", Prefix = "test", Suffix = "test" });
            context.PractitionerTelecoms.Add(new PractitionerTelecom { PractitionerID = 1, System = "Email", RecordVersion = version, Use = "test", Value = "test", CreatedBy = "Admin", CreatedDate = DateTime.UtcNow, IsDeleted = false, Status = true });
            await context.SaveChangesAsync();

            var request = GetMockRequest(version);
            request.PractitionerInfo.PractitionerTelecom.RemoveAll(t => !string.IsNullOrEmpty(t.PhoneNumber));

            var result = await CreateService(context).UpdatePractitionerInfo(request);
            result.Should().BeTrue();
        }

        [Fact]
        public async Task UpdatePractitionerInfo_ShouldWork_WhenOnlyPhoneExists()
        {
            var version = new byte[] { 1, 2, 3 };
            using var context = new ReadWriteDbContext(GetDbContextOptions());

            context.Practitioners.Add(new Practitioner { Id = 1, RecordVersion = version, ResourceID = "RES001", CreatedDate = DateTime.UtcNow, IsDeleted = false, Status = true });
            context.PractitionerName.Add(new PractitionerNames { PractitionerID = 1, RecordVersion = version, Use = "RES001", CreatedBy = "Admin", CreatedDate = DateTime.UtcNow, IsDeleted = false, Status = true, FamilyName = "test", GivenName = "test", Language = "EU", MiddleName = "test", Prefix = "test", Suffix = "test" });
            context.PractitionerTelecoms.Add(new PractitionerTelecom { PractitionerID = 1, System = "Phone", RecordVersion = version, Use = "test", CreatedBy = "Admin", CreatedDate = DateTime.UtcNow, IsDeleted = false, Status = true, Value = "test" });
            await context.SaveChangesAsync();

            var request = GetMockRequest(version);
            request.PractitionerInfo.PractitionerTelecom.RemoveAll(t => !string.IsNullOrEmpty(t.Email));

            var result = await CreateService(context).UpdatePractitionerInfo(request);
            result.Should().BeTrue();
        }

        [Fact]
        public async Task UpdatePractitionerInfo_ShouldWork_WhenRoleNotFound()
        {
            var version = new byte[] { 1, 2, 3 };
            using var context = new ReadWriteDbContext(GetDbContextOptions());

            context.Practitioners.Add(new Practitioner { Id = 1, RecordVersion = version, ResourceID = "RES001", CreatedDate = DateTime.UtcNow, IsDeleted = false, Status = true });
            context.PractitionerName.Add(new PractitionerNames { PractitionerID = 1, RecordVersion = version, Use = "RES001", CreatedBy = "Admin", CreatedDate = DateTime.UtcNow, IsDeleted = false, Status = true, FamilyName = "test", GivenName = "test", Language = "EU", MiddleName = "test", Prefix = "test", Suffix = "test" });
            await context.SaveChangesAsync();

            var result = await CreateService(context).UpdatePractitionerInfo(GetMockRequest(version));
            result.Should().BeTrue();
        }

        [Fact]
        public async Task UpdatePractitionerInfo_ShouldWork_WhenRoleCodeIsNull()
        {
            var version = new byte[] { 1, 2, 3 };
            using var context = new ReadWriteDbContext(GetDbContextOptions());

            context.Practitioners.Add(new Practitioner { Id = 1, RecordVersion = version, ResourceID = "RES001", CreatedDate = DateTime.UtcNow, IsDeleted = false, Status = true });
            context.PractitionerName.Add(new PractitionerNames { PractitionerID = 1, RecordVersion = version, Use = "RES001", CreatedBy = "Admin", CreatedDate = DateTime.UtcNow, IsDeleted = false, Status = true, FamilyName = "test", GivenName = "test", Language = "EU", MiddleName = "test", Prefix = "test", Suffix = "test" });
            context.PractitionerRoles.Add(new PractitionerRole { Id = 10, PractitionerID = "1", CreatedBy = "Admin", CreatedDate = DateTime.UtcNow, IsDeleted = false, UUID = Guid.Empty, UpdatedBy = "Admin", AvailabilityExceptions = "test" });
            await context.SaveChangesAsync();

            var result = await CreateService(context).UpdatePractitionerInfo(GetMockRequest(version));
            result.Should().BeTrue();
        }
    }
}
