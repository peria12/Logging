﻿using Moq;
using AutoMapper;
using Aurora.AdministrationService.Infrastructure;
using Aurora.AdministrationService.Domain.V1.Entities.Practitioners;
using Aurora.AdministrationService.API.Models.Dto.ManageVisibility;
using Aurora.AdministrationService.API.Services.IService.AdminDoctor;
using Aurora.AdministrationService.API.Services.Service.AdminDoctor;
using Microsoft.EntityFrameworkCore.Storage;
using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Diagnostics;
using Aurora.AdministrationService.CrossCutting.Constants;

namespace Aurora.AdministrationService.Tests
{
    public class ManageVisibilityCommandServiceTests : TestsBase<ManageVisibilityCommandService>
    {
        private ReadWriteDbContext _dbContext;
        private ManageVisibilityCommandService _commandService;
        private readonly IMapper _mapper = CommonMocks.MockMapper();

        [Fact]
        public async Task ManageDoctorsVisibility_ShouldCommitTransaction_WhenInsertActionsAreSuccessful()
        {
            // Arrange
            DbContextOptions<ReadWriteDbContext> options = new DbContextOptionsBuilder<ReadWriteDbContext>()
           .UseInMemoryDatabase(databaseName: "McareTestDb11").UseQueryTrackingBehavior(QueryTrackingBehavior.NoTracking)
           .ConfigureWarnings(b => b.Ignore(InMemoryEventId.TransactionIgnoredWarning)).Options;
            ReadWriteDbContext _readWriteDbContext = new ReadWriteDbContext(options);
            _commandService = new ManageVisibilityCommandService(_readWriteDbContext, _mapper);

            var doctorVisibilityDto = new List<ManageVisibilityRequestDto>
            {
                new ManageVisibilityRequestDto { Action = AppConstants.INSERT,PractitionerID="PRACT123",LocationID="BRIM",ManageVisibilityId=-10,UserGroups=new List<string>{"Group1","Group2" } },
            };

            // Act
            var result = await _commandService.ManageDoctorsVisibility(doctorVisibilityDto);

            // Assert
            Assert.True(result.isSuccess);
        }
        [Fact]
        public async Task ManageDoctorsVisibility_ShouldCommitTransaction_WhenUpdateActionsAreSuccessful()
        {
            // Arrange
            var doctorVisibilityDto = new List<ManageVisibilityRequestDto>
            {
                new ManageVisibilityRequestDto { Action = AppConstants.UPDATE,PractitionerID="PRACT1",LocationID="BRIM",ManageVisibilityId=2,UserGroups=new List<string>{"Group1","Group2" } },
            };

            DbContextOptions<ReadWriteDbContext> options = new DbContextOptionsBuilder<ReadWriteDbContext>()
            .UseInMemoryDatabase(databaseName: "McareTestDb8").UseQueryTrackingBehavior(QueryTrackingBehavior.NoTracking)
            .ConfigureWarnings(b => b.Ignore(InMemoryEventId.TransactionIgnoredWarning)).Options;
            ManageVisibility manageVisibility = new ManageVisibility()
            {
                ID = 2,
                PractitionerID = "Pract1",
                LocationID = "BRIM",
                IsDeleted = false,
                CreatedDate = DateTime.UtcNow,
                RecordVersion = MockRecordVersion.Generate(),
            };
            ManageVisibilityUserGroups visibilityUserGroups = new ManageVisibilityUserGroups()
            {
                ManageVisibilityID = 2,
                UserGroups = "Group1",
                IsDeleted = false,
                CreatedDate = DateTime.UtcNow,
                RecordVersion = MockRecordVersion.Generate(),
            };

            using (var context = new ReadWriteDbContext(options))
            {
                context.ManageVisibility.Add(manageVisibility);
                context.ManageVisibilityUserGroups.AddRange(visibilityUserGroups);
                await context.SaveChangesAsync();
            }
            ReadWriteDbContext _readWriteDbContext = new ReadWriteDbContext(options);
           
            _commandService = new ManageVisibilityCommandService(_readWriteDbContext, _mapper);


            // Act
            var result = await _commandService.ManageDoctorsVisibility(doctorVisibilityDto);

            // Assert
            Assert.True(result.isSuccess);
        }
        [Fact]
        public async Task ManageDoctorsVisibility_ShouldCommitTransaction_WhenUpdateActionsAreSuccessfulForExistingGroup()
        {
            // Arrange
            var doctorVisibilityDto = new List<ManageVisibilityRequestDto>
            {
                new ManageVisibilityRequestDto { Action = AppConstants.UPDATE,PractitionerID="PRACT1",LocationID="BRIM",ManageVisibilityId=2,UserGroups=new List<string>{"Group1","Group2" } },
            };

            DbContextOptions<ReadWriteDbContext> options = new DbContextOptionsBuilder<ReadWriteDbContext>()
            .UseInMemoryDatabase(databaseName: "McareTestDb1").UseQueryTrackingBehavior(QueryTrackingBehavior.NoTracking)
            .ConfigureWarnings(b => b.Ignore(InMemoryEventId.TransactionIgnoredWarning)).Options;
            ManageVisibility manageVisibility = new ManageVisibility()
            {
                ID = 2,
                PractitionerID = "Pract1",
                LocationID = "BRIM",
                IsDeleted = false,
                CreatedDate = DateTime.UtcNow,
                RecordVersion = MockRecordVersion.Generate(),
            };
           List<ManageVisibilityUserGroups> visibilityUserGroups = new List<ManageVisibilityUserGroups>()
            { 
               new ManageVisibilityUserGroups
               {
                 ManageVisibilityID = 2,
                UserGroups = "Group1",
                IsDeleted = false,
                CreatedDate = DateTime.UtcNow,
                RecordVersion = MockRecordVersion.Generate(),
               },
                new ManageVisibilityUserGroups
               {
                 ManageVisibilityID = 2,
                UserGroups = "Group4",
                IsDeleted = false,
                CreatedDate = DateTime.UtcNow,
                RecordVersion = MockRecordVersion.Generate(),
               },
                 new ManageVisibilityUserGroups
               {
                 ManageVisibilityID = 2,
                UserGroups = "Group5",
                IsDeleted = false,
                CreatedDate = DateTime.UtcNow,
                RecordVersion = MockRecordVersion.Generate(),
               }

            };

            using (var context = new ReadWriteDbContext(options))
            {
                context.ManageVisibility.Add(manageVisibility);
                context.ManageVisibilityUserGroups.AddRange(visibilityUserGroups);
                await context.SaveChangesAsync();
            }
            ReadWriteDbContext _readWriteDbContext = new ReadWriteDbContext(options);
            _commandService = new ManageVisibilityCommandService(_readWriteDbContext, _mapper);

            // Act
            var result = await _commandService.UpdateDoctorsVisibility(doctorVisibilityDto[0]);

            // Assert
            Assert.True(result.isSuccess);
        }

        [Fact]
        public async Task ManageDoctorsVisibility_ShouldRollbackTransaction_WhenAnyActionFails()
        {
            DbContextOptions<ReadWriteDbContext> options = new DbContextOptionsBuilder<ReadWriteDbContext>()
         .UseInMemoryDatabase(databaseName: "McareTestDb13").UseQueryTrackingBehavior(QueryTrackingBehavior.NoTracking)
         .ConfigureWarnings(b => b.Ignore(InMemoryEventId.TransactionIgnoredWarning)).Options;
            ReadWriteDbContext _readWriteDbContext = new ReadWriteDbContext(options);
            _commandService = new ManageVisibilityCommandService(_readWriteDbContext, _mapper);

           // Arrange
            var doctorVisibilityDto = new List<ManageVisibilityRequestDto>
            {
                new ManageVisibilityRequestDto { Action =  AppConstants.INSERT,PractitionerID="PRACT123",LocationID="BRIM",ManageVisibilityId=-10,UserGroups=new List<string>{"Group1","Group2" } },
                new ManageVisibilityRequestDto { Action = "X",PractitionerID="PRACT123",LocationID="BRIM",ManageVisibilityId=1,UserGroups=new List<string>{"Group1","Group2" } },
            };


            // Act
            var result = await _commandService.ManageDoctorsVisibility(doctorVisibilityDto);

            // Assert
            Assert.False(result.isSuccess);
        }

        [Fact]
        public async Task ManageDoctorsVisibility_ShouldHandleEmptyList()
        {
            DbContextOptions<ReadWriteDbContext> options = new DbContextOptionsBuilder<ReadWriteDbContext>()
           .UseInMemoryDatabase(databaseName: "McareTestDb12").UseQueryTrackingBehavior(QueryTrackingBehavior.NoTracking)
           .ConfigureWarnings(b => b.Ignore(InMemoryEventId.TransactionIgnoredWarning)).Options;
            ReadWriteDbContext _readWriteDbContext = new ReadWriteDbContext(options);
            _commandService = new ManageVisibilityCommandService(_readWriteDbContext, _mapper);

            _commandService = new ManageVisibilityCommandService(_readWriteDbContext, _mapper);

            // Arrange
            var doctorVisibilityDto = new List<ManageVisibilityRequestDto>();

            // Act
            var result = await _commandService.ManageDoctorsVisibility(doctorVisibilityDto);

            // Assert
            Assert.False(result.isSuccess);
        }

        [Fact]
        public async Task ManageDoctorsVisibility_ShouldHandleNullList()
        {
            _dbContext = GetReadWriteDBContextInMemory();
            _commandService = new ManageVisibilityCommandService(_dbContext, _mapper);

            // Arrange
            List<ManageVisibilityRequestDto> doctorVisibilityDto = null;

            // Act
            var result = await _commandService.ManageDoctorsVisibility(doctorVisibilityDto);

            // Assert
            Assert.False(result.isSuccess);
        }

        [Fact]
        public async Task CreateDoctorsVisibility_ShouldReturnFalse_WhenManageVisibilityExist()
        {

            // Arrange
            _dbContext = GetReadWriteDBContextInMemory();
            _commandService = new ManageVisibilityCommandService(_dbContext, _mapper);

            var visibilityRequest = GetManageVisibilityRequestDto();
            visibilityRequest.ManageVisibilityId = 10;


            // Act
            var result = await _commandService.CreateDoctorsVisibility(visibilityRequest);

            // Assert
            Assert.False(result.isSuccess);
        }

        [Fact]
        public async Task CreateDoctorsVisibility_ShouldReturnFalse_WhenManageVisibilityIdIsPositive()
        {
            // Arrange
            _dbContext = GetReadWriteDBContextInMemory();
            _commandService = new ManageVisibilityCommandService(_dbContext, _mapper);
            var visibilityRequest = GetManageVisibilityRequestDto();

            // Act
            var result = await _commandService.CreateDoctorsVisibility(visibilityRequest);

            // Assert
            Assert.False(result.isSuccess);
        }

        [Fact]
        public async Task DeleteDoctorsVisibility_ShouldReturnFalse_WhenManageVisibilityIdIsNegative()
        {
            // Arrange
            _dbContext = GetReadWriteDBContextInMemory();
            _commandService = new ManageVisibilityCommandService(_dbContext, _mapper);
            var visibilityRequest = GetManageVisibilityRequestDto();
            visibilityRequest.ManageVisibilityId = -1;

            // Act
            var result = await _commandService.DeleteDoctorsVisibility(visibilityRequest);

            // Assert
            Assert.False(result.isSuccess);
        }

        [Fact]
        public async Task UpdateDoctorsVisibility_ShouldReturnFalse_WhenManageVisibilityIdIsNegative()
        {
            // Arrange
            _dbContext = GetReadWriteDBContextInMemory();
            _commandService = new ManageVisibilityCommandService(_dbContext, _mapper);
            var visibilityRequest = GetManageVisibilityRequestDto();
            visibilityRequest.ManageVisibilityId = -1;

            // Act
            var result = await _commandService.UpdateDoctorsVisibility(visibilityRequest);

            // Assert
            Assert.False(result.isSuccess);
        }

        [Fact]
        public async Task DeleteDoctorsVisibility_ShouldReturnFalse_WhenManageVisibilityDoesNotExist()
        {

            // Arrange
            _dbContext = GetReadWriteDBContextInMemory();
            _commandService = new ManageVisibilityCommandService(_dbContext, _mapper);

            var visibilityRequest = GetManageVisibilityRequestDto();
            visibilityRequest.ManageVisibilityId = 10;


            // Act
            var result = await _commandService.DeleteDoctorsVisibility(visibilityRequest);

            // Assert
            Assert.False(result.isSuccess);
        }

        [Fact]
        public async Task ManageDoctorVisibility_ShouldCommitTransaction_WhenDeleteActionsAreSuccessful() 
        {
            // Arrange
            DbContextOptions<ReadWriteDbContext> options = new DbContextOptionsBuilder<ReadWriteDbContext>()
                 .UseInMemoryDatabase(databaseName: "McareTestDb2").UseQueryTrackingBehavior(QueryTrackingBehavior.NoTracking)
                 .ConfigureWarnings(b => b.Ignore(InMemoryEventId.TransactionIgnoredWarning)).Options;

            
            var visibilityRequest = new List<ManageVisibilityRequestDto>
            {
                new ManageVisibilityRequestDto { Action = AppConstants.DELETE,PractitionerID="PRACT1",LocationID="BRIM",ManageVisibilityId=1,UserGroups=new List<string>{"Group1","Group2" } },
            };
            var visibility = new ManageVisibility
            {
                ID = 1,
                PractitionerID = "PRACT1",
                LocationID = "BRIM",
                IsDeleted = false,
                RecordVersion = MockRecordVersion.Generate(),
                CreatedDate = DateTime.UtcNow
            };

            var userGroups = new List<ManageVisibilityUserGroups>
    {
        new ManageVisibilityUserGroups { ManageVisibilityID = 1, UserGroups = "Group1", IsDeleted = false ,CreatedDate=DateTime.UtcNow},
        new ManageVisibilityUserGroups { ManageVisibilityID = 1, UserGroups = "Group2", IsDeleted = false ,CreatedDate=DateTime.UtcNow}
    };

            using (var context = new ReadWriteDbContext(options))
            {
                context.ManageVisibility.Add(visibility);
                context.ManageVisibilityUserGroups.AddRange(userGroups);
                await context.SaveChangesAsync();
            }
            ReadWriteDbContext _readWriteDbContext = new ReadWriteDbContext(options);
            _commandService = new ManageVisibilityCommandService(_readWriteDbContext, _mapper);
                      

            // Act
            var result = await _commandService.ManageDoctorsVisibility(visibilityRequest);

            // Assert
            Assert.True(result.isSuccess);

            // Verify that the 'IsDeleted' flag was set to true for both ManageVisibility and ManageVisibilityUserGroups
            using (var context = new ReadWriteDbContext(options))
            {
                var updatedVisibility = await context.ManageVisibility.FindAsync(1L);
                Assert.True(updatedVisibility.IsDeleted);

                var updatedUserGroups = await context.ManageVisibilityUserGroups.Where(ug => ug.ManageVisibilityID == 1L).ToListAsync();
                Assert.All(updatedUserGroups, ug => Assert.True(ug.IsDeleted));
            }
        }

        [Fact]
        public async Task DeleteDoctorsVisibility_ShouldReturnFalse_WhenSavingChangesFails()
        {
            // Arrange
            DbContextOptions<ReadWriteDbContext> options = new DbContextOptionsBuilder<ReadWriteDbContext>()
                   .UseInMemoryDatabase(databaseName: "McareTestDb3").UseQueryTrackingBehavior(QueryTrackingBehavior.NoTracking)
                   .ConfigureWarnings(b => b.Ignore(InMemoryEventId.TransactionIgnoredWarning)).Options;

            var visibilityRequest = GetManageVisibilityRequestDto();
            visibilityRequest.ManageVisibilityId = 5;

            var visibility = GetManageVisilityData();
            visibility.ID = 1;

            using (var context = new ReadWriteDbContext(options))
            {
                context.ManageVisibility.Add(visibility);
                await context.SaveChangesAsync();
            }
            ReadWriteDbContext _readWriteDbContext = new ReadWriteDbContext(options);
            _commandService = new ManageVisibilityCommandService(_readWriteDbContext, _mapper);

            // Act
            var result = await _commandService.DeleteDoctorsVisibility(visibilityRequest);

            // Assert
            Assert.False(result.isSuccess);
        }


        private static ManageVisibility GetManageVisilityData()
        {
            return new ManageVisibility()
            {
                ID = 2,
                PractitionerID = "Pract1",
                LocationID = "BRIM",
                IsDeleted = false,
                CreatedDate = DateTime.UtcNow,
                RecordVersion = MockRecordVersion.Generate(),
            };
        }
        private static ManageVisibilityRequestDto GetManageVisibilityRequestDto()
        {
            return new ManageVisibilityRequestDto()
            {
                Action = "I",
                PractitionerID = "PRACT123",
                LocationID = "BRIM",
                ManageVisibilityId = 1,
                UserGroups = new List<string> { "Group1", "Group2" }
            };
        }

    }
}
