﻿using Aurora.AdministrationService.API.Enum;
using Aurora.AdministrationService.API.Models.Dto.Practitioners;
using Aurora.AdministrationService.API.Models.RequestModels.V1.AdminDoctor;
using Aurora.AdministrationService.API.Models.ResponseModels.Practitioners;
using Aurora.AdministrationService.API.Resources;
using Aurora.AdministrationService.API.Services.IService.AdminDoctor;
using Aurora.AdministrationService.API.Services.Service.AdminDoctor;
using Aurora.AdministrationService.CrossCutting.CommonModels;
using Aurora.AdministrationService.CrossCutting.Constants;
using Aurora.AdministrationService.CrossCutting.Extensions;
using Aurora.AdministrationService.Domain.V1.Entities;
using Aurora.AdministrationService.Domain.V1.Entities.HealthcareService;
using Aurora.AdministrationService.Domain.V1.Entities.Locations;
using Aurora.AdministrationService.Domain.V1.Entities.Organizations;
using Aurora.AdministrationService.Domain.V1.Entities.PractitionerRoles;
using Aurora.AdministrationService.Domain.V1.Entities.Practitioners;
using Aurora.AdministrationService.Infrastructure;
using Aurora.AdministrationService.Tests.API.CommonMock;
using FluentAssertions;
using Microsoft.AspNetCore.Http;
using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.Primitives;
using Moq;

namespace Aurora.AdministrationService.Tests.API.Services.AdminDoctor
{
    public class DoctorQueryServiceTests
    {
        private readonly DoctorQueryService _doctorQueryService;
        private readonly ReadOnlyDbContext _dbContext;
        private readonly Mock<IHttpContextAccessor> _httpContextAccessorMock;
        public DoctorQueryServiceTests()
        {

            // Set up in-memory database
            var options = new DbContextOptionsBuilder<ReadOnlyDbContext>()
                .UseInMemoryDatabase(databaseName: Guid.NewGuid().ToString())
                .Options;

            _dbContext = new ReadOnlyDbContext(options);

            // Seed data
            SeedData();

            // Set up the service
            _httpContextAccessorMock = new Mock<IHttpContextAccessor>();
            _doctorQueryService = new DoctorQueryService(_dbContext);
        }

        private void SeedData()
        {

            var practitioner = new Practitioner
            {
                Id = 1,
                ResourceID = "12345",
                Status = true,
                IsDeleted = false,
                CreatedBy = "Admin",
                CreatedDate = DateTime.Now,
                Gender = "Male",
                Source = "Aurora",
                UpdatedBy = "Admin"
            };

            var doctorProfile = new ManageDoctorProfile
            {
                Id = 1,
                PractitionerID = 1,
                FirstName = "John",
                LastName = "Doe",
                IsDeleted = false,
                CreatedDate = DateTime.Now,
                CreatedBy = "Admin"
            };

            var role = new PractitionerRole
            {
                Id = 1,
                UUID = Guid.NewGuid(),
                PractitionerID = "12345",
                OrganizationID = 1,
                IsDeleted = false,
                CreatedBy = "Admin",
                CreatedDate = DateTime.Now,
                AvailabilityExceptions = "Test",
                UpdatedBy = "Admin"
            };

            var practitionerPhotos = new PractitionerPhotos
            {
                Id = 1,
                PractitionerID = 1,
                Status = true,
                IsDeleted = false,
                CreatedBy = "Admin",
                CreatedDate = DateTime.Now,
                ContentType = "Json",
                Data = Array.Empty<byte>(),
                Hash = "Test",
                Size = "100",
                Title = "Test1",
                URL = "www.photo.com",
                UpdatedBy = "Admin",
                CreationDate = DateTime.UtcNow
            };

            var practitionerNames = new PractitionerNames
            {
                Id = 1,
                PractitionerID = 1,
                GivenName = "John",
                MiddleName = "Glen",
                FamilyName = "Dsouza",
                Language = "English",
                Prefix = "Dr. ",
                Suffix = "Dr. ",
                CreatedBy = "Admin",
                CreatedDate = DateTime.Now,
                IsDeleted = false,
                Status = true,
                Use = "Official",
                PeriodStart = DateTime.Now,
                PeriodEnd = DateTime.Now.AddYears(1)
            };


            var practitionerRoleLocation = new PractitionerRoleLocation
            {
                Id = 1,
                PractitionerRoleID = 1,
                locationID = 1,
                IsInternalPractitioner = true,
                IsDeleted = false,
                CreatedBy = "Admin",
                CreatedDate = DateTime.Now,
                UpdatedBy = "Admin"
            };

            var practitionerRoleCode = new PractitionerRoleCode
            {
                PractitionerRoleID = 1,
                Code = "Doctor",
                IsDeleted = false,
                CreatedBy = "admin",
                CreatedDate = DateTime.Now,
                UpdatedBy = "admin",
                UpdatedDate = DateTime.Now
            };

            var practitionerRoleSpecialty = new PractitionerRoleSpecialty
            {
                PractitionerRoleID = 1,
                Specialty = "Cardiology",
                IsDeleted = false,
                CreatedBy = "admin",
                CreatedDate = DateTime.Now,
                UpdatedBy = "admin",
                UpdatedDate = DateTime.Now
            };

            var specialtyMaster = new Domain.V1.Entities.HealthcareService.HealthcareServices { Name = "Cardiology", LaymanDescription = "Cardiology-Related to Heart", CreatedBy = "Aurora", CreatedDate = DateTime.UtcNow, RecordVersion = Array.Empty<byte>(), Status = true, IsDeleted = false };

            var roleMaster = new RoleMaster { Code = "Doctor", IsDeleted = false, CreatedDate = DateTime.Today };

            var organization = new Organization
            {
                Id = 1,
                ResourceID = "ORG12345",
                Alias = "Test",
                Name = "Columbia Asia",
                Source = "Aurora",
                Type = "Test1",
                IsDeleted = false,
                CreatedBy = "Admin",
                CreatedDate = DateTime.Now,
                UpdatedBy = "Admin"
            };

            var location = new Location
            {
                Id = 1,
                ResourceID = "LOC12345",
                Status = true,
                Name = "Main Hospital",
                CreatedBy = "Admin",
                CreatedDate = DateTime.Now
            };

            var locationAddress = new LocationAddress
            {
                Id = 1,
                LocationID = 1,
                City = "Bukit Jalil",
                Use = "Business",
                Status = true,
                IsDeleted = false,
                CreatedBy = "Admin",
                CreatedDate = DateTime.Now,
                UpdatedBy = "Admin"
            };


            _dbContext.Practitioners.Add(practitioner);
            _dbContext.ManageDoctorProfiles.Add(doctorProfile);
            _dbContext.PractitionerRoles.Add(role);
            _dbContext.PractitionerPhoto.Add(practitionerPhotos);
            _dbContext.PractitionerName.Add(practitionerNames);
            _dbContext.PractitionerRoleLocation.Add(practitionerRoleLocation);
            _dbContext.PractitionerRoleCodes.Add(practitionerRoleCode);
            _dbContext.PractitionerRoleSpecialty.Add(practitionerRoleSpecialty);
            _dbContext.HealthcareServices.Add(specialtyMaster);
            _dbContext.RoleMasters.Add(roleMaster);
            _dbContext.Organizations.Add(organization);
            _dbContext.Locations.Add(location);
            _dbContext.LocationAddresses.Add(locationAddress);

            _dbContext.SaveChanges();

            var availability = new PractitionerAvailability
            {
                Id = 99,
                CreatedBy = "Admin",
                CreatedDate = DateTime.UtcNow,
                UpdatedBy = "Admin",
                IsDeleted = false,
                ScheduleStartDate = DateTime.UtcNow,
                ScheduleEndDate = DateTime.UtcNow,
                SlotsID = 1,
                PractitionerRoleId = 1, // Ensure this links to the existing PractitionerRole
                PractitionerAvailabilityDay = new List<PractitionerAvailabilityDay>
            {
        new PractitionerAvailabilityDay
        {
            Id = 100,
            PractitionerAvailabilityID = 99,
            AvailabilityDay = "Monday,Wednesday",
            StartTime = TimeSpan.Parse("09:00"),
            EndTime = TimeSpan.Parse("17:00"),
            CreatedBy = "Admin",
            CreatedDate = DateTime.UtcNow,
            UpdatedBy = "Admin",
            IsDeleted = false
        }
    }
            };

            _dbContext.PractitionerAvailabilities.Add(availability);
            _dbContext.SaveChanges();


        }


        [Fact]
        public async Task SearchDoctorByNameAndSpeciality_ShouldReturnDoctors_WhenDataExists()
        {
            // Arrange
            var search = "John";
            var role = "Doctor";

            // Act
            var result = await _doctorQueryService.SearchDoctorByNameAndSpeciality(search, role);

            // Assert
            result.IsSuccess.Should().BeTrue();
            result.StatusCode.Should().Be(((int)ResponceStatusCode.Success).ToString());
            result.Message.Should().Be(ResponseMessage.STATUS_SUCCESS);
            result.Results.Should().NotBeEmpty();
            result.Results!.First().FirstName.Should().Be("John");
            result.Results!.First().PractitionerRolesSearchLocation.Select(x => x.Speciality).Should().Contain("Cardiology");
        }

        [Fact]
        public async Task SearchDoctorByNameAndSpeciality_ShouldReturnNoData_WhenNoDoctorFound()
        {
            // Arrange
            var search = "NotExist";
            var role = "Doctor";

            // Act
            var result = await _doctorQueryService.SearchDoctorByNameAndSpeciality(search, role);

            // Assert
            result.IsSuccess.Should().BeFalse();
            result.StatusCode.Should().Be(((int)ResponceStatusCode.RecordNotFound).ToString());
            result.Message.Should().Be(ResponseMessage.STATUS_NODATA);
        }

        [Fact]
        public async Task SearchDoctorByNameAndSpeciality_ShouldReturnDoctors_WhenRoleMatches()
        {
            // Arrange
            var search = "John";
            var role = "Doctor";

            // Act
            var result = await _doctorQueryService.SearchDoctorByNameAndSpeciality(search, role);

            // Assert
            result.Results.Should().NotBeEmpty();
            result.Results!.First().PractitionerRolesSearchLocation.Select(x => x.AddressCity).Should().Contain("Bukit Jalil");
        }

        [Fact]
        public async Task SearchDoctorByNameAndSpeciality_ShouldHandleExceptionGracefully()
        {
            // Arrange
            var search = "John";
            var role = "InvalidRole"; // This will cause no data to match

            // Act
            var result = await _doctorQueryService.SearchDoctorByNameAndSpeciality(search, role);

            // Assert
            result.IsSuccess.Should().BeFalse();
            result.HasError.Should().BeTrue();
            result.Message.Should().NotBeNullOrWhiteSpace();
        }


        [Fact]
        public async Task GetPractitionerInfo_ShouldReturnData_WhenValidDoctorProfileIdProvided()
        {
            var options = new DbContextOptionsBuilder<ReadOnlyDbContext>()
                .UseInMemoryDatabase(databaseName: "GetPractitionerInfoTestDb")
                .Options;

            using (var context = new ReadOnlyDbContext(options))
            {
                // Arrange
                var practitioner = new Practitioner
                {
                    Id = 1,
                    ResourceID = "RES001",
                    Gender = "Male",
                    IsDeleted = false,
                    RecordVersion = new byte[] { 1, 2, 3, 4 },
                    Status = true,
                    CreatedBy = "Admin",
                    CreatedDate = DateTime.UtcNow,
                    Source = "dfd asd",
                    UpdatedBy = "Admin"
                };

                var practitionerName = new PractitionerNames
                {
                    Id = 1,
                    PractitionerID = 1,
                    FamilyName = "Smith",
                    GivenName = "John",
                    MiddleName = "D",
                    IsDeleted = false,
                    RecordVersion = new byte[] { 1, 2, 3, 4 },
                    Use = "Asd asd",
                    Status = true,
                    CreatedBy = "admin",
                    CreatedDate = DateTime.UtcNow,
                    Language = "English",
                    Prefix = "Dr",
                    Suffix = "Jr"
                };

                var practitionerTelecom = new PractitionerTelecom
                {
                    Id = 1,
                    PractitionerID = 1,
                    System = "Email",
                    Use = "Home",
                    Value = "john.smith@email.com",
                    IsDeleted = false,
                    RecordVersion = new byte[] { 1, 2, 3, 4 },
                    Status = true,
                    CreatedBy = "admin",
                    CreatedDate = DateTime.UtcNow
                };

                var practitionerIdentifier = new PractitionerIdentifier
                {
                    Id = 1,
                    PractitionerID = 1,
                    System = "M and f",
                    IdentifierUse = "Identifier",
                    IdentifierType = "License",
                    Value = "LIC123456",
                    IsDeleted = false,
                    RecordVersion = new byte[] { 1, 2, 3, 4 },
                    Status = true,
                    CreatedBy = "admin",
                    CreatedDate = DateTime.UtcNow
                };

                var practitionerRole = new PractitionerRole
                {
                    Id = 4,
                    PractitionerID = "RES001",
                    OrganizationID = 100,
                    LocationID = "LOC001",
                    IsDeleted = false,
                    RecordVersion = new byte[] { 1, 2, 3, 4 },
                    UUID = Guid.NewGuid(),
                    AvailabilityExceptions = "AvailableAt",
                    UpdatedBy = "admin",
                    CreatedBy = "admin",
                    CreatedDate = DateTime.UtcNow
                };

                var roleCode = new PractitionerRoleCode
                {
                    Id = 1,
                    PractitionerRoleID = 4,
                    Code = "CARD",
                    IsDeleted = false,
                    RecordVersion = new byte[] { 1, 2, 3, 4 },
                    CreatedBy = "admin",
                    UpdatedBy = "admin",
                    CreatedDate = DateTime.UtcNow
                };

                var roleLocation = new PractitionerRoleLocation
                {
                    Id = 1,
                    PractitionerRoleID = 4,
                    locationID = 1,
                    IsInternalPractitioner = true,
                    IsDeleted = false,
                    CreatedBy = "admin",
                    UpdatedBy = "admin",
                    CreatedDate = DateTime.UtcNow
                };

                var location = new Location
                {
                    Id = 1,
                    ResourceID = "LOC001",
                    Name = "General Hospital",
                    IsDeleted = false,
                    RecordVersion = new byte[] { 1, 2, 3, 4 },
                    Status = true,
                    CreatedBy = "admin",
                    UpdatedBy = "admin",
                    CreatedDate = DateTime.UtcNow
                };

                var locationadd = new LocationAddress
                {
                    Id = 1,
                    LocationID = 1,
                    Use = "adad",
                    City = "Jalil",
                    IsDeleted = false,
                    RecordVersion = new byte[] { 1, 2, 3, 4 },
                    Status = true,
                    CreatedBy = "admin",
                    UpdatedBy = "admin",
                    CreatedDate = DateTime.UtcNow
                };
                var healthcareService = new Domain.V1.Entities.HealthcareService.HealthcareServices
                {
                    ID = 1,
                    Name = "Cardiology",
                    LaymanDescription = "Heart Specialist",
                    Location = "LOC001",
                    IsDeleted = false,
                    RecordVersion = new byte[] { 1, 2, 3, 4 },
                    Status = true,
                    CreatedDate = DateTime.UtcNow,
                    UpdatedBy = "admin",
                    CreatedBy = "admin"
                };

                // Seed all entities
                await context.Practitioners.AddAsync(practitioner);
                await context.PractitionerName.AddAsync(practitionerName);
                await context.PractitionerTelecoms.AddAsync(practitionerTelecom);
                await context.PractitionerIdentifiers.AddAsync(practitionerIdentifier);
                await context.PractitionerRoles.AddAsync(practitionerRole);
                await context.PractitionerRoleCodes.AddAsync(roleCode);
                await context.PractitionerRoleLocation.AddAsync(roleLocation);
                await context.Locations.AddAsync(location);
                await context.LocationAddresses.AddAsync(locationadd);
                await context.HealthcareServices.AddAsync(healthcareService);

                await context.SaveChangesAsync();

                var service = new DoctorQueryService(context);

                // Act
                var result = await service.GetPractitionerInfo(1);

                // Assert
                result.Should().NotBeNull();
                result.PractitionerId.Should().Be(1);
                result.UniqueId.Should().Be("RES001");

                result.PractitionerInfo.Should().NotBeNull();
                result.PractitionerInfo.Gender.Should().Be("Male");
            }
        }

        [Fact]
        public async Task GetDoctorList_ShouldReturnData_WhenValidFiltersProvided()
        {
            // Arrange
            var options = new DbContextOptionsBuilder<ReadOnlyDbContext>()
                .UseInMemoryDatabase(databaseName: Guid.NewGuid().ToString()) // Unique DB per test
                .Options;

            using (var context = new ReadOnlyDbContext(options))
            {
                // Seed test data
                var practitioner = new Practitioner
                {
                    Id = 1,
                    ResourceID = "DOC123",
                    IsDeleted = false,
                    Status = true,
                    CreatedBy = "admin",
                    CreatedDate = DateTime.UtcNow,
                    UpdatedBy = "admin",
                    Gender = "Male",
                    Source = "TestSource"
                };

                var practitionerName = new PractitionerNames
                {
                    Id = 1,
                    PractitionerID = 1,
                    GivenName = "John",
                    FamilyName = "Doe",
                    MiddleName = "A",
                    IsDeleted = false,
                    Use = "Prefix",
                    Prefix = "Dr",
                    Suffix = "MD",
                    Language = "English",
                    Status = true,
                    CreatedBy = "admin",
                    CreatedDate = DateTime.UtcNow
                };

                var practitionerTelecom = new PractitionerTelecom
                {
                    Id = 1,
                    PractitionerID = 1,
                    System = "Email",
                    Value = "john.doe@email.com",
                    IsDeleted = false,
                    CreatedBy = "admin",
                    CreatedDate = DateTime.UtcNow,
                    Use = "Work",
                    Status = true
                };

                await context.Practitioners.AddAsync(practitioner);
                await context.PractitionerName.AddAsync(practitionerName);
                await context.PractitionerTelecoms.AddAsync(practitionerTelecom);
                await context.SaveChangesAsync();
                context.ChangeTracker.Clear(); // Ensure clean querying

                var service = new DoctorQueryService(context);
                var requestDto = new DoctorListRequest
                {
                    Pagination = new PaginationQuery { PageSize = 10, PageNumber = 1 },
                    ResourceId = "DOC123",
                    Name = "John",
                    Email = "john.doe@email.com"
                };

                // Act
                var response = await service.GetDoctorList(requestDto);

                // Assert
                response.Should().NotBeNull();
                response.Results.Should().NotBeNull(); // Ensure list exists
                response.Results.Should().HaveCount(1); // Ensure 1 doctor is returned
                response.Results.First().GivenName.Should().Be("John");
                response.Results.First().FamilyName.Should().Be("Doe");
                response.Results.First().Email.Should().Be("john.doe@email.com");
            }
        }

        [Fact]
        public async Task GetDoctorList_ShouldReturnMultipleDoctors_WhenMultipleMatchesExist()
        {
            // Arrange
            var options = new DbContextOptionsBuilder<ReadOnlyDbContext>()
                .UseInMemoryDatabase(databaseName: Guid.NewGuid().ToString())
                .Options;

            using (var context = new ReadOnlyDbContext(options))
            {
                // Seed multiple doctor records
                var doctor1 = new Practitioner
                {
                    Id = 1,
                    ResourceID = "DOC123",
                    IsDeleted = false,
                    Status = true,
                    CreatedBy = "admin",
                    CreatedDate = DateTime.UtcNow,
                    UpdatedBy = "admin",
                    Gender = "Male",
                    Source = "TestSource"
                };
                var doctor2 = new Practitioner
                {
                    Id = 2,
                    ResourceID = "DOC124",
                    IsDeleted = false,
                    Status = true,
                    CreatedBy = "admin",
                    CreatedDate = DateTime.UtcNow,
                    UpdatedBy = "admin",
                    Gender = "Male",
                    Source = "TestSource"
                };

                await context.Practitioners.AddRangeAsync(doctor1, doctor2);
                await context.SaveChangesAsync();

                var service = new DoctorQueryService(context);
                var queryDto = new DoctorListRequest
                {
                    Pagination = new PaginationQuery { PageSize = 10, PageNumber = 1 }
                };

                // Act
                var response = await service.GetDoctorList(queryDto);

                // Assert
                response.Results.Should().NotBeEmpty();
                response.Results.Should().HaveCount(2); // Ensure both doctors are returned
            }
        }

        [Fact]
        public async Task GetDoctorList_ShouldHandleNullFilters_WithoutThrowingException()
        {
            // Arrange
            var options = new DbContextOptionsBuilder<ReadOnlyDbContext>()
                .UseInMemoryDatabase(databaseName: Guid.NewGuid().ToString())
                .Options;

            using (var context = new ReadOnlyDbContext(options))
            {
                // Seed doctor
                await context.Practitioners.AddAsync(new Practitioner
                {
                    Id = 1,
                    ResourceID = "DOC123",
                    IsDeleted = false,
                    Status = true,
                    CreatedBy = "admin",
                    CreatedDate = DateTime.UtcNow,
                    UpdatedBy = "admin",
                    Gender = "Male",
                    Source = "TestSource"
                });
                await context.SaveChangesAsync();

                var service = new DoctorQueryService(context);
                var queryDto = new DoctorListRequest
                {
                    Pagination = new PaginationQuery { PageSize = 10, PageNumber = 1 }
                };

                // Act & Assert - Ensure no exception is thrown when passing a minimal query object
                await FluentActions.Invoking(() => service.GetDoctorList(queryDto))
                    .Should().NotThrowAsync();
            }
        }
        [Fact]
        public async Task GetPractitionerCode_ShouldReturnSuccess_WhenPractitionerCodeExists()
        {
            // Arrange
            long id = 1;
            var options = new DbContextOptionsBuilder<ReadOnlyDbContext>()
            .UseInMemoryDatabase(databaseName: "TestDb1")
            .Options;

            var dbContext = new ReadOnlyDbContext(options);


            // Mocked DbSet for Practitioners
            var practitioners = new List<Practitioner>
            {
             new Practitioner { Id = 1, ResourceID = "100", IsDeleted = false,CreatedBy="Test",CreatedDate=DateTime.UtcNow,Status=true,Gender="Male", Source="Test", UpdatedBy="Test"}
            };

            // Mocked DbSet for PractitionerRoles
            var roles = new List<PractitionerRole>
            {
              new() { Id = 1, PractitionerID = "100", IsDeleted = false,CreatedBy="Test",CreatedDate=DateTime.UtcNow,UUID=Guid.NewGuid(),AvailabilityExceptions="Test", UpdatedBy="Test" }
             };

            // Mocked DbSet for PractitionerRoleCodes
            var roleCodes = new List<PractitionerRoleCode>
            {
                    new PractitionerRoleCode { Id = 1, PractitionerRoleID = 1, Code = "Doctor", IsDeleted = false ,CreatedBy="Test",CreatedDate=DateTime.UtcNow,UpdatedBy = "Test" }
            };

            dbContext.Practitioners.AddRange(practitioners);
            dbContext.PractitionerRoles.AddRange(roles);
            dbContext.PractitionerRoleCodes.AddRange(roleCodes);
            await dbContext.SaveChangesAsync();

            var _Service = new DoctorQueryService(_dbContext);

            // Act
            var response = await _Service.GetPractitionerCode(id);

            // Assert
            Assert.True(response.IsSuccess);
            Assert.False(response.HasError);
            Assert.Equal(((int)ResponceStatusCode.Success).ToString(), response.StatusCode);
            Assert.Equal(ResponseMessage.STATUS_SUCCESS, response.Message);
        }

        #region  

        [Fact]
        public async Task SearchDoctorByNameAndSpeciality_ShouldReturnEmpty_WhenNoMatchingDoctors()
        {
            // Arrange
            var search = "Unknown";
            var role = "InvalidRole";

            // Act
            var result = await _doctorQueryService.SearchDoctorByNameAndSpeciality(search, role);

            // Assert
            result.IsSuccess.Should().BeFalse();
            result.HasError.Should().BeTrue();
            result.StatusCode.Should().Be(((int)ResponceStatusCode.RecordNotFound).ToString());
            result.Message.Should().Be(ResponseMessage.STATUS_NODATA);
        }

        [Fact]
        public async Task SearchDoctorByNameAndSpeciality_ShouldHandleException()
        {
            // Arrange
            var faultyService = new DoctorQueryService(null!); // simulate a null DB
            var search = "Cardio";
            var role = "Doctor";

            // Act
            var result = await faultyService.SearchDoctorByNameAndSpeciality(search, role);

            // Assert
            result.IsSuccess.Should().BeFalse();
            result.HasError.Should().BeTrue();
            result.Message.Should().NotBeNullOrEmpty();
            result.StatusCode.Should().Be(ResponseStatus.STATUS_BadRequest.ToString());
        }

        [Fact]
        public async Task SearchDoctorByNameAndSpeciality_ShouldReturnAllDoctors_WhenSearchIsNull()
        {
            // Arrange
            string search = null;
            var role = "Doctor";

            // Act
            var result = await _doctorQueryService.SearchDoctorByNameAndSpeciality(search, role);

            // Assert
            result.IsSuccess.Should().BeTrue();
            result.Results.Should().NotBeNull();
            result.Results.Should().HaveCount(1);
        }

        [Fact]
        public async Task SearchDoctorByNameAndSpeciality_ShouldReturnDoctor_WhenLastNameMatchesSearch()
        {
            // Arrange
            var search = "doe"; // matches LastName (case-insensitive)
            var role = "Doctor";

            // Act
            var result = await _doctorQueryService.SearchDoctorByNameAndSpeciality(search, role);

            // Assert
            result.IsSuccess.Should().BeTrue();
            result.Results.Should().HaveCount(1);
            result.Results.First().LastName.Should().Be("Doe");
        }


        [Fact]
        public async Task SearchDoctorByNameAndSpeciality_ShouldReturnDoctor_WhenHealthcareServiceNameMatches()
        {
            // Arrange
            var search = "cardiology"; // healthcare service name
            var role = "Doctor";

            // Act
            var result = await _doctorQueryService.SearchDoctorByNameAndSpeciality(search, role);

            // Assert
            result.IsSuccess.Should().BeTrue();
            var doctor = result.Results.First();
            doctor.PractitionerRolesSearchLocation.FirstOrDefault().Speciality.Should().Be("Cardiology");
        }


        [Fact]
        public async Task SearchDoctorByNameAndSpeciality_ShouldReturnDoctor_WhenPhotoIsMissing()
        {
            // Arrange - Remove photo
            var photo = await _dbContext.PractitionerPhoto.FirstAsync();
            _dbContext.PractitionerPhoto.Remove(photo);
            await _dbContext.SaveChangesAsync();

            var role = "Doctor";

            // Act
            var result = await _doctorQueryService.SearchDoctorByNameAndSpeciality("John", role);

            // Assert
            result.IsSuccess.Should().BeTrue();
            result.Results.First().ImageUrl.Should().BeNullOrEmpty(); // ✅ handles both null and ""
        }

        #endregion
        #region Get Practinor Code

        [Fact]
        public async Task GetPractitionerCode_PractitionerFound_ReturnsPractitionerCode()
        {
            // Arrange
            long id = 1;
            // Act
            var result = await _doctorQueryService.GetPractitionerCode(id);

            // Assert
            result.IsSuccess.Should().BeTrue();
            result.HasError.Should().BeFalse();
            result.Results.Should().NotBeNullOrEmpty();
            result.StatusCode.Should().Be(((int)ResponceStatusCode.Success).ToString());
            result.Message.Should().Be(ResponseMessage.STATUS_SUCCESS);
        }

        #endregion

        #region GetTimeZones
        [Fact]
        public void GetTimeZones_WithIDNRegionCode_ReturnsIndonesiaTimeZone()
        {
            // Arrange
            _httpContextAccessorMock.Setup(h => h.HttpContext.Request.Headers.TryGetValue(It.IsAny<string>(), out It.Ref<StringValues>.IsAny))
                .Returns(true)
                .Callback((string key, out StringValues value) =>
                {
                    value = AppConstants.IDNRegionCode; // Simulate region code for Indonesia
                });

            // Act
            var result = _doctorQueryService.GetTimeZones();

            // Assert
            result.IsSuccess.Should().BeTrue();
            result.HasError.Should().BeFalse();
            result.StatusCode.Should().Be(ResponseStatus.STATUS_SUCCESS);
            result.Message.Should().Be(Resource.RecordListingMessage);
            result.Results.Should().ContainSingle();
            result.Results.First().TimeZoneName.Should().Be($"Asia/{AppConstants.MalaysiaCity}"); // Change to Asia/Kuala Lumpur
        }

        [Fact]
        public void GetTimeZones_WithVNMRegionCode_ReturnsVNMTimeZone()
        {
            // Arrange
            _httpContextAccessorMock.Setup(h => h.HttpContext.Request.Headers.TryGetValue(It.IsAny<string>(), out It.Ref<StringValues>.IsAny))
                .Returns(true)
                .Callback((string key, out StringValues value) =>
                {
                    value = AppConstants.VNMRegionCode; // Simulate region code for Vietnam
                });

            // Act
            var result = _doctorQueryService.GetTimeZones();

            // Assert
            result.IsSuccess.Should().BeTrue();
            result.HasError.Should().BeFalse();
            result.StatusCode.Should().Be(ResponseStatus.STATUS_SUCCESS);
            result.Message.Should().Be(Resource.RecordListingMessage);
            result.Results.Should().ContainSingle();
            result.Results.First().TimeZoneName.Should().Be($"Asia/{AppConstants.MalaysiaCity}"); // Change to Asia/Kuala Lumpur
        }


        // Test case 3: Region Code is invalid or not provided, should return Malaysia time zone
        [Fact]
        public void GetTimeZones_WithInvalidOrNoRegionCode_ReturnsMalaysiaTimeZone()
        {
            // Arrange
            _httpContextAccessorMock.Setup(h => h.HttpContext.Request.Headers.TryGetValue(It.IsAny<string>(), out It.Ref<StringValues>.IsAny))
                .Returns(false); // Simulate no region code

            // Act
            var result = _doctorQueryService.GetTimeZones();

            // Assert
            result.IsSuccess.Should().BeTrue();
            result.HasError.Should().BeFalse();
            result.StatusCode.Should().Be(ResponseStatus.STATUS_SUCCESS);
            result.Message.Should().Be(Resource.RecordListingMessage);
            result.Results.Should().ContainSingle();
            result.Results.First().TimeZoneName.Should().Be($"{AppConstants.ContinentName}/{AppConstants.MalaysiaCity}");
        }

        [Fact]
        public void GetTimeZones_WithEmptyHeader_ReturnsMalaysiaTimeZone()
        {
            // Arrange
            _httpContextAccessorMock.Setup(h => h.HttpContext.Request.Headers.TryGetValue(It.IsAny<string>(), out It.Ref<StringValues>.IsAny))
                .Returns(true)
                .Callback((string key, out StringValues value) =>
                {
                    value = StringValues.Empty; // Simulate empty header value
                });

            // Act
            var result = _doctorQueryService.GetTimeZones();

            // Assert
            result.IsSuccess.Should().BeTrue();
            result.HasError.Should().BeFalse();
            result.StatusCode.Should().Be(ResponseStatus.STATUS_SUCCESS);
            result.Results.Should().ContainSingle();
            result.Results.First().TimeZoneName.Should().Be($"{AppConstants.ContinentName}/{AppConstants.MalaysiaCity}");
        }

        #endregion

        #region GetDoctorDetailsById

        [Fact]
        public async Task GetDoctorDetailsById_DoctorDoesNotExist_ReturnsNotFound()
        {
            // Act
            var result = await _doctorQueryService.GetDoctorDetailsById(999);

            // Assert
            result.Should().NotBeNull();
            result.IsSuccess.Should().BeFalse();
            result.HasError.Should().BeTrue();
            result.StatusCode.Should().Be(((int)ResponceStatusCode.RecordNotFound).ToString());
            result.Message.Should().Be(ResponseMessage.STATUS_NODATA);
            result.Results.Should().BeNullOrEmpty();
        }

        [Fact]
        public async Task GetDoctorDetailsById_PractitionerIsDeleted_ReturnsNotFound()
        {
            // Arrange
            var practitioner = await _dbContext.Practitioners.FirstAsync();
            practitioner.IsDeleted = true;
            await _dbContext.SaveChangesAsync();

            // Act
            var result = await _doctorQueryService.GetDoctorDetailsById(practitioner.Id);

            // Assert
            result.Should().NotBeNull();
            result.IsSuccess.Should().BeFalse();
            result.HasError.Should().BeTrue();
            result.StatusCode.Should().Be(((int)ResponceStatusCode.RecordNotFound).ToString());
            result.Results.Should().BeNullOrEmpty();
        }

        [Fact]
        public async Task GetDoctorDetailsById_LocationIsDeleted_ReturnsNotFound()
        {
            // Arrange
            var location = await _dbContext.Locations.FirstAsync();
            location.IsDeleted = true;
            await _dbContext.SaveChangesAsync();

            // Act
            var result = await _doctorQueryService.GetDoctorDetailsById(1);

            // Assert
            result.Should().NotBeNull();
            result.IsSuccess.Should().BeFalse();
            result.HasError.Should().BeTrue();
            result.StatusCode.Should().Be(((int)ResponceStatusCode.RecordNotFound).ToString());
            result.Results.Should().BeNullOrEmpty();
        }

        [Fact]
        public async Task GetDoctorDetailsById_RoleIsDeleted_ReturnsNotFound()
        {
            // Arrange
            var role = await _dbContext.PractitionerRoles.FirstAsync();
            role.IsDeleted = true;
            await _dbContext.SaveChangesAsync();

            // Act
            var result = await _doctorQueryService.GetDoctorDetailsById(1);

            // Assert
            result.Should().NotBeNull();
            result.IsSuccess.Should().BeFalse();
            result.HasError.Should().BeTrue();
        }

        [Fact]
        public async Task GetDoctorDetailsById_RoleCodeIsDeleted_ReturnsNotFound()
        {
            // Arrange
            var roleCode = await _dbContext.PractitionerRoleCodes.FirstAsync();
            roleCode.IsDeleted = true;
            await _dbContext.SaveChangesAsync();

            // Act
            var result = await _doctorQueryService.GetDoctorDetailsById(1);

            // Assert
            result.IsSuccess.Should().BeFalse();
            result.HasError.Should().BeTrue();
            result.Results.Should().BeNullOrEmpty();
        }

        [Fact]
        public async Task GetDoctorDetailsById_SpecialtyIsDeleted_ReturnsNotFound()
        {
            // Arrange
            var specialty = await _dbContext.PractitionerRoleSpecialty.FirstAsync();
            specialty.IsDeleted = true;
            await _dbContext.SaveChangesAsync();

            // Act
            var result = await _doctorQueryService.GetDoctorDetailsById(1);

            // Assert
            result.IsSuccess.Should().BeFalse();
            result.HasError.Should().BeTrue();
            result.Results.Should().BeNullOrEmpty();
        }

        [Fact]
        public async Task GetDoctorDetailsById_ShouldReturnNoData_WhenDoctorNotFound()
        {
            // Arrange
            var practitionerId = 999; // Non-existing ID

            // Act
            var result = await _doctorQueryService.GetDoctorDetailsById(practitionerId);

            // Assert
            result.IsSuccess.Should().BeFalse();
            result.HasError.Should().BeTrue();
            result.StatusCode.Should().Be(((int)ResponceStatusCode.RecordNotFound).ToString());
            result.Message.Should().Be(ResponseMessage.STATUS_NODATA);
        }

        [Fact]
        public async Task GetDoctorDetailsById_ShouldReturn_GroupedDoctorList()
        {
            // Arrange
            long practitionerId = 1;

            var expectedResponse = new GenericResponseList<GetDoctorDetailsDto>
            {
                IsSuccess = true,
                HasError = false,
                Results = new List<GetDoctorDetailsDto>
            {
            new GetDoctorDetailsDto
            {
                Id = 1,
                ResourceId = "RES001",
                Code = "DOC001",
                SlotType = "Consultation",
                PractitionerSpeciality = new List<GetPractitionerSpecialtyListDto>
                {
                    new GetPractitionerSpecialtyListDto { PractitionerRoleId = 1, Specialty = "Cardiology", LocationId = "001", LaymanDescription = "Heart Specialist" },
                    new GetPractitionerSpecialtyListDto { PractitionerRoleId = 1, Specialty = "Neurology", LocationId = "001", LaymanDescription = "Brain Specialist" }
                },
                PractitionerLocation = new List<GetPractitionerLocationListDto>
                {
                    new GetPractitionerLocationListDto { Id = 10, Name = "Clinic A", ResourceId = "LOC001" },
                    new GetPractitionerLocationListDto { Id = 11, Name = "Clinic B", ResourceId = "LOC002" }
                }
              }
            },
                StatusCode = ((int)ResponceStatusCode.Success).ToString(),
                Message = ResponseMessage.STATUS_SUCCESS
            };

            var mockDoctorQueryService = new Mock<IDoctorQueryService>();
            mockDoctorQueryService
                .Setup(service => service.GetDoctorDetailsById(practitionerId))
                .ReturnsAsync(expectedResponse); // **Hardcoded response**

            var doctorQueryService = mockDoctorQueryService.Object;

            // Act
            var response = await doctorQueryService.GetDoctorDetailsById(practitionerId);

            // Assert
            Assert.NotNull(response);
            Assert.True(response.IsSuccess, $"Expected IsSuccess to be true, but got {response.IsSuccess}");
            Assert.False(response.HasError, $"Expected HasError to be false, but got {response.HasError}");
            Assert.NotNull(response.Results);
            Assert.Single(response.Results);

            var doctor = response.Results.First();
            Assert.Equal(1, doctor.Id);
            Assert.Equal("RES001", doctor.ResourceId);
            Assert.Equal("DOC001", doctor.Code);
            Assert.Equal("Consultation", doctor.SlotType);

            // Ensure distinct specialties
            Assert.Equal(2, doctor.PractitionerSpeciality.Count);
            Assert.Contains(doctor.PractitionerSpeciality, s => s.Specialty == "Cardiology");
            Assert.Contains(doctor.PractitionerSpeciality, s => s.Specialty == "Neurology");

            // Ensure distinct locations
            Assert.Equal(2, doctor.PractitionerLocation.Count);
            Assert.Contains(doctor.PractitionerLocation, l => l.Name == "Clinic A");
            Assert.Contains(doctor.PractitionerLocation, l => l.Name == "Clinic B");
        }

        [Fact]
        public async Task GetDoctorDetailsById_ShouldReturn_EmptyList_WhenNoDoctorsFound()
        {
            // Arrange
            long practitionerId = 99; // Non-existent doctor

            var doctorQueryService = new DoctorQueryService(_dbContext);

            // Act
            var response = await doctorQueryService.GetDoctorDetailsById(practitionerId);

            // Assert
            Assert.False(response.IsSuccess);
            Assert.True(response.HasError);
            Assert.Null(response.Results);
            Assert.Equal(((int)ResponceStatusCode.RecordNotFound).ToString(), response.StatusCode);
            Assert.Equal(ResponseMessage.STATUS_NODATA, response.Message);
        }

        #endregion
        #region GetDoctors

        [Fact]
        public async Task GetDoctors_WithValidData_ReturnsPractitionerList()
        {
            // Act
            var result = await _doctorQueryService.GetDoctors();

            // Assert
            result.Should().NotBeNull();
            result.IsSuccess.Should().BeTrue();
            result.HasError.Should().BeFalse();
            result.StatusCode.Should().Be(ResponseStatus.STATUS_SUCCESS);
            result.Message.Should().Be(Resource.RecordListingMessage);
            result.Results.Should().HaveCount(1);

            var practitioner = result.Results.First();
            practitioner.Id.Should().Be(1);
            practitioner.ResourceId.Should().Be("12345");
            practitioner.GivenName.Should().Be("John");
            practitioner.MiddleName.Should().Be("Glen");
            practitioner.FamilyName.Should().Be("Dsouza");
        }

        [Fact]
        public void Test_NormalScenario_NoExceptionThrown()
        {
            try
            {
                // Simulate normal operation without exception
                // This block should contain the actual code that is being tested
                // For demonstration, we assume no exception is thrown
            }
            catch (Exception)
            {
                Assert.Fail("Exception should not be thrown in normal scenario");
            }
        }

        [Fact]
        public void Test_EdgeCase_ExceptionThrown()
        {
            try
            {
                // Simulate operation that throws an exception
                throw new Exception("Simulated exception");
            }
            catch (Exception)
            {
                var response = new GenericResponseList<GetPractitionerListDto>
                {
                    HasError = true,
                    IsSuccess = false,
                    StatusCode = ResponseStatus.STATUS_InternalServerError,
                    Message = Resource.LogMessage
                };

                // Assert the response properties
                Assert.True(response.HasError);
                Assert.False(response.IsSuccess);
                Assert.Equal(ResponseStatus.STATUS_InternalServerError, response.StatusCode);
                Assert.Equal(Resource.LogMessage, response.Message);
            }
        }

        #endregion
        #region get doctor profile

        [Fact]
        public async Task GetDoctorProfile_OnException_ReturnsInternalServerErrorResponse()
        {
            // Arrange
            long profileId = 1;
            // Inject a failure by disposing the context before call
            await _dbContext.DisposeAsync();

            // Act
            var response = await _doctorQueryService.GetDoctorProfile(profileId);

            // Assert
            Assert.False(response.IsSuccess);
            Assert.True(response.HasError);
            Assert.Equal(ResponseStatus.STATUS_InternalServerError, response.StatusCode);
            Assert.Equal(Resource.LogMessage, response.Message);
        }
        [Fact]
        public async Task GetDoctorProfile_WithAvailability_PopulatesAvailabilityCorrectly()
        {
            // Act
            var response = await _doctorQueryService.GetDoctorProfile(1);

            // Assert top‐level
            Assert.True(response.IsSuccess);
            Assert.False(response.HasError);
            Assert.NotNull(response.Result);

            var dto = response.Result;

            // 1) Ensure we have at least one PractitionerRoleResponse
            Assert.NotEmpty(dto.PractitionerRoles);
            var firstRole = dto.PractitionerRoles.FirstOrDefault();

            // 2) Ensure that role.Availability has exactly one entry
            Assert.NotNull(firstRole.Availability);
            Assert.Single(firstRole.Availability);

            var availResp = firstRole.Availability[0];

            // 3) Validate the availability fields
            Assert.False(availResp.AllDay);
            Assert.Equal(TimeSpan.Parse("09:00"), availResp.AvailableStartTime);
            Assert.Equal(TimeSpan.Parse("17:00"), availResp.AvailableEndTime);

            // 4) Validate DaysOfWeek via GetDayNames
            Assert.Equal("Mon,Wed", availResp.DaysOfWeek);
        }


        [Fact]
        public async Task GetDoctorProfile_WithValidId_ReturnsDoctorProfileSuccessfully()
        {
            // Arrange
            var doctorId = 1;

            // Act
            var result = await _doctorQueryService.GetDoctorProfile(doctorId);

            // Assert
            result.IsSuccess.Should().BeTrue();
            result.HasError.Should().BeFalse();
            result.StatusCode.Should().Be(ResponseStatus.STATUS_SUCCESS);
            result.Result.Should().NotBeNull();
            result.Result.FirstName.Should().Be("John");
            result.Result.LastName.Should().Be("Doe");
            result.Result.PhotoUrl.Should().Be("www.photo.com");
            result.Result.Gender.Should().NotBeNull();
        }

        [Fact]
        public async Task GetDoctorProfile_WithInvalidId_ReturnsNotFound()
        {
            // Arrange
            var invalidId = 999;

            // Act
            var result = await _doctorQueryService.GetDoctorProfile(invalidId);

            // Assert
            result.IsSuccess.Should().BeFalse();
            result.HasError.Should().BeTrue();
            result.StatusCode.Should().Be(ResponseStatus.STATUS_NotFound);
            result.Message.Should().Be(Resource.RecordNotFound);
        }

        [Fact]
        public async Task GetDoctorProfile_WithMissingOptionalCollections_HandlesGracefully()
        {
            // Arrange
            var practitioner = await _dbContext.Practitioners.FirstAsync();
            var photos = await _dbContext.PractitionerPhoto.ToListAsync();
            _dbContext.PractitionerPhoto.RemoveRange(photos);
            await _dbContext.SaveChangesAsync();

            // Act
            var result = await _doctorQueryService.GetDoctorProfile(practitioner.Id);

            // Assert
            result.IsSuccess.Should().BeTrue();
            result.Result.PhotoUrl.Should().BeEmpty();
        }

        #endregion GetDoctorSearchByFilter
        #region 

        [Fact]
        public async Task GetDoctorDetailsById_NoSuchPractitioner_ReturnsRecordNotFound()
        {
            // Arrange
            long missingId = 999;

            // Act
            var response = await _doctorQueryService.GetDoctorDetailsById(missingId);

            // Assert
            Assert.False(response.IsSuccess);
            Assert.True(response.HasError);
            Assert.Equal(((int)ResponceStatusCode.RecordNotFound).ToString(), response.StatusCode);
            Assert.Null(response.Results);
        }

        [Fact]
        public async Task GetDoctorSearchByFilter_BaseQuery_ReturnsResults()
        {
            var criteria = new DoctorSearchCriteriaRequest();

            var result = await _doctorQueryService.GetDoctorSearchByFilter(criteria, "Doctor");

            result.Should().NotBeNull();
            result.Should().HaveCount(1);
            result.FirstOrDefault().FirstName.Should().Be("John");
        }

        [Fact]
        public async Task GetDoctorSearchByFilter_WithHospitalFilter_ReturnsMatchingDoctor()
        {
            var criteria = new DoctorSearchCriteriaRequest
            {
                HospitalIds = "1"
            };

            var result = await _doctorQueryService.GetDoctorSearchByFilter(criteria, "Doctor");

            result.Should().NotBeNull();
            result.Should().ContainSingle();
        }

        [Fact]
        public async Task GetDoctorProfile_ShouldReturnSuccess_WhenDoctorProfileExists()
        {
            // Arrange
            var doctorProfileId = 1;

            // Act
            var result = await _doctorQueryService.GetDoctorProfile(doctorProfileId);

            // Assert
            result.IsSuccess.Should().BeTrue();
            result.HasError.Should().BeFalse();
            result.StatusCode.Should().Be(ResponseStatus.STATUS_SUCCESS);
            result.Result.Should().NotBeNull();
            result.Result.FirstName.Should().Be("John");
            result.Result.LastName.Should().Be("Doe");
        }

        [Fact]
        public async Task GetDoctorProfile_ShouldReturnNotFound_WhenDoctorProfileDoesNotExist()
        {
            // Arrange
            var doctorProfileId = 9999;

            // Act
            var result = await _doctorQueryService.GetDoctorProfile(doctorProfileId);

            // Assert
            result.IsSuccess.Should().BeFalse();
            result.HasError.Should().BeTrue();
            result.StatusCode.Should().Be(ResponseStatus.STATUS_NotFound);
            result.Message.Should().Be(Resource.RecordNotFound);
        }
        [Fact]
        public async Task GetDoctorProfile_ShouldReturnEmptyRoles_WhenNoPractitionerRolesExist()
        {
            // Arrange
            var doctorProfileId = 1;
            await _dbContext.Practitioners.FirstAsync();
            _dbContext.PractitionerRoles.RemoveRange(_dbContext.PractitionerRoles);
            await _dbContext.SaveChangesAsync();

            // Act
            var result = await _doctorQueryService.GetDoctorProfile(doctorProfileId);

            // Assert
            result.IsSuccess.Should().BeTrue();
            result.HasError.Should().BeFalse();
            result.StatusCode.Should().Be(ResponseStatus.STATUS_SUCCESS);
            result.Result.PractitionerRoles.Should().BeEmpty();
        }
        [Fact]
        public async Task GetDoctorSearchByFilter_WithGenderFilter_ReturnsMatchingDoctor()
        {
            var criteria = new DoctorSearchCriteriaRequest
            {
                Genders = "Male"
            };

            var result = await _doctorQueryService.GetDoctorSearchByFilter(criteria, "Doctor");

            result.Should().NotBeNull();
            result.FirstOrDefault().Gender.Should().Be("Male");
        }


        #endregion

        [Fact]
        public async Task GetPractitionerCode_ShouldReturnSuccess_WhenPractitionerCodesExist()
        {
            // Arrange
            long id = 3;
            var options = new DbContextOptionsBuilder<ReadOnlyDbContext>()
            .UseInMemoryDatabase(databaseName: "TestDb123")
            .Options;

            var dbContext = new ReadOnlyDbContext(options);

            // Mocked DbSet for Practitioners
            var practitioners = new List<Practitioner>
            {
            new() { Id = 1, ResourceID = "100", IsDeleted = false, CreatedBy="Test", CreatedDate=DateTime.UtcNow, Status=true, Gender="Male", Source="Test", UpdatedBy="Test" }
             };

            // Mocked DbSet for PractitionerRoles
            var roles = new List<PractitionerRole>
            {
              new() { Id = 1, PractitionerID = "100", IsDeleted = false, CreatedBy="Test", CreatedDate=DateTime.UtcNow, UUID=Guid.NewGuid(), AvailabilityExceptions="Test", UpdatedBy="Test", OrganizationID = 3 },
                new() { Id = 2, PractitionerID = "100", IsDeleted = false, CreatedBy="Test", CreatedDate=DateTime.UtcNow, UUID=Guid.NewGuid(), AvailabilityExceptions="Test", UpdatedBy="Test", OrganizationID = 3 }
             };

            // Mocked DbSet for PractitionerRoleCodes
            var roleCodes = new List<PractitionerRoleCode>
            {
              new() { Id = 1, PractitionerRoleID = 1, Code = "Doctor", IsDeleted = false, CreatedBy="Test", CreatedDate=DateTime.UtcNow, UpdatedBy = "Test" }
            };

            dbContext.Practitioners.AddRange(practitioners);
            dbContext.PractitionerRoles.AddRange(roles);
            dbContext.PractitionerRoleCodes.AddRange(roleCodes);
            await dbContext.SaveChangesAsync();

            var _doctorService = new DoctorQueryService(dbContext);
            // Act
            var result = await _doctorService.GetPractitionerCode(id);

            // Assert
            result.IsSuccess.Should().BeTrue();
            result.HasError.Should().BeFalse();
            result.Results.First().Code.Should().Contain("Doctor");
            result.StatusCode.Should().Be(((int)ResponceStatusCode.Success).ToString());
            result.Message.Should().Be(ResponseMessage.STATUS_SUCCESS);
        }
        [Fact]
        public async Task GetPractitionerCode_ShouldReturnNotFound_WhenNoPractitionerCodesExist()
        {
            long id = 1;
            // Arrange
            var options = new DbContextOptionsBuilder<ReadOnlyDbContext>()
            .UseInMemoryDatabase(databaseName: "TestDb145")
            .Options;

            var dbContext = new ReadOnlyDbContext(options);

            var _doctorService = new DoctorQueryService(dbContext);

            // Act
            var result = await _doctorService.GetPractitionerCode(id);

            // Assert
            result.IsSuccess.Should().BeFalse();
            result.HasError.Should().BeTrue();
            result.Results.Should().BeNull();
            result.StatusCode.Should().Be(((int)ResponceStatusCode.NotFound).ToString());
            result.Message.Should().Be(ResponseMessage.STATUS_NODATA);
        }

        [Fact]
        public async Task GetPractitionerName_WithValidId_ReturnsExpectedData()
        {
            //Arrange

            var options = new DbContextOptionsBuilder<ReadOnlyDbContext>()
            .UseInMemoryDatabase(databaseName: "TestDb12323")
            .Options;

            var dbContext = new ReadOnlyDbContext(options);
            var practitioner = new Practitioner
            {
                Id = 1,
                ResourceID = "RES123",
                Status = true,
                Gender = "male",
                BirthDate = DateTime.UtcNow,
                Source = "TestSystem",
                RecordVersion = new byte[] { 1, 2, 3, 4 },
                IsDeleted = false,
                CreatedBy = "TestUser",
                CreatedDate = DateTime.UtcNow.AddDays(-10),
                UpdatedBy = "AdminUser",
                UpdatedDate = DateTime.UtcNow
            };

            var mockPractitionerRole = new PractitionerRole
            {
                Id = 10,
                UUID = Guid.NewGuid(),
                PractitionerID = "RES123",  // Should match a Practitioner.ResourceID
                OrganizationID = 1,
                PeriodStart = DateTime.UtcNow,
                PeriodEnd = DateTime.UtcNow,
                ResourceID = "ROLE001",
                LocationID = "LOC001",
                Active = true,
                AvailabilityExceptions = "Unavailable on weekends",
                RecordVersion = [1, 2, 3],
                IsDeleted = false,
                CreatedBy = "TestUser",
                CreatedDate = DateTime.UtcNow.AddDays(-100),
                UpdatedBy = "AdminUser",
                UpdatedDate = DateTime.UtcNow.AddDays(-10),
            };

            var mockPractitionerRoleSpecialty = new PractitionerRoleSpecialty
            {
                Id = 100,
                PractitionerRoleID = 10, // This should correspond to an existing PractitionerRole ID
                Specialty = "Cardiology", // Example specialty
                RecordVersion = [1, 2, 3, 4],
                IsDeleted = false,
                CreatedBy = "TestUser",
                CreatedDate = DateTime.UtcNow.AddMonths(-3),
                UpdatedBy = "AdminUser",
                UpdatedDate = DateTime.UtcNow.AddMonths(-1)
            };

            var mockPractitionerNames = new PractitionerNames
            {
                Id = 1,
                PractitionerID = 1,
                Use = "official",
                FamilyName = "Doe",
                GivenName = "John",
                MiddleName = "Michael",
                Prefix = "Dr.",
                Suffix = "MD",
                Language = "English",
                PeriodStart = DateTime.Now,
                PeriodEnd = DateTime.Now,
                CreatedBy = "Test",
                CreatedDate = DateTime.UtcNow.AddMonths(-3),
                UpdatedBy = "Test",
                IsDeleted = false,
                Status = true
            };


            dbContext.Practitioners.Add(practitioner);
            dbContext.PractitionerRoles.Add(mockPractitionerRole);
            dbContext.PractitionerRoleSpecialty.Add(mockPractitionerRoleSpecialty);
            dbContext.PractitionerName.Add(mockPractitionerNames);
            await dbContext.SaveChangesAsync();

            var _doctorService = new DoctorQueryService(dbContext);

            // Act
            var result = await _doctorService.GetPractitionerName(100);

            // Assert
            result.Should().NotBeNull();
            result.IsSuccess.Should().BeTrue();
            result.HasError.Should().BeFalse();
            result.Results.Should().HaveCount(1);

            var dto = result.Results.First();
            dto.Id.Should().Be(1);
            dto.FamilyName.Should().Be("Doe");
            dto.GivenName.Should().Be("John");
            dto.MiddleName.Should().Be("Michael");
            dto.Prefix.Should().Be("Dr.");
            dto.Suffix.Should().Be("MD");

            result.StatusCode.Should().Be(((int)ResponceStatusCode.Success).ToString());
            result.Message.Should().Be(ResponseMessage.STATUS_SUCCESS);
        }

        [Fact]
        public async Task GetPractitionerName_WithInvalidId_ReturnsNotFound()
        {
            //Arrange
            var options = new DbContextOptionsBuilder<ReadOnlyDbContext>()
      .UseInMemoryDatabase(databaseName: "TestDb12312")
      .Options;

            var dbContext = new ReadOnlyDbContext(options);
            var practitioner = new Practitioner
            {
                Id = 1,
                ResourceID = "RES123",
                Status = true,
                Gender = "male",
                BirthDate = DateTime.UtcNow,
                Source = "TestSystem",
                RecordVersion = new byte[] { 1, 2, 3, 4 },
                IsDeleted = false,
                CreatedBy = "TestUser",
                CreatedDate = DateTime.UtcNow.AddDays(-10),
                UpdatedBy = "AdminUser",
                UpdatedDate = DateTime.UtcNow
            };

            var mockPractitionerRole = new PractitionerRole
            {
                Id = 10,
                UUID = Guid.NewGuid(),
                PractitionerID = "RES123",  // Should match a Practitioner.ResourceID
                OrganizationID = 1,
                PeriodStart = DateTime.UtcNow,
                PeriodEnd = DateTime.UtcNow,
                ResourceID = "ROLE001",
                LocationID = "LOC001",
                Active = true,
                AvailabilityExceptions = "Unavailable on weekends",
                RecordVersion = [1, 2, 3],
                IsDeleted = false,
                CreatedBy = "TestUser",
                CreatedDate = DateTime.UtcNow.AddDays(-100),
                UpdatedBy = "AdminUser",
                UpdatedDate = DateTime.UtcNow.AddDays(-10),
            };

            var mockPractitionerRoleSpecialty = new PractitionerRoleSpecialty
            {
                Id = 100,
                PractitionerRoleID = 10, // This should correspond to an existing PractitionerRole ID
                Specialty = "Cardiology", // Example specialty
                RecordVersion = new byte[] { 1, 2, 3, 4 },
                IsDeleted = false,
                CreatedBy = "TestUser",
                CreatedDate = DateTime.UtcNow.AddMonths(-3),
                UpdatedBy = "AdminUser",
                UpdatedDate = DateTime.UtcNow.AddMonths(-1)
            };

            var mockPractitionerNames = new PractitionerNames
            {
                Id = 1,
                PractitionerID = 1,
                Use = "official",
                FamilyName = "Doe",
                GivenName = "John",
                MiddleName = "Michael",
                Prefix = "Dr.",
                Suffix = "MD",
                Language = "English",
                PeriodStart = DateTime.Now,
                PeriodEnd = DateTime.Now,
                CreatedBy = "Test",
                CreatedDate = DateTime.UtcNow.AddMonths(-3),
                UpdatedBy = "Test",
                IsDeleted = false,
                Status = true
            };


            dbContext.Practitioners.Add(practitioner);
            dbContext.PractitionerRoles.Add(mockPractitionerRole);
            dbContext.PractitionerRoleSpecialty.Add(mockPractitionerRoleSpecialty);
            dbContext.PractitionerName.Add(mockPractitionerNames);
            await dbContext.SaveChangesAsync();

            var _doctorService = new DoctorQueryService(_dbContext);

            // Act

            var result = await _doctorService.GetPractitionerName(999); // ID that doesn’t exist

            // Assert
            result.Should().NotBeNull();
            result.IsSuccess.Should().BeFalse();
            result.HasError.Should().BeTrue();
            result.Results.Should().BeNull();
            result.StatusCode.Should().Be(((int)ResponceStatusCode.NotFound).ToString());
            result.Message.Should().Be(ResponseMessage.STATUS_NODATA);
        }

        //GetDoctorSearch Tests
        [Fact]
        public async Task GetDoctorSearchList_WithOutKeyword_ReturnsExpectedData()
        {
            //Arrange

            var options = new DbContextOptionsBuilder<ReadOnlyDbContext>()
            .UseInMemoryDatabase(databaseName: "TestDbGetDoctorsSearchList")
            .Options;

            var dbContext = new ReadOnlyDbContext(options);

            dbContext.HealthcareServicesKeyWords.Add(HealthCareServiceKeywordsMock.GetHealthcareServicesKeyWords());
            dbContext.HealthcareServices.Add(HealthCareServicesMock.GetHealthcareServices());
            dbContext.Practitioners.Add(PractitionerMock.GetPractitioner());
            dbContext.ManageDoctorProfiles.Add(ManageDoctorProfileMock.GetManageDoctorProfile());
            dbContext.PractitionerName.Add(PractitionerNamesMock.GetPractitionerNames());
            dbContext.PractitionerPhoto.Add(PractitionerPhotosMock.GetPractitionerPhotos());
            dbContext.PractitionerRoles.Add(PractitionerRoleMock.GetPractitionerRole());
            dbContext.PractitionerRoleSpecialty.Add(PractitionerRoleSpecialtyMock.GetPractitionerRoleSpecialty());
            dbContext.Organizations.Add(OrganizationMock.GetOrganization());
            dbContext.Locations.Add(LocationMock.GetLocation());
            await dbContext.SaveChangesAsync();

            var _doctorService = new DoctorQueryService(dbContext);

            // Act
            var result = await _doctorService.GetDoctorSearchList(null);

            // Assert
            result.Should().NotBeNull();
            result.IsSuccess.Should().BeTrue();
            result.HasError.Should().BeFalse();
            result.Results.Should().HaveCount(1);

            var dto = result.Results.First();
            dto.Id.Should().Be(1);
            dto.FirstName.Should().Be("John");
            dto.LastName.Should().Be("Doe");
            dto.MiddleName.Should().Be("Michael");
            dto.DoctorSpecialities[0].DoctorsSpeciality.Should().Be("Neur");

            result.StatusCode.Should().Be(((int)ResponceStatusCode.Success).ToString());
            result.Message.Should().Be(ResponseMessage.STATUS_SUCCESS);
        }

        [Fact]
        public async Task GetDoctorSearchList_WithKeyword_ReturnsExpectedData()
        {
            //Arrange

            var options = new DbContextOptionsBuilder<ReadOnlyDbContext>()
            .UseInMemoryDatabase(databaseName: "TestDbGetDoctorSearchLists")
            .Options;

            var dbContext = new ReadOnlyDbContext(options);

            dbContext.HealthcareServicesKeyWords.Add(HealthCareServiceKeywordsMock.GetHealthcareServicesKeyWords());
            dbContext.HealthcareServices.Add(HealthCareServicesMock.GetHealthcareServices());
            dbContext.Practitioners.Add(PractitionerMock.GetPractitioner());
            dbContext.ManageDoctorProfiles.Add(ManageDoctorProfileMock.GetManageDoctorProfile());
            dbContext.PractitionerName.Add(PractitionerNamesMock.GetPractitionerNames());
            dbContext.PractitionerPhoto.Add(PractitionerPhotosMock.GetPractitionerPhotos());
            dbContext.PractitionerRoles.Add(PractitionerRoleMock.GetPractitionerRole());
            dbContext.PractitionerRoleSpecialty.Add(PractitionerRoleSpecialtyMock.GetPractitionerRoleSpecialty());
            dbContext.Organizations.Add(OrganizationMock.GetOrganization());
            dbContext.Locations.Add(LocationMock.GetLocation());
            await dbContext.SaveChangesAsync();

            var _doctorService = new DoctorQueryService(dbContext);

            // Act
            var result = await _doctorService.GetDoctorSearchList("brain");

            // Assert
            result.Should().NotBeNull();
            result.IsSuccess.Should().BeTrue();
            result.HasError.Should().BeFalse();
            result.Results.Should().HaveCount(1);

            var dto = result.Results.First();
            dto.Id.Should().Be(1);
            dto.FirstName.Should().Be("John");
            dto.LastName.Should().Be("Doe");
            dto.MiddleName.Should().Be("Michael");
            dto.DoctorSpecialities[0].DoctorsSpeciality.Should().Be("Neur");

            result.StatusCode.Should().Be(((int)ResponceStatusCode.Success).ToString());
            result.Message.Should().Be(ResponseMessage.STATUS_SUCCESS);
        }

        [Fact]
        public async Task GetDoctorSearchList_WithKeyword_ReturnsNoData()
        {
            //Arrange

            var options = new DbContextOptionsBuilder<ReadOnlyDbContext>()
            .UseInMemoryDatabase(databaseName: "TestDbGetDoctorSearchList")
            .Options;

            var dbContext = new ReadOnlyDbContext(options);

            dbContext.HealthcareServicesKeyWords.Add(HealthCareServiceKeywordsMock.GetHealthcareServicesKeyWords());
            dbContext.HealthcareServices.Add(HealthCareServicesMock.GetHealthcareServices());
            dbContext.Practitioners.Add(PractitionerMock.GetPractitioner());
            dbContext.ManageDoctorProfiles.Add(ManageDoctorProfileMock.GetManageDoctorProfile());
            dbContext.PractitionerName.Add(PractitionerNamesMock.GetPractitionerNames());
            dbContext.PractitionerPhoto.Add(PractitionerPhotosMock.GetPractitionerPhotos());
            dbContext.PractitionerRoles.Add(PractitionerRoleMock.GetPractitionerRole());
            dbContext.PractitionerRoleSpecialty.Add(PractitionerRoleSpecialtyMock.GetPractitionerRoleSpecialty());
            dbContext.Organizations.Add(OrganizationMock.GetOrganization());
            dbContext.Locations.Add(LocationMock.GetLocation());
            await dbContext.SaveChangesAsync();

            var _doctorService = new DoctorQueryService(dbContext);

            // Act
            var result = await _doctorService.GetDoctorSearchList("drain");

            // Assert
            result.Should().NotBeNull();
            result.IsSuccess.Should().BeFalse();
            result.HasError.Should().BeTrue();
            result.Results.Should().BeNull();
            result.StatusCode.Should().Be(((int)ResponceStatusCode.NotFound).ToString());
            result.Message.Should().Be(ResponseMessage.STATUS_NODATA);
        }

        [Fact]
        public async Task GetDoctorProfileDetails_ReturnsNotFound_WhenDoctorNotInDb()
        {
            // Act
            var response = await _doctorQueryService.GetDoctorProfileDetails(999L);

            // Assert
            response.IsSuccess.Should().BeFalse();
            response.HasError.Should().BeTrue();
            response.StatusCode.Should().Be(ResponseStatus.STATUS_NotFound);
            response.Message.Should().Be(Resource.RecordNotFound);
            response.Result.Should().BeNull();
        }

        [Fact]
        public async Task GetDoctorProfileDetails_ReturnsError_WhenDbContextIsNull()
        {
            // Arrange
            var brokenSvc = new DoctorQueryService(readOnlyDbContext: null!);

            // Act
            var response = await brokenSvc.GetDoctorProfileDetails(1L);

            // Assert
            response.IsSuccess.Should().BeFalse();
            response.HasError.Should().BeTrue();
            response.StatusCode.Should().Be(ResponseStatus.STATUS_NotFound);
            response.Message.Should().Contain("Object reference");
            response.Result.Should().BeNull();
        }



        [Fact]
        public async Task GetDoctorProfileDetails_ShouldReturnSuccessResponse_WhenDoctorExists()
        {
            // Arrange
            long practitionerId = 6;

            var expectedDto = new DoctorProfileDetailsDto
            {
                Id = 1,
                URL = "www.photo.com",
                Prefix = "Dr.",
                Suffix = "MD",
                GivenName = "John",
                FamilyName = "Dsouza",
                Description = "Experienced Cardiologist",
                ManageDoctorProfileId = 101,
                ResourceId = "RES12345",
                PractitionerRoleId = 201,
                PractitionerId = practitionerId.ToString(),
                PractitionerCommunications = "English, Hindi", // Updated from list to string
                ExperienceDetails = new List<ExperienceDetailsDto>
        {
            new ExperienceDetailsDto
            {
                JobDurationFrom = new DateTime(2020, 1, 1),
                JobDurationTo = new DateTime(2023, 12, 31),
                Designation = "Consultant",
                Organization = "Apollo Hospital",
                Location = "Mumbai",
                CurrentlyWorkingHere = false
            },
            new ExperienceDetailsDto
            {
                JobDurationFrom = new DateTime(2024, 1, 1),
                JobDurationTo = null,
                Designation = "Senior Consultant",
                Organization = "Fortis Hospital",
                Location = "Delhi",
                CurrentlyWorkingHere = true
            }
        },
                EducationalQualifications = new List<EducationalQualificationDto>
        {
            new EducationalQualificationDto { EducationalDegree = "MBBS", Institute = "AIIMS", YearOfPassing = 2010 },
            new EducationalQualificationDto { EducationalDegree = "MD", Institute = "KEM Hospital", YearOfPassing = 2014 }
        },
                Interests = "Cardiology Research, Medical Writing", // Flattened from InterestDtos
                SectionDetails = new List<SectionDto>
        {
            new SectionDto { Title = "Cardiology", Description = "Expert in treating heart-related conditions." },
            new SectionDto { Title = "Neurology", Description = "Specialized in nervous system disorders." }
        },
                OrganizationDetails = new List<DoctorOrganizationDto>
        {
            new DoctorOrganizationDto
            {
                Id = 8,
                LocationName = "Apollo Mumbai",
                OrganizationName = "Apollo Hospital",
                Alias = "Apollo",
                City = "Mumbai",
                Specialties = "Cardiology", // Flattened
                Longitude = 72.8777m,
                Latitude = 19.0760m,
                Altitude = 10.0m,
                ScheduleStartDate = new DateTime(2025, 01, 01),
                ScheduleEndDate = new DateTime(2025, 12, 31),
                NextAvailability = "2025-05-01",
                PractitionerRoleId = 201
            },
            new DoctorOrganizationDto
            {
                Id = 9,
                LocationName = "Fortis Delhi",
                OrganizationName = "Fortis Hospital",
                Alias = "Fortis",
                City = "Delhi",
                Specialties = "Internal Medicine", // Flattened
                Longitude = 77.1025m,
                Latitude = 28.7041m,
                Altitude = 15.0m,
                ScheduleStartDate = new DateTime(2025, 01, 01),
                ScheduleEndDate = new DateTime(2025, 12, 31),
                NextAvailability = "2025-06-01",
                PractitionerRoleId = 202
            }
        }
            };

            var expectedResponse = new GenericResponse<DoctorProfileDetailsDto>
            {
                IsSuccess = true,
                HasError = false,
                StatusCode = ResponseStatus.STATUS_SUCCESS,
                Result = expectedDto,
                Message = "Doctor profile fetched successfully."
            };

            var mockDoctorService = new Mock<IDoctorQueryService>(MockBehavior.Strict);
            mockDoctorService
                .Setup(s => s.GetDoctorProfileDetails(practitionerId))
                .ReturnsAsync(expectedResponse);

            // Act
            var response = await mockDoctorService.Object.GetDoctorProfileDetails(practitionerId);

            // Assert
            mockDoctorService.Verify(s => s.GetDoctorProfileDetails(practitionerId), Times.Once);

            response.Should().NotBeNull();
            response.IsSuccess.Should().BeTrue();
            response.HasError.Should().BeFalse();
            response.StatusCode.Should().Be(ResponseStatus.STATUS_SUCCESS);
            response.Message.Should().Be("Doctor profile fetched successfully.");

            var result = response.Result;
            result.Should().NotBeNull();
            result.GivenName.Should().Be("John");
            result.FamilyName.Should().Be("Dsouza");
            result.Description.Should().Be("Experienced Cardiologist");
            result.PractitionerId.Should().Be(practitionerId.ToString());

            result.PractitionerCommunications.Should().Be("English, Hindi");
            result.ExperienceDetails.Should().HaveCount(2);
            result.EducationalQualifications.Should().HaveCount(2);
            result.Interests.Should().Be("Cardiology Research, Medical Writing");
            result.SectionDetails.Should().HaveCount(2);
            result.OrganizationDetails.Should().HaveCount(2);

            result.OrganizationDetails![0].OrganizationName.Should().Be("Apollo Hospital");
            result.OrganizationDetails[1].City.Should().Be("Delhi");
        }

    }
}