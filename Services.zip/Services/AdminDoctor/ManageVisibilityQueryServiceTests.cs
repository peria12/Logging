﻿using Aurora.AdministrationService.API.Models.ResponseModels.Schedules;
using Aurora.AdministrationService.API.Services.IService.Schedule;
using Aurora.AdministrationService.API.Services.Service.AdminDoctor;
using Aurora.AdministrationService.API.Services.Service.Schedule;
using Aurora.AdministrationService.Domain.V1.Entities.Locations;
using Aurora.AdministrationService.Domain.V1.Entities.PractitionerRoles;
using Aurora.AdministrationService.Domain.V1.Entities.Practitioners;
using Aurora.AdministrationService.Infrastructure;
using Microsoft.EntityFrameworkCore;
using Moq;

namespace Aurora.AdministrationService.Tests.API.Services.AdminDoctor
{
    public class ManageVisibilityQueryServiceTests : TestsBase<ManageVisibilityQueryService>
    {
   
        private readonly ManageVisibilityQueryService _service;
        private readonly ReadOnlyDbContext _dbContext;
        private readonly Mock<IScheduleQueryService> _scheduleQueryService;

        public ManageVisibilityQueryServiceTests() {
            // Create In-Memory Database options

            _dbContext = GetReadOnlyDBContextInMemory();
             _scheduleQueryService=new Mock<IScheduleQueryService>();

            // Initialize service with in-memory DbContext
            _service = new ManageVisibilityQueryService(_dbContext, _scheduleQueryService.Object);
        }

        // Test Case 1.1 - Successful Retrieval of Practitioner Visibility Details
        [Fact]
        public async Task GetPractitionerVisibilityDetails_Should_Return_PractitionerVisibilityResponseDto_When_Found()
        {
            // Arrange
            string partitionerId = "Pract123";

            // Insert mock data into the in-memory database
            _dbContext.Practitioners.Add(new Practitioner
            {
                ResourceID = partitionerId,
                CreatedBy="Admin",
                CreatedDate = DateTime.UtcNow,
                IsDeleted = false,
                Status=true,
                Gender="Male",
                UpdatedBy="Admin",
                Source="test",
                PractitionerNames = new List<PractitionerNames>
            {
                new() { GivenName = "John", FamilyName = "Doe",Language="en",MiddleName="Singh",Prefix="Mr",Suffix="",CreatedDate=DateTime.UtcNow,IsDeleted=false,PractitionerID=1,CreatedBy="Admin",Status=true,Use="Office"}
            },
                PractitionerPhotos = new List<PractitionerPhotos>
                {
                new() { 
                Id = 1,
                PractitionerID = 1,
                Status = true,
                IsDeleted = false,
                CreatedBy = "Admin",
                CreatedDate = DateTime.Now,
                ContentType = "Json",
                Data = Array.Empty<byte>(),
                Hash = "Test",
                Size = "100",
                Title = "Test1",
                URL = "https://photo.url",
                UpdatedBy = "Admin"  
                ,CreationDate=DateTime.UtcNow             }
            },
                ManageVisibility = new List<ManageVisibility>
            {
                new ManageVisibility
                {
                    ID = 1,
                    LocationID = "BRIM",
                    CreatedDate=DateTime.UtcNow,
                    IsDeleted=false,
                    PractitionerID=partitionerId,
                    ManageVisibilityUserGroups = new List<ManageVisibilityUserGroups>
                    {
                        new() { ID = 1, UserGroups = "Group1", CreatedDate=DateTime.UtcNow,IsDeleted=false,ManageVisibilityID=1
                        }
                    }
                }
            }
            });
            await _dbContext.SaveChangesAsync();

            // Act
            var result = await _service.GetPractitionerVisibilityDetails(partitionerId);

            // Assert
            Assert.NotNull(result);
            Assert.Equal("John", result.GivenName);
            Assert.Equal("Doe", result.FamilyName);
            Assert.Equal("https://photo.url", result.PhotoUrl);
            Assert.Single(result.PractitionerVisibilityDtl);
            Assert.Equal("Group1", result.PractitionerVisibilityDtl.First().UserGroups.First().GroupName);
        }

        // Test Case 1.2 - Practitioner Not Found
        [Fact]
        public async Task GetPractitionerVisibilityDetails_Should_Return_Null_When_Practitioner_Not_Found()
        {
            // Arrange
            string partitionerId = "123";

            // Act
            var result = await _service.GetPractitionerVisibilityDetails(partitionerId);

            // Assert
            Assert.Null(result);
        }

        // Test Case 2.1 - Successful Retrieval of Practitioner Locations
        [Fact]
        public async Task GetPractitionerLocation_Should_Return_Locations_When_Found()
        {
            // Arrange
            string partitionerId = "123";

            // Insert mock data into the in-memory database
            _dbContext.Locations.Add(new Location
            {
                ResourceID = partitionerId,
                Id = 1,
                Name = "Location 1",
                Alias = "Location Alias",
                IsDeleted = false,
                CreatedBy="Admin",
                CreatedDate = DateTime.UtcNow,
                Status=false,
                UpdatedBy="Admin",
                AvailabilityExceptions=" ",
                PractitionerRole = new List<PractitionerRole>
            {
                new PractitionerRole { 
                 Practitioner = new Practitioner { 
                    ResourceID = partitionerId,
                    CreatedBy="Admin",
                    CreatedDate = DateTime.UtcNow,
                    IsDeleted = false,
                    Status=true,
                    Gender="Male",
                    UpdatedBy="Admin",
                    Source="test"
                                     
                 }
                   ,CreatedBy="Admin",
                    CreatedDate=DateTime.UtcNow,
                    IsDeleted=false,
                    PractitionerID=partitionerId,
                    UUID=Guid.NewGuid(),
                    UpdatedBy="Admin",
                    AvailabilityExceptions="Test"
                }
            }
            });
            await _dbContext.SaveChangesAsync();

            // Act
            var result = await _service.GetPractitionerLocation(partitionerId);

            // Assert
            Assert.NotEmpty(result);
            Assert.Equal("Location 1", result.First().Name);
            Assert.Equal("Location Alias", result.First().Alias);
        }

        // Test Case 2.2 - No Locations Found
        [Fact]
        public async Task GetPractitionerLocation_Should_Return_Empty_When_No_Locations_Found()
        {
            // Arrange
            string partitionerId = "123";

            // Act
            var result = await _service.GetPractitionerLocation(partitionerId);

            // Assert
            Assert.Empty(result);
        }
                   
       
    }

}
