﻿using Aurora.AdministrationService.API.Models.Dto.Practitioners.PractitionerTelecoms;
using Aurora.AdministrationService.API.Services.Service.Practitioners.PractitionerTelecoms;
using Aurora.AdministrationService.Infrastructure;
using AutoMapper;
using Microsoft.EntityFrameworkCore;
using Moq;

namespace Aurora.AdministrationService.Tests.API.Services.Practitioners
{
    public class PractitionerTelecomCommandServiceTests
    {
        private readonly Mock<ReadWriteDbContext> _readWriteDbContextMock;
        private readonly Mock<ReadOnlyDbContext> _readOnlyDbContextMock;
        private readonly Mock<IMapper> _mapperMock;
        private PractitionerTelecomCommandService _practitionerTelecomCommandService;

        public PractitionerTelecomCommandServiceTests()
        {
            // Initialize the mocks
            _mapperMock = new Mock<IMapper>();
            _readWriteDbContextMock = new Mock<ReadWriteDbContext>();
            _readOnlyDbContextMock = new Mock<ReadOnlyDbContext>();


            // Setup in-memory ready only database for testing
            DbContextOptions<ReadWriteDbContext> options = new DbContextOptionsBuilder<ReadWriteDbContext>()
              .UseInMemoryDatabase(databaseName: "AdminPractitionerTelecomTestDB").Options;

            _readWriteDbContextMock = new(options);

            // Initialize the service being tested
            _practitionerTelecomCommandService = new PractitionerTelecomCommandService(_readWriteDbContextMock.Object, _mapperMock.Object);
        }

        [Fact]
        public async Task CreatePractitionerTelecomAsync_ShouldReturnTrue_WhenPractitionerTelecomIsCreatedSuccessfully()
        {
            // Arrange
            var newPractitionerTelecom = new PractitionerTelecomDto
            {
                PractitionerID = 1,
                Status = true,
                System = "test",
                Use = "test",
                Value = "test",
                PeriodStart = DateTime.UtcNow,
                PeriodEnd = DateTime.UtcNow,
                Rank = 1,
            };

            // Mock AutoMapper to return a PractitionerTelecom entity
            var practitionerTelecomId = 1;
            var practitionerTelecomEntity = new Domain.V1.Entities.Practitioners.PractitionerTelecom
            {
                Id = practitionerTelecomId,
                PractitionerID = 1,
                Status = true,
                System = "test",
                Use = "test",
                Value = "test",
                PeriodStart = DateTime.UtcNow,
                PeriodEnd = DateTime.UtcNow,
                Rank = 1,
                IsDeleted = false,
                CreatedBy = "Admin",
                CreatedDate = DateTime.UtcNow,
                UpdatedBy = "Admin",  // Adding the missing property
                UpdatedDate = DateTime.UtcNow,// Assuming UpdatedDate is required as well
            };


            // Mock AutoMapper to return the PractitionerTelecom entity
            _mapperMock.Setup(m => m.Map<Domain.V1.Entities.Practitioners.PractitionerTelecom>(newPractitionerTelecom)).Returns(practitionerTelecomEntity);

            // Mock DbContext to simulate saving the entity without actually hitting the database
            _readWriteDbContextMock.Setup(db => db.PractitionerTelecoms.Add(It.IsAny<Domain.V1.Entities.Practitioners.PractitionerTelecom>()));

            // Act
            var result = await _practitionerTelecomCommandService.CreatePractitionerTelecomAsync(newPractitionerTelecom);

            // Assert
            Assert.True(result);
            _readWriteDbContextMock.Verify(db => db.PractitionerTelecoms.Add(It.Is<Domain.V1.Entities.Practitioners.PractitionerTelecom>(l => l.Use == "test")), Times.Once);
        }


        [Fact]
        public async Task CreatePractitionerTelecomAsync_ShouldReturnFalse_WhenExceptionOccurs()
        {
            // Arrange
            var newPractitionerTelecom = new PractitionerTelecomDto
            {
                PractitionerID = 1,
                Status = true,
                System = "test",
                Use = "test",
                Value = "test",
                PeriodStart = DateTime.UtcNow,
                PeriodEnd = DateTime.UtcNow,
                Rank = 1,
            };

            // Mock AutoMapper to return a PractitionerTelecom entity
            var practitionerTelecomId = 1;
            var practitionerTelecomEntity = new Domain.V1.Entities.Practitioners.PractitionerTelecom
            {
                Id = practitionerTelecomId,
                PractitionerID = 1,
                Status = true,
                System = "test",
                Use = "test",
                Value = "test",
                PeriodStart = DateTime.UtcNow,
                PeriodEnd = DateTime.UtcNow,
                Rank = 1,
                IsDeleted = false,
                CreatedBy = "Admin",
                CreatedDate = DateTime.UtcNow,
                UpdatedBy = "Admin",  // Adding the missing property
                UpdatedDate = DateTime.UtcNow,// Assuming UpdatedDate is required as well
            };

            //Setup
            _mapperMock.Setup(m => m.Map<Domain.V1.Entities.Practitioners.PractitionerTelecom>(newPractitionerTelecom)).Returns(practitionerTelecomEntity);

            // Act
            var result = await _practitionerTelecomCommandService.CreatePractitionerTelecomAsync(newPractitionerTelecom);

            // Assert
            Assert.False(result);
        }
        [Fact]
        public async Task Test_UpdatePractitionerTelecom_Returns_Success()
        {
            //Arrange
            DbContextOptions<ReadWriteDbContext> options = new DbContextOptionsBuilder<ReadWriteDbContext>()
               .UseInMemoryDatabase(databaseName: "UpdatePractitionerTelecom").Options;

            byte[] concurrencyToken = new byte[8] { byte.MinValue, byte.MinValue, byte.MinValue, byte.MinValue, byte.MinValue, byte.MinValue, byte.MinValue, byte.MaxValue };
            var practitionerTelecom = new Domain.V1.Entities.Practitioners.PractitionerTelecom
            {
                Id = 1,
                PractitionerID = 1,
                Status = true,
                System = "test",
                Use = "test",
                Value = "test",
                PeriodStart = DateTime.UtcNow,
                PeriodEnd = DateTime.UtcNow,
                Rank = 1,
                IsDeleted = false,
                CreatedBy = "Admin",
                CreatedDate = DateTime.UtcNow,
                UpdatedBy = "Admin",  // Adding the missing property
                UpdatedDate = DateTime.UtcNow,// Assuming UpdatedDate is required as well
                RecordVersion = concurrencyToken
            };


            //Arrange
            using ReadWriteDbContext dbContext = new(options);
            dbContext.PractitionerTelecoms.Add(practitionerTelecom);
            await dbContext.SaveChangesAsync();


            UpdatePractitionerTelecomRequest updateModel = new UpdatePractitionerTelecomRequest
            {
                Id = 1,
                PractitionerID = 1,
                Status = true,
                System = "test",
                Use = "test",
                Value = "test",
                PeriodStart = DateTime.UtcNow,
                PeriodEnd = DateTime.UtcNow,
                Rank = 1,
                RecordVersion = concurrencyToken
            };

            //updateModel.ID = 1;
            updateModel.RecordVersion = practitionerTelecom.RecordVersion;

            _practitionerTelecomCommandService = new PractitionerTelecomCommandService(dbContext, _mapperMock.Object);

            // Act
            bool result = await _practitionerTelecomCommandService.UpdatePractitionerTelecomAsync(updateModel, practitionerTelecom);

            Assert.True(result);
        }
        [Fact]
        public async Task Test_DeletePractitionerTelecom_Returns_Success()
        {
            //Arrange
            DbContextOptions<ReadWriteDbContext> options = new DbContextOptionsBuilder<ReadWriteDbContext>()
               .UseInMemoryDatabase(databaseName: "DeletePractitionerTelecom").Options;

            byte[] concurrencyToken = new byte[8] { byte.MinValue, byte.MinValue, byte.MinValue, byte.MinValue, byte.MinValue, byte.MinValue, byte.MinValue, byte.MaxValue };
            var practitionerTelecom = new Domain.V1.Entities.Practitioners.PractitionerTelecom
            {
                Id = 1,
                PractitionerID = 1,
                Status = true,
                System = "test",
                Use = "test",
                Value = "test",
                PeriodStart = DateTime.UtcNow,
                PeriodEnd = DateTime.UtcNow,
                Rank = 1,
                IsDeleted = false,
                CreatedBy = "Admin",
                CreatedDate = DateTime.UtcNow,
                UpdatedBy = "Admin",  // Adding the missing property
                UpdatedDate = DateTime.UtcNow,// Assuming UpdatedDate is required as well
                RecordVersion = concurrencyToken
            };



            //Arrange
            using ReadWriteDbContext dbContext = new(options);
            dbContext.PractitionerTelecoms.Add(practitionerTelecom);
            await dbContext.SaveChangesAsync();

            _practitionerTelecomCommandService = new PractitionerTelecomCommandService(dbContext, _mapperMock.Object);

            // Act
            bool result = await _practitionerTelecomCommandService.DeletePractitionerTelecomByIdAsync(concurrencyToken, practitionerTelecom);

            Assert.True(result);
        }
    }
}
