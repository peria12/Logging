﻿using Aurora.AdministrationService.API.Models.Dto.Practitioners;
using Aurora.AdministrationService.API.Models.Dto.Practitioners.PractitionerAddresses;
using Aurora.AdministrationService.API.Models.Dto.Practitioners.PractitionerIdentifiers;
using Aurora.AdministrationService.API.Models.Dto.Practitioners.PractitionerNames;
using Aurora.AdministrationService.API.Models.Dto.Practitioners.PractitionerTelecoms;
using Aurora.AdministrationService.API.Models.ResponseModels.Practitioners;
using Aurora.AdministrationService.API.Services.IService.Practitioners.PractitionerAddresses;
using Aurora.AdministrationService.API.Services.IService.Practitioners.PractitionerIdentifiers;
using Aurora.AdministrationService.API.Services.Service.Practitioners;
using Aurora.AdministrationService.API.Services.Service.Practitioners.PractitionerAddresses;
using Aurora.AdministrationService.API.Services.Service.Practitioners.PractitionerIdentifiers;
using Aurora.AdministrationService.API.Services.Service.Practitioners.PractitionerNames;
using Aurora.AdministrationService.API.Services.Service.Practitioners.PractitionerTelecoms;
using Aurora.AdministrationService.Domain.V1.Entities.Practitioners;
using Aurora.AdministrationService.Infrastructure;
using Aurora.AdministrationService.Tests.API.Controllers.Practitioner;
using AutoMapper;
using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Diagnostics;
using Moq;

namespace Aurora.AdministrationService.Tests.API.Services.Practitioners
{
    public class PractitionerCommandServiceTests
    {
        private readonly Mock<ReadWriteDbContext> _readWriteDbContextMock;
        private readonly Mock<ReadOnlyDbContext> _readOnlyDbContextMock;
        private readonly Mock<IMapper> _mapperMock;
        private PractitionerCommandService _practitionerCommandService;
        private readonly Mock<PractitionerQueryService> _practitionerQueryService;
        private PractitionerAddressesCommandService _practitionerAddressesCommandService;
        private PractitionerIdentifierCommandService _practitionerIdentifierCommandService;
        private PractitionerNamesCommandService _practitionerNamesCommandService;
        private PractitionerTelecomCommandService _practitionerTelecomCommandService;
        public PractitionerCommandServiceTests()
        {
            // Initialize the mocks
            _mapperMock = new Mock<IMapper>();
            _readWriteDbContextMock = new Mock<ReadWriteDbContext>();
            _readOnlyDbContextMock = new Mock<ReadOnlyDbContext>();
            _practitionerQueryService = new Mock<PractitionerQueryService>();

            

            // Setup in-memory ready only database for testing
            DbContextOptions<ReadWriteDbContext> options = new DbContextOptionsBuilder<ReadWriteDbContext>()
              .UseInMemoryDatabase(databaseName: "AdminPractitionerTestDB").Options;

            _readWriteDbContextMock = new(options);

            _practitionerAddressesCommandService = new PractitionerAddressesCommandService(_readWriteDbContextMock.Object, _mapperMock.Object);
            _practitionerIdentifierCommandService = new PractitionerIdentifierCommandService(_readWriteDbContextMock.Object, _mapperMock.Object);
            _practitionerNamesCommandService = new PractitionerNamesCommandService(_readWriteDbContextMock.Object, _mapperMock.Object);
            _practitionerTelecomCommandService = new PractitionerTelecomCommandService(_readWriteDbContextMock.Object, _mapperMock.Object);

            // Initialize the service being tested
            _practitionerCommandService = new PractitionerCommandService(
                _readWriteDbContextMock.Object, 
                _mapperMock.Object,
                _practitionerAddressesCommandService,
                _practitionerIdentifierCommandService,
                _practitionerNamesCommandService,
                _practitionerTelecomCommandService
                );
        }
        [Fact]
        public async Task CreateNewPractitionerAsync_ShouldReturnTrue_WhenUserIsCreatedSuccessfully()
        {
            //Arrange
            DbContextOptions<ReadWriteDbContext> options = new DbContextOptionsBuilder<ReadWriteDbContext>()
                            .UseInMemoryDatabase(databaseName: "CreateNewPractitioner_DB")
                            .ConfigureWarnings(b => b.Ignore(InMemoryEventId.TransactionIgnoredWarning)).Options;

            byte[] concurrencyToken = new byte[8] { byte.MinValue, byte.MinValue, byte.MinValue, byte.MinValue, byte.MinValue, byte.MinValue, byte.MinValue, byte.MaxValue };
            using ReadWriteDbContext dbContext = new(options);

            // Initialize the service being tested
            _practitionerCommandService = new PractitionerCommandService(
                dbContext,
                _mapperMock.Object,
                _practitionerAddressesCommandService,
                _practitionerIdentifierCommandService,
                _practitionerNamesCommandService,
                _practitionerTelecomCommandService
                );

            var practitionerDetailDto = CommonMockData.GetMockPractitionerDetailDto(); // Mock DTO

            // Act
            var result = await _practitionerCommandService.CreateNewPractitionerAsync(practitionerDetailDto);

            // Assert
            Assert.True(result);
        }
        [Fact]
        public async Task CreateNewPractitionerAsync_ShouldReturnFalse_WhenInvalidUserData()
        {
            //Arrange
            DbContextOptions<ReadWriteDbContext> options = new DbContextOptionsBuilder<ReadWriteDbContext>()
                            .UseInMemoryDatabase(databaseName: "CreateNewPractitioner_DB")
                            .ConfigureWarnings(b => b.Ignore(InMemoryEventId.TransactionIgnoredWarning)).Options;

            byte[] concurrencyToken = new byte[8] { byte.MinValue, byte.MinValue, byte.MinValue, byte.MinValue, byte.MinValue, byte.MinValue, byte.MinValue, byte.MaxValue };
            using ReadWriteDbContext dbContext = new(options);

            // Initialize the service being tested
            _practitionerCommandService = new PractitionerCommandService(
                dbContext,
                _mapperMock.Object,
                _practitionerAddressesCommandService,
                _practitionerIdentifierCommandService,
                _practitionerNamesCommandService,
                _practitionerTelecomCommandService
                );

            var practitionerDetailDto = CommonMockData.GetMockPractitionerDetailDto(); // Mock DTO
            practitionerDetailDto.Identifiers[0].IdentifierType = null;
            practitionerDetailDto.Identifiers[0].IdentifierUse = null;
            practitionerDetailDto.Identifiers[0].System = null;
            practitionerDetailDto.Identifiers[0].Value = null;

            // Act
            var result = await _practitionerCommandService.CreateNewPractitionerAsync(practitionerDetailDto);

            // Assert
            Assert.False(result);
        }
        [Fact]
        public async Task UpdatePractitionerDetailAsync_ShouldReturnTrue_WhenUserIsCreatedSuccessfully()
        {
            //Arrange
            DbContextOptions<ReadWriteDbContext> options = new DbContextOptionsBuilder<ReadWriteDbContext>()
                            .UseInMemoryDatabase(databaseName: "UpdatePractitionerDetail_DB")
                            .ConfigureWarnings(b => b.Ignore(InMemoryEventId.TransactionIgnoredWarning)).Options;

            byte[] concurrencyToken = new byte[8] { byte.MinValue, byte.MinValue, byte.MinValue, byte.MinValue, byte.MinValue, byte.MinValue, byte.MinValue, byte.MaxValue };
            

            
            var practitionerDetailDto = CommonMockData.GetMockPractitionerDetailDto(); // Mock DTO
            var updatePractitionerDetailDto= CommonMockData.GetMockPractitionerDetailAsync();

            UpdatePractitionerRequest updatePractitionerRequest = new UpdatePractitionerRequest()
            {
                ResourceID = "123",
                Status = true,
                BirthDate = DateTime.UtcNow,
                Gender = "Male",
                Id = 1,
                Source = "test",
                RecordVersion = concurrencyToken
            };
            // Mock AutoMapper to return the Practitioner entity
            _mapperMock.Setup(m => m.Map<UpdatePractitionerRequest>(practitionerDetailDto)).Returns(updatePractitionerRequest);

            using ReadWriteDbContext dbContext = new(options);
            dbContext.Practitioners.Add(updatePractitionerDetailDto.PractitionerDetail);
            await dbContext.SaveChangesAsync();
            var practitionerCommandService = new PractitionerCommandService(
                dbContext,
                _mapperMock.Object,
                _practitionerAddressesCommandService,
                _practitionerIdentifierCommandService,
                _practitionerNamesCommandService,
                _practitionerTelecomCommandService
                );

            // Act
            var result = await practitionerCommandService.UpdatePractitionerDetailAsync(practitionerDetailDto, updatePractitionerDetailDto);

            // Assert
            Assert.False(result);
        }

        [Fact]
        public async Task CreateNewPractitionerAsync_ShouldReturnError_WhenFirstSaveFails()
        {
            // Arrange
            var options = new DbContextOptionsBuilder<ReadWriteDbContext>()
                .UseInMemoryDatabase(databaseName: "CreateNewPractitioner_DB")
                .ConfigureWarnings(b => b.Ignore(InMemoryEventId.TransactionIgnoredWarning))
                .Options;

            using var dbContext = new ReadWriteDbContext(options);
            _practitionerCommandService = new PractitionerCommandService(
                dbContext,
                _mapperMock.Object,
                _practitionerAddressesCommandService,
                _practitionerIdentifierCommandService,
                _practitionerNamesCommandService,
                _practitionerTelecomCommandService
                );

            var practitionerDetailDto = CommonMockData.GetMockPractitionerDetailDto(); // Mock DTO


            // Act
            var result = await _practitionerCommandService.CreateNewPractitionerAsync(practitionerDetailDto);

            // Assert
            Assert.True(result);
        }

        [Fact]
        public async Task CreateNewPractitionerAsync_ShouldReturnTrue_WhenUserRegisterWithIdentifierNumberCreatedSuccessfully()
        {
            // Arrange
            var options = new DbContextOptionsBuilder<ReadWriteDbContext>()
                .UseInMemoryDatabase(databaseName: "CreateNewPractitionerNew_DB")
                .ConfigureWarnings(b => b.Ignore(InMemoryEventId.TransactionIgnoredWarning))
                .Options;

            using var dbContext = new ReadWriteDbContext(options);
            _practitionerCommandService = new PractitionerCommandService(
                dbContext,
                _mapperMock.Object,
                _practitionerAddressesCommandService,
                _practitionerIdentifierCommandService,
                _practitionerNamesCommandService,
                _practitionerTelecomCommandService
                );

            var practitionerDetailDto = CommonMockData.GetMockPractitionerDetailDto(); // Mock DTO


            // Act
            var result = await _practitionerCommandService.CreateNewPractitionerAsync(practitionerDetailDto);

            // Assert
            Assert.True(result);
        }
        [Fact]
        public async Task CreatePractitionerAsync_ShouldReturnTrue_WhenPractitionerIsCreatedSuccessfully()
        {
            // Arrange
            var newPractitioner = new PractitionerDto
            {
                ResourceID = "123",
                Status = true,
                BirthDate = DateTime.UtcNow,
                Gender = "Male",
                Source = "test",
            };

            // Mock AutoMapper to return a Practitioner entity
            var practitionerId = 1L;
            var practitionerEntity = new Domain.V1.Entities.Practitioners.Practitioner
            {
                Id = practitionerId,
                ResourceID = "123",
                Status = true,
                BirthDate = DateTime.UtcNow,
                Gender = "Male",
                Source = "test",
                IsDeleted = false,
                CreatedBy = "Admin",
                CreatedDate = DateTime.UtcNow,
                UpdatedBy = "Admin",  // Adding the missing property
                UpdatedDate = DateTime.UtcNow,// Assuming UpdatedDate is required as well
            };


            // Mock AutoMapper to return the Practitioner entity
            _mapperMock.Setup(m => m.Map<Practitioner>(newPractitioner)).Returns(practitionerEntity);

            // Mock DbContext to simulate saving the entity without actually hitting the database
            _readWriteDbContextMock.Setup(db => db.Practitioners.Add(It.IsAny<Practitioner>()));

            // Act
            var result = await _practitionerCommandService.CreatePractitionerAsync(newPractitioner);

            // Assert
            Assert.True(result);
            _readWriteDbContextMock.Verify(db => db.Practitioners.Add(It.Is<Practitioner>(l => l.Source == "test")), Times.Once);
        }


        [Fact]
        public async Task CreatePractitionerAsync_ShouldReturnFalse_WhenExceptionOccurs()
        {
            // Arrange
            var newPractitioner = new PractitionerDto
            {
                ResourceID = "123",
                Status = true,
                BirthDate = DateTime.UtcNow,
                Gender = "Male",
                Source = "test",
            };

            // Mock AutoMapper to return a Practitioner entity
            var practitionerId = 1;
            var practitionerEntity = new Domain.V1.Entities.Practitioners.Practitioner
            {
                Id = practitionerId,
                ResourceID = "123",
                Status = true,
                BirthDate = DateTime.UtcNow,
                Gender = "Male",
                Source = "test",
                IsDeleted = false,
                CreatedBy = "Admin",
                CreatedDate = DateTime.UtcNow,
                UpdatedBy = "Admin",  // Adding the missing property
                UpdatedDate = DateTime.UtcNow,// Assuming UpdatedDate is required as well
            };

            //Setup
            _mapperMock.Setup(m => m.Map<Practitioner>(newPractitioner)).Returns(practitionerEntity);

            // Act
            var result = await _practitionerCommandService.CreatePractitionerAsync(newPractitioner);

            // Assert
            Assert.False(result);
        }
        [Fact]
        public async Task Test_UpdatePractitioner_Returns_Success()
        {
            //Arrange
            DbContextOptions<ReadWriteDbContext> options = new DbContextOptionsBuilder<ReadWriteDbContext>()
               .UseInMemoryDatabase(databaseName: "UpdatePractitioner").Options;

            byte[] concurrencyToken = new byte[8] { byte.MinValue, byte.MinValue, byte.MinValue, byte.MinValue, byte.MinValue, byte.MinValue, byte.MinValue, byte.MaxValue };
            var practitioner = new Practitioner
            {
                Id = 1,
                ResourceID = "123",
                Status = true,
                BirthDate = DateTime.UtcNow,
                Gender = "Male",
                Source = "test",
                IsDeleted = false,
                CreatedBy = "Admin",
                CreatedDate = DateTime.UtcNow,
                UpdatedBy = "Admin",  // Adding the missing property
                UpdatedDate = DateTime.UtcNow,// Assuming UpdatedDate is required as well
                RecordVersion = concurrencyToken
            };


            //Arrange
            using ReadWriteDbContext dbContext = new(options);
            dbContext.Practitioners.Add(practitioner);
            await dbContext.SaveChangesAsync();


            UpdatePractitionerRequest updateModel = new UpdatePractitionerRequest
            {
                Id = 1,
                ResourceID = "123",
                Status = true,
                BirthDate = DateTime.UtcNow,
                Gender = "Male",
                Source = "test",
                RecordVersion = concurrencyToken
            };

            //updateModel.ID = 1;
            updateModel.RecordVersion = practitioner.RecordVersion;

            _practitionerCommandService = new PractitionerCommandService(
                dbContext,
                _mapperMock.Object,
                _practitionerAddressesCommandService,
                _practitionerIdentifierCommandService,
                _practitionerNamesCommandService,
                _practitionerTelecomCommandService
                );

            // Act
            bool result = await _practitionerCommandService.UpdatePractitionerAsync(updateModel, practitioner);

            Assert.True(result);
        }
        [Fact]
        public async Task Test_DeletePractitioner_Returns_Success()
        {
            //Arrange
            DbContextOptions<ReadWriteDbContext> options = new DbContextOptionsBuilder<ReadWriteDbContext>()
               .UseInMemoryDatabase(databaseName: "DeletePractitioner").Options;

            byte[] concurrencyToken = new byte[8] { byte.MinValue, byte.MinValue, byte.MinValue, byte.MinValue, byte.MinValue, byte.MinValue, byte.MinValue, byte.MaxValue };
            var practitioner = new Practitioner
            {
                Id = 1,
                ResourceID = "123",
                Status = true,
                BirthDate = DateTime.UtcNow,
                Gender = "Male",
                Source = "test",
                IsDeleted = false,
                CreatedBy = "Admin",
                CreatedDate = DateTime.UtcNow,
                UpdatedBy = "Admin",  // Adding the missing property
                UpdatedDate = DateTime.UtcNow,// Assuming UpdatedDate is required as well
                RecordVersion = concurrencyToken
            };



            //Arrange
            using ReadWriteDbContext dbContext = new(options);
            dbContext.Practitioners.Add(practitioner);
            await dbContext.SaveChangesAsync();

            _practitionerCommandService = new PractitionerCommandService(
                dbContext,
                _mapperMock.Object,
                _practitionerAddressesCommandService,
                _practitionerIdentifierCommandService,
                _practitionerNamesCommandService,
                _practitionerTelecomCommandService
                );

            // Act
            bool result = await _practitionerCommandService.DeletePractitionerByIdAsync(concurrencyToken, practitioner);

            Assert.True(result);
        }

        [Fact]
        public async Task UpdatePractitionerAddressesAsync_Returns_Success()
        {
            //Arrange
            DbContextOptions<ReadWriteDbContext> options = new DbContextOptionsBuilder<ReadWriteDbContext>()
               .UseInMemoryDatabase(databaseName: "UpdatePractitionerAddressesDB").Options;

            byte[] concurrencyToken = new byte[8] { byte.MinValue, byte.MinValue, byte.MinValue, byte.MinValue, byte.MinValue, byte.MinValue, byte.MinValue, byte.MaxValue };
            var practitioner = new Practitioner
            {
                Id = 1,
                ResourceID = "123",
                Status = true,
                BirthDate = DateTime.UtcNow,
                Gender = "Male",
                Source = "test",
                IsDeleted = false,
                CreatedBy = "Admin",
                CreatedDate = DateTime.UtcNow,
                UpdatedBy = "Admin",  // Adding the missing property
                UpdatedDate = DateTime.UtcNow,// Assuming UpdatedDate is required as well
                RecordVersion = concurrencyToken
            };

            PractitionerAddressDetailDto practitionerAddressDetailDto = new PractitionerAddressDetailDto()
            {
                Use = "test",
                City = "test",
                Country = "test",
                District = "test",
                Line1 = "test",
                Line2 = "test",
                Line3 = "test",
                Line4 = "test",
                PeriodEnd = DateTime.UtcNow,
                PeriodStart = DateTime.UtcNow,
                PostalCode = "test",
                State = "test",
                Type = "test",
            };

            Domain.V1.Entities.Practitioners.PractitionerAddresses practitionerAddress = new PractitionerAddresses()
            {
                PractitionerID = 1,
                City = "test",
                Country = "test",
                District = "test",
                Id = 1,
                Line1 = "test",
                Line2 = "test",
                Line3 = "test",
                Line4 = "test",
                State = "test",
                Type = "test",
                PeriodEnd = DateTime.UtcNow,
                PeriodStart = DateTime.UtcNow,
                PostalCode = "test",
                Status = true,
                Use = "test",
                IsDeleted = false,
                CreatedBy = "Admin",
                CreatedDate = DateTime.UtcNow,
                UpdatedBy = "Admin",  // Adding the missing property
                UpdatedDate = DateTime.UtcNow,// Assuming UpdatedDate is required as well
                RecordVersion = concurrencyToken
            };
            UpdatePractitionerAddressesRequest updatePractitionerAddressesRequest = new UpdatePractitionerAddressesRequest() 
            { 
                PractitionerID = 1, 
                City = "test",
                Country = "test",
                District = "test",
                Id = 1,
                Line1 = "test",
                Line2 = "test",
                Line3 = "test",
                Line4 = "test",
                State = "test",
                Type = "test",
                PeriodEnd = DateTime.UtcNow,
                PeriodStart = DateTime.UtcNow,
                PostalCode = "test",
                Status = true,
                Use = "test",

            };

            //Arrange
            using ReadWriteDbContext dbContext = new(options);
            dbContext.Practitioners.Add(practitioner);
            dbContext.PractitionerAddress.Add(practitionerAddress);
            await dbContext.SaveChangesAsync();
            _practitionerAddressesCommandService = new PractitionerAddressesCommandService(dbContext, _mapperMock.Object);
            _practitionerCommandService = new PractitionerCommandService(
                dbContext,
                _mapperMock.Object,
                _practitionerAddressesCommandService,
                _practitionerIdentifierCommandService,
                _practitionerNamesCommandService,
                _practitionerTelecomCommandService
                );
            // Mock AutoMapper to return the Practitioner entity
            _mapperMock.Setup(m => m.Map<UpdatePractitionerAddressesRequest>(practitionerAddressDetailDto)).Returns(updatePractitionerAddressesRequest);
            _mapperMock.Setup(m =>m.Map(updatePractitionerAddressesRequest, practitionerAddress)).Returns(practitionerAddress);


            // Act
            bool result = await _practitionerCommandService.UpdatePractitionerAddressesAsync(practitionerAddressDetailDto, practitionerAddress);

            Assert.True(result);
        }
        [Fact]
        public async Task UpdatePractitionerNamesAsync_Returns_Success()
        {
            //Arrange
            DbContextOptions<ReadWriteDbContext> options = new DbContextOptionsBuilder<ReadWriteDbContext>()
               .UseInMemoryDatabase(databaseName: "UpdatePractitionerNamesDB").Options;

            byte[] concurrencyToken = new byte[8] { byte.MinValue, byte.MinValue, byte.MinValue, byte.MinValue, byte.MinValue, byte.MinValue, byte.MinValue, byte.MaxValue };
            var practitioner = new Practitioner
            {
                Id = 1,
                ResourceID = "123",
                Status = true,
                BirthDate = DateTime.UtcNow,
                Gender = "Male",
                Source = "test",
                IsDeleted = false,
                CreatedBy = "Admin",
                CreatedDate = DateTime.UtcNow,
                UpdatedBy = "Admin",  // Adding the missing property
                UpdatedDate = DateTime.UtcNow,// Assuming UpdatedDate is required as well
                RecordVersion = concurrencyToken
            };

            PractitionerNamesDetailDto practitionerNamesDetail = new PractitionerNamesDetailDto()
            {
                Use = "test",
                PeriodEnd = DateTime.UtcNow,
                PeriodStart = DateTime.UtcNow,
                FamilyName = "test",
                GivenName = "test",
                Language = "test",
                MiddleName = "test",
                Prefix = "test",
                Suffix = "test"
            };

            Domain.V1.Entities.Practitioners.PractitionerNames practitionerNames = new PractitionerNames()
            {
                PractitionerID = 1,
                Status = true,
                Use = "test",
                Id = 1,
                PeriodStart = DateTime.UtcNow,
                PeriodEnd = DateTime.UtcNow,
                FamilyName = "test",
                GivenName = "test",
                Language = "test",
                MiddleName = "test",
                Prefix = "test",
                Suffix = "test",
                IsDeleted = false,
                CreatedBy = "Admin",
                CreatedDate = DateTime.UtcNow,
                UpdatedBy = "Admin",  // Adding the missing property
                UpdatedDate = DateTime.UtcNow,// Assuming UpdatedDate is required as well
                RecordVersion = concurrencyToken
            };
            UpdatePractitionerNamesRequest updatePractitionerNamesRequest = new UpdatePractitionerNamesRequest()
            {
                PractitionerID = 1,
                Id = 1,
                Use = "test",
                PeriodEnd = DateTime.UtcNow,
                PeriodStart = DateTime.UtcNow,
                FamilyName = "test",
                GivenName = "test",
                Language = "test",
                MiddleName = "test",
                Prefix = "test",
                Suffix = "test",
                Status = true,
                RecordVersion = concurrencyToken
            };

            //Arrange
            using ReadWriteDbContext dbContext = new(options);
            dbContext.Practitioners.Add(practitioner);
            dbContext.PractitionerName.Add(practitionerNames);
            await dbContext.SaveChangesAsync();
            _practitionerNamesCommandService = new PractitionerNamesCommandService(dbContext, _mapperMock.Object);
            _practitionerCommandService = new PractitionerCommandService(
                dbContext,
                _mapperMock.Object,
                _practitionerAddressesCommandService,
                _practitionerIdentifierCommandService,
                _practitionerNamesCommandService,
                _practitionerTelecomCommandService
                );
            // Mock AutoMapper to return the Practitioner entity
            _mapperMock.Setup(m => m.Map<UpdatePractitionerNamesRequest>(practitionerNamesDetail)).Returns(updatePractitionerNamesRequest);
            _mapperMock.Setup(m => m.Map(updatePractitionerNamesRequest, practitionerNames)).Returns(practitionerNames);


            // Act
            bool result = await _practitionerCommandService.UpdatePractitionerNamesAsync(practitionerNamesDetail, practitionerNames);

            Assert.True(result);
        }
        [Fact]
        public async Task UpdatePractitionerNamesAsync_Returns_UnSuccess()
        {
            //Arrange
            DbContextOptions<ReadWriteDbContext> options = new DbContextOptionsBuilder<ReadWriteDbContext>()
               .UseInMemoryDatabase(databaseName: "UpdatePractitionerNamesNewDB").Options;
            byte[] concurrencyToken = new byte[8] { byte.MinValue, byte.MinValue, byte.MinValue, byte.MinValue, byte.MinValue, byte.MinValue, byte.MinValue, byte.MaxValue };
             
            // Act
            bool result = await _practitionerCommandService.UpdatePractitionerNamesAsync(null, null);

            Assert.False(result);
        }
        [Fact]
        public async Task UpdatePractitionerAddressesAsync_Returns_UnSuccess()
        {
            //Arrange
            DbContextOptions<ReadWriteDbContext> options = new DbContextOptionsBuilder<ReadWriteDbContext>()
               .UseInMemoryDatabase(databaseName: "UpdatePractitionerAddressesAsyncNewDB").Options;
            byte[] concurrencyToken = new byte[8] { byte.MinValue, byte.MinValue, byte.MinValue, byte.MinValue, byte.MinValue, byte.MinValue, byte.MinValue, byte.MaxValue };

            // Act
            bool result = await _practitionerCommandService.UpdatePractitionerAddressesAsync(null, null);

            Assert.False(result);
        }
        [Fact]
        public async Task UpdatePractitionerIdentifiersAsync_Returns_Success()
        {
            //Arrange
            DbContextOptions<ReadWriteDbContext> options = new DbContextOptionsBuilder<ReadWriteDbContext>()
               .UseInMemoryDatabase(databaseName: "UpdatePractitionerIdentifiersDB").Options;

            byte[] concurrencyToken = new byte[8] { byte.MinValue, byte.MinValue, byte.MinValue, byte.MinValue, byte.MinValue, byte.MinValue, byte.MinValue, byte.MaxValue };
            var practitioner = new Practitioner
            {
                Id = 1,
                ResourceID = "123",
                Status = true,
                BirthDate = DateTime.UtcNow,
                Gender = "Male",
                Source = "test",
                IsDeleted = false,
                CreatedBy = "Admin",
                CreatedDate = DateTime.UtcNow,
                UpdatedBy = "Admin",  // Adding the missing property
                UpdatedDate = DateTime.UtcNow,// Assuming UpdatedDate is required as well
                RecordVersion = concurrencyToken
            };

            Aurora.AdministrationService.API.Models.Dto.Practitioners.PractitionerIdentifierDto practitionerIdentifierDto = new Aurora.AdministrationService.API.Models.Dto.Practitioners.PractitionerIdentifierDto()
            {
                System = "test",
                IdentifierUse = "test",
                PeriodStart = DateTime.UtcNow,
                PeriodEnd = DateTime.UtcNow,
                IdentifierType = "test",
                Value = "test",
                 
            };
            List<Aurora.AdministrationService.API.Models.Dto.Practitioners.PractitionerIdentifierDto> Identifiers = new List<Aurora.AdministrationService.API.Models.Dto.Practitioners.PractitionerIdentifierDto>() { practitionerIdentifierDto };
            PractitionerIdentifier practitionerIdentifier = new PractitionerIdentifier()
            {
                PractitionerID = 1,
                Status = true,
                IdentifierUse = "test",
                System = "test",
                Value = "test",
                Id = 1,
                IdentifierType = "test",
                PeriodEnd = DateTime.UtcNow,
                PeriodStart = DateTime.UtcNow,
                IsDeleted = false,
                CreatedBy = "Admin",
                CreatedDate = DateTime.UtcNow,
                UpdatedBy = "Admin",  // Adding the missing property
                UpdatedDate = DateTime.UtcNow,// Assuming UpdatedDate is required as well
                RecordVersion = concurrencyToken
            };
            List<PractitionerIdentifier> practitionerIdentifiers = new List<PractitionerIdentifier>() { practitionerIdentifier };
            UpdatePractitionerIdentifierRequest updatePractitionerIdentifierRequest = new UpdatePractitionerIdentifierRequest() 
            {
                PractitionerID = 1,
                Status = true,
                IdentifierUse = "test",
                System = "test",
                Value = "test",
                Id = 1,
                IdentifierType = "test",
                PeriodEnd = DateTime.UtcNow,
                PeriodStart = DateTime.UtcNow,
                RecordVersion = concurrencyToken
            };

            //Arrange
            using ReadWriteDbContext dbContext = new(options);
            dbContext.Practitioners.Add(practitioner);
            dbContext.PractitionerIdentifiers.Add(practitionerIdentifier);
            await dbContext.SaveChangesAsync();
            _practitionerIdentifierCommandService = new PractitionerIdentifierCommandService(dbContext, _mapperMock.Object);
            _practitionerCommandService = new PractitionerCommandService(
                dbContext,
                _mapperMock.Object,
                _practitionerAddressesCommandService,
                _practitionerIdentifierCommandService,
                _practitionerNamesCommandService,
                _practitionerTelecomCommandService
                );

            // Mock AutoMapper to return the Practitioner entity
            _mapperMock.Setup(m => m.Map<UpdatePractitionerIdentifierRequest>(Identifiers[0])).Returns(updatePractitionerIdentifierRequest);


            // Act
            bool result = await _practitionerCommandService.UpdatePractitionerIdentifiersAsync(Identifiers, practitionerIdentifiers);

            Assert.True(result);
        }
        [Fact]
        public async Task UpdatePractitionerIdentifiersAsync_Returns_Success_WhenMoreRecords()
        {
            //Arrange
            DbContextOptions<ReadWriteDbContext> options = new DbContextOptionsBuilder<ReadWriteDbContext>()
               .UseInMemoryDatabase(databaseName: "UpdatePractitionerIdentifiersNewDB").Options;

            byte[] concurrencyToken = new byte[8] { byte.MinValue, byte.MinValue, byte.MinValue, byte.MinValue, byte.MinValue, byte.MinValue, byte.MinValue, byte.MaxValue };
            var practitioner = new Practitioner
            {
                Id = 1,
                ResourceID = "123",
                Status = true,
                BirthDate = DateTime.UtcNow,
                Gender = "Male",
                Source = "test",
                IsDeleted = false,
                CreatedBy = "Admin",
                CreatedDate = DateTime.UtcNow,
                UpdatedBy = "Admin",  // Adding the missing property
                UpdatedDate = DateTime.UtcNow,// Assuming UpdatedDate is required as well
                RecordVersion = concurrencyToken
            };

            Aurora.AdministrationService.API.Models.Dto.Practitioners.PractitionerIdentifierDto practitionerIdentifierDto = new Aurora.AdministrationService.API.Models.Dto.Practitioners.PractitionerIdentifierDto()
            {
                System = "test",
                IdentifierUse = "test",
                PeriodStart = DateTime.UtcNow,
                PeriodEnd = DateTime.UtcNow,
                IdentifierType = "test",
                Value = "test",

            };
            List<Aurora.AdministrationService.API.Models.Dto.Practitioners.PractitionerIdentifierDto> Identifiers = new List<Aurora.AdministrationService.API.Models.Dto.Practitioners.PractitionerIdentifierDto>() { practitionerIdentifierDto };
            PractitionerIdentifier practitionerIdentifier = new PractitionerIdentifier()
            {
                PractitionerID = 1,
                Status = true,
                IdentifierUse = "test",
                System = "test",
                Value = "test",
                Id = 1,
                IdentifierType = "test",
                PeriodEnd = DateTime.UtcNow,
                PeriodStart = DateTime.UtcNow,
                IsDeleted = false,
                CreatedBy = "Admin",
                CreatedDate = DateTime.UtcNow,
                UpdatedBy = "Admin",  // Adding the missing property
                UpdatedDate = DateTime.UtcNow,// Assuming UpdatedDate is required as well
                RecordVersion = concurrencyToken
            };
            PractitionerIdentifier practitionerIdentifierNew = new PractitionerIdentifier()
            {
                PractitionerID = 1,
                Status = true,
                IdentifierUse = "test",
                System = "test",
                Value = "test",
                Id = 2,
                IdentifierType = "test",
                PeriodEnd = DateTime.UtcNow,
                PeriodStart = DateTime.UtcNow,
                IsDeleted = false,
                CreatedBy = "Admin",
                CreatedDate = DateTime.UtcNow,
                UpdatedBy = "Admin",  // Adding the missing property
                UpdatedDate = DateTime.UtcNow,// Assuming UpdatedDate is required as well
                RecordVersion = concurrencyToken
            };
            List<PractitionerIdentifier> practitionerIdentifiers = new List<PractitionerIdentifier>() { practitionerIdentifier , practitionerIdentifierNew };
            UpdatePractitionerIdentifierRequest updatePractitionerIdentifierRequest = new UpdatePractitionerIdentifierRequest()
            {
                PractitionerID = 1,
                Status = true,
                IdentifierUse = "test",
                System = "test",
                Value = "test",
                Id = 1,
                IdentifierType = "test",
                PeriodEnd = DateTime.UtcNow,
                PeriodStart = DateTime.UtcNow,
                RecordVersion = concurrencyToken
            };

            //Arrange
            using ReadWriteDbContext dbContext = new(options);
            dbContext.Practitioners.Add(practitioner);
            dbContext.PractitionerIdentifiers.Add(practitionerIdentifier);
            dbContext.PractitionerIdentifiers.Add(practitionerIdentifierNew);
            await dbContext.SaveChangesAsync();
            _practitionerIdentifierCommandService = new PractitionerIdentifierCommandService(dbContext, _mapperMock.Object);
            _practitionerCommandService = new PractitionerCommandService(
                dbContext,
                _mapperMock.Object,
                _practitionerAddressesCommandService,
                _practitionerIdentifierCommandService,
                _practitionerNamesCommandService,
                _practitionerTelecomCommandService
                );

            // Mock AutoMapper to return the Practitioner entity
            _mapperMock.Setup(m => m.Map<UpdatePractitionerIdentifierRequest>(Identifiers[0])).Returns(updatePractitionerIdentifierRequest);


            // Act
            bool result = await _practitionerCommandService.UpdatePractitionerIdentifiersAsync(Identifiers, practitionerIdentifiers);

            Assert.True(result);
        }
        [Fact]
        public async Task UpdatePractitionerIdentifiersAsync_Returns_Success_WhenMoreNewRecords()
        {
            //Arrange
            DbContextOptions<ReadWriteDbContext> options = new DbContextOptionsBuilder<ReadWriteDbContext>()
               .UseInMemoryDatabase(databaseName: "UpdatePractitionerIdentifiersNewDataDB").Options;

            byte[] concurrencyToken = new byte[8] { byte.MinValue, byte.MinValue, byte.MinValue, byte.MinValue, byte.MinValue, byte.MinValue, byte.MinValue, byte.MaxValue };
            var practitioner = new Practitioner
            {
                Id = 1,
                ResourceID = "123",
                Status = true,
                BirthDate = DateTime.UtcNow,
                Gender = "Male",
                Source = "test",
                IsDeleted = false,
                CreatedBy = "Admin",
                CreatedDate = DateTime.UtcNow,
                UpdatedBy = "Admin",  // Adding the missing property
                UpdatedDate = DateTime.UtcNow,// Assuming UpdatedDate is required as well
                RecordVersion = concurrencyToken
            };

            Aurora.AdministrationService.API.Models.Dto.Practitioners.PractitionerIdentifierDto practitionerIdentifierDto = new Aurora.AdministrationService.API.Models.Dto.Practitioners.PractitionerIdentifierDto()
            {
                System = "test",
                IdentifierUse = "test",
                PeriodStart = DateTime.UtcNow,
                PeriodEnd = DateTime.UtcNow,
                IdentifierType = "test",
                Value = "test",

            };
            Aurora.AdministrationService.API.Models.Dto.Practitioners.PractitionerIdentifierDto practitionerIdentifierDtoNew = new Aurora.AdministrationService.API.Models.Dto.Practitioners.PractitionerIdentifierDto()
            {
                System = "test1",
                IdentifierUse = "test1",
                PeriodStart = DateTime.UtcNow,
                PeriodEnd = DateTime.UtcNow,
                IdentifierType = "test1",
                Value = "test1",
            };
            List<Aurora.AdministrationService.API.Models.Dto.Practitioners.PractitionerIdentifierDto> Identifiers = new List<Aurora.AdministrationService.API.Models.Dto.Practitioners.PractitionerIdentifierDto>() { practitionerIdentifierDto, practitionerIdentifierDtoNew };
            PractitionerIdentifier practitionerIdentifier = new PractitionerIdentifier()
            {
                PractitionerID = 1,
                Status = true,
                IdentifierUse = "test",
                System = "test",
                Value = "test",
                Id = 1,
                IdentifierType = "test",
                PeriodEnd = DateTime.UtcNow,
                PeriodStart = DateTime.UtcNow,
                IsDeleted = false,
                CreatedBy = "Admin",
                CreatedDate = DateTime.UtcNow,
                UpdatedBy = "Admin",  // Adding the missing property
                UpdatedDate = DateTime.UtcNow,// Assuming UpdatedDate is required as well
                RecordVersion = concurrencyToken
            };
            PractitionerIdentifier practitionerIdentifierNew = new PractitionerIdentifier()
            {
                PractitionerID = 1,
                Status = true,
                IdentifierUse = "test",
                System = "test",
                Value = "test",
                Id = 2,
                IdentifierType = "test",
                PeriodEnd = DateTime.UtcNow,
                PeriodStart = DateTime.UtcNow,
                IsDeleted = false,
                CreatedBy = "Admin",
                CreatedDate = DateTime.UtcNow,
                UpdatedBy = "Admin",  // Adding the missing property
                UpdatedDate = DateTime.UtcNow,// Assuming UpdatedDate is required as well
                RecordVersion = concurrencyToken
            };
            List<PractitionerIdentifier> practitionerIdentifiers = new List<PractitionerIdentifier>() { practitionerIdentifier };
            UpdatePractitionerIdentifierRequest updatePractitionerIdentifierRequest = new UpdatePractitionerIdentifierRequest()
            {
                PractitionerID = 1,
                Status = true,
                IdentifierUse = "test",
                System = "test",
                Value = "test",
                Id = 1,
                IdentifierType = "test",
                PeriodEnd = DateTime.UtcNow,
                PeriodStart = DateTime.UtcNow,
                RecordVersion = concurrencyToken
            };
            UpdatePractitionerIdentifierRequest updatePractitionerIdentifierRequestNew = new UpdatePractitionerIdentifierRequest()
            {
                PractitionerID = 1,
                Status = true,
                IdentifierUse = "test1",
                System = "test1",
                Value = "test1",
                Id = 2,
                IdentifierType = "test1",
                PeriodEnd = DateTime.UtcNow,
                PeriodStart = DateTime.UtcNow,
                RecordVersion = concurrencyToken
            };
            Aurora.AdministrationService.API.Models.Dto.Practitioners.PractitionerIdentifiers.PractitionerIdentifierDto practitionerIdentifierDtonew = new AdministrationService.API.Models.Dto.Practitioners.PractitionerIdentifiers.PractitionerIdentifierDto()
            {
                PractitionerID = 1,
                Status = true,
                IdentifierUse = "test1",
                System = "test1",
                Value = "test1",
                IdentifierType = "test1",
                PeriodEnd = DateTime.UtcNow,
                PeriodStart = DateTime.UtcNow,
            };
            //Arrange
            using ReadWriteDbContext dbContext = new(options);
            dbContext.Practitioners.Add(practitioner);
            dbContext.PractitionerIdentifiers.Add(practitionerIdentifier);
            await dbContext.SaveChangesAsync();
            _practitionerIdentifierCommandService = new PractitionerIdentifierCommandService(dbContext, _mapperMock.Object);
            _practitionerCommandService = new PractitionerCommandService(
                dbContext,
                _mapperMock.Object,
                _practitionerAddressesCommandService,
                _practitionerIdentifierCommandService,
                _practitionerNamesCommandService,
                _practitionerTelecomCommandService
                );

            // Mock AutoMapper to return the Practitioner entity
            _mapperMock.Setup(m => m.Map<UpdatePractitionerIdentifierRequest>(Identifiers[0])).Returns(updatePractitionerIdentifierRequest);
            _mapperMock.Setup(m => m.Map<UpdatePractitionerIdentifierRequest>(practitionerIdentifierDtoNew)).Returns(updatePractitionerIdentifierRequestNew);
            _mapperMock.Setup(m => m.Map<PractitionerIdentifier>(updatePractitionerIdentifierRequestNew)).Returns(practitionerIdentifierNew);

            _mapperMock.Setup(m => m.Map<Aurora.AdministrationService.API.Models.Dto.Practitioners.PractitionerIdentifiers.PractitionerIdentifierDto>(practitionerIdentifierDtoNew)).Returns(practitionerIdentifierDtonew);

            _mapperMock.Setup(m => m.Map<PractitionerIdentifier>(practitionerIdentifierDtonew)).Returns(practitionerIdentifierNew); 
            // Act
            bool result = await _practitionerCommandService.UpdatePractitionerIdentifiersAsync(Identifiers, practitionerIdentifiers);

            Assert.True(result);
        }


        [Fact]
        public async Task UpdatePractitionerTelecomsAsync_Returns_Success()
        {
            //Arrange
            DbContextOptions<ReadWriteDbContext> options = new DbContextOptionsBuilder<ReadWriteDbContext>()
               .UseInMemoryDatabase(databaseName: "UpdatePractitionerTelecomsDB").Options;

            byte[] concurrencyToken = new byte[8] { byte.MinValue, byte.MinValue, byte.MinValue, byte.MinValue, byte.MinValue, byte.MinValue, byte.MinValue, byte.MaxValue };
            var practitioner = new Practitioner
            {
                Id = 1,
                ResourceID = "123",
                Status = true,
                BirthDate = DateTime.UtcNow,
                Gender = "Male",
                Source = "test",
                IsDeleted = false,
                CreatedBy = "Admin",
                CreatedDate = DateTime.UtcNow,
                UpdatedBy = "Admin",  // Adding the missing property
                UpdatedDate = DateTime.UtcNow,// Assuming UpdatedDate is required as well
                RecordVersion = concurrencyToken
            };

            Aurora.AdministrationService.API.Models.Dto.Practitioners.PractitionerTelecomDetailDto practitionerTelecomDto = new PractitionerTelecomDetailDto
            {
                System = "test",
                PeriodStart = DateTime.UtcNow,
                PeriodEnd = DateTime.UtcNow,
                Value = "test",
                PhoneCountryCode = "001",
                Use = "test",
                Rank = 1
            };
            List<Aurora.AdministrationService.API.Models.Dto.Practitioners.PractitionerTelecomDetailDto> Identifiers = new List<Aurora.AdministrationService.API.Models.Dto.Practitioners.PractitionerTelecomDetailDto>() { practitionerTelecomDto };
            PractitionerTelecom practitionerTelecom = new PractitionerTelecom()
            {
                PractitionerID = 1,
                Status = true,
                System = "test",
                Value = "test",
                Use = "test",
                Rank = 1,
                Id = 1,
                PeriodEnd = DateTime.UtcNow,
                PeriodStart = DateTime.UtcNow,
                IsDeleted = false,
                CreatedBy = "Admin",
                CreatedDate = DateTime.UtcNow,
                UpdatedBy = "Admin",  // Adding the missing property
                UpdatedDate = DateTime.UtcNow,// Assuming UpdatedDate is required as well
                RecordVersion = concurrencyToken
            };
            List<PractitionerTelecom> practitionerTelecoms = new List<PractitionerTelecom>() { practitionerTelecom };
            UpdatePractitionerTelecomRequest updatePractitionerTelecomRequest = new UpdatePractitionerTelecomRequest()
            {
                PractitionerID = 1,
                Status = true,
                System = "test",
                Value = "test",
                Use = "test",
                Rank = 1,
                Id = 1,
                PeriodEnd = DateTime.UtcNow,
                PeriodStart = DateTime.UtcNow,
                RecordVersion = concurrencyToken
            };

            //Arrange
            using ReadWriteDbContext dbContext = new(options);
            dbContext.Practitioners.Add(practitioner);
            dbContext.PractitionerTelecoms.Add(practitionerTelecom);
            await dbContext.SaveChangesAsync();
            _practitionerTelecomCommandService = new PractitionerTelecomCommandService(dbContext, _mapperMock.Object);
            _practitionerCommandService = new PractitionerCommandService(
                dbContext,
                _mapperMock.Object,
                _practitionerAddressesCommandService,
                _practitionerIdentifierCommandService,
                _practitionerNamesCommandService,
                _practitionerTelecomCommandService
                );

            // Mock AutoMapper to return the Practitioner entity
            _mapperMock.Setup(m => m.Map<UpdatePractitionerTelecomRequest>(Identifiers[0])).Returns(updatePractitionerTelecomRequest);


            // Act
            bool result = await _practitionerCommandService.UpdatePractitionerTelecomsAsync(Identifiers, practitionerTelecoms);

            Assert.True(result);
        }


        [Fact]
        public async Task UpdatePractitionerTelecomsAsync_Returns_Success_WhenMoreRecords()
        {
            //Arrange
            DbContextOptions<ReadWriteDbContext> options = new DbContextOptionsBuilder<ReadWriteDbContext>()
               .UseInMemoryDatabase(databaseName: "UpdatePractitionerTelecomsNewDB").Options;

            byte[] concurrencyToken = new byte[8] { byte.MinValue, byte.MinValue, byte.MinValue, byte.MinValue, byte.MinValue, byte.MinValue, byte.MinValue, byte.MaxValue };
            var practitioner = new Practitioner
            {
                Id = 1,
                ResourceID = "123",
                Status = true,
                BirthDate = DateTime.UtcNow,
                Gender = "Male",
                Source = "test",
                IsDeleted = false,
                CreatedBy = "Admin",
                CreatedDate = DateTime.UtcNow,
                UpdatedBy = "Admin",  // Adding the missing property
                UpdatedDate = DateTime.UtcNow,// Assuming UpdatedDate is required as well
                RecordVersion = concurrencyToken
            };

            Aurora.AdministrationService.API.Models.Dto.Practitioners.PractitionerTelecomDetailDto practitionerTelecomDto = new  PractitionerTelecomDetailDto()
            {
                System = "test",
                PeriodStart = DateTime.UtcNow,
                PeriodEnd = DateTime.UtcNow,
                Value = "test",
                PhoneCountryCode = "001",
                Use = "test",
                Rank = 1

            };
            List<Aurora.AdministrationService.API.Models.Dto.Practitioners.PractitionerTelecomDetailDto> Identifiers = new List<PractitionerTelecomDetailDto>() { practitionerTelecomDto };
            PractitionerTelecom practitionerTelecom = new PractitionerTelecom()
            {
                PractitionerID = 1,
                Status = true,
                System = "test",
                Value = "test",
                Use = "test",
                Rank = 1,
                Id = 1,
                PeriodEnd = DateTime.UtcNow,
                PeriodStart = DateTime.UtcNow,
                IsDeleted = false,
                CreatedBy = "Admin",
                CreatedDate = DateTime.UtcNow,
                UpdatedBy = "Admin",  // Adding the missing property
                UpdatedDate = DateTime.UtcNow,// Assuming UpdatedDate is required as well
                RecordVersion = concurrencyToken
            };
            PractitionerTelecom practitionerTelecomNew = new PractitionerTelecom()
            {
                PractitionerID = 1,
                Status = true,
                System = "test",
                Value = "test",
                Use = "test",
                Rank = 1,
                Id = 2,
                PeriodEnd = DateTime.UtcNow,
                PeriodStart = DateTime.UtcNow,
                IsDeleted = false,
                CreatedBy = "Admin",
                CreatedDate = DateTime.UtcNow,
                UpdatedBy = "Admin",  // Adding the missing property
                UpdatedDate = DateTime.UtcNow,// Assuming UpdatedDate is required as well
                RecordVersion = concurrencyToken
            };
            List<PractitionerTelecom> practitionerTelecoms = new List<PractitionerTelecom>() { practitionerTelecom, practitionerTelecomNew };
            UpdatePractitionerTelecomRequest updatePractitionerTelecomRequest = new UpdatePractitionerTelecomRequest()
            {
                PractitionerID = 1,
                Status = true,
                System = "test",
                Value = "test",
                Use = "test",
                Rank = 1,
                Id = 1,
                PeriodEnd = DateTime.UtcNow,
                PeriodStart = DateTime.UtcNow,
                RecordVersion = concurrencyToken
            };

            //Arrange
            using ReadWriteDbContext dbContext = new(options);
            dbContext.Practitioners.Add(practitioner);
            dbContext.PractitionerTelecoms.Add(practitionerTelecom);
            dbContext.PractitionerTelecoms.Add(practitionerTelecomNew);
            await dbContext.SaveChangesAsync();
            _practitionerTelecomCommandService = new PractitionerTelecomCommandService(dbContext, _mapperMock.Object);
            _practitionerCommandService = new PractitionerCommandService(
                dbContext,
                _mapperMock.Object,
                _practitionerAddressesCommandService,
                _practitionerIdentifierCommandService,
                _practitionerNamesCommandService,
                _practitionerTelecomCommandService
                );

            // Mock AutoMapper to return the Practitioner entity
            _mapperMock.Setup(m => m.Map<UpdatePractitionerTelecomRequest>(Identifiers[0])).Returns(updatePractitionerTelecomRequest);


            // Act
            bool result = await _practitionerCommandService.UpdatePractitionerTelecomsAsync(Identifiers, practitionerTelecoms);

            Assert.True(result);
        }
        [Fact]
        public async Task UpdatePractitionerTelecomsAsync_Returns_Success_WhenMoreNewRecords()
        {
            //Arrange
            DbContextOptions<ReadWriteDbContext> options = new DbContextOptionsBuilder<ReadWriteDbContext>()
               .UseInMemoryDatabase(databaseName: "UpdatePractitionerTelecomsNewDataDB").Options;

            byte[] concurrencyToken = new byte[8] { byte.MinValue, byte.MinValue, byte.MinValue, byte.MinValue, byte.MinValue, byte.MinValue, byte.MinValue, byte.MaxValue };
            var practitioner = new Practitioner
            {
                Id = 1,
                ResourceID = "123",
                Status = true,
                BirthDate = DateTime.UtcNow,
                Gender = "Male",
                Source = "test",
                IsDeleted = false,
                CreatedBy = "Admin",
                CreatedDate = DateTime.UtcNow,
                UpdatedBy = "Admin",  // Adding the missing property
                UpdatedDate = DateTime.UtcNow,// Assuming UpdatedDate is required as well
                RecordVersion = concurrencyToken
            };

            Aurora.AdministrationService.API.Models.Dto.Practitioners.PractitionerTelecomDetailDto practitionerTelecomDto = new PractitionerTelecomDetailDto()
            {
                System = "test",
                PeriodStart = DateTime.UtcNow,
                PeriodEnd = DateTime.UtcNow,
                Value = "test",
                PhoneCountryCode = "001",
                Use = "test",
                Rank = 1

            };
            Aurora.AdministrationService.API.Models.Dto.Practitioners.PractitionerTelecomDetailDto practitionerTelecomDtoNew = new PractitionerTelecomDetailDto()
            {
                System = "test1",
                PeriodStart = DateTime.UtcNow,
                PeriodEnd = DateTime.UtcNow,
                Value = "test",
                PhoneCountryCode = "001",
                Use = "test",
                Rank = 1
            };
            List<Aurora.AdministrationService.API.Models.Dto.Practitioners.PractitionerTelecomDetailDto> Identifiers = new List<Aurora.AdministrationService.API.Models.Dto.Practitioners.PractitionerTelecomDetailDto>() { practitionerTelecomDto, practitionerTelecomDtoNew };
            PractitionerTelecom practitionerTelecom = new PractitionerTelecom()
            {
                PractitionerID = 1,
                Status = true,
                System = "test",
                Value = "test",
                Use = "test",
                Rank = 1,
                Id = 1,
                PeriodEnd = DateTime.UtcNow,
                PeriodStart = DateTime.UtcNow,
                IsDeleted = false,
                CreatedBy = "Admin",
                CreatedDate = DateTime.UtcNow,
                UpdatedBy = "Admin",  // Adding the missing property
                UpdatedDate = DateTime.UtcNow,// Assuming UpdatedDate is required as well
                RecordVersion = concurrencyToken
            };
            PractitionerTelecom practitionerTelecomNew = new PractitionerTelecom()
            {
                PractitionerID = 1,
                Status = true,
                System = "test",
                Value = "test",
                Use = "test",
                Rank = 1,
                Id = 2,
                PeriodEnd = DateTime.UtcNow,
                PeriodStart = DateTime.UtcNow,
                IsDeleted = false,
                CreatedBy = "Admin",
                CreatedDate = DateTime.UtcNow,
                UpdatedBy = "Admin",  // Adding the missing property
                UpdatedDate = DateTime.UtcNow,// Assuming UpdatedDate is required as well
                RecordVersion = concurrencyToken
            };
            List<PractitionerTelecom> practitionerTelecoms = new List<PractitionerTelecom>() { practitionerTelecom };
            UpdatePractitionerTelecomRequest updatePractitionerTelecomRequest = new UpdatePractitionerTelecomRequest()
            {
                PractitionerID = 1,
                Status = true,
                System = "test",
                Value = "test",
                PhoneCountryCode = "001",
                Use = "test",
                Rank = 1,
                Id = 1,
                PeriodEnd = DateTime.UtcNow,
                PeriodStart = DateTime.UtcNow,
                RecordVersion = concurrencyToken
            };
            UpdatePractitionerTelecomRequest updatePractitionerTelecomRequestNew = new UpdatePractitionerTelecomRequest()
            {
                PractitionerID = 1,
                Status = true,
                System = "test1",
                Value = "test",
                PhoneCountryCode = "001",
                Use = "test",
                Rank = 1,
                Id = 2,
                PeriodEnd = DateTime.UtcNow,
                PeriodStart = DateTime.UtcNow,
                RecordVersion = concurrencyToken
            };
            Aurora.AdministrationService.API.Models.Dto.Practitioners.PractitionerTelecoms.PractitionerTelecomDto practitionerTelecomDtonew = new AdministrationService.API.Models.Dto.Practitioners.PractitionerTelecoms.PractitionerTelecomDto()
            {
                PractitionerID = 1,
                Status = true,
                System = "test1",
                Value = "test",
                PhoneCountryCode = "001",
                Use = "test",
                Rank = 1,
                PeriodEnd = DateTime.UtcNow,
                PeriodStart = DateTime.UtcNow,
            };
            //Arrange
            using ReadWriteDbContext dbContext = new(options);
            dbContext.Practitioners.Add(practitioner);
            dbContext.PractitionerTelecoms.Add(practitionerTelecom);
            await dbContext.SaveChangesAsync();
            _practitionerTelecomCommandService = new PractitionerTelecomCommandService(dbContext, _mapperMock.Object);
            _practitionerCommandService = new PractitionerCommandService(
                dbContext,
                _mapperMock.Object,
                _practitionerAddressesCommandService,
                _practitionerIdentifierCommandService,
                _practitionerNamesCommandService,
                _practitionerTelecomCommandService
                );

            // Mock AutoMapper to return the Practitioner entity
            _mapperMock.Setup(m => m.Map<UpdatePractitionerTelecomRequest>(Identifiers[0])).Returns(updatePractitionerTelecomRequest);
            _mapperMock.Setup(m => m.Map<UpdatePractitionerTelecomRequest>(practitionerTelecomDtoNew)).Returns(updatePractitionerTelecomRequestNew);
            _mapperMock.Setup(m => m.Map<PractitionerTelecom>(updatePractitionerTelecomRequestNew)).Returns(practitionerTelecomNew);

            _mapperMock.Setup(m => m.Map<Aurora.AdministrationService.API.Models.Dto.Practitioners.PractitionerTelecoms.PractitionerTelecomDto>(practitionerTelecomDtoNew)).Returns(practitionerTelecomDtonew);

            _mapperMock.Setup(m => m.Map<PractitionerTelecom>(practitionerTelecomDtonew)).Returns(practitionerTelecomNew);
            // Act
            bool result = await _practitionerCommandService.UpdatePractitionerTelecomsAsync(Identifiers, practitionerTelecoms);

            Assert.True(result);
        }

    }
}

