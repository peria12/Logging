﻿using Aurora.AdministrationService.API.Models.Dto.Practitioners.PractitionerIdentifiers;
using Aurora.AdministrationService.API.Services.Service.Practitioners.PractitionerIdentifiers;
using Aurora.AdministrationService.Infrastructure;
using AutoMapper;
using Microsoft.EntityFrameworkCore;
using Moq;

namespace Aurora.AdministrationService.Tests.API.Services.Practitioners
{
    public class PractitionerIdentifierCommandServiceTests
    {
        private readonly Mock<ReadWriteDbContext> _readWriteDbContextMock;
        private readonly Mock<ReadOnlyDbContext> _readOnlyDbContextMock;
        private readonly Mock<IMapper> _mapperMock;
        private PractitionerIdentifierCommandService _practitionerIdentifierCommandService;

        public PractitionerIdentifierCommandServiceTests()
        {
            // Initialize the mocks
            _mapperMock = new Mock<IMapper>();
            _readWriteDbContextMock = new Mock<ReadWriteDbContext>();
            _readOnlyDbContextMock = new Mock<ReadOnlyDbContext>();


            // Setup in-memory ready only database for testing
            DbContextOptions<ReadWriteDbContext> options = new DbContextOptionsBuilder<ReadWriteDbContext>()
              .UseInMemoryDatabase(databaseName: "AdminPractitionerIdentifierTestDB").Options;

            _readWriteDbContextMock = new(options);

            // Initialize the service being tested
            _practitionerIdentifierCommandService = new PractitionerIdentifierCommandService(_readWriteDbContextMock.Object, _mapperMock.Object);
        }

        [Fact]
        public async Task CreatePractitionerIdentifierAsync_ShouldReturnTrue_WhenPractitionerIdentifierIsCreatedSuccessfully()
        {
            // Arrange
            var newPractitionerIdentifier = new PractitionerIdentifierDto
            {
                PractitionerID = 1,
                Status = true,
                IdentifierUse = "test",
                System = "test",
                Value = "test",
                IdentifierType = "test",
                PeriodEnd = DateTime.UtcNow,
                PeriodStart = DateTime.UtcNow,
            };

            // Mock AutoMapper to return a PractitionerIdentifier entity
            var practitionerIdentifierId = 1;
            var practitionerIdentifierEntity = new Domain.V1.Entities.Practitioners.PractitionerIdentifier
            {
                Id = practitionerIdentifierId,
                PractitionerID = 1,
                Status = true,
                IdentifierUse = "test",
                System = "test",
                Value = "test",
                IdentifierType = "test",
                PeriodEnd = DateTime.UtcNow,
                PeriodStart = DateTime.UtcNow,
                IsDeleted = false,
                CreatedBy = "Admin",
                CreatedDate = DateTime.UtcNow,
                UpdatedBy = "Admin",  // Adding the missing property
                UpdatedDate = DateTime.UtcNow,// Assuming UpdatedDate is required as well
            };


            // Mock AutoMapper to return the PractitionerIdentifier entity
            _mapperMock.Setup(m => m.Map<Domain.V1.Entities.Practitioners.PractitionerIdentifier>(newPractitionerIdentifier)).Returns(practitionerIdentifierEntity);

            // Mock DbContext to simulate saving the entity without actually hitting the database
            _readWriteDbContextMock.Setup(db => db.PractitionerIdentifiers.Add(It.IsAny<Domain.V1.Entities.Practitioners.PractitionerIdentifier>()));

            // Act
            var result = await _practitionerIdentifierCommandService.CreatePractitionerIdentifierAsync(newPractitionerIdentifier);

            // Assert
            Assert.True(result);
            _readWriteDbContextMock.Verify(db => db.PractitionerIdentifiers.Add(It.Is<Domain.V1.Entities.Practitioners.PractitionerIdentifier>(l => l.Value == "test")), Times.Once);
        }


        [Fact]
        public async Task CreatePractitionerIdentifierAsync_ShouldReturnFalse_WhenExceptionOccurs()
        {
            // Arrange
            var newPractitionerIdentifier = new PractitionerIdentifierDto
            {
                PractitionerID = 1,
                Status = true,
                IdentifierUse = "test",
                System = "test",
                Value = "test",
                IdentifierType = "test",
                PeriodEnd = DateTime.UtcNow,
                PeriodStart = DateTime.UtcNow,
            };

            // Mock AutoMapper to return a PractitionerIdentifier entity
            var practitionerIdentifierId = 1;
            var practitionerIdentifierEntity = new Domain.V1.Entities.Practitioners.PractitionerIdentifier
            {
                Id = practitionerIdentifierId,
                PractitionerID = 1,
                Status = true,
                IdentifierUse = "test",
                System = "test",
                Value = "test",
                IdentifierType = "test",
                PeriodEnd = DateTime.UtcNow,
                PeriodStart = DateTime.UtcNow,
                IsDeleted = false,
                CreatedBy = "Admin",
                CreatedDate = DateTime.UtcNow,
                UpdatedBy = "Admin",  // Adding the missing property
                UpdatedDate = DateTime.UtcNow,// Assuming UpdatedDate is required as well
            };

            //Setup
            _mapperMock.Setup(m => m.Map<Domain.V1.Entities.Practitioners.PractitionerIdentifier>(newPractitionerIdentifier)).Returns(practitionerIdentifierEntity);

            // Act
            var result = await _practitionerIdentifierCommandService.CreatePractitionerIdentifierAsync(newPractitionerIdentifier);

            // Assert
            Assert.False(result);
        }
        [Fact]
        public async Task Test_UpdatePractitionerIdentifier_Returns_Success()
        {
            //Arrange
            DbContextOptions<ReadWriteDbContext> options = new DbContextOptionsBuilder<ReadWriteDbContext>()
               .UseInMemoryDatabase(databaseName: "UpdatePractitionerIdentifier").Options;

            byte[] concurrencyToken = new byte[8] { byte.MinValue, byte.MinValue, byte.MinValue, byte.MinValue, byte.MinValue, byte.MinValue, byte.MinValue, byte.MaxValue };
            var practitionerIdentifier = new Domain.V1.Entities.Practitioners.PractitionerIdentifier
            {
                Id = 1,
                PractitionerID = 1,
                Status = true,
                IdentifierUse = "test",
                System = "test",
                Value = "test",
                IdentifierType = "test",
                PeriodEnd = DateTime.UtcNow,
                PeriodStart = DateTime.UtcNow,
                IsDeleted = false,
                CreatedBy = "Admin",
                CreatedDate = DateTime.UtcNow,
                UpdatedBy = "Admin",  // Adding the missing property
                UpdatedDate = DateTime.UtcNow,// Assuming UpdatedDate is required as well
                RecordVersion = concurrencyToken
            };


            //Arrange
            using ReadWriteDbContext dbContext = new(options);
            dbContext.PractitionerIdentifiers.Add(practitionerIdentifier);
            await dbContext.SaveChangesAsync();


            UpdatePractitionerIdentifierRequest updateModel = new UpdatePractitionerIdentifierRequest
            {
                Id = 1,
                PractitionerID = 1,
                Status = true,
                IdentifierUse = "test",
                System = "test",
                Value = "test",
                IdentifierType = "test",
                PeriodEnd = DateTime.UtcNow,
                PeriodStart = DateTime.UtcNow,
                RecordVersion = concurrencyToken
            };

            //updateModel.ID = 1;
            updateModel.RecordVersion = practitionerIdentifier.RecordVersion;

            _practitionerIdentifierCommandService = new PractitionerIdentifierCommandService(dbContext, _mapperMock.Object);

            // Act
            bool result = await _practitionerIdentifierCommandService.UpdatePractitionerIdentifierAsync(updateModel, practitionerIdentifier);

            Assert.True(result);
        }
        [Fact]
        public async Task Test_DeletePractitionerIdentifier_Returns_Success()
        {
            //Arrange
            DbContextOptions<ReadWriteDbContext> options = new DbContextOptionsBuilder<ReadWriteDbContext>()
               .UseInMemoryDatabase(databaseName: "DeletePractitionerIdentifier").Options;

            byte[] concurrencyToken = new byte[8] { byte.MinValue, byte.MinValue, byte.MinValue, byte.MinValue, byte.MinValue, byte.MinValue, byte.MinValue, byte.MaxValue };
            var practitionerIdentifier = new Domain.V1.Entities.Practitioners.PractitionerIdentifier
            {
                Id = 1,
                PractitionerID = 1,
                Status = true,
                IdentifierUse = "test",
                System = "test",
                Value = "test",
                IdentifierType = "test",
                PeriodEnd = DateTime.UtcNow,
                PeriodStart = DateTime.UtcNow,
                IsDeleted = false,
                CreatedBy = "Admin",
                CreatedDate = DateTime.UtcNow,
                UpdatedBy = "Admin",  // Adding the missing property
                UpdatedDate = DateTime.UtcNow,// Assuming UpdatedDate is required as well
                RecordVersion = concurrencyToken
            };



            //Arrange
            using ReadWriteDbContext dbContext = new(options);
            dbContext.PractitionerIdentifiers.Add(practitionerIdentifier);
            await dbContext.SaveChangesAsync();

            _practitionerIdentifierCommandService = new PractitionerIdentifierCommandService(dbContext, _mapperMock.Object);

            // Act
            bool result = await _practitionerIdentifierCommandService.DeletePractitionerIdentifierByIdAsync(concurrencyToken, practitionerIdentifier);

            Assert.True(result);
        }
    }
}
