﻿using Aurora.AdministrationService.API.Models.Dto.Practitioners.PractitionerNames;
using Aurora.AdministrationService.API.Services.Service.Practitioners.PractitionerNames;
using Aurora.AdministrationService.Infrastructure;
using AutoMapper;
using Microsoft.EntityFrameworkCore;
using Moq;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Aurora.AdministrationService.Tests.API.Services.Practitioners
{
    public class PractitionerNamesCommandServiceTests
    {
        private readonly Mock<ReadWriteDbContext> _readWriteDbContextMock;
        private readonly Mock<ReadOnlyDbContext> _readOnlyDbContextMock;
        private readonly Mock<IMapper> _mapperMock;
        private PractitionerNamesCommandService _practitionerNamesCommandService;

        public PractitionerNamesCommandServiceTests()
        {
            // Initialize the mocks
            _mapperMock = new Mock<IMapper>();
            _readWriteDbContextMock = new Mock<ReadWriteDbContext>();
            _readOnlyDbContextMock = new Mock<ReadOnlyDbContext>();


            // Setup in-memory ready only database for testing
            DbContextOptions<ReadWriteDbContext> options = new DbContextOptionsBuilder<ReadWriteDbContext>()
              .UseInMemoryDatabase(databaseName: "AdminPractitionerNamesTestDB").Options;

            _readWriteDbContextMock = new(options);

            // Initialize the service being tested
            _practitionerNamesCommandService = new PractitionerNamesCommandService(_readWriteDbContextMock.Object, _mapperMock.Object);
        }

        [Fact]
        public async Task CreatePractitionerNamesAsync_ShouldReturnTrue_WhenPractitionerNamesIsCreatedSuccessfully()
        {
            // Arrange
            var newPractitionerNames = new PractitionerNamesDto
            {
                PractitionerID = 1,
                Status = true,
                Use = "test",
                PeriodStart = DateTime.UtcNow,
                PeriodEnd = DateTime.UtcNow,
                FamilyName = "test",
                GivenName = "test",
                Language = "test",
                MiddleName = "test",
                Prefix = "test",
                Suffix = "test",
            };

            // Mock AutoMapper to return a PractitionerNames entity
            var practitionerNamesId = 1;
            var practitionerNamesEntity = new Domain.V1.Entities.Practitioners.PractitionerNames
            {
                Id = practitionerNamesId,
                PractitionerID = 1,
                Use = "test",
                PeriodStart = DateTime.UtcNow,
                PeriodEnd = DateTime.UtcNow,
                FamilyName = "test",
                GivenName = "test",
                Language = "test",
                MiddleName = "test",
                Prefix = "test",
                Suffix = "test",
                Status = true,
                IsDeleted = false,
                CreatedBy = "Admin",
                CreatedDate = DateTime.UtcNow,
                UpdatedBy = "Admin",  // Adding the missing property
                UpdatedDate = DateTime.UtcNow,// Assuming UpdatedDate is required as well
            };


            // Mock AutoMapper to return the PractitionerNames entity
            _mapperMock.Setup(m => m.Map<Domain.V1.Entities.Practitioners.PractitionerNames>(newPractitionerNames)).Returns(practitionerNamesEntity);

            // Mock DbContext to simulate saving the entity without actually hitting the database
            _readWriteDbContextMock.Setup(db => db.PractitionerName.Add(It.IsAny<Domain.V1.Entities.Practitioners.PractitionerNames>()));

            // Act
            var result = await _practitionerNamesCommandService.CreatePractitionerNamesAsync(newPractitionerNames);

            // Assert
            Assert.True(result);
            _readWriteDbContextMock.Verify(db => db.PractitionerName.Add(It.Is<Domain.V1.Entities.Practitioners.PractitionerNames>(l => l.FamilyName == "test")), Times.Once);
        }


        [Fact]
        public async Task CreatePractitionerNamesAsync_ShouldReturnFalse_WhenExceptionOccurs()
        {
            // Arrange
            var newPractitionerNames = new PractitionerNamesDto
            {
                PractitionerID = 1,
                Use = "test",
                PeriodStart = DateTime.UtcNow,
                PeriodEnd = DateTime.UtcNow,
                FamilyName = "test",
                GivenName = "test",
                Language = "test",
                MiddleName = "test",
                Prefix = "test",
                Suffix = "test",
                Status = true,
            };

            // Mock AutoMapper to return a PractitionerNames entity
            var practitionerNamesId = 1;
            var practitionerNamesEntity = new Domain.V1.Entities.Practitioners.PractitionerNames
            {
                Id = practitionerNamesId,
                PractitionerID = 1,
                Use = "test",
                PeriodStart = DateTime.UtcNow,
                PeriodEnd = DateTime.UtcNow,
                FamilyName = "test",
                GivenName = "test",
                Language = "test",
                MiddleName = "test",
                Prefix = "test",
                Suffix = "test",
                Status = true,
                IsDeleted = false,
                CreatedBy = "Admin",
                CreatedDate = DateTime.UtcNow,
                UpdatedBy = "Admin",  // Adding the missing property
                UpdatedDate = DateTime.UtcNow,// Assuming UpdatedDate is required as well
            };

            //Setup
            _mapperMock.Setup(m => m.Map<Domain.V1.Entities.Practitioners.PractitionerNames>(newPractitionerNames)).Returns(practitionerNamesEntity);

            // Act
            var result = await _practitionerNamesCommandService.CreatePractitionerNamesAsync(newPractitionerNames);

            // Assert
            Assert.False(result);
        }
        [Fact]
        public async Task Test_UpdatePractitionerNames_Returns_Success()
        {
            //Arrange
            DbContextOptions<ReadWriteDbContext> options = new DbContextOptionsBuilder<ReadWriteDbContext>()
               .UseInMemoryDatabase(databaseName: "UpdatePractitionerNames").Options;

            byte[] concurrencyToken = new byte[8] { byte.MinValue, byte.MinValue, byte.MinValue, byte.MinValue, byte.MinValue, byte.MinValue, byte.MinValue, byte.MaxValue };
            var practitionerNames = new Domain.V1.Entities.Practitioners.PractitionerNames
            {
                Id = 1,
                PractitionerID = 1,
                Use = "test",
                PeriodStart = DateTime.UtcNow,
                PeriodEnd = DateTime.UtcNow,
                FamilyName = "test",
                GivenName = "test",
                Language = "test",
                MiddleName = "test",
                Prefix = "test",
                Suffix = "test",
                Status = true,
                IsDeleted = false,
                CreatedBy = "Admin",
                CreatedDate = DateTime.UtcNow,
                UpdatedBy = "Admin",  // Adding the missing property
                UpdatedDate = DateTime.UtcNow,// Assuming UpdatedDate is required as well
                RecordVersion = concurrencyToken
            };


            //Arrange
            using ReadWriteDbContext dbContext = new(options);
            dbContext.PractitionerName.Add(practitionerNames);
            await dbContext.SaveChangesAsync();


            UpdatePractitionerNamesRequest updateModel = new UpdatePractitionerNamesRequest
            {
                Id = 1,
                PractitionerID = 1,
                Use = "test",
                PeriodStart = DateTime.UtcNow,
                PeriodEnd = DateTime.UtcNow,
                FamilyName = "test",
                GivenName = "test",
                Language = "test",
                MiddleName = "test",
                Prefix = "test",
                Status = true,
                Suffix = "test",
                RecordVersion = concurrencyToken
            };

            //updateModel.ID = 1;
            updateModel.RecordVersion = practitionerNames.RecordVersion;

            _practitionerNamesCommandService = new PractitionerNamesCommandService(dbContext, _mapperMock.Object);

            // Act
            bool result = await _practitionerNamesCommandService.UpdatePractitionerNamesAsync(updateModel, practitionerNames);

            Assert.True(result);
        }
        [Fact]
        public async Task Test_DeletePractitionerNames_Returns_Success()
        {
            //Arrange
            DbContextOptions<ReadWriteDbContext> options = new DbContextOptionsBuilder<ReadWriteDbContext>()
               .UseInMemoryDatabase(databaseName: "DeletePractitionerNames").Options;

            byte[] concurrencyToken = new byte[8] { byte.MinValue, byte.MinValue, byte.MinValue, byte.MinValue, byte.MinValue, byte.MinValue, byte.MinValue, byte.MaxValue };
            var practitionerNames = new Domain.V1.Entities.Practitioners.PractitionerNames
            {
                Id = 1,
                PractitionerID = 1,
                Use = "test",
                PeriodStart = DateTime.UtcNow,
                PeriodEnd = DateTime.UtcNow,
                FamilyName = "test",
                GivenName = "test",
                Language = "test",
                MiddleName = "test",
                Prefix = "test",
                Suffix = "test",
                Status = true,
                IsDeleted = false,
                CreatedBy = "Admin",
                CreatedDate = DateTime.UtcNow,
                UpdatedBy = "Admin",  // Adding the missing property
                UpdatedDate = DateTime.UtcNow,// Assuming UpdatedDate is required as well
                RecordVersion = concurrencyToken
            };



            //Arrange
            using ReadWriteDbContext dbContext = new(options);
            dbContext.PractitionerName.Add(practitionerNames);
            await dbContext.SaveChangesAsync();

            _practitionerNamesCommandService = new PractitionerNamesCommandService(dbContext, _mapperMock.Object);

            // Act
            bool result = await _practitionerNamesCommandService.DeletePractitionerNamesByIdAsync(concurrencyToken, practitionerNames);

            Assert.True(result);
        }
    }
}
