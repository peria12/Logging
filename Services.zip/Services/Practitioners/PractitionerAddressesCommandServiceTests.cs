﻿using Aurora.AdministrationService.API.Models.Dto.Practitioners.PractitionerAddresses;
using Aurora.AdministrationService.API.Services.Service.Practitioners.PractitionerAddresses;
using Aurora.AdministrationService.Domain.V1.Entities.Practitioners;
using Aurora.AdministrationService.Infrastructure;
using AutoMapper;
using Microsoft.EntityFrameworkCore;
using Moq;

namespace Aurora.AdministrationService.Tests.API.Services.Practitioners
{
    public class PractitionerAddressesCommandServiceTests
    {
        private readonly Mock<ReadWriteDbContext> _readWriteDbContextMock;
        private readonly Mock<ReadOnlyDbContext> _readOnlyDbContextMock;
        private readonly Mock<IMapper> _mapperMock;
        private PractitionerAddressesCommandService _practitionerAddressesCommandService;

        public PractitionerAddressesCommandServiceTests()
        {
            // Initialize the mocks
            _mapperMock = new Mock<IMapper>();
            _readWriteDbContextMock = new Mock<ReadWriteDbContext>();
            _readOnlyDbContextMock = new Mock<ReadOnlyDbContext>();


            // Setup in-memory ready only database for testing
            DbContextOptions<ReadWriteDbContext> options = new DbContextOptionsBuilder<ReadWriteDbContext>()
              .UseInMemoryDatabase(databaseName: "AdminPractitionerAddressesTestDB").Options;

            _readWriteDbContextMock = new(options);

            // Initialize the service being tested
            _practitionerAddressesCommandService = new PractitionerAddressesCommandService(_readWriteDbContextMock.Object, _mapperMock.Object);
        }

        [Fact]
        public async Task CreatePractitionerAddressesAsync_ShouldReturnTrue_WhenPractitionerAddressesIsCreatedSuccessfully()
        {
            // Arrange
            var newPractitionerAddresses = new PractitionerAddressesDto
            {
                PractitionerID = 1,
                City = "test",
                Country = "test",
                District = "test",
                Line1 = "test",
                Line2 = "test",
                Line3 = "test",
                Line4 = "test",
                State = "test",
                Type = "test",
                PeriodEnd = DateTime.UtcNow,
                PeriodStart = DateTime.UtcNow,
                PostalCode = "test",
                Status = true,
                Use = "test",
            };

            // Mock AutoMapper to return a PractitionerAddresses entity
            var practitionerAddressesId = 1;
            var practitionerAddressesEntity = new Domain.V1.Entities.Practitioners.PractitionerAddresses
            {
                Id = practitionerAddressesId,
                PractitionerID = 1,
                City = "test",
                Country = "test",
                District = "test",
                Line1 = "test",
                Line2 = "test",
                Line3 = "test",
                Line4 = "test",
                State = "test",
                Type = "test",
                PeriodEnd = DateTime.UtcNow,
                PeriodStart = DateTime.UtcNow,
                PostalCode = "test",
                Status = true,
                Use = "test",
                IsDeleted = false,
                CreatedBy = "Admin",
                CreatedDate = DateTime.UtcNow,
                UpdatedBy = "Admin",  // Adding the missing property
                UpdatedDate = DateTime.UtcNow,// Assuming UpdatedDate is required as well
            };


            // Mock AutoMapper to return the PractitionerAddresses entity
            _mapperMock.Setup(m => m.Map<PractitionerAddresses>(newPractitionerAddresses)).Returns(practitionerAddressesEntity);

            // Mock DbContext to simulate saving the entity without actually hitting the database
            _readWriteDbContextMock.Setup(db => db.PractitionerAddress.Add(It.IsAny<PractitionerAddresses>()));

            // Act
            var result = await _practitionerAddressesCommandService.CreatePractitionerAddressesAsync(newPractitionerAddresses);

            // Assert
            Assert.True(result);
            _readWriteDbContextMock.Verify(db => db.PractitionerAddress.Add(It.Is<PractitionerAddresses>(l => l.Type == "test")), Times.Once);
        }


        [Fact]
        public async Task CreatePractitionerAddressesAsync_ShouldReturnFalse_WhenExceptionOccurs()
        {
            // Arrange
            var newPractitionerAddresses = new PractitionerAddressesDto
            {
                PractitionerID = 1,
                City = "test",
                Country = "test",
                District = "test",
                Line1 = "test",
                Line2 = "test",
                Line3 = "test",
                Line4 = "test",
                State = "test",
                Type = "test",
                PeriodEnd = DateTime.UtcNow,
                PeriodStart = DateTime.UtcNow,
                PostalCode = "test",
                Status = true,
                Use = "test",
            };

            // Mock AutoMapper to return a PractitionerAddresses entity
            var practitionerAddressesId = 1;
            var practitionerAddressesEntity = new Domain.V1.Entities.Practitioners.PractitionerAddresses
            {
                Id = practitionerAddressesId,
                PractitionerID = 1,
                City = "test",
                Country = "test",
                District = "test",
                Line1 = "test",
                Line2 = "test",
                Line3 = "test",
                Line4 = "test",
                State = "test",
                Type = "test",
                PeriodEnd = DateTime.UtcNow,
                PeriodStart = DateTime.UtcNow,
                PostalCode = "test",
                Status = true,
                Use = "test",
                IsDeleted = false,
                CreatedBy = "Admin",
                CreatedDate = DateTime.UtcNow,
                UpdatedBy = "Admin",  // Adding the missing property
                UpdatedDate = DateTime.UtcNow,// Assuming UpdatedDate is required as well
            };

            //Setup
            _mapperMock.Setup(m => m.Map<PractitionerAddresses>(newPractitionerAddresses)).Returns(practitionerAddressesEntity);

            // Act
            var result = await _practitionerAddressesCommandService.CreatePractitionerAddressesAsync(newPractitionerAddresses);

            // Assert
            Assert.False(result);
        }
        [Fact]
        public async Task Test_UpdatePractitionerAddresses_Returns_Success()
        {
            //Arrange
            DbContextOptions<ReadWriteDbContext> options = new DbContextOptionsBuilder<ReadWriteDbContext>()
               .UseInMemoryDatabase(databaseName: "UpdatePractitionerAddresses").Options;

            byte[] concurrencyToken = new byte[8] { byte.MinValue, byte.MinValue, byte.MinValue, byte.MinValue, byte.MinValue, byte.MinValue, byte.MinValue, byte.MaxValue };
            var practitionerAddresses = new Domain.V1.Entities.Practitioners.PractitionerAddresses
            {
                Id = 1,
                PractitionerID = 1,
                City = "test",
                Country = "test",
                District = "test",
                Line1 = "test",
                Line2 = "test",
                Line3 = "test",
                Line4 = "test",
                State = "test",
                Type = "test",
                PeriodEnd = DateTime.UtcNow,
                PeriodStart = DateTime.UtcNow,
                PostalCode = "test",
                Status = true,
                Use = "test",
                IsDeleted = false,
                CreatedBy = "Admin",
                CreatedDate = DateTime.UtcNow,
                UpdatedBy = "Admin",  // Adding the missing property
                UpdatedDate = DateTime.UtcNow,// Assuming UpdatedDate is required as well
                RecordVersion = concurrencyToken
            };


            //Arrange
            using ReadWriteDbContext dbContext = new(options);
            dbContext.PractitionerAddress.Add(practitionerAddresses);
            await dbContext.SaveChangesAsync();


            UpdatePractitionerAddressesRequest updateModel = new UpdatePractitionerAddressesRequest
            {
                Id = 1,
                PractitionerID = 1,
                City = "test",
                Country = "test",
                District = "test",
                Line1 = "test",
                Line2 = "test",
                Line3 = "test",
                Line4 = "test",
                State = "test",
                Type = "test",
                PeriodEnd = DateTime.UtcNow,
                PeriodStart = DateTime.UtcNow,
                PostalCode = "test",
                Status = true,
                Use = "test",
                RecordVersion = concurrencyToken
            };

            //updateModel.ID = 1;
            updateModel.RecordVersion = practitionerAddresses.RecordVersion;

            _practitionerAddressesCommandService = new PractitionerAddressesCommandService(dbContext, _mapperMock.Object);

            // Act
            bool result = await _practitionerAddressesCommandService.UpdatePractitionerAddressesAsync(updateModel, practitionerAddresses);

            Assert.True(result);
        }
        [Fact]
        public async Task Test_DeletePractitionerAddresses_Returns_Success()
        {
            //Arrange
            DbContextOptions<ReadWriteDbContext> options = new DbContextOptionsBuilder<ReadWriteDbContext>()
               .UseInMemoryDatabase(databaseName: "DeletePractitionerAddresses").Options;

            byte[] concurrencyToken = new byte[8] { byte.MinValue, byte.MinValue, byte.MinValue, byte.MinValue, byte.MinValue, byte.MinValue, byte.MinValue, byte.MaxValue };
            var practitionerAddresses = new Domain.V1.Entities.Practitioners.PractitionerAddresses
            {
                Id = 1,
                PractitionerID = 1,
                City = "test",
                Country = "test",
                District = "test",
                Line1 = "test",
                Line2 = "test",
                Line3 = "test",
                Line4 = "test",
                State = "test",
                Type = "test",
                PeriodEnd = DateTime.UtcNow,
                PeriodStart = DateTime.UtcNow,
                PostalCode = "test",
                Status = true,
                Use = "test",
                IsDeleted = false,
                CreatedBy = "Admin",
                CreatedDate = DateTime.UtcNow,
                UpdatedBy = "Admin",  // Adding the missing property
                UpdatedDate = DateTime.UtcNow,// Assuming UpdatedDate is required as well
                RecordVersion = concurrencyToken
            };



            //Arrange
            using ReadWriteDbContext dbContext = new(options);
            dbContext.PractitionerAddress.Add(practitionerAddresses);
            await dbContext.SaveChangesAsync();

            _practitionerAddressesCommandService = new PractitionerAddressesCommandService(dbContext, _mapperMock.Object);

            // Act
            bool result = await _practitionerAddressesCommandService.DeletePractitionerAddressesByIdAsync(concurrencyToken, practitionerAddresses);

            Assert.True(result);
        }
    }
}
