﻿using Aurora.AdministrationService.API.Enum;
using Aurora.AdministrationService.API.Models.Dto.Practitioners;
using Aurora.AdministrationService.API.Models.ResponseModels.Practitioners;
using Aurora.AdministrationService.API.Services.Service.Practitioners;
using Aurora.AdministrationService.CrossCutting.CommonModels;
using Aurora.AdministrationService.Domain.V1.Entities.Contents;
using Aurora.AdministrationService.Domain.V1.Entities.Locations;
using Aurora.AdministrationService.Domain.V1.Entities.Organizations;
using Aurora.AdministrationService.Domain.V1.Entities.Practitioners;
using Aurora.AdministrationService.Infrastructure;
using AutoMapper;
using FluentAssertions;
using FluentAssertions.Common;
using Microsoft.EntityFrameworkCore;
using Moq;
using System.Collections.Concurrent;

namespace Aurora.AdministrationService.Tests.API.Services.Practitioners
{

    public class PractitionerQueryServiceTests
    {
        private readonly Mock<ReadOnlyDbContext> _readOnlyDbContextMock;
        private readonly Mock<IMapper> _mapperMock;
        private readonly PractitionerQueryService _practitionerQueryService;
        private Mock<DbSet<Domain.V1.Entities.Practitioners.Practitioner>> _mockDbSet;
        private readonly DbContextOptions<ReadOnlyDbContext> _dbContextOptions;

        public PractitionerQueryServiceTests()
        {
            //Initialize mock
            _readOnlyDbContextMock = new Mock<ReadOnlyDbContext>();
            _mapperMock = new Mock<IMapper>();
            _dbContextOptions = new DbContextOptionsBuilder<ReadOnlyDbContext>()
               .UseInMemoryDatabase(databaseName: Guid.NewGuid().ToString()) // Unique DB for each test
               .Options;
            // Setup in-memory ready only database for testing
            DbContextOptions<ReadOnlyDbContext> options = new DbContextOptionsBuilder<ReadOnlyDbContext>()
              .UseInMemoryDatabase(databaseName: "AdminPractitionersTestDB").Options;

            _readOnlyDbContextMock = new(options);

            _mockDbSet = new Mock<DbSet<Domain.V1.Entities.Practitioners.Practitioner>>();

            var data = new List<Domain.V1.Entities.Practitioners.Practitioner>
            {
                new  Domain.V1.Entities.Practitioners.Practitioner { Id = 1, ResourceID="1" , IsDeleted = false, Status = true, CreatedDate=DateTime.UtcNow, CreatedBy="Admin" },
                new  Domain.V1.Entities.Practitioners.Practitioner { Id = 2, ResourceID="1" , IsDeleted = true, Status = false,  CreatedDate=DateTime.UtcNow, CreatedBy="Admin" }

            }.AsQueryable();


            //Setup
            _mockDbSet.As<IQueryable<Domain.V1.Entities.Practitioners.Practitioner>>().Setup(m => m.Provider).Returns(data.Provider);
            _mockDbSet.As<IQueryable<Domain.V1.Entities.Practitioners.Practitioner>>().Setup(m => m.Expression).Returns(data.Expression);
            _mockDbSet.As<IQueryable<Domain.V1.Entities.Practitioners.Practitioner>>().Setup(m => m.ElementType).Returns(data.ElementType);
            _mockDbSet.As<IQueryable<Domain.V1.Entities.Practitioners.Practitioner>>().Setup(m => m.GetEnumerator()).Returns(data.GetEnumerator());
            _readOnlyDbContextMock.Setup(c => c.Practitioners).Returns(_mockDbSet.Object);
            // Create the service instance
            _practitionerQueryService = new PractitionerQueryService(_readOnlyDbContextMock.Object, _mapperMock.Object);
        }

        [Fact]
        public async Task GetPractitionerById_PractitionersExists_ReturnsPractitionersDetailDto()
        {
            // Arrange
            var practitionersId = 1;
            var practitioners = new Domain.V1.Entities.Practitioners.Practitioner
            {
                Id = practitionersId,
                ResourceID = "1",
                Status = true,
                CreatedBy = "Admin",
                IsDeleted = false,
                CreatedDate = DateTime.UtcNow,
            };

            var practitionersDto = new GetPractitionerDetailDto
            {
                Id = practitionersId,
                Status = true,
                IsDeleted = false,
            };

            _readOnlyDbContextMock.Setup(db => db.Practitioners.FindAsync(practitionersId))
                .ReturnsAsync(practitioners);

            _mapperMock.Setup(m => m.Map<GetPractitionerDetailDto>(practitioners))
                .Returns(practitionersDto);

            // Act
            var result = await _practitionerQueryService.GetPractitionerById(practitionersId);

            // Assert
            Assert.NotNull(result);
            Assert.Equal(practitionersId, result.Id);
        }

        [Fact]
        public async Task GetPractitionerById_PractitionersNotFound_ReturnsNull()
        {
            //Arrange
            var practitionersId = 1;

            _readOnlyDbContextMock.Setup(db => db.Practitioners.FindAsync(practitionersId))
                .ReturnsAsync((Domain.V1.Entities.Practitioners.Practitioner?)null);

            //Act
            var result = await _practitionerQueryService.GetPractitionerById(practitionersId);

            //Assert
            Assert.Null(result);
        }

        [Fact]
        public async Task GetPractitionerById_PractitionersExists_BindingError_ReturnsNull()
        {
            // Arrange
            var practitionersId = 1;
            var practitioners = new Domain.V1.Entities.Practitioners.Practitioner
            {
                Id = practitionersId,
                ResourceID = "1",
                Status = true,
                CreatedBy = "Admin",
                IsDeleted = false,
                CreatedDate = DateTime.UtcNow,
            };

            _readOnlyDbContextMock.Setup(db => db.Practitioners.FindAsync(practitionersId))
                .ReturnsAsync(practitioners);

            _mapperMock.Setup(m => m.Map<GetPractitionerDetailDto>(practitioners))
                .Throws(new AutoMapperMappingException("Error mapping entity to DTO"));

            // Act & Assert
            var exception = await Assert.ThrowsAsync<AutoMapperMappingException>(
                () => _practitionerQueryService.GetPractitionerById(practitionersId)
            );

            Assert.Equal("Error mapping entity to DTO", exception.Message);
        }

        [Fact]
        public async Task FindPractitionerById_PractitionersExists_ReturnsPractitioners()
        {
            // Arrange
            var practitionersId = 1;
            var practitioners = new Domain.V1.Entities.Practitioners.Practitioner
            {
                Id = practitionersId,
                ResourceID = "1",
                Status = true,
                CreatedBy = "Admin",
                IsDeleted = false,
                CreatedDate = DateTime.UtcNow,
            };

            // Mock the FindAsync method to return the practitioners
            _readOnlyDbContextMock.Setup(db => db.Practitioners.FindAsync(practitionersId))
                .ReturnsAsync(practitioners);

            // Act
            var result = await _practitionerQueryService.FindPractitionerById(practitionersId);

            // Assert
            Assert.NotNull(result);
            Assert.Equal(practitionersId, result.Id);
            Assert.Equal("1", result.ResourceID);
        }

        [Fact]
        public async Task FindPractitionerById_PractitionersNotFound_ReturnsNull()
        {
            // Arrange
            var practitionersId = 1;

            // Mock the FindAsync method to return null (practitioners not found)
            _readOnlyDbContextMock.Setup(db => db.Practitioners.FindAsync(practitionersId))
                .ReturnsAsync((Domain.V1.Entities.Practitioners.Practitioner?)null);

            // Act
            var result = await _practitionerQueryService.FindPractitionerById(practitionersId);

            // Assert
            Assert.Null(result);
        }

        [Fact]
        public void GetPractitionerList_ReturnsCorrectPractitionerList()
        {
            // Act
            var result = _practitionerQueryService.GetPractitionerList();

            // Assert
            Assert.NotNull(result);
            Assert.Equal(2, result.Count); // Verifying that 3 items are returned

            // Verifying that the returned items are mapped correctly
            Assert.Contains(result, r => r.Id == 1 && r.ResourceID == "1" && r.Status);
            Assert.Contains(result, r => r.Id == 2 && r.ResourceID == "1" && !r.Status);
        }
        [Fact]
        public async Task GetPractitionerDetail_ReturnsCorrectPractitionerList()
        {
            //Arrange
            DbContextOptions<ReadOnlyDbContext> options = new DbContextOptionsBuilder<ReadOnlyDbContext>()
               .UseInMemoryDatabase(databaseName: "GetPractitionerDetailDBr").Options;

            byte[] concurrencyToken = new byte[8] { byte.MinValue, byte.MinValue, byte.MinValue, byte.MinValue, byte.MinValue, byte.MinValue, byte.MinValue, byte.MaxValue };
            var practitioner = new Practitioner
            {
                Id = 1,
                ResourceID = "123",
                Status = true,
                BirthDate = DateTime.UtcNow,
                Gender = "Male",
                Source = "test",
                IsDeleted = false,
                CreatedBy = "Admin",
                CreatedDate = DateTime.UtcNow,
                UpdatedBy = "Admin",  // Adding the missing property
                UpdatedDate = DateTime.UtcNow,// Assuming UpdatedDate is required as well
                RecordVersion = concurrencyToken
            };

            var practitionerAddress = new PractitionerAddresses()
            {
                PractitionerID = 1,
                City = "test",
                Country = "test",
                District = "test",
                Id = 1,
                Line1 = "test",
                Line2 = "test",
                Line3 = "test",
                Line4 = "test",
                State = "test",
                Type = "test",
                PeriodEnd = DateTime.UtcNow,
                PeriodStart = DateTime.UtcNow,
                PostalCode = "test",
                Status = true,
                Use = "test",
                IsDeleted = false,
                CreatedBy = "Admin",
                CreatedDate = DateTime.UtcNow,
                UpdatedBy = "Admin",  // Adding the missing property
                UpdatedDate = DateTime.UtcNow,// Assuming UpdatedDate is required as well
                RecordVersion = concurrencyToken
            };

            var practitionerName = new PractitionerNames()
            {
                PractitionerID = 1,
                Status = true,
                Use = "test",
                Id = 1,
                PeriodStart = DateTime.UtcNow,
                PeriodEnd = DateTime.UtcNow,
                FamilyName = "test",
                GivenName = "test",
                Language = "test",
                MiddleName = "test",
                Prefix = "test",
                Suffix = "test",
                IsDeleted = false,
                CreatedBy = "Admin",
                CreatedDate = DateTime.UtcNow,
                UpdatedBy = "Admin",  // Adding the missing property
                UpdatedDate = DateTime.UtcNow,// Assuming UpdatedDate is required as well
                RecordVersion = concurrencyToken
            };
            var practitionerIdentifiers = new PractitionerIdentifier()
            {
                PractitionerID = 1,
                Status = true,
                IdentifierUse = "test",
                System = "test",
                Value = "test",
                Id = 1,
                IdentifierType = "test",
                PeriodEnd = DateTime.UtcNow,
                PeriodStart = DateTime.UtcNow,
                IsDeleted = false,
                CreatedBy = "Admin",
                CreatedDate = DateTime.UtcNow,
                UpdatedBy = "Admin",  // Adding the missing property
                UpdatedDate = DateTime.UtcNow,// Assuming UpdatedDate is required as well
                RecordVersion = concurrencyToken
            };
            var practitionerTelecom = new PractitionerTelecom()
            {
                PractitionerID = 1,
                Status = true,
                System = "test",
                Use = "test",
                Value = "test",
                Id = 1,
                PeriodStart = DateTime.UtcNow,
                PeriodEnd = DateTime.UtcNow,
                Rank = 1,
                IsDeleted = false,
                CreatedBy = "Admin",
                CreatedDate = DateTime.UtcNow,
                UpdatedBy = "Admin",  // Adding the missing property
                UpdatedDate = DateTime.UtcNow,// Assuming UpdatedDate is required as well
                RecordVersion = concurrencyToken
            };


            //Arrange
            using ReadOnlyDbContext dbContext = new(options);
            dbContext.Practitioners.Add(practitioner);
            dbContext.PractitionerAddress.Add(practitionerAddress);
            dbContext.PractitionerName.Add(practitionerName);
            dbContext.PractitionerIdentifiers.Add(practitionerIdentifiers);
            dbContext.PractitionerTelecoms.Add(practitionerTelecom);

            await dbContext.SaveChangesAsync();
            var practitionerQueryService = new PractitionerQueryService(dbContext, _mapperMock.Object);


            // Act
            (bool isLoaded, UpdatePractitionerDetailDto result) = await practitionerQueryService.GetPractitionerDetailAsync("123");

            // Assert
            Assert.NotNull(result);

        }

        [Fact]
        public async Task IsPractitionerAlreadyExist_ShouldReturnTrue_WhenPractitionersExists()
        {
            // Arrange
            var practitionersId = 1;
            var practitioners = new Domain.V1.Entities.Practitioners.Practitioner
            {
                Id = practitionersId,
                ResourceID = "1",
                Status = true,
                CreatedBy = "Admin",
                IsDeleted = false,
                CreatedDate = DateTime.UtcNow,
            };

            // Mock the FindAsync method to return the practitioners
            _readOnlyDbContextMock.Setup(db => db.Practitioners.FindAsync(practitionersId))
                .ReturnsAsync(practitioners);

            // Act
            var result = await _practitionerQueryService.IsPractitionerAlreadyExist(practitionersId);

            // Assert
            Assert.True(result.result);
            Assert.Equal(ResponseMessage.STATUS_DATA_FOUND, result.message);
        }

        [Fact]
        public async Task IsPractitionerAlreadyExist_ShouldReturnFalse_WhenPractitionersDoesNotExist()
        {
            // Arrange
            var practitionersId = 3;

            // Act
            var result = await _practitionerQueryService.IsPractitionerAlreadyExist(practitionersId);

            // Assert
            Assert.False(result.result);
            Assert.Equal(ResponseMessage.STATUS_NODATA, result.message);
        }
        [Fact]
        public async Task GetPractiotionerDetails_ReturnsData_WhenPractitionerExists()
        {
            //Arrage
            var dbContextOptions = new DbContextOptionsBuilder<ReadOnlyDbContext>()
               .UseInMemoryDatabase(databaseName: Guid.NewGuid().ToString()) // Unique DB for each test
               .Options;
            var context1 = new ReadOnlyDbContext(dbContextOptions);
            var practitioner = new Practitioner
            {
                Id = 1,
                BirthDate = new DateTime(1980, 1, 1),
                Gender = "male",
                Source = "system",
                ResourceID = "abc-123",
                RecordVersion = new byte[123],
                Status = true,
                IsDeleted = false,
                CreatedBy = "test",
                CreatedDate = DateTime.UtcNow,
                UpdatedBy = "test",
                UpdatedDate = DateTime.UtcNow
            };

            context1.Practitioners.Add(practitioner);

            context1.PractitionerName.Add(new PractitionerNames
            {
                PractitionerID = 1,
                Use = "official",
                FamilyName = "Doe",
                GivenName = "John",
                IsDeleted = false,
                Status = true,
                CreatedBy = "test",
                CreatedDate = DateTime.UtcNow,
                Language = "eng",
                MiddleName = "test",
                Prefix = "dr",
                Suffix = "dr"
            });

            context1.PractitionerTelecoms.Add(new PractitionerTelecom
            {
                PractitionerID = 1,
                System = "phone",
                Use = "work",
                Value = "1234567890",
                IsDeleted = false,
                Status = true,
                CreatedBy = "test",
                CreatedDate = DateTime.UtcNow,

            });

            context1.PractitionerAddress.Add(new PractitionerAddresses
            {
                PractitionerID = 1,
                Use = "home",
                City = "City",
                Country = "Country",
                IsDeleted = false,
                Status = true,
                CreatedBy = "test",
                CreatedDate = DateTime.UtcNow,
                District = "test",
                Line1 = "s",
                Line2 = "sd",
                Line3 = "sd",
                Line4 = "sd",
                PostalCode = "sd",
                State = "sd",
                Type = "sd"
            });

            context1.PractitionerPhoto.Add(new PractitionerPhotos
            {
                PractitionerID = 1,
                URL = "https://image.jpg",
                ContentType = "image/jpeg",
                IsDeleted = false,
                Status = true,
                CreatedBy = "test",
                CreatedDate = DateTime.UtcNow,
                Data = new byte[234],
                Hash = "test",
                Size = "20",
                Title = "sfsdf",
                UpdatedBy = "asda"
                ,
                CreationDate = DateTime.UtcNow
            });

            context1.PractitionerCommunications.Add(new PractitionerCommunication
            {
                PractitionerID = 1,
                Language = "en",
                Preferred = true,
                IsDeleted = false,
                Status = true,
                CreatedBy = "test",
                CreatedDate = DateTime.UtcNow,
            });

            context1.PractitionerIdentifiers.Add(new PractitionerIdentifier
            {
                PractitionerID = 1,
                System = "http://system.com",
                Value = "ID-123",
                IsDeleted = false,
                Status = true,
                CreatedBy = "test",
                CreatedDate = DateTime.UtcNow,
                IdentifierUse = "testuse",
                IdentifierType = "test",
            });

            context1.PractitionerQualifications.Add(new PractitionerQualification
            {
                PractitionerID = 1,
                Qualification = "MBBS",
                IsDeleted = false,
                Status = true,
                CreatedBy = "test",
                CreatedDate = DateTime.UtcNow,
                UpdatedBy = "test",
            });
            string resourceId = "abc-123";
            await context1.SaveChangesAsync();
            var service = new PractitionerQueryService(context1, _mapperMock.Object);
            // Act
            var result = await service.GetPractitionerDetailsFhir(resourceId);

            // Assert
            Assert.NotNull(result);
            Assert.Single(result);
            var dto = result.First();
            Assert.Equal("Doe", dto.name.First().Family);
            Assert.Equal("1234567890", dto.telecom.First().Value);
            Assert.Equal("City", dto.address.First().City);
            Assert.Equal("https://image.jpg", dto.photo.First().URL);
            Assert.Equal("en", dto.communication.First().Language);
            Assert.Equal("ID-123", dto.Identifier.First().Value);
            Assert.Equal("MBBS", dto.qualification.First().Code);
        }

        [Fact]
        public async Task GetDoctorApppointmentByDoctorIdAndLocationId_Should_Return_Data_When_Exists()
        {
            // Arrange
            var options = new DbContextOptionsBuilder<ReadOnlyDbContext>()
              .UseInMemoryDatabase(databaseName: Guid.NewGuid().ToString())
              .Options;
            
            var context = new ReadOnlyDbContext(options);
            var doctorId = "123";
            string locationId = "1";
            SeedTestData(context);
            var service = new PractitionerQueryService(context, _mapperMock.Object);
            // Act
            var result = await service.GetDoctorApppointmentByDoctorIdAndLocationId(doctorId, locationId);

            // Assert
            result.StatusCode.Should().Be(((int)ResponceStatusCode.Success).ToString());
            result.Message.Should().Be(ResponseMessage.STATUS_SUCCESS);
        }

        [Fact]
        public async Task GetDoctorApppointmentByDoctorIdAndLocationId_Should_Return_NoRecordFound_When_No_Data()
        {
            //Arrange
            var options = new DbContextOptionsBuilder<ReadOnlyDbContext>()
              .UseInMemoryDatabase(databaseName: Guid.NewGuid().ToString())
              .Options;

            var context = new ReadOnlyDbContext(options);
            var doctorId = "NotExist";
            string locationId = "2";
            SeedTestData(context);
            var service = new PractitionerQueryService(context, _mapperMock.Object);

            // Act
            var result = await service.GetDoctorApppointmentByDoctorIdAndLocationId(doctorId, locationId);

            // Assert
            result.Should().NotBeNull();
            result.IsSuccess.Should().BeTrue();
            result.HasError.Should().BeFalse();
            result.Result.Should().BeNull();
            result.StatusCode.Should().Be(((int)ResponceStatusCode.NoRecordFound).ToString());
            result.Message.Should().Be(ResponseMessage.STATUS_NODATA);
        }
        private static void SeedTestData(ReadOnlyDbContext context)
        {

            var practitioner = new Practitioner
            {
                Id = 1,
                ResourceID = "123",
                Status = true,
                BirthDate = DateTime.UtcNow,
                Gender = "Male",
                Source = "test",
                IsDeleted = false,
                CreatedBy = "Admin",
                CreatedDate = DateTime.UtcNow,
                UpdatedBy = "Admin",
                UpdatedDate = DateTime.UtcNow,
            };

            var practitionerName = new PractitionerNames()
            {
                PractitionerID = 1,
                Status = true,
                Use = "test",
                Id = 1,
                PeriodStart = DateTime.UtcNow,
                PeriodEnd = DateTime.UtcNow,
                FamilyName = "test",
                GivenName = "test",
                Language = "test",
                MiddleName = "test",
                Prefix = "test",
                Suffix = "test",
                IsDeleted = false,
                CreatedBy = "Admin",
                CreatedDate = DateTime.UtcNow,
                UpdatedBy = "Admin",  // Adding the missing property
                UpdatedDate = DateTime.UtcNow,// Assuming UpdatedDate is required as well
            };
            var practitionerPhoto = new PractitionerPhotos
            {
                PractitionerID = 1,
                URL = "https://image.jpg",
                ContentType = "image/jpeg",
                IsDeleted = false,
                Status = true,
                CreatedBy = "test",
                CreatedDate = DateTime.UtcNow,
                Data = new byte[234],
                Hash = "test",
                Size = "20",
                Title = "sfsdf",
                UpdatedBy = "asda",
            };
            var organization = new Organization
            {
                ResourceID = "123",
                Name = "Clinic A",
                Alias = "CA",
                Type = "Private",
                IsDeleted = false,
                CreatedBy = "test",
                CreatedDate = DateTime.UtcNow,
                Source="test",
                UpdatedBy="Test"
            };
            var locations = new Location
            {
                Id = 1,
                Name = "Main Branch",
                Altitude = 12.3m,
                Latitude = 45.1m,
                Longitude = 22.5m,
                CreatedBy = "test",
                ResourceID = "123",
                Status = true,
                CreatedDate = DateTime.UtcNow,
                UpdatedBy="admin",
                Source="test"
            };
            var locaitonAddresses = new LocationAddress
            {

                Country = "CountryY",
                Use = "work",
                Type = "both",
                CreatedBy = "test",
                IsDeleted = false,
                LocationID = 1,
                Status = true,
                CreatedDate = DateTime.UtcNow,
                UpdatedBy="admin",
                UpdatedDate=DateTime.UtcNow
            };
            context.Practitioners.Add(practitioner);
            context.PractitionerName.Add(practitionerName);
            context.PractitionerPhoto.Add(practitionerPhoto);
            context.Organizations.Add(organization);
            context.Locations.Add(locations);
            context.LocationAddresses.Add(locaitonAddresses);
            context.SaveChanges();
        }
    }
}
