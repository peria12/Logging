﻿using Aurora.AdministrationService.API.Helper;
using Aurora.AdministrationService.API.Models.ResponseModels.Location;
using Aurora.AdministrationService.API.Resources;
using Aurora.AdministrationService.API.Services.Service.Locations;
using Aurora.AdministrationService.CrossCutting.CommonModels;
using Aurora.AdministrationService.Domain.Old.Entities;
using Aurora.AdministrationService.Infrastructure.IRepository;
using Aurora.AdministrationService.Tests.Services.Location;
using AutoMapper;
using FluentAssertions;
using Moq;

namespace Aurora.AdministrationService.Tests.API.Services.Locations
{
    public class LocationServiceTest
    {
        private readonly Mock<IDoctorRepository> _doctorRepository;
        private readonly Mock<ILocationRepository> _locationRepository;
        private readonly Mock<IMapper> _mapper;
        private readonly Mock<IResponseMessageHelper> _responseMessageHelper;
        private readonly LocationService _mockLocationService;

        public LocationServiceTest()
        {
            _doctorRepository = new Mock<IDoctorRepository>();
            _locationRepository = new Mock<ILocationRepository>();
            _mapper = new Mock<IMapper>();
            _responseMessageHelper = new Mock<IResponseMessageHelper>();
            _mockLocationService = new LocationService(
                _doctorRepository.Object,
                _mapper.Object,
                _locationRepository.Object,
                _responseMessageHelper.Object
            );
        }

        [Fact]
        public async Task AddLocation_ShouldAddLocationSuccessfully_AndReturnSuccessResponse()
        {
            // Arrange
            var request = new AdminLocationsRequest
            {
                Name = "Test Location",
                Address = "123 Test St",
                City = "Test City",
                State = "Test State",
                PostalCode = "12345",
                Country = "Test Country",
                PhoneNumber = "123-456-7890",
                Active = true,
                Identifier = "TestIdentifier",
                Status = "Active",
                Description = "Test Description",
                LocationType = "Test Type",
                PhysicalType = "Test Physical Type",
                AddressLine1 = "Test Address Line 1",
                AddressLine2 = "Test Address Line 2",
                Latitude = 12.34,
                Longitude = 56.78,
                Altitude = 9.10,
                ManagingOrganizationId = 1,
                PartOfLocationId = 2,
                Mode = "Test Mode",
                FloorMap = "Test Floor Map"
            };

            var locationId = 1;

            _locationRepository
                .Setup(repo => repo.AddLocationAsync(It.IsAny<AdminLocation>()))
                .ReturnsAsync(locationId);
            
            // Act
            var result = await _mockLocationService.AddLocation(request);

            // Assert
            result.IsSuccess.Should().BeTrue();
            _locationRepository.Verify(repo => repo.AddLocationAsync(It.IsAny<AdminLocation>()), Times.Once);
        }

        [Fact]
        public async Task AddLocation_ShouldReturnInternalServerError_WhenExceptionIsThrown()
        {
            // Arrange
            var request = new AdminLocationsRequest
            {
                Name = "Test Location",
                Address = "123 Test St",
                City = "Test City",
                State = "Test State",
                PostalCode = "12345",
                Country = "Test Country",
                PhoneNumber = "1234567890",
                Active = true
            };

            var internalErrorResponse = new GenericResponse<string>
            {
                HasError = true,
                IsSuccess = false,
                StatusCode = "500",
                Message = "Internal Server Error"
            };

            _locationRepository
                .Setup(repo => repo.AddLocationAsync(It.IsAny<AdminLocation>()))
                .ThrowsAsync(new Exception("Database Error"));

            _responseMessageHelper
                .Setup(helper => helper.GetInternalServerErrorResponseMessage(""))
                .Returns(internalErrorResponse);
            // Act
            var result = await _mockLocationService.AddLocation(request);

            // Assert
            result.Should().BeEquivalentTo(internalErrorResponse);
            _locationRepository.Verify(repo => repo.AddLocationAsync(It.IsAny<AdminLocation>()), Times.Once);
            _responseMessageHelper.Verify(helper => helper.GetInternalServerErrorResponseMessage(""), Times.Once);
        }

        #region GetLocations Test Cases
        [Fact]
        public async Task GetLocations_ShouldReturnLocationsSuccessfully_WhenDataExists()
        {
            // Arrange
            var mockLocations = MockDataLocation.GetAdminLocationsList();
            var mockLocationsDTO = MockDataLocation.GetAdminLocationsListDTO();
            var mockDoctorRepository = new Mock<IDoctorRepository>();
            mockDoctorRepository
                .Setup(repo => repo.GetLocations())
                .ReturnsAsync(mockLocations);

            var mockMapper = new Mock<IMapper>();
            mockMapper
                .Setup(mapper => mapper.Map<List<AdminLocationsDTO>>(mockLocations))
                .Returns(mockLocationsDTO);
            var service = new LocationService(mockDoctorRepository.Object, mockMapper.Object, null!, null!);

            // Act
            var result = await service.GetLocations();

            // Assert
            result.Should().NotBeNull();
            result.HasError.Should().BeFalse();
            result.IsSuccess.Should().BeTrue();
            result.StatusCode.Should().Be("200");
            result.Results.Should().BeEquivalentTo(mockLocationsDTO);
        }

        [Fact]
        public async Task GetLocations_ShouldReturnErrorResponse_WhenExceptionOccurs()
        {
            // Arrange
            var mockDoctorRepository = new Mock<IDoctorRepository>();
            mockDoctorRepository
                .Setup(repo => repo.GetLocations())
                .ThrowsAsync(new Exception("Database error"));

            var mockMapper = new Mock<IMapper>();
            var mockResponseHelper = new Mock<IResponseMessageHelper>();
            var service = new LocationService(mockDoctorRepository.Object, mockMapper.Object, null!, mockResponseHelper.Object);

            // Act
            var result = await service.GetLocations();

            // Assert
            result.Should().NotBeNull();
            result.HasError.Should().BeTrue();
            result.IsSuccess.Should().BeFalse();
            result.StatusCode.Should().Be("500");
            result.Results.Should().BeNull();
            result.Message.Should().Be(Resource.LogMessage);
        }
        #endregion

        #region Update Location Test Cases
        [Fact]
        public async Task UpdateLocation_ShouldReturnSuccessResponse_WhenUpdateIsSuccessful()
        {
            // Arrange
            var request = MockDataLocation.GetAdminLocationsRequest();

            var existingLocation = new AdminLocation
            {
                LocationId = 1,
                Name = "Test Location",
                Address = "123 Test Street",
                City = "Test City",
            };

            var mockLocationRepository = new Mock<ILocationRepository>();
            mockLocationRepository
                .Setup(repo => repo.GetLocationByIdAsync(request.LocationId))
                .ReturnsAsync(existingLocation);
            mockLocationRepository
                .Setup(repo => repo.UpdateLocationAsync(It.IsAny<AdminLocation>()))
                .ReturnsAsync(1);

            var mockMapper = new Mock<IMapper>();
            mockMapper.Setup(mapper => mapper.Map(request, existingLocation));

            var mockResponseHelper = new Mock<IResponseMessageHelper>();
            mockResponseHelper
                .Setup(helper => helper.GetSuccessUpdationResponseMessage(""))
                .Returns(new GenericResponse<string> { HasError = false, IsSuccess = true });
            var service = new LocationService(null!, mockMapper.Object, mockLocationRepository.Object, mockResponseHelper.Object);

            // Act
            var result = await service.UpdateLocation(request);

            // Assert
            result.Should().NotBeNull();
            result!.HasError.Should().BeFalse();
            result.IsSuccess.Should().BeTrue();
            mockLocationRepository.Verify(repo => repo.GetLocationByIdAsync(request.LocationId), Times.Once);
            mockLocationRepository.Verify(repo => repo.UpdateLocationAsync(existingLocation), Times.Once);
        }

        [Fact]
        public async Task UpdateLocation_ShouldReturnInternalServerErrorResponse_WhenExceptionOccurs()
        {
            // Arrange
            var request = MockDataLocation.GetAdminLocationsRequest();

            var mockLocationRepository = new Mock<ILocationRepository>();
            mockLocationRepository
                .Setup(repo => repo.GetLocationByIdAsync(request.LocationId))
                .ThrowsAsync(new Exception("Database Error"));

            var mockResponseHelper = new Mock<IResponseMessageHelper>();
            mockResponseHelper
                .Setup(helper => helper.GetInternalServerErrorResponseMessage(""))
                .Returns(new GenericResponse<string> { HasError = true, IsSuccess = false, Message = "Internal Server Error" });

            var service = new LocationService(null!, null!, mockLocationRepository.Object, mockResponseHelper.Object);

            // Act
            var result = await service.UpdateLocation(request);

            // Assert
            result.Should().NotBeNull();
            result!.HasError.Should().BeTrue();
            result.IsSuccess.Should().BeFalse();
            result.Message.Should().Be("Internal Server Error");
            mockLocationRepository.Verify(repo => repo.GetLocationByIdAsync(request.LocationId), Times.Once);
            mockLocationRepository.Verify(repo => repo.UpdateLocationAsync(It.IsAny<AdminLocation>()), Times.Never);
        }
        #endregion
    }
}
