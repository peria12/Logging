﻿using Aurora.AdministrationService.API.Enum;
using Aurora.AdministrationService.API.Helper;
using Aurora.AdministrationService.API.Models.Dto.Locations;
using Aurora.AdministrationService.API.Models.ResponseModels.Location;
using Aurora.AdministrationService.API.Models.ResponseModels.Locations;
using Aurora.AdministrationService.API.Services.IService.Locations;
using Aurora.AdministrationService.API.Services.Service.Locations;
using Aurora.AdministrationService.CrossCutting.CommonModels;
using Aurora.AdministrationService.CrossCutting.Constants;
using Aurora.AdministrationService.Domain.Entities;
using Aurora.AdministrationService.Domain.V1.Entities.Locations;
using Aurora.AdministrationService.Infrastructure;
using Aurora.AdministrationService.Tests.Services.Location;
using AutoMapper;
using FluentAssertions;
using FluentAssertions.Common;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using Moq;
using System.Threading.Tasks;

namespace Aurora.AdministrationService.Tests.API.Services.Locations
{
    public class LocationQueryServiceTests
    {
        private readonly LocationQueryService _locationQueryService;
        private readonly DbContextOptions<ReadOnlyDbContext> _options;
        private readonly Mock<IMapper> _mapperMock;
        private readonly Mock<IResponseMessageHelper<Location>> _locationResponseMessageHelper;
        private readonly Mock<IResponseMessageHelper<GetLocationTypeDto>> _locationTypeResponseMessageHelper;


        public LocationQueryServiceTests()
        {
            _options = new DbContextOptionsBuilder<ReadOnlyDbContext>()
                .UseInMemoryDatabase(databaseName: Guid.NewGuid().ToString())
                .Options;

            _mapperMock = new Mock<IMapper>();

            var context = new ReadOnlyDbContext(_options);
            context.Locations.AddRange(LocationQueryMockData.GetLocationData());
            context.LocationAddresses.AddRange(LocationQueryMockData.GetLocationAddressesData());
            context.LocationImages.AddRange(LocationQueryMockData.locationImageData());
            context.LocationTelecoms.AddRange(LocationQueryMockData.GetLocationTelecomData());
            context.SaveChanges();

            _locationResponseMessageHelper = new Mock<IResponseMessageHelper<Location>>();
            _locationTypeResponseMessageHelper = new Mock<IResponseMessageHelper<GetLocationTypeDto>>();
            _locationQueryService = new LocationQueryService(context, _mapperMock.Object, _locationResponseMessageHelper.Object, _locationTypeResponseMessageHelper.Object);
        }

        [Fact]
        public async Task IsLocationAlreadyExist_ReturnsTrue_WhenLocationExist()
        {
            // Arrange
            int locationId = 1; // An ID that does not exist in the database

            // Act
            var result = await _locationQueryService.IsLocationAlreadyExist(locationId);

            // Assert
            Assert.True(result.result);
            Assert.Equal(ResponseMessage.STATUS_DATA_FOUND, result.message);
        }

        [Fact]
        public async Task IsLocationAlreadyExist_ReturnsFalse_WhenLocationDoesNotExist()
        {
            // Arrange
            int locationId = 999; // An ID that does not exist in the database

            // Act
            var result = await _locationQueryService.IsLocationAlreadyExist(locationId);

            // Assert
            Assert.False(result.result);
            Assert.Equal(ResponseMessage.STATUS_NODATA, result.message);
        }

        [Fact]
        public async Task GetLocationById_ReturnsLocationDetailDto_WhenLocationExists()
        {
            // Arrange
            long locationId = 1; // Assuming this ID exists in the mock data

            // Mock the IMapper to map the Location entity to GetLocationDetailDto
            _mapperMock.Setup(m => m.Map<GetLocationDetailDto>(It.IsAny<Location>()))
                .Returns((Location location) => new GetLocationDetailDto
                {
                    Id = location.Id,
                    Name = location.Name,
                    Description = location.Description ?? "",
                    Status = location.Status
                });

            // Act
            var result = await _locationQueryService.GetLocationById(locationId);

            // Assert
            result.Should().NotBeNull();
            result.Id.Should().Be(locationId);
            result.Name.Should().NotBeNullOrEmpty(); // Ensure the name is mapped correctly
            result.Description.Should().NotBeNullOrEmpty(); // Ensure the description is mapped correctly
            result.Status.Should().BeTrue(); // Ensure the status is mapped correctly
        }

        [Fact]
        public async Task FindLocationById_ReturnsLocation_WhenLocationExists()
        {
            // Arrange
            int locationId = 1; // An ID that does not exist in the database

            // Act
            var result = await _locationQueryService.FindLocationById(locationId);

            // Assert
            Assert.NotNull(result);
        }

        [Fact]
        public async Task GetLocationList_ReturnsLocationDtos_WhenLocationsExist()
        {
            // Arrange
            _mapperMock.Setup(m => m.Map<GetLocationDto>(It.IsAny<Location>()))
                .Returns((Location location) => new GetLocationDto
                {
                    Id = location.Id,
                    Name = location.Name,
                    Alias = location.Alias,
                    Description = location.Description ?? "",
                    Status = location.Status
                });

            // Act
            var result = await _locationQueryService.GetLocations();

            // Assert
            result.Should().NotBeNull();
            result.Count.Should().NotBe(0); // Ensure the name is mapped correctly
        }

        [Fact]
        public void GetLocationIdByLatLong_ReturnsZero_WhenLocationDoesNotExist()
        {
            // Arrange
            double latitude = 999.9999;  // An unlikely latitude
            double longitude = 999.9999; // An unlikely longitude

            // Act
            var result = _locationQueryService.GetLocationIdByLatLong(latitude, longitude);

            // Assert
            Assert.Equal(0, result); // Assert that the result is 0 (i.e., location not found)
        }

        [Fact]
        public void GetLocationIdByLatLong_ReturnsZero_WhenLatitudeOrLongitudeIsNull()
        {
            // Arrange
            double? latitude = null;  // Latitude is null
            double? longitude = 13.4050; // Valid longitude

            // Act
            var result = _locationQueryService.GetLocationIdByLatLong(latitude, longitude);

            // Assert
            Assert.Equal(0, result); // Assert that the result is 0 (since one of the parameters is null)

            // Arrange for other null combinations
            latitude = 52.5200;
            longitude = null;  // Longitude is null

            // Act
            result = _locationQueryService.GetLocationIdByLatLong(latitude, longitude);

            // Assert
            Assert.Equal(0, result); // Assert that the result is 0
        }

        [Fact]
        public void GetLocationIdByLatLong_ReturnsZero_WhenLocationCoordinatesAreOutsideEpsilonRange()
        {
            // Arrange
            double latitude = 52.5201;  // Slightly different from the actual latitude in the mock data (out of epsilon range)
            double longitude = 13.4051; // Slightly different from the actual longitude in the mock data

            // Act
            var result = _locationQueryService.GetLocationIdByLatLong(latitude, longitude);

            // Assert
            Assert.Equal(0, result); // Assert that no location is found (out of epsilon range)
        }

        [Fact]
        public async Task GetLocationTypeMaster_ReturnsEmptyList_WhenNoLocationTypesExist()
        {
            _locationTypeResponseMessageHelper.Setup(c => c.GetRecordsNotFoundResponseMessage(ResponseMessage.STATUS_NODATA)).Returns(new GenericResponseList<GetLocationTypeDto>()
            {
                HasError = true,
                IsSuccess = false,
                StatusCode = ResponceStatusCode.RecordNotFound.ToString(),
                Message = ResponseMessage.STATUS_NODATA,
                Results = null,
            });
            var result = _locationQueryService.GetLocationTypeMaster();

            Assert.True(result.HasError);
            Assert.False(result.IsSuccess);
            Assert.Equal(ResponceStatusCode.RecordNotFound.ToString(), result.StatusCode);
            Assert.Equal(ResponseMessage.STATUS_NODATA, result.Message);
            Assert.Null(result.Results);
        }

        [Fact]
        public async Task GetLocationTypeMaster_ReturnsListOfLocationTypes_WhenLocationTypesExist()
        {
            // Arrange
            var mockData = new List<LocationType>
            {
                new LocationType
                {
                    Id = 1,
                    LocationID = 5,
                    ServiceDeliveryLocationRoleTypeCode = "Building",
                    Status = true,
                    IsDeleted = false,
                    CreatedBy = "Admin",
                    CreatedDate = DateTime.UtcNow,
                    UpdatedBy = "Admin"
                },
                new LocationType
                {
                    Id = 2,
                    LocationID = 6,
                    ServiceDeliveryLocationRoleTypeCode = "Clinic",
                    Status = true,
                    IsDeleted = false,
                    CreatedBy = "Admin",
                    CreatedDate = DateTime.UtcNow,
                    UpdatedBy = "Admin"
                }
            };

            using (var context = new ReadOnlyDbContext(_options))
            {
                await context.LocationTypes.AddRangeAsync(mockData);
                await context.SaveChangesAsync();
            }

            var mockResponse = new List<GetLocationTypeDto>
            {
                new GetLocationTypeDto { Id = 1, LocationID = 5, Name = "Bukit" },
                new GetLocationTypeDto { Id = 2, LocationID = 6, Name = "Bukit Jail" }
            };

            _locationTypeResponseMessageHelper
                .Setup(c => c.GetSuccessResponseMessage(It.IsAny<List<GetLocationTypeDto>>(),
                    ResponceStatusCode.Success, ResponseMessage.STATUS_DATA_FOUND))
                .Returns(new GenericResponseList<GetLocationTypeDto>
                {
                    HasError = false,
                    IsSuccess = true,
                    StatusCode = ((int)ResponceStatusCode.Success).ToString(),
                    Message = ResponseMessage.STATUS_DATA_FOUND,
                    Results = mockResponse
                });

            // Act
            var result = _locationQueryService.GetLocationTypeMaster(); // Ensure GetLocationTypeMaster is awaited if it's async

            // Assert
            Assert.NotNull(result);
            Assert.False(result.HasError);
            Assert.True(result.IsSuccess);
            Assert.Equal(((int)ResponceStatusCode.Success).ToString(), result.StatusCode);
            //Assert.NotEmpty(result.Results);
        }

        [Fact]
        public async Task GetLocationTypeMaster_ThrowsDatabaseException()
        {
            var mockContext = new Mock<ReadOnlyDbContext>(_options);
            mockContext.Setup(c => c.LocationTypes).Throws(new DbUpdateException("Database operation failed"));

            var service = new LocationQueryService(mockContext.Object, _mapperMock.Object, _locationResponseMessageHelper.Object, _locationTypeResponseMessageHelper.Object);

            var result = service.GetLocationTypeMaster();

            Assert.True(result.HasError);
            Assert.False(result.IsSuccess);
            Assert.Equal(ResponseStatus.STATUS_InternalServerError, result.StatusCode);
            Assert.Contains("Database operation failed", result.Message);
        }

        [Fact]
        public async Task GetLocationTypeMaster_ThrowsInvalidOperationException()
        {
            var mockContext = new Mock<ReadOnlyDbContext>(_options);
            mockContext.Setup(c => c.LocationTypes).Throws(new InvalidOperationException("An unexpected error occurred"));

            var service = new LocationQueryService(mockContext.Object, _mapperMock.Object, _locationResponseMessageHelper.Object, _locationTypeResponseMessageHelper.Object);

            var result = service.GetLocationTypeMaster();

            Assert.True(result.HasError);
            Assert.False(result.IsSuccess);
            Assert.Equal(ResponseStatus.STATUS_InternalServerError, result.StatusCode);
            Assert.Contains("An unexpected error occurred", result.Message);
        }

        [Fact]
        public async Task GetLocationTypeMaster_ThrowsGeneralException()
        {
            var mockContext = new Mock<ReadOnlyDbContext>(_options);
            mockContext.Setup(c => c.LocationTypes).Throws(new Exception("Unexpected error"));

            var service = new LocationQueryService(mockContext.Object, _mapperMock.Object, _locationResponseMessageHelper.Object, _locationTypeResponseMessageHelper.Object);

            var result = service.GetLocationTypeMaster();

            Assert.True(result.HasError);
            Assert.False(result.IsSuccess);
            Assert.Equal(ResponseStatus.STATUS_Problem, result.StatusCode);
            Assert.Contains("An unexpected error occurred", result.Message);
        }

        [Fact]
        public async Task GetLocationParofList_ReturnsEmptyList_WhenNoLocationsExist()
        {
            // Create a new in-memory context with no data inserted (simulating "no data" scenario)
            var emptyOptions = new DbContextOptionsBuilder<ReadOnlyDbContext>()
                                .UseInMemoryDatabase(databaseName: "GetLocationPartof_Empty")  // New DB instance for empty state
                                .Options;

            var emptyContext = new ReadOnlyDbContext(emptyOptions); // New context instance with no data

            var mockMapper = new Mock<IMapper>();
            var service = new LocationQueryService(emptyContext, mockMapper.Object, _locationResponseMessageHelper.Object, _locationTypeResponseMessageHelper.Object);

            var result = service.GetLocationMastersList();

            Assert.False(result.HasError);
            Assert.True(result.IsSuccess);
            Assert.Equal(ResponceStatusCode.RecordNotFound.ToString(), result.StatusCode);
            Assert.Equal(ResponseMessage.STATUS_NODATA, result.Message);
        }

        [Fact]
        public async Task GetLocationParofList_ReturnsListOfLocationPart_WhenLocationsPartofExist()
        {
            var result = _locationQueryService.GetLocationMastersList();
            Assert.False(result.HasError);
            Assert.True(result.IsSuccess);
            Assert.Equal(ResponseStatus.STATUS_SUCCESS, result.StatusCode);
        }

        [Fact]
        public void GetHospitalByLocation_ShouldReturnGroupedHospitals_WhenDataExists()
        {
            // Act
            var result = _locationQueryService.GetHospitalList();

            // Assert
            result.IsSuccess.Should().BeTrue();
            result.Results.Should().NotBeNull();
            result.Results.Should().HaveCount(2);

            var state1Hospitals = result.Results?.FirstOrDefault(h => h.State == "S1")?.Hospitals;
            state1Hospitals.Should().NotBeNull();
            state1Hospitals.Should().HaveCount(1);
            state1Hospitals.Should().Contain(h => h.Name == "CA1");

            var state2Hospitals = result.Results?.FirstOrDefault(h => h.State == "S2")?.Hospitals;
            state2Hospitals.Should().NotBeNull();
            state2Hospitals.Should().HaveCount(2);
            state2Hospitals.Should().Contain(h => h.Name == "CA2");
            state2Hospitals.Should().Contain(h => h.Name == "CA3");

            var hospitalA = state1Hospitals?.FirstOrDefault(h => h.Name == "CA1");
            hospitalA?.ImageUrl.Should().Be("Url1");
            hospitalA?.FloorMapCount.Should().Be(0);

            var hospitalB = state1Hospitals?.FirstOrDefault(h => h.Name == "CA2");
            hospitalB?.ImageUrl.Should().Be(string.Empty);
            hospitalB?.FloorMapCount.Should().BeGreaterThan(0);
        }

        [Fact]
        public void GetHospitalListByDistance_ShouldReturnHospitals_WithCalculatedDistances_WhenDistanceIsNeeded()
        {
            // Arrange
            double currentLatitude = 80.0;
            double currentLongitude = 120.0;

            // Act
            var result = _locationQueryService.GetHospitalListByDistance(currentLatitude, currentLongitude, true);

            // Assert
            result.IsSuccess.Should().BeTrue();
            result.Results.Should().NotBeNull();
            result.Results.Should().HaveCount(2);

            var state1Hospitals = result.Results?.FirstOrDefault(h => h.State == "S1")?.Hospitals;
            state1Hospitals.Should().NotBeNull();
            state1Hospitals.Should().HaveCount(1);
            state1Hospitals.Should().Contain(h => h.Name == "CA1");

            var state2Hospitals = result.Results?.FirstOrDefault(h => h.State == "S2")?.Hospitals;
            state2Hospitals.Should().NotBeNull();
            state2Hospitals.Should().HaveCount(2);
            state2Hospitals.Should().Contain(h => h.Name == "CA2");
            state2Hospitals.Should().Contain(h => h.Name == "CA3");

            // Verify hospital distances are calculated
            var hospitalA = state1Hospitals?.FirstOrDefault(h => h.Name == "CA1");
            hospitalA?.Distance.Should().BeGreaterThan(0);

            var hospitalB = state2Hospitals?.FirstOrDefault(h => h.Name == "CA2");
            hospitalB?.Distance.Should().BeGreaterThan(0);
        }

        [Fact]
        public void GetHospitalListByDistance_ShouldReturnHospitals_WithNoCalculatedDistances_WhenDistanceIsNotNeeded()
        {
            // Arrange
            double currentLatitude = 180.0;
            double currentLongitude = 20.0;

            // Act
            var result = _locationQueryService.GetHospitalListByDistance(currentLatitude, currentLongitude, false);

            // Assert
            result.IsSuccess.Should().BeTrue();
            result.Results.Should().NotBeNull();
            result.Results.Should().HaveCount(2);

            var state1Hospitals = result.Results?.FirstOrDefault(h => h.State == "S1")?.Hospitals;
            state1Hospitals.Should().NotBeNull();
            state1Hospitals.Should().HaveCount(1);
            state1Hospitals.Should().Contain(h => h.Name == "CA1");

            var state2Hospitals = result.Results?.FirstOrDefault(h => h.State == "S2")?.Hospitals;
            state2Hospitals.Should().NotBeNull();
            state2Hospitals.Should().HaveCount(2);
            state2Hospitals.Should().Contain(h => h.Name == "CA2");
            state2Hospitals.Should().Contain(h => h.Name == "CA3");

            // Verify hospital distances are not calculated (should be 0)
            var hospitalA = state1Hospitals?.FirstOrDefault(h => h.Name == "CA1");
            hospitalA?.Distance.Should().Be(0);

            var hospitalB = state2Hospitals?.FirstOrDefault(h => h.Name == "CA2");
            hospitalB?.Distance.Should().Be(0);
        }

        [Fact]
        public void GetHospitalListByDistance_ShouldReturnHospitals_WithNoCalculatedDistances_WhenInvalidCoordinatesAreProvided()
        {
            // Arrange
            double currentLatitude = double.NaN;  // Invalid Latitude
            double currentLongitude = double.NaN; // Invalid Longitude

            // Act
            var result = _locationQueryService.GetHospitalListByDistance(currentLatitude, currentLongitude, true);

            // Assert
            result.IsSuccess.Should().BeTrue();
            result.Results.Should().NotBeNull();
            result.Results.Should().HaveCount(2);

            var state1Hospitals = result.Results?.FirstOrDefault(h => h.State == "S1")?.Hospitals;
            state1Hospitals.Should().NotBeNull();
            state1Hospitals.Should().HaveCount(1);
            state1Hospitals.Should().Contain(h => h.Name == "CA1");

            var state2Hospitals = result.Results?.FirstOrDefault(h => h.State == "S2")?.Hospitals;
            state2Hospitals.Should().NotBeNull();
            state2Hospitals.Should().HaveCount(2);
            state2Hospitals.Should().Contain(h => h.Name == "CA2");
            state2Hospitals.Should().Contain(h => h.Name == "CA3");

            // Verify hospital distances are not calculated (should be 0)
            var hospitalA = state1Hospitals?.FirstOrDefault(h => h.Name == "CA1");
            hospitalA?.Distance.Should().Be(0);

            var hospitalB = state2Hospitals?.FirstOrDefault(h => h.Name == "CA2");
            hospitalB?.Distance.Should().Be(0);
        }

        [Fact]
        public void GetHospitalList_ShouldReturnEmptyGroupedHospitals_WhenNoDataExists()
        {
            // Create a new in-memory context with no data inserted (simulating "no data" scenario)
            var emptyOptions = new DbContextOptionsBuilder<ReadOnlyDbContext>()
                                .UseInMemoryDatabase(databaseName: "LocationQueryServiceTestDB1_Empty")  // New DB instance for empty state
                                .Options;

            var emptyContext = new ReadOnlyDbContext(emptyOptions); // New context instance with no data
            var mockMapper = new Mock<IMapper>();
            var service = new LocationQueryService(emptyContext, mockMapper.Object, _locationResponseMessageHelper.Object, _locationTypeResponseMessageHelper.Object);

            // Act
            var result = service.GetHospitalList();

            // Assert
            result.IsSuccess.Should().BeTrue();
            result.HasError.Should().BeFalse();
            result.Results.Should().NotBeNull();
            result.Results.Should().HaveCount(0);  // Expecting empty result set
            result.Message.Should().Be(ResponseMessage.STATUS_NODATA); // Ensure no data message is returned
        }

        [Fact]
        public void GetHospitalListByDistance_ShouldReturnEmptyGroupedHospitals_WhenNoDataExists()
        {
            // Arrange
            double currentLatitude = 80.0;
            double currentLongitude = 120.0;

            // Create a new in-memory context with no data inserted (simulating "no data" scenario)
            var emptyOptions = new DbContextOptionsBuilder<ReadOnlyDbContext>()
                                .UseInMemoryDatabase(databaseName: "LocationQueryServiceTestDB2_Empty")  // New DB instance for empty state
                                .Options;

            var emptyContext = new ReadOnlyDbContext(emptyOptions); // New context instance with no data

            var mockMapper = new Mock<IMapper>();
            var service = new LocationQueryService(emptyContext, mockMapper.Object, _locationResponseMessageHelper.Object, _locationTypeResponseMessageHelper.Object);

            // Act
            var result = service.GetHospitalListByDistance(currentLatitude, currentLongitude, true);

            // Assert
            result.IsSuccess.Should().BeTrue();
            result.HasError.Should().BeFalse();
            result.Results.Should().NotBeNull();
            result.Results.Should().HaveCount(0);  // Expecting empty result set
            result.Message.Should().Be(ResponseMessage.STATUS_NODATA); // Ensure no data message is returned
        }

        #region GetLocationDetailById Service Test Cases
        [Fact]
        public async Task LocationDetailById_ReturnsLLocation_WhenLocationExists()
        {
            using (var context = new ReadOnlyDbContext(_options))
            {
                context.Locations.AddRange(
                    new Location
                    {
                        Id = 10,
                        ResourceID = "RES001",
                        Status = true,
                        OperationalStatus = "Active",
                        Name = "Hospital A",
                        Alias = "HospA",
                        Description = "Main hospital in city center",
                        Mode = "Online",
                        Longitude = 123.45M,
                        Latitude = -45.67M,
                        Altitude = 500M,
                        PhysicalType = "Building",
                        ManagingOrganization = Guid.NewGuid(),
                        PartOf = "Health System A",
                        AvailabilityExceptions = "None",
                        Source = "System",
                        URL = "https://hospitala.com",
                        RecordVersion = Array.Empty<byte>(),
                        IsDeleted = false,
                        CreatedBy = "Admin",
                        CreatedDate = DateTime.UtcNow,
                        UpdatedBy = "Admin",
                        UpdatedDate = DateTime.UtcNow
                    }
                );
            }

            var mockData = new Location { Id = 1, CreatedBy = "admin", CreatedDate = DateTime.Now, IsDeleted = false, ResourceID = "234", Name = "bukit", Status = true };
            _locationResponseMessageHelper
               .Setup(c => c.GetRecordDetailSuccessResponseMessage(It.IsAny<Location>(),
                   ResponceStatusCode.Success, ResponseMessage.STATUS_DATA_FOUND))
               .Returns(new GenericResponse<Location>
               {
                   HasError = false,
                   IsSuccess = true,
                   StatusCode = ((int)ResponceStatusCode.Success).ToString(),
                   Message = ResponseMessage.STATUS_DATA_FOUND,
                   Result = mockData
               });

            var result = await _locationQueryService.LocationDetailById(1);

            Assert.False(result.HasError);
            Assert.True(result.IsSuccess);
            Assert.Equal(ResponseStatus.STATUS_SUCCESS, result.StatusCode);
            Assert.NotNull(result.Result);
        }

        [Fact]
        public async Task LocationDetailById_ReturnsNull_WhenNoLocationExist()
        {
            _locationResponseMessageHelper.Setup(c => c.GetRecordFailureStatusResponseMessage(null, ResponceStatusCode.NotFound, ResponseMessage.STATUS_NODATA)).Returns(new GenericResponse<Location>()
            {
                HasError = true,
                IsSuccess = false,
                StatusCode = ResponceStatusCode.RecordNotFound.ToString(),
                Message = ResponseMessage.STATUS_NODATA,
                Result = null,
            });
            var result = await _locationQueryService.LocationDetailById(0);

            Assert.True(result.HasError);
            Assert.False(result.IsSuccess);
            Assert.Equal(ResponceStatusCode.RecordNotFound.ToString(), result.StatusCode);
            Assert.Equal(ResponseMessage.STATUS_NODATA, result.Message);
            Assert.Null(result.Result);
        }
        #endregion

        [Fact]
        public async Task GetLocationSearchList_ReturnsEmptyList_WhenNoLocationsExist()
        {
            LocationSearchRequest searchRequest = new LocationSearchRequest("Test", "1", "Active");
            var result = await _locationQueryService.GetLocationSearch(searchRequest);
            Assert.Empty(result);
        }

        [Fact]
        public async Task GetLocationSearchInActiveList_ReturnsEmptyList_WhenNoLocationsExist()
        {
            LocationSearchRequest searchRequest = new LocationSearchRequest("Test", "1", "InActive");
            var result = await _locationQueryService.GetLocationSearch(searchRequest);
            Assert.Empty(result);
        }

        [Fact]
        public async Task GetLocationSearchActiveList_ReturnsEmptyList_WhenNoLocationsExist()
        {
            LocationSearchRequest searchRequest = new LocationSearchRequest() { SelectedLocationId = string.Empty, SelectedLocationName = string.Empty, SelectedStatus = string.Empty };
            searchRequest.PageNumber = 1;
            searchRequest.PageSize = 10;
            var result = await _locationQueryService.GetLocationSearch(searchRequest);
            Assert.True(result.Count > 0);
        }

        [Fact]
        public async Task GetNearByOrganizationsAsync_ShouldReturn_NearestAndFarbyContacts()
        {
            // Arrange Latitude = 81.02M, Longitude = 119.22M,
            var latitude = 81.02;
            var longitude = 119.22;

            // Act
            var result = await _locationQueryService.GetNearByOrganizationsAsync(latitude, longitude);

            // Assert
            Assert.NotNull(result);
            Assert.True(result.IsSuccess);
            Assert.NotNull(result.Result);
            Assert.NotEmpty(result.Result.NearestContacts);

            // Verify nearest and far locations
            Assert.Contains(result.Result.NearestContacts, n => n.LocationId == 1);
        }

        [Fact]
        public async Task GetNearByOrganizationsAsync_ShouldReturn_Empty_WhenNoLocationsExist()
        {
            // Arrange
            var latitude = 40.7128;
            var longitude = -74.0060;

            // Act
            var result = await _locationQueryService.GetNearByOrganizationsAsync(latitude, longitude);

            // Assert
            Assert.NotNull(result);
            Assert.True(result.IsSuccess);
            Assert.NotNull(result.Result);
            Assert.Empty(result.Result.NearestContacts);
        }

        #region Get All Location Details
        [Fact]
        public async Task GetLocationDetailsByResourceId_ShouldReturnEmpty_WhenResourceNotExists()
        {
            // Arrange
            var resourceId = "KLAN";

            // Act
            var result = await _locationQueryService.GetLocationDetailsByResourceId(resourceId);

            // Assert
            result.Should().NotBeNull();
            result.Results.Should().BeEmpty();
            result.StatusCode.Should().Be(ResponceStatusCode.RecordNotFound.ToString());
            result.Message.Should().Be(ResponseMessage.STATUS_NODATA);
            result.HasError.Should().BeFalse();
            result.IsSuccess.Should().BeTrue();
        }

        [Fact]
        public async Task GetLocationDetailsByResourceId_ShouldReturnSuccessResponse_WhenLocationExists()
        {
            // Arrange
            var mockRepo = new Mock<ILocationQueryService>();
            var mockResourceId = "KLAN";
            var expectedResult = MockDataLocation.GetAdminLocationsListDTO()
                                                  .Where(x => x.ResourceId == mockResourceId)
                                                  .ToList();

            mockRepo.Setup(service => service.GetLocationDetailsByResourceId(mockResourceId))
                    .ReturnsAsync(new GenericResponseList<AdminLocationsDTO>
                    {
                        HasError = false,
                        IsSuccess = true,
                        StatusCode = ResponseStatus.STATUS_SUCCESS.ToString(),
                        Message = ResponseMessage.STATUS_SUCCESS,
                        Results = expectedResult
                    });

            var service = mockRepo.Object;

            // Act
            var result = await service.GetLocationDetailsByResourceId(mockResourceId);

            // Assert
            result.Should().NotBeNull();
            result.StatusCode.Should().Be(ResponseStatus.STATUS_SUCCESS.ToString());
            result.Results.Should().NotBeNullOrEmpty();
            result.Results.All(x => x.ResourceId == mockResourceId).Should().BeTrue();
        }
        [Fact]
        public async Task GetLocationDetailsByResourceId_ShouldReturnSuccessResponse_WhenMatchingLocationExistsInDb()
        {
            // Arrange
            var existingResourceId = LocationQueryMockData.GetLocationData().First().ResourceID;

            // Act
            var result = await _locationQueryService.GetLocationDetailsByResourceId(existingResourceId);

            // Assert
            result.Should().NotBeNull();
            result.IsSuccess.Should().BeTrue();
            result.HasError.Should().BeFalse();
            result.StatusCode.Should().Be(ResponseStatus.STATUS_SUCCESS);
            result.Message.Should().Be(ResponseMessage.STATUS_SUCCESS);

            result.Results.Should().NotBeNullOrEmpty();

            var first = result.Results.First();
            first.ResourceId.Should().Be(existingResourceId);
            first.Status.Should().NotBeNullOrEmpty();
            first.Active.Should().BeTrue();
            first.FloorMap.Should().NotBeNull();
            first.PhoneNumber.Should().NotBeNull();
            first.City.Should().NotBeNull();
        }

        #endregion

        #region Search Location By State and Facility 

        [Fact]
        public void SearchHospitals_ShouldReturnGroupedHospitals_WhenNoFiltersApplied()
        {
            // Arrange
            var options = new DbContextOptionsBuilder<ReadOnlyDbContext>()
                .UseInMemoryDatabase(databaseName: "HospitalDb_NoFilters")
                .EnableSensitiveDataLogging()
                .Options;

            using var context = new ReadOnlyDbContext(options);

            context.Locations.AddRange(
                new Location { Id = 1, Name = "City Hospital", URL = "url1", Latitude = 22.3m, Longitude = 72.6m, ResourceID = "001", Status = false, CreatedBy = "Admin", CreatedDate = DateTime.UtcNow, UpdatedBy = "Admin", UpdatedDate = DateTime.UtcNow },
                new Location { Id = 2, Name = "Care Hospital", URL = "url2", Latitude = 23.4m, Longitude = 73.7m, ResourceID = "002", Status = false, CreatedBy = "Admin", CreatedDate = DateTime.UtcNow, UpdatedBy = "Admin", UpdatedDate = DateTime.UtcNow }
            );

            context.LocationAddresses.AddRange(
                new LocationAddress { Id = 1, LocationID = 1, City = "Ahmedabad", State = "Gujarat", Use = "09870", Status = false, IsDeleted = false, CreatedBy = "Admin", CreatedDate = DateTime.UtcNow, UpdatedBy = "Admin", UpdatedDate = DateTime.UtcNow },
                new LocationAddress { Id = 2, LocationID = 2, City = "Baroda", State = "Gujarat", Use = "09970", Status = false, IsDeleted = false, CreatedBy = "Admin", CreatedDate = DateTime.UtcNow, UpdatedBy = "Admin", UpdatedDate = DateTime.UtcNow }
            );

            context.LocationTelecoms.AddRange(
                new LocationTelecom { Id = 1, LocationID = 1, Use = "123456", Value = "test", System = "test", IsDeleted = false, CreatedBy = "Admin", CreatedDate = DateTime.UtcNow, UpdatedBy = "Admin", UpdatedDate = DateTime.UtcNow },
                new LocationTelecom { Id = 2, LocationID = 2, Use = "987654", Value = "test", System = "test", IsDeleted = false, CreatedBy = "Admin", CreatedDate = DateTime.UtcNow, UpdatedBy = "Admin", UpdatedDate = DateTime.UtcNow }
            );

            context.LocationImages.AddRange(
                new LocationImage { Id = 1, LocationID = 1, URL = "main1.png", Category = "Main", IsDeleted = false, CreatedBy = "Admin", CreatedDate = DateTime.UtcNow, UpdatedBy = "Admin", UpdatedDate = DateTime.UtcNow },
                new LocationImage { Id = 2, LocationID = 1, URL = "floor1.png", Category = "Floor", IsDeleted = false, CreatedBy = "Admin", CreatedDate = DateTime.UtcNow, UpdatedBy = "Admin", UpdatedDate = DateTime.UtcNow },
                new LocationImage { Id = 3, LocationID = 2, URL = "main2.png", Category = "Main", IsDeleted = false, CreatedBy = "Admin", CreatedDate = DateTime.UtcNow, UpdatedBy = "Admin", UpdatedDate = DateTime.UtcNow }
            );

            context.SaveChanges();

            var mapperMock = new Mock<IMapper>();
            var locationResponseMessageHelperMock = new Mock<IResponseMessageHelper<Location>>();
            var locationTypeResponseMessageHelperMock = new Mock<IResponseMessageHelper<GetLocationTypeDto>>();

            var locationQueryService = new LocationQueryService(
                context,
                mapperMock.Object,
                locationResponseMessageHelperMock.Object,
                locationTypeResponseMessageHelperMock.Object
            );

            // Act
            var result = locationQueryService.SearchHospitals(null);

            // Assert
            result.Should().NotBeNull();


            var stateGroup = result.First();
            stateGroup.State.Should().Be("Gujarat");
            stateGroup.Hospitals.Should().HaveCount(2);

            var cityHospital = stateGroup.Hospitals.FirstOrDefault(h => h.Name == "City Hospital");
            cityHospital.Should().NotBeNull();
            cityHospital.ImageUrl.Should().Be("main1.png");
            cityHospital.FloorMapCount.Should().Be(1);

            var careHospital = stateGroup.Hospitals.FirstOrDefault(h => h.Name == "Care Hospital");
            careHospital.Should().NotBeNull();
            careHospital.ImageUrl.Should().Be("main2.png");
            careHospital.FloorMapCount.Should().Be(0);
        }

        [Fact]
        public void SearchHospitals_ShouldFilterHospitals_WhenSearchApplied()
        {
            // Arrange
            var options = new DbContextOptionsBuilder<ReadOnlyDbContext>()
                .UseInMemoryDatabase(databaseName: "HospitalDb_SearchFilter")
                .EnableSensitiveDataLogging()
                .Options;

            using var context = new ReadOnlyDbContext(options);

            context.Locations.Add(
                new Location { Id = 1, Name = "City Hospital", URL = "url1", Latitude = 22.3m, Longitude = 72.6m, ResourceID = "001", Status = false, CreatedBy = "Admin", CreatedDate = DateTime.UtcNow, UpdatedBy = "Admin", UpdatedDate = DateTime.UtcNow }
            );
            context.LocationAddresses.Add(
                new LocationAddress { Id = 1, LocationID = 1, City = "Ahmedabad", State = "Gujarat", Use = "09870", Status = false, IsDeleted = false, CreatedBy = "Admin", CreatedDate = DateTime.UtcNow, UpdatedBy = "Admin", UpdatedDate = DateTime.UtcNow }
            );
            context.LocationTelecoms.Add(
                new LocationTelecom { Id = 1, LocationID = 1, Use = "123456", Value = "test", System = "test", IsDeleted = false, CreatedBy = "Admin", CreatedDate = DateTime.UtcNow, UpdatedBy = "Admin", UpdatedDate = DateTime.UtcNow }
            );
            context.LocationImages.Add(
                new LocationImage { Id = 1, LocationID = 1, URL = "main1.png", Category = "Main", IsDeleted = false, CreatedBy = "Admin", CreatedDate = DateTime.UtcNow, UpdatedBy = "Admin", UpdatedDate = DateTime.UtcNow }
            );

            context.SaveChanges();

            var mapperMock = new Mock<IMapper>();
            var locationResponseMessageHelperMock = new Mock<IResponseMessageHelper<Location>>();
            var locationTypeResponseMessageHelperMock = new Mock<IResponseMessageHelper<GetLocationTypeDto>>();

            var locationQueryService = new LocationQueryService(
                context,
                mapperMock.Object,
                locationResponseMessageHelperMock.Object,
                locationTypeResponseMessageHelperMock.Object
            );

            // Act
            var result = locationQueryService.SearchHospitals("Gujarat");

            // Assert
            result.Should().NotBeNull();


            var stateGroup = result.First();
            stateGroup.State.Should().Be("Gujarat");
            stateGroup.Hospitals.Should().HaveCount(1);

            var hospital = stateGroup.Hospitals.First();
            hospital.Name.Should().Be("City Hospital");
        }


        #endregion
    }
}
