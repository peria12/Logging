﻿using Aurora.AdministrationService.API.Services.Service.Locations;
using Aurora.AdministrationService.Domain.V1.Entities.Locations;
using Aurora.AdministrationService.Infrastructure;
using AutoMapper;
using FluentAssertions.Common;
using Moq;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Aurora.AdministrationService.Tests.API.Services.Locations
{
    public static class LocationQueryMockData
    {
        public static List<Location> GetLocationData() => new List<Location>
            {
                new Location {Id = 1, ResourceID = "21cbd134-83bc-4820-aa75-1526d1609c16", Name = "CA1", Status = true, Alias = "CA1", Altitude = 10, AvailabilityExceptions = "A1", Description = "D1", Latitude = 81.02M, Longitude = 119.22M, Mode = "M1", OperationalStatus = "true", PartOf = "P1", PhysicalType = "P1", Source = "S1", URL = "Ur11", IsDeleted = false, CreatedBy = "1", CreatedDate = DateTime.Now, UpdatedBy = "1", UpdatedDate = DateTime.Now},
                new Location {Id = 2, ResourceID = "5918e073-e4a5-4857-b039-fe2bf380219b", Name = "CA2", Status = true, Alias = "CA1", Altitude = 10, AvailabilityExceptions = "A1", Description = "D1", Latitude = 81.02M, Longitude = 119.22M, Mode = "M1", OperationalStatus = "true", PartOf = "P1", PhysicalType = "P1", Source = "S1", URL = "Ur11", IsDeleted = false, CreatedBy = "1", CreatedDate = DateTime.Now, UpdatedBy = "1", UpdatedDate = DateTime.Now},
                new Location {Id = 3, ResourceID = "3d854f80-4606-440b-9d9d-6c103a3fde4b", Name = "CA3", Status = true, Alias = "CA1", Altitude = 10, AvailabilityExceptions = "A1", Description = "D1", Latitude = 81.02M, Longitude = 119.22M, Mode = "M1", OperationalStatus = "true", PartOf = "P1", PhysicalType = "P1", Source = "S1", URL = "Ur11", IsDeleted = false, CreatedBy = "1", CreatedDate = DateTime.Now, UpdatedBy = "1", UpdatedDate = DateTime.Now},
            };

        public static List<LocationAddress> GetLocationAddressesData() => new List<LocationAddress>
            {
                new LocationAddress { Id = 1,  LocationID = 1, City = "C1", Country = "CO1", State = "S1", Use = "Use1", District = "D1", Type = "T1", Line1 = "L1", Line2 = "L2", Line3 = "L3", Line4 = "L4", PostalCode = "420202", PeriodStart = DateTime.Now, PeriodEnd = DateTime.Now, Status = true, IsDeleted = false, CreatedBy = "1", CreatedDate = DateTime.Now, UpdatedBy = "1", UpdatedDate = DateTime.Now},
                new LocationAddress { Id = 2,  LocationID = 2, City = "C2", Country = "CO1", State = "S2", Use = "Use2", District = "D1", Type = "T1", Line1 = "L1", Line2 = "L2", Line3 = "L3", Line4 = "L4", PostalCode = "420202", PeriodStart = DateTime.Now, PeriodEnd = DateTime.Now, Status = true, IsDeleted = false, CreatedBy = "1", CreatedDate = DateTime.Now, UpdatedBy = "1", UpdatedDate = DateTime.Now},
                new LocationAddress { Id = 3,  LocationID = 3, City = "C3", Country = "CO2", State = "S2", Use = "Use3", District = "D1", Type = "T1", Line1 = "L1", Line2 = "L2", Line3 = "L3", Line4 = "L4", PostalCode = "420202", PeriodStart = DateTime.Now, PeriodEnd = DateTime.Now, Status = true, IsDeleted = false, CreatedBy = "1", CreatedDate = DateTime.Now, UpdatedBy = "1", UpdatedDate = DateTime.Now},
            };

        public static List<LocationTelecom> GetLocationTelecomData() => new List<LocationTelecom>
            {
                new LocationTelecom { Id = 1, LocationID = 1, System = "1234567890", Use = "1234567890", Value = "1234567890", IsDeleted = false, CreatedBy = "1", CreatedDate = DateTime.Now, UpdatedBy = "1", UpdatedDate = DateTime.Now },
                new LocationTelecom { Id = 2, LocationID = 2, System = "2345678901", Use = "2345678901", Value = "4567890123", IsDeleted = false, CreatedBy = "1", CreatedDate = DateTime.Now, UpdatedBy = "1", UpdatedDate = DateTime.Now },
                new LocationTelecom { Id = 3, LocationID = 3, System = "3456789021", Use = "3456789012", Value = "4567890123", IsDeleted = false, CreatedBy = "1", CreatedDate = DateTime.Now, UpdatedBy = "1", UpdatedDate = DateTime.Now },

            };

        public static List<LocationImage> locationImageData() => new List<LocationImage>
            {
                new LocationImage { Id = 1, LocationID = 1, BuildingName = "B1", FloorName = "F1", Category = "Main", URL = "Url1", IsDeleted = false, CreatedBy = "1", CreatedDate = DateTime.Now, UpdatedBy = "1", UpdatedDate = DateTime.Now},
                new LocationImage { Id = 2, LocationID = 2, BuildingName = "B2", FloorName = "F2", Category = "FloorMap", URL = "Url2", IsDeleted = false, CreatedBy = "1", CreatedDate = DateTime.Now, UpdatedBy = "1", UpdatedDate = DateTime.Now},
                new LocationImage { Id = 3, LocationID = 3, BuildingName = "B2", FloorName = "F2", Category = "FloorMap", URL = "Url2", IsDeleted = false, CreatedBy = "1", CreatedDate = DateTime.Now, UpdatedBy = "1", UpdatedDate = DateTime.Now},

            };
    }
}
