﻿using Aurora.AdministrationService.API.Models.ResponseModels.Doctors;
using Aurora.AdministrationService.API.Models.ResponseModels.Location;
using Aurora.AdministrationService.Domain.Entities;
using Aurora.AdministrationService.Domain.Old.Entities;

namespace Aurora.AdministrationService.Tests.Services.Location;

/// <summary>
/// Mock data for testing Location-related services and controllers.
/// </summary>
/// <remarks>
/// Mock data includes data for AdminLocationsDTO and related entities.
/// </remarks>
public static class MockDataLocation
{
    public static AdminLocation GetAdminLocations()
    {
        return new AdminLocation
        {
            LocationId = 1,
            Name = "Test Location",
            Address = "123 Test Street",
            City = "Test City",
            State = "Test State",
            PostalCode = "12345",
            Country = "Test Country",
            PhoneNumber = "1234567890",
            Active = true,
            DateCreated = DateTime.UtcNow,
            CreatedBy = 1,
            LastModifiedBy = 2,
            LastModifiedDate = DateTime.UtcNow,
            Identifier = "LOC-001",
            Status = "Active",
            Description = "Test Description",
            LocationType = "Clinic",
            PhysicalType = "Building",
            AddressLine1 = "123 Test Street",
            AddressLine2 = "Suite 456",
            Latitude = 40.7128,
            Longitude = -74.0060,
            Altitude = 10,
            ManagingOrganizationId = 100,
            PartOfLocationId = null,
            Mode = "Online",
            FloorMap = "Test Floor Map",
            CreatedAt = DateTime.UtcNow.AddMonths(-1),
            UpdatedAt = DateTime.UtcNow,
            AdminDoctorLocations = new List<AdminDoctorLocation>(),
            CreatedByNavigation = new AdminUser (),
            InversePartOfLocation = new List<AdminLocation>(),
            LastModifiedByNavigation = new AdminUser (),
            PartOfLocation = null
        };
    }
    public static AdminLocationsDTO GetAdminLocationsDTO()
    {
        return new AdminLocationsDTO
        {
            LocationId = 1,
            ResourceId = "KLAN",
            Name = "Test Location",
            Address = "123 Test Street",
            City = "Test City",
            State = "Test State",
            PostalCode = "12345",
            Country = "Test Country",
            PhoneNumber = "1234567890",
            Active = true,
            DateCreated = DateTime.UtcNow,
            CreatedBy = "Admin",
            LastModifiedBy = 2,
            LastModifiedDate = DateTime.UtcNow,
            Identifier = "LOC-001",
            Status = "Active",
            Description = "Test Description",
            LocationType = "Clinic",
            PhysicalType = "Building",
            AddressLine1 = "123 Test Street",
            AddressLine2 = "Suite 456",
            Latitude = 40.7128,
            Longitude = -74.0060,
            Altitude = 10,
            ManagingOrganizationId = 100,
            PartOfLocationId = null,
            Mode = "Online",
            FloorMap = "Test Floor Map",
            CreatedAt = DateTime.UtcNow.AddMonths(-1),
            UpdatedAt = DateTime.UtcNow,
            AdminDoctorLocations = new List<AdminDoctorLocationDTO>(),
            CreatedByNavigation = new AdminUserDTO(),
            InversePartOfLocation = new List<AdminLocationsDTO>(),
            LastModifiedByNavigation = new AdminUserDTO(),
            PartOfLocation = null
        };
    }

    public static List<AdminLocation> GetAdminLocationsList()
    {
        return new List<AdminLocation>
        {
            new AdminLocation
            {
                 LocationId = 1,
            Name = "Test Location",
            Address = "123 Test Street",
            City = "Test City",
            State = "Test State",
            PostalCode = "12345",
            Country = "Test Country",
            PhoneNumber = "1234567890",
            Active = true,
            DateCreated = DateTime.UtcNow,
            CreatedBy = 1,
            LastModifiedBy = 2,
            LastModifiedDate = DateTime.UtcNow,
            Identifier = "LOC-001",
            Status = "Active",
            Description = "Test Description",
            LocationType = "Clinic",
            PhysicalType = "Building",
            AddressLine1 = "123 Test Street",
            AddressLine2 = "Suite 456",
            Latitude = 40.7128,
            Longitude = -74.0060,
            Altitude = 10,
            ManagingOrganizationId = 100,
            PartOfLocationId = null,
            Mode = "Online",
            FloorMap = "Test Floor Map",
            CreatedAt = DateTime.UtcNow.AddMonths(-1),
            UpdatedAt = DateTime.UtcNow,
            AdminDoctorLocations = new List<AdminDoctorLocation>(),
            CreatedByNavigation = new AdminUser (),
            InversePartOfLocation = new List<AdminLocation>(),
            LastModifiedByNavigation = new AdminUser (),      
            PartOfLocation = null
            },
            new AdminLocation
            {
                 LocationId = 2,
            Name = "Test Location",
            Address = "123 Test Street",
            City = "Test City",
            State = "Test State",
            PostalCode = "12345",
            Country = "Test Country",
            PhoneNumber = "1234567890",
            Active = true,
            DateCreated = DateTime.UtcNow,
            CreatedBy = 1,
            LastModifiedBy = 2,
            LastModifiedDate = DateTime.UtcNow,
            Identifier = "LOC-001",
            Status = "Active",
            Description = "Test Description",
            LocationType = "Clinic",
            PhysicalType = "Building",
            AddressLine1 = "123 Test Street",
            AddressLine2 = "Suite 456",
            Latitude = 40.7128,
            Longitude = -74.0060,
            Altitude = 10,
            ManagingOrganizationId = 100,
            PartOfLocationId = null,
            Mode = "Online",
            FloorMap = "Test Floor Map",
            CreatedAt = DateTime.UtcNow.AddMonths(-1),
            UpdatedAt = DateTime.UtcNow,
            AdminDoctorLocations = new List<AdminDoctorLocation>(),
            CreatedByNavigation = new AdminUser (),
            InversePartOfLocation = new List<AdminLocation>(),
            LastModifiedByNavigation = new AdminUser (),
            PartOfLocation = null
            }
        };
    }

    public static List<AdminLocationsDTO> GetAdminLocationsListDTO()
    {
        return new List<AdminLocationsDTO>
        {
            new AdminLocationsDTO
            {
            LocationId = 1,
            ResourceId = "KLAN",
            Name = "Test Location",
            Address = "123 Test Street",
            City = "Test City",
            State = "Test State",
            PostalCode = "12345",
            Country = "Test Country",
            PhoneNumber = "1234567890",
            Active = true,
            DateCreated = DateTime.UtcNow,
            CreatedBy = "Admin",
            LastModifiedBy = 2,
            LastModifiedDate = DateTime.UtcNow,
            Identifier = "LOC-001",
            Status = "Active",
            Description = "Test Description",
            LocationType = "Clinic",
            PhysicalType = "Building",
            AddressLine1 = "123 Test Street",
            AddressLine2 = "Suite 456",
            Latitude = 40.7128,
            Longitude = -74.0060,
            Altitude = 10,
            ManagingOrganizationId = 100,
            PartOfLocationId = null,
            Mode = "Online",
            FloorMap = "Test Floor Map",
            CreatedAt = DateTime.UtcNow.AddMonths(-1),
            UpdatedAt = DateTime.UtcNow,
            AdminDoctorLocations = new List<AdminDoctorLocationDTO>(),
            CreatedByNavigation = new AdminUserDTO (),
            InversePartOfLocation = new List<AdminLocationsDTO>(),
            LastModifiedByNavigation = new AdminUserDTO (),
            PartOfLocation = null
            },
            new AdminLocationsDTO
            {
                 LocationId = 2,
                 ResourceId =  "KLAN",
            Name = "Test Location",
            Address = "123 Test Street",
            City = "Test City",
            State = "Test State",
            PostalCode = "12345",
            Country = "Test Country",
            PhoneNumber = "1234567890",
            Active = true,
            DateCreated = DateTime.UtcNow,
            CreatedBy = "Admin",
            LastModifiedBy = 2,
            LastModifiedDate = DateTime.UtcNow,
            Identifier = "LOC-001",
            Status = "Active",
            Description = "Test Description",
            LocationType = "Clinic",
            PhysicalType = "Building",
            AddressLine1 = "123 Test Street",
            AddressLine2 = "Suite 456",
            Latitude = 40.7128,
            Longitude = -74.0060,
            Altitude = 10,
            ManagingOrganizationId = 100,
            PartOfLocationId = null,
            Mode = "Online",
            FloorMap = "Test Floor Map",
            CreatedAt = DateTime.UtcNow.AddMonths(-1),
            UpdatedAt = DateTime.UtcNow,
            AdminDoctorLocations = new List<AdminDoctorLocationDTO>(),
            CreatedByNavigation = new AdminUserDTO (),
            InversePartOfLocation = new List<AdminLocationsDTO>(),
            LastModifiedByNavigation = new AdminUserDTO (),
            PartOfLocation = null
            },
        };
    }


    /// <summary>
    /// Returns a mock AdminLocationsRequest object for creating or updating a location.
    /// </summary>
    public static AdminLocationsRequest GetAdminLocationsRequest()
    {
        return new AdminLocationsRequest
        {
            LocationId = 1,
            Name = "Test Location",
            Address = "123 Test Street",
            City = "Test City",
            State = "Test State",
            PostalCode = "12345",
            Country = "Test Country",
            PhoneNumber = "1234567890",
            Active = true,
            DateCreated = DateTime.UtcNow,
            CreatedBy = 1,
            LastModifiedBy = 2,
            LastModifiedDate = DateTime.UtcNow,
            Identifier = "LOC-001",
            Status = "Active",
            Description = "Test Description",
            LocationType = "Clinic",
            PhysicalType = "Building",
            AddressLine1 = "123 Test Street",
            AddressLine2 = "Suite 456",
            Latitude = 40.7128,
            Longitude = -74.0060,
            Altitude = 10,
            ManagingOrganizationId = 100,
            PartOfLocationId = null,
            Mode = "Online",
            FloorMap = "Test Floor Map",
            CreatedAt = DateTime.UtcNow.AddMonths(-1),
            UpdatedAt = DateTime.UtcNow
        };
    }

    /// <summary>
    /// Returns a mock AdminLocationsRequest object with minimal data for edge case testing.
    /// </summary>
    public static AdminLocationsRequest GetMinimalAdminLocationsRequest()
    {
        return new AdminLocationsRequest
        {
            Address = "123 Minimal Street",
            Active = true,
            Name = "Minimal Location"
        };
    }
}
