﻿using Aurora.AdministrationService.API.Models.Dto.LocationDetail.Create;
using Aurora.AdministrationService.API.Models.Dto.LocationDetail.Update;
using Aurora.AdministrationService.API.Resources;
using Aurora.AdministrationService.API.Services.Service.Locations;
using Aurora.AdministrationService.CrossCutting.CommonModels;
using Aurora.AdministrationService.Domain.V1.Entities.Locations;
using Aurora.AdministrationService.Infrastructure;
using AutoMapper;
using FluentAssertions;
using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Diagnostics;
using Moq;

namespace Aurora.AdministrationService.Tests.API.Services.Locations
{
    public class LocationCommandServiceTests
    {
        private readonly Mock<IMapper> _mockMapper;
        private readonly ReadWriteDbContext _dbReadWriteContext;
        private readonly LocationCommandService _locationService;

        public LocationCommandServiceTests()
        {
            // Set up an in-memory database
            DbContextOptions<ReadWriteDbContext> options = new DbContextOptionsBuilder<ReadWriteDbContext>()
                .UseInMemoryDatabase(databaseName: "TestLocationDatabase")
                .ConfigureWarnings(b => b.Ignore(InMemoryEventId.TransactionIgnoredWarning))
                .Options;

            _dbReadWriteContext = new ReadWriteDbContext(options);

            _mockMapper = new Mock<IMapper>();

            _locationService = new LocationCommandService(_dbReadWriteContext, _mockMapper.Object);
        }

        [Fact]
        public async Task CreateLocationDetailAsync_ShouldReturnTrue_WhenSuccessfullyCreated()
        {
            // Arrange
            var newLocationDetail = new CreateLocationDetailDto
            {
                LocationDetailInformation = new CreateLocationDetailInformationDto
                {
                    Altitude = 1,
                    Description = "D1",
                    Latitude = 1,
                    Longitude = 1,
                    PhysicalType = "P1",
                    URL = "U1",
                    ResourceID = "12345",
                    Name = "Test Location",
                    PartOf = "ExistingLocation",
                    Status = true,
                },
                LocationDetailAddress = new CreateLocationDetailAddressDto
                {

                    Line1 = "123 Test St",
                    Line2 = "123 Test St",
                    City = "Test City",
                    Country = "Test Country",
                    State = "S1",
                    PostalCode = "P1",
                    Type = "Type"
                },
                LocationDetailImages = new List<CreateLocationDetailImageDto>
                {
                    new CreateLocationDetailImageDto
                    {
                        Category = "Exterior",
                        URL = "http://test.com/image1.jpg",
                    }
                },
                LocationDetailTelecom = new CreateLocationDetailTelecomDto
                {
                    Value = "1234567890",
                }
            };

            // Set up the mock for AutoMapper
            _mockMapper.Setup(m => m.Map<Location>(It.IsAny<CreateLocationDetailInformationDto>()))
                .Returns(new Location
                {
                    ResourceID = newLocationDetail.LocationDetailInformation.ResourceID,
                    Name = newLocationDetail.LocationDetailInformation.Name,
                    Status = newLocationDetail.LocationDetailInformation.Status,
                    ManagingOrganization = Guid.NewGuid(),
                    IsDeleted = false,
                    PartOf = newLocationDetail.LocationDetailInformation.PartOf,
                    CreatedBy = "testUser",
                    CreatedDate = DateTime.UtcNow,
                    UpdatedBy = "testUser"
                });

            _mockMapper.Setup(m => m.Map<LocationAddress>(newLocationDetail.LocationDetailAddress))
                .Returns(new LocationAddress
                {
                    Use = newLocationDetail.LocationDetailAddress.Type,
                    Line1 = newLocationDetail.LocationDetailAddress.Line1,
                    Line2 = newLocationDetail.LocationDetailAddress.Line2,
                    City = newLocationDetail.LocationDetailAddress.City,
                    Country = newLocationDetail.LocationDetailAddress.Country,
                    LocationID = 1,
                    State = newLocationDetail.LocationDetailAddress.State,
                    PostalCode = newLocationDetail.LocationDetailAddress.PostalCode,
                    Status = true,
                    IsDeleted = false,
                    CreatedBy = "testUser",
                    CreatedDate = DateTime.UtcNow,
                    UpdatedBy = "testUser",
                    UpdatedDate = DateTime.UtcNow
                });

            _mockMapper.Setup(m => m.Map<List<LocationImage>>(It.IsAny<List<CreateLocationDetailImageDto>>()))
                .Returns(new List<LocationImage> { new LocationImage { Id = 1, URL = newLocationDetail.LocationDetailImages[0].URL, LocationID = 1 } });

            _mockMapper.Setup(m => m.Map<LocationTelecom>(It.IsAny<CreateLocationDetailTelecomDto>()))
                .Returns(new LocationTelecom
                {
                    System = "System",
                    Value = newLocationDetail.LocationDetailTelecom.Value,
                    Use = "Use",
                    LocationID = 1,
                    IsDeleted = false,
                    CreatedBy = "testUser",
                    CreatedDate = DateTime.UtcNow
                });

            // Act
            var result = await _locationService.CreateLocationDetailAsync(newLocationDetail);

            // Assert
            result.IsSuccess.Should().BeTrue();
            result.Should().BeOfType<GenericResponse<CreateLocationDetailDto>>();
            result.HasError.Should().BeFalse();
        }

        [Fact]
        public async Task CreateLocationDetailAsync_ShouldReturnFalse_WhenNoRecordsCreated()
        {
            // Arrange
            var newLocationDetail = new CreateLocationDetailDto
            {
                LocationDetailInformation = new CreateLocationDetailInformationDto
                {
                    Altitude = 1,
                    Description = "D1",
                    Latitude = 1,
                    Longitude = 1,
                    PhysicalType = "P1",
                    URL = "U1",
                    ResourceID = "12345",
                    Name = "Test Location",
                    PartOf = "ExistingLocation",
                    Status = true,
                },
                LocationDetailAddress = new CreateLocationDetailAddressDto
                {
                    Line1 = "123 Test St",
                    Line2 = "123 Test St",
                    City = "Test City",
                    Country = "Test Country",
                    State = "S1",
                    PostalCode = "P1",
                    Type = "Type"
                },
                LocationDetailImages = new List<CreateLocationDetailImageDto>
                {
                    new CreateLocationDetailImageDto
                    {
                        Category = "Exterior",
                        URL = "http://test.com/image1.jpg",
                    }
                },
                LocationDetailTelecom = new CreateLocationDetailTelecomDto
                {
                    Value = "1234567890",
                }
            };

            // Set up a fresh in-memory database for this test
            var options = new DbContextOptionsBuilder<ReadWriteDbContext>()
                .UseInMemoryDatabase(databaseName: $"TestLocationDatabaseEmpty")
                .ConfigureWarnings(b => b.Ignore(InMemoryEventId.TransactionIgnoredWarning))
                .Options;

            var freshDbContext = new ReadWriteDbContext(options);

            // Create the service with the fresh DbContext
            var freshLocationService = new LocationCommandService(freshDbContext, _mockMapper.Object);

            // Act
            var result = await freshLocationService.CreateLocationDetailAsync(newLocationDetail);

            // Assert
            result.Should().BeOfType<GenericResponse<CreateLocationDetailDto>>();
            result.IsSuccess.Should().BeFalse();
            result.HasError.Should().BeTrue();
        }

        [Fact]
        public async Task CreateLocationDetailAsync_ShouldRollbackAndReturnFailure_WhenNoRecordsAreInserted()
        {
            // Arrange
            var newLocationDetail = new CreateLocationDetailDto
            {
                LocationDetailInformation = new CreateLocationDetailInformationDto
                {
                    Altitude = 1,
                    Description = "D1",
                    Latitude = 1,
                    Longitude = 1,
                    PhysicalType = "P1",
                    URL = "U1",
                    ResourceID = "12345",
                    Name = "Test Location",
                    PartOf = "ExistingLocation",
                    Status = true,
                },
                LocationDetailAddress = new CreateLocationDetailAddressDto
                {
                    Line1 = "123 Test St",
                    Line2 = "123 Test St",
                    City = "Test City",
                    Country = "Test Country",
                    State = "S1",
                    PostalCode = "P1",
                    Type = "Type"
                },
                LocationDetailImages = new List<CreateLocationDetailImageDto>
                {
                    new CreateLocationDetailImageDto
                    {
                        Category = "Exterior",
                        URL = "http://test.com/image1.jpg",
                    }
                },
                LocationDetailTelecom = new CreateLocationDetailTelecomDto
                {
                    Value = "1234567890",
                }
            };

            // Set up the in-memory database for this test
            var options = new DbContextOptionsBuilder<ReadWriteDbContext>()
                .UseInMemoryDatabase(databaseName: "TestLocationDatabase")
                .ConfigureWarnings(b => b.Ignore(InMemoryEventId.TransactionIgnoredWarning))
                .Options;

            var freshDbContext = new ReadWriteDbContext(options);

            var freshLocationService = new LocationCommandService(freshDbContext, _mockMapper.Object);

            _mockMapper.Setup(m => m.Map<Location>(It.IsAny<CreateLocationDetailInformationDto>()))
                .Returns(new Location
                {
                    Id = 1,
                    ResourceID = newLocationDetail.LocationDetailInformation.ResourceID,
                    Name = newLocationDetail.LocationDetailInformation.Name,
                    Status = newLocationDetail.LocationDetailInformation.Status,
                    CreatedBy = "testUser",
                    CreatedDate = DateTime.UtcNow,
                    UpdatedBy = "testUser",
                    IsDeleted = false,
                });

            _mockMapper.Setup(m => m.Map<LocationAddress>(It.IsAny<CreateLocationDetailAddressDto>()))
                .Returns(new LocationAddress
                {
                    Use = newLocationDetail.LocationDetailAddress.Type,
                    Line1 = newLocationDetail.LocationDetailAddress.Line1,
                    Line2 = newLocationDetail.LocationDetailAddress.Line2,
                    City = newLocationDetail.LocationDetailAddress.City,
                    Country = newLocationDetail.LocationDetailAddress.Country,
                    State = newLocationDetail.LocationDetailAddress.State,
                    PostalCode = newLocationDetail.LocationDetailAddress.PostalCode,
                    LocationID = 1,
                    CreatedBy = "testUser",
                    CreatedDate = DateTime.UtcNow,
                    IsDeleted = false,
                    Status = true
                });

            _mockMapper.Setup(m => m.Map<List<LocationImage>>(It.IsAny<List<CreateLocationDetailImageDto>>()))
                .Returns(new List<LocationImage>
                {
            new LocationImage { Id = 1, URL = newLocationDetail.LocationDetailImages[0].URL, LocationID = 1 }
                });

            _mockMapper.Setup(m => m.Map<LocationTelecom>(It.IsAny<CreateLocationDetailTelecomDto>()))
                .Returns(new LocationTelecom
                {
                    System = "System",
                    Value = newLocationDetail.LocationDetailTelecom.Value,
                    Use = "Use",
                    LocationID = 1,
                    CreatedBy = "testUser",
                    CreatedDate = DateTime.UtcNow,
                    IsDeleted = false,
                });

            var mockDbContext = new Mock<ReadWriteDbContext>(options);
            mockDbContext.Setup(db => db.SaveChangesAsync(It.IsAny<CancellationToken>()))
                         .ReturnsAsync(0);

            // Act
            var result = await freshLocationService.CreateLocationDetailAsync(newLocationDetail);

            // Assert
            result.Should().BeOfType<GenericResponse<CreateLocationDetailDto>>();
            result.IsSuccess.Should().BeFalse();
            result.HasError.Should().BeTrue();
            result.Message.Should().Be(Resource.RecordInsertionFailureMessage); // The message should indicate failure
        }

        [Fact]
        public async Task UpdateLocationDetailAsync_ShouldReturnTrue_WhenSuccessfullyUpdated()
        {
            // Arrange
            var location = new Location
            {
                Id = 1,
                PartOf = "partOf",
                Name = "Old Location",
                ResourceID = "12345",
                Status = true,
                RecordVersion = new byte[] { },
                ManagingOrganization = Guid.NewGuid(),
                CreatedBy = "testUser",
                CreatedDate = DateTime.UtcNow,
                UpdatedBy = "testUser",
                IsDeleted = false
            };

            var locationAddress = new LocationAddress
            {
                LocationID = 1,
                Line1 = "123 Old St",
                Line2 = "123 Old St",
                City = "Old City",
                Country = "Old Country",
                State = "S1",
                PostalCode = "P1",
                Use = "Billing",
                CreatedBy = "testUser",
                CreatedDate = DateTime.UtcNow,
                UpdatedBy = "testUser",
                UpdatedDate = DateTime.UtcNow,
                IsDeleted = false,
                Status = true
            };

            var locationTelecom = new LocationTelecom
            {
                LocationID = 1,
                System = "Phone",
                Value = "1234567890",
                Use = "Work",
                CreatedBy = "testUser",
                CreatedDate = DateTime.UtcNow,
                UpdatedBy = "testUser",
                UpdatedDate = DateTime.UtcNow,
                IsDeleted = false
            };

            var updatedLocationDetail = new UpdateLocationDetailDto
            {
                LocationDetailInformation = new UpdateLocationDetailInformationDto
                {
                    Id = 1,
                    Name = "Updated Location",
                    ResourceID = "12345",
                    Status = true
                },
                LocationDetailAddress = new UpdateLocationDetailAddressDto
                {
                    Id=1,
                    Line1 = "123 Updated St",
                    Line2 = "123 Updated St",
                    City = "Updated City",
                    Country = "Updated Country",
                    State = "S1",
                    PostalCode = "P1",
                    Type = "Type"
                },
                LocationDetailTelecom = new UpdateLocationDetailTelecomDto
                {
                    Id =1,
                    Value = "9876543210",
                }
            };
                    var options = new DbContextOptionsBuilder<ReadWriteDbContext>()
            .UseInMemoryDatabase(databaseName: $"TestLocationDatabaseUpdate")
            .ConfigureWarnings(b => b.Ignore(InMemoryEventId.TransactionIgnoredWarning))
            .Options;
            var freshDbContext = new ReadWriteDbContext(options);

            var freshLocationService = new LocationCommandService(freshDbContext, _mockMapper.Object);

            freshDbContext.Locations.Add(location);
            freshDbContext.LocationAddresses.Add(locationAddress);
            freshDbContext.LocationTelecoms.Add(locationTelecom);
            await freshDbContext.SaveChangesAsync();

            _mockMapper.Setup(m => m.Map(It.IsAny<UpdateLocationDetailInformationDto>(), location));
            _mockMapper.Setup(m => m.Map(It.IsAny<UpdateLocationDetailAddressDto>(), locationAddress));
            _mockMapper.Setup(m => m.Map(It.IsAny<UpdateLocationDetailTelecomDto>(), locationTelecom));

            // Act
            var result = await freshLocationService.UpdateLocationDetailAsync(updatedLocationDetail, location, locationAddress, locationTelecom);

            // Assert
            result.IsSuccess.Should().BeTrue();
            result.Should().BeOfType<GenericResponse<UpdateLocationDetailDto>>();
            result.HasError.Should().BeFalse();
        }

        [Fact]
        public async Task UpdateLocationDetailAsync_ShouldReturnFalse_WhenNoRecordsUpdated()
        {
            // Arrange
            var location = new Location
            {
                Id = 1,
                Name = "Old Location",
                ResourceID = "12345",
                Status = true,
                RecordVersion = new byte[] { },
                ManagingOrganization = Guid.NewGuid(),
                CreatedBy = "testUser",
                CreatedDate = DateTime.UtcNow,
                UpdatedBy = "testUser",
                IsDeleted = false
            };

            var locationAddress = new LocationAddress
            {
                LocationID = 1,
                Line1 = "123 Old St",
                Line2 = "123 Old St",
                City = "Old City",
                Country = "Old Country",
                State = "S1",
                PostalCode = "P1",
                Use = "Billing",
                CreatedBy = "testUser",
                CreatedDate = DateTime.UtcNow,
                UpdatedBy = "testUser",
                UpdatedDate = DateTime.UtcNow,
                IsDeleted = false,
                Status = true
            };

            var locationTelecom = new LocationTelecom
            {
                LocationID = 1,
                System = "Phone",
                Value = "1234567890",
                Use = "Work",
                CreatedBy = "testUser",
                CreatedDate = DateTime.UtcNow,
                UpdatedBy = "testUser",
                UpdatedDate = DateTime.UtcNow,
                IsDeleted = false
            };

            var updatedLocationDetail = new UpdateLocationDetailDto
            {
                LocationDetailInformation = new UpdateLocationDetailInformationDto
                {

                    Id = 1,
                    Name = "Old Location",
                    ResourceID = "12345",
                    Status = true
                },
                LocationDetailAddress = new UpdateLocationDetailAddressDto
                {

                    Id =1,
                    Line1 = "123 Old St",
                    Line2 = "123 Old St",
                    City = "Old City",
                    Country = "Old Country",
                    State = "S1",
                    PostalCode = "P1",
                    Type = "Type"
                },
                LocationDetailTelecom = new UpdateLocationDetailTelecomDto
                {

                    Id=1,
                    Value = "1234567890",
                }
            };

            _mockMapper.Setup(m => m.Map(It.IsAny<UpdateLocationDetailInformationDto>(), location));
            _mockMapper.Setup(m => m.Map(It.IsAny<UpdateLocationDetailAddressDto>(), locationAddress));
            _mockMapper.Setup(m => m.Map(It.IsAny<UpdateLocationDetailTelecomDto>(), locationTelecom));
            var options = new DbContextOptionsBuilder<ReadWriteDbContext>()
                .UseInMemoryDatabase(databaseName: $"TestLocationDatabaseEmpty")
                .ConfigureWarnings(b => b.Ignore(InMemoryEventId.TransactionIgnoredWarning))
                .Options;

            var freshDbContext = new ReadWriteDbContext(options);

            var freshLocationService = new LocationCommandService(freshDbContext, _mockMapper.Object);
            // Act
            var result = await freshLocationService.UpdateLocationDetailAsync(updatedLocationDetail, location, locationAddress, locationTelecom);

            // Assert
            result.IsSuccess.Should().BeFalse();
            result.Should().BeOfType<GenericResponse<UpdateLocationDetailDto>>();
            result.HasError.Should().BeTrue();
        }

        [Fact]
        public async Task UpdateLocationDetailAsync_ShouldReturnTrue_DeleteExistingImagesAndAddNewOnes()
        {
            // Arrange
            var location = new Location
            {
                Id = 1,
                Name = "Test Location",
                ResourceID = "12345",
                Status = true,
                ManagingOrganization = Guid.NewGuid(),
                IsDeleted = false,
                CreatedBy = "testUser",
                CreatedDate = DateTime.UtcNow,
                UpdatedBy = "testUser",
                PartOf = "l1"
            };

            var locationAddress = new LocationAddress
            {
                LocationID = 1,
                Line1 = "123 Old St",
                Line2 = "123 Old St",
                City = "Old City",
                Country = "Old Country",
                State = "S1",
                PostalCode = "P1",
                Use = "Billing",
                CreatedBy = "testUser",
                CreatedDate = DateTime.UtcNow,
                UpdatedBy = "testUser",
                UpdatedDate = DateTime.UtcNow,
                IsDeleted = false,
                Status = true
            };

            var locationTelecom = new LocationTelecom
            {
                LocationID = 1,
                System = "Phone",
                Value = "1234567890",
                Use = "Work",
                CreatedBy = "testUser",
                CreatedDate = DateTime.UtcNow,
                UpdatedBy = "testUser",
                UpdatedDate = DateTime.UtcNow,
                IsDeleted = false
            };

            var locationImage = new LocationImage
            {
                LocationID = 1,
                Id = 10,
                BuildingName = "B1",
                CreatedBy = "testUser",
                CreatedDate = DateTime.UtcNow,
                UpdatedBy = "testUser",
                UpdatedDate = DateTime.UtcNow,
                IsDeleted = false
            };
            var options = new DbContextOptionsBuilder<ReadWriteDbContext>()
            .UseInMemoryDatabase(databaseName: $"TestLocationDatabaseUpdateNew")
            .ConfigureWarnings(b => b.Ignore(InMemoryEventId.TransactionIgnoredWarning))
            .Options;

            var freshDbContext = new ReadWriteDbContext(options);

            var freshLocationService = new LocationCommandService(freshDbContext, _mockMapper.Object);

            freshDbContext.Locations.Add(location);
            freshDbContext.LocationAddresses.Add(locationAddress);
            freshDbContext.LocationTelecoms.Add(locationTelecom);
            freshDbContext.LocationImages.Add(locationImage);
            await freshDbContext.SaveChangesAsync();


            _mockMapper.Setup(m => m.Map(It.IsAny<UpdateLocationDetailAddressDto>(), locationAddress));
            _mockMapper.Setup(m => m.Map(It.IsAny<UpdateLocationDetailTelecomDto>(), locationTelecom));

            var request = new UpdateLocationDetailDto
            {
                LocationDetailAddress = new UpdateLocationDetailAddressDto
                {

                    Id = 1,
                    Line1 = "123 Old St",
                    Line2 = "123 Old St",
                    City = "Old City",
                    Country = "Old Country",
                    State = "S1",
                    PostalCode = "P1",
                    Type = "Type"
                },
                LocationDetailInformation = new UpdateLocationDetailInformationDto
                {
                    Id = 1,
                    Name = "Test Location",
                    ResourceID = "12345",
                    Status = true,
                },
                LocationDetailTelecom = new UpdateLocationDetailTelecomDto
                {

                    Id=1,
                    Value = "1234567890",
                },
                LocationDetailImages = new List<UpdateLocationDetailImageDto>
                {
                    new UpdateLocationDetailImageDto { BuildingName = "B1", FloorName = "F1", Category = "Exterior", URL = "http://test.com/newimage.jpg" },
                    new UpdateLocationDetailImageDto { BuildingName = "B1", FloorName = "F1", Category = "Interior", URL = "http://test.com/newimage2.jpg" }
                }
            };

            int count = 1;
            foreach (var imageDto in request.LocationDetailImages)
            {
                _mockMapper.Setup(m => m.Map<LocationImage>(imageDto))
                    .Returns(new LocationImage
                    {
                        Id = count++,
                        LocationID = location.Id,
                        BuildingName = imageDto.BuildingName,
                        FloorName = imageDto.FloorName,
                        Category = imageDto.Category,
                        URL = imageDto.URL,
                        CreatedBy = "testUser",
                        CreatedDate = DateTime.UtcNow,
                        UpdatedBy = "testUser",
                        UpdatedDate = DateTime.UtcNow
                    });
            }

            // Act
            var response = await freshLocationService.UpdateLocationDetailAsync(request, location, locationAddress, locationTelecom);

            // Assert
            Assert.False(response.HasError);
            Assert.True(response.IsSuccess);
        }
    }
}
