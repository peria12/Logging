﻿using Aurora.AdministrationService.API.Models.ResponseModels.LocationAddresses;
using Aurora.AdministrationService.API.Services.Service.LocationAddresss;
using Aurora.AdministrationService.CrossCutting.CommonModels;
using Aurora.AdministrationService.Domain.V1.Entities.Locations;
using Aurora.AdministrationService.Infrastructure;
using AutoMapper;
using Microsoft.EntityFrameworkCore;
using Moq;

namespace Aurora.AdministrationService.Tests.API.Services.Locations
{
    public class LocationAddressQueryServiceTests
    {
        private readonly Mock<ReadOnlyDbContext> _readOnlyDbContextMock;
        private readonly Mock<IMapper> _mapperMock;
        private readonly LocationAddressQueryService _locationAddressQueryService;
        private readonly Mock<DbSet<LocationAddress>> _mockDbSet;

        public LocationAddressQueryServiceTests()
        {
            //Initialize mock
            _readOnlyDbContextMock = new Mock<ReadOnlyDbContext>();
            _mapperMock = new Mock<IMapper>();

            // Setup in-memory ready only database for testing
            DbContextOptions<ReadOnlyDbContext> options = new DbContextOptionsBuilder<ReadOnlyDbContext>()
              .UseInMemoryDatabase(databaseName: "LocationAddressTestDB").Options;

            _readOnlyDbContextMock = new(options);

            _mockDbSet = new Mock<DbSet<LocationAddress>>();

            var data = new List<LocationAddress>
            {
               new LocationAddress {
                Id = 1,
                City = "Pulkit",
                District = "Jallil",
                Country = "Mayesia",
                Line1 = "address1",
                Line2 = "address2",
                Line3 = "address3",
                Line4 = "address4",
                IsDeleted = false,
                PeriodStart = DateTime.UtcNow,
                PeriodEnd = DateTime.UtcNow,
                PostalCode = "1",
                CreatedBy = "Admin",
                CreatedDate = DateTime.UtcNow,
                Use = "Billing",
                LocationID = 1,
                Status = true,
                State = "state",
                Type = "type",
                UpdatedBy = "Admin",  // Adding the missing property
                UpdatedDate = DateTime.UtcNow,// Assuming UpdatedDate is required as well
            },
               new LocationAddress {
                Id = 2,
                City = "Pulkit",
                District = "Jallil",
                Country = "Mayesia",
                Line1 = "address1",
                Line2 = "address2",
                Line3 = "address3",
                Line4 = "address4",
                IsDeleted = false,
                PeriodStart = DateTime.UtcNow,
                PeriodEnd = DateTime.UtcNow,
                PostalCode = "1",
                CreatedBy = "Admin",
                CreatedDate = DateTime.UtcNow,
                Use = "Billing",
                LocationID = 1,
                Status = true,
                State = "state",
                Type = "type",
                UpdatedBy = "Admin",  // Adding the missing property
                UpdatedDate = DateTime.UtcNow,// Assuming UpdatedDate is required as well
            }}.AsQueryable();

            //Setup
            _mockDbSet.As<IQueryable<LocationAddress>>().Setup(m => m.Provider).Returns(data.Provider);
            _mockDbSet.As<IQueryable<LocationAddress>>().Setup(m => m.Expression).Returns(data.Expression);
            _mockDbSet.As<IQueryable<LocationAddress>>().Setup(m => m.ElementType).Returns(data.ElementType);
            _mockDbSet.As<IQueryable<LocationAddress>>().Setup(m => m.GetEnumerator()).Returns(data.GetEnumerator());
            _readOnlyDbContextMock.Setup(c => c.LocationAddresses).Returns(_mockDbSet.Object);

            // Create the service instance
            _locationAddressQueryService = new LocationAddressQueryService(_readOnlyDbContextMock.Object, _mapperMock.Object);
        }

        [Fact]
        public async Task GetLocationAddressById_LogoExists_ReturnsLogoDetailDto()
        {
            // Arrange
            var locationAddressId = 1;
            var locationAddress = new LocationAddress
            {
                Id = 1,
                City = "Pulkit",
                District = "Jallil",
                Country = "Mayesia",
                Line1 = "address1",
                Line2 = "address2",
                Line3 = "address3",
                Line4 = "address4",
                IsDeleted = false,
                PeriodStart = DateTime.UtcNow,
                PeriodEnd = DateTime.UtcNow,
                PostalCode = "1",
                CreatedBy = "Admin",
                CreatedDate = DateTime.UtcNow,
                Use = "Billing",
                LocationID = 1,
                Status = true,
                State = "state",
                Type = "type",
                UpdatedBy = "Admin",  // Adding the missing property
                UpdatedDate = DateTime.UtcNow,// Assuming UpdatedDate is required as well
            };

            var locationAddressDto = new GetLocationAddressDetailDto
            { Id = 1, City = "Pulkit", District = "Jallil", Country = "Mayesia", Line1 = "address1", Line2 = "address2", Line3 = "address3", Line4 = "address4", IsDeleted = false, PeriodStart = DateTime.UtcNow, PeriodEnd = DateTime.UtcNow, PostalCode = "1", Use = "Billing"  };

            _readOnlyDbContextMock.Setup(db => db.LocationAddresses.FindAsync(locationAddressId))
                .ReturnsAsync(locationAddress);

            _mapperMock.Setup(m => m.Map<GetLocationAddressDetailDto>(locationAddress))
                .Returns(locationAddressDto);

            // Act
            var result = await _locationAddressQueryService.GetLocationAddressById(locationAddressId);

            // Assert
            Assert.NotNull(result);
            Assert.Equal(locationAddressId, result.Id);
            Assert.Equal("Pulkit", result.City);
        }

        [Fact]
        public async Task GetLocationAddressById_locationAddressNotFound_ReturnsNull()
        {
            //Arrange
            var locationAddressId = 1;
            var locationAddress = new LocationAddress
            {
                Id = 1,
                City = "Pulkit",
                District = "Jallil",
                Country = "Mayesia",
                Line1 = "address1",
                Line2 = "address2",
                Line3 = "address3",
                Line4 = "address4",
                IsDeleted = false,
                PeriodStart = DateTime.UtcNow,
                PeriodEnd = DateTime.UtcNow,
                PostalCode = "1",
                CreatedBy = "Admin",
                CreatedDate = DateTime.UtcNow,
                Use = "Billing",
                LocationID = 1,
                Status = true,
                State = "state",
                Type = "type",
                UpdatedBy = "Admin",  // Adding the missing property
                UpdatedDate = DateTime.UtcNow,// Assuming UpdatedDate is required as well
            };

            _readOnlyDbContextMock.Setup(db => db.LocationAddresses.FindAsync(locationAddressId))
                .ReturnsAsync(locationAddress);

            //Act
            var result = await _locationAddressQueryService.GetLocationAddressById(locationAddressId);

            //Assert
            Assert.Null(result);
        }

        [Fact]
        public async Task GetLocationAddressById_locationAddressExists_BindingError_ReturnsNull()
        {
            // Arrange
            var locationAddressId = 1;
            var locationAddress = new LocationAddress
            {
                Id = 1,
                City = "Pulkit",
                District = "Jallil",
                Country = "Mayesia",
                Line1 = "address1",
                Line2 = "address2",
                Line3 = "address3",
                Line4 = "address4",
                IsDeleted = false,
                PeriodStart = DateTime.UtcNow,
                PeriodEnd = DateTime.UtcNow,
                PostalCode = "1",
                CreatedBy = "Admin",
                CreatedDate = DateTime.UtcNow,
                Use = "Billing",
                LocationID = 1,
                Status = true,
                State = "state",
                Type = "type",
                UpdatedBy = "Admin",  // Adding the missing property
                UpdatedDate = DateTime.UtcNow,// Assuming UpdatedDate is required as well
            };

            _readOnlyDbContextMock.Setup(db => db.LocationAddresses.FindAsync(locationAddressId))
                .ReturnsAsync(locationAddress);

            _mapperMock.Setup(m => m.Map<GetLocationAddressDetailDto>(locationAddress))
                .Throws(new AutoMapperMappingException("Error mapping entity to DTO"));

            // Act & Assert
            var exception = await Assert.ThrowsAsync<AutoMapperMappingException>(
                () => _locationAddressQueryService.GetLocationAddressById(locationAddressId)
            );

            Assert.Equal("Error mapping entity to DTO", exception.Message);
        }

        [Fact]
        public async Task FindLocationAddressById_locationAddressExists_ReturnslocationAddress()
        {
            // Arrange
            var locationAddressId = 1;
            var locationAddress = new LocationAddress
            {
                Id = locationAddressId,
                City = "Pulkit",
                District = "Jallil",
                Country = "Mayesia",
                Line1 = "address1",
                Line2 = "address2",
                Line3 = "address3",
                Line4 = "address4",
                IsDeleted = false,
                PeriodStart = DateTime.UtcNow,
                PeriodEnd = DateTime.UtcNow,
                PostalCode = "1",
                CreatedBy = "Admin",
                CreatedDate = DateTime.UtcNow,
                Use = "Billing",
                LocationID = 1,
                Status = true,
                State = "state",
                Type = "type",
                UpdatedBy = "Admin",  // Adding the missing property
                UpdatedDate = DateTime.UtcNow,// Assuming UpdatedDate is required as well
            };

            // Mock the FindAsync method to return the locationAddress
            _readOnlyDbContextMock.Setup(db => db.LocationAddresses.FindAsync(locationAddressId))
                .ReturnsAsync(locationAddress);

            // Act
            var result = await _locationAddressQueryService.FindLocationAddressById(locationAddressId);

            // Assert
            Assert.Null(result);
        }

        [Fact]
        public void GetLocationAddressList_ReturnsCorrectLocationAddressList()
        {
            // Act
            var result = _locationAddressQueryService.GetLocationAddressList();

            // Assert
            Assert.NotNull(result);
            Assert.Equal(2, result.Count); // Verifying that 3 items are returned

            // Verifying that the returned items are mapped correctly
            Assert.Contains(result, r => r.Id == 1 && r.LocationID == 1);
            Assert.Contains(result, r => r.Id == 2 && r.LocationID == 1);
        }

        [Fact]
        public async Task IsLocationAddressAlreadyExist_ShouldReturnTrue_WhenlocationAddressExists()
        {
            // Arrange
            var locationAddressId = 1;
            var locationAddress = new LocationAddress
            {
                Id = 1,
                City = "Pulkit",
                District = "Jallil",
                Country = "Mayesia",
                Line1 = "address1",
                Line2 = "address2",
                Line3 = "address3",
                Line4 = "address4",
                IsDeleted = false,
                PeriodStart = DateTime.UtcNow,
                PeriodEnd = DateTime.UtcNow,
                PostalCode = "1",
                CreatedBy = "Admin",
                CreatedDate = DateTime.UtcNow,
                Use = "Billing",
                LocationID = 1,
                Status = true,
                State = "state",
                Type = "type",
                UpdatedBy = "Admin",  // Adding the missing property
                UpdatedDate = DateTime.UtcNow,// Assuming UpdatedDate is required as well
            };

            // Mock the FindAsync method to return the locationAddress
            _readOnlyDbContextMock.Setup(db => db.LocationAddresses.FindAsync(locationAddressId))
                .ReturnsAsync(locationAddress);

            // Act
            var result = await _locationAddressQueryService.IsLocationAddressAlreadyExist(locationAddressId);

            // Assert
            Assert.True(result.result);
            Assert.Equal(ResponseMessage.STATUS_DATA_FOUND, result.message);
        }

        [Fact]
        public async Task IsLocationAddressAlreadyExist_ShouldReturnFalse_WhenlocationAddressDoesNotExist()
        {
            // Arrange
            var locationAddressId = 3;

            // Act
            var result = await _locationAddressQueryService.IsLocationAddressAlreadyExist(locationAddressId);

            // Assert
            Assert.False(result.result);
            Assert.Equal(ResponseMessage.STATUS_NODATA, result.message);
        }
    }
}
