﻿using Aurora.AdministrationService.API.Models.RequestModels.Passcode;
using Aurora.AdministrationService.API.Services.IService.OTP.Token;
using Aurora.AdministrationService.API.Services.Service.Passcode;
using Aurora.AdministrationService.CrossCutting.CommonModels;
using Aurora.AdministrationService.Infrastructure;
using FluentAssertions;
using Microsoft.EntityFrameworkCore;
using Moq;

namespace Aurora.AdministrationService.Tests.API.Services.Passcode
{
    public class LoginPasscodeTests
    {
        private readonly ReadOnlyDbContext _dbContextMock;
        private readonly Mock<ITokenQueryService> _tokenServiceMock;
        private readonly PasscodeQueryService _passcodeQueryService;

        public LoginPasscodeTests()
        {
            // ✅ Use EF Core In-Memory Database instead of mocking DbContext
            var options = new DbContextOptionsBuilder<ReadOnlyDbContext>()
                .UseInMemoryDatabase(databaseName: "TestDatabase")
                .Options;

            _dbContextMock = new ReadOnlyDbContext(options);
            _tokenServiceMock = new Mock<ITokenQueryService>();
            _passcodeQueryService = new PasscodeQueryService(_dbContextMock, _tokenServiceMock.Object);
        }

        [Fact]
        public async Task LoginPasscodeAsync_Success_ShouldReturnOk()
        {
            // Arrange
            var request = new LoginPasscodeRequest { UserName = "User123", Passcode = "123456" };

            var fakeUser = new Aurora.AdministrationService.Domain.V1.Entities.Users.User()
            {
                BioAuthenticationEnabled = true,
                CreatedBy = "",
                CreatedDate = DateTime.Now,
                IsTempAccount = true,
                NotificationsEnabled = true,
                SOSButtonEnabled = true,
                Status = true,
                UpdatedBy = "",
                UpdatedDate = DateTime.Now,
                UserType = "Patient",
                UserName = "User123",
                Passcode = "123456",
                IsDeleted = false
            };

            // ✅ Seed the In-Memory Database
            _dbContextMock.UserNew.Add(fakeUser);
            await _dbContextMock.SaveChangesAsync();

            var expectedToken = "JWT-TOKEN";
            _tokenServiceMock.Setup(t => t.GenerateToken(It.IsAny<string>(), It.IsAny<string>())).ReturnsAsync(expectedToken);

            // Act
            var result = await _passcodeQueryService.LoginPasscodeAsync(request);

            // Assert
            result.Should().NotBeNull();
            result.IsSuccess.Should().BeTrue();
            result.HasError.Should().BeFalse();
            result.StatusCode.Should().Be(ResponseStatus.STATUS_SUCCESS);
            result.Message.Should().Be(ResponseMessage.LOGIN_SUCCESS);
            result.Result.Should().NotBeNull();
            result.Result.Token.Should().Be(expectedToken);
        }

        [Fact]
        public async Task LoginPasscodeAsync_InvalidUsername_ShouldReturnBadRequest()
        {
            // Arrange
            var request = new LoginPasscodeRequest { UserName = "NonExistentUser", Passcode = "123456" };

            // Act
            var result = await _passcodeQueryService.LoginPasscodeAsync(request);

            // Assert
            result.Should().NotBeNull();
            result.IsSuccess.Should().BeFalse();
            result.HasError.Should().BeTrue();
            result.StatusCode.Should().Be(ResponseStatus.STATUS_BadRequest);
            result.Message.Should().Be(ResponseMessage.INVALID_CREDENTIAL);
        }

        [Fact]
        public async Task LoginPasscodeAsync_IncorrectPasscode_ShouldReturnBadRequest()
        {
            // Arrange
            var request = new LoginPasscodeRequest { UserName = "User123", Passcode = "WrongPasscode" };

            var fakeUser = new Aurora.AdministrationService.Domain.V1.Entities.Users.User()
            {
                BioAuthenticationEnabled = true,
                CreatedBy = "",
                CreatedDate = DateTime.Now,
                IsTempAccount = true,
                NotificationsEnabled = true,
                SOSButtonEnabled = true,
                Status = true,
                UpdatedBy = "",
                UpdatedDate = DateTime.Now,
                UserType = "Patient",
                UserName = "User123",
                Passcode = "123456",
                IsDeleted = false
            };

            _dbContextMock.UserNew.Add(fakeUser);
            await _dbContextMock.SaveChangesAsync();

            // Act
            var result = await _passcodeQueryService.LoginPasscodeAsync(request);

            // Assert
            result.Should().NotBeNull();
            result.IsSuccess.Should().BeFalse();
            result.HasError.Should().BeTrue();
            result.StatusCode.Should().Be(ResponseStatus.STATUS_BadRequest);
            result.Message.Should().Be(ResponseMessage.INCORRECT_PASSWORD);
        }

        [Fact]
        public async Task LoginPasscodeAsync_ExceptionThrown_ShouldReturnInternalServerError()
        {
            // Arrange
            var request = new LoginPasscodeRequest { UserName = "User123", Passcode = "123456" };

            // Simulate database error by disposing context before calling method
            await _dbContextMock.DisposeAsync();

            // Act
            Func<Task> act = async () => await _passcodeQueryService.LoginPasscodeAsync(request);

            // Assert
            await act.Should().ThrowAsync<ObjectDisposedException>();
        }
    }
}
