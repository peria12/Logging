﻿using Aurora.AdministrationService.API.Enum;
using Aurora.AdministrationService.API.Models.RequestModels.Leaves;
using Aurora.AdministrationService.API.Models.RequestModels.Schedules;
using Aurora.AdministrationService.API.Services.IService.AzureBus;
using Aurora.AdministrationService.API.Services.Service.Schedule;
using Aurora.AdministrationService.CrossCutting.CommonModels;
using Aurora.AdministrationService.CrossCutting.Constants;
using Aurora.AdministrationService.Domain.V1.Entities.PractitionerRoles;
using Aurora.AdministrationService.Infrastructure;
using AutoMapper;
using FluentAssertions;
using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Diagnostics;
using Microsoft.EntityFrameworkCore.Infrastructure;
using Microsoft.EntityFrameworkCore.Storage;
using Microsoft.Extensions.Configuration;
using Moq;

namespace Aurora.AdministrationService.Tests.API.Services.Schedule
{
    public class ScheduleCommandServiceTests
    {
        private readonly Mock<ReadWriteDbContext> _readWriteDbContextMock;
        private ScheduleCommandService _service;
        private readonly Mock<IMapper> _mapperMock;
        private readonly Mock<IAzureBusCommandServices> _azureBusCommandServicesMock;
        private readonly Mock<IConfiguration> _mockConfiguration;

        public ScheduleCommandServiceTests()
        {
            // Initialize the mocks
            _readWriteDbContextMock = new Mock<ReadWriteDbContext>();
            _mapperMock = new Mock<IMapper>();
            _azureBusCommandServicesMock = new Mock<IAzureBusCommandServices>();
            _mockConfiguration = new Mock<IConfiguration>();

            // Setup in-memory ready only database for testing
            DbContextOptions<ReadWriteDbContext> options = new DbContextOptionsBuilder<ReadWriteDbContext>()
              .UseInMemoryDatabase(databaseName: "ScheduleTestDB").Options;

            _readWriteDbContextMock = new(options);

            // Initialize the service being tested
            _service = new ScheduleCommandService(_readWriteDbContextMock.Object, _azureBusCommandServicesMock.Object, _mockConfiguration.Object);
        }
        //Clone
        [Fact]
        public async Task CloneScheduleLeaveAsync_ShouldReturnFalse_WhenRequestIsInvalid()
        {
            // Arrange
            var options = new DbContextOptionsBuilder<ReadWriteDbContext>()
    .UseInMemoryDatabase(databaseName: Guid.NewGuid().ToString())
    .ConfigureWarnings(b => b.Ignore(InMemoryEventId.TransactionIgnoredWarning)).Options;

            await using var context = new ReadWriteDbContext(options);
            var service = new ScheduleCommandService(context, _azureBusCommandServicesMock.Object, _mockConfiguration.Object);
            // Arrange
            var request = new ScheduleLeavesRequestDto
            {
                practitionerId = 1,
                newTimeOff = new List<TimeOffAddRequestDto>(), // Still testing the invalid case (empty list)
                Action = "Create",
                Type = "Leave",
                LocationResourceId = "loc-001",
                NewOverrides = string.Empty,
                RemovedOverrides = string.Empty,
                PractitionerIdentifiers = new List<PractitionerIdentifierRequestDto>()
            };

            // Act
            var result = await service.CloneScheduleLeaveAsync(request);

            // Assert
            result.result.Should().BeFalse();
            result.message.Should().Be(CommonConstants.DUPLICATE_NOTALLOWED);
        }
        [Fact]
        public async Task CloneScheduleLeaveAsync_ShouldReturnSuccess_WhenValidRequest()
        {
            // Arrange
            var options = new DbContextOptionsBuilder<ReadWriteDbContext>()
  .UseInMemoryDatabase(databaseName: Guid.NewGuid().ToString())
  .ConfigureWarnings(b => b.Ignore(InMemoryEventId.TransactionIgnoredWarning)).Options;

            await using var context = new ReadWriteDbContext(options);
            var service = new ScheduleCommandService(context, _azureBusCommandServicesMock.Object, _mockConfiguration.Object);
            var request = new ScheduleLeavesRequestDto
            {
                practitionerId = 1,
                PractitionerIdentifiers = new List<PractitionerIdentifierRequestDto>
                {
                    new PractitionerIdentifierRequestDto
                    {
                        IdentifierType="test",
                        IdentifierUse="test",
                        PeriodEnd=DateTime.UtcNow,
                        PeriodStart=DateTime.UtcNow,
                        System="test",
                        Value="demo"
                    }
                },
                newTimeOff = new List<TimeOffAddRequestDto>
        {
            new TimeOffAddRequestDto
            {

                StartDateTime = DateTime.UtcNow,
                EndDateTime = DateTime.UtcNow.AddDays(1),
                Description = "Personal Leave",
                IsWorkingDay = false
            }
        }
            };

            _readWriteDbContextMock.Setup(x => x.PractitionerNotAvailables.AddRangeAsync(It.IsAny<IEnumerable<PractitionerNotAvailable>>(), default));
            _readWriteDbContextMock.Setup(x => x.SaveChangesAsync(default)).ReturnsAsync(1);

            // Act
            var result = await service.CloneScheduleLeaveAsync(request);

            // Assert
            result.result.Should().BeTrue();
            result.message.Should().Be(CommonConstants.SUCCESS);
        }
        [Fact]
        public async Task CloneScheduleLeaveAsync_ShouldReturnFalse_WhenTimeOffIsClashing()
        {
            // Arrange
            var options = new DbContextOptionsBuilder<ReadWriteDbContext>()
                .UseInMemoryDatabase(databaseName: Guid.NewGuid().ToString())
                .ConfigureWarnings(b => b.Ignore(InMemoryEventId.TransactionIgnoredWarning))
                .Options;

            await using var context = new ReadWriteDbContext(options);

            // Seed existing time-off that will cause a clash
            var existingTimeOff = new PractitionerNotAvailable
            {
                PractitionerID = 1,
                StartDateTime = DateTime.UtcNow.AddHours(2),
                EndDateTime = DateTime.UtcNow.AddHours(4),
                IsDeleted = false,
                Description = "demo",
                UpdatedBy = "admin",
                UpdatedDate = DateTime.Now,
                IsworkingDay = false,
                CreatedBy = "admin",
                CreatedDate = DateTime.Now
            };

            context.PractitionerNotAvailables.Add(existingTimeOff);
            await context.SaveChangesAsync();

            var service = new ScheduleCommandService(context, _azureBusCommandServicesMock.Object, _mockConfiguration.Object);

            var request = new ScheduleLeavesRequestDto
            {
                practitionerId = 1,
                PractitionerIdentifiers = new List<PractitionerIdentifierRequestDto>
        {
            new PractitionerIdentifierRequestDto
            {
                IdentifierType = "test",
                IdentifierUse = "test",
                PeriodEnd = DateTime.UtcNow,
                PeriodStart = DateTime.UtcNow,
                System = "test",
                Value = "demo"
            }
        },
                newTimeOff = new List<TimeOffAddRequestDto>
        {
            new TimeOffAddRequestDto
            {
                // This overlaps with the seeded time-off
                StartDateTime = DateTime.UtcNow.AddHours(3),
                EndDateTime = DateTime.UtcNow.AddHours(5),
                Description = "Clashing Leave",
                IsWorkingDay = false
            }
        }
            };

            // Act
            var result = await service.CloneScheduleLeaveAsync(request);

            // Assert
            result.result.Should().BeFalse();
            result.message.Should().Be(CommonConstants.Duplicate_Schedule);
        }

        [Fact]
        public async Task CloneScheduleLeaveAsync_ShouldReturnFailure_WhenSaveChangesFails()
        {
            // Arrange
            var request = new ScheduleLeavesRequestDto
            {
                practitionerId = 1,
                PractitionerIdentifiers = new List<PractitionerIdentifierRequestDto>
                {
                    new PractitionerIdentifierRequestDto
                    {
                        IdentifierType="test",
                        IdentifierUse="test",
                        PeriodEnd=DateTime.UtcNow,
                        PeriodStart=DateTime.UtcNow,
                        System="test",
                        Value="demo"
                    }
                },
                newTimeOff = new List<TimeOffAddRequestDto>
        {
            new TimeOffAddRequestDto
            {

                StartDateTime = DateTime.UtcNow,
                EndDateTime = DateTime.UtcNow.AddDays(1),
                Description = "Personal Leave",
                IsWorkingDay = false
            }
        }
            };

            var dbContextMock = new Mock<ReadWriteDbContext>(
                new DbContextOptionsBuilder<ReadWriteDbContext>()
                    .UseInMemoryDatabase(Guid.NewGuid().ToString())
                    .Options);

            var dbFacadeMock = new Mock<DatabaseFacade>(dbContextMock.Object);
            var transactionMock = new Mock<IDbContextTransaction>();
            dbFacadeMock.Setup(f => f.BeginTransactionAsync(default))
                        .ReturnsAsync(transactionMock.Object);

            dbContextMock.SetupGet(x => x.Database).Returns(dbFacadeMock.Object);
            dbContextMock.Setup(x => x.SaveChangesAsync(default)).ThrowsAsync(new Exception("Save failure"));

            var service = new ScheduleCommandService(
                dbContextMock.Object,
                _azureBusCommandServicesMock.Object,
                _mockConfiguration.Object
                );

            // Act
            var result = await service.CloneScheduleLeaveAsync(request);

            // Assert
            result.result.Should().BeFalse();
            result.message.Should().Be(CommonConstants.Failed);
            transactionMock.Verify(x => x.RollbackAsync(It.IsAny<CancellationToken>()), Times.Once);
        }
        [Fact]
        public async Task CreateScheduleLeaveAsync_ShouldReturnFalse_WhenRequestIsInvalid()
        {
            // Arrange
            var options = new DbContextOptionsBuilder<ReadWriteDbContext>()
    .UseInMemoryDatabase(databaseName: Guid.NewGuid().ToString())
    .ConfigureWarnings(b => b.Ignore(InMemoryEventId.TransactionIgnoredWarning)).Options;

            await using var context = new ReadWriteDbContext(options);
            var service = new ScheduleCommandService(context, _azureBusCommandServicesMock.Object, _mockConfiguration.Object);
            // Arrange
            var request = new ScheduleLeavesRequestDto
            {
                practitionerId = 1,
                newTimeOff = new List<TimeOffAddRequestDto>(), // Still testing the invalid case (empty list)
                Action = "Create",
                Type = "Leave",
                LocationResourceId = "loc-001",
                NewOverrides = string.Empty,
                RemovedOverrides = string.Empty,
                PractitionerIdentifiers = new List<PractitionerIdentifierRequestDto>()
            };

            // Act
            var result = await service.CreateScheduleLeaveAsync(request);

            // Assert
            result.result.Should().BeFalse();
            result.message.Should().Be(CommonConstants.DUPLICATE_NOTALLOWED);
        }
        [Fact]
        public async Task CreateScheduleLeaveAsync_ShouldReturnFalse_WhenDateRangeInvalid()
        {
            // Arrange
            var options = new DbContextOptionsBuilder<ReadWriteDbContext>()
    .UseInMemoryDatabase(databaseName: Guid.NewGuid().ToString())
    .ConfigureWarnings(b => b.Ignore(InMemoryEventId.TransactionIgnoredWarning)).Options;

            await using var context = new ReadWriteDbContext(options);
            var service = new ScheduleCommandService(context, _azureBusCommandServicesMock.Object, _mockConfiguration.Object);
            var request = new ScheduleLeavesRequestDto
            {
                practitionerId = 1,
                newTimeOff = new List<TimeOffAddRequestDto>
        {
            new TimeOffAddRequestDto
            {

                StartDateTime = DateTime.UtcNow.AddDays(1),
                EndDateTime = DateTime.UtcNow, // Invalid: Start > End
                Description = "Invalid Leave",
                IsWorkingDay = false
            }
        }
            };

            // Act
            var result = await service.CreateScheduleLeaveAsync(request);

            // Assert
            result.result.Should().BeTrue();
        }
        [Fact]
        public async Task CreateScheduleLeaveAsync_ShouldReturnSuccess_WhenValidRequest()
        {
            // Arrange
            var options = new DbContextOptionsBuilder<ReadWriteDbContext>()
  .UseInMemoryDatabase(databaseName: Guid.NewGuid().ToString())
  .ConfigureWarnings(b => b.Ignore(InMemoryEventId.TransactionIgnoredWarning)).Options;

            await using var context = new ReadWriteDbContext(options);
            var service = new ScheduleCommandService(context, _azureBusCommandServicesMock.Object, _mockConfiguration.Object);
            var request = new ScheduleLeavesRequestDto
            {
                practitionerId = 1,
                PractitionerIdentifiers = new List<PractitionerIdentifierRequestDto>
                {
                    new PractitionerIdentifierRequestDto
                    {
                        IdentifierType="test",
                        IdentifierUse="test",
                        PeriodEnd=DateTime.UtcNow,
                        PeriodStart=DateTime.UtcNow,
                        System="test",
                        Value="demo"
                    }
                },
                newTimeOff = new List<TimeOffAddRequestDto>
        {
            new TimeOffAddRequestDto
            {

                StartDateTime = DateTime.UtcNow,
                EndDateTime = DateTime.UtcNow.AddDays(1),
                Description = "Personal Leave",
                IsWorkingDay = false
            }
        }
            };

            _readWriteDbContextMock.Setup(x => x.PractitionerNotAvailables.AddRangeAsync(It.IsAny<IEnumerable<PractitionerNotAvailable>>(), default));
            _readWriteDbContextMock.Setup(x => x.SaveChangesAsync(default)).ReturnsAsync(1);

            // Act
            var result = await service.CreateScheduleLeaveAsync(request);

            // Assert
            result.result.Should().BeTrue();
            result.message.Should().Be(CommonConstants.SUCCESS);
        }
        [Fact]
        public async Task CreateScheduleLeaveAsync_ShouldReturnFailure_WhenSaveChangesFails()
        {
            // Arrange
            var request = new ScheduleLeavesRequestDto
            {
                practitionerId = 1,
                PractitionerIdentifiers = new List<PractitionerIdentifierRequestDto>
                {
                    new PractitionerIdentifierRequestDto
                    {
                        IdentifierType="test",
                        IdentifierUse="test",
                        PeriodEnd=DateTime.UtcNow,
                        PeriodStart=DateTime.UtcNow,
                        System="test",
                        Value="demo"
                    }
                },
                newTimeOff = new List<TimeOffAddRequestDto>
        {
            new TimeOffAddRequestDto
            {

                StartDateTime = DateTime.UtcNow,
                EndDateTime = DateTime.UtcNow.AddDays(1),
                Description = "Personal Leave",
                IsWorkingDay = false
            }
        }
            };

            var dbContextMock = new Mock<ReadWriteDbContext>(
                new DbContextOptionsBuilder<ReadWriteDbContext>()
                    .UseInMemoryDatabase(Guid.NewGuid().ToString())
                    .Options);

            var dbFacadeMock = new Mock<DatabaseFacade>(dbContextMock.Object);
            var transactionMock = new Mock<IDbContextTransaction>();
            dbFacadeMock.Setup(f => f.BeginTransactionAsync(default))
                        .ReturnsAsync(transactionMock.Object);

            dbContextMock.SetupGet(x => x.Database).Returns(dbFacadeMock.Object);
            dbContextMock.Setup(x => x.SaveChangesAsync(default)).ThrowsAsync(new Exception("Save failure"));

            var service = new ScheduleCommandService(
                dbContextMock.Object,
                _azureBusCommandServicesMock.Object,
                _mockConfiguration.Object
                );

            // Act
            var result = await service.CreateScheduleLeaveAsync(request);

            // Assert
            result.result.Should().BeFalse();
            result.message.Should().Be(CommonConstants.Failed);
            transactionMock.Verify(x => x.RollbackAsync(It.IsAny<CancellationToken>()), Times.Once);
        }
        [Fact]
        public async Task AddNewLeavesAsync_ShouldReturnEmptyList_WhenNewTimeOffIsEmpty()
        {
            // Arrange

            // Arrange
            var options = new DbContextOptionsBuilder<ReadWriteDbContext>()
  .UseInMemoryDatabase(databaseName: Guid.NewGuid().ToString())
  .ConfigureWarnings(b => b.Ignore(InMemoryEventId.TransactionIgnoredWarning)).Options;

            await using var context = new ReadWriteDbContext(options);
            var service = new ScheduleCommandService(context, _azureBusCommandServicesMock.Object, _mockConfiguration.Object);
            var request = new ScheduleLeavesRequestDto
            {
                practitionerId = 1,
                PractitionerIdentifiers = new List<PractitionerIdentifierRequestDto>
                {
                    new PractitionerIdentifierRequestDto
                    {
                        IdentifierType="test",
                        IdentifierUse="test",
                        PeriodEnd=DateTime.UtcNow,
                        PeriodStart=DateTime.UtcNow,
                        System="test",
                        Value="demo"
                    }
                },
                newTimeOff = new List<TimeOffAddRequestDto>()


            };

            // Act
            var result = await service.UpdateScheduleLeaveAsync(request);

            // Assert
            result.Should().NotBeNull();
        }

        [Fact]
        public async Task UpdateScheduleLeaveAsync_ShouldReturnFailure_WhenSaveChangesFails()
        {
            // Arrange
            var request = new ScheduleLeavesRequestDto
            {
                practitionerId = 1,
                PractitionerIdentifiers = new List<PractitionerIdentifierRequestDto>
                {
                    new PractitionerIdentifierRequestDto
                    {
                        IdentifierType="test",
                        IdentifierUse="test",
                        PeriodEnd=DateTime.UtcNow,
                        PeriodStart=DateTime.UtcNow,
                        System="test",
                        Value="demo"
                    }
                },
                newTimeOff = new List<TimeOffAddRequestDto>
        {
            new TimeOffAddRequestDto
            {

                StartDateTime = DateTime.UtcNow,
                EndDateTime = DateTime.UtcNow.AddDays(1),
                Description = "Personal Leave",
                IsWorkingDay = false
            }
        }
            };

            var dbContextMock = new Mock<ReadWriteDbContext>(
                new DbContextOptionsBuilder<ReadWriteDbContext>()
                    .UseInMemoryDatabase(Guid.NewGuid().ToString())
                    .Options);

            var dbFacadeMock = new Mock<DatabaseFacade>(dbContextMock.Object);
            var transactionMock = new Mock<IDbContextTransaction>();
            dbFacadeMock.Setup(f => f.BeginTransactionAsync(default))
                        .ReturnsAsync(transactionMock.Object);

            dbContextMock.SetupGet(x => x.Database).Returns(dbFacadeMock.Object);
            dbContextMock.Setup(x => x.SaveChangesAsync(default)).ThrowsAsync(new Exception("Save failure"));

            var service = new ScheduleCommandService(
                dbContextMock.Object,
                _azureBusCommandServicesMock.Object,
                _mockConfiguration.Object
                );

            // Act
            var result = await service.UpdateScheduleLeaveAsync(request);

            // Assert
            result.result.Should().BeFalse();
            result.message.Should().Be(CommonConstants.Failed);
            transactionMock.Verify(x => x.RollbackAsync(It.IsAny<CancellationToken>()), Times.Once);
        }
        [Fact]
        public async Task UpdateScheduleLeaveAsync_NullRequest_ReturnsFalse()
        {
            var options = new DbContextOptionsBuilder<ReadWriteDbContext>()
       .UseInMemoryDatabase(databaseName: Guid.NewGuid().ToString())
         .ConfigureWarnings(b => b.Ignore(InMemoryEventId.TransactionIgnoredWarning)).Options;

            await using var context = new ReadWriteDbContext(options);
            var service = new ScheduleCommandService(context, _azureBusCommandServicesMock.Object, _mockConfiguration.Object);
            var result = await service.UpdateScheduleLeaveAsync(null);
            result.result.Should().BeFalse();
            result.message.Should().Be(CommonConstants.DUPLICATE_NOTALLOWED);
        }


        [Fact]
        public async Task UpdateScheduleLeaveAsync_InvalidRequest_ReturnsFalse()
        {
            var options = new DbContextOptionsBuilder<ReadWriteDbContext>()
       .UseInMemoryDatabase(databaseName: Guid.NewGuid().ToString())
         .ConfigureWarnings(b => b.Ignore(InMemoryEventId.TransactionIgnoredWarning)).Options;

            await using var context = new ReadWriteDbContext(options);
            var service = new ScheduleCommandService(context, _azureBusCommandServicesMock.Object, _mockConfiguration.Object);
            var request = new ScheduleLeavesRequestDto { practitionerId = 1 }; // Assuming IsValidRequest returns false for this
            var result = await service.UpdateScheduleLeaveAsync(request);
            result.result.Should().BeFalse();
            result.message.Should().Be(CommonConstants.DUPLICATE_NOTALLOWED);
        }
        [Fact]
        public async Task UpdateScheduleLeaveAsync_ExceptionThrown_ReturnsFalse()
        {
            var options = new DbContextOptionsBuilder<ReadWriteDbContext>()
       .UseInMemoryDatabase(databaseName: Guid.NewGuid().ToString())
         .ConfigureWarnings(b => b.Ignore(InMemoryEventId.TransactionIgnoredWarning)).Options;

            await using var context = new ReadWriteDbContext(options);
            var service = new ScheduleCommandService(context, _azureBusCommandServicesMock.Object, _mockConfiguration.Object);
            _readWriteDbContextMock.Setup(m => m.SaveChangesAsync(default)).ThrowsAsync(new Exception("Test Exception"));

            var request = new ScheduleLeavesRequestDto
            {
                practitionerId = 1,
                removeTimeOff = new List<TimeOffUpdateRequestDto>(),
                newTimeOff = new List<TimeOffAddRequestDto>()
            };

            var result = await service.UpdateScheduleLeaveAsync(request);

            result.result.Should().BeFalse();
        }


        [Fact]
        public async Task UpdateScheduleLeaveAsync_ValidRequest_RemovesExistingLeave()
        {
            var options = new DbContextOptionsBuilder<ReadWriteDbContext>()
       .UseInMemoryDatabase(databaseName: Guid.NewGuid().ToString())
         .ConfigureWarnings(b => b.Ignore(InMemoryEventId.TransactionIgnoredWarning)).Options;

            await using var context = new ReadWriteDbContext(options);
            var service = new ScheduleCommandService(context, _azureBusCommandServicesMock.Object, _mockConfiguration.Object);
            // Arrange
            var now = DateTime.UtcNow;

            var request = new ScheduleLeavesRequestDto
            {
                practitionerId = 1,
                newTimeOff = new List<TimeOffAddRequestDto>
        {
            new TimeOffAddRequestDto
            {
                StartDateTime = now,
                EndDateTime = now.AddDays(1),
                Description = "Personal Leave",
                IsWorkingDay = true
            }
        },
                removeTimeOff = new List<TimeOffUpdateRequestDto>
        {
            new TimeOffUpdateRequestDto
            {
                StartDateTime = now,
                EndDateTime = now.AddHours(1),
                IsDelete = true,
                Description="Test demo"


            }
        }
            };

            var existingLeave = new PractitionerNotAvailable
            {
                PractitionerID = 1,
                StartDateTime = request.removeTimeOff.First().StartDateTime,
                EndDateTime = request.removeTimeOff.First().EndDateTime,
                IsDeleted = false,
                Description = "test",
                IsworkingDay = true,
                CreatedBy = "admin",
                UpdatedBy = "admin",
                UpdatedDate = DateTime.UtcNow,
                CreatedDate = DateTime.UtcNow,
            };
            context.PractitionerNotAvailables.Add(existingLeave);
            await context.SaveChangesAsync();
            // Act
            var result = await service.UpdateScheduleLeaveAsync(request);

            // Assert
            result.result.Should().BeTrue();

            existingLeave.IsDeleted.Should().BeTrue();
        }
        [Fact]
        public async Task UpdateScheduleLeaveAsync_Should_Add_New_Leaves_When_Request_Is_Valid()
        {
            var options = new DbContextOptionsBuilder<ReadWriteDbContext>()
       .UseInMemoryDatabase(databaseName: Guid.NewGuid().ToString())
         .ConfigureWarnings(b => b.Ignore(InMemoryEventId.TransactionIgnoredWarning)).Options;

            await using var context = new ReadWriteDbContext(options);
            var service = new ScheduleCommandService(context, _azureBusCommandServicesMock.Object, _mockConfiguration.Object);
            var practitionerId = 1;
            var newLeaves = new List<TimeOffAddRequestDto>
            {
                new TimeOffAddRequestDto
                {
                    StartDateTime = DateTime.UtcNow.AddDays(1),
                    EndDateTime = DateTime.UtcNow.AddDays(1).AddHours(2),
                    Description = "Leave for conference",
                    IsWorkingDay = false
                }
            };

            var request = new ScheduleLeavesRequestDto
            {
                Action = "Add",
                Type = "Leave",
                practitionerId = practitionerId,
                LocationResourceId = "LOC001",
                newTimeOff = newLeaves,
                removeTimeOff = new List<TimeOffUpdateRequestDto>(),
                NewOverrides = "",
                RemovedOverrides = "",
                PractitionerIdentifiers = new List<PractitionerIdentifierRequestDto>()
            };

            _readWriteDbContextMock.Setup(x => x.PractitionerNotAvailables.AddRangeAsync(It.IsAny<IEnumerable<PractitionerNotAvailable>>(), default));
            _readWriteDbContextMock.Setup(m => m.SaveChangesAsync(default)).ReturnsAsync(1);

            var result = await service.UpdateScheduleLeaveAsync(request);

            result.result.Should().BeTrue();
            result.message.Should().Be(CommonConstants.SUCCESS);
            // _readWriteDbContextMock.Verify(m => m.SaveChangesAsync(default), Times.Once);
        }
        [Fact]
        public async Task UpdateScheduleLeaveAsync_ValidRequest_ExceptionExistingLeave()
        {

            // Arrange
            var options = new DbContextOptionsBuilder<ReadWriteDbContext>()
       .UseInMemoryDatabase(databaseName: Guid.NewGuid().ToString())
         .ConfigureWarnings(b => b.Ignore(InMemoryEventId.TransactionIgnoredWarning)).Options;

            await using var context = new ReadWriteDbContext(options);
            var service = new ScheduleCommandService(context, _azureBusCommandServicesMock.Object, _mockConfiguration.Object);
            var now = DateTime.UtcNow;

            var request = new ScheduleLeavesRequestDto
            {
                practitionerId = 1,
                newTimeOff = new List<TimeOffAddRequestDto>
        {
            new TimeOffAddRequestDto
            {
                StartDateTime = now,
                EndDateTime = now.AddDays(1),
                Description = "Personal Leave",
                IsWorkingDay = true
            }
        },
                removeTimeOff = new List<TimeOffUpdateRequestDto>
        {
            new TimeOffUpdateRequestDto
            {
                StartDateTime = now,
                EndDateTime = now.AddHours(1)

            }
        }
            };

            var existingLeave = new PractitionerNotAvailable
            {
                PractitionerID = 1,
                StartDateTime = request.removeTimeOff.First().StartDateTime,
                EndDateTime = request.removeTimeOff.First().EndDateTime,
                IsDeleted = false,
                Description = "test",
                IsworkingDay = true,
                CreatedBy = "admin",
                UpdatedBy = "admin",
                UpdatedDate = DateTime.UtcNow,
                CreatedDate = DateTime.UtcNow,
            };
            _readWriteDbContextMock.Setup(x => x.PractitionerNotAvailables.AddRangeAsync(It.IsAny<IEnumerable<PractitionerNotAvailable>>(), default));
            _readWriteDbContextMock.Setup(m => m.SaveChangesAsync(default)).ReturnsAsync(1);

            var result = await service.UpdateScheduleLeaveAsync(request);


            // Assert
            result.result.Should().BeTrue();

            existingLeave.IsDeleted.Should().BeFalse();
        }

        #region Update Schedule Details

        private static UpdateScheduleRequestDto GetValidRequestDto()
        {
            return new UpdateScheduleRequestDto
            {
                PractitionerId = 1,
                LocationId = "LOC001",
                Timezone = "Pune/MH",
                SlotDuration = 10,
                SlotType = "Consultation",
                BookableFor = "1,2,3,4",
                RequestableFor = "5,6,7,8,9",
                UpdatePractitionerAvailability = new UpdatePractitionerAvailabilityDto
                {
                    AvailabilityId = 7,
                    PractitionerRoleId = 11,
                    ScheduleStartDate = new DateTime(2025, 7, 1, 4, 14, 33, 244, DateTimeKind.Utc),
                    ScheduleEndDate = new DateTime(2025, 11, 29, 4, 14, 46, 502, DateTimeKind.Utc),
                    Instructions = "Updated Records deleted one, created one and one is kept as it is.",
                    RecordVersion = Convert.FromBase64String("AAAAAAAAw3c="),
                    IsDeleted = false,
                    UpdatePractitionerAvailabilityDays = new List<UpdatePractitionerAvailabilityDayDto>
                    {
                        new()
                        {
                            AvailabilityDayId = 3,
                            AvailabilityDay = "Monday",
                            DayStartTime = new TimeSpan(9, 0, 0),
                            DayEndTime = new TimeSpan(21, 0, 0),
                            IsDeleted = false,
                            PractitionerAvailabilityOccurances = new List<UpdatePractitionerAvailabilityOccuranceDto>
                            {
                                new() { OccuranceId = 3, OccuranceType = "first" },
                                new() { OccuranceId = 4, OccuranceType = "third" },
                                new() { OccuranceId = 5, OccuranceType = "every" }
                            },
                            PractitionerAvailabilityBreaks = new List<UpdatePractitionerAvailabilityBreakDto>
                            {
                                new() { AvailabilityBreakId = 3, BreakTitle = "Morning Tea", BreakStartTime = new TimeSpan(11, 0, 0), BreakEndTime =     new        TimeSpan(11, 15, 0) },
                                new() { AvailabilityBreakId = 4, BreakTitle = "Lunch", BreakStartTime = new TimeSpan(13, 0, 0), BreakEndTime = new      TimeSpan (14, 0, 0) },
                                new() { AvailabilityBreakId = 5, BreakTitle = "Evening Tea", BreakStartTime = new TimeSpan(17, 0, 0), BreakEndTime =     new        TimeSpan(17, 15, 0) }
                            }
                        },
                        new()
                        {
                            AvailabilityDayId = 4,
                            AvailabilityDay = "Tuesday",
                            DayStartTime = new TimeSpan(9, 0, 0),
                            DayEndTime = new TimeSpan(21, 0, 0),
                            IsDeleted = true,
                            PractitionerAvailabilityOccurances = new List<UpdatePractitionerAvailabilityOccuranceDto>
                            {
                                new() { OccuranceId = 6, OccuranceType = "second" },
                                new() { OccuranceId = 7, OccuranceType = "fourth" }
                            },
                            PractitionerAvailabilityBreaks = new List<UpdatePractitionerAvailabilityBreakDto>
                            {
                                new() { AvailabilityBreakId = 6, BreakTitle = "Brunch", BreakStartTime = new TimeSpan(12, 0, 0), BreakEndTime = new         TimeSpan    (12, 30, 0) },
                                new() { AvailabilityBreakId = 7, BreakTitle = "Snack Break", BreakStartTime = new TimeSpan(16, 0, 0), BreakEndTime =     new        TimeSpan(16, 15, 0) }
                            }
                        },
                        new()
                        {
                            AvailabilityDayId = 0,
                            AvailabilityDay = "Friday",
                            DayStartTime = new TimeSpan(9, 0, 0),
                            DayEndTime = new TimeSpan(21, 0, 0),
                            IsDeleted = false,
                            PractitionerAvailabilityOccurances = new List<UpdatePractitionerAvailabilityOccuranceDto>
                            {
                                new() { OccuranceId = 0, OccuranceType = "second" },
                                new() { OccuranceId = null, OccuranceType = "fourth" }
                            },
                            PractitionerAvailabilityBreaks = new List<UpdatePractitionerAvailabilityBreakDto>
                            {
                                new() { AvailabilityBreakId = 0, BreakTitle = "Brunch", BreakStartTime = new TimeSpan(12, 0, 0), BreakEndTime = new         TimeSpan    (12, 30, 0) },
                                new() { AvailabilityBreakId = null, BreakTitle = "Snack Break", BreakStartTime = new TimeSpan(16, 0, 0),    BreakEndTime =     new     TimeSpan(16, 15, 0) }
                            }
                        }
                    }
                }
            };
        }

        private static PractitionerAvailability GetAvailability()
        {
            return new PractitionerAvailability
            {
                Id = 7,
                PractitionerRoleId = 11,
                SlotsID = 2001,
                ScheduleStartDate = new DateTime(2025, 7, 1, 4, 14, 33, 244, DateTimeKind.Utc),
                ScheduleEndDate = new DateTime(2025, 11, 29, 4, 14, 46, 502, DateTimeKind.Utc),
                IsDeleted = false,
                CreatedBy = "admin",
                CreatedDate = DateTime.UtcNow,
                UpdatedBy = "admin",
                UpdatedDate = DateTime.UtcNow,
                RecordVersion = Convert.FromBase64String("AAAAAAAAw3c="),

                PractitionerAvailabilityDay = new List<PractitionerAvailabilityDay>
                {
                    new PractitionerAvailabilityDay
                    {
                        Id = 3,
                        PractitionerAvailabilityID = 7,
                        AvailabilityDay = "Monday",
                        StartTime = new TimeSpan(9, 0, 0),
                        EndTime = new TimeSpan(21, 0, 0),
                        AllDay = false,
                        IsDeleted = false,
                        CreatedBy = "admin",
                        CreatedDate = DateTime.UtcNow,
                        UpdatedBy = "admin",
                        UpdatedDate = DateTime.UtcNow,
                        PractitionerAvailabilityBreak = new List<PractitionerAvailabilityBreak>
                        {
                            new() { Id = 3, PractitionerAvailabilityDayID = 3, BreakTitle = "Morning Tea", StartTime = new TimeSpan(11, 0, 0),  EndTime = new TimeSpan(11, 15, 0), IsDeleted = false, CreatedBy = "admin", CreatedDate = DateTime.UtcNow, UpdatedBy = "Admin", UpdatedDate = DateTime.UtcNow },
                            new() { Id = 4, PractitionerAvailabilityDayID = 3, BreakTitle = "Lunch", StartTime = new TimeSpan(13, 0, 0), EndTime =  new TimeSpan(14, 0, 0), IsDeleted = false, CreatedBy = "admin", CreatedDate = DateTime.UtcNow, UpdatedBy = "Admin", UpdatedDate = DateTime.UtcNow },
                            new() { Id = 5, PractitionerAvailabilityDayID = 3, BreakTitle = "Evening Tea", StartTime = new TimeSpan(17, 0, 0),  EndTime = new TimeSpan(17, 15, 0), IsDeleted = false, CreatedBy = "admin", CreatedDate = DateTime.UtcNow, UpdatedBy = "Admin", UpdatedDate = DateTime.UtcNow }
                        },

                        PractitionerAvailabilityOccurance = new List<PractitionerAvailabilityOccurance>
                        {
                            new() { Id = 3, PractitionerAvailabilityDayID = 3, OccuranceType = "first", IsDeleted = false, CreatedBy = "admin",         CreatedDate = DateTime.UtcNow, UpdatedBy = "Admin", UpdatedDate = DateTime.UtcNow },
                            new() { Id = 4, PractitionerAvailabilityDayID = 3, OccuranceType = "third", IsDeleted = false, CreatedBy = "admin",         CreatedDate = DateTime.UtcNow, UpdatedBy = "Admin", UpdatedDate = DateTime.UtcNow },
                            new() { Id = 5, PractitionerAvailabilityDayID = 3, OccuranceType = "every", IsDeleted = false, CreatedBy = "admin",         CreatedDate = DateTime.UtcNow, UpdatedBy = "Admin", UpdatedDate = DateTime.UtcNow }
                        }
                    },

                    new PractitionerAvailabilityDay
                    {
                        Id = 4,
                        PractitionerAvailabilityID = 7,
                        AvailabilityDay = "Tuesday",
                        StartTime = new TimeSpan(9, 0, 0),
                        EndTime = new TimeSpan(21, 0, 0),
                        AllDay = false,
                        IsDeleted = true,
                        CreatedBy = "admin",
                        CreatedDate = DateTime.UtcNow,
                        UpdatedBy = "Admin",
                        UpdatedDate = DateTime.UtcNow,
                        PractitionerAvailabilityBreak = new List<PractitionerAvailabilityBreak>
                        {
                            new() { Id = 6, PractitionerAvailabilityDayID = 4, BreakTitle = "Brunch", StartTime = new TimeSpan(12, 0, 0), EndTime = new TimeSpan(12, 30, 0), IsDeleted = false, CreatedBy = "admin", CreatedDate = DateTime.UtcNow, UpdatedBy = "Admin", UpdatedDate = DateTime.UtcNow},
                            new() { Id = 7, PractitionerAvailabilityDayID = 4, BreakTitle = "Snack Break", StartTime = new TimeSpan(16, 0, 0),  EndTime =  new TimeSpan(16, 15, 0), IsDeleted = false, CreatedBy = "admin", CreatedDate = DateTime.UtcNow, UpdatedBy = "Admin", UpdatedDate = DateTime.UtcNow }
                        },

                        PractitionerAvailabilityOccurance = new List<PractitionerAvailabilityOccurance>
                        {
                            new() { Id = 6, PractitionerAvailabilityDayID = 4, OccuranceType = "second", IsDeleted = false, CreatedBy = "admin",        CreatedDate = DateTime.UtcNow, UpdatedBy = "Admin", UpdatedDate = DateTime.UtcNow },
                            new() { Id = 7, PractitionerAvailabilityDayID = 4, OccuranceType = "fourth", IsDeleted = false, CreatedBy = "admin",        CreatedDate = DateTime.UtcNow, UpdatedBy = "Admin", UpdatedDate = DateTime.UtcNow }
                        }
                    }
                }
            };

        }

        [Fact]
        public async Task UpdateScheduleAsync_ShouldReturnTrue_WhenValidDataIsProvided()
        {
            // Arrange
            var options = new DbContextOptionsBuilder<ReadWriteDbContext>()
                .UseInMemoryDatabase(databaseName: Guid.NewGuid().ToString())
                .ConfigureWarnings(w => w.Ignore(InMemoryEventId.TransactionIgnoredWarning))
                .EnableSensitiveDataLogging()
                .Options;

            using var context = new ReadWriteDbContext(options);

            var request = GetValidRequestDto();

            var availability = GetAvailability();

            context.PractitionerAvailabilities.Add(availability);
            await context.SaveChangesAsync();

            // Mock other dependencies
            var mockBus = new Mock<IAzureBusCommandServices>();
            var mockConfig = new Mock<IConfiguration>();

            var service = new ScheduleCommandService(context, mockBus.Object, mockConfig.Object);
            // Act
            var result = await service.UpdateScheduleAsync(request, availability);

            // Assert
            result.Should().BeTrue();

            var updatedAvailability = await context.PractitionerAvailabilities
                .Include(p => p.PractitionerAvailabilityDay)
                .FirstOrDefaultAsync(a => a.Id == 7);

            updatedAvailability.Should().NotBeNull();
            updatedAvailability.PractitionerAvailabilityDay.Should().HaveCount(3);
        }


        [Fact]
        public async Task ScheduleLeaveTimeOffServiceBusConnect_ValidInput_SendsPayloadAndReturnsSuccess()
        {
            // Arrange
            var newLeaves = new List<PractitionerNotAvailable>
    {
        new PractitionerNotAvailable
        {
            PractitionerID = 1,
            StartDateTime = DateTime.UtcNow.AddHours(2),
            EndDateTime = DateTime.UtcNow.AddHours(4),
            IsDeleted = false,
            Description = "demo",
            UpdatedBy = "admin",
            UpdatedDate = DateTime.UtcNow,
            IsworkingDay = false,
            CreatedBy = "admin",
            CreatedDate = DateTime.UtcNow
        }
    };

            var removedLeaves = new List<PractitionerNotAvailable>
    {
        new PractitionerNotAvailable
        {
            PractitionerID = 1,
            StartDateTime = DateTime.UtcNow.AddHours(5),
            EndDateTime = DateTime.UtcNow.AddHours(6),
            IsDeleted = false,
            Description = "demo",
            UpdatedBy = "admin",
            UpdatedDate = DateTime.UtcNow,
            IsworkingDay = false,
            CreatedBy = "admin",
            CreatedDate = DateTime.UtcNow
        }
    };

            var identifiers = new List<PractitionerIdentifierRequestDto>
    {
        new PractitionerIdentifierRequestDto
        {
            IdentifierType = "test",
            IdentifierUse = "test",
            PeriodEnd = DateTime.UtcNow,
            PeriodStart = DateTime.UtcNow,
            System = "test",
            Value = "demo"
        }
    };

            string locationResourceId = "test-location-id"; // Important

            // Mock config to return expected key
            _mockConfiguration
                .Setup(x => x[$"{CommonConstants.ServiceBusSection}:{CommonConstants.ScheduleLeaveTimeOffBusKey}"])
                .Returns("dummy-service-bus-key");

            // Mock the service bus call properly
            _azureBusCommandServicesMock
                .Setup(bus => bus.SendData(It.IsAny<ScheduleLeavesRequestDto>(), It.IsAny<string>(), It.IsAny<string>()))
                .ReturnsAsync(new GenericResponse<string>
                {
                    IsSuccess = true,
                    Result = "OK"
                });

            // Act
            var result = await _service.ScheduleLeaveTimeOffServiceBusConnect(
                newLeaves,
                removedLeaves,
                identifiers,
                locationResourceId,
                EventAction.Update);

            // Assert
            Assert.Equal(1, result);

            _azureBusCommandServicesMock.Verify(
                x => x.SendData(It.IsAny<ScheduleLeavesRequestDto>(), RegionCode.MALAYSIA_REGION_CODE, "dummy-service-bus-key"),
                Times.Once);
        }

        #endregion
    }
}
