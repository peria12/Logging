﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Aurora.AdministrationService.API.Services.Service.Schedule;
using Aurora.AdministrationService.Domain.V1.Entities.PractitionerRoles;
using Aurora.AdministrationService.Infrastructure;
using AutoMapper;
using Microsoft.EntityFrameworkCore.Infrastructure;
using Microsoft.EntityFrameworkCore.Storage;
using Microsoft.EntityFrameworkCore;
using Moq;
using Aurora.AdministrationService.API.Models.RequestModels.Schedules;
using FluentAssertions;
using Aurora.AdministrationService.API.Services.IService.AzureBus;
using Aurora.AdministrationService.API.Services.Service.Holiday;
using Microsoft.Extensions.Configuration;

namespace Aurora.AdministrationService.Tests.API.Services.Schedule
{
    public class ScheduleCommandServiceTests_Create_Schedule
    {
        private readonly Mock<DbSet<PractitionerAvailability>> _mockPractitionerAvailabilities;
        private readonly Mock<DbSet<PractitionerAvailabilityDay>> _mockPractitionerAvailabilityDays;
        private readonly Mock<DbSet<PractitionerAvailabilityOccurance>> _mockPractitionerAvailabilityOccurances;
        private readonly Mock<DbSet<PractitionerAvailabilityBreak>> _mockPractitionerAvailabilityBreaks;
        private readonly Mock<ReadWriteDbContext> _mockDbContext;
        private readonly Mock<DatabaseFacade> _mockDatabaseFacade;
        private readonly Mock<IDbContextTransaction> _mockTransaction;
        private readonly ScheduleCommandService _service;
        private readonly Mock<IMapper> _mapperMock;
        private readonly Mock<IAzureBusCommandServices> _azureBusCommandServicesMock;
        private readonly Mock<IConfiguration> _mockConfiguration;

        public ScheduleCommandServiceTests_Create_Schedule()
        {
            // Mock DbSets
            _mockPractitionerAvailabilities = new Mock<DbSet<PractitionerAvailability>>();
            _mockPractitionerAvailabilityDays = new Mock<DbSet<PractitionerAvailabilityDay>>();
            _mockPractitionerAvailabilityOccurances = new Mock<DbSet<PractitionerAvailabilityOccurance>>();
            _mockPractitionerAvailabilityBreaks = new Mock<DbSet<PractitionerAvailabilityBreak>>();


            var options = new DbContextOptionsBuilder<ReadWriteDbContext>()
            .UseInMemoryDatabase(Guid.NewGuid().ToString()) // Create a unique database for each test
            .Options;

            _mockDbContext = new Mock<ReadWriteDbContext>(options);
            _mockDatabaseFacade = new Mock<DatabaseFacade>(_mockDbContext.Object);
            _mockTransaction = new Mock<IDbContextTransaction>();
            _mapperMock = new Mock<IMapper>();
            _azureBusCommandServicesMock = new Mock<IAzureBusCommandServices>();
            _mockConfiguration = new Mock<IConfiguration>();



            // Mocking the BeginTransactionAsync() to return a mocked transaction
            _mockDatabaseFacade.Setup(db => db.BeginTransactionAsync(It.IsAny<CancellationToken>()))
                .ReturnsAsync(_mockTransaction.Object);

            _mockDbContext.Setup(x => x.Database).Returns(_mockDatabaseFacade.Object);

            _mockDbContext.Setup(db => db.SaveChangesAsync(It.IsAny<CancellationToken>()))
                .ReturnsAsync(1);

            // Set up the DbSets to return the mocked DbSets
            _mockDbContext.Setup(x => x.PractitionerAvailabilities).Returns(_mockPractitionerAvailabilities.Object);
            _mockDbContext.Setup(x => x.PractitionerAvailabilityDays).Returns(_mockPractitionerAvailabilityDays.Object);
            _mockDbContext.Setup(x => x.PractitionerAvailabilityOccurances).Returns(_mockPractitionerAvailabilityOccurances.Object);
            _mockDbContext.Setup(x => x.PractitionerAvailabilityBreaks).Returns(_mockPractitionerAvailabilityBreaks.Object);

            // Initialize the service with the mock context and userId
            _service = new ScheduleCommandService(_mockDbContext.Object,_azureBusCommandServicesMock.Object, _mockConfiguration.Object);
        }

        #region Create Schedule Command Service Tests

        [Fact]
        public async Task CreateSchedule_ShouldReturnTrue_WhenValidRequestIsProvided()
        {
            // Arrange
            var request = new CreateScheduleRequestDto
            {
                PractitionerId = 1,
                LocationId = "LOC001",
                SlotDuration = 15,
                SlotType = "Consult",
                Timezone = "Bukit/MYS",
                RequestableFor = "1,2,3,4,5",
                BookableFor = "6,7,8,9",
                PractitionerAvailability = new PractitionerAvailabilityDto
                {
                    PractitionerRoleId = 1,
                    ScheduleStartDate = DateTime.Today,
                    ScheduleEndDate = DateTime.Today.AddDays(10),
                    PractitionerAvailabilityDays = new List<PractitionerAvailabilityDayDto>
                    {
                        new PractitionerAvailabilityDayDto
                        {
                            AvailabilityDay = "Monday",
                            DayStartTime = new TimeSpan(12, 0, 0),
                            DayEndTime = new TimeSpan(14, 30, 0),
                            PractitionerAvailabilityBreaks = new List<PractitionerAvailabilityBreakDto>
                            {
                                new PractitionerAvailabilityBreakDto
                                {
                                    BreakTitle = "Lunch Break",
                                    BreakStartTime = TimeSpan.FromHours(13),
                                    BreakEndTime = TimeSpan.FromHours(14)
                                }
                            },
                            PractitionerAvailabilityOccurances = new List<PractitionerAvailabilityOccuranceDto>
                            {
                                new PractitionerAvailabilityOccuranceDto
                                {
                                    OccuranceType = "first"
                                }
                            }
                        }
                    },
                }
            };

            // Act
            var result = await _service.CreateScheduleAsync(request);

            // Assert
            result.Should().BeTrue();
        }

        [Fact]
        public async Task CreateSchedule_ShouldReturnFalse_WhenDatabaseSaveFails()
        {
            // Arrange
            var request = new CreateScheduleRequestDto
            {
                PractitionerId = 1,
                LocationId = "LOC001",
                SlotDuration = 15,
                SlotType = "Consult",
                Timezone = "Bukit/MYS",
                RequestableFor = "1,2,3,4,5",
                BookableFor = "6,7,8,9",
                PractitionerAvailability = new PractitionerAvailabilityDto
                {
                    PractitionerRoleId = 1,
                    ScheduleStartDate = DateTime.Today,
                    ScheduleEndDate = DateTime.Today.AddDays(10),
                    PractitionerAvailabilityDays = new List<PractitionerAvailabilityDayDto>
                    {
                        new PractitionerAvailabilityDayDto
                        {
                            AvailabilityDay = "Monday",
                            DayStartTime = new TimeSpan(12, 0, 0),
                            DayEndTime = new TimeSpan(14, 30, 0),
                            PractitionerAvailabilityBreaks = new List<PractitionerAvailabilityBreakDto>
                            {
                                new PractitionerAvailabilityBreakDto
                                {
                                    BreakTitle = "Lunch Break",
                                    BreakStartTime = TimeSpan.FromHours(13),
                                    BreakEndTime = TimeSpan.FromHours(14)
                                }
                            },
                            PractitionerAvailabilityOccurances = new List<PractitionerAvailabilityOccuranceDto>
                            {
                                new PractitionerAvailabilityOccuranceDto
                                {
                                    OccuranceType = "first"
                                }
                            }
                        }
                    }
                }
            };

            // Simulating a failure during SaveChangesAsync (database failure)
            _mockDbContext.Setup(db => db.SaveChangesAsync(It.IsAny<CancellationToken>()))
                .ThrowsAsync(new InvalidOperationException("Database save failed"));

            // Act
            Func<Task> act = async () => await _service.CreateScheduleAsync(request);

            // Assert
            // We expect the exception to be thrown and handled by the service
            await act.Should().ThrowAsync<InvalidOperationException>()
                .WithMessage("An Error Occured While saving the Schedule:Database save failed.");
        }
        #endregion
    }
}
