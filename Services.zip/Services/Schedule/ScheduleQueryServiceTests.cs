﻿using System.Globalization;
using System.Net;
using System.Reflection;
using Aurora.AdministrationService.API.Models.RequestModels.Leaves;
using Aurora.AdministrationService.API.Models.RequestModels.Schedules;
using Aurora.AdministrationService.API.Models.ResponseModels.Schedules;
using Aurora.AdministrationService.API.Models.ResponseModels.ServiceCommunication.Appoinment;
using Aurora.AdministrationService.API.Models.ResponseModels.ServiceCommunication.Holiday;
using Aurora.AdministrationService.API.Models.ResponseModels.ServiceCommunication.PractitionerException;
using Aurora.AdministrationService.API.Services.Service.Schedule;
using Aurora.AdministrationService.CrossCutting.Constants;
using Aurora.AdministrationService.CrossCutting.HttpService;
using Aurora.AdministrationService.Domain.V1.Entities.Locations;
using Aurora.AdministrationService.Domain.V1.Entities.PractitionerRoles;
using Aurora.AdministrationService.Domain.V1.Entities.Practitioners;
using Aurora.AdministrationService.Infrastructure;
using FluentAssertions;
using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.Logging;
using Moq;
using Newtonsoft.Json;

namespace Aurora.AdministrationService.Tests.API.Services.Schedule
{
    public class ScheduleQueryServiceTests
    {
            private readonly ReadOnlyDbContext _mockDbContext;
            private readonly ScheduleQueryService _scheduleQueryService;
            private readonly Mock<IHttpClientService> _httpClientServiceMock;
            private readonly Mock<ILogger<ScheduleQueryService>> _loggerMock;
            private readonly Mock<IConfiguration> _configurationMock;
            public ScheduleQueryServiceTests()
            {
                _httpClientServiceMock = new Mock<IHttpClientService>();
                _loggerMock = new Mock<ILogger<ScheduleQueryService>>();
                _configurationMock = new Mock<IConfiguration>();
                // Set up in-memory database
                var options = new DbContextOptionsBuilder<ReadOnlyDbContext>()
                    .UseInMemoryDatabase(databaseName: Guid.NewGuid().ToString())
                    .Options;

                _mockDbContext = new ReadOnlyDbContext(options);
                // Set up the mock for HealthcareServices DbSet
                var hcs1 = new Domain.V1.Entities.HealthcareService.HealthcareServices { ID = 1, Name = "Service 1", Location = "Location 1", CreatedBy = "Admin", IsDeleted = false, CreatedDate = DateTime.UtcNow, RecordVersion = Array.Empty<byte>(), Status = true };
                var hcs2 = new Domain.V1.Entities.HealthcareService.HealthcareServices { ID = 2, Name = "Service 2", Location = "Location 2", CreatedBy = "Admin", IsDeleted = false, CreatedDate = DateTime.UtcNow, RecordVersion = Array.Empty<byte>(), Status = true };
                var hcs3 = new Domain.V1.Entities.HealthcareService.HealthcareServices { ID = 3, Name = "Service 3", Location = "Location 3", CreatedBy = "Admin", IsDeleted = true, CreatedDate = DateTime.UtcNow, RecordVersion = Array.Empty<byte>(), Status = true };

                _mockDbContext.HealthcareServices.Add(hcs1);
                _mockDbContext.HealthcareServices.Add(hcs2);
                _mockDbContext.HealthcareServices.Add(hcs3);
                _mockDbContext.SaveChanges();

                // Initialize the service
                _scheduleQueryService = new ScheduleQueryService(_mockDbContext, _httpClientServiceMock.Object, _configurationMock.Object, _loggerMock.Object);
                SeedDatabase();
            }

            private void SeedDatabase()
        {
            var practitioner = new Practitioner
            {
                Id = 11,
                ResourceID = "123",
                Status = true,
                Gender = "Male",
                BirthDate = new DateTime(1985, 5, 10, 1, 1, 1, DateTimeKind.Utc),
                Source = "Internal",
                IsDeleted = false,
                CreatedBy = "Admin",
                CreatedDate = DateTime.UtcNow,
                UpdatedBy = "Admin",
                UpdatedDate = DateTime.UtcNow
            };
            _mockDbContext.Practitioners.Add(practitioner);

            var practitionerName = new PractitionerNames
            {
                Id = 1,
                PractitionerID = practitioner.Id,
                Use = "Official",
                FamilyName = "Doe",
                GivenName = "John",
                MiddleName = "A.",
                Prefix = "Dr.",
                Suffix = "MD",
                Language = "en",
                PeriodStart = DateTime.UtcNow,
                PeriodEnd = DateTime.UtcNow.AddMonths(12),
                IsDeleted = false,
                CreatedBy = "UnitTest",
                CreatedDate = DateTime.UtcNow,
                UpdatedBy = "UnitTest",
                UpdatedDate = DateTime.UtcNow,
                Status = true
            };

            _mockDbContext.PractitionerName.Add(practitionerName);

            var location = new Location
            {
                Id = 1,
                ResourceID = "KLAN",
                Status = true,
                OperationalStatus = "Operational",
                Name = "Main Office",
                Alias = "HQ",
                Description = "Main office for healthcare services",
                Mode = "In-person",
                Longitude = -74.0060m,
                Latitude = 40.7128m,
                Altitude = 33.0m,
                PhysicalType = "Building",
                ManagingOrganization = Guid.NewGuid(),
                PartOf = "Healthcare System A",
                AvailabilityExceptions = "Closed on public holidays",
                Source = "Internal",
                URL = "https://www.example.com",
                IsDeleted = false,
                CreatedBy = "Admin",
                CreatedDate = DateTime.UtcNow,
                UpdatedBy = "Admin",
                UpdatedDate = DateTime.UtcNow
            };
            _mockDbContext.Locations.Add(location);

            var locationAddress = new LocationAddress
            {
                Id = 1,
                LocationID = location.Id,
                Use = "Home",
                Type = "Physical",
                Line1 = "123 Main Street",
                Line2 = "Suite 5B",
                Line3 = null,
                Line4 = null,
                City = "Kuala Lumpur",
                State = "Federal Territory",
                District = "KL Central",
                PostalCode = "50000",
                Country = "Malaysia",
                PeriodStart = DateTime.UtcNow,
                PeriodEnd = DateTime.UtcNow.AddMonths(12),
                Status = true,
                RecordVersion = new byte[] { 1, 2, 3, 4 },
                IsDeleted = false,
                CreatedBy = "UnitTest",
                CreatedDate = DateTime.UtcNow,
                UpdatedBy = "UnitTest",
                UpdatedDate = DateTime.UtcNow
            };

            _mockDbContext.LocationAddresses.Add(locationAddress);

            var healthcareService = new Domain.V1.Entities.HealthcareService.HealthcareServices
            {
                ID = 11,
                Name = "Cardio",
                LaymanDescription = "Cardiology-Specialists for heart",
                Location = "Main Office",
                Status = true,
                RecordVersion = Array.Empty<byte>(),
                IsDeleted = false,
                CreatedBy = "Admin",
                CreatedDate = DateTime.UtcNow,
                UpdatedBy = "Admin",
                UpdatedDate = DateTime.UtcNow
            };

            _mockDbContext.HealthcareServices.Add(healthcareService);

            var practitionerRole = new PractitionerRole
            {
                Id = 1,
                UUID = Guid.NewGuid(),
                PractitionerID = practitioner.ResourceID,
                LocationID = location.ResourceID,
                OrganizationID = 123,
                PeriodStart = DateTime.UtcNow,
                PeriodEnd = DateTime.UtcNow.AddYears(1),
                Active = true,
                AvailabilityExceptions = "None",
                IsDeleted = false,
                CreatedBy = "Admin",
                CreatedDate = DateTime.UtcNow,
                UpdatedBy = "Admin",
                UpdatedDate = DateTime.UtcNow,
                Practitioner = practitioner,
                Location = location
            };
            var practitionerRoleCodes = new PractitionerRoleCode
            {
                Id = 1,
                PractitionerRoleID = practitionerRole.Id,
                Code = "Doctor",
                IsDeleted = false,
                CreatedBy = "admin",
                CreatedDate = DateTime.UtcNow,
                UpdatedBy = "admin",
                UpdatedDate = DateTime.UtcNow
            };

            var roleMaster = new RoleMaster
            {
                Id = 1,
                Code = "Doctor",
                Definition = "Role Doctor",
                IsDeleted = false,
                CreatedBy = "admin",
                CreatedDate = DateTime.UtcNow
            };
            _mockDbContext.RoleMasters.Add(roleMaster);

            _mockDbContext.PractitionerRoles.Add(practitionerRole);
            _mockDbContext.PractitionerRoleCodes.Add(practitionerRoleCodes);

            // Adding PractitionerRoleSpecialty data
            var practitionerRoleSpecialty = new PractitionerRoleSpecialty
            {
                Id = 1,
                PractitionerRoleID = practitionerRole.Id,
                Specialty = healthcareService.Name,
                RecordVersion = Array.Empty<byte>(),
                IsDeleted = false,
                CreatedBy = "Admin",
                CreatedDate = DateTime.UtcNow,
                UpdatedBy = "Admin",
                UpdatedDate = DateTime.UtcNow
            };

            _mockDbContext.PractitionerRoleSpecialty.Add(practitionerRoleSpecialty);

            // Link HealthcareService to PractitionerRoleSpecialty (if needed)
            practitionerRoleSpecialty.HealthcareService = healthcareService;

            var practitionerAvailability1 = new PractitionerAvailability
            {
                Id = 1,
                PractitionerRoleId = 1,
                SlotsID = 1,
                ScheduleStartDate = new DateTime(2025, 01, 01, 0, 0, 0, DateTimeKind.Utc),
                ScheduleEndDate = DateTime.Today.AddDays(7),
                Instruction = "General availability",
                IsDeleted = false,
                CreatedBy = "Admin",
                CreatedDate = DateTime.UtcNow,
                UpdatedBy = "Admin",
                UpdatedDate = DateTime.UtcNow
            };
            var practitionerAvailability2 = new PractitionerAvailability
            {
                Id = 2,
                PractitionerRoleId = 1,
                SlotsID = 1,
                ScheduleStartDate = new DateTime(2025, 01, 01, 0, 0, 0, DateTimeKind.Utc),
                ScheduleEndDate = DateTime.Today.AddDays(7),
                Instruction = "test availability",
                IsDeleted = true,
                CreatedBy = "Admin",
                CreatedDate = DateTime.UtcNow,
                UpdatedBy = "Admin",
                UpdatedDate = DateTime.UtcNow
            };
            _mockDbContext.PractitionerAvailabilities.Add(practitionerAvailability1);
            _mockDbContext.PractitionerAvailabilities.Add(practitionerAvailability2);

            var availabilityDay1 = new PractitionerAvailabilityDay
            {
                Id = 1,
                PractitionerAvailabilityID = practitionerAvailability1.Id,
                AvailabilityDay = "Monday",
                StartTime = new TimeSpan(9, 30, 0),
                EndTime = new TimeSpan(12, 30, 0),
                AllDay = false,
                IsDeleted = false,
                CreatedBy = "Admin",
                CreatedDate = DateTime.UtcNow,
                UpdatedBy = "Admin",
                UpdatedDate = DateTime.UtcNow
            };
            var availabilityDay2 = new PractitionerAvailabilityDay
            {
                Id = 2,
                PractitionerAvailabilityID = practitionerAvailability1.Id,
                AvailabilityDay = "Tuesday",
                StartTime = new TimeSpan(9, 30, 0),
                EndTime = new TimeSpan(15, 30, 0),
                AllDay = false,
                IsDeleted = false,
                CreatedBy = "Admin",
                CreatedDate = DateTime.UtcNow,
                UpdatedBy = "Admin",
                UpdatedDate = DateTime.UtcNow
            };
            var availabilityDay3 = new PractitionerAvailabilityDay
            {
                Id = 3,
                PractitionerAvailabilityID = practitionerAvailability2.Id,
                AvailabilityDay = "Friday",
                StartTime = new TimeSpan(9, 30, 0),
                EndTime = new TimeSpan(15, 30, 0),
                AllDay = false,
                IsDeleted = false,
                CreatedBy = "Admin",
                CreatedDate = DateTime.UtcNow,
                UpdatedBy = "Admin",
                UpdatedDate = DateTime.UtcNow
            };
            _mockDbContext.PractitionerAvailabilityDays.Add(availabilityDay1);
            _mockDbContext.PractitionerAvailabilityDays.Add(availabilityDay2);
            _mockDbContext.PractitionerAvailabilityDays.Add(availabilityDay3);

            var availabilityOccurance1 = new PractitionerAvailabilityOccurance
            {
                Id = 1,
                PractitionerAvailabilityDayID = availabilityDay1.Id,
                OccuranceType = "First",
                IsDeleted = false,
                CreatedBy = "Admin",
                CreatedDate = DateTime.UtcNow,
                UpdatedBy = "Admin",
                UpdatedDate = DateTime.UtcNow
            };

            var availabilityOccurance2 = new PractitionerAvailabilityOccurance
            {
                Id = 2,
                PractitionerAvailabilityDayID = availabilityDay2.Id,
                OccuranceType = "Fifth",
                IsDeleted = false,
                CreatedBy = "Admin",
                CreatedDate = DateTime.UtcNow,
                UpdatedBy = "Admin",
                UpdatedDate = DateTime.UtcNow
            };
            var availabilityOccurance3 = new PractitionerAvailabilityOccurance
            {
                Id = 3,
                PractitionerAvailabilityDayID = availabilityDay2.Id,
                OccuranceType = "All",
                IsDeleted = false,
                CreatedBy = "Admin",
                CreatedDate = DateTime.UtcNow,
                UpdatedBy = "Admin",
                UpdatedDate = DateTime.UtcNow
            };
            var availabilityOccurance4 = new PractitionerAvailabilityOccurance
            {
                Id = 4,
                PractitionerAvailabilityDayID = availabilityDay1.Id,
                OccuranceType = "All",
                IsDeleted = false,
                CreatedBy = "Admin",
                CreatedDate = DateTime.UtcNow,
                UpdatedBy = "Admin",
                UpdatedDate = DateTime.UtcNow
            };
            _mockDbContext.PractitionerAvailabilityOccurances.Add(availabilityOccurance1);
            _mockDbContext.PractitionerAvailabilityOccurances.Add(availabilityOccurance2);
            _mockDbContext.PractitionerAvailabilityOccurances.Add(availabilityOccurance3);
            _mockDbContext.PractitionerAvailabilityOccurances.Add(availabilityOccurance4);

            var availabilityBreak = new PractitionerAvailabilityBreak
            {
                Id = 1,
                PractitionerAvailabilityDayID = availabilityDay1.Id,
                BreakTitle = "Lunch Break",
                StartTime = new TimeSpan(12, 0, 0),
                EndTime = new TimeSpan(12, 30, 0),
                IsDeleted = false,
                CreatedBy = "Admin",
                CreatedDate = DateTime.UtcNow,
                UpdatedBy = "Admin",
                UpdatedDate = DateTime.UtcNow
            };
            _mockDbContext.PractitionerAvailabilityBreaks.Add(availabilityBreak);

            var availabilityBreak1 = new PractitionerAvailabilityBreak
            {
                Id = 11,
                PractitionerAvailabilityDayID = availabilityDay2.Id,
                BreakTitle = "Coffee Break",
                StartTime = new TimeSpan(12, 0, 0),
                EndTime = new TimeSpan(12, 30, 0),
                IsDeleted = false,
                CreatedBy = "Admin",
                CreatedDate = DateTime.UtcNow,
                UpdatedBy = "Admin",
                UpdatedDate = DateTime.UtcNow
            };
            _mockDbContext.PractitionerAvailabilityBreaks.Add(availabilityBreak1);

            // Adding Practitioner Not Available Slots
            var practitionerNotAvailable1 = new PractitionerNotAvailable
            {
                Id = 11,
                PractitionerID = practitioner.Id,
                StartDateTime = new DateTime(2025, 03, 11, 0, 0, 0, DateTimeKind.Utc),
                EndDateTime = new DateTime(2025, 03, 15, 0, 0, 0, DateTimeKind.Utc),
                Description = "Emergency",
                IsworkingDay = false,
                IsDeleted = false,
                CreatedBy = "Admin",
                CreatedDate = DateTime.UtcNow,
                UpdatedBy = "Admin",
                UpdatedDate = DateTime.UtcNow
            };
            var practitionerNotAvailable2 = new PractitionerNotAvailable
            {
                Id = 12,
                PractitionerID = practitioner.Id,
                StartDateTime = new DateTime(2025, 03, 17, 12, 0, 0, DateTimeKind.Utc),
                EndDateTime = new DateTime(2025, 03, 17, 12, 30, 0, DateTimeKind.Utc),
                Description = "Lunch Break",
                IsworkingDay = true,
                IsDeleted = false,
                CreatedBy = "Admin",
                CreatedDate = DateTime.UtcNow,
                UpdatedBy = "Admin",
                UpdatedDate = DateTime.UtcNow
            };
            _mockDbContext.PractitionerNotAvailables.Add(practitionerNotAvailable1);
            _mockDbContext.PractitionerNotAvailables.Add(practitionerNotAvailable2);

            var practitionerIdentifier = new PractitionerIdentifier
            {
                PractitionerID = practitioner.Id,

                Value = "ABC",
                Id = 3,
                IdentifierUse = "test",
                IdentifierType = "Test",
                PeriodEnd = DateTime.Now,
                PeriodStart = DateTime.Now,
                Status = true,
                CreatedBy = "admin",
                UpdatedBy = "admin",
                CreatedDate = DateTime.Now,
                System = "test",
                IsDeleted = false
            };

            _mockDbContext.PractitionerIdentifiers.Add(practitionerIdentifier);
            _mockDbContext.SaveChanges();
        }


        [Fact]
        public void GetAllUserGroups_ShouldReturnListOfUserGroups()
        {
            // Act
            List<GetAllUserGroupsResponse> result = _scheduleQueryService.GetAllUserGroups();

            // Assert
            Assert.NotNull(result);
            Assert.True(result.Count > 0);
        }
        // Test for GetAllHealthCareServices method
        [Fact]
        public void GetAllHealthCareServices_ShouldReturnNonDeletedHealthCareServices()
        {
            // Act
            var result = _scheduleQueryService.GetHealthCareServices();

            // Assert
            Assert.NotNull(result);
        }
        [Fact]
        public void GetScheduleLeaveAsync_ReturnsEmptyList_WhenNoSchedulesFound()
        {
            // Arrange
            // _scheduleQueryService.Clear(); // No schedules


            // Act
            var result = _scheduleQueryService.GetScheduleLeaveService(3, "ABC123");

            // Assert
            Assert.NotNull(result);
            Assert.Empty(result);
        }

        [Fact]
        public void GetScheduleLeaveAsync_ReturnsList_WhenSchedulesFound()
        {
            // Act
            var result = _scheduleQueryService.GetScheduleLeaveService(11, "KLAN");

            // Assert
            Assert.NotNull(result);
            Assert.Single(result);
            Assert.Equal("Lunch Break", result[0].Description);
            Assert.True(result[0].IsWorkingDay);
        }
        [Fact]
        public void GetHasValidPractitionerIdentifierAsync_ReturnsList_WhenSchedulesFound()
        {
            var leavesRequestDto = new ScheduleLeavesRequestDto
            {
                practitionerId = 1,
            };

            // Act
            var result = _scheduleQueryService.HasValidPractitionerIdentifier(leavesRequestDto);

            // Assert
            Assert.NotNull(result);
        }
        [Fact]
        public async Task IsDuplicateLeaveAsync_ShouldReturnFalse_WhenCreateRequestIsNull()
        {
            // Act
            var result = await _scheduleQueryService.IsDuplicateLeaveAsync(null);

            // Assert
            Assert.False(result);
        }
        [Fact]
        public async Task IsDuplicateLeaveAsync_ShouldReturnTrue_WhenOverlappingLeavesExist()
        {
            // Arrange
            var request = new ScheduleLeavesRequestDto
            {
                practitionerId = 3,
                newTimeOff = new List<TimeOffAddRequestDto>
            {
                new TimeOffAddRequestDto
                {

                    IsWorkingDay= true,
                   StartDateTime = new DateTime(2025, 03, 12, 1, 0, 0, DateTimeKind.Utc),
                   EndDateTime = new DateTime(2025, 03, 12, 3, 0, 0, DateTimeKind.Utc),
                   Description="test",
                },
                new TimeOffAddRequestDto
                {

                    IsWorkingDay= true,
                   StartDateTime = new DateTime(2025, 03, 12, 4, 0, 0, DateTimeKind.Utc),
                   EndDateTime = new DateTime(2025, 03, 12, 5, 0, 0, DateTimeKind.Utc),
                   Description="test",
                }
            }
            };

            // Act
            var result = await _scheduleQueryService.IsDuplicateLeaveAsync(request);

            // Assert
            result.Should().BeFalse();
        }

        #region Create Schedule Validation Query Test Cases
        [Fact]
        public async Task IsTimeOverlapping_ShouldReturnFalse_WhenNoConflictingSchedulesExist()
        {
            var request = new CreateScheduleRequestDto
            {
                PractitionerId = 1,
                LocationId = "LOC001",
                SlotDuration = 15,
                SlotType = "Consult",
                Timezone = "Bukit/MYS",
                RequestableFor = "1,2,3,4,5",
                BookableFor = "6,7,8,9",
                PractitionerAvailability = new PractitionerAvailabilityDto
                {
                    PractitionerRoleId = 1,
                    ScheduleStartDate = DateTime.Today.AddDays(8),
                    ScheduleEndDate = DateTime.Today.AddDays(15),
                    PractitionerAvailabilityDays = new List<PractitionerAvailabilityDayDto>
                    {
                        new PractitionerAvailabilityDayDto
                        {
                            AvailabilityDay = "Monday",
                            DayStartTime = new TimeSpan(9, 30, 0),
                            DayEndTime = new TimeSpan(10, 30, 0),
                            PractitionerAvailabilityBreaks = new List<PractitionerAvailabilityBreakDto>
                            {
                                new PractitionerAvailabilityBreakDto
                                {
                                    BreakTitle = "Lunch Break",
                                    BreakStartTime = TimeSpan.FromHours(13),
                                    BreakEndTime = TimeSpan.FromHours(14)
                                }
                            }
                        }
                    }
                }
            };

            var result = await _scheduleQueryService.IsTimeOverlapping(request);

            result.Should().BeFalse();
        }

        [Fact]
        public async Task IsTimeOverlapping_ShouldReturnTrue_WhenDateRangesOverlapAndTimeOverlaps()
        {
            var request = new CreateScheduleRequestDto
            {
                PractitionerId = 1,
                LocationId = "LOC001",
                SlotDuration = 15,
                SlotType = "Consult",
                Timezone = "Bukit/MYS",
                RequestableFor = "1,2,3,4,5",
                BookableFor = "6,7,8,9",
                PractitionerAvailability = new PractitionerAvailabilityDto
                {
                    PractitionerRoleId = 1,
                    ScheduleStartDate = DateTime.Today,
                    ScheduleEndDate = DateTime.Today.AddDays(10),
                    PractitionerAvailabilityDays = new List<PractitionerAvailabilityDayDto>
                    {
                        new PractitionerAvailabilityDayDto
                        {
                            AvailabilityDay = "Monday",
                            DayStartTime = new TimeSpan(9, 0, 0),
                            DayEndTime = new TimeSpan(11, 30, 0),
                            PractitionerAvailabilityBreaks = new List<PractitionerAvailabilityBreakDto>
                            {
                                new PractitionerAvailabilityBreakDto
                                {
                                    BreakTitle = "Lunch Break",
                                    BreakStartTime = TimeSpan.FromHours(13),
                                    BreakEndTime = TimeSpan.FromHours(14)
                                }
                            },
                            PractitionerAvailabilityOccurances = new List<PractitionerAvailabilityOccuranceDto>
                            {
                                new PractitionerAvailabilityOccuranceDto
                                {
                                    OccuranceType = "first"
                                }
                            }
                        }
                    },

                }
            };

            var result = await _scheduleQueryService.IsTimeOverlapping(request);

            result.Should().BeTrue();
        }

        [Fact]
        public async Task IsTimeOverlapping_ShouldReturnFalse_WhenSameDaysButDifferentTimes()
        {
            var request = new CreateScheduleRequestDto
            {
                PractitionerId = 1,
                LocationId = "LOC001",
                SlotDuration = 15,
                SlotType = "Consult",
                Timezone = "Bukit/MYS",
                RequestableFor = "1,2,3,4,5",
                BookableFor = "6,7,8,9",
                PractitionerAvailability = new PractitionerAvailabilityDto
                {
                    PractitionerRoleId = 1,
                    ScheduleStartDate = DateTime.Today,
                    ScheduleEndDate = DateTime.Today.AddDays(10),
                    PractitionerAvailabilityDays = new List<PractitionerAvailabilityDayDto>
                    {
                        new PractitionerAvailabilityDayDto
                        {
                            AvailabilityDay = "Monday",
                            DayStartTime = new TimeSpan(5, 0, 0),
                            DayEndTime = new TimeSpan(6, 30, 0),
                            PractitionerAvailabilityBreaks = new List<PractitionerAvailabilityBreakDto>
                            {
                                new PractitionerAvailabilityBreakDto
                                {
                                    BreakTitle = "Lunch Break",
                                    BreakStartTime = TimeSpan.FromHours(13),
                                    BreakEndTime = TimeSpan.FromHours(14)
                                }
                            },
                            PractitionerAvailabilityOccurances = new List<PractitionerAvailabilityOccuranceDto>
                            {
                                new PractitionerAvailabilityOccuranceDto
                                {
                                    OccuranceType = "First"
                                }
                            }
                        }
                    },

                }
            };

            var result = await _scheduleQueryService.IsTimeOverlapping(request);

            result.Should().BeFalse();
        }

        #endregion

        const string DateOnlyFormat = "yyyy-MM-dd";

        #region Get Schedule Details by AvailabilityId

        [Fact]
        public async Task GetScheduleDetailsAsync_WithValidAvailabilityId_ReturnsScheduleDetails()
        {
            // Arrange
            long validAvailabilityId = 1;

            // Act
            var result = await _scheduleQueryService.GetScheduleDetailsAsync(validAvailabilityId);

            // Assert
            result.Should().NotBeNull();
            result.PractitionerAvailability.Should().NotBeNull();
            result.PractitionerAvailability.PractitionerAvailabilityDays.Should().HaveCount(2);

            var monday = result.PractitionerAvailability.PractitionerAvailabilityDays.FirstOrDefault(d => d.AvailabilityDay == "Monday");
            var tuesday = result.PractitionerAvailability.PractitionerAvailabilityDays.FirstOrDefault(d => d.AvailabilityDay == "Tuesday");

            monday.Should().NotBeNull();
            monday.PractitionerAvailabilityBreaks.Should().ContainSingle();
            monday.PractitionerAvailabilityOccurances.Should().HaveCount(2);

            tuesday.Should().NotBeNull();
            tuesday.PractitionerAvailabilityBreaks.Should().ContainSingle();
            tuesday.PractitionerAvailabilityOccurances.Should().HaveCount(2);
        }

        [Fact]
        public async Task GetScheduleDetailsAsync_WithInvalidAvailabilityId_ReturnsNull()
        {
            // Arrange
            long invalidAvailabilityId = 999;

            // Act
            var result = await _scheduleQueryService.GetScheduleDetailsAsync(invalidAvailabilityId);

            // Assert
            result.Should().BeNull();
        }

        [Fact]
        public async Task GetScheduleDetailsAsync_WithNoAvailabilityDays_ReturnsEmptyDays()
        {
            // Arrange
            var availability = await _mockDbContext.PractitionerAvailabilities.FindAsync(1L);
            var days = _mockDbContext.PractitionerAvailabilityDays.Where(d => d.PractitionerAvailabilityID == 1);
            _mockDbContext.PractitionerAvailabilityDays.RemoveRange(days);
            await _mockDbContext.SaveChangesAsync();

            // Act
            var result = await _scheduleQueryService.GetScheduleDetailsAsync(availability.Id);

            // Assert
            result.Should().NotBeNull();
            result.PractitionerAvailability.PractitionerAvailabilityDays.Should().BeEmpty();
        }
        [Fact]
        public async Task GetViewScheduleDetailsAsync_ShouldReturnResults_WhenValidRequest()
        {
            // Arrange
            var scheduleSearchRequest = new ScheduleSearchRequestDto
            {
                PractitionerResourceId = "123",
                PractitionerSpecialtyId = "Cardiology",
                LocationId = "KLAN",
                SearchStartDate = new DateTime(2025, 01, 01, 0, 0, 0, DateTimeKind.Utc),
                SearchEndDate = DateTime.Today.AddDays(7),
                Status = "Active",
                PageNumber = 1,
                PageSize = 10
            };

            // Act
            var result = await _scheduleQueryService.GetViewScheduleDetailsAsync(scheduleSearchRequest);

            // Assert
            result.Should().NotBeNull();
            result.TotalCount.Should().Be(1);
            result.Records.First().PractitionerResourceId.Should().Be("123");
        }

        [Fact]
        public async Task GetViewScheduleDetailsAsync_shouldReturnNull_whenNoPractitionersFound()
        {
            // arrange
            var scheduleSearchRequest = new ScheduleSearchRequestDto
            {
                PractitionerResourceId = "12",
                PageNumber = 1,
                PageSize = 10
            };

            // act
            var result = await _scheduleQueryService.GetViewScheduleDetailsAsync(scheduleSearchRequest);

            // assert
            result.Should().BeNull();
        }

        [Fact]
        public async Task GetViewScheduleDetailsAsync_ShouldReturnNull_WhenNoRolesFound()
        {
            // Arrange
            var scheduleSearchRequest = new ScheduleSearchRequestDto
            {
                PractitionerResourceId = "123",
                PractitionerSpecialtyId = "Cardiology1",
                PageNumber = 1,
                PageSize = 10
            };

            // Act
            var result = await _scheduleQueryService.GetViewScheduleDetailsAsync(scheduleSearchRequest);

            // Assert
            result.Should().BeNull();
        }

        [Fact]
        public async Task GetViewScheduleDetailsAsync_ShouldReturnNull_WhenNoLocationsFound()
        {
            // Arrange
            var scheduleSearchRequest = new ScheduleSearchRequestDto
            {
                PractitionerResourceId = "123",
                PractitionerSpecialtyId = "Cardiology",
                LocationId = "KLAN1",
                PageNumber = 1,
                PageSize = 10
            };
            // Act
            var result = await _scheduleQueryService.GetViewScheduleDetailsAsync(scheduleSearchRequest);

            // Assert
            result.Should().BeNull();
        }

        [Fact]
        public async Task GetViewScheduleDetailsAsync_ShouldReturnNull_WhenNoAvailabilityFound()
        {
            // Arrange
            var scheduleSearchRequest = new ScheduleSearchRequestDto
            {
                PractitionerResourceId = "123",
                PractitionerSpecialtyId = "Cardiology",
                LocationId = "KLAN",
                SearchStartDate = new DateTime(2025, 02, 02, 0, 0, 0, DateTimeKind.Utc),
                PageNumber = 1,
                PageSize = 10
            };
            // Act
            var result = await _scheduleQueryService.GetViewScheduleDetailsAsync(scheduleSearchRequest);

            // Assert
            result.Should().BeNull();
        }

        [Fact]
        public async Task GetViewScheduleDetailsAsync_ShouldHandleEmptyRequest()
        {
            // Arrange
            var scheduleSearchRequest = new ScheduleSearchRequestDto
            {
                PageNumber = 1, PageSize = 10, PractitionerResourceId = "101"
            };

            // Act
            var result = await _scheduleQueryService.GetViewScheduleDetailsAsync(scheduleSearchRequest);

            // Assert
            result.Should().BeNull();
        }
        [Fact]
        public async Task GetViewScheduleDetailsAsync_ShouldApplyActiveStatusFilterAndReturnPagedResult()
        {
            // Arrange
            var scheduleSearchRequest = new ScheduleSearchRequestDto
            {
                PageNumber = 1,
                PageSize = 10,
                Status = "Active"
            };

            // Act
            var result = await _scheduleQueryService.GetViewScheduleDetailsAsync(scheduleSearchRequest);

            // Assert
            result.Should().NotBeNull();
            result.Records.Should().HaveCount(1);
            result.Records.First().Status.Should().BeTrue();
            result.TotalCount.Should().Be(1);
        }
        [Fact]
        public async Task GetViewScheduleDetailsAsync_ShouldApplyInActiveStatusFilterAndReturnPagedResult()
        {
            // Arrange
            var scheduleSearchRequest = new ScheduleSearchRequestDto
            {
                PageNumber = 1,
                PageSize = 10,
                Status = "InActive"
            };

            // Act
            var result = await _scheduleQueryService.GetViewScheduleDetailsAsync(scheduleSearchRequest);

            // Assert
            result.Should().NotBeNull();
            result.Records.Should().HaveCount(1);
            result.Records.First().Status.Should().BeFalse();
            result.TotalCount.Should().Be(1);
        }
        #endregion

        [Theory]
        [InlineData("123", "KLAN", "Cardiology", "2025-03-25", "2025-03-30", ScheduleViewType.Day)]
        [InlineData("123", "KLAN", "Cardiology", "2025-04-01", "2025-04-01", ScheduleViewType.Day)]
        [InlineData("123", "KLAN", "Cardiology", "2025-03-25", "2025-04-25", ScheduleViewType.Month)]
        [InlineData("123", "KLAN", "Cardiology", "2025-03-25", "2025-04-25", ScheduleViewType.Week)]
        [InlineData("practitioner1", "KLAN", "speciality1", "2023-10-01", "2025-10-30", ScheduleViewType.Day)]
        [InlineData("nonexistent", "KLAN", "speciality1", "2023-10-01", "2025-10-30", ScheduleViewType.Day)]
        [InlineData("practitioner1", "nonexistentLocation", "speciality1", "2023-10-01", "2025-10-30", ScheduleViewType.Day)]
        [InlineData("123", "KLAN", "Cardiology", "2025-03-12", "2025-03-30", ScheduleViewType.Day)]
        [InlineData("123", "KLAN", "Cardiology", "2025-03-17", "2025-03-30", ScheduleViewType.Day)]
        [InlineData("123", "KLAN", "Cardiology", "2025-03-04", "2025-03-30", ScheduleViewType.Day)]
        public async Task GetDoctorScheduleByDay_ShouldReturnScheduleBasedOnInputs(
            string practitionerId,
            string locationId,
            string specialityName,
            string startDateString,
            string endDateString,
            ScheduleViewType viewType)
        {
            // Mock Practitioner Exceptions
            var mockPractitionerExceptions = new List<PractitionerExceptionResponse>
    {
        new PractitionerExceptionResponse
        {
            ExceptionDate = new DateTime(2025, 03, 31, 0, 0, 0, DateTimeKind.Utc),
            Exceptions = new PractitionerExceptionResult()
            {
                Id = 1,
                PractitionerID = "123",
                StartDateTime = new DateTime(2025, 03, 31, 12, 0, 0, DateTimeKind.Utc),
                EndDateTime = new DateTime(2025, 03, 31, 19, 0, 0, DateTimeKind.Utc),
            },
        },
        new PractitionerExceptionResponse
        {
            Exceptions = new PractitionerExceptionResult()
            {
                PractitionerID = "123",
                StartDateTime = new DateTime(2025, 03, 17, 12, 0, 0, DateTimeKind.Utc),
                EndDateTime = new DateTime(2025, 03, 17, 12, 30, 0, DateTimeKind.Utc),
            }
        }
    };

            var jsonPractitionerExceptionResponse = JsonConvert.SerializeObject(mockPractitionerExceptions);
            var practitionerExceptionHttpResponse = new HttpResponseMessage
            {
                StatusCode = HttpStatusCode.OK,
                Content = new StringContent(jsonPractitionerExceptionResponse)
            };

            _httpClientServiceMock
                .Setup(x => x.GetAsyncCall(It.Is<string>(s => s.Contains("Exceptions")), It.IsAny<string>()))
                .ReturnsAsync(practitionerExceptionHttpResponse);

            // Mock Patient Data
            var patients = new List<PatientDetails>
    {
        new PatientDetails { Id = "1", MRN = "P123", Name = "John Doe" },
        new PatientDetails { Id = "2", MRN = "P124", Name = "Jane Doe" }
    };

            var jsonPatientResponse = JsonConvert.SerializeObject(patients);
            var patientHttpResponse = new HttpResponseMessage
            {
                StatusCode = HttpStatusCode.OK,
                Content = new StringContent(jsonPatientResponse)
            };

            _httpClientServiceMock
                .Setup(x => x.GetAsyncCall(It.Is<string>(s => s.Contains("NamesAndMRNs")), It.IsAny<string>()))
                .ReturnsAsync(patientHttpResponse);

            // Mock Holiday Data
            var holidays = new List<HolidayForLocationResponse>
    {
        new HolidayForLocationResponse { HolidayName = "New Year", HolidayDate = new DateTime(2025, 03, 31, 0, 0, 0, DateTimeKind.Utc) },
        new HolidayForLocationResponse { HolidayName = "Day After New Year", HolidayDate = new DateTime(2025, 04, 01, 0, 0, 0, DateTimeKind.Utc) }
    };

            var jsonHolidayResponse = JsonConvert.SerializeObject(holidays);
            var holidayHttpResponse = new HttpResponseMessage
            {
                StatusCode = HttpStatusCode.OK,
                Content = new StringContent(jsonHolidayResponse)
            };

            _httpClientServiceMock
                .Setup(x => x.GetAsyncCall(It.Is<string>(s => s.Contains("GetForLocation")), It.IsAny<string>()))
                .ReturnsAsync(holidayHttpResponse);

            //// Mock Appointments Data
            var appointments = new AppointmentGroupedResponse
            {
                GroupedAppointments = new List<AppointmentTimeResult>()
                {
                    new AppointmentTimeResult()
                    {
                        AppointmentDate = new DateTime(2025, 03, 24, 0, 0, 0, 0, DateTimeKind.Utc),
                        Appointments = new List<AppointmentTimeDto>()
                        {
                            new AppointmentTimeDto()
                            {
                                PatientId = "1",
                                SlotId = 1,
                                RequestedPeriodEnd = new DateTime(2025, 3, 24, 13, 0, 0, 0, DateTimeKind.Utc),
                                RequestedPeriodStart = new DateTime(2025, 3, 24, 13, 30, 0, 0, 0, DateTimeKind.Utc)
                            }
                        },
                        
                    },
                    new AppointmentTimeResult()
                    {
                        AppointmentDate = new DateTime(2025, 03, 31, 0, 0, 0, 0, DateTimeKind.Utc),
                        Appointments = new List<AppointmentTimeDto>()
                        {
                            new AppointmentTimeDto()
                            {
                                PatientId = "1",
                                SlotId = 1,
                                RequestedPeriodEnd = new DateTime(2025, 3, 31, 12, 0, 0, 0, DateTimeKind.Utc),
                                RequestedPeriodStart = new DateTime(2025, 3, 31, 12, 10, 0, 0, 0, DateTimeKind.Utc)
                            }
                        },

                    }
                },
                SlotDurations = new Dictionary<long, int?>() { { 1, 30} } ,
                PatientIds = new List<string> { "P123", "P124" }
            };

            var jsonAppointmentResponse = JsonConvert.SerializeObject(appointments);
            var appointmentHttpResponse = new HttpResponseMessage
            {
                StatusCode = HttpStatusCode.OK,
                Content = new StringContent(jsonAppointmentResponse)
            };

            _httpClientServiceMock
                .Setup(x => x.GetAsyncCall(It.Is<string>(s => s.Contains("GetAppointmentTimes")), It.IsAny<string>()))
                .ReturnsAsync(appointmentHttpResponse);

            // Configuration Mock Setup
            var mockSection = new Mock<IConfigurationSection>();
            _configurationMock
  .Setup(config => config.GetSection("Aurora-AppointmentServiceURL"))
  .Returns(mockSection.Object);

            _configurationMock
              .Setup(config => config.GetSection("Aurora-PatientLifeCycleServiceURL"))
              .Returns(mockSection.Object);

            _configurationMock
                .Setup(config => config[CommonConstants.AuroraAppointmentServiceAPIURL])
                .Returns("test-client-id");


            // Prepare Schedule Request
            var startDate = DateTime.ParseExact(startDateString, DateOnlyFormat, CultureInfo.InvariantCulture);
            var endDate = DateTime.ParseExact(endDateString, DateOnlyFormat, CultureInfo.InvariantCulture);
            var scheduleRequest = new ScheduleViewRequestDto
            {
                PractitionerId = practitionerId,
                LocationId = locationId,
                Specialty = specialityName,
                ViewType = viewType,
                StartDate = startDate,
                EndDate = endDate
            };

            // Act: Call the method to get schedule view
            var result = await _scheduleQueryService.GetScheduleViewAsync(scheduleRequest);

            // Assert: Verify the correct data is returned for each aspect
            result.Should().NotBeNull();
        }



        public enum ExpectedResultType
        {
            ValidSchedule,
            EmptySchedule
        }

        #region GetAvailability Details

        [Fact]
        public async Task GetAvailabilityWithDetailsAsync_ShouldReturnAvailabilityWithDetails_WhenExists()
        {
            // Act
            var result = await _scheduleQueryService.GetAvailabilityWithDetailsAsync(1);

            // Assert
            result.Should().NotBeNull();
            result!.Id.Should().Be(1);
            result.PractitionerAvailabilityDay.Should().HaveCount(2);
        }

        [Fact]
        public async Task GetAvailabilityWithDetailsAsync_ShouldReturnNull_WhenNotFound()
        {
            // Act
            var result = await _scheduleQueryService.GetAvailabilityWithDetailsAsync(999); // ID that doesn't exist

            // Assert
            result.Should().BeNull();
        }
        #endregion

        [Fact]
        public void GetSlotDetails_ShouldReturnCorrectSlotDetails_WhenAvailabilityIsProvided()
        {
            // Arrange
            var selectedDate = new DateTime(2025, 4, 27, 0, 0, 0, DateTimeKind.Local); // Assume this is a Sunday
            var availabilityData = new List<PractitionerAvailabilityInfo>
            {
                 new PractitionerAvailabilityInfo
                 {
                     PractitionerAvailability = new PractitionerAvailability
                     {
                         Id = 1,
                         SlotsID = 101,
                         CreatedBy = "Admin",
                         CreatedDate = DateTime.UtcNow,
                         IsDeleted = false,
                         ScheduleEndDate = DateTime.UtcNow,
                         ScheduleStartDate = DateTime.UtcNow,
                     },
                     PractitionerAvailabilityDay = new PractitionerAvailabilityDay
                     {
                         AvailabilityDay = "Sunday",  // This should match the selected date's day of week
                         StartTime = new TimeSpan(9, 0, 0),  // 9 AM
                         EndTime = new TimeSpan(17, 0, 0),  // 5 PM
                         CreatedBy = "Admin",
                         CreatedDate = DateTime.UtcNow,
                         IsDeleted = false,
                         PractitionerAvailabilityID = 1,
                     }
                 },
                 new PractitionerAvailabilityInfo
                 {
                     PractitionerAvailability = new PractitionerAvailability
                     {
                         SlotsID = 102,
                         CreatedBy = "Admin",
                         CreatedDate = DateTime.UtcNow,
                         IsDeleted = false,
                         ScheduleEndDate = DateTime.UtcNow,
                         ScheduleStartDate = DateTime.UtcNow,
                     },
                     PractitionerAvailabilityDay = new PractitionerAvailabilityDay
                     {
                         AvailabilityDay = "Sunday",  // This should match the selected date's day of week
                         StartTime = new TimeSpan(10, 0, 0), // 10 AM
                         EndTime = new TimeSpan(18, 0, 0),  // 6 PM
                         CreatedBy = "Admin",
                         CreatedDate = DateTime.UtcNow,
                         IsDeleted = false,
                         PractitionerAvailabilityID = 1,
                     }
                 }
             };

            // Act
            // Get the private method using reflection
            var methodInfo = typeof(ScheduleQueryService).GetMethod(
                "GetAvailabilityForSelectedDate", // Ensure the method name is exactly as it is in the class
                BindingFlags.NonPublic | BindingFlags.Static); // Correct BindingFlags for private instance method

            // Invoke the private method using reflection
            var result = (List<SlotDetailsDto>)methodInfo.Invoke(_scheduleQueryService, new object[] { selectedDate, availabilityData });

            // Assert
            result.Should().NotBeNull();
            result.Should().HaveCount(2);

            result[0].SlotId.Should().Be(102);
            result[0].ScheduleStartTime.Should().Be(new TimeSpan(10, 0, 0));
            result[0].ScheduleEndTime.Should().Be(new TimeSpan(18, 0, 0));
           

            result[1].SlotId.Should().Be(101);
            result[1].ScheduleStartTime.Should().Be(new TimeSpan(9, 0, 0));
            result[1].ScheduleEndTime.Should().Be(new TimeSpan(17, 0, 0));
        }

        [Fact]
        public void GetSlotDetails_ShouldReturnEmptyList_WhenNoMatchingAvailabilityDay()
        {
            // Arrange
            var selectedDate = new DateTime(2025, 4, 27, 0, 0, 0, DateTimeKind.Local); // Assume this is a Sunday
            var availabilityData = new List<PractitionerAvailabilityInfo>
            {
            new PractitionerAvailabilityInfo
            {
                PractitionerAvailability = new PractitionerAvailability
                {  
                    Id = 1,
                    SlotsID = 103,
                    CreatedBy = "Admin",
                    CreatedDate = DateTime.UtcNow,
                    IsDeleted = false,
                    ScheduleEndDate = DateTime.UtcNow,
                    ScheduleStartDate = DateTime.UtcNow,
                },
                PractitionerAvailabilityDay = new PractitionerAvailabilityDay
                {
                    AvailabilityDay = "Monday",  // This doesn't match the selected date's day of week
                    StartTime = new TimeSpan(9, 0, 0),  // 9 AM
                    EndTime = new TimeSpan(17, 0, 0),   // 5 PM
                    CreatedBy = "Admin",
                    CreatedDate = DateTime.UtcNow,
                    IsDeleted = false,
                    PractitionerAvailabilityID = 1,
                }
            }
        };


            // Get the private method using reflection
            var methodInfo = typeof(ScheduleQueryService).GetMethod(
                "GetAvailabilityForSelectedDate", // Ensure the method name is exactly as it is in the class
                BindingFlags.NonPublic | BindingFlags.Static); // Correct BindingFlags for private instance method

            // Ensure the method exists
            methodInfo.Should().NotBeNull("Method GetAvailabilityForSelectedDate should exist in ScheduleQueryService");

            // Invoke the private method using reflection
            var result = (List<SlotDetailsDto>)methodInfo.Invoke(_scheduleQueryService, new object[] { selectedDate, availabilityData });

            // Assert
            result.Should().BeEmpty();
        }
    }
}
