﻿using Moq;
using System;
using System.Threading.Tasks;
using FluentAssertions;
using Xunit;
using Aurora.AdministrationService.API.Services.IService.OTPSender;
using Aurora.AdministrationService.Infrastructure.IRepository.OTP;
using Aurora.AdministrationService.Infrastructure.IRepository;
using Aurora.AdministrationService.API.Enum.OTP;
using Aurora.AdministrationService.API.Models.RequestModels.OTP;
using Aurora.AdministrationService.Infrastructure.IRepository.Password;
using Aurora.AdministrationService.CrossCutting.CommonModels;
using Aurora.AdministrationService.API.Resources;
using Aurora.AdministrationService.API.Services.Service.Old.OTP;
using Aurora.AdministrationService.Domain.Old.Entities;

namespace Aurora.AdministrationService.Tests.API.Services.OTP
{
    public class OtpServiceTests
    {
        private readonly Mock<IPasswordRepository> _mockUserRepository;
        private readonly Mock<IOtpRepository> _mockOtpRepository;
        private readonly Mock<IOTPSenderService> _mockOtpSender;
        private readonly OtpService _otpService;

        public OtpServiceTests()
        {
            _mockUserRepository = new Mock<IPasswordRepository>();
            _mockOtpRepository = new Mock<IOtpRepository>();
            _mockOtpSender = new Mock<IOTPSenderService>();
            _otpService = new OtpService(_mockUserRepository.Object, _mockOtpSender.Object, _mockOtpRepository.Object);
        }

        [Fact]
        public async Task SendOtpAsync_ShouldReturnSuccess_WhenOtpIsSent()
        {
            // Arrange
            var contactSelectionDto = new ContactSelectionDto { UserId = "user1", Email = "test@example.com", MobileNo = "1234567890", OtpType = OTPType.Email };
            var userData = new AdminUser { Username = "user1", Email = "test@example.com", PhoneNumber = "1234567890" };

            _mockUserRepository.Setup(repo => repo.GetUserProfileByIdAsync(It.IsAny<string>(), It.IsAny<string>(), It.IsAny<string>())).ReturnsAsync(userData);
            _mockOtpRepository.Setup(repo => repo.GetOtpAttemptsInLast24HoursAsync(It.IsAny<string>())).ReturnsAsync(2);
            _mockOtpSender.Setup(sender => sender.SendOTPEmailAsync(It.IsAny<string>(), It.IsAny<string>())).ReturnsAsync(true);
            _mockOtpRepository.Setup(repo => repo.SaveOtpAsync(It.IsAny<OtpEntry>())).Returns(Task.CompletedTask);

            // Act
            var result = await _otpService.SendOtpAsync(contactSelectionDto);

            // Assert
            result.IsSuccess.Should().BeTrue();
            result.StatusCode.Should().Be("200");
            result.Message.Should().Contain(Resource.OtpSend);
        }
        [Fact]
        public async Task SendOtpAsync_ShouldReturnNotFound_WhenUserIsNotFound()
        {
            // Arrange
            var contactSelectionDto = new ContactSelectionDto { UserId = "user1", Email = "test@example.com", MobileNo = "1234567890", OtpType = OTPType.Email };

            _mockUserRepository.Setup(repo => repo.GetUserProfileByIdAsync(It.IsAny<string>(), It.IsAny<string>(), It.IsAny<string>())).ReturnsAsync((AdminUser)null);

            // Act
            var result = await _otpService.SendOtpAsync(contactSelectionDto);

            // Assert
            result.IsSuccess.Should().BeFalse();
            result.StatusCode.Should().Be(ResponseStatus.STATUS_NotFound);
            result.Message.Should().Be(Resource.RecordNotFound);
        }

        [Fact]
        public async Task SendOtpAsync_ShouldReturnProblem_WhenOtpLimitReached()
        {
            // Arrange
            var contactSelectionDto = new ContactSelectionDto { UserId = "user1", Email = "test@example.com", MobileNo = "1234567890", OtpType = OTPType.SMS };
            var userData = new AdminUser { Username = "user1", Email = "test@example.com", PhoneNumber = "1234567890" };

            _mockUserRepository.Setup(repo => repo.GetUserProfileByIdAsync(It.IsAny<string>(), It.IsAny<string>(), It.IsAny<string>())).ReturnsAsync(userData);
            _mockOtpRepository.Setup(repo => repo.GetOtpAttemptsInLast24HoursAsync(It.IsAny<string>())).ReturnsAsync(6); // Limit exceeded

            // Act
            var result = await _otpService.SendOtpAsync(contactSelectionDto);

            // Assert
            result.IsSuccess.Should().BeFalse();
            result.StatusCode.Should().Be(ResponseStatus.STATUS_Problem);
            result.Message.Should().Be(Resource.OTPLimitReached);
        }

        [Fact]
        public async Task ValidateOtpAsync_ShouldReturnSuccess_WhenOtpIsValid()
        {
            // Arrange
            var otp = "123456";
            var contactSelectionDto = new ContactSelectionDto { UserId = "user1", OtpType = OTPType.Email, Email = "test@example.com" };

            var otpEntry = new OtpEntry { Otp = otp, IsUsed = false, ExpiryTime = DateTime.UtcNow.AddMinutes(5), UserId = "user1" };

            _mockOtpRepository.Setup(repo => repo.GetOtpByUserId(It.IsAny<string>(), It.IsAny<string>(), It.IsAny<string>(), It.IsAny<int?>())).ReturnsAsync(new List<OtpEntry> { otpEntry });
            _mockOtpRepository.Setup(repo => repo.MarkOtpAsUsed(It.IsAny<OtpEntry>()));

            // Act
            var result = await _otpService.ValidateOtpAsync(contactSelectionDto.UserId, otp, OTPType.Email, contactSelectionDto.Email, contactSelectionDto.MobileNo);

            // Assert
            result.IsSuccess.Should().BeTrue();
            result.Message.Should().Be(Resource.OTPVerified);
        }

        [Fact]
        public async Task ValidateOtpAsync_ShouldReturnError_WhenOtpIsExpired()
        {
            // Arrange
            var otp = "123456";
            var contactSelectionDto = new ContactSelectionDto { UserId = "user1", OtpType = OTPType.Email, Email = "test@example.com" };

            var otpEntry = new OtpEntry { Otp = otp, IsUsed = false, ExpiryTime = DateTime.UtcNow.AddMinutes(-5), UserId = "user1" };

            _mockOtpRepository.Setup(repo => repo.GetOtpByUserId(It.IsAny<string>(), It.IsAny<string>(), It.IsAny<string>(), It.IsAny<int?>())).ReturnsAsync(new List<OtpEntry> { otpEntry });
            _mockOtpRepository.Setup(repo => repo.MarkOtpAsUsed(It.IsAny<OtpEntry>()));

            // Act
            var result = await _otpService.ValidateOtpAsync(contactSelectionDto.UserId, otp, OTPType.Email, contactSelectionDto.Email, contactSelectionDto.MobileNo);

            // Assert
            result.IsSuccess.Should().BeFalse();
            result.Message.Should().Be(Resource.OTPExpired);
        }

        [Fact]
        public async Task ValidateOtpAsync_ShouldReturnConflict_WhenOtpIsInvalid()
        {
            // Arrange
            var otp = "123456";
            var contactSelectionDto = new ContactSelectionDto { UserId = "user1", OtpType = OTPType.Email, Email = "test@example.com" };

            var otpEntry = new OtpEntry { Otp = "654321", IsUsed = false, ExpiryTime = DateTime.UtcNow.AddMinutes(5), UserId = "user1" };

            _mockOtpRepository.Setup(repo => repo.GetOtpByUserId(It.IsAny<string>(), It.IsAny<string>(), It.IsAny<string>(), It.IsAny<int?>())).ReturnsAsync(new List<OtpEntry> { otpEntry });

            // Act
            var result = await _otpService.ValidateOtpAsync(contactSelectionDto.UserId, otp, OTPType.Email, contactSelectionDto.Email, contactSelectionDto.MobileNo);

            // Assert
            result.IsSuccess.Should().BeFalse();
            result.Message.Should().Contain(Resource.AttemptsLeft);
        }

        [Fact]
        public async Task ValidateOtpAsync_ShouldReturnConflict_WhenOtpIsAlreadyUsed()
        {
            // Arrange
            var otp = "123456";
            var contactSelectionDto = new ContactSelectionDto { UserId = "user1", OtpType = OTPType.Email, Email = "test@example.com" };

            var otpEntry = new OtpEntry { Otp = otp, IsUsed = true, ExpiryTime = DateTime.UtcNow.AddMinutes(5), UserId = "user1" };

            _mockOtpRepository.Setup(repo => repo.GetOtpByUserId(It.IsAny<string>(), It.IsAny<string>(), It.IsAny<string>(), It.IsAny<int?>())).ReturnsAsync(new List<OtpEntry> { otpEntry });

            // Act
            var result = await _otpService.ValidateOtpAsync(contactSelectionDto.UserId, otp, OTPType.Email, contactSelectionDto.Email, contactSelectionDto.MobileNo);

            // Assert
            result.IsSuccess.Should().BeFalse();
            result.Message.Should().Be(Resource.OTPAlreadyUsed);
        }

    }
}