﻿using Aurora.AdministrationService.API.Resources;
using Aurora.AdministrationService.API.Services.IService.OTPSender;
using Aurora.AdministrationService.API.Services.Service.OTPService;
using Aurora.AdministrationService.CrossCutting.CommonModels;
using FluentAssertions;
using Microsoft.Extensions.Configuration;
using Moq;
using System.Net;

namespace Aurora.AdministrationService.Tests.API.Services.OTP
{
    public class OTPSenderServiceTests
    {
        private readonly Mock<IOTPSenderService> _mockOtpRepository;
        private readonly Mock<IOTPSenderService> _mockOtpSender;
        private readonly OtpSenderService _otpSenderService;
        private readonly Mock<IConfiguration> _configurationMock;
        private readonly Mock<HttpClient> _httpClientMock;
        private Mock<HttpMessageHandler> _httpMessageHandlerMock;

        public OTPSenderServiceTests()
        {
            _httpMessageHandlerMock = new Mock<HttpMessageHandler>();
            _mockOtpRepository = new Mock<IOTPSenderService>();
            _mockOtpSender = new Mock<IOTPSenderService>();
            _configurationMock = new Mock<IConfiguration>();
            _httpClientMock = new Mock<HttpClient>();
            _otpSenderService = new OtpSenderService(_httpClientMock.Object, _configurationMock.Object);
        }

        [Fact]
        public async Task SendOTPEmailAsync_ValidResponse_ReturnsTrue()
        {
            // Arrange
            var emailAddress = "test@example.com";
            var otp = "123456";
            var responseMessage = new HttpResponseMessage(HttpStatusCode.OK)
            {
                Content = new StringContent("status=0")
            };
            _httpClientMock
                .Setup(m => m.SendAsync(It.IsAny<HttpRequestMessage>(), It.IsAny<CancellationToken>()))
                .ReturnsAsync(responseMessage);

            // Act
            var result = await _otpSenderService.SendOTPEmailAsync(emailAddress, otp);

            // Assert
            result.Should().BeTrue();
        }

        [Fact]
        public async Task SendOTPEmailAsync_EmptyEmailAddress_ReturnsFalse()
        {
            // Arrange
            var emailAddress = "";
            var otp = "123456";
            var responseMessage = new HttpResponseMessage(HttpStatusCode.OK)
            {
                Content = new StringContent("status=1")
            };
            _httpClientMock
                .Setup(m => m.SendAsync(It.IsAny<HttpRequestMessage>(), It.IsAny<CancellationToken>()))
                .ReturnsAsync(responseMessage);

            // Act
            var result = await _otpSenderService.SendOTPEmailAsync(emailAddress, otp);

            // Assert
            result.Should().BeFalse();
        }

        [Fact]
        public async Task SendOTPEmailAsync_HttpRequestException_ReturnsFalse()
        {
            // Arrange
            var emailAddress = "test@example.com";
            var otp = "123456";
            _httpClientMock
                .Setup(m => m.SendAsync(It.IsAny<HttpRequestMessage>(), It.IsAny<CancellationToken>()))
                .ThrowsAsync(new HttpRequestException());

            // Act
            var result = await _otpSenderService.SendOTPEmailAsync(emailAddress, otp);

            // Assert
            result.Should().BeFalse();
        }

        [Fact]
        public async Task SendOTPSmsAsync_ValidInput_ReturnsSuccessResponse()
        {
            // Arrange
            var phoneNumber = "1234567890";
            var otp = "123456";

            // Act
            var result = await _otpSenderService.SendOTPSmsAsync(phoneNumber, otp);

            // Assert
            result.Should().NotBeNull();
            result.Status.Should().Be(0);
            result.ErrMsg.Should().Be("");
        }
    }
}