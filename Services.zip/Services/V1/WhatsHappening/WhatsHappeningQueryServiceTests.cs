﻿using Aurora.AdministrationService.API.Enum;
using Aurora.AdministrationService.API.Models.Dto.WhatHappenings;
using Aurora.AdministrationService.API.Services.Service.WhatsHappenings;
using Aurora.AdministrationService.Domain.V1.Entities.Locations;
using Aurora.AdministrationService.Domain.V1.Entities.Marketings;
using Aurora.AdministrationService.Infrastructure;
using AutoMapper;
using FluentAssertions;
using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Diagnostics;
using Moq;
using entityWhatsHappening = Aurora.AdministrationService.Domain.V1.Entities.Marketings.WhatsHappening;

namespace Aurora.AdministrationService.Tests.API.Services.V1.WhatsHappening
{
    public class WhatsHappeningQueryServiceTests
    {
        private readonly Mock<IMapper> _mapperMock;
        private readonly ReadOnlyDbContext _mockDbContext;
        private readonly WhatsHappeningQueryService _whatsHappeningQueryService;
        private readonly DbContextOptions<ReadOnlyDbContext> _options;

        public WhatsHappeningQueryServiceTests()
        {
            // Initialize database options
            _options = new DbContextOptionsBuilder<ReadOnlyDbContext>()
                .UseInMemoryDatabase(databaseName: Guid.NewGuid().ToString()) // Unique DB for each test
                .Options;

            // Initialize DbContext
            _mockDbContext = new ReadOnlyDbContext(_options);

            // Initialize Mocks
            _mapperMock = new Mock<IMapper>();
            _mockDbContext.Database.EnsureCreated();

            SeedTestData(_mockDbContext);
            // Initialize service with valid DbContext
            _whatsHappeningQueryService = new WhatsHappeningQueryService(_mockDbContext, _mapperMock.Object);

        }
        private static void SeedTestData(ReadOnlyDbContext context)
        {
            var whatsHappening = new entityWhatsHappening
            {
                ID = 1,
                Title = "Free Health Checkup",
                Description = "Event description",
                URL = "http://example.com",
                Image = "http://example.com/image.png",
                StartDate = new DateTime(2024, 4, 12),
                EndDate = new DateTime(2025, 4, 12),
                Status = true,
                HospitalID = 101,
                CategoryID = 201,
                RecordVersion = new byte[] { 1 },
                CreatedBy = "Tester",
                CreatedDate = DateTime.UtcNow,
                UpdatedBy = "Tester",
                UpdatedDate = DateTime.UtcNow,
                IsDeleted = false
            };

            var location = new Location
            {
                Id = 101,
                Name = "Test Hospital",
                Latitude = 10.12m,
                Longitude = 20.34m,
                ResourceID="324325",
                Status=true,
                IsDeleted=false,
                CreatedBy="adnmin",
                CreatedDate=DateTime.UtcNow.AddDays(-2),
                UpdatedBy="admin",
                PartOf="Test"
            };

            var locationAddress = new LocationAddress
            {
                LocationID = 101,
                City = "Test City",
                State = "Test State",
                Country = "Test Country",
                Use = "Test",
                Status = true,
                IsDeleted = false,
                CreatedBy = "admin",
                CreatedDate = DateTime.Now,
                UpdatedBy="admin",
                UpdatedDate=DateTime.UtcNow
            };

            var category = new CategoryMaster
            {
                ID = 201,
                Definition = "Health Camp",
                IsDeleted = false,
                CreatedBy = "admin",
                CreatedDate = DateTime.Now,
                UpdatedBy="admin",
                UpdatedDate=DateTime.UtcNow
            };

            context.WhatsHappeningsNew.Add(whatsHappening);
            context.Locations.Add(location);
            context.LocationAddresses.Add(locationAddress);
            context.CategoryMasters.Add(category);
            context.SaveChanges();
        }
        public static List<entityWhatsHappening> GetMockWhatsHappeningList()
        {
            return new List<entityWhatsHappening>
        {
            new entityWhatsHappening
            {
                ID = 1,
                Title = "Health Awareness Camp",
                URL = "https://example.com/health-camp",
                CategoryID = 1,
                HospitalID = 201,
                StartDate = DateTime.UtcNow,
                EndDate = DateTime.UtcNow.AddDays(3),
                Image = "https://example.com/images/health-camp.jpg",
                Description = "A three-day health awareness camp with free checkups.",
                Status = true,
                RecordVersion = Array.Empty<byte>(),
                IsDeleted = false,
                CreatedBy = "Admin",
                CreatedDate = DateTime.UtcNow,
                UpdatedBy = "Admin",
                UpdatedDate = DateTime.UtcNow,
                Location = new Location
                {
                    Id = 1001,
                    Name = "City Park",
                    Latitude = 37.77M,
                    Longitude = -122.41M,
                    ResourceID="324324",
                    Status=true,
                    IsDeleted=false,
                    CreatedBy="adnmin",
                    CreatedDate=DateTime.UtcNow.AddDays(-2),
                    UpdatedBy="admin",
                    PartOf="Test"
                }
            },
            new entityWhatsHappening
            {
                ID = 2,
                Title = "Blood Donation Drive",
                URL = "https://example.com/blood-donation",
                CategoryID = 1,
                HospitalID = 202,
                StartDate = DateTime.UtcNow,
                EndDate = DateTime.UtcNow.AddDays(3),
                Image = "https://example.com/images/blood-donation.jpg",
                Description = "Join our blood donation drive and save lives!",
                Status = true,
                RecordVersion = new byte[] { 4, 5, 6 },
                IsDeleted = false,
                CreatedBy = "Admin",
                CreatedDate = DateTime.UtcNow,
                UpdatedBy = "Admin",
                UpdatedDate = DateTime.UtcNow,
                Location = new Location
                {
                    Id = 1002,
                    Name = "Downtown Community Center",
                    Latitude = 40.71M,
                    Longitude = -74.00M,
                    ResourceID="324325",
                    Status=true,
                    IsDeleted=false,
                    CreatedBy="adnmin",
                    CreatedDate=DateTime.UtcNow.AddDays(-2),
                    UpdatedBy="admin",
                    PartOf="Test"
                }
            },
            new entityWhatsHappening
            {
                ID = 3,
                Title = "Mental Health Workshop",
                URL = "https://example.com/mental-health",
                CategoryID = 1,
                HospitalID = 203,
                StartDate = DateTime.UtcNow,
                EndDate = DateTime.UtcNow.AddDays(3),
                Image = "https://example.com/images/mental-health.jpg",
                Description = "A workshop on mental health awareness and self-care.",
                Status = false,
                RecordVersion = new byte[] { 7, 8, 9 },
                IsDeleted = false,
                CreatedBy = "Admin",
                CreatedDate = DateTime.UtcNow,
                UpdatedBy = "Admin",
                UpdatedDate = DateTime.UtcNow,
                Location = new Location
                {
                    Id = 1003,
                    Name = "Wellness Center",
                    Latitude = 34.0522M,
                    Longitude = -118.24M,
                    ResourceID="324326",
                    Status=true,
                    IsDeleted=false,
                    CreatedBy="adnmin",
                    CreatedDate=DateTime.UtcNow.AddDays(-2),
                    UpdatedBy="admin",
                    PartOf="Test"
                 }
            }
        };
        }

        public static List<Domain.V1.Entities.Organizations.Organization> GetMockOrganizations()
        {
            return new List<Domain.V1.Entities.Organizations.Organization>
            {
                new Domain.V1.Entities.Organizations.Organization
                {
                    Id = 201,
                    ResourceID = "ORG201",
                    Status = true,
                    Type = "Hospital",
                    Name = "Sunrise Medical Center",
                    Alias = "Sunrise",
                    PartOf = Guid.NewGuid(),
                    Source = "System",
                    IsDeleted = false,
                    CreatedBy = "Admin",
                    CreatedDate = DateTime.UtcNow,
                    UpdatedBy = "Admin",
                    UpdatedDate = DateTime.UtcNow
                },
                new Domain.V1.Entities.Organizations.Organization
                {
                    Id = 202,
                    ResourceID = "ORG202",
                    Status = true,
                    Type = "Clinic",
                    Name = "Green Valley Clinic",
                    Alias = "Green Valley",
                    PartOf = Guid.NewGuid(),
                    Source = "External",
                    IsDeleted = false,
                    CreatedBy = "Admin",
                    CreatedDate = DateTime.UtcNow,
                    UpdatedBy = "Admin",
                    UpdatedDate = DateTime.UtcNow
                },
                new Domain.V1.Entities.Organizations.Organization
                {
                    Id = 203,
                    ResourceID = "ORG203",
                    Status = false,
                    Type = "Health Center",
                    Name = "Blue Cross Health",
                    Alias = "Blue Cross",
                    PartOf = Guid.NewGuid(),
                    Source = "Internal",
                    IsDeleted = false,
                    CreatedBy = "Admin",
                    CreatedDate = DateTime.UtcNow,
                    UpdatedBy = "Admin",
                    UpdatedDate = DateTime.UtcNow
                }
            };
        }


        #region Get WhatsHappening Query service Test cases

        [Fact]
        public async Task GetWhatsHappeningBySearch_ReturnsListOfWhatsHappening_WhenWhatsHappeningExist()
        {
            // Arrange
            DbContextOptions<ReadOnlyDbContext> options = new DbContextOptionsBuilder<ReadOnlyDbContext>()
          .UseInMemoryDatabase(databaseName: "McareTestDb1").UseQueryTrackingBehavior(QueryTrackingBehavior.NoTracking)
          .ConfigureWarnings(b => b.Ignore(InMemoryEventId.TransactionIgnoredWarning)).Options;
            var mockData = GetMockWhatsHappeningList();
            var mockFilters = new WhatsHappeningSearchFilterDto
            {
                Title = "Blood Donation Drive",
                CategoryId = 1,
                HospitalId = 1,
                Status = "Inactive",
                StartDate = DateTime.UtcNow,
                EndDate = DateTime.UtcNow,
                PageNumber = 1,
                PageSize = 5
            };
            using (var context = new ReadOnlyDbContext(options))
            {
                await context.WhatsHappeningsNew.AddRangeAsync(mockData);
                await context.Organizations.AddRangeAsync(GetMockOrganizations());
                await context.SaveChangesAsync();
            }

            var dbContext = new ReadOnlyDbContext(options);
            var _whatsHappeningQueryService = new WhatsHappeningQueryService(dbContext, _mapperMock.Object);


            // Act
            var result = await _whatsHappeningQueryService.GetWhatsHappeningBySearch(mockFilters); // Ensure GetLocationTypeMaster is awaited if it's async

            // Assert
            result.Should().NotBeNull();
            result.HasError.Should().BeFalse();
            result.IsSuccess.Should().BeTrue();
            result.StatusCode.Should().Be(((int)ResponceStatusCode.Success).ToString());
            result.Result.Should().NotBeNull();

        }

        [Fact]
        public async Task GetCategoryList_ShouldReturnMappedCategoryList()
        {
            // Arrange: Set up in-memory database options
            var options = new DbContextOptionsBuilder<ReadOnlyDbContext>()
                .UseInMemoryDatabase(databaseName: "TestDB_Categories")
                .Options;

            // Seed data in a separate DbContext instance
            using (var context = new ReadOnlyDbContext(options))
            {
                context.CategoryMasters.AddRange(new List<CategoryMaster>
        {
            new CategoryMaster
        {
            ID = 2,
            Code = "PAC",
            Definition = "Packages",
            RecordVersion = new byte[] { 0, 0, 0, 0, 0, 0, 56, 185 }, // Assuming RecordVersion is a byte array
            IsDeleted = false,
            CreatedBy = "Admin",
            CreatedDate = new DateTime(2025, 03, 30, 14, 50, 0),  // DateTime.Parse("30-03-2025 14:50") could also work
            UpdatedBy = string.Empty,
            UpdatedDate = DateTime.MinValue,  // Empty or null since no update details are provided
            WhatsHappening = []//new List<entityWhatsHappening>() // Assuming WhatsHappening is a list of strings
        },
        new CategoryMaster
        {
            ID = 3,
            Code = "CAT001",
            Definition = "Category 1",
            RecordVersion = new byte[] { 0, 0, 0, 0, 0, 0, 56, 223 }, // Assuming RecordVersion is a byte array
            IsDeleted = false,
            CreatedBy = "Admin",
            CreatedDate = new DateTime(2025, 04, 01, 9, 18, 0),  // DateTime.Parse("01-04-2025 09:18") could also work
            UpdatedBy = string.Empty,
            UpdatedDate = DateTime.MinValue,
            WhatsHappening = new List<entityWhatsHappening>() // Empty, since no updates are provided
        },        });
                await context.SaveChangesAsync(); // Ensure data is saved
            }

            // Act: Create a new context and call the service
            using (var context = new ReadOnlyDbContext(options))
            {
                var service = new WhatsHappeningQueryService(context, _mapperMock.Object);
                var result = await service.GetCategoryList();

                // Assert
                Assert.Null(result);
            }
        }
        public static IEnumerable<object[]> GetCategorySeedData()
        {
            yield return new object[]
            {
                new List<CategoryMaster>(), // No categories
                0
            };

            yield return new object[]
            {
                new List<CategoryMaster>
                {
                    new CategoryMaster { ID = 1, Definition = "Education", IsDeleted = false, CreatedBy = "admin", CreatedDate = DateTime.UtcNow },
                    new CategoryMaster { ID = 2, Definition = "Health", IsDeleted = false, CreatedBy = "admin", CreatedDate = DateTime.UtcNow }
                },
                2
            };
        }

        [Fact]
        public async Task GetWhatsHappeningBySearch_ShouldReturnBadRequest_WhenSearchRequestIsNull()
        {
            var result = await _whatsHappeningQueryService.GetWhatsHappeningBySearch(null);

            result.Should().NotBeNull();
            result.IsSuccess.Should().BeFalse();
            result.HasError.Should().BeTrue();
            result.StatusCode.Should().Be(((int)ResponceStatusCode.BadRequest).ToString());
            result.Result.Should().BeNull();
        }
        [Fact]
        public async Task GetWhatsHappeningBySearch_ShouldReturnData_WhenNoFiltersApplied()
        {
            var request = new WhatsHappeningSearchFilterDto
            {
                PageNumber = 1,
                PageSize = 10
            };

            var result = await _whatsHappeningQueryService.GetWhatsHappeningBySearch(request);

            result.IsSuccess.Should().BeTrue();
            result.Result.Should().NotBeNull();
            if (result.Result.Data.Count > 0)
            {
                result.Result.Data.Should().HaveCount(1);
                result.Result.Data.First().Title.Should().Be("Free Health Checkup");
            }
        }
        [Fact]
        public async Task GetWhatsHappeningBySearch_ShouldFilterByTitle()
        {
            var request = new WhatsHappeningSearchFilterDto
            {
                Title = "Health",
                PageNumber = 1,
                PageSize = 10
            };

            var result = await _whatsHappeningQueryService.GetWhatsHappeningBySearch(request);

            result.IsSuccess.Should().BeTrue();
            if (result.Result.Data.Count > 0)
            {
                result.Result.Data.Should().OnlyContain(x => x.Title.Contains("Health"));
            }
        }
        [Fact]
        public async Task GetWhatsHappeningBySearch_ShouldFilterByCategory()
        {
            var request = new WhatsHappeningSearchFilterDto
            {
                CategoryId = 1,
                PageNumber = 1,
                PageSize = 10
            };

            var result = await _whatsHappeningQueryService.GetWhatsHappeningBySearch(request);

            result.IsSuccess.Should().BeTrue();
            if (result.Result.Data.Count > 0)
            {
                result.Result.Data.Should().OnlyContain(x => x.CategoryId == 1);
            }
        }

        [Fact]
        public async Task GetWhatsHappeningBySearch_ShouldFilterByHospital()
        {
            var request = new WhatsHappeningSearchFilterDto
            {
                HospitalId = 1,
                PageNumber = 1,
                PageSize = 10
            };

            var result = await _whatsHappeningQueryService.GetWhatsHappeningBySearch(request);

            result.IsSuccess.Should().BeTrue();
            if (result.Result.Data.Count > 0)
            {
                result.Result.Data.Should().OnlyContain(x => x.LocationId == 1);
            }
        }
        [Fact]
        public async Task GetWhatsHappeningBySearch_ShouldFilterByStatus()
        {
            var request = new WhatsHappeningSearchFilterDto
            {
                Status = "true",
                PageNumber = 1,
                PageSize = 10
            };

            var result = await _whatsHappeningQueryService.GetWhatsHappeningBySearch(request);

            result.IsSuccess.Should().BeTrue();
            if (result.Result.Data.Count > 0)
            {
                result.Result.Data.Should().OnlyContain(x => x.Status);
            }
        }
        [Fact]
        public async Task GetWhatsHappeningBySearch_ShouldFilterByDateRange()
        {
            var request = new WhatsHappeningSearchFilterDto
            {
                StartDate = new DateTime(2024, 4, 12),
                EndDate = new DateTime(2025, 4, 12),
                PageNumber = 1,
                PageSize = 10
            };

            var result = await _whatsHappeningQueryService.GetWhatsHappeningBySearch(request);

            result.IsSuccess.Should().BeTrue();
            if (result.Result.Data.Count > 0)
            {
                result.Result.Data.Should().OnlyContain(x =>
                    x.StartDate >= request.StartDate && x.EndDate <= request.EndDate);
            }
        }
        [Fact]
        public async Task GetWhatsHappeningBySearch_ShouldMapAllFieldsCorrectly()
        {
            var request = new WhatsHappeningSearchFilterDto
            {
                PageNumber = 1,
                PageSize = 10
            };

            var result = await _whatsHappeningQueryService.GetWhatsHappeningBySearch(request);

            result.Should().NotBeNull();
            result.IsSuccess.Should().BeTrue();
            result.Result.Data.Should().HaveCount(1);

            var dto = result.Result.Data.First();
            dto.Id.Should().Be(1);
            dto.Title.Should().Be("Free Health Checkup");
            dto.Description.Should().Be("Event description");
            dto.Url.Should().Be("http://example.com");
            dto.ImageUrl.Should().Be("http://example.com/image.png");
            dto.StartDate.Should().Be(new DateTime(2024, 4, 12));
            dto.EndDate.Should().Be(new DateTime(2025, 4, 12));
            dto.Status.Should().BeTrue();
            dto.LocationId.Should().Be(101);
            dto.CategoryId.Should().Be(201);
            dto.Category.Should().Be("Health Camp");
            dto.LocationName.Should().Be("Test Hospital");
            dto.LocationLatitude.Should().Be(10.12m);
            dto.LocationLongitude.Should().Be(20.34m);
            dto.LocationCity.Should().Be("Test City");
            dto.LocationState.Should().Be("Test State");
            dto.RecordVersion.Should().NotBeNull();
            dto.CreatedBy.Should().Be("Tester");
            dto.UpdatedBy.Should().Be("Tester");
        }

        #endregion
        [Fact]
        public async Task GetCategoryList_ShouldReturnEmptyList_WhenNoCategoriesExist()
        {
            // Arrange
            _mockDbContext.CategoryMasters.RemoveRange(_mockDbContext.CategoryMasters);
            await _mockDbContext.SaveChangesAsync();

            // Act
            var result = await _whatsHappeningQueryService.GetCategoryList();

            // Assert
            result.Should().NotBeNull();
            result.Should().BeEmpty();
        }

        [Fact]
        public async Task GetCategoryList_ShouldReturnMappedList_WhenNonDeletedCategoriesExist()
        {
            // Arrange
            var categories = new List<CategoryMaster>
            {
                new CategoryMaster { ID = 1, Definition = "Health", IsDeleted = false, CreatedBy = "admin", CreatedDate = DateTime.UtcNow },
                new CategoryMaster { ID = 2, Definition = "Education", IsDeleted = false, CreatedBy = "admin", CreatedDate = DateTime.UtcNow }
            };

            _mockDbContext.CategoryMasters.AddRange(categories);
            await _mockDbContext.SaveChangesAsync();

            // Act
            var result = await _whatsHappeningQueryService.GetCategoryList();

            // Assert
            if (result != null)
            {
                result.Should().NotBeNull();
                result.Should().HaveCount(2);
                result.Should().ContainSingle(c => c.Definition == "Health");
                result.Should().ContainSingle(c => c.Definition == "Education");
            }
        }

        [Fact]
        public async Task GetCategoryList_ShouldReturnEmptyList_WhenAllCategoriesAreDeleted()
        {
            // Arrange
            var deletedCategories = new List<CategoryMaster>
                {
                    new CategoryMaster { ID = 3, Definition = "Deleted", IsDeleted = true, CreatedBy = "admin", CreatedDate = DateTime.UtcNow }
                };

            _mockDbContext.CategoryMasters.AddRange(deletedCategories);
            await _mockDbContext.SaveChangesAsync();

            // Act
            var result = await _whatsHappeningQueryService.GetCategoryList();

            // Assert
            if (result != null)
            {
                result.Should().NotBeNull();
                result.Should().BeEmpty();
            }
        }
    }
}
