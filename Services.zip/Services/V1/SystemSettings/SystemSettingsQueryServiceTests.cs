﻿using Aurora.AdministrationService.API.Services.Service.SystemSettings;
using Aurora.AdministrationService.CrossCutting.CommonModels;
using Aurora.AdministrationService.Domain.V1.Entities;
using Aurora.AdministrationService.Infrastructure;
using FluentAssertions;
using Microsoft.EntityFrameworkCore;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Aurora.AdministrationService.Tests.API.Services.V1.SystemSettings;
public class SystemSettingsQueryServiceTests
{
    private readonly DbContextOptions<ReadOnlyDbContext> _dbContextOptions;
    private readonly ReadOnlyDbContext _context;
    private readonly SystemSettingsQueryService _service;

    public SystemSettingsQueryServiceTests()
    {
        // Setup the in-memory database
        _dbContextOptions = new DbContextOptionsBuilder<ReadOnlyDbContext>()
            .UseInMemoryDatabase(Guid.NewGuid().ToString())  // Use a unique name for each test run
            .Options;

        // Initialize context and service
        _context = new ReadOnlyDbContext(_dbContextOptions);
        _service = new SystemSettingsQueryService(_context);
    }

    [Fact]
    public async Task GetSystemModulesAsync_ReturnsSystemModules_WhenThereAreNewUpdates()
    {
        // Arrange
        _context.FAQNew.Add(new Domain.V1.Entities.FAQ
        {
            UniqueID = "1",
            ID = 1,
            Status = true,
            Platforms = "1",
            IsDeleted = false,
            UpdatedDate = DateTime.Now.AddDays(-15),
            CreatedBy = "1",
            CreatedDate = DateTime.Now,
            UpdatedBy = "1",
        });

        _context.WhatsHappeningsNew.Add(new Domain.V1.Entities.Marketings.WhatsHappening
        {
            ID = 1,
            CreatedBy = "1",
            CreatedDate = DateTime.Now,
            UpdatedBy = "1",
            IsDeleted = false,
            Title = "Title",
            UpdatedDate = DateTime.Now.AddDays(-10),
            Description = "Description",
            CategoryID = 1,
            Image = "image.png"
        });

        _context.AgreementNew.Add(new Domain.V1.Entities.Agreement
        {
            ID = 1,
            CreatedBy = "1",
            CreatedDate = DateTime.Now,
            UpdatedBy = "1",
            Status = true,
            IsDeleted = false,
            UpdatedDate = DateTime.Now.AddDays(-5)
        });

        _context.ManageDoctorProfiles.Add(new ManageDoctorProfile
        {
            CreatedDate = DateTime.Now,
            FirstName = "Test",
            Id = 1,
            IsDeleted = false,
            LastName = "Test",
            PractitionerID = 1,
            CreatedBy = "1",
            UpdatedBy = "1",
            UpdatedDate = DateTime.Now.AddDays(-1)
        });

        await _context.SaveChangesAsync();

        // Act
        var response = await _service.GetSystemModulesAsync();

        // Assert
        response.IsSuccess.Should().BeTrue();
        response.HasError.Should().BeFalse();
        response.StatusCode.Should().Be(ResponseStatus.STATUS_SUCCESS);

        response.Result.Should().NotBeNull();
        response.Result.Should().ContainSingle(m => m.ModuleName == "FAQs" && m.IsNewlyUpdated);
        response.Result.Should().ContainSingle(m => m.ModuleName == "WhatsHappening" && m.IsNewlyUpdated);
        response.Result.Should().ContainSingle(m => m.ModuleName == "Agreements" && m.IsNewlyUpdated);
        response.Result.Should().ContainSingle(m => m.ModuleName == "Admin_DoctorProfiles" && m.IsNewlyUpdated);
    }

    [Fact]
    public async Task GetSystemModulesAsync_ReturnsEmptyList_WhenNoNewUpdates()
    {
        // Arrange
        _context.FAQNew.Add(new Domain.V1.Entities.FAQ
        {
            UniqueID = "1",
            ID = 1,
            Status = true,
            Platforms = "1",
            IsDeleted = false,
            UpdatedDate = DateTime.Now.AddDays(-40),
            CreatedBy = "1",
            CreatedDate = DateTime.Now,
            UpdatedBy = "1",
        });

        _context.WhatsHappeningsNew.Add(new Domain.V1.Entities.Marketings.WhatsHappening
        {
            ID = 1,
            CreatedBy = "1",
            CreatedDate = DateTime.Now,
            UpdatedBy = "1",
            IsDeleted = false,
            Title = "Title",
            UpdatedDate = DateTime.Now.AddDays(-40),
            Description = "Description",
            CategoryID = 1,
            Image = "image.png"
        });

        _context.AgreementNew.Add(new Domain.V1.Entities.Agreement
        {
            ID = 1,
            CreatedBy = "1",
            CreatedDate = DateTime.Now,
            UpdatedBy = "1",
            Status = true,
            IsDeleted = false,
            UpdatedDate = DateTime.Now.AddDays(-40)
        });

        _context.ManageDoctorProfiles.Add(new ManageDoctorProfile
        {
            CreatedDate = DateTime.Now,
            FirstName = "Test",
            Id = 1,
            IsDeleted = false,
            LastName = "Test",
            PractitionerID = 1,
            UpdatedDate = DateTime.Now.AddDays(-40),
            CreatedBy = "1",
            UpdatedBy = "1",
        });

        await _context.SaveChangesAsync();

        // Act
        var response = await _service.GetSystemModulesAsync();

        // Assert
        response.IsSuccess.Should().BeTrue();
        response.HasError.Should().BeFalse();
        response.StatusCode.Should().Be(ResponseStatus.STATUS_SUCCESS);

        response.Result.Should().BeEmpty(); // Add this if you want to validate the empty list
    }
}

