﻿//using Aurora.AdministrationService.API.Enum;
//using Aurora.AdministrationService.API.Models.RequestModels.V1.AdminDoctor;
//using Aurora.AdministrationService.API.Services.Service.AdminDoctor;
//using Aurora.AdministrationService.Domain.V1.Entities.InsurancePanels;
//using Aurora.AdministrationService.Domain.V1.Entities.PractitionerRoles;
//using Aurora.AdministrationService.Domain.V1.Entities.Practitioners;
//using Aurora.AdministrationService.Infrastructure;
//using FluentAssertions;
//using Microsoft.EntityFrameworkCore;
//using Moq;

//namespace Aurora.AdministrationService.Tests.API.Services.V1;

//public class PractitionerQueryServicesTest
//{
//    private readonly ReadOnlyDbContext _dbContext;
//    private readonly DoctorQueryService _doctorQueryService;

//    public PractitionerQueryServicesTest()
//    {
//        var options = new DbContextOptionsBuilder<ReadOnlyDbContext>()
//            .UseInMemoryDatabase(databaseName: Guid.NewGuid().ToString())
//            .Options;

//        _dbContext = new ReadOnlyDbContext(options);
//        _doctorQueryService = new DoctorQueryService(_dbContext);

//        SeedDatabase();
//    }

//    private void SeedDatabase()
//    {
//        _dbContext.InsurancePanelLocations.Add(new InsurancePanelLocation
//        {
//            Id = 1,
//            InsurancePanelID = 1,  // Matching InsuranceId
//            LocationID = "101",     // Matching HospitalId
//            IsDeleted = false,
//            CreatedBy = "TestUser",
//            CreatedDate = DateTime.UtcNow,
//            UpdatedBy = "admin"
//        });

//        var practitioner = new Practitioner
//        {
//            Id = 1,
//            ResourceID = "PRAC001",
//            Status = true,
//            Gender = "Male",
//            BirthDate = new DateTime(1985, 5, 20),
//            Source = "System",
//            IsDeleted = false,
//            CreatedBy = "Admin",
//            CreatedDate = DateTime.UtcNow,
//            UpdatedBy = "admin",
//            PractitionerRole = new List<PractitionerRole>
//        {
//            new PractitionerRole
//            {
//                Id = 1,
//                UUID = Guid.NewGuid(),
//                PractitionerID = 1,
//                OrganizationID = 101,
//                PeriodStart = new DateTime(2023, 1, 1),
//                PeriodEnd = new DateTime(2025, 12, 31),
//                Active = true,
//                AvailabilityExceptions = "Unavailable on public holidays",
//                IsDeleted = false,
//                CreatedBy = "Admin",
//                CreatedDate = DateTime.UtcNow,
//                UpdatedBy = "admin",
//                PractitionerRoleLocation = new List<PractitionerRoleLocation>
//                {
//                    new PractitionerRoleLocation
//                    {
//                        Id = 1,
//                        PractitionerRoleID = 1,
//                        locationID = 101, // Matching HospitalId
//                        IsInternalPractitioner = true,
//                        IsDeleted = false,
//                        CreatedBy = "Admin",
//                        CreatedDate = DateTime.UtcNow,
//                        UpdatedBy = "admin"
//                    }
//                },
//                PractitionerRoleSpecialty = new PractitionerRoleSpecialty
//                {
                   
//                        Id = 1,
//                        PractitionerRoleID = 1,
//                        specialty = "Cardiology", // Matching Specialties
//                        IsDeleted = false,
//                        CreatedBy = "Admin",
//                        CreatedDate = DateTime.UtcNow,
//                        UpdatedBy = "admin"
                    
//                }
//            }
//        },
//            PractitionerCommunication = new List<PractitionerCommunication>
//        {
//            new PractitionerCommunication
//            {
//                Id = 1,
//                PractitionerID = 1,
//                Language = "English", // Matching Language
//                Preferred = true,
//                Status = true,
//                IsDeleted = false,
//                CreatedBy = "Admin",
//                CreatedDate = DateTime.UtcNow,
//                UpdatedBy = "admin"
//            }
//        }
//        };

//        _dbContext.Practitioners.Add(practitioner);
//        _dbContext.SaveChanges();
//    }
//    [Fact]
//    public async Task GetDoctorSearchByFilter_ShouldReturnMatchingDoctors()
//    {
//        // Arrange
//        var searchCriteria = new DoctorSearchCriteriaRequest
//        {
//            Specialties = new List<string> { "cardiology" },
//            Genders = new List<string> { "Male" },
//            Language = new List<string> { "english" }
//        };

//        // Act
//        var result = await _doctorQueryService.GetDoctorSearchByFilter(searchCriteria);

//        // Assert
//        result.Should().NotBeNull();
//        result.Should().HaveCount(1);

//    }

//    [Fact]
//    public async Task SearchDoctorByNameAndSpeciality_ShouldReturnNoData_WhenNoMatchingDoctors()
//    {
//        // Arrange
//        var practitioners = new List<Practitioner>();
//        var mockDbSet = new Mock<DbSet<Practitioner>>();
//        var specialist = new List<PractitionerRoleSpecialty>();
//        var mockDbSett = new Mock<DbSet<PractitionerRoleSpecialty>>();
//        mockDbSet.Setup(m => m.AsQueryable()).Returns(Enumerable.Empty<Practitioner>().AsQueryable());
//        mockDbSett.Setup(m => m.AsQueryable()).Returns(Enumerable.Empty<PractitionerRoleSpecialty>().AsQueryable());

//        // Act
//        var result = await _doctorQueryService.SearchDoctorByNameAndSpeciality("Unknown");

//        // Assert
//        Assert.NotNull(result);
//        Assert.False(result.IsSuccess);
//        Assert.Equal(((int)ResponceStatusCode.RecordNotFound).ToString(), result.StatusCode);
//    }
//    [Fact]
//    public async Task SearchDoctorByNameAndSpeciality_SearchIsEmptyString_ReturnsAllDoctors()
//    {

//        // Arrange
//        var practitioners = new List<Practitioner>();
//        var mockDbSet = new Mock<DbSet<Practitioner>>();
//        var specialist = new List<PractitionerRoleSpecialty>();
//        var mockDbSett = new Mock<DbSet<PractitionerRoleSpecialty>>();
//        mockDbSet.Setup(m => m.AsQueryable()).Returns(Enumerable.Empty<Practitioner>().AsQueryable());
//        mockDbSett.Setup(m => m.AsQueryable()).Returns(Enumerable.Empty<PractitionerRoleSpecialty>().AsQueryable());

//        // Act
//        var result = await _doctorQueryService.SearchDoctorByNameAndSpeciality(string.Empty);

//        // Assert
//        Assert.True(result.IsSuccess);
//    }
//}