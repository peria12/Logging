﻿using Aurora.AdministrationService.API.Controllers.AdminOrganization;
using Aurora.AdministrationService.API.Services.Service.AdminOrganization;
using Aurora.AdministrationService.API.Services.Service.Organizations;
using Aurora.AdministrationService.CrossCutting.CommonModels;
using Aurora.AdministrationService.CrossCutting.Constants;
using Aurora.AdministrationService.CrossCutting.HttpService;
using Aurora.AdministrationService.Infrastructure;
using Aurora.AdministrationService.Tests.API.Services.Locations;
using FluentAssertions;
using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.Logging;
using Moq;

namespace Aurora.AdministrationService.Tests.API.Services.V1.Organization
{
    public class OrganizationsQueryServiceTests : TestsBase<OrganizationsQueryService>
    {
        private readonly DbContextOptions<ReadOnlyDbContext> _dbOptions;

        public OrganizationsQueryServiceTests()
        {
            _dbOptions = new DbContextOptionsBuilder<ReadOnlyDbContext>()
                .UseInMemoryDatabase(databaseName: Guid.NewGuid().ToString()) // Unique DB for each test
                .Options;
        }

        private OrganizationsQueryService CreateService(ReadOnlyDbContext readOnlyDbContext)
        {
            return new OrganizationsQueryService(readOnlyDbContext);
        }

        private static void SeedTestData(ReadOnlyDbContext readOnlyDbContext)
        {
            var locations = LocationQueryMockData.GetLocationData();
            var locationAddresses = LocationQueryMockData.GetLocationAddressesData();
            var locationTelecoms = LocationQueryMockData.GetLocationTelecomData();
            var locationImages = LocationQueryMockData.locationImageData();

            readOnlyDbContext.Locations.AddRange(locations);
            readOnlyDbContext.LocationAddresses.AddRange(locationAddresses);
            readOnlyDbContext.LocationTelecoms.AddRange(locationTelecoms);
            readOnlyDbContext.LocationImages.AddRange(locationImages);
            readOnlyDbContext.SaveChanges();
        }

        [Fact]
        public void GetHospitalListByDistance_ReturnsNotFound_WhenNoRecordsExist()
        {
            var readOnlyDbContext = GetReadOnlyDBContextInMemory();
            var organizationsQueryService = CreateService(readOnlyDbContext);

            var result = organizationsQueryService.GetHospitalListByDistance(0, 0, false);

            result.IsSuccess.Should().BeTrue();
            result.HasError.Should().BeFalse();
            result.StatusCode.Should().Be((ResponseStatusCode.STATUS_NOTFOUND).ToString());
            result.Message.Should().Be(ResponseMessage.STATUS_NODATA);
            result.Results.Should().BeNullOrEmpty();
        }

        [Fact]
        public void GetHospitalListByDistance_ReturnsSuccess_WhenRecordsExist()
        {
            var readOnlyDbContext = GetReadOnlyDBContextInMemory();
            SeedTestData(readOnlyDbContext); // Seed mock data

            var organizationsQueryService = CreateService(readOnlyDbContext);

            var result = organizationsQueryService.GetHospitalListByDistance(0, 0, true);

            result.IsSuccess.Should().BeTrue();
            result.HasError.Should().BeFalse();
            result.StatusCode.Should().Be((ResponseStatus.STATUS_SUCCESS).ToString());
            result.Results.Should().NotBeNull();
            result.Results.Should().NotBeEmpty();
            result.Results.Should().HaveCountGreaterThan(0);
        }
        [Fact]
        public async Task GetHospitals_ShouldReturnHospitalList_WhenDataExists()
        {
            // Arrange
            using var context = new ReadOnlyDbContext(_dbOptions);
            context.Organizations.AddRange(
                new Domain.V1.Entities.Organizations.Organization
                {
                    Id = 1,
                    Name = "Hospital A",
                    Alias = "Alias A",
                    IsDeleted = false,
                    ResourceID = "Test",
                    CreatedBy = "Admin",
                    CreatedDate = DateTime.Now,
                    Source = "Test",
                    Type ="test",
                    UpdatedBy = "Test",
                },
                new Domain.V1.Entities.Organizations.Organization
                {
                    Id = 2,
                    Name = "Hospital B",
                    Alias = "Alias B",
                    IsDeleted = false,
                     ResourceID = "Test",
                    CreatedBy = "Admin",
                    CreatedDate = DateTime.Now,
                    Source = "Test",
                    Type = "test",
                    UpdatedBy = "Test",
                }
            );
            await context.SaveChangesAsync();

            var service = new OrganizationsQueryService(context);

            // Act
            var result = await service.GetHospitals();

            // Assert
            result.Should().NotBeNull();
            result.IsSuccess.Should().BeTrue();
            result.HasError.Should().BeFalse();
            result.StatusCode.Should().Be(ResponseStatus.STATUS_SUCCESS);
            result.Results.Should().HaveCount(2);
            result.Results.Should().ContainSingle(h => h.Name == "Hospital A");
            result.Results.Should().ContainSingle(h => h.Name == "Hospital B");
        }
    }
}
