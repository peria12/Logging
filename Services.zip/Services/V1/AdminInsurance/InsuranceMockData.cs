﻿using Aurora.AdministrationService.Domain.V1.Entities.InsurancePanels;
using System;
using System.Collections.Generic;
using System.Linq;

namespace Aurora.AdministrationService.Tests.API.Services.V1.AdminInsurance
{
    public class InsuranceMockData
    {
        public static IQueryable<InsurancePanel> GetSampleInsurancePanels()
        {
            var insurancePanels = new List<InsurancePanel>
            {
                new InsurancePanel { Id = 1, DebtorName = "ABC Insurance", Logo = "Logo1", ResourceID = "1", Status = true, IsDeleted = false, CreatedBy = "test", CreatedDate = DateTime.UtcNow, UpdatedBy = "test" },
                new InsurancePanel { Id = 2, DebtorName = "XYZ Insurance", Logo = "Logo2", ResourceID = "2", Status = true, IsDeleted = false, CreatedBy = "test", CreatedDate = DateTime.UtcNow, UpdatedBy = "test" },
                new InsurancePanel { Id = 3, DebtorName = "DEF Insurance", Logo = "Logo3", ResourceID = "3", Status = true, IsDeleted = false, CreatedBy = "test", CreatedDate = DateTime.UtcNow, UpdatedBy = "test" }
            };

            return insurancePanels.AsQueryable();
        }

        public static IQueryable<InsurancePanelLocation> GetSampleInsurancePanelLocations()
        {
            return new List<InsurancePanelLocation>
            {
                new InsurancePanelLocation { Id = 1, InsurancePanelID = 1, LocationID = "1", CreatedBy = "test", CreatedDate = DateTime.UtcNow, UpdatedBy = "test", IsDeleted = false },
                new InsurancePanelLocation { Id = 2, InsurancePanelID = 2, LocationID = "1", CreatedBy = "test", CreatedDate = DateTime.UtcNow, UpdatedBy = "test", IsDeleted = false },
                new InsurancePanelLocation { Id = 3, InsurancePanelID = 3, LocationID = "1", CreatedBy = "test", CreatedDate = DateTime.UtcNow, UpdatedBy = "test", IsDeleted = false }
            }.AsQueryable();
        }
    }
}
