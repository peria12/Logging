﻿using Aurora.AdministrationService.API.Services.Service.AdminInsurance;
using Aurora.AdministrationService.CrossCutting.CommonModels;
using Aurora.AdministrationService.Infrastructure;
using AutoMapper;
using Moq;
using Aurora.AdministrationService.API.Enum;
using FluentAssertions;

namespace Aurora.AdministrationService.Tests.API.Services.V1.AdminInsurance
{
    public class InsuranceQueryServiceTests : TestsBase<InsuranceQueryService>
    {
        private InsuranceQueryService CreateService(ReadOnlyDbContext readOnlyDbContext)
        {
            return new InsuranceQueryService(readOnlyDbContext, _mockMapper.Object);
        }

        private static void SeedTestData(ReadOnlyDbContext readOnlyDbContext)
        {
            var insurancePanels = InsuranceMockData.GetSampleInsurancePanels();
            var insuranceLocations = InsuranceMockData.GetSampleInsurancePanelLocations();
            readOnlyDbContext.InsurancePanels.AddRange(insurancePanels);
            readOnlyDbContext.InsurancePanelLocations.AddRange(insuranceLocations);
            readOnlyDbContext.SaveChanges();
        }

        [Fact]
        public async Task GetAllInsuranceList_ReturnsRecordNotFound_WhenNoRecordsExist()
        {
            var readOnlyDbContext = GetReadOnlyDBContextInMemory();
            var insuranceQueryService = CreateService(readOnlyDbContext);
            var result = await insuranceQueryService.GetAllInsuranceList();
            result.IsSuccess.Should().BeTrue();             
            result.HasError.Should().BeFalse();
            result.StatusCode.Should().Be(((int)ResponceStatusCode.RecordNotFound).ToString());
            result.Message.Should().Be(ResponseMessage.STATUS_NODATA);             
            result.Results.Should().BeNullOrEmpty();         }

        [Fact]
        public async Task GetAllInsuranceList_ReturnsSuccess_WhenRecordsExist()
        {
            var readOnlyDbContext = GetReadOnlyDBContextInMemory();
            SeedTestData(readOnlyDbContext);              
            var insuranceQueryService = CreateService(readOnlyDbContext);
            var result = await insuranceQueryService.GetAllInsuranceList();
            result.IsSuccess.Should().BeTrue();             
            result.HasError.Should().BeFalse();
            result.StatusCode.Should().Be(((int)ResponceStatusCode.Success).ToString());
            result.Message.Should().Be(ResponseMessage.STATUS_SUCCESS);
            result.Results.Should().NotBeEmpty();
            result.Results.Should().HaveCountGreaterThan(0);
        }
    }
}
