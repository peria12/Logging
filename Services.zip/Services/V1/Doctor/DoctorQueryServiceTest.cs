﻿using Aurora.AdministrationService.API.Enum;
using Aurora.AdministrationService.API.Helper;
using Aurora.AdministrationService.API.Models.ResponseModels.V1.AdminDoctor;
using Aurora.AdministrationService.API.Resources;
using Aurora.AdministrationService.API.Services.Service.AdminDoctor;
using Aurora.AdministrationService.CrossCutting.CommonModels;
using Aurora.AdministrationService.Domain.V1.Entities.Languade;
using Aurora.AdministrationService.Domain.V1.Entities.PractitionerRoles;
using Aurora.AdministrationService.Domain.V1.Entities.Practitioners;
using Aurora.AdministrationService.Infrastructure;
using Aurora.AdministrationService.Tests.API.Services.V1.Doctor.MockData;
using AutoMapper;
using FluentAssertions;
using Microsoft.EntityFrameworkCore;
using Moq;

namespace Aurora.AdministrationService.Tests.API.Services.V1.Doctor
{
    public class DoctorQueryServiceTest : PractitionerMockData
    {
        private readonly ReadOnlyDbContext _dbContext;
        private readonly Mock<IMapper> _mockMapper;
        private readonly DoctorQueryService _doctorQueryService;
        private readonly DbContextOptions<ReadOnlyDbContext> _options;
        private readonly Mock<IResponseMessageHelper<LanguageV1>> _locationResponseMessageHelper;
        private readonly Mock<IResponseMessageHelper<Practitioner>> _practitionerMock;
        private readonly Mock<IResponseMessageHelper<LanguageResponseDto>> _locationTypeResponseMessageHelper;

        public DoctorQueryServiceTest()
        {
            // Initialize database options
            _options = new DbContextOptionsBuilder<ReadOnlyDbContext>()
                .UseInMemoryDatabase(databaseName: Guid.NewGuid().ToString()) // Unique DB for each test
                .Options;

            // Initialize DbContext
            _dbContext = new ReadOnlyDbContext(_options);

            // Initialize Mocks
            _mockMapper = new Mock<IMapper>();
            _practitionerMock = new Mock<IResponseMessageHelper<Practitioner>>();
            _locationResponseMessageHelper = new Mock<IResponseMessageHelper<LanguageV1>>();
            _locationTypeResponseMessageHelper = new Mock<IResponseMessageHelper<LanguageResponseDto>>();

            // Initialize service with valid DbContext
            _doctorQueryService = new DoctorQueryService(_dbContext);

        }

        
        [Fact]
        public async Task GetDoctorProfile_DoctorNotFound_ReturnsNotFoundResponse()
        {
            // Arrange
            var doctorProfileId = 999; // Non-existing ID
            var mockDbSet = new Mock<DbSet<Practitioner>>();
            mockDbSet.Setup(m => m.AsQueryable()).Returns(Enumerable.Empty<Practitioner>().AsQueryable());
            // Act
            var response = await _doctorQueryService.GetDoctorProfile(doctorProfileId);

            // Assert
            Assert.False(response.IsSuccess);
            Assert.True(response.HasError);
            Assert.Equal(ResponseStatus.STATUS_NotFound, response.StatusCode);
            Assert.Equal(Resource.RecordNotFound, response.Message);
        }

        [Fact]
        public async Task GetDoctorProfile_ThrowsException_ReturnsInternalServerErrorResponse()
        {
            // Arrange
            var doctorProfileId = 1;

            // Act
            var response = await _doctorQueryService.GetDoctorProfile(doctorProfileId);

            // Assert
            Assert.False(response.IsSuccess);
            Assert.True(response.HasError);
        }

       
    }
}