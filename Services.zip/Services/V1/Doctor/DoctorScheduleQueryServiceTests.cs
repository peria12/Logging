﻿using Microsoft.EntityFrameworkCore;
using Moq;
using FluentAssertions;
using Aurora.AdministrationService.CrossCutting.Constants;
using Aurora.AdministrationService.Domain.V1.Entities.PractitionerRoles;
using Aurora.AdministrationService.Infrastructure;
using AutoMapper;
using Aurora.AdministrationService.Tests.API.Services.V1.Doctor.MockData;
using Aurora.AdministrationService.CrossCutting.CommonModels;
using Aurora.AdministrationService.API.Services.Service.AdminDoctor;

namespace Aurora.AdministrationService.Tests.API.Services.V1.Doctor
{
    public class DoctorScheduleServiceTests : PractitionerMockData
    {
        private readonly ReadOnlyDbContext _dbContext;
        private readonly Mock<IMapper> _mockMapper;
        private readonly DoctorQueryService _doctorQueryService;
        private readonly DbContextOptions<ReadOnlyDbContext> _options;

        public DoctorScheduleServiceTests()
        {
            // Initialize database options
            _options = new DbContextOptionsBuilder<ReadOnlyDbContext>()
                .UseInMemoryDatabase(databaseName: Guid.NewGuid().ToString())
                .Options;

            // Initialize DbContext
            _dbContext = new ReadOnlyDbContext(_options);

            // Initialize Mocks
            _mockMapper = new Mock<IMapper>();

            // Initialize the service using the in-memory context
            _doctorQueryService = new DoctorQueryService(_dbContext);
        }

        [Fact]
        public async Task GetDoctorScheduleAsync_Should_Return_NoData_When_Practitioner_Not_Found()
        {
            // Arrange

            // Act
            var result = await _doctorQueryService.GetDoctorScheduleAsync("1", 1, DateTime.UtcNow, DateTime.UtcNow.AddDays(7));

            // Assert
            // Assert
            result.Should().NotBeNull();
            result.HasError.Should().BeFalse();
            result.Result.Should().BeNull();
        }

        [Fact]
        public async Task GetDoctorScheduleAsync_Should_Return_NoData_When_Date_Range_Invalid()
        {
            // Arrange
            var practitioner = new PractitionerRole
            {
                Id = 1,
                PractitionerID = "1",
                UUID = Guid.NewGuid(),
                IsDeleted = false,
                CreatedDate = DateTime.UtcNow,
                CreatedBy = "",
                UpdatedBy = "",
                AvailabilityExceptions = "",
                PractitionerRoleLocation = new List<PractitionerRoleLocation> { new PractitionerRoleLocation { locationID = 1,IsDeleted = false,UpdatedBy="",
                CreatedBy = "",
                CreatedDate = DateTime.UtcNow,IsInternalPractitioner=true,PractitionerRoleID=1 } }
            };

            var availability = new PractitionerAvailability
            {
                Id = 1,
                PractitionerRoleId = 1,
                ScheduleStartDate = DateTime.UtcNow.AddDays(10), // Out of requested range
                ScheduleEndDate = DateTime.UtcNow.AddDays(15),
                SlotsID = 123,
                IsDeleted = false,
                CreatedBy = "",
                CreatedDate = DateTime.UtcNow,
                UpdatedBy = ""
            };

            _dbContext.PractitionerRoles.Add(practitioner);
            _dbContext.PractitionerAvailabilities.Add(availability);
            await _dbContext.SaveChangesAsync();

            // Act
            var result = await _doctorQueryService.GetDoctorScheduleAsync("1", 1, DateTime.UtcNow, DateTime.UtcNow.AddDays(7));

            // Assert
            result.Should().NotBeNull();
            result.HasError.Should().BeFalse();
            result.Result.Should().BeNull();
        }

        [Fact]
        public async Task GetDoctorScheduleAsync_ShouldReturnDoctorSchedule_WhenDoctorRoleExists()
        {
            // Arrange
            var practitionerId = "121";
            var locationId = 1;
            var selectedStartDate = new DateTime(2025, 2, 22);
            var selectedEndDate = new DateTime(2025, 2, 23);

            // Seed data into the in-memory database
            _dbContext.PractitionerRoles.Add(GetMockPractitionerRole());
            _dbContext.SaveChanges();

            var doctorQueryService = new DoctorQueryService(_dbContext);

            // Act
            var result = await doctorQueryService.GetDoctorScheduleAsync(practitionerId, locationId, selectedStartDate, selectedEndDate);

            // Assert
            result.Should().NotBeNull();
            result.IsSuccess.Should().BeTrue();
            result.StatusCode.Should().Be(ResponseStatus.STATUS_SUCCESS);
            result.Result.Should().NotBeNull();
            result.Result?.FirstName.Should().Be("John");
            result.Result?.LastName.Should().Be("Doe");
            result.Result?.Specialty.Should().Be("Cardiology");
        }

        [Fact]
        public async Task GetDays_ShouldReturnCalendarDays_WhenAvailabilityDataExists()
        {
            // Arrange
            var selectedStartDate = new DateTime(2025, 2, 01);
            var selectedEndDate = new DateTime(2025, 2, 28);

            // Prepare mock data
            var practitionerRole = GetMockPractitionerRole();
            _dbContext.PractitionerRoles.Add(practitionerRole);
            _dbContext.PractitionerAvailabilities.AddRange(GetMockPractitionerAvailabilityData());
            _dbContext.PractitionerAvailabilityOccurances.AddRange(GetMockPractitionerAvailabilityOccuranceData());
            _dbContext.PractitionerAvailabilityDays.AddRange(GetMockPractitionerAvailabilityDayData());
            _dbContext.SaveChanges();

            // Act
            var result = await _doctorQueryService.GetDays(selectedStartDate, selectedEndDate, practitionerRole);

            // Assert
            result.Should().NotBeNull();
            result.Should().HaveCountGreaterThan(0);

            var firstDay = result[0];
            firstDay.Date.Should().Be(new DateTime(2025, 2, 01));
            firstDay.SlotsId.Should().Be(123);
            firstDay.IsAvailable.Should().BeTrue();
            firstDay.IsHoliday.Should().BeFalse();
            firstDay.IsNotAvailable.Should().BeFalse();
        }

        [Fact]
        public async Task GetDays_ShouldFilterOutNonBookableIntervals()
        {
            // Arrange
            var selectedStartDate = new DateTime(2025, 2, 01, 0, 0, 0, DateTimeKind.Local);
            var selectedEndDate = new DateTime(2025, 2, 28, 0, 0, 0, DateTimeKind.Local);

            // Prepare mock data
            var practitionerRole = GetMockPractitionerRole();
            _dbContext.PractitionerRoles.Add(practitionerRole);

            var mockDataWithNonBookableInterval = new List<PractitionerAvailability>
        {
            new PractitionerAvailability
            {
                Id = 1,
                SlotsID = 123,
                PractitionerRoleId = 1,
                ScheduleStartDate = new DateTime(2025, 2, 01, 0, 0, 0, DateTimeKind.Local),
                ScheduleEndDate = new DateTime(2025, 2, 28, 0, 0, 0, DateTimeKind.Local).AddMinutes(ScheduleConfig.NonBookableInterval.TotalMinutes - 1),  // Non-bookable interval
                IsDeleted = false,
                CreatedBy="Admin",
                CreatedDate=DateTime.UtcNow,
                UpdatedBy="Admin",
                UpdatedDate=DateTime.UtcNow,
            }
        };

            _dbContext.PractitionerAvailabilities.AddRange(mockDataWithNonBookableInterval);
            _dbContext.PractitionerAvailabilityOccurances.AddRange(GetMockPractitionerAvailabilityOccuranceData());
            _dbContext.PractitionerAvailabilityDays.AddRange(GetMockPractitionerAvailabilityDayData());
            _dbContext.SaveChanges(); // Save to in-memory database

            // Act
            var result = await _doctorQueryService.GetDays(selectedStartDate, selectedEndDate, practitionerRole);

            // Assert
            result.Should().NotBeNull();
        }
    }
}