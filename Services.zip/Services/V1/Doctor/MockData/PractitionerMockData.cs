﻿using Aurora.AdministrationService.API.Models.ResponseModels.V1.AdminDoctor;
using Aurora.AdministrationService.Domain.V1.Entities.PractitionerRoles;
using Aurora.AdministrationService.Domain.V1.Entities.Practitioners;
using Aurora.AdministrationService.Domain.V1.Entities;
using Aurora.AdministrationService.Domain.V1.Entities.Locations;

namespace Aurora.AdministrationService.Tests.API.Services.V1.Doctor.MockData
{
    public class PractitionerMockData
    {
        /// <summary>
        /// Get mock practitioner role data
        /// </summary>
        protected static PractitionerRole GetMockPractitionerRole()
        {
            return new PractitionerRole
            {
                Id = 1,
                PractitionerID = "121",
                CreatedBy = "Admin",
                CreatedDate = DateTime.UtcNow,
                IsDeleted = false,
                UpdatedBy = "Admin",
                UpdatedDate = DateTime.UtcNow,
                UUID = Guid.NewGuid(),
                AvailabilityExceptions = "1",
                PractitionerRoleLocation = new List<PractitionerRoleLocation>
                {
                new PractitionerRoleLocation { locationID = 1, IsDeleted=false,CreatedBy="Admin",CreatedDate=DateTime.UtcNow,PractitionerRoleID=1, IsInternalPractitioner=true,UpdatedBy="Admin", UpdatedDate=DateTime.UtcNow,
                    Location = new Location {PartOf="Test PartOf", Name = "Clinic A", ResourceID="121", Status=true, CreatedBy="Admin",CreatedDate=DateTime.UtcNow,IsDeleted=false, UpdatedBy="Admin", UpdatedDate=DateTime.UtcNow } }

                },
                Practitioner = new Practitioner
                {
                    ResourceID = "121",
                    Status = true,
                    CreatedBy = "Admin",
                    CreatedDate = DateTime.UtcNow,
                    IsDeleted = false,
                    UpdatedBy = "Admin",
                    UpdatedDate = DateTime.UtcNow,
                    Gender = "Male",
                    Source = "Admin",
                    ManageDoctorProfile = new List<ManageDoctorProfile>
                {
                    new ManageDoctorProfile { Id = 1, FirstName = "John", LastName = "Doe", MiddleName = "C", PractitionerID=1,
                        CreatedBy="Admin", CreatedDate=DateTime.UtcNow,IsDeleted=false,UpdatedBy="Admin", UpdatedDate=DateTime.UtcNow,
                    Description="Manage Doctor Profile", Designation="Doctor", Rank="1", Title="Manage profile"}
                },
                    PractitionerPhotos = new List<PractitionerPhotos>(),
                },
                PractitionerRoleSpecialty = new PractitionerRoleSpecialty
             { Specialty = "Cardiology", PractitionerRoleID=1,CreatedDate=DateTime.UtcNow,IsDeleted=false,UpdatedBy="Admin", UpdatedDate=DateTime.UtcNow,CreatedBy="Admin" }
            
            };
        }

        public static List<PractitionerAvailabilityOccurance> GetMockPractitionerAvailabilityOccuranceData()
        {
            return new List<PractitionerAvailabilityOccurance>
        {
            new PractitionerAvailabilityOccurance
            {
                Id = 1,
                PractitionerAvailabilityDayID = 1,
                CreatedBy = "Admin",
                CreatedDate = DateTime.UtcNow,
                IsDeleted = false,
                UpdatedBy = "Admin",
                UpdatedDate = DateTime.UtcNow,
                OccuranceType="3",


            },
            new PractitionerAvailabilityOccurance
            {
                Id = 2,
                PractitionerAvailabilityDayID = 2,
                CreatedBy = "Admin",
                CreatedDate = DateTime.UtcNow,
                IsDeleted = false,
                UpdatedBy = "Admin",
                UpdatedDate = DateTime.UtcNow,
                OccuranceType="4",
            }
        };
        }

        public static List<PractitionerAvailability> GetMockPractitionerAvailabilityData()
        {
            return new List<PractitionerAvailability>
        {
            new PractitionerAvailability
            {
                Id = 1,
                SlotsID = 123,
                PractitionerRoleId = 1,
                ScheduleStartDate = new DateTime(2025, 2, 01),
                ScheduleEndDate = new DateTime(2025, 2, 28).AddHours(1),
                IsDeleted = false,
                CreatedBy="Admin",
                CreatedDate=DateTime.UtcNow,
                UpdatedBy="Admin",
                UpdatedDate=DateTime.UtcNow,
            },
            new PractitionerAvailability
            {
                Id = 2,
                SlotsID = 124,
                PractitionerRoleId = 1,
                ScheduleStartDate = new DateTime(2025, 2, 01),
                ScheduleEndDate = new DateTime(2025, 2, 28).AddHours(1),
                IsDeleted = false,
                CreatedBy="Admin",
                CreatedDate=DateTime.UtcNow,
                UpdatedBy="Admin",
                UpdatedDate=DateTime.UtcNow,
            }
        };
        }

        public static List<PractitionerAvailabilityDay> GetMockPractitionerAvailabilityDayData()
        {
            return new List<PractitionerAvailabilityDay>
        {
            new PractitionerAvailabilityDay
            {
                Id = 1,
                IsDeleted = false,
                CreatedBy = "Admin",
                CreatedDate = DateTime.UtcNow,
                AvailabilityDay="Monday",
                PractitionerAvailabilityID=1,
                UpdatedBy="Admin",
                UpdatedDate=DateTime.UtcNow

            },
            new PractitionerAvailabilityDay
            {
                Id = 2,
                IsDeleted = false,
                CreatedBy = "Admin",
                CreatedDate = DateTime.UtcNow,
                AvailabilityDay="Tuesday",
                PractitionerAvailabilityID=1,
                UpdatedBy="Admin",
                UpdatedDate=DateTime.UtcNow
            }
        };
        }

    }
}
