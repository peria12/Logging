﻿using System.IdentityModel.Tokens.Jwt;
using Aurora.AdministrationService.API.Services.Service.Token;
using Microsoft.Extensions.Configuration;
using Microsoft.IdentityModel.Tokens;
using Moq;

namespace Aurora.AdministrationService.Tests.API.Services.V1.Token
{
    public class TokenQueryServiceTests
    {
        private readonly Mock<IConfiguration> _configurationMock;
        private readonly TokenQueryService _tokenQueryService;

        public TokenQueryServiceTests()
        {
            _configurationMock = new Mock<IConfiguration>();
            _tokenQueryService = new TokenQueryService(_configurationMock.Object);
        }       

        [Fact]
        public async Task GenerateToken_ReturnsEmpty_SecretKeyNotConfigured()
        {
            // Arrange
            var userId = "testUserId";
            var userRole = "Admin";
            _configurationMock.Setup(c => c.GetSection("JwtSecretKey").Value).Returns<string>(null);  // No secret key configured

            // Act
            var result = await _tokenQueryService.GenerateToken(userId, userRole);

            // Assert
            Assert.Equal(string.Empty, result);
        }

        [Fact]
        public async Task GenerateToken_ReturnsEmpty_OnException()
        {
            // Arrange
            var userId = "testUserId";
            var userRole = "Admin";
            var secretKey = "validSecretKey";
            _configurationMock.Setup(c => c.GetSection("JwtSecretKey").Value).Returns(secretKey);

            // Simulate an exception during token creation
            var tokenHandlerMock = new Mock<JwtSecurityTokenHandler>();
            tokenHandlerMock.Setup(t => t.CreateToken(It.IsAny<SecurityTokenDescriptor>())).Throws<Exception>();

            // Act
            var result = await _tokenQueryService.GenerateToken(userId, userRole);

            // Assert
            Assert.Equal(string.Empty, result);
        }       

        [Theory]
        [InlineData(null, "Admin")]
        [InlineData("testUserId", null)]
        [InlineData("", "Admin")]
        [InlineData("testUserId", "")]
        public async Task GenerateToken_ReturnsEmpty_OnNullOrEmptyInputs(string userId, string userRole)
        {
            // Arrange
            var secretKey = "validSecretKey";
            _configurationMock.Setup(c => c.GetSection("JwtSecretKey").Value).Returns(secretKey);

            // Act
            var result = await _tokenQueryService.GenerateToken(userId, userRole);

            // Assert
            Assert.Equal(string.Empty, result);
        }
        
        [Fact]
        public async Task GenerateToken_ReturnsToken_Success()
        {
            // Arrange
            var userId = "testUserId";
            var userRole = "Admin";
            var secretKey = "validSecretKey";
            _configurationMock.Setup(c => c.GetSection("JwtSecretKey").Value).Returns(secretKey);

            // Act
            var result = await _tokenQueryService.GenerateToken(userId, userRole);

            // Assert
            Assert.Empty(result);
        }
    }
}
