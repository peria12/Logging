﻿using Aurora.AdministrationService.Domain.V1.Entities;
using Aurora.AdministrationService.Domain.V1.Entities.Languade;
using System;
using System.Collections.Generic;
using System.Linq;

namespace Aurora.AdministrationService.Tests.API.Services.V1.Agreement
{
    public class AgreementMockData
    {
        public static IQueryable<Domain.V1.Entities.Agreement> GetAgreementData()
        {
            var agreements = new List<Domain.V1.Entities.Agreement>
            {
                new Domain.V1.Entities.Agreement { ID = 1, UniqueID = "AG1", FrequencyID = 1, Status = true, CreatedBy = "test", CreatedDate = DateTime.UtcNow, UpdatedBy = "test", UpdatedDate = DateTime.UtcNow, IsDeleted = false },
                new Domain.V1.Entities.Agreement { ID = 2, UniqueID = "AG2", FrequencyID = 2, Status = true, CreatedBy = "test", CreatedDate = DateTime.UtcNow, UpdatedBy = "test", UpdatedDate = DateTime.UtcNow, IsDeleted = false }
            };

            return agreements.AsQueryable();
        }

        public static IQueryable<AgreementLanguage> GetAgreementLanguagesData()
        {
            var agreementLanguages = new List<AgreementLanguage>
            {
                new AgreementLanguage { AgreementID = 1, LanguageID = 1, Name = "Agreement 1 Language", Description = "Description 1", IsDeleted = false, Status = true, CreatedBy = "test", CreatedDate = DateTime.UtcNow, UpdatedBy = "test", UpdatedDate = DateTime.UtcNow },
                new AgreementLanguage { AgreementID = 2, LanguageID = 2, Name = "Agreement 2 Language", Description = "Description 2", IsDeleted = false, Status = true, CreatedBy = "test", CreatedDate = DateTime.UtcNow, UpdatedBy = "test", UpdatedDate = DateTime.UtcNow }
            };

            return agreementLanguages.AsQueryable();
        }

        public static IQueryable<LanguageV1> GetLanguagesData()
        {
            var languages = new List<LanguageV1>
            {
                new LanguageV1 { Id = 1, Display = "English", Code = "ENG", Definition = "English",  CreatedBy = "test", RecordVersion = [2,3,4], Source = "source", UpdatedBy = "test" },
                new LanguageV1 { Id = 2, Display = "Spanish", Code = "SPA", Definition = "Spanish",  CreatedBy = "test", RecordVersion = [1,2,3], Source = "source", UpdatedBy = "test" }
            };

            return languages.AsQueryable();
        }
    }
}
