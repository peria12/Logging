﻿using Aurora.AdministrationService.API.Models.Dto.V1.Agreement;
using Aurora.AdministrationService.API.Models.RequestModels.V1.Agreement;
using Aurora.AdministrationService.API.Services.Service.Agreement;
using Aurora.AdministrationService.CrossCutting.CommonModels;
using Aurora.AdministrationService.CrossCutting.Constants;
using Aurora.AdministrationService.Infrastructure;
using Aurora.AdministrationService.Tests.API.CommonMock;
using Microsoft.EntityFrameworkCore;
using Moq;
using Entities = Aurora.AdministrationService.Domain.V1.Entities;

namespace Aurora.AdministrationService.Tests.API.Services.V1.Agreement;

public class AgreementCommandServiceTests : TestsBase<AgreementCommandService>
{
    [Fact]
    public async Task AddAgreementAsync_Should_Save_Entry()
    {
        // Arrange
        using var context = GetReadWriteDBContextInMemory();
        var service = new AgreementCommandService(context, _mockMapper.Object);
        var agreement = DTO.GetAgreementDto();
        var domainAgreement = DTO.GetAgreement();
        var agreementLanguage = DTO.GetAgreementLanguage();

        _mockMapper.Setup(m => m.Map<Entities.Agreement>(It.IsAny<AgreementDto>())).Returns(domainAgreement);
        _mockMapper.Setup(m => m.Map<Entities.AgreementLanguage>(It.IsAny<AgreementDto>())).Returns(agreementLanguage);

        // Act
        var result = await service.AddAgreementAsync(agreement);

        // Assert
        var response = Assert.IsType<GenericResponse<string>>(result);
        Assert.True(response.IsSuccess);
    }

    [Fact]
    public async Task UpdateAgreementAsync_ShouldHandleDifferentScenarios()
    {
        // Arrange
        var request = new UpdateAgreementsRequest { RecordVersion = new byte[] { 1 }, Description = "", FrequencyID = 1, LanguageID = 1, Name = "", UniqueId = "1" };
        var agreement = DTO.GetAgreement();
        var agreementLanguage = DTO.GetAgreementLanguage();

        _mockMapper.Setup(m => m.Map(It.IsAny<UpdateAgreementsRequest>(), It.IsAny<Domain.V1.Entities.Agreement>()));
        _mockMapper.Setup(m => m.Map(It.IsAny<UpdateAgreementsRequest>(), It.IsAny<Domain.V1.Entities.AgreementLanguage>()));
        
        using var context = GetReadWriteDBContextInMemory();
        context.AgreementNew.Add(agreement);
        context.AgreementLanguages.Add(agreementLanguage);
        await context.SaveChangesAsync();
        var service = new AgreementCommandService(context, _mockMapper.Object);
        
        // Act
        var result = await service.UpdateAgreementAsync(request, agreement, agreementLanguage);

        // Assert
        Assert.True(result.IsSuccess);
    }
    
    [Fact]
    public async Task DeleteAgreementAsync_ShouldHandleDifferentScenarios()
    {
        // Arrange
        _ = new UpdateAgreementsRequest { RecordVersion = new byte[] { 1 }, Description = "", FrequencyID = 1, LanguageID = 1, Name = "", UniqueId = "1" };
        var agreement = DTO.GetAgreement();
        var agreementLanguage = DTO.GetAgreementLanguage();

        using var context = GetReadWriteDBContextInMemory();
        context.AgreementNew.Add(agreement);
        context.AgreementLanguages.Add(agreementLanguage);
        await context.SaveChangesAsync();
        var service = new AgreementCommandService(context, _mockMapper.Object);
        
        // Act
        var result = await service.DeleteAgreementAsync(new byte[] { 1 }, agreement, agreementLanguage);

        // Assert
        Assert.True(result.IsSuccess);
    }
    [Fact]
    public async Task AddAgreementAsync_Should_Fail_When_SaveChanges_Returns_Zero()
    {
        // Arrange
        var agreement = DTO.GetAgreementDto();
        var domainAgreement = DTO.GetAgreement();
        var agreementLanguage = DTO.GetAgreementLanguage();

        var options = new DbContextOptionsBuilder<ReadWriteDbContext>()
            .UseInMemoryDatabase(databaseName: "AddAgreement_Should_Fail")
            .Options;

        var context = new FakeFailingDbContext(options); // Use the fake class here

        _mockMapper.Setup(m => m.Map<Entities.Agreement>(It.IsAny<AgreementDto>())).Returns(domainAgreement);
        _mockMapper.Setup(m => m.Map<Entities.AgreementLanguage>(It.IsAny<AgreementDto>())).Returns(agreementLanguage);

        var service = new AgreementCommandService(context, _mockMapper.Object);

        // Act
        var result = await service.AddAgreementAsync(agreement);

        // Assert
        Assert.False(result.IsSuccess);
        Assert.True(result.HasError);
        Assert.Equal(ResponseMessage.STATUS_DATA_ADD_FAIL, result.Message);
        Assert.Equal(ResponseStatusCode.STATUS_BADREQUEST, result.StatusCode);
    }

    public class FakeFailingDbContext : ReadWriteDbContext
    {
        public FakeFailingDbContext(DbContextOptions<ReadWriteDbContext> options) : base(options)
        {
        }

        public override Task<int> SaveChangesAsync(CancellationToken cancellationToken = default)
        {
            return Task.FromResult(0); // Simulate failure
        }
    }
}
