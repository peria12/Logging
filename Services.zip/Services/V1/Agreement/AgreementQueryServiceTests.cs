﻿using Aurora.AdministrationService.API.Enum;
using Aurora.AdministrationService.API.Services.Service.Agreement;
using Aurora.AdministrationService.CrossCutting.CommonModels;
using Aurora.AdministrationService.Infrastructure;
using FluentAssertions;
using Microsoft.EntityFrameworkCore;

namespace Aurora.AdministrationService.Tests.API.Services.V1.Agreement
{
    public class AgreementQueryServiceTests : TestsBase<AgreementQueryService>
    {

        private static AgreementQueryService CreateService(ReadOnlyDbContext dbContext)
        {
            return new AgreementQueryService(dbContext);
        }

        private static void SeedTestData(ReadOnlyDbContext dbContext)
        {
            dbContext.AgreementNew.AddRange(AgreementMockData.GetAgreementData());
            dbContext.AgreementLanguages.AddRange(AgreementMockData.GetAgreementLanguagesData());
            dbContext.LanguageV1.AddRange(AgreementMockData.GetLanguagesData());
            dbContext.SaveChanges();
        }

        [Fact]
        public async Task GetAgreementById_ReturnsNotFound_WhenAgreementDoesNotExist()
        {
            var dbContext = GetReadOnlyDBContextInMemory();
            var agreementQueryService = CreateService(dbContext);

            var result = await agreementQueryService.GetAgreementById(999); // Non-existent agreement ID

            result.IsSuccess.Should().BeFalse();
            result.StatusCode.Should().Be(ResponceStatusCode.RecordNotFound.ToString());
            result.Message.Should().Be(ResponseMessage.STATUS_NODATA);
            result.Result.Should().BeNull();
        }

        [Fact]
        public async Task GetAgreementById_ReturnsAgreement_WhenAgreementExists()
        {
            var dbContext = GetReadOnlyDBContextInMemory();
            SeedTestData(dbContext);

            var agreementQueryService = CreateService(dbContext);

            var result = await agreementQueryService.GetAgreementById(1); // Existing agreement ID

            result.IsSuccess.Should().BeTrue();
            result.StatusCode.Should().Be(ResponseStatus.STATUS_SUCCESS);
            result.Message.Should().Be(ResponseMessage.STATUS_SUCCESS);
            result.Result.Should().NotBeNull();
            result.Result?.Id.Should().Be(1);
            result.Result?.Name.Should().Be("Agreement 1 Language");
        }

        [Fact]
        public async Task GetAgreementLanguageAsync_ReturnsLanguage_WhenLanguageExists()
        {
            var dbContext = GetReadOnlyDBContextInMemory();
            SeedTestData(dbContext);

            var agreementQueryService = CreateService(dbContext);

            var result = await agreementQueryService.GetAgreementLanguageAsync(1); // Agreement ID 1

            result.Should().NotBeNull();
            result?.Name.Should().Be("Agreement 1 Language");
        }


        [Fact]
        public async Task GetAgreements_ReturnsFilteredAgreements_WhenFiltersAreApplied()
        {
            var dbContext = GetReadOnlyDBContextInMemory();
            SeedTestData(dbContext);

            var agreementQueryService = CreateService(dbContext);

            var result = await agreementQueryService.GetAgreements(1, 10, "English", "AG1", "Active");

            result.IsSuccess.Should().BeTrue();
            result.StatusCode.Should().Be(ResponseStatus.STATUS_SUCCESS);
            result.Results.Should().HaveCount(1);
        }

        [Fact]
        public async Task GetAgreements_ReturnsEmpty_WhenLanguageDoesNotExist()
        {
            // Arrange
            var dbContext = GetReadOnlyDBContextInMemory();
            SeedTestData(dbContext);

            var agreementQueryService = CreateService(dbContext);
            var selectedLanguage = "French";

            // Act
            var result = await agreementQueryService.GetAgreements(1, 10, selectedLanguage, null, null);

            // Assert
            result.IsSuccess.Should().BeTrue();
            result.StatusCode.Should().Be(ResponseStatus.STATUS_SUCCESS);
            result.Results.Should().BeEmpty();
        }


        [Fact]
        public async Task GetAgreements_ReturnsAllAgreements_WhenNoFiltersAreApplied()
        {
            var dbContext = GetReadOnlyDBContextInMemory();
            SeedTestData(dbContext);

            var agreementQueryService = CreateService(dbContext);

            var result = await agreementQueryService.GetAgreements(null, null, null, null, null);

            result.IsSuccess.Should().BeTrue();
            result.StatusCode.Should().Be(ResponseStatus.STATUS_SUCCESS);
            result.Results.Should().HaveCountGreaterThan(0);
        }

        [Fact]
        public async Task GetAgreementByIdAsync_ShouldReturnAgreement_WhenExists()
        {
            // Arrange
            var dbContext = GetReadOnlyDBContextInMemory();
            SeedTestData(dbContext);
            var agreementId = 1;
            var agreementService = CreateService(dbContext);

            // Act
            var result = await agreementService.GetAgreementByIdAsync(agreementId);

            // Assert
            Assert.NotNull(result);
            Assert.Equal(agreementId, result?.ID);
        }

        [Fact]
        public async Task GetAgreementByIdAsync_ShouldReturnNull_WhenNotExists()
        {
            // Arrange
            var dbContext = GetReadOnlyDBContextInMemory();
            var agreementId = 999;
            var agreementService = CreateService(dbContext);

            // Act
            var result = await agreementService.GetAgreementByIdAsync(agreementId);

            // Assert
            Assert.Null(result);
        }

        [Fact]
        public async Task GetAgreementLanguageByIdAsync_ShouldReturnLanguage_WhenExists()
        {
            // Arrange
            var dbContext = GetReadOnlyDBContextInMemory();
            SeedTestData(dbContext);
            var languageId = 1;
            var agreementQueryService = CreateService(dbContext);

            // Act
            var result = await agreementQueryService.GetAgreementLanguageByIdAsync(languageId);

            // Assert
            result.Should().NotBeNull();
            Assert.Equal(languageId, result?.LanguageID);
            Assert.Equal("Agreement 1 Language", result?.Name);
        }

        [Fact]
        public async Task GetAgreementLanguageByIdAsync_ShouldReturnNull_WhenNotExists()
        {
            // Arrange
            var dbContext = GetReadOnlyDBContextInMemory();
            var languageId = 999;
            var agreementQueryService = CreateService(dbContext);

            // Act
            var result = await agreementQueryService.GetAgreementLanguageByIdAsync(languageId);

            // Assert
            Assert.Null(result);
        }
        [Fact]
        public async Task IsUniqueIDAlreadyExist_ShouldReturnTrue_WhenUniqueIDExists()
        {
            var dbContext = GetReadOnlyDBContextInMemory();
            SeedTestData(dbContext);
            var service = CreateService(dbContext);

            var result = await service.IsUniqueIDAlreadyExist("AG1");

            result.Should().BeTrue();
        }
        [Fact]
        public async Task IsUniqueIDAlreadyExist_ShouldReturnFalse_WhenUniqueIDDoesNotExist()
        {
            var dbContext = GetReadOnlyDBContextInMemory();
            var service = CreateService(dbContext);

            var result = await service.IsUniqueIDAlreadyExist("NON_EXISTENT");

            result.Should().BeFalse();
        }
        [Fact]
        public async Task IsAgreementNameAlreadyExist_ShouldReturnTrueAndFalse_WhenOnlyLanguageExists()
        {
            var dbContext = GetReadOnlyDBContextInMemory();
            SeedTestData(dbContext);
            var service = CreateService(dbContext);

            var (isLangExist, isNameExist) = await service.IsAgreementNameAlreadyExist("Nonexistent Name", 1);

            isLangExist.Should().BeTrue();
            isNameExist.Should().BeFalse();
        }
        [Fact]
        public async Task IsAgreementNameAlreadyExist_ShouldReturnFalseForBoth_WhenNeitherExists()
        {
            var dbContext = GetReadOnlyDBContextInMemory();
            var service = CreateService(dbContext);

            var (isLangExist, isNameExist) = await service.IsAgreementNameAlreadyExist("Random", 999);

            isLangExist.Should().BeFalse();
            isNameExist.Should().BeFalse();
        }
        private AgreementQueryService SetupServiceWithSeededData(out ReadOnlyDbContext dbContext)
        {
            dbContext = GetReadOnlyDBContextInMemory();
            SeedTestData(dbContext);
            return CreateService(dbContext);
        }
        [Fact]
        public async Task GetAgreementById_ReturnsAgreement_WhenAgreementExist()
        {
            var agreementQueryService = SetupServiceWithSeededData(out _);

            var result = await agreementQueryService.GetAgreementById(1);

            result.IsSuccess.Should().BeTrue();
            result.Result?.Id.Should().Be(1);
        }
        [Fact]
        public async Task GetAgreements_ShouldReturnOnlyInactive_WhenSelectedStatusIsInActive()
        {
            // Arrange
            var options = new DbContextOptionsBuilder<ReadOnlyDbContext>()
                .UseInMemoryDatabase(databaseName: Guid.NewGuid().ToString())
                .Options;

            using var context = new ReadOnlyDbContext(options);

            // Seed inactive and active data
            context.AgreementNew.AddRange(
                new Domain.V1.Entities.Agreement { ID = 1, UniqueID = "A001", Status = false, IsDeleted = false, UpdatedDate = DateTime.UtcNow,CreatedBy="admin",CreatedDate=DateTime.UtcNow,UpdatedBy="admin" },
                new Domain.V1.Entities.Agreement { ID = 2, UniqueID = "A002", Status = true, IsDeleted = false, UpdatedDate = DateTime.UtcNow,CreatedBy = "admin", CreatedDate = DateTime.UtcNow, UpdatedBy = "admin" }
            );
            context.AgreementLanguages.Add(
                new Domain.V1.Entities.AgreementLanguage { Id = 1, AgreementID = 1, Name = "Inactive Agreement", IsDeleted = false, CreatedBy = "admin", CreatedDate = DateTime.UtcNow, UpdatedBy = "admin",Status=false,UpdatedDate=DateTime.UtcNow }
            );
            await context.SaveChangesAsync();

            var service = new AgreementQueryService(context);

            // Act
            var result = await service.GetAgreements(null, null, null, null, "InActive");

            // Assert
            Assert.True(result.IsSuccess);
            Assert.Single(result.Results); // Only one should be returned
            Assert.Equal("A001", result.Results.First().UniqueId);
        }


    }
}