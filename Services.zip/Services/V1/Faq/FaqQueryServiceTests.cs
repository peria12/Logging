﻿using Aurora.AdministrationService.API.Enum;
using Aurora.AdministrationService.API.Services.IService.Faq;
using Aurora.AdministrationService.API.Services.Service.Faq;
using Aurora.AdministrationService.API.Services.Service.WhatsHappenings;
using Aurora.AdministrationService.CrossCutting.CommonModels;
using Aurora.AdministrationService.Domain.V1.Entities;
using Aurora.AdministrationService.Infrastructure;
using FluentAssertions;
using Microsoft.EntityFrameworkCore;
using Moq;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Aurora.AdministrationService.Tests.API.Services.V1.Faq
{
    public class FaqQueryServiceTests
    {
        private readonly DbContextOptions<ReadOnlyDbContext> _readOnlyDbContext;
        private readonly FaqQuerySerivce _faqQueryService;

        public FaqQueryServiceTests()
        {
            _readOnlyDbContext = new DbContextOptionsBuilder<ReadOnlyDbContext>()
                 .UseInMemoryDatabase(databaseName: Guid.NewGuid().ToString())
                 .Options;
            var context = new ReadOnlyDbContext(_readOnlyDbContext);
            _faqQueryService = new FaqQuerySerivce(context);
        }

        [Fact]
        public async Task GetFaqByIdAsync_ShouldReturnFaq_WhenIdExists()
        {
            // Arrange
            using (var context = new ReadOnlyDbContext(_readOnlyDbContext))
            {
                var faq = new Aurora.AdministrationService.Domain.V1.Entities.FAQ { ID = 1, UniqueID = "FAQ-123", IsDeleted = false, Status = true, Platforms = "Test", CreatedDate = DateTime.UtcNow };
                context.FAQNew.Add(faq);
                await context.SaveChangesAsync();

                var service = new FaqQuerySerivce(context);

                // Act
                var result = await service.GetFaqByIdAsync(1);

                // Assert
                result.Should().NotBeNull();
                result?.ID.Should().Be(1);
                result?.UniqueID.Should().Be("FAQ-123");
            }
        }

        [Fact]
        public async Task GetFaqLanguageAsync_ShouldReturnFaqLanguage_WhenFaqIdExists()
        {
            // Arrange
            using (var context = new ReadOnlyDbContext(_readOnlyDbContext))
            {
                var faqLanguage = new FAQLanguage
                {
                    Id = 1,
                    FAQID = 100,
                    Header = "Sample FAQ",
                    Description = "This is a sample FAQ description.",
                    Status = true,
                    IsDeleted = false,
                    CreatedDate = DateTime.Now
                };
                context.FAQLanguages.Add(faqLanguage);
                await context.SaveChangesAsync();

                var service = new FaqQuerySerivce(context);

                // Act
                var result = await service.GetFaqLanguageAsync(100);

                // Assert
                result.Should().NotBeNull();
                result?.Id.Should().Be(1);
                result?.FAQID.Should().Be(100);
                result?.Header.Should().Be("Sample FAQ");
                result?.Description.Should().Be("This is a sample FAQ description.");
            }
        }
        [Fact]
        public async Task GetFaqUserTypesAsync_ShouldReturnFaqUserTypes_WhenFaqIdExists()
        {
            // Arrange
            using (var context = new ReadOnlyDbContext(_readOnlyDbContext))
            {
                var faqUserType = new FAQUserTypes
                {
                    Id = 1,
                    FAQID = 200,
                    UserType = "Admin",
                    IsDeleted = false,
                    CreatedDate = DateTime.Now
                };
                context.FAQUserTypes.Add(faqUserType);
                await context.SaveChangesAsync();

                var service = new FaqQuerySerivce(context);

                // Act
                var result = await service.GetFaqUserTypesAsync(200);

                // Assert
                result.Should().NotBeNull();
                result?.Id.Should().Be(1);
                result?.FAQID.Should().Be(200);
                result?.UserType.Should().Be("Admin");
            }
        }
        [Fact]
        public async Task GetFaqLanguageByIdAsync_ShouldReturnFaqLanguage_WhenLanguageIdExists()
        {
            // Arrange
            using (var context = new ReadOnlyDbContext(_readOnlyDbContext))
            {
                var faqLanguage = new FAQLanguage
                {
                    Id = 10,
                    FAQID = 300,
                    Header = "General Information",
                    Description = "FAQ details about general information.",
                    IsDeleted = false,
                    CreatedDate = DateTime.Now,
                    Status = true
                };
                context.FAQLanguages.Add(faqLanguage);
                await context.SaveChangesAsync();

                var service = new FaqQuerySerivce(context);

                // Act
                var result = await service.GetFaqLanguageByIdAsync(10);

                // Assert
                result.Should().NotBeNull();
                result?.Id.Should().Be(10);
                result?.FAQID.Should().Be(300);
                result?.Header.Should().Be("General Information");
                result?.Description.Should().Be("FAQ details about general information.");
            }
        }

        [Fact]
        public async Task GetFaqDetailById_ShouldReturnFaqDetails_WhenFaqExists()
        {
            // Arrange
            using (var context = new ReadOnlyDbContext(_readOnlyDbContext))
            {
                var faq = new Aurora.AdministrationService.Domain.V1.Entities.FAQ
                {
                    ID = 1,
                    UniqueID = "FAQ-001",
                    Platforms = "Web",
                    Status = true,
                    IsDeleted = false,
                    CreatedDate = DateTime.UtcNow
                };

                var faqLanguage = new FAQLanguage
                {
                    Id = 100,
                    FAQID = 1,
                    Header = "General Inquiry",
                    Description = "This is a test FAQ.",
                    Status = true,
                    IsDeleted = false,
                    CreatedDate = DateTime.UtcNow
                };

                var faqUserType = new FAQUserTypes
                {
                    Id = 200,
                    FAQID = 1,
                    UserType = "Admin",
                    IsDeleted = false,
                    CreatedDate = DateTime.UtcNow
                };

                context.FAQNew.Add(faq);
                context.FAQLanguages.Add(faqLanguage);
                context.FAQUserTypes.Add(faqUserType);
                await context.SaveChangesAsync();

                var service = new FaqQuerySerivce(context);

                // Act
                var response = await service.GetFaqDetailById(1);

                // Assert
                response.Should().NotBeNull();
                response.IsSuccess.Should().BeTrue();
                response.HasError.Should().BeFalse();
                response.StatusCode.Should().Be(ResponseStatus.STATUS_SUCCESS);
                response.Result.Should().NotBeNull();
                response.Result?.Id.Should().Be(1);
                response.Result?.Header.Should().Be("General Inquiry");
                response.Result?.Description.Should().Be("This is a test FAQ.");
                response.Result?.UserType.Should().Be("Admin");
                response.Result?.Platforms.Should().Be("Web");
                response.Result?.UniqueID.Should().Be("FAQ-001");
                response.Result?.Status.Should().BeTrue();
            }
        }

        [Fact]
        public async Task GetFaqDetailById_ShouldReturnNotFound_WhenFaqDoesNotExist()
        {
            // Arrange
            using (var context = new ReadOnlyDbContext(_readOnlyDbContext))
            {
                var service = new FaqQuerySerivce(context);

                // Act
                var response = await service.GetFaqDetailById(999); // ID that does not exist

                // Assert
                response.Should().NotBeNull();
                response.IsSuccess.Should().BeFalse();
                response.HasError.Should().BeTrue();
                response.Result.Should().BeNull();
                response.StatusCode.Should().Be(ResponceStatusCode.RecordNotFound.ToString());
                response.Message.Should().Be(ResponseMessage.STATUS_NODATA);
            }
        }

        [Fact]
        public async Task GetFaqs_ShouldReturnFaqs_WithPagination()
        {
            // Arrange
            using (var context = new ReadOnlyDbContext(_readOnlyDbContext))
            {
                context.FAQNew.Add(new Aurora.AdministrationService.Domain.V1.Entities.FAQ { ID = 1, Platforms = "Web", UniqueID = "FAQ-001", Status = true, IsDeleted = false, CreatedDate = DateTime.Now });
                context.FAQNew.Add(new Aurora.AdministrationService.Domain.V1.Entities.FAQ { ID = 2, Platforms = "Mobile", UniqueID = "FAQ-002", Status = true, IsDeleted = false, CreatedDate = DateTime.Now });

                context.FAQLanguages.Add(new FAQLanguage { Id = 101, FAQID = 1, Header = "General Inquiry", Description = "FAQ 1 Description", LanguageID = 1, Status = true, IsDeleted = false, CreatedDate = DateTime.Now });
                context.FAQLanguages.Add(new FAQLanguage { Id = 102, FAQID = 2, Header = "Technical Issue", Description = "FAQ 2 Description", LanguageID = 2, Status = true, IsDeleted = false, CreatedDate = DateTime.Now });

                context.FAQUserTypes.Add(new FAQUserTypes { Id = 201, FAQID = 1, UserType = "Admin", IsDeleted = false, CreatedDate = DateTime.Now });
                context.FAQUserTypes.Add(new FAQUserTypes { Id = 202, FAQID = 2, UserType = "User", IsDeleted = false, CreatedDate = DateTime.Now });

                await context.SaveChangesAsync();
                var service = new FaqQuerySerivce(context);

                // Act
                var response = await service.GetFaqs(1, 1, null, null, null, null);

                // Assert
                response.Should().NotBeNull();
                response.IsSuccess.Should().BeTrue();
                response.HasError.Should().BeFalse();
                response.StatusCode.Should().Be(ResponseStatus.STATUS_SUCCESS);
                response.Results.Should().NotBeNull();
                response.TotalCount.Should().Be(2);
                response.CurrentPage.Should().Be(1);
                response.PageSize.Should().Be(1);
            }
        }
        [Fact]
        public async Task GetFaqs_ShouldReturnFilteredFaqs_ByPlatform()
        {
            // Arrange
            using (var context = new ReadOnlyDbContext(_readOnlyDbContext))
            {
                context.FAQNew.Add(new Aurora.AdministrationService.Domain.V1.Entities.FAQ { ID = 1, Platforms = "Web", UniqueID = "FAQ-001", Status = true, IsDeleted = false, CreatedDate = DateTime.Now });
                context.FAQNew.Add(new Aurora.AdministrationService.Domain.V1.Entities.FAQ { ID = 2, Platforms = "Mobile", UniqueID = "FAQ-002", Status = true, IsDeleted = false, CreatedDate = DateTime.Now });

                context.FAQLanguages.Add(new FAQLanguage { Id = 101, FAQID = 1, Header = "General Inquiry", Description = "FAQ 1 Description", LanguageID = 1, Status = true, IsDeleted = false, CreatedDate = DateTime.Now });
                context.FAQLanguages.Add(new FAQLanguage { Id = 102, FAQID = 2, Header = "Technical Issue", Description = "FAQ 2 Description", LanguageID = 2, Status = true, IsDeleted = false, CreatedDate = DateTime.Now });


                await context.SaveChangesAsync();
                var service = new FaqQuerySerivce(context);

                // Act
                var response = await service.GetFaqs(null, null, "Web", null, null, null);

                // Assert
                response.Should().NotBeNull();
                response.IsSuccess.Should().BeTrue();
                response.HasError.Should().BeFalse();
                response.Results.Should().NotBeNull();
            }
        }
        [Fact]
        public async Task GetFaqs_ShouldReturnFaqs_ByStatus()
        {
            // Arrange
            using (var context = new ReadOnlyDbContext(_readOnlyDbContext))
            {
                context.FAQNew.Add(new Aurora.AdministrationService.Domain.V1.Entities.FAQ { ID = 1, Platforms = "Web", UniqueID = "FAQ-001", Status = true, IsDeleted = false, CreatedDate = DateTime.Now });
                context.FAQNew.Add(new Aurora.AdministrationService.Domain.V1.Entities.FAQ { ID = 2, Platforms = "Mobile", UniqueID = "FAQ-002", Status = true, IsDeleted = false, CreatedDate = DateTime.Now });

                await context.SaveChangesAsync();
                var service = new FaqQuerySerivce(context);

                // Act
                var response = await service.GetFaqs(null, null, null, null, null, "Active");

                // Assert
                response.Should().NotBeNull();
                response.IsSuccess.Should().BeTrue();
                response.HasError.Should().BeFalse();
                response.Results.Should().NotBeNull();
            }
        }
        [Fact]
        public async Task GetFaqs_ShouldReturnNotFound_WhenNoFaqsExist()
        {
            // Arrange
            using (var context = new ReadOnlyDbContext(_readOnlyDbContext))
            {
                var service = new FaqQuerySerivce(context);

                // Act
                var response = await service.GetFaqs(null, null, null, null, null, null);

                // Assert
                response.Should().NotBeNull();
                response.IsSuccess.Should().BeFalse();
                response.HasError.Should().BeTrue();
                response.StatusCode.Should().Be(ResponceStatusCode.RecordNotFound.ToString());
                response.Results.Should().BeNull();
                response.Message.Should().Be(ResponseMessage.STATUS_NODATA);
            }
        }

        [Fact]
        public async Task GetFaqs_ShouldReturnNotFound_WhenFilterDoesNotMatch()
        {
            // Arrange
            using (var context = new ReadOnlyDbContext(_readOnlyDbContext))
            {
                context.FAQNew.Add(new Aurora.AdministrationService.Domain.V1.Entities.FAQ { ID = 1, Platforms = "Web", UniqueID = "FAQ-001", Status = true, IsDeleted = false, CreatedDate = DateTime.Now });

                context.FAQLanguages.Add(new FAQLanguage { Id = 101, FAQID = 1, Header = "General Inquiry", Description = "FAQ 1 Description", LanguageID = 1, Status = true, IsDeleted = false, CreatedDate = DateTime.Now });

                await context.SaveChangesAsync();
                var service = new FaqQuerySerivce(context);

                // Act
                var response = await service.GetFaqs(null, null, "NonExistentPlatform", null, null, null);

                // Assert
                response.Should().NotBeNull();
                response.IsSuccess.Should().BeFalse();
                response.HasError.Should().BeTrue();
                response.StatusCode.Should().Be(ResponceStatusCode.RecordNotFound.ToString());
                response.Results.Should().BeNull();
                response.Message.Should().Be(ResponseMessage.STATUS_NODATA);
            }
        }

    }
}
