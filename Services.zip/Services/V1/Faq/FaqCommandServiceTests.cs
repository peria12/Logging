﻿using Aurora.AdministrationService.API.Models.Dto.V1.FAQ;
using Aurora.AdministrationService.API.Models.RequestModels.V1.Faq;
using Aurora.AdministrationService.API.Services.Service.Faq;
using Aurora.AdministrationService.CrossCutting.CommonModels;
using Aurora.AdministrationService.CrossCutting.Constants;
using Aurora.AdministrationService.Domain.V1.Entities;
using Aurora.AdministrationService.Infrastructure;
using Aurora.AdministrationService.Tests.API.CommonMock;
using FluentAssertions;
using Microsoft.EntityFrameworkCore;
using Moq;
using Entities = Aurora.AdministrationService.Domain.V1.Entities;

namespace Aurora.AdministrationService.Tests.API.Services.V1.Faq
{
    public class FaqCommandServiceTests : TestsBase<FaqCommandService>
    {
        private FaqCommandService CreateService(ReadWriteDbContext dbContext)
        {
            return new FaqCommandService(dbContext, _mockMapper.Object);
        }

        [Fact]
        public async Task AddFaqAsync_ShouldReturnSuccess_WhenFaqIsAdded()
        {
            // Arrange
            var dbContext = GetReadWriteDBContextInMemory();
            var faqCommandService = CreateService(dbContext);
            var request = DTO.GetFaqDto();
            var domainFaq = DTO.GetFaq();
            var faqLanguage = DTO.GetFaqLanguage();
            var faqUserType = DTO.GetFaqUserTypes();

            _mockMapper.Setup(m => m.Map<Entities.FAQ>(It.IsAny<FaqDto>())).Returns(domainFaq);
            _mockMapper.Setup(m => m.Map<FAQLanguage>(It.IsAny<FaqDto>())).Returns(faqLanguage);
            _mockMapper.Setup(m => m.Map<FAQUserTypes>(It.IsAny<FaqDto>())).Returns(faqUserType);

            // Act
            var result = await faqCommandService.AddFaqAsync(request);

            // Assert
            result.IsSuccess.Should().BeTrue();
            result.Message.Should().Be(ResponseMessage.STATUS_DATA_ADDED);
            result.StatusCode.Should().Be(ResponseStatusCode.STATUS_SUCCESS);
        }

        [Fact]
        public async Task AddFaqAsync_ShouldReturnError_WhenSaveFails()
        {
            // Arrange
            var dbContext = GetReadWriteDBContextInMemory(); // Uses in-memory DB that you already have
            var faqCommandService = CreateService(dbContext);

            var request = DTO.GetFaqDto();
            var domainFaq = DTO.GetFaq();
            var faqLanguage = DTO.GetFaqLanguage();
            var faqUserType = DTO.GetFaqUserTypes();

            _mockMapper.Setup(m => m.Map<Entities.FAQ>(It.IsAny<FaqDto>())).Returns(domainFaq);
            _mockMapper.Setup(m => m.Map<FAQLanguage>(It.IsAny<FaqDto>())).Returns(faqLanguage);
            _mockMapper.Setup(m => m.Map<FAQUserTypes>(It.IsAny<FaqDto>())).Returns(faqUserType);

            // Simulate SaveChangesAsync returns 0 on first call (FAQ save fails)
            var dbContextMock = new Mock<ReadWriteDbContext>(new DbContextOptionsBuilder<ReadWriteDbContext>()
                .UseInMemoryDatabase(databaseName: Guid.NewGuid().ToString())
                .Options);

            dbContextMock.Setup(db => db.FAQNew.Add(It.IsAny<Entities.FAQ>()));
            dbContextMock.Setup(db => db.SaveChangesAsync(default)).ReturnsAsync(0);

            var service = new FaqCommandService(dbContextMock.Object, _mockMapper.Object);

            // Act
            var result = await service.AddFaqAsync(request);

            // Assert
            result.Should().NotBeNull();
            result.IsSuccess.Should().BeFalse();
            result.HasError.Should().BeTrue();
            result.Message.Should().Be(ResponseMessage.STATUS_DATA_ADD_FAIL);
            result.StatusCode.Should().Be(ResponseStatusCode.STATUS_BADREQUEST);
        }



        [Fact]
        public async Task UpdateFaqAsync_ShouldHandleDifferentScenarios()
        {
            // Arrange
            var request = DTO.GetUpdateFaqsRequest();
            var faq = DTO.GetFaq();
            var faqLanguage = DTO.GetFaqLanguage();
            var faqUserType = DTO.GetFaqUserTypes();

            // Setup Mock Mapper if needed
            _mockMapper.Setup(m => m.Map(It.IsAny<UpdateFaqRequest>(), It.IsAny<Entities.FAQ>()));
            _mockMapper.Setup(m => m.Map(It.IsAny<UpdateFaqRequest>(), It.IsAny<FAQLanguage>()));
            _mockMapper.Setup(m => m.Map(It.IsAny<UpdateFaqRequest>(), It.IsAny<FAQUserTypes>()));

            using var context = GetReadWriteDBContextInMemory();
            context.FAQNew.Add(faq);
            context.FAQLanguages.Add(faqLanguage);
            context.FAQUserTypes.Add(faqUserType);
            await context.SaveChangesAsync();

            var service = new FaqCommandService(context, _mockMapper.Object);

            // Act
            var result = await service.UpdateFaqAsync(request, faq, faqLanguage, faqUserType);

            // Assert
            Assert.True(result.IsSuccess);
        }

        [Fact]
        public async Task DeleteFaqAsync_ShouldHandleDifferentScenarios()
        {
            // Arrange
            var faq = DTO.GetFaq();
            var faqLanguage = DTO.GetFaqLanguage();
            var faqUserType = DTO.GetFaqUserTypes();

            using var context = GetReadWriteDBContextInMemory();
            context.FAQNew.Add(faq);
            context.FAQLanguages.Add(faqLanguage);
            context.FAQUserTypes.Add(faqUserType);
            await context.SaveChangesAsync();

            var service = new FaqCommandService(context, _mockMapper.Object);

            // Act
            var result = await service.DeleteFaqAsync(faq, faqLanguage, faqUserType);

            // Assert
            Assert.True(result.IsSuccess);
            var deletedFaq = context.FAQNew.First(f => f.ID == faq.ID);
            deletedFaq.IsDeleted.Should().BeTrue();  // Ensure the FAQ is marked as deleted
        }


    }
}
