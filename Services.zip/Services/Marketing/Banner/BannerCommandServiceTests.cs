﻿using Aurora.AdministrationService.API.Models.Dto.Marketing.Banner;
using Aurora.AdministrationService.API.Resources;
using Aurora.AdministrationService.API.Services.Service.Marketing.Banner;
using Aurora.AdministrationService.CrossCutting.CommonModels;
using Aurora.AdministrationService.Infrastructure;
using AutoMapper;
using Microsoft.EntityFrameworkCore;
using Moq;

namespace Aurora.AdministrationService.Tests.API.Services.Marketing.Banner
{
    public class BannerCommandServiceTests
    {
        private readonly Mock<IMapper> _mockMapper;
        private readonly ReadWriteDbContext _dbReadWriteContext;
        private readonly BannerCommandService _bannerService;

        public BannerCommandServiceTests()
        {
            DbContextOptions<ReadWriteDbContext> options = new DbContextOptionsBuilder<ReadWriteDbContext>()
                .UseInMemoryDatabase(databaseName: "TestLocationDatabase")
                .Options;

            _dbReadWriteContext = new ReadWriteDbContext(options);

            _mockMapper = new Mock<IMapper>();

            _bannerService = new BannerCommandService(_dbReadWriteContext, _mockMapper.Object);
        }

        [Fact]
        public async Task CreateBanner_ShouldReturnSuccess_WhenValidRequest()
        {
            // Arrange
            var newBannerRequest = new BannerDto
            {
                Title = "Title",
                URL = "URL",
                ImageUrl = "ImageUrl",
                Status = true,
                StartDate = DateTime.UtcNow,
                EndDate = DateTime.Now,
            };

            // Setup mock mapping to return a banner
            _mockMapper.Setup(m => m.Map<Domain.V1.Entities.Banner>(It.IsAny<BannerDto>()))
                       .Returns(new Domain.V1.Entities.Banner
                       {
                           ID = 1,
                           Title = "Title",
                           URL = "URL",
                           ImageUrl = "ImageUrl",
                           Status = false,
                           StartDate = DateTime.Now,
                           EndDate = DateTime.Now,
                           IsDeleted = false,
                           CreatedBy = "testUser",
                           CreatedDate = DateTime.Now,
                           UpdatedBy = "testUser",
                           UpdatedDate = DateTime.Now,
                       });

            // Act
            var result = await _bannerService.CreateBanner(newBannerRequest);

            // Assert
            Assert.True(result.IsSuccess);
            Assert.Equal(ResponseStatus.STATUS_SUCCESS_Create, result.StatusCode);
            Assert.Equal(Resource.RecordInsertionMessage, result.Message);
        }

        // Test for error during banner creation
        [Fact]
        public async Task CreateBanner_ShouldReturnError_WhenExceptionOccurs()
        {
            // Arrange
            var newBannerRequest = new BannerDto
            {
                Title = "Title",
                URL = "URL",
                ImageUrl = "ImageUrl",
                Status = true,
                StartDate = DateTime.Now,
                EndDate = DateTime.Now,
            };

            _mockMapper.Setup(m => m.Map<Domain.V1.Entities.Banner>(It.IsAny<BannerDto>()))
                       .Throws(new Exception("Simulated error"));

            // Act
            var result = await _bannerService.CreateBanner(newBannerRequest);

            // Assert
            Assert.False(result.IsSuccess);
            Assert.Equal(ResponseStatus.STATUS_InternalServerError, result.StatusCode);
            Assert.Equal(Resource.LogMessage, result.Message);
        }

        [Fact]
        public async Task UpdateBanner_ShouldReturnSuccess_WhenValidRequestAndValidRecordVersion()
        {
            // Arrange
            var banner = new Domain.V1.Entities.Banner
            {
                ID = 12,
                Title = "Old Title",
                URL = "https://oldurl.com",
                ImageUrl = "oldimage.jpg",
                Status = false,
                StartDate = DateTime.Now,
                EndDate = DateTime.Now.AddDays(1),
                IsDeleted = false,
                CreatedBy = "testUser",
                CreatedDate = DateTime.Now,
                UpdatedBy = "testUser",
                UpdatedDate = DateTime.Now,
                RecordVersion = [1, 2, 3, 4] 
            };
            _dbReadWriteContext.Banners.Add(banner);
            await _dbReadWriteContext.SaveChangesAsync();

            var updateRequest = new UpdateBannerRequest
            {
                Title = "Updated Title",
                URL = "https://updatedurl.com",
                ImageUrl = "updatedimage.jpg",
                Status = true,
                StartDate = DateTime.Now.AddDays(2),
                EndDate = DateTime.Now.AddDays(3),
                RecordVersion = banner.RecordVersion
            };

            // Act
            var result = await _bannerService.UpdateBanner(updateRequest, banner);

            // Assert
            Assert.True(result.IsSuccess);
            Assert.Equal(Resource.RecordUpdationMessage, result.Message);
        }

        [Fact]
        public async Task UpdateBanner_ShouldReturnError_WhenExceptionOccurs()
        {
            // Arrange
            var banner = new Domain.V1.Entities.Banner
            {
                ID = 16,
                Title = "Old Title",
                URL = "https://oldurl.com",
                ImageUrl = "oldimage.jpg",
                Status = false,
                StartDate = DateTime.Now,
                EndDate = DateTime.Now.AddDays(1),
                IsDeleted = false,
                CreatedBy = "testUser",
                CreatedDate = DateTime.Now,
                UpdatedBy = "testUser",
                UpdatedDate = DateTime.Now,
                RecordVersion = new byte[] { 1, 2, 3, 4 }
            };

            _dbReadWriteContext.Banners.Add(banner);
            await _dbReadWriteContext.SaveChangesAsync();

            var updateRequest = new UpdateBannerRequest
            {
                Title = "Updated Title",
                URL = "https://updatedurl.com",
                ImageUrl = "updatedimage.jpg",
                Status = true,
                StartDate = DateTime.Now.AddDays(2),
                EndDate = DateTime.Now.AddDays(3),
                RecordVersion = banner.RecordVersion
            };

            // Simulate an exception during the update process
            _mockMapper.Setup(m => m.Map(It.IsAny<UpdateBannerRequest>(), It.IsAny<Domain.V1.Entities.Banner>()))
                       .Throws(new Exception("Simulated error"));

            // Act
            var result = await _bannerService.UpdateBanner(updateRequest, banner);

            // Assert
            Assert.False(result.IsSuccess);
            Assert.Equal(ResponseStatus.STATUS_InternalServerError, result.StatusCode);
            Assert.Equal(Resource.RecordUpdationFailureMessage, result.Message);
        }

        [Fact]
        public async Task UpdateBanner_ShouldThrowDbUpdateConcurrencyException_WhenConcurrencyConflictOccurs()
        {
            // Arrange
            var banner = new Domain.V1.Entities.Banner
            {
                ID = 11,
                Title = "Old Title",
                URL = "https://oldurl.com",
                ImageUrl = "oldimage.jpg",
                Status = false,
                StartDate = DateTime.Now,
                EndDate = DateTime.Now.AddDays(1),
                IsDeleted = false,
                CreatedBy = "testUser",
                CreatedDate = DateTime.Now,
                UpdatedBy = "testUser",
                UpdatedDate = DateTime.Now,
                RecordVersion = new byte[] { 1, 2, 3, 4 }
            };

            _dbReadWriteContext.Banners.Add(banner);
            await _dbReadWriteContext.SaveChangesAsync();

            var updateRequest = new UpdateBannerRequest
            {
                Title = "Updated Title",
                URL = "https://updatedurl.com",
                ImageUrl = "updatedimage.jpg",
                Status = true,
                StartDate = DateTime.Now.AddDays(2),
                EndDate = DateTime.Now.AddDays(3),
                RecordVersion = new byte[] { 5, 6, 7, 8 } // Simulate a concurrency conflict
            };

            // Act & Assert
            await Assert.ThrowsAsync<DbUpdateConcurrencyException>(() => _bannerService.UpdateBanner(updateRequest, banner));
        }

        //Delete banner
        [Fact]
        public async Task DeleteBanner_ShouldReturnSuccess_WhenValidRequestAndRecordVersionMatches()
        {
            // Arrange
            var banner = new Domain.V1.Entities.Banner
            {
                ID = 13,
                Title = "Banner to Delete",
                URL = "https://deleteurl.com",
                ImageUrl = "deleteimage.jpg",
                Status = true,
                StartDate = DateTime.Now,
                EndDate = DateTime.Now.AddDays(1),
                IsDeleted = false,
                CreatedBy = "testUser",
                CreatedDate = DateTime.Now,
                UpdatedBy = "testUser",
                UpdatedDate = DateTime.Now,
                RecordVersion = new byte[] { 1, 2, 3, 4 }
            };

            _dbReadWriteContext.Banners.Add(banner);
            await _dbReadWriteContext.SaveChangesAsync();

            var recordVersion = banner.RecordVersion;

            // Act
            var result = await _bannerService.DeleteBanner(recordVersion, banner);

            // Assert
            Assert.True(result.IsSuccess);
            var deletedBanner = await _dbReadWriteContext.Banners.FindAsync(banner.ID);
            Assert.NotNull(deletedBanner);
            Assert.True(deletedBanner.IsDeleted);
        }

        [Fact]
        public async Task DeleteBanner_ShouldReturnError_WhenRecordVersionDoesNotMatch()
        {
            // Arrange
            var banner = new Domain.V1.Entities.Banner
            {
                ID = 20,
                Title = "Banner to Delete",
                URL = "https://deleteurl.com",
                ImageUrl = "deleteimage.jpg",
                Status = true,
                StartDate = DateTime.Now,
                EndDate = DateTime.Now.AddDays(1),
                IsDeleted = false,
                CreatedBy = "testUser",
                CreatedDate = DateTime.Now,
                UpdatedBy = "testUser",
                UpdatedDate = DateTime.Now,
                RecordVersion = new byte[] { 1, 2, 3, 4 }
            };

            _dbReadWriteContext.Banners.Add(banner);
            await _dbReadWriteContext.SaveChangesAsync();

            var incorrectRecordVersion = new byte[] { 5, 6, 7, 8 };

            // Act
            var result = await _bannerService.DeleteBanner(incorrectRecordVersion, banner);

            // Assert
            Assert.False(result.IsSuccess);
            Assert.Equal(ResponseStatus.STATUS_InternalServerError, result.StatusCode);
            Assert.Equal(Resource.RecordDeletionFailureMessage, result.Message);
        }
    }
}
