﻿using Aurora.AdministrationService.API.Enum;
using Aurora.AdministrationService.API.Models.Dto.Marketing.Banner;
using Aurora.AdministrationService.API.Services.Service.Marketing.Banner;
using Aurora.AdministrationService.CrossCutting.CommonModels;
using Aurora.AdministrationService.Infrastructure;
using FluentAssertions;
using Microsoft.EntityFrameworkCore;
using Moq;

namespace Aurora.AdministrationService.Tests.API.Services.Marketing.Banner
{
    /// <summary>
    /// Added test cases for banner service which contains test cases e.i. record exist, not exist and exception
    /// </summary>
    public class BannerQueryServiceTests
    {
        private readonly BannerQueryService _bannerQueryService;
        private readonly DbContextOptions<ReadOnlyDbContext> _options;
        private readonly ReadOnlyDbContext _context;

        public BannerQueryServiceTests()
        {
            // Use a unique database name for each test to avoid shared state
            _options = new DbContextOptionsBuilder<ReadOnlyDbContext>()
                .UseInMemoryDatabase(databaseName: Guid.NewGuid().ToString()) // Unique name
                .Options;

            // Create a context that uses the InMemoryDatabase
            _context = new ReadOnlyDbContext(_options);

            // Create the service instance
            _bannerQueryService = new BannerQueryService(_context);
            SeedData(_context);
        }

        private static void SeedData(ReadOnlyDbContext context)
        {
            var banners = Enumerable.Range(1, 10).Select(i => new Domain.V1.Entities.Banner
            {
                ID = i,
                Title = $"Banner {i}",
                Status = true,
                IsDeleted = false,
                StartDate = DateTime.UtcNow.AddDays(-i),
                EndDate = DateTime.UtcNow.AddDays(10),
                URL = $"https://example.com/banner{i}",
                ImageUrl = $"https://images.com/banner{i}.jpg",
                CreatedBy = "UnitTest",
                CreatedDate = DateTime.UtcNow,
                UpdatedDate = DateTime.UtcNow
            });

            context.Banners.AddRange(banners);
            context.SaveChanges();
        }

        [Fact]
        public async Task GetMarketingMainBanners_ShouldReturnSuccess_WhenBannersExist()
        {
            // Arrange
            using (var context = new ReadOnlyDbContext(_options))
            {
                context.Banners.AddRange(
                   new Domain.V1.Entities.Banner { ID = 151, URL = "https://example.com", ImageUrl = "image151.jpg", Title = "Banner 151", Status = true, CreatedBy = "Admin", UpdatedBy = "Admin", IsDeleted = false, CreatedDate = DateTime.UtcNow, UpdatedDate = DateTime.UtcNow },
                   new Domain.V1.Entities.Banner { ID = 152, URL = "https://example2.com", ImageUrl = "image152.jpg", Title = "Banner 152", Status = false, CreatedBy = "Admin", UpdatedBy = "Admin", IsDeleted = false, CreatedDate = DateTime.UtcNow, UpdatedDate = DateTime.UtcNow }

                );
                await context.SaveChangesAsync();
            }

            // Act
            var response = await _bannerQueryService.GetMarketingMainBanners();

            // Assert
            response.HasError.Should().BeFalse();
            response.IsSuccess.Should().BeTrue();
        }

        [Fact]
        public async Task GetMarketingMainBanners_ShouldReturnEmpty_WhenNoDataIsPresent()
        {
            // Arrange: Create a new empty in-memory database for this test case
            // Use a unique database name for each test to avoid shared state
            var options = new DbContextOptionsBuilder<ReadOnlyDbContext>()
                .UseInMemoryDatabase(databaseName: Guid.NewGuid().ToString()) // Unique name
                .Options;

            // Create a context that uses the InMemoryDatabase
            var context = new ReadOnlyDbContext(options);

            var bannerQueryService = new BannerQueryService(context);

            // Act
            var response = await bannerQueryService.GetMarketingMainBanners();

            // Assert
            response.HasError.Should().BeFalse();
            response.IsSuccess.Should().BeTrue();
            response.StatusCode.Should().Be(ResponseStatus.STATUS_SUCCESS);
            response.Result.Should().BeEmpty();  // No banners in the database
        }


        [Fact]
        public async Task GetMarketingMainBanners_ShouldReturnError_WhenExceptionOccurs()
        {
            // Arrange: Mock the DbContext to throw an exception
            var mockDbContext = new Mock<ReadOnlyDbContext>();
            mockDbContext.Setup(m => m.Banners).Throws(new Exception("Database error"));

            // Create a context that uses the InMemoryDatabase
            mockDbContext = new(_options);

            var bannerService = new BannerQueryService(mockDbContext.Object);

            // Act
            var response = await bannerService.GetMarketingMainBanners();

            // Assert
            response.HasError.Should().BeTrue();
            response.IsSuccess.Should().BeFalse();
            response.StatusCode.Should().Be(ResponseStatus.STATUS_InternalServerError);
            response.Message.Should().NotBeNullOrEmpty();
        }

        [Fact]
        public async Task GetBannerDetailById_ShouldReturnSuccess_WhenBannerExists()
        {
            // Arrange
            var banner = new Domain.V1.Entities.Banner
            {
                ID = 112,
                Title = "Test Banner",
                URL = "http://example.com",
                ImageUrl = "http://example.com/image.jpg",
                StartDate = DateTime.UtcNow,
                EndDate = DateTime.UtcNow.AddDays(1),
                Status = true,
                RecordVersion = [ 1, 2, 3, 4 ],
                CreatedBy = "testUser",
                CreatedDate = DateTime.UtcNow,
                IsDeleted = false,
                UpdatedDate = DateTime.UtcNow,
                UpdatedBy = "testUser"
            };

            _context.Banners.Add(banner);
            await _context.SaveChangesAsync();

            // Act
            var result = await _bannerQueryService.GetBannerDetailById(banner.ID);

            // Assert
            Assert.True(result.IsSuccess);
            Assert.Equal(ResponseStatus.STATUS_SUCCESS, result.StatusCode);
            Assert.NotNull(result);
            Assert.NotNull(result.Result);
            Assert.Equal(banner.Title, result.Result.Title);
            Assert.Equal(banner.URL, result.Result.URL);
            Assert.Equal(banner.ImageUrl, result.Result.ImageUrl);
            Assert.Equal(banner.StartDate, result.Result.StartDate);
            Assert.Equal(banner.EndDate, result.Result.EndDate);
            Assert.Equal(banner.Status, result.Result.Status);
        }

        [Fact]
        public async Task GetBannerDetailById_ShouldReturnError_WhenBannerDoesNotExist()
        {
            // Arrange: ID does not exist in the database
            long nonExistingBannerId = 9999;

            // Act
            var result = await _bannerQueryService.GetBannerDetailById(nonExistingBannerId);

            // Assert
            Assert.False(result.IsSuccess);
            Assert.Equal(ResponceStatusCode.RecordNotFound.ToString(), result.StatusCode);
            Assert.Equal(ResponseMessage.STATUS_NODATA, result.Message);
            Assert.Null(result.Result);
        }

        [Fact]
        public async Task GetBannerDetailById_ShouldReturnError_WhenDatabaseIsEmpty()
        {
            // Act: Call the service when no banners are in the database
            var result = await _bannerQueryService.GetBannerDetailById(1001);

            // Assert
            Assert.False(result.IsSuccess);
            Assert.Equal(ResponceStatusCode.RecordNotFound.ToString(), result.StatusCode);
            Assert.Equal(ResponseMessage.STATUS_NODATA, result.Message);
            Assert.Null(result.Result);
        }


        [Fact]
        public async Task GetBannerDetailById_ShouldReturnCorrectResult_WhenBannerExistsForDifferentId()
        {
            // Arrange
            var banner1 = new Domain.V1.Entities.Banner
            {
                ID = 109,
                Title = "Banner 1",
                URL = "http://example.com/1",
                ImageUrl = "http://example.com/image1.jpg",
                StartDate = DateTime.UtcNow,
                EndDate = DateTime.UtcNow.AddDays(1),
                Status = true,
                RecordVersion = [ 1, 2, 3, 4 ],
                CreatedBy = "testUser",
                CreatedDate = DateTime.UtcNow,
                IsDeleted = false,
                UpdatedDate = DateTime.UtcNow,
                UpdatedBy = "testUser"
            };
            var banner2 = new Domain.V1.Entities.Banner
            {
                ID = 111,
                Title = "Banner 2",
                URL = "http://example.com/2",
                ImageUrl = "http://example.com/image2.jpg",
                StartDate = DateTime.UtcNow,
                EndDate = DateTime.UtcNow.AddDays(1),
                Status = true,
                RecordVersion = [ 5, 6, 7, 8 ],
                CreatedBy = "testUser",
                CreatedDate = DateTime.UtcNow,
                IsDeleted = false,
                UpdatedDate = DateTime.UtcNow,
                UpdatedBy = "testUser"
            };

            _context.Banners.Add(banner1);
            _context.Banners.Add(banner2);
            await _context.SaveChangesAsync();

            // Act: Fetch the second banner
            var result = await _bannerQueryService.GetBannerDetailById(111);

            // Assert
            Assert.True(result.IsSuccess);
            Assert.Equal(ResponseStatus.STATUS_SUCCESS, result.StatusCode);
            Assert.NotNull(result.Result);
            Assert.Equal(banner2.Title, result.Result.Title);
            Assert.Equal(banner2.URL, result.Result.URL);
            Assert.Equal(banner2.ImageUrl, result.Result.ImageUrl);
            Assert.Equal(banner2.StartDate, result.Result.StartDate);
            Assert.Equal(banner2.EndDate, result.Result.EndDate);
            Assert.Equal(banner2.Status, result.Result.Status);
        }

      

        [Fact]
        public void GetBannerSearch_ShouldReturnEmptyList_WhenNoBannersExist()
        {
            // Arrange
            var searchRequest = new BannerSearchRequest
            {
                SelectedTitle = "NonExistingTitle", // Search for a title that does not exist
                SelectedStatus = "Active",          // Search for active status
                SelectedStartDate = DateTime.UtcNow.AddDays(-10),
                SelectedEndDate = DateTime.UtcNow.AddDays(10)
            };

            // Act
            var result =  _bannerQueryService.GetBannerSearch(searchRequest);

            // Assert
            Assert.Empty(result);  // No banners should match the search criteria
        }

        [Fact]
        public async Task GetBannerSearch_ShouldReturnBanners_WhenBannersExist()
        {
            // Arrange: Adding banners to the database
            using (var context = new ReadOnlyDbContext(_options))
            {
                context.Banners.AddRange(
                    new Domain.V1.Entities.Banner { ID = 119, Title = "Banner 119", Status = true, IsDeleted = false, CreatedDate = DateTime.UtcNow, UpdatedDate = DateTime.UtcNow, CreatedBy = "testUser" },
                    new Domain.V1.Entities.Banner { ID = 120, Title = "Banner 120", Status = false, IsDeleted = false, CreatedDate = DateTime.UtcNow, UpdatedDate = DateTime.UtcNow, CreatedBy = "testUser" }
                );
                await context.SaveChangesAsync();
            }

            // Act
            var searchRequest = new BannerSearchRequest { SelectedTitle = "Banner 119", SelectedStatus = "Active" };
            var result =  _bannerQueryService.GetBannerSearch(searchRequest);

            // Assert
            Assert.Single(result);  // Only one banner should match the search criteria
            result[0].Title.Should().Be("Banner 119");  // Banner 1 should be returned
        }

        [Fact]
        public async Task GetBannerSearch_ShouldReturnEmptyList_WhenStatusDoesNotMatch()
        {
            // Arrange: Adding banners to the database
            using (var context = new ReadOnlyDbContext(_options))
            {
                context.Banners.AddRange(
                    new Domain.V1.Entities.Banner { ID = 129, Title = "Banner 129", Status = true, IsDeleted = false, CreatedDate = DateTime.UtcNow, UpdatedDate = DateTime.UtcNow, CreatedBy = "testUser" },
                    new Domain.V1.Entities.Banner { ID = 130, Title = "Banner 130", Status = false, IsDeleted = false, CreatedDate = DateTime.UtcNow, UpdatedDate = DateTime.UtcNow, CreatedBy = "testUser" }
                );
                await context.SaveChangesAsync();
            }

            // Act
            var searchRequest = new BannerSearchRequest { SelectedStatus = "InActive", SelectedTitle = "Banner 130"}; // Searching for inactive banners
            var result = _bannerQueryService.GetBannerSearch(searchRequest);

            // Assert
            Assert.Single(result);  // Only Banner 2 should match as inactive
            result[0].Status.Should().BeFalse();  // Banner 2 should have a status of 'false' (inactive)
        }

        [Fact]
        public async Task GetBannerSearch_ShouldReturnBanners_WhenStartDateAndEndDateAreProvided()
        {
            // Arrange: Adding banners to the database
            using (var context = new ReadOnlyDbContext(_options))
            {
                context.Banners.AddRange(
                    new Domain.V1.Entities.Banner { ID = 126, Title = "Banner 126", Status = true, StartDate = DateTime.UtcNow.AddDays(-15), EndDate = DateTime.UtcNow.AddDays(15), IsDeleted = false, CreatedDate = DateTime.UtcNow, UpdatedDate = DateTime.UtcNow, CreatedBy = "testUser" },
                    new Domain.V1.Entities.Banner { ID = 127, Title = "Banner 127", Status = false, StartDate = DateTime.UtcNow.AddDays(15), EndDate = DateTime.UtcNow.AddDays(10), IsDeleted = false, CreatedDate = DateTime.UtcNow, UpdatedDate = DateTime.UtcNow, CreatedBy = "testUser" }
                );
                await context.SaveChangesAsync();
            }

            // Act
            var searchRequest = new BannerSearchRequest { SelectedStartDate = DateTime.UtcNow.AddDays(-20), SelectedEndDate = DateTime.UtcNow.AddDays(20), SelectedStatus = "Active", SelectedTitle = "Banner 126" };
            var result =  _bannerQueryService.GetBannerSearch(searchRequest);

            // Assert
            Assert.Single(result);  // Only Banner 1 should match the date filter
            result[0].Title.Should().Be("Banner 126");  // Banner 1 should be returned
        }

        [Fact]
        public async Task GetBannerSearch_ShouldReturnBanners_WhenOnlyStartDateIsProvided()
        {
            // Adding banners with start dates to the in-memory DB
            using (var context = new ReadOnlyDbContext(_options))
            {
                context.Banners.AddRange(
                    new Domain.V1.Entities.Banner { ID = 125, Title = "Banner 125", Status = true, StartDate = DateTime.UtcNow.AddDays(-5), EndDate = DateTime.UtcNow.AddDays(5), IsDeleted = false, CreatedDate = DateTime.UtcNow, CreatedBy = "testUser", UpdatedDate = DateTime.UtcNow },
                    new Domain.V1.Entities.Banner { ID = 126, Title = "Banner 126", Status = false, StartDate = DateTime.UtcNow.AddDays(5), EndDate = DateTime.UtcNow.AddDays(10), IsDeleted = false, CreatedDate = DateTime.UtcNow, CreatedBy = "testUser", UpdatedDate = DateTime.UtcNow }
                );
                await context.SaveChangesAsync();
            }

            var searchRequest = new BannerSearchRequest { SelectedStartDate = DateTime.UtcNow.AddDays(-6), SelectedTitle = "Banner 125", SelectedStatus = "Active" };

            var result = _bannerQueryService.GetBannerSearch(searchRequest);

            Assert.Single(result);  // Only Banner 1 should match since its start date is before the selected start date
            Assert.Equal("Banner 125", result[0].Title);  // Banner 1 should be returned
        }

        [Fact]
        public async Task GetBannerSearch_ShouldReturnBanners_WhenOnlyEndDateIsProvided()
        {
            // Adding banners with end dates to the in-memory DB
            using (var context = new ReadOnlyDbContext(_options))
            {
                context.Banners.AddRange(
                    new Domain.V1.Entities.Banner { ID = 121, Title = "Banner 121", Status = true, StartDate = DateTime.UtcNow.AddDays(-5), EndDate = DateTime.UtcNow.AddDays(10), IsDeleted = false, CreatedDate = DateTime.UtcNow, CreatedBy = "testUser", UpdatedDate = DateTime.UtcNow },
                    new Domain.V1.Entities.Banner { ID = 122, Title = "Banner 122", Status = false, StartDate = DateTime.UtcNow.AddDays(5), EndDate = DateTime.UtcNow.AddDays(10), IsDeleted = false, CreatedDate = DateTime.UtcNow, CreatedBy = "testUser", UpdatedDate = DateTime.UtcNow }
                );
                await context.SaveChangesAsync();
            }

            var searchRequest = new BannerSearchRequest { SelectedEndDate = DateTime.UtcNow.AddDays(11), SelectedStatus = "Active", SelectedTitle = "Banner 121" };

            var result = _bannerQueryService.GetBannerSearch(searchRequest);

            Assert.Single(result);  // Only Banner 1 should match since its end date is before the selected end date
            Assert.Equal("Banner 121", result[0].Title);  // Banner 1 should be returned
        }

        [Fact]
        public async Task GetBannerSearch_ShouldApplyPaginationCorrectly()
        {
            // Adding banners to the in-memory DB
            using (var context = new ReadOnlyDbContext(_options))
            {
                context.Banners.AddRange(
                    new Domain.V1.Entities.Banner { ID = 115, Title = "Banner 1", Status = true, StartDate = DateTime.UtcNow.AddDays(-5), EndDate = DateTime.UtcNow.AddDays(5), IsDeleted = false, CreatedDate = DateTime.UtcNow, CreatedBy = "testUser", UpdatedDate = DateTime.UtcNow },
                    new Domain.V1.Entities.Banner { ID = 116, Title = "Banner 2", Status = false, StartDate = DateTime.UtcNow.AddDays(5), EndDate = DateTime.UtcNow.AddDays(10), IsDeleted = false, CreatedDate = DateTime.UtcNow, CreatedBy = "testUser", UpdatedDate = DateTime.UtcNow },
                    new Domain.V1.Entities.Banner { ID = 117, Title = "Banner 3", Status = true, StartDate = DateTime.UtcNow.AddDays(-5), EndDate = DateTime.UtcNow.AddDays(5), IsDeleted = false, CreatedDate = DateTime.UtcNow, CreatedBy = "testUser", UpdatedDate = DateTime.UtcNow }
                );
                await context.SaveChangesAsync();
            }

            var searchRequest = new BannerSearchRequest { PageNumber = 1, PageSize = 2, SelectedStatus = "",SelectedTitle = "" };

            var result = _bannerQueryService.GetBannerSearch(searchRequest);

            Assert.Equal(2, result.Count);  // Only two banners should be returned due to pagination
        }

        [Fact]
        public async Task GetBannerSearch_ShouldReturnEmptyList_WhenStartDateIsAfterEndDate()
        {
            // Arrange: Add banners to the in-memory DB
            using (var context = new ReadOnlyDbContext(_options))
            {
                context.Banners.AddRange(
                    new Domain.V1.Entities.Banner { ID = 127, Title = "Banner 127", Status = true, StartDate = DateTime.UtcNow.AddDays(-5), EndDate = DateTime.UtcNow.AddDays(5), IsDeleted = false, CreatedDate = DateTime.UtcNow, CreatedBy = "testUser", UpdatedDate = DateTime.UtcNow },
                    new Domain.V1.Entities.Banner { ID = 128, Title = "Banner 128", Status = false, StartDate = DateTime.UtcNow.AddDays(5), EndDate = DateTime.UtcNow.AddDays(10), IsDeleted = false, CreatedDate = DateTime.UtcNow, CreatedBy = "testUser", UpdatedDate = DateTime.UtcNow }
                );
                await context.SaveChangesAsync();
            }

            // Create a BannerSearchRequest with start date after the end date
            var searchRequest = new BannerSearchRequest
            {
                SelectedStartDate = DateTime.UtcNow.AddDays(10),
                SelectedEndDate = DateTime.UtcNow.AddDays(5), // Start date is after the end date,
                SelectedTitle = "",
                SelectedStatus = ""

            };

            // Act: Call GetBannerSearch with the invalid date range
            var result = _bannerQueryService.GetBannerSearch(searchRequest);

            // Assert: The result should be empty as the date range is invalid
            Assert.Empty(result); 
        }

        [Fact]
        public async Task FindBannerById_ShouldReturnBanner_WhenBannerExists()
        {
            // Arrange
            var banner = new Domain.V1.Entities.Banner
            {
                ID = 101,
                Title = "Test Banner",
                URL = "http://example.com",
                ImageUrl = "http://example.com/image.jpg",
                StartDate = DateTime.UtcNow,
                EndDate = DateTime.UtcNow.AddDays(1),
                Status = true,
                RecordVersion = [1, 2, 3, 4],
                CreatedBy = "testUser",
                CreatedDate = DateTime.UtcNow,
                IsDeleted = false,
                UpdatedDate = DateTime.UtcNow,
                UpdatedBy = "testUser"
            };

            _context.Banners.Add(banner);
            await _context.SaveChangesAsync();

            // Act
            var result = await _bannerQueryService.FindBannerById(banner.ID);

            // Assert
            Assert.NotNull(result);
            Assert.Equal(banner.ID, result.ID);
            Assert.Equal(banner.Title, result.Title);
            Assert.Equal(banner.URL, result.URL);
            Assert.Equal(banner.ImageUrl, result.ImageUrl);
            Assert.Equal(banner.StartDate, result.StartDate);
            Assert.Equal(banner.EndDate, result.EndDate);
            Assert.Equal(banner.Status, result.Status);
        }

        [Fact]
        public async Task FindBannerById_ShouldReturnNull_WhenBannerDoesNotExist()
        {
            // Arrange: ID does not exist in the database
            long nonExistingBannerId = 9999;

            // Act
            var result = await _bannerQueryService.FindBannerById(nonExistingBannerId);

            // Assert
            Assert.Null(result);
        }

        [Fact]
        public async Task FindBannerById_ShouldReturnNull_WhenDatabaseIsEmpty()
        {
            // Act: Call the service when no banners are in the database
            var result = await _bannerQueryService.FindBannerById(1001);

            // Assert
            Assert.Null(result);
        }

        [Fact]
        public async Task FindBannerById_ShouldReturnCorrectBanner_WhenMultipleBannersExist()
        {
            // Arrange
            var banner1 = new Domain.V1.Entities.Banner
            {
                ID = 105,
                Title = "Banner 1",
                URL = "http://example.com/1",
                ImageUrl = "http://example.com/image1.jpg",
                StartDate = DateTime.UtcNow,
                EndDate = DateTime.UtcNow.AddDays(1),
                Status = true,
                RecordVersion = [1, 2, 3, 4],
                CreatedBy = "testUser",
                CreatedDate = DateTime.UtcNow,
                IsDeleted = false,
                UpdatedDate = DateTime.UtcNow,
                UpdatedBy = "testUser"
            };
            var banner2 = new Domain.V1.Entities.Banner
            {
                ID = 106,
                Title = "Banner 2",
                URL = "http://example.com/2",
                ImageUrl = "http://example.com/image2.jpg",
                StartDate = DateTime.UtcNow,
                EndDate = DateTime.UtcNow.AddDays(1),
                Status = true,
                RecordVersion = [5, 6, 7, 8],
                CreatedBy = "testUser",
                CreatedDate = DateTime.UtcNow,
                IsDeleted = false,
                UpdatedDate = DateTime.UtcNow,
                UpdatedBy = "testUser"
            };

            _context.Banners.Add(banner1);
            _context.Banners.Add(banner2);
            await _context.SaveChangesAsync();

            // Act: Fetch the first banner
            var result = await _bannerQueryService.FindBannerById(105);

            // Assert
            Assert.NotNull(result);
            Assert.Equal(banner1.ID, result.ID);
            Assert.Equal(banner1.Title, result.Title);
            Assert.Equal(banner1.URL, result.URL);
            Assert.Equal(banner1.ImageUrl, result.ImageUrl);
            Assert.Equal(banner1.StartDate, result.StartDate);
            Assert.Equal(banner1.EndDate, result.EndDate);
            Assert.Equal(banner1.Status, result.Status);
        }

        #region PreLogin dashboard banner service method tests

        [Fact]
        public async Task GetLatestBannerDetails_ShouldReturn8LatestActiveBanners()
        {
            // Arrange
            var options = new DbContextOptionsBuilder<ReadOnlyDbContext>()
                .UseInMemoryDatabase(databaseName: Guid.NewGuid().ToString()) // Unique name
                .Options;
            using var context = new ReadOnlyDbContext(options);
            SeedData(context);

            var service = new BannerQueryService(context);

            // Act
            var result = await service.GetLatestBannerDetails();

            // Assert
            result.Should().HaveCount(8);
            result.Should().OnlyContain(b => b.Status == true);
            result.Should().BeInDescendingOrder(b => b.StartDate);
        }

        [Fact]
        public async Task GetLatestBannerDetails_ShouldReturnEmptyList_WhenNoBannersExist()
        {
            // Arrange
            var options = new DbContextOptionsBuilder<ReadOnlyDbContext>()
                .UseInMemoryDatabase(databaseName: Guid.NewGuid().ToString()) // Unique name
                .Options;
            using var context = new ReadOnlyDbContext(options);

            var service = new BannerQueryService(context);

            // Act
            var result = await service.GetLatestBannerDetails();

            // Assert
            result.Should().BeEmpty();
        }

        #endregion
    }
}

