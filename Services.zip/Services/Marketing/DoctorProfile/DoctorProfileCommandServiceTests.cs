﻿using System;
using System.Reflection;
using Aurora.AdministrationService.API.Models.Dto.Marketing.DoctorProfile;
using Aurora.AdministrationService.API.Models.Dto.Marketing.DoctorProfile.Manage;
using Aurora.AdministrationService.API.Models.Dto.Marketing.DoctorProfile.View;
using Aurora.AdministrationService.API.Models.RequestModels.V1.AdminDoctor;
using Aurora.AdministrationService.API.Models.ResponseModels.PractitionerPhotos;
using Aurora.AdministrationService.API.Resources;
using Aurora.AdministrationService.API.Services.IService.AdminDoctor;
using Aurora.AdministrationService.API.Services.Service.Marketing.DoctorProfile;
using Aurora.AdministrationService.CrossCutting.CommonModels;
using Aurora.AdministrationService.CrossCutting.Constants;
using Aurora.AdministrationService.Domain.V1.Entities;
using Aurora.AdministrationService.Domain.V1.Entities.Contents;
using Aurora.AdministrationService.Domain.V1.Entities.Practitioners;
using Aurora.AdministrationService.Infrastructure;
using Aurora.AdministrationService.Tests.API.CommonMock;
using AutoMapper;
using FluentAssertions;
using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Diagnostics;
using Microsoft.EntityFrameworkCore.Infrastructure;
using Microsoft.EntityFrameworkCore.Storage;
using Microsoft.Graph;
using Microsoft.Graph.ExternalConnectors;
using Moq;

namespace Aurora.AdministrationService.Tests.API.Services.Marketing.DoctorProfile
{
    public class DoctorProfileCommandServiceTests
    {
        private readonly DoctorProfileCommandService _service;
        private readonly ReadWriteDbContext _dbContext;
        private readonly Mock<IMapper> _mockMapper;
        public DoctorProfileCommandServiceTests()
        {
            // Set up in-memory database
            var options = new DbContextOptionsBuilder<ReadWriteDbContext>()
                .UseInMemoryDatabase(databaseName: "TestDatabase")
                .ConfigureWarnings(b => b.Ignore(InMemoryEventId.TransactionIgnoredWarning))
                .Options;

            _dbContext = new ReadWriteDbContext(options);

            // Set up Mock Mapper
            _mockMapper = new Mock<IMapper>();

            // Initialize the service
            _service = new DoctorProfileCommandService(_dbContext, _mockMapper.Object);
        }

        [Fact]
        public async Task ManageDoctorProfileAsync_ShouldSaveData_WhenValidInputIsProvided()
        {
            // Arrange
            var doctorDetails = new ManageDoctorDetailsDto
            {
                ManageDoctorPrimaryDetails = new ManageDoctorPrimaryDetailsDto
                {
                    PractitionerID = 22,
                    FirstName = "John",
                    LastName = "Doe",
                    GenderID = 1,
                },
                ManageDoctorSpecialityDetails =
            [
                new ManageDoctorSpecialityDetailsDto { Speciality = "speciality1" }
            ],
                ManageDoctorLocationDetails =
            [
                new ManageDoctorLocationDetailsDto { Location = "location1" }
            ],
                ManageDoctorEducationalDetails =
            [
                new ManageDoctorEducationalDetailsDto { EducationalDegree = "degree1",  Institute = "institute", YearOfPassing = 2019  }
            ],
                ManageDoctorExperienceDetails =
            [
                new ManageDoctorExperienceDetailsDto { Designation = "designation1", Title = "title1", Location = "location",  Organization = "organization", CurrentlyWorkingHere = true, JobDurationFrom = DateTime.UtcNow, JobDurationTo = DateTime.UtcNow.AddDays(10), RecordVersion =new byte[] { 1, 2, 3 } }
            ],
                ManageDoctorInterestDetails =
            [
                new ManageDoctorInterestDetailsDto { Interests = "interest1" }
            ],
                ManageDoctorPublicationDetails =
            [
                new ManageDoctorPublicationDetailsDto { Title = "publicationTitle", Link = "publicationLink" , RecordVersion = new byte[] { 1, 2, 3 } }
            ],
                ManageDoctorAdditionalDetails =
            [
                new ManageDoctorAdditionalDetailsDto { Title = "additionalDetailsTitle", Description = "additionalDetailsDescription"}
            ]
            };

            // Mock the mapping for each DTO to entity
            _mockMapper.Setup(m => m.Map<ManageDoctorProfile>(doctorDetails.ManageDoctorPrimaryDetails))
                .Returns(new ManageDoctorProfile { Id = 1, PractitionerID = 1, FirstName = doctorDetails.ManageDoctorPrimaryDetails.FirstName, LastName = doctorDetails.ManageDoctorPrimaryDetails.LastName, CreatedDate = DateTime.UtcNow, IsDeleted = false }); // Ensure PractitionerId is set

            _mockMapper.Setup(m => m.Map<List<ManageDoctorSpeciality>>(doctorDetails.ManageDoctorSpecialityDetails))
                .Returns([new ManageDoctorSpeciality() { Id = 1, Speciality = doctorDetails.ManageDoctorSpecialityDetails[0].Speciality, ManageDoctorProfileID = 1, Status = true, CreatedDate = DateTime.UtcNow, IsDeleted = false }]);

            _mockMapper.Setup(m => m.Map<List<ManageDoctorLocation>>(doctorDetails.ManageDoctorLocationDetails))
                .Returns([new ManageDoctorLocation() { Id = 1, Location = doctorDetails.ManageDoctorLocationDetails[0].Location, ManageDoctorProfileID = 1, Status = true, CreatedDate = DateTime.UtcNow, IsDeleted = false, }]);

            _mockMapper.Setup(m => m.Map<List<EducationalQualification>>(doctorDetails.ManageDoctorEducationalDetails))
                .Returns([new EducationalQualification() { Id = 1, EducationalDegree = doctorDetails.ManageDoctorEducationalDetails[0].EducationalDegree, ManageDoctorProfileID = 1, Institute = doctorDetails.ManageDoctorEducationalDetails[0].Institute, YearOfPassing = doctorDetails.ManageDoctorEducationalDetails[0].YearOfPassing, Status = true, CreatedDate = DateTime.UtcNow, IsDeleted = false }]);

            _mockMapper.Setup(m => m.Map<List<ExperienceDetails>>(doctorDetails.ManageDoctorExperienceDetails))
                .Returns([new ExperienceDetails() { Id = 1, ManageDoctorProfileID = 1, Designation = doctorDetails.ManageDoctorExperienceDetails[0].Designation, Title = doctorDetails.ManageDoctorExperienceDetails[0].Title, Organization = doctorDetails.ManageDoctorExperienceDetails[0].Organization, Location = doctorDetails.ManageDoctorExperienceDetails[0].Location, JobDurationFrom = doctorDetails.ManageDoctorExperienceDetails[0].JobDurationFrom, JobDurationTo = doctorDetails.ManageDoctorExperienceDetails[0].JobDurationTo, CurrentlyWorkingHere = doctorDetails.ManageDoctorExperienceDetails[0].CurrentlyWorkingHere, Status = true, CreatedDate = DateTime.UtcNow, IsDeleted = false }]);

            _mockMapper.Setup(m => m.Map<List<Interest>>(doctorDetails.ManageDoctorInterestDetails))
                .Returns([new Interest() { Id = 1, ManageDoctorProfileID = 1, Interests = doctorDetails.ManageDoctorInterestDetails[0].Interests, Status = true, CreatedDate = DateTime.UtcNow, IsDeleted = false }]);

            _mockMapper.Setup(m => m.Map<List<Publications>>(doctorDetails.ManageDoctorPublicationDetails))
                .Returns([new Publications() { ID = 1, ManageDoctorProfileID = 1, Title = doctorDetails.ManageDoctorPublicationDetails[0].Title, Link = doctorDetails.ManageDoctorPublicationDetails[0].Link, Status = true, CreatedDate = DateTime.UtcNow, IsDeleted = false }]);

            _mockMapper.Setup(m => m.Map<List<Section>>(doctorDetails.ManageDoctorAdditionalDetails))
                .Returns([new Section() { ID = 1, ManageDoctorProfileID = 1, Title = doctorDetails.ManageDoctorAdditionalDetails[0].Title, Description = doctorDetails.ManageDoctorAdditionalDetails[0].Description, Status = true, CreatedDate = DateTime.UtcNow, IsDeleted = false }]);

            _dbContext.Practitioners.Add(new Practitioner { Id = 1, Gender = "gender", Source = "source", ResourceID = "resourceId", Status = true, CreatedDate = DateTime.UtcNow, CreatedBy = "test", UpdatedBy = "test", IsDeleted = false });
             await _dbContext.SaveChangesAsync();

            // Act
            var result = await _service.ManageDoctorProfileAsync(doctorDetails);

            // Assert
            Assert.True(result);

            // Verify that the doctor profile and related entities are saved
            Assert.NotEmpty(_dbContext.ManageDoctorProfiles);

            // Verify that the PractitionerId is correctly set in ManageDoctorProfile
            var savedProfile = await _dbContext.ManageDoctorProfiles.FirstOrDefaultAsync();
            Assert.NotNull(savedProfile);

            // Verify that the mapper was called for each mapping
            _mockMapper.Verify(m => m.Map<ManageDoctorProfile>(doctorDetails.ManageDoctorPrimaryDetails), Times.Once);
            _mockMapper.Verify(m => m.Map<List<ManageDoctorSpeciality>>(doctorDetails.ManageDoctorSpecialityDetails), Times.Once);
            _mockMapper.Verify(m => m.Map<List<ManageDoctorLocation>>(doctorDetails.ManageDoctorLocationDetails), Times.Once);
            _mockMapper.Verify(m => m.Map<List<EducationalQualification>>(doctorDetails.ManageDoctorEducationalDetails), Times.Once);
            _mockMapper.Verify(m => m.Map<List<ExperienceDetails>>(doctorDetails.ManageDoctorExperienceDetails), Times.Once);
            _mockMapper.Verify(m => m.Map<List<Interest>>(doctorDetails.ManageDoctorInterestDetails), Times.Once);
            _mockMapper.Verify(m => m.Map<List<Publications>>(doctorDetails.ManageDoctorPublicationDetails), Times.Once);
            _mockMapper.Verify(m => m.Map<List<Section>>(doctorDetails.ManageDoctorAdditionalDetails), Times.Once);
        }

        [Fact]
        public async Task UpdateRankAsync_ShouldReturnNotFound_WhenDoctorProfileDoesNotExist()
        {
            // Arrange
            var dto = new ManageRankDto { Id = 22, Rank = "5" };

            // Act
            var result = await _service.UpdateRank(dto);

            // Assert
            Assert.False(result.HasError);
            Assert.True(result.IsSuccess);
            Assert.Equal(AdministrationService.CrossCutting.CommonModels.ResponseStatus.STATUS_NotFound, result.StatusCode);
            Assert.Equal(Resource.RecordNotFound, result.Message);
        }

        [Fact]
        public async Task UpdateRankAsync_ShouldUpdateRank_WhenDoctorProfileExists()
        {
            // Arrange
            var dto = new ManageRankDto { Id = 2, Rank = "5" };
            var doctorProfile = new ManageDoctorProfile { Id = 2, Rank = "3", PractitionerID = 14, FirstName = "John", LastName = "Richard", IsDeleted = false, CreatedDate = DateTime.UtcNow };

            await _dbContext.ManageDoctorProfiles.AddAsync(doctorProfile);
            await _dbContext.SaveChangesAsync();

            // Act
            var result = await _service.UpdateRank(dto);

            // Assert
            Assert.False(result.HasError);
            Assert.True(result.IsSuccess);
            Assert.Equal(AdministrationService.CrossCutting.CommonModels.ResponseStatus.STATUS_SUCCESS, result.StatusCode);
            Assert.Equal(Resource.RankUpdatedSuccessfully, result.Message);
            Assert.Equal(dto.Rank, doctorProfile.Rank);
        }
        [Fact]
        public async Task UpdateRankAsync_ShouldAddRank_WhenDoctorProfileExists()
        {
            // Arrange
            var dto = new ManageRankDto { Id = 12, Rank = "5" };
            var doctorProfile = new ManageDoctorProfile { Id = 12, Rank = "", PractitionerID = 15, FirstName = "John", LastName = "Richard", IsDeleted = false, CreatedDate = DateTime.UtcNow };

            await _dbContext.ManageDoctorProfiles.AddAsync(doctorProfile);
            await _dbContext.SaveChangesAsync();

            // Act
            var result = await _service.UpdateRank(dto);

            // Assert
            Assert.False(result.HasError);
            Assert.True(result.IsSuccess);
            Assert.Equal(AdministrationService.CrossCutting.CommonModels.ResponseStatus.STATUS_SUCCESS, result.StatusCode);
            Assert.Equal(Resource.RankSavedSuccessfully, result.Message);
        }

        #region Update primary details testcases
        [Fact]
        public async Task UpdateDoctorPrimaryDetailsAsync_ShouldUpdateDoctorProfile_WhenDoctorProfileExists()
        {
            // Arrange
            // Arrange: Setup in-memory DB
            var options = new DbContextOptionsBuilder<ReadWriteDbContext>()
                .UseInMemoryDatabase(databaseName: Guid.NewGuid().ToString())
                .ConfigureWarnings(warnings => warnings.Ignore(InMemoryEventId.TransactionIgnoredWarning))
                .Options;

            using var _readWriteContext = new ReadWriteDbContext(options);

            // Mock mapper or any other external dependency

            var service = new DoctorProfileCommandService(_readWriteContext, _mockMapper.Object);
            var mockDoctorDetails = new UpdateDoctorPrimaryDetailDto
            {
                DoctorProfileId = 300,
                PractitionerId = 400,
                DoctorDetailsInfo = new DoctorDetailsInfo
                {
                    Salutation = "Dr.",
                    FirstName = "Alicia",
                    MiddleName = "Marie",
                    LastName = "Thompson",
                    GenderID = 1,
                    Designation = "Cardiologist",
                    Status = true,
                    RecordVersion = [1]
                },
                DoctorLocations = new List<DoctorLocationInfo>
                {
                    new DoctorLocationInfo
                    {
                        LocationId = 201,
                        Location = "City Health Clinic",
                        Status = true,
                        RecordVersion = Array.Empty < byte >()
                    },
                    new DoctorLocationInfo
                    {
                        LocationId = 5,
                        Location = "Test",
                        Status = true,
                        RecordVersion = [1]
                    }
                },
                DoctorSpecialities = new List<DoctorSpecialty>
                {
                    new DoctorSpecialty
                    {
                        SpecialtyId = 5,
                        Speciality = "Test",
                        Status = true,
                        IsDeleted=false,
                         RecordVersion = [1]
                    }, 
                    new DoctorSpecialty
                    {
                        SpecialtyId = 301,
                        Speciality = "Cardiology",
                        Status = true,
                        IsDeleted=false,
                        RecordVersion = Array.Empty < byte >()
                    }
                     },
                ImageDetail = new GetPractitionerPhotosDto
                {
                    Id = 1001,
                    PractitionerID = 400,
                    ContentType = "image/jpeg",
                    Data = new byte[] { 255, 216, 255 }, // JPEG header bytes (as an example)
                    URL = "https://example.com/photos/doctor_profile_501.jpg",
                    Size = "512KB",
                    Hash = "a1b2c3d4e5f6g7h8",
                    Title = "Profile Picture",
                    Status = true,
                    CreationDate = DateTime.UtcNow,
                    RecordVersion = [1],
                    IsDeleted = false
                },
                DoctorLanguageInfo=new List<DoctorLanguageInfo>
                {
                     new DoctorLanguageInfo
                    {
                        LanguageId = 6,
                        Language = "English",
                        Status = true,
                        RecordVersion =Array.Empty < byte >()
                    },
                     new DoctorLanguageInfo
                    {
                        LanguageId = 5,
                        Language = "English",
                        Status = true,
                        RecordVersion = [1]
                    },
                }
                
            };

            var doctorProfile = new ManageDoctorProfile { Id = 300, Rank = "3", PractitionerID = 400, FirstName = "John", LastName = "Richard", IsDeleted = false, CreatedDate = DateTime.UtcNow };
            var photo = new PractitionerPhotos { Id = 1, PractitionerID = 400, ContentType = "jpeg", CreationDate = DateTime.UtcNow, Size = "123", Title = "Image", UpdatedBy = "admin", URL = "sample", Data = new byte[] { 1, 1, 1 }, Hash = "asdasd", IsDeleted = false, CreatedDate = DateTime.UtcNow, CreatedBy = "admin", Status = true };
            var languageDetails = new PractitionerCommunication
            {
                Language = "Hindi",
                Id = 5,
                IsDeleted = false,
                CreatedDate = DateTime.UtcNow,
                CreatedBy = "admin",
                Status = true,
                PractitionerID=400,
                RecordVersion = [1]
            };
            var speciality = new ManageDoctorSpeciality
            {
                IsDeleted = false,
                CreatedBy = "Admin",
                CreatedDate = DateTime.UtcNow,
                Status = true,
                Speciality = "Test",
                Id = 5,
                ManageDoctorProfileID = mockDoctorDetails.DoctorProfileId.Value,
                RecordVersion = [1]
            };
            var location = new ManageDoctorLocation
            {
                IsDeleted = false,
                CreatedBy = "Admin",
                CreatedDate = DateTime.UtcNow,
                Status = true,
                Location = "Test",
                Id = 5,
                ManageDoctorProfileID = mockDoctorDetails.DoctorProfileId.Value,
                RecordVersion = [1]
            };

            await _readWriteContext.ManageDoctorLocations.AddAsync(location);
            await _readWriteContext.ManageDoctorSpecialities.AddAsync(speciality); 
            await _readWriteContext.ManageDoctorProfiles.AddAsync(doctorProfile);
            await _readWriteContext.PractitionerPhoto.AddAsync(photo);
            await _readWriteContext.PractitionerCommunications.AddAsync(languageDetails);

            await _readWriteContext.SaveChangesAsync();

            //Mock the Mapper
            _mockMapper.Setup(m => m.Map(It.IsAny<DoctorSpecialty>(), It.IsAny<ManageDoctorSpeciality>()))
                .Callback<DoctorSpecialty, ManageDoctorSpeciality>((dto, entity) =>
                {
                    entity.ManageDoctorProfileID = mockDoctorDetails.DoctorProfileId.Value;
                    entity.IsDeleted = dto.IsDeleted.Value;
                    entity.UpdatedBy = "Admin";
                    entity.UpdatedDate = DateTime.UtcNow;
                });
            _mockMapper.Setup(m => m.Map(It.IsAny<DoctorLocationInfo>(), It.IsAny<ManageDoctorLocation>()))
              .Callback<DoctorLocationInfo, ManageDoctorLocation>((dto, entity) =>
              {
                  entity.ManageDoctorProfileID = mockDoctorDetails.DoctorProfileId.Value;
                  entity.IsDeleted = dto.IsDeleted.Value;
                  entity.UpdatedBy = "Admin";
                  entity.UpdatedDate = DateTime.UtcNow;
              });
            _mockMapper.Setup(m => m.Map(It.IsAny<DoctorLanguageInfo>(), It.IsAny<PractitionerCommunication>()))
            .Callback<DoctorLanguageInfo, PractitionerCommunication>((dto, entity) =>
            {
                entity.PractitionerID = mockDoctorDetails.PractitionerId;
                entity.IsDeleted = dto.IsDeleted.Value;
                entity.UpdatedBy = "Admin";
                entity.UpdatedDate = DateTime.UtcNow;
            });

            _mockMapper.Setup(m => m.Map<ManageDoctorSpeciality>(It.IsAny<DoctorSpecialty>()))
                       .Returns<DoctorSpecialty>(dto => new ManageDoctorSpeciality
                       {
                           IsDeleted = dto.IsDeleted.Value,
                           CreatedBy = "Admin",
                           CreatedDate = DateTime.UtcNow,
                           Status = true,
                           Speciality= "Cardiology",
                           Id= 301,
                           ManageDoctorProfileID = mockDoctorDetails.DoctorProfileId.Value,
                       });
            _mockMapper.Setup(m => m.Map<ManageDoctorLocation>(It.IsAny<DoctorLocationInfo>()))
                      .Returns<DoctorLocationInfo>(dto => new ManageDoctorLocation
                      {
                          IsDeleted = dto.IsDeleted.Value,
                          CreatedBy = "Admin",
                          CreatedDate = DateTime.UtcNow,
                          Status = true,
                          Location = "Test",
                          Id = 1,
                          ManageDoctorProfileID = mockDoctorDetails.DoctorProfileId.Value,
                      });
            _mockMapper.Setup(m => m.Map<PractitionerCommunication>(It.IsAny<DoctorLanguageInfo>()))
                     .Returns<DoctorLanguageInfo>(dto => new PractitionerCommunication
                     {
                         IsDeleted = dto.IsDeleted.Value,
                         CreatedBy = "Admin",
                         CreatedDate = DateTime.UtcNow,
                         Status = true,
                         Language = "Test",
                         Id = 1,
                         PractitionerID = mockDoctorDetails.PractitionerId,
                     });
            // Act
            var result = await service.UpdateDoctorPrimaryDetailsAsync(mockDoctorDetails);

            // Assert
            result.Should().BeTrue();
        }

        [Fact]
        public async Task UpdateDoctorPrimaryDetailsAsync_ShouldNotUpdateDoctorProfile_WhenDoctorProfileNotExists()
        {
            // Arrange
            var mockDoctorDetails = new UpdateDoctorPrimaryDetailDto
            {
                DoctorProfileId = 909090,
                PractitionerId = 32432,
                DoctorDetailsInfo = new DoctorDetailsInfo
                {
                    Salutation = "Dr.",
                    FirstName = "Alicia",
                    MiddleName = "Marie",
                    LastName = "Thompson",
                    GenderID = 1,
                    Designation = "Cardiologist",
                    Status = true,
                    RecordVersion = Array.Empty<byte>()
                },
                DoctorLocations = new List<DoctorLocationInfo>
                {
                    new DoctorLocationInfo
                    {
                        LocationId = 201,
                        Location = "City Health Clinic",
                        Status = true,
                        RecordVersion = Array.Empty < byte >()
                    },
                    new DoctorLocationInfo
                    {
                        LocationId = 202,
                        Location = "Downtown Medical Center",
                        Status = true,
                       RecordVersion = Array.Empty<byte>()
                    }
                },
                DoctorSpecialities = new List<DoctorSpecialty>
                {
                    new DoctorSpecialty
                    {
                        SpecialtyId = 301,
                        Speciality = "Cardiology",
                        Status = true,
                        RecordVersion = Array.Empty<byte>()
                    },
                    new DoctorSpecialty
                    {
                        SpecialtyId = 302,
                        Speciality = "Internal Medicine",
                        Status = true,
                        RecordVersion = Array.Empty<byte>()
                    }
                     },
                ImageDetail = new GetPractitionerPhotosDto
                {
                    Id = 1001,
                    PractitionerID = 400,
                    ContentType = "image/jpeg",
                    Data = new byte[] { 255, 216, 255 }, // JPEG header bytes (as an example)
                    URL = "https://example.com/photos/doctor_profile_501.jpg",
                    Size = "512KB",
                    Hash = "a1b2c3d4e5f6g7h8",
                    Title = "Profile Picture",
                    Status = true,
                    CreationDate = DateTime.UtcNow,
                    RecordVersion = Array.Empty<byte>(),
                    IsDeleted = false
                }
            };

            // Act
            var result = await _service.UpdateDoctorPrimaryDetailsAsync(mockDoctorDetails);

            // Assert
            result.Should().BeFalse();
        }
        #endregion

        #region Test cases for Managedoctor Profile Interest 

        [Fact]
        public async Task UpdateDoctorInterest_ShouldUpdateDoctorInterest_WhenDoctorProfileExists()
        {
            // Arrange

            var options = new DbContextOptionsBuilder<ReadWriteDbContext>()
               .UseInMemoryDatabase(databaseName: Guid.NewGuid().ToString())
               .ConfigureWarnings(b => b.Ignore(InMemoryEventId.TransactionIgnoredWarning))
               .Options;

            var _Context = new ReadWriteDbContext(options);



            // Initialize the service
           var _serviceCommand = new DoctorProfileCommandService(_Context, _mockMapper.Object);


            var dto = new List<DoctorInterestDto>
            {
                 new DoctorInterestDto { Id = 1, Interests = "Test" }
            };

            var doctorProfile = new ManageDoctorProfile
            {
                Id = 100,
                Rank = "3",
                PractitionerID = 200,
                FirstName = "John",
                LastName = "Richard",
                IsDeleted = false,
                CreatedDate = DateTime.UtcNow
                ,
                RecordVersion = [1]
            };

            var interest = new Interest
            {
                Id = 14,
                ManageDoctorProfileID = 100,
                Interests = "Updated Interest",
                IsDeleted = false,
                CreatedDate = DateTime.UtcNow
            };

            // Add data to the context
            await _Context.ManageDoctorProfiles.AddAsync(doctorProfile);
            await _Context.Interests.AddAsync(interest);
            await _Context.SaveChangesAsync();



            _mockMapper.Setup(m => m.Map<Interest>(It.IsAny<DoctorInterestDto>()))
                      .Returns<DoctorInterestDto>(dto => new Interest
                      {
                          Interests = dto.Interests,
                          
                          CreatedDate = DateTime.UtcNow,
                          Id =0,
                          IsDeleted= false,
                          ManageDoctorProfileID=6
                      });

            // Use reflection to access the private method
            var method = typeof(DoctorProfileCommandService)
                .GetMethod("UpdateDoctorInterest", BindingFlags.NonPublic | BindingFlags.Instance);

            // Act
            var result = await (Task<bool>)method.Invoke(_serviceCommand, new object[] { dto, 100 });

            // Assert
            result.Should().BeTrue();
        }

        #endregion


        [Fact]
        public async Task UpdatePublications_ReturnsFalse_WhenDtoIsNullOrEmpty()
        {
            // Arrange
            var manageDoctorProfileID = 1;
            var service = new DoctorProfileCommandService(_dbContext, _mockMapper.Object);

           
            // Use reflection to access the private method
            var method = typeof(DoctorProfileCommandService)
                .GetMethod("UpdateDoctorInterest", BindingFlags.NonPublic | BindingFlags.Instance);


            // Act
            var result = await (Task<bool>)method.Invoke(service, new object[] { null, manageDoctorProfileID });

            // Assert
            result.Should().BeFalse();


        }


        [Fact]
        public async Task UpdatePublications_ReturnsFalse_WhenMappingFails()
        {
            // Arrange
            var manageDoctorProfileID = 1L;
            var publicationsFromDb = new List<Publications>
            {
                new Publications  { ID = 22, ManageDoctorProfileID = manageDoctorProfileID,CreatedDate =DateTime.UtcNow,IsDeleted=false,   }
            };

            var updateDtoList = new List<DoctorInterestDto>
            {
                new DoctorInterestDto { Id = 22,  RecordVersion = new byte[] { 1, 1, 1 },Interests="Test" }
            };

            await _dbContext.Publications.AddRangeAsync(publicationsFromDb);

            await _dbContext.SaveChangesAsync();

            _mockMapper.Setup(m => m.Map(It.IsAny<DoctorInterestDto>(), It.IsAny<Interest>()))
                .Throws(new Exception("Mapping failure"));

            var service = new DoctorProfileCommandService(_dbContext, _mockMapper.Object);

            try
            {
                // Act
                var method = typeof(DoctorProfileCommandService)
                .GetMethod("UpdateDoctorInterest", BindingFlags.NonPublic | BindingFlags.Instance);


                // Act
                var result = await (Task<bool>)method.Invoke(service, new object[] { updateDtoList, manageDoctorProfileID });
            }

            catch (Exception ex)
            {
                // Assert
                Assert.Equal("Object reference not set to an instance of an object.", ex.Message);
            }
           
        }
        [Fact]
        public async Task UpdateAdditional_ReturnsFalse_WhenInputIsNull()
        {
            // Act
            var result = await _service.UpdateAdditional(null, 1);

            // Assert
            Assert.False(result);
        }

        [Fact]
        public async Task UpdateAdditional_ReturnsFalse_WhenInputIsEmpty()
        {
            // Act
            var result = await _service.UpdateAdditional([], 1);

            // Assert
            Assert.False(result);
        }
        [Fact]
        public async Task UpdateAdditional_ShouldReturnTrue_WhenValidInputIsGiven()
        {
            // Arrange: Prepare the input DTO and entities
            var dtoList = new List<UpdateDoctorAdditionalDetailsDto>
            {
                new UpdateDoctorAdditionalDetailsDto
                {
                  ID = 1,
                    IsDeleted = false,
                    RecordVersion = [1]
                }
            };

            var existingMarketSections = new List<Section>
            {
                new Section
                {
                    ID = 1,
                    ManageDoctorProfileID = 1,
                    Status = true,
                     IsDeleted = true,
                     CreatedDate= DateTime.UtcNow
                     , RecordVersion = [1]
                }
            };

            // Mock DbSet behavior
            await _dbContext.MarketSections.AddRangeAsync(existingMarketSections);

            await _dbContext.SaveChangesAsync();

            // Mock the Mapper
            _mockMapper.Setup(m => m.Map(It.IsAny<UpdateDoctorAdditionalDetailsDto>(), It.IsAny<Section>()))
                .Callback<UpdateDoctorAdditionalDetailsDto,Section>((dto, entity) =>
                {
                    entity.IsDeleted = dto.IsDeleted;
                    entity.UpdatedBy = "Admin";
                    entity.UpdatedDate = DateTime.UtcNow;
                });

            // Act: Call the method
            var result = await _service.UpdateAdditional(dtoList, 1);

            // Assert: Verify the result and the mock interactions
            result.Should().BeTrue(); // Ensure the method returns true

            // Verify that the update was mapped correctly
            _mockMapper.Verify(m => m.Map(It.IsAny<UpdateDoctorAdditionalDetailsDto>(), It.IsAny<Section>()), Times.Once);

           
        }

        [Fact]
        public async Task AddAdditional_ShouldReturnTrue_WhenValidInputIsGiven()
        {
            // Arrange: Prepare the input DTO and entities
            var dtoList = new List<UpdateDoctorAdditionalDetailsDto>
            {
                new UpdateDoctorAdditionalDetailsDto
                {
                  ID = 0,
                    IsDeleted = false,
                    RecordVersion = [1],
                }
            };

            var existingMarketSections = new List<Section>
            {
                new Section
                {
                    ID = 22,
                    ManageDoctorProfileID = 33,
                    Status = true,
                     IsDeleted = true,
                     CreatedDate= DateTime.UtcNow
                     , RecordVersion = [1]
                }
            };

            // Mock DbSet behavior
            await _dbContext.MarketSections.AddRangeAsync(existingMarketSections);

            await _dbContext.SaveChangesAsync();

            _mockMapper.Setup(m => m.Map<Section>(It.IsAny<UpdateDoctorAdditionalDetailsDto>()))
                        .Returns<UpdateDoctorAdditionalDetailsDto>(dto => new Section
                        {
                            IsDeleted = dto.IsDeleted,
                            CreatedBy = "Admin",
                            CreatedDate = DateTime.UtcNow,
                            Status = true
                            ,ID=0,
                            ManageDoctorProfileID=1
                        });

            // Act: Call the method
            var result = await _service.UpdateAdditional(dtoList, 1);

            // Assert: Verify the result and the mock interactions
            result.Should().BeTrue(); // Ensure the method returns true

            // Verify that the update was mapped correctly
            _mockMapper.Verify(m => m.Map(It.IsAny<UpdateDoctorAdditionalDetailsDto>(), It.IsAny<Section>()), Times.Never);


        }

        [Fact]
        public async Task UpdateAdditional_ShouldReturnFalse_WhenDtoIsNullOrEmpty()
        {
            // Arrange: Prepare the input as null or empty
            var dtoList = new List<UpdateDoctorAdditionalDetailsDto>();

            // Act: Call the method
            var result = await _service.UpdateAdditional(dtoList, 1);

            // Assert: Ensure that the result is false when input is invalid
            result.Should().BeFalse();
        }


        [Fact]
        public async Task UpdateDoctorImageDetail_ShouldUpdateAndReturnTrue_WhenPhotoExists()
        {
            // Arrange
            var recordVersion = BitConverter.GetBytes(1);

            var doctorDetails = new UpdatePractitionerPhotosDto
            {
                PractitionerID = 22,
                URL = "https://example.com/photo.jpg",
                Size = "1111",
                Data = new byte[] { 1, 2, 3 },
                ContentType = "image/jpeg",
                RecordVersion = recordVersion,
                Hash = "Test",
                Title = "Test"
            };

            var practitionerPhoto = new PractitionerPhotos
            {
                PractitionerID = 22,
                URL = "https://example.com/photo.jpg",
                Size = "1111",
                Data = new byte[] { 1, 2, 3 },
                ContentType = "image/jpeg",
                IsDeleted = false,
                Status = true,
                CreatedBy = "Admin",
                CreatedDate = DateTime.UtcNow,
                Hash = "test",
                Title = "test",
                UpdatedBy = "test",
                RecordVersion = recordVersion,
                CreationDate = DateTime.UtcNow
            };

            var manageDoctorProfile = new ManageDoctorProfile
            {
                Id = 223,
                PractitionerID = 22,
                IsDeleted = false,
                FirstName = "Test",
                CreatedDate = DateTime.UtcNow,
                LastName = "Test"
            };

            await _dbContext.PractitionerPhoto.AddAsync(practitionerPhoto);
            await _dbContext.ManageDoctorProfiles.AddAsync(manageDoctorProfile);
            await _dbContext.SaveChangesAsync();

            // Use reflection to get the private method
            var privateMethod = typeof(DoctorProfileCommandService)
                .GetMethod("UpdateDoctorImageDetail", BindingFlags.NonPublic | BindingFlags.Instance);

            // Act
            var result = await (Task<bool>)privateMethod.Invoke(_service, new object[] { doctorDetails });

            // Assert
            result.Should().BeTrue();
        }

        #region EducationalQualification
        [Fact]
        public async Task UpdateEducationalQualification_ShouldReturnFalse_WhenInputIsNull()
        {
            // Arrange
            var method = typeof(DoctorProfileCommandService)
                .GetMethod("UpdateEducationalQualification", BindingFlags.NonPublic | BindingFlags.Instance);

            // Act
            var result = await  (Task<bool>)method.Invoke(_service, new object[] { 1L, null });

            // Assert
            result.Should().BeFalse();
        }

        [Fact]
        public async Task UpdateEducationalQualification_ShouldReturnFalse_WhenInputListIsEmpty()
        {
            // Arrange
            var method = typeof(DoctorProfileCommandService)
                .GetMethod("UpdateEducationalQualification", BindingFlags.NonPublic | BindingFlags.Instance);

            // Act
            var result = await (Task<bool>)method.Invoke(_service, new object[] { 1L, new List<UpdateEducationalQualificationRequest>() });

            // Assert
            result.Should().BeFalse();
        }


        [Fact]
        public async Task UpdateEducationalQualification_ShouldUpdate_WhenMatchingDataExists()
        {
            // Arrange
            long profileId = 9;
            var version = Convert.FromBase64String("AAAAAAAAB9E=");

            var dto = new UpdateEducationalQualificationRequest
            {
                Id = 16,
                EducationalDegree = "MBBS h1",
                YearOfPassing = 2010,
                Institute = "Harvard college",
                RecordVersion = version
            };

            var dtoList = new List<UpdateEducationalQualificationRequest> { dto };

            var entity = new EducationalQualification
            {
                Id = 16,
                ManageDoctorProfileID = profileId,
                EducationalDegree = "MBBS",
                Institute = "Old College",
                YearOfPassing = 2005,
                CreatedDate = DateTime.UtcNow,
                IsDeleted = false,
                RecordVersion = version
            };

            await _dbContext.EducationalQualifications.AddAsync(entity);
            await _dbContext.SaveChangesAsync();

            // Use reflection to call the private method
            var method = typeof(DoctorProfileCommandService)
                .GetMethod("UpdateEducationalQualification", BindingFlags.NonPublic | BindingFlags.Instance);

            // Act
            var result = await (Task<bool>)method.Invoke(_service, new object[] { profileId, dtoList });

            // Assert
            result.Should().BeTrue();

            // Fetch the updated entity from the database
            var updated = await _dbContext.EducationalQualifications.FirstOrDefaultAsync(e => e.Id == 16);
            updated.Should().NotBeNull();
            updated.EducationalDegree.Should().Be("MBBS h1");
            updated.Institute.Should().Be("Harvard college");
            updated.YearOfPassing.Should().Be(2010);
        }
        [Fact]
        public async Task AddEducationalQualification_WhenMatchingDataExists()
        {
            // Arrange
            long profileId = 9;
            var version = Convert.FromBase64String("AAAAAAAAB9E=");

            var dto = new UpdateEducationalQualificationRequest
            {
                Id = 0,
                EducationalDegree = "MBBS h1",
                YearOfPassing = 2010,
                Institute = "Harvard college",
                RecordVersion = version
            };

            var dtoList = new List<UpdateEducationalQualificationRequest> { dto };

            var entity = new EducationalQualification
            {
                Id = 18,
                ManageDoctorProfileID = profileId,
                EducationalDegree = "MBBS",
                Institute = "Old College",
                YearOfPassing = 2005,
                CreatedDate = DateTime.UtcNow,
                IsDeleted = false,
                RecordVersion = version
            };

            await _dbContext.EducationalQualifications.AddAsync(entity);
            await _dbContext.SaveChangesAsync();

            _mockMapper.Setup(m => m.Map<EducationalQualification>(It.IsAny<UpdateEducationalQualificationRequest>()))
            .Returns<UpdateEducationalQualificationRequest>(dto => new EducationalQualification
             {
                EducationalDegree = dto.EducationalDegree,
                 YearOfPassing = dto.YearOfPassing,
                Institute = dto.Institute,
                RecordVersion = dto.RecordVersion,
                IsDeleted = dto.IsDeleted,
                Id=0,
                CreatedDate=DateTime.UtcNow,
                ManageDoctorProfileID= profileId
            });

            // Use reflection to call the private method
            var method = typeof(DoctorProfileCommandService)
                .GetMethod("UpdateEducationalQualification", BindingFlags.NonPublic | BindingFlags.Instance);

            // Act
            var result = await (Task<bool>)method.Invoke(_service, new object[] { profileId, dtoList });

            // Assert
            result.Should().BeTrue();

           
        }

        #endregion

        #region ExperienceDetails

        [Fact]
        public async Task UpdateDoctorProfileExperienceDetails_ShouldReturnFalse_WhenInputIsNull()
        {
            // Arrange
            long profileId = 1;

            // Use reflection to call the private method
            var method = typeof(DoctorProfileCommandService)
                .GetMethod("UpdateDoctorProfileExperienceDetails", BindingFlags.NonPublic | BindingFlags.Instance);

            // Act
            var result =await (Task<bool>)method.Invoke(_service, new object[] { profileId, null });

            // Assert
            result.Should().BeFalse();
        }

        [Fact]
        public async Task UpdateDoctorProfileExperienceDetails_ShouldReturnFalse_WhenInputIsEmpty()
        {
            // Arrange
            long profileId = 1;
            var emptyList = new List<UpdateExperienceDetailsDto>(); // Empty list

            // Use reflection to call the private method
            var method = typeof(DoctorProfileCommandService)
                .GetMethod("UpdateDoctorProfileExperienceDetails", BindingFlags.NonPublic | BindingFlags.Instance);

            // Act
            var result = await (Task<bool>)method.Invoke(_service, new object[] { profileId, emptyList });

            // Assert
            result.Should().BeFalse();
        }

        [Fact]
        public async Task UpdateDoctorProfileExperienceDetails_ShouldUpdateExperienceDetails_WhenMatchingRecordsExist()
        {
            // Arrange
            long profileId = 1;
            var version = Convert.FromBase64String("AAAAAAAAB9E=");

            // Clear existing data
            _dbContext.ExperienceDetail.RemoveRange(_dbContext.ExperienceDetail);
            await _dbContext.SaveChangesAsync();

            var dbExperiences = new List<ExperienceDetails>
            {
                new ExperienceDetails
                {
                    Id = 1,
                    ManageDoctorProfileID = profileId,
                    Title = "Old Title",
                    Designation = "Old Designation",
                    Organization = "Old Organization",
                    Location = "Old Location",
                    CreatedDate = DateTime.UtcNow,
                    CurrentlyWorkingHere = false,
                    JobDurationFrom = new DateTime(2020, 1, 1, 0, 0, 0, DateTimeKind.Utc),
                    JobDurationTo = new DateTime(2020, 1, 1, 0, 0, 0, DateTimeKind.Utc),
                    IsDeleted = false,
                    RecordVersion = version
                }
            };

            await _dbContext.ExperienceDetail.AddRangeAsync(dbExperiences);
            await _dbContext.SaveChangesAsync();

            var dtoList = new List<UpdateExperienceDetailsDto>
            {
                new UpdateExperienceDetailsDto
                {
                    ExperienceDetailsId = 1,
                    Title = "New Title",
                    Designation = "New Designation",
                    Organization = "New Organization",
                    Location = "New Location",
                    CurrentlyWorkingHere = true,
                    JobDurationFrom = new DateTime(2022, 1, 1, 0, 0, 0, DateTimeKind.Utc),
                    JobDurationTo = new DateTime(2023, 1, 1, 0, 0, 0, DateTimeKind.Utc),
                    RecordVersion = version,
                    ManageDoctorProfileID= 1,
                    IsDeleted = false,
                }
            };

            // Act
            // Use reflection to get the private method
            var privateMethod = typeof(DoctorProfileCommandService)
                .GetMethod("UpdateDoctorProfileExperienceDetails", BindingFlags.NonPublic | BindingFlags.Instance);

            // Act
            var result = await (Task<bool>)privateMethod.Invoke(_service, new object[] { profileId, dtoList });

            // Assert
            result.Should().BeTrue();
        }

        [Fact]
        public async Task AddDoctorProfileExperienceDetails_ShouldUpdateExperienceDetails_WhenMatchingRecordsExist()
        {
            // Arrange
            long profileId = 13;
            var version = Convert.FromBase64String("AAAAAAAAB9E=");

            // Clear existing data
            _dbContext.ExperienceDetail.RemoveRange(_dbContext.ExperienceDetail);
            await _dbContext.SaveChangesAsync();

            var dbExperiences = new List<ExperienceDetails>
            {
                new ExperienceDetails
                {
                    Id = 1,
                    ManageDoctorProfileID = profileId,
                    Title = "Old Title",
                    Designation = "Old Designation",
                    Organization = "Old Organization",
                    Location = "Old Location",
                    CreatedDate = DateTime.UtcNow,
                    CurrentlyWorkingHere = false,
                    JobDurationFrom = new DateTime(2020, 1, 1, 0, 0, 0, DateTimeKind.Utc),
                    JobDurationTo = new DateTime(2020, 1, 1, 0, 0, 0, DateTimeKind.Utc),
                    IsDeleted = false,
                    RecordVersion = version
                }
            };

            await _dbContext.ExperienceDetail.AddRangeAsync(dbExperiences);
            await _dbContext.SaveChangesAsync();

            var dtoList = new List<UpdateExperienceDetailsDto>
            {
                new UpdateExperienceDetailsDto
                {
                    ExperienceDetailsId = 0,
                    Title = "New Title",
                    Designation = "New Designation",
                    Organization = "New Organization",
                    Location = "New Location",
                    CurrentlyWorkingHere = true,
                    JobDurationFrom = new DateTime(2022, 1, 1, 0, 0, 0, DateTimeKind.Utc),
                    JobDurationTo = new DateTime(2023, 1, 1, 0, 0, 0, DateTimeKind.Utc),
                    RecordVersion = version,
                    ManageDoctorProfileID= 1,
                    IsDeleted = false,
                    
                }
            };

            _mockMapper.Setup(m => m.Map<ExperienceDetails>(It.IsAny<UpdateExperienceDetailsDto>()))
                .Returns<UpdateExperienceDetailsDto>(dto => new ExperienceDetails
                {
                    Title = dto.Title,
                    Designation = dto.Designation,
                    Organization = dto.Organization,
                    Location = dto.Location,
                    JobDurationFrom = dto.JobDurationFrom,
                    JobDurationTo = dto.JobDurationTo,
                    CurrentlyWorkingHere = dto.CurrentlyWorkingHere,
                    RecordVersion = dto.RecordVersion,
                    CreatedDate = DateTime.UtcNow,
                    CreatedBy = "TestUser",   // mock user
                    IsDeleted = false,
                    Status = true,
                    Id=0,
                    ManageDoctorProfileID= profileId
                });
            // Act
            // Use reflection to get the private method
            var privateMethod = typeof(DoctorProfileCommandService)
                .GetMethod("UpdateDoctorProfileExperienceDetails", BindingFlags.NonPublic | BindingFlags.Instance);

            // Act
            var result = await (Task<bool>)privateMethod.Invoke(_service, new object[] { profileId, dtoList });

            // Assert
            result.Should().BeTrue();
        }

        #endregion

        [Fact]
        public async Task UpdateDoctorProfile_UpdatePriaryDetail_WhenSucceed()
        {
            // Arrange: Setup in-memory DB
            var options = new DbContextOptionsBuilder<ReadWriteDbContext>()
                .UseInMemoryDatabase(databaseName: Guid.NewGuid().ToString())
                .ConfigureWarnings(warnings => warnings.Ignore(InMemoryEventId.TransactionIgnoredWarning))
                .Options;

            using var context = new ReadWriteDbContext(options);

            // Mock mapper or any other external dependency
            var mockMapper = new Mock<IMapper>();

            var service = new DoctorProfileCommandService(context, mockMapper.Object);

            var profileId = 1L;
            var updateDto = new UpdateDoctorProfileDto
            {
                UpdatePrimaryDetails = new UpdateDoctorPrimaryDetailDto(),
                PhotosDetails =null,
                ExperienceDetails =null,
                Interests = null,              
                PublicationDetails = null,
                AdditionalDetails = null
            };


            // Act
            var result = await service.UpdateDoctorProfile(profileId, updateDto);

            // Assert
            Assert.True(result.IsSuccess);
            Assert.False(result.HasError);
            Assert.Equal(ResponseMessage.STATUS_DATA_UPDATED, result.Message);
            Assert.Equal(ResponseStatusCode.STATUS_SUCCESS, result.StatusCode);
        }

        [Fact]
        public async Task UpdatePublications_ShouldAddNewPublication_WhenNotExists()
        {
            // Arrange
            var profileId = 10;
            var version = BitConverter.GetBytes(1);

            var dto = new UpdateDoctorPublicationDetailsDto
            {
                Id = null, // Simulate a new record
                Title = "New Research Paper",
                IsDeleted = false,
                RecordVersion = version
            };

            var dtoList = new List<UpdateDoctorPublicationDetailsDto> { dto };

            var mockMapper = new Mock<IMapper>();
            mockMapper.Setup(m => m.Map<Publications>(It.IsAny<UpdateDoctorPublicationDetailsDto>()))
                      .Returns<UpdateDoctorPublicationDetailsDto>(d => new Publications
                      {
                          Title = d.Title,
                          RecordVersion = d.RecordVersion
                          ,CreatedDate= DateTime.Now,
                          ID = 0,
                          IsDeleted= false,
                          ManageDoctorProfileID = profileId
                      });

            var service = new DoctorProfileCommandService(_dbContext, mockMapper.Object);

            // Act
            var method = typeof(DoctorProfileCommandService)
                .GetMethod("UpdatePublications", BindingFlags.Instance | BindingFlags.NonPublic);

            var resultTask = (Task<bool>)method.Invoke(service, new object[] { dtoList, profileId });
            var result = await resultTask;

            // Assert
            result.Should().BeTrue();

            var publication = await _dbContext.Publications.FirstOrDefaultAsync();
            publication.Should().NotBeNull();
            publication.Title.Should().Be(dto.Title);
            publication.ManageDoctorProfileID.Should().Be(profileId);
            publication.IsDeleted.Should().BeFalse();
            publication.Status.Should().BeTrue();
        }
        [Fact]
        public async Task UpdatePublications_AddNewPublication_WhenNotExists()
        {
            // Arrange
            var options = new DbContextOptionsBuilder<ReadWriteDbContext>()
                .UseInMemoryDatabase(databaseName: Guid.NewGuid().ToString())
                .ConfigureWarnings(b => b.Ignore(InMemoryEventId.TransactionIgnoredWarning))
                .Options;

            var _Context = new ReadWriteDbContext(options);

            // Initialize the service
            var _serviceCommand = new DoctorProfileCommandService(_Context, _mockMapper.Object);

            var profileId = 10;
            var version = BitConverter.GetBytes(1);

            var dto = new UpdateDoctorPublicationDetailsDto
            {
                Id = 1, // Simulate a new record
                Title = "New Research Paper",
                IsDeleted = false,
                RecordVersion = version,
                
                
            };

            var data = new Publications
            {
                ID = 1, // Existing publication
                CreatedDate = DateTime.UtcNow,
                ManageDoctorProfileID = profileId,
                IsDeleted = false,
                RecordVersion = version
            };

            var dtoList = new List<UpdateDoctorPublicationDetailsDto> { dto };

            // Add existing publication
            await _Context.Publications.AddAsync(data);
            await _Context.SaveChangesAsync();

            // Mock the Mapper to return a new Publication with a unique ID
            _mockMapper.Setup(m => m.Map<Publications>(It.IsAny<UpdateDoctorPublicationDetailsDto>()))
                .Returns<UpdateDoctorPublicationDetailsDto>(dto => new Publications
                {
                    CreatedDate = DateTime.UtcNow,
                    ID = 2, // Ensure unique ID for new publication
                    IsDeleted = false,
                    ManageDoctorProfileID = profileId,
                });

            // Act
            var method = typeof(DoctorProfileCommandService)
                .GetMethod("UpdatePublications", BindingFlags.Instance | BindingFlags.NonPublic);

            var resultTask = (Task<bool>)method.Invoke(_serviceCommand, new object[] { dtoList, profileId });
            var result = await resultTask;

            // Assert
            result.Should().BeTrue();

            // Check if the new publication was added
            var publication = await _Context.Publications.FirstOrDefaultAsync(p => p.ID == 1);
            publication.Should().NotBeNull(); // Ensure the new publication exists
        }

        [Fact]
        public async Task UpdateDoctorProfile_UpdateDoctorInterest_WhenNotNull()
        {
            // Arrange
            var profileId = 100;
            var recordVersion =new byte[8];

            var interestDto = new List<DoctorInterestDto>
            {
            new DoctorInterestDto
            {
            Id = 1,
            Interests = "New Interest",
            IsDeleted = false,
            RecordVersion = recordVersion
            }
            };

            var existingInterest = new Interest
            {
                Id = 1,
                ManageDoctorProfileID = profileId,
                Interests = "Old Interest",
                IsDeleted = false,
                CreatedDate = DateTime.UtcNow,
                CreatedBy = "test",
                RecordVersion = recordVersion
            };

            await _dbContext.Interests.AddAsync(existingInterest);
            await _dbContext.SaveChangesAsync();
            var updateDto = new UpdateDoctorProfileDto
            {
                UpdatePrimaryDetails = new UpdateDoctorPrimaryDetailDto(),
                PhotosDetails = null,
                ExperienceDetails = null,
                Interests = interestDto,
                PublicationDetails = null,
                AdditionalDetails = null
            };
            var result = await _service.UpdateDoctorProfile(profileId, updateDto);

            // Assert

            Assert.True(result.IsSuccess);
            Assert.False(result.HasError);
            Assert.Equal(ResponseMessage.STATUS_DATA_UPDATED, result.Message);
            Assert.Equal(ResponseStatusCode.STATUS_SUCCESS, result.StatusCode);
        }
        [Fact]
        public async Task UpdateDoctorProfile_UpdatePublications_WhenNotNull()
        {
            // Arrange
            var profileId = 10;
            var version = BitConverter.GetBytes(1);

            var dto = new UpdateDoctorPublicationDetailsDto
            {
                Id = null, // Simulate a new record
                Title = "New Research Paper",
                IsDeleted = false,
                RecordVersion = version
            };

            var dtoList = new List<UpdateDoctorPublicationDetailsDto> { dto };
            _mockMapper.Setup(m => m.Map<Publications>(It.IsAny<UpdateDoctorPublicationDetailsDto>()))
                      .Returns<UpdateDoctorPublicationDetailsDto>(d => new Publications
                      {
                          Title = d.Title,
                          RecordVersion = d.RecordVersion
                          ,
                          CreatedDate = DateTime.Now,
                          ID = 0,
                          IsDeleted = false,
                          ManageDoctorProfileID = profileId
                      });

            // Act
            var updateDto = new UpdateDoctorProfileDto
            {
                UpdatePrimaryDetails = new UpdateDoctorPrimaryDetailDto(),
                PhotosDetails = null,
                ExperienceDetails = null,
                Interests = null,
                PublicationDetails = dtoList,
                AdditionalDetails = null
            };
            var result = await _service.UpdateDoctorProfile(profileId, updateDto);

            // Assert

            Assert.True(result.IsSuccess);
            Assert.False(result.HasError);
            Assert.Equal(ResponseMessage.STATUS_DATA_UPDATED, result.Message);
            Assert.Equal(ResponseStatusCode.STATUS_SUCCESS, result.StatusCode);
        }

        [Fact]
        public async Task UpdateDoctorProfile_UpdateDoctorProfileExperienceDetails_WhenNull()
        {
            // Arrange
            long profileId = 1;
            var version = Convert.FromBase64String("AAAAAAAAB9E=");

            // Clear existing data
            _dbContext.ExperienceDetail.RemoveRange(_dbContext.ExperienceDetail);
            await _dbContext.SaveChangesAsync();

            var dbExperiences = new List<ExperienceDetails>
            {
                new ExperienceDetails
                {
                    Id = 1,
                    ManageDoctorProfileID = profileId,
                    Title = "Old Title",
                    Designation = "Old Designation",
                    Organization = "Old Organization",
                    Location = "Old Location",
                    CreatedDate = DateTime.UtcNow,
                    CurrentlyWorkingHere = false,
                    JobDurationFrom = new DateTime(2020, 1, 1, 0, 0, 0, DateTimeKind.Utc),
                    JobDurationTo = new DateTime(2020, 1, 1, 0, 0, 0, DateTimeKind.Utc),
                    IsDeleted = false,
                    RecordVersion = version
                }
            };

            await _dbContext.ExperienceDetail.AddRangeAsync(dbExperiences);
            await _dbContext.SaveChangesAsync();

            var dtoList = new List<UpdateExperienceDetailsDto>
            {
                new UpdateExperienceDetailsDto
                {
                    ExperienceDetailsId = 1,
                    Title = "New Title",
                    Designation = "New Designation",
                    Organization = "New Organization",
                    Location = "New Location",
                    CurrentlyWorkingHere = true,
                    JobDurationFrom = new DateTime(2022, 1, 1, 0, 0, 0, DateTimeKind.Utc),
                    JobDurationTo = new DateTime(2023, 1, 1, 0, 0, 0, DateTimeKind.Utc),
                    RecordVersion = version,
                    ManageDoctorProfileID= 1,
                    IsDeleted = false,
                }
            };

            // Act
            var updateDto = new UpdateDoctorProfileDto
            {
                UpdatePrimaryDetails = new UpdateDoctorPrimaryDetailDto(),
                PhotosDetails = null,
                ExperienceDetails = dtoList,
                Interests = null,
                PublicationDetails = null,
                AdditionalDetails = null
            };
            var result = await _service.UpdateDoctorProfile(profileId, updateDto);

            // Assert

            Assert.True(result.IsSuccess);
            Assert.False(result.HasError);
            Assert.Equal(ResponseMessage.STATUS_DATA_UPDATED, result.Message);
            Assert.Equal(ResponseStatusCode.STATUS_SUCCESS, result.StatusCode);
        }


    }
}