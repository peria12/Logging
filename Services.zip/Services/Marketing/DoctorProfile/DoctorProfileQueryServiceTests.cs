﻿using Aurora.AdministrationService.API.Controllers.Marketing.DoctorProfile;
using Aurora.AdministrationService.API.Helper;
using Aurora.AdministrationService.API.Models.Dto.Marketing.DoctorProfile.Manage;
using Aurora.AdministrationService.API.Models.Dto.Marketing.DoctorProfile.Summary;
using Aurora.AdministrationService.API.Models.Dto.Marketing.DoctorProfile.View;
using Aurora.AdministrationService.API.Services.IService.Marketing.DoctorProfile;
using Aurora.AdministrationService.API.Services.Service.Marketing.DoctorProfile;
using Aurora.AdministrationService.API.Services.Service.Schedule;
using Aurora.AdministrationService.CrossCutting.CommonModels;
using Aurora.AdministrationService.Domain.V1.Entities;
using Aurora.AdministrationService.Infrastructure;
using AutoMapper;
using Castle.Core.Logging;
using FluentAssertions;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Diagnostics;
using Microsoft.Extensions.Logging;
using Moq;

namespace Aurora.AdministrationService.Tests.API.Services.Marketing.DoctorProfile
{
    public class DoctorProfileQueryServiceTests
    {
        private readonly DoctorProfileQueryService _service;
        private readonly ReadOnlyDbContext _dbContext;
        private readonly Mock<IRegionCodeValidationHelper> _mockRegionCodeValidationHelper;
        private readonly Mock<IDoctorProfileCommandService> _mockDoctorProfileCommandService;
        private readonly Mock<IDoctorProfileQueryService> _mockDoctorProfileQueryService;
        private readonly Mock<DbSet<Section>> _mockMarketSectionDbSet;
        private readonly Mock<ReadWriteDbContext> _mockDbContext;
        private readonly ILogger<DoctorProfileQueryService> _logger; // Declare ILogger

        public DoctorProfileQueryServiceTests()
        {
            _mockRegionCodeValidationHelper = new Mock<IRegionCodeValidationHelper>();
            _mockDoctorProfileCommandService = new Mock<IDoctorProfileCommandService>();
            _mockDoctorProfileQueryService = new Mock<IDoctorProfileQueryService>();
            _mockMarketSectionDbSet = new Mock<DbSet<Section>>();
            _mockDbContext = new Mock<ReadWriteDbContext>();
            _logger = null;
            // Set up in-memory database
            var options = new DbContextOptionsBuilder<ReadOnlyDbContext>()
                .UseInMemoryDatabase(databaseName: "TestDatabase")
                .ConfigureWarnings(b => b.Ignore(InMemoryEventId.TransactionIgnoredWarning))
                .Options;

            _dbContext = new ReadOnlyDbContext(options);

            // Initialize the service
            _service = new DoctorProfileQueryService(_dbContext, _logger);
        }

        [Fact]
        public async Task GetDoctorProfileGridData_ShouldReturnData()
        {
            // Arrange
            ManageDoctorProfile obj1 = new ManageDoctorProfile
            {
                Id = 1,
                PractitionerID = 111,
                Title = "Doctor",
                FirstName = "James",
                MiddleName = "David",
                LastName = "Bush",
                IsDeleted = true,
                CreatedDate = System.DateTime.UtcNow,
                UpdatedBy = "1",
                UpdatedDate = System.DateTime.UtcNow,
                CreatedBy = "1"
            };
            _dbContext.ManageDoctorProfiles.Add(obj1);

            ManageDoctorProfile obj2 = new ManageDoctorProfile
            {
                Id = 2,
                PractitionerID = 111,
                Title = "Doctor1",
                FirstName = "James1",
                MiddleName = "David1",
                LastName = "Bush1",
                IsDeleted = true,
                CreatedDate = System.DateTime.UtcNow,
                UpdatedBy = "1",
                UpdatedDate = System.DateTime.UtcNow,
                CreatedBy = "1"
            };
            _dbContext.ManageDoctorProfiles.Add(obj2);

            ManageDoctorSpeciality spl1 = new ManageDoctorSpeciality
            {
                Id = 1,
                ManageDoctorProfileID = 33,
                Speciality = "general",
                CreatedBy = "A",
                CreatedDate = System.DateTime.UtcNow,
                IsDeleted = false,
            };
            _dbContext.ManageDoctorSpecialities.Add(spl1);

            ManageDoctorSpeciality spl2 = new ManageDoctorSpeciality
            {
                Id = 2,
                ManageDoctorProfileID = 44,
                Speciality = "general",
                CreatedBy = "B",
                CreatedDate = System.DateTime.UtcNow,
                IsDeleted = false,
            };
            _dbContext.ManageDoctorSpecialities.Add(spl2);

            ManageDoctorLocation locObj1 = new ManageDoctorLocation
            {
                Id = 1,
                ManageDoctorProfileID = 55,
                Location = "Delhi",
                Status = true,
                IsDeleted = false,
                CreatedBy = "A",
                CreatedDate = System.DateTime.UtcNow,
            };
            _dbContext.ManageDoctorLocations.Add(locObj1);

            ExperienceDetails expObj1 = new ExperienceDetails
            {
                Id = 1,
                ManageDoctorProfileID = 55,
                Location = "Hyd",
                Status = true,
                IsDeleted = false,
                CreatedBy = "CCC",
                CreatedDate = System.DateTime.UtcNow,
            };
            _dbContext.ExperienceDetail.Add(expObj1);

            var result = await _service.GetDoctorProfileGridData();
            if (result.Count == 0)
            {
                Assert.True(result.Count == 0);
            }
            if (result.Count > 0)
            {
                Assert.True(result.Count > 0);
            }
        }

        [Fact]
        public async Task GetDoctorProfileBySearch_ShouldReturnDataByName()
        {
             // Arrange
                ManageDoctorProfile obj = new ManageDoctorProfile
                {
                    Id = 10,
                    PractitionerID = 111,
                    Title = "Doctor",
                    FirstName = "James",
                    MiddleName = "David",
                    LastName = "Bush",
                    IsDeleted = false,
                    CreatedDate = System.DateTime.UtcNow,
                    UpdatedBy = "1",
                    UpdatedDate = System.DateTime.UtcNow,
                    CreatedBy = "1"
                };
                _dbContext.ManageDoctorProfiles.Add(obj);
                await _dbContext.SaveChangesAsync();

                DoctorProfileSearchFilterDto searchObj = new DoctorProfileSearchFilterDto()
                {
                    Name = "James"
                };
                // Act
                var result = await _service.GetDoctorProfileBySearch(searchObj);

                // Assert
                Assert.True(result.Count > 0);
        }

        [Fact]
        public async Task GetDoctorProfileBySearch_ShouldReturnEmptyDataWhenNameMissMatch()
        {
            // Arrange
            ManageDoctorProfile obj = new ManageDoctorProfile
            {
                Id = 99,
                PractitionerID = 1,
                Title = "BBB",
                FirstName = "GGG",
                MiddleName = "WWW",
                LastName = "VVV",
                IsDeleted = true,
                CreatedDate = System.DateTime.UtcNow,
            };
            _dbContext.ManageDoctorProfiles.Add(obj);
            await _dbContext.SaveChangesAsync();

            DoctorProfileSearchFilterDto searchObj = new DoctorProfileSearchFilterDto()
            {
                Name = "James123"
            };
            // Act
            var result = await _service.GetDoctorProfileBySearch(searchObj);
            // Assert
            Assert.True(result.Count == 0);
        }

        [Fact]
        public async Task GetSearchFiltersData_ShouldReturnOk()
        {           
            Aurora.AdministrationService.Domain.V1.Entities.ManageDoctorSpeciality mdocSplObj = new Aurora.AdministrationService.Domain.V1.Entities.ManageDoctorSpeciality
            {
                Id = 111,
                Speciality = "general",
                ManageDoctorProfileID = 2,
                IsDeleted = true,
                Status = true,
                CreatedBy = "David",
                CreatedDate = System.DateTime.UtcNow,
            };
            _dbContext.ManageDoctorSpecialities.Add(mdocSplObj);
                await _dbContext.SaveChangesAsync();                

            Aurora.AdministrationService.Domain.V1.Entities.Locations.Location locObj = new Aurora.AdministrationService.Domain.V1.Entities.Locations.Location
            {
                Id = 1,
                Name = "loc",
                ResourceID = "1",
                Status = true,
                IsDeleted = false,
                CreatedBy = "A",
                CreatedDate = System.DateTime.UtcNow,
            };
            _dbContext.Locations.Add(locObj);
            await _dbContext.SaveChangesAsync();

            Aurora.AdministrationService.Domain.V1.Entities.Organizations.Organization expdetObj = new Aurora.AdministrationService.Domain.V1.Entities.Organizations.Organization
            {
                Id = 1,
                Name = "Org1",
                ResourceID = "1",
                Status = true,
                CreatedBy = "A",
                CreatedDate = System.DateTime.UtcNow,
                IsDeleted = false,
                Alias = "A",
                Source = "Doc",
                Type = "A",
                UpdatedBy = "A",
            };
            _dbContext.Organizations.Add(expdetObj);
            await _dbContext.SaveChangesAsync();

            Domain.Old.Entities.Language practcomObj = new Aurora.AdministrationService.Domain.Old.Entities.Language
            {
                LanguageId = 1,
                LanguageName = "Eng",
                LanguageCode = "111",
            };
            _dbContext.Languages.Add(practcomObj);
            await _dbContext.SaveChangesAsync();

            // Act
            var result = await _service.GetSearchFiltersData();                                        
            Assert.True(result.LocationMasterList.Count > 0);
            Assert.True(result.OrganizationMasterList.Count > 0);
            Assert.True(result.SpokenLanguageMasterList.Count > 0);
           
        }

        [Fact]
        public async Task GetSearchFiltersData_ShouldReturnNoData()
        {
            // Act
            var result = await _service.GetSearchFiltersData();           
            Assert.True(result.LocationMasterList.Count == 0);
            Assert.True(result.OrganizationMasterList.Count == 0);
            Assert.True(result.SpokenLanguageMasterList.Count == 0);
        }


        [Fact]
        public async Task GetPublicationById_NotFound_ReturnsNotFound()
        {
            // Arrange
            var mockQueryService = new Mock<IDoctorProfileQueryService>();
            var regionHelperMock = new Mock<IRegionCodeValidationHelper>();
            var controller = new DoctorProfileController(_mockRegionCodeValidationHelper.Object, _mockDoctorProfileCommandService.Object, _mockDoctorProfileQueryService.Object);

            regionHelperMock.Setup(x => x.VerifyRegionCodeHeader(It.IsAny<HttpRequest>()))
                .Returns(new GenericResponse<string> { HasError = false });
            mockQueryService.Setup(x => x.GetPublicationById(1)).ReturnsAsync((List<ManageDoctorPublicationDetailsDto>)null);

            // Act
            var result = await controller.GetPublicationById(1);

            // Assert
            Assert.IsType<NotFoundObjectResult>(result.Result);
        }

        [Fact]
        public async Task GetPublicationById_ContentDoesNotExist_ReturnsNull()
        {
            // Arrange
            var options = new DbContextOptionsBuilder<ReadOnlyDbContext>()
                .UseInMemoryDatabase(databaseName: Guid.NewGuid().ToString()) // ensures isolation
                .Options;

            using var context = new ReadOnlyDbContext(options);

            // Seed with some data (IDs 1 and 2 only)
            context.Publications.AddRange(new List<Publications>
                                        {
                                            new Publications
                                            {
                                                ID = 1,
                                                ManageDoctorProfileID = 1,
                                                Title = "Cardiology Research",
                                                Link = "https://researchlink.com",
                                                CreatedBy = "Admin",
                                                CreatedDate = DateTime.UtcNow,
                                                RecordVersion = new byte[8] { 1, 2, 3, 4, 5, 6, 7, 8 },
                                                IsDeleted = false
                                            },
                                            new Publications
                                            {
                                                ID = 2,
                                                ManageDoctorProfileID = 2,
                                                Title = "Cardiology Research 2",
                                                Link = "https://researchlink2.com",
                                                CreatedBy = "Admin1",
                                                CreatedDate = DateTime.UtcNow,
                                                RecordVersion = new byte[8] { 8, 7, 6, 5, 4, 3, 2, 1 },
                                                IsDeleted = false
                                            }
                                        });

            await context.SaveChangesAsync();

            var service = new DoctorProfileQueryService(context, _logger);

            // Act
            List<ManageDoctorPublicationDetailsDto> result = await service.GetPublicationById(999); // ID 999 does not exist

            // Assert
            Assert.Empty(result);
        }

        [Fact]
        public async Task GetSectionById_SectionDoesNotExist_ReturnsNull()
        {
            // Arrange
            var sections = new List<Section>().AsQueryable();

            _mockMarketSectionDbSet.As<IQueryable<Section>>().Setup(m => m.Provider).Returns(sections.Provider);
            _mockMarketSectionDbSet.As<IQueryable<Section>>().Setup(m => m.Expression).Returns(sections.Expression);
            _mockMarketSectionDbSet.As<IQueryable<Section>>().Setup(m => m.ElementType).Returns(sections.ElementType);
            _mockMarketSectionDbSet.As<IQueryable<Section>>().Setup(m => m.GetEnumerator()).Returns(sections.GetEnumerator());

            _mockDbContext.Setup(x => x.MarketSections).Returns(_mockMarketSectionDbSet.Object);

            // Act
            var result = await _service.GetSectionById(999);

            // Assert
            Assert.Empty(result);
        }

        [Fact]
        public async Task GetDoctorProfileInterest_ShouldReturnData()
        {
            // Arrange
            long practitionerId = 21;
            long profileId = 333333;

            var obj1 = new ManageDoctorProfile
            {
                Id = profileId,
                PractitionerID = practitionerId,
                Title = "Doctor",
                FirstName = "James",
                MiddleName = "David",
                LastName = "Bush",
                IsDeleted = true,
                Description = "Experienced physician",
                CreatedDate = DateTime.UtcNow,
                UpdatedBy = "1",
                UpdatedDate = DateTime.UtcNow,
                CreatedBy = "1"
            };
            _dbContext.ManageDoctorProfiles.Add(obj1);

            var int1 = new Aurora.AdministrationService.Domain.V1.Entities.Interest
            {
                Id = 2,
                ManageDoctorProfileID = profileId,
                Interests = "Cardiology, Surgery",
                CreatedBy = "B",
                CreatedDate = DateTime.UtcNow,
                IsDeleted = false,
            };
            _dbContext.Interests.Add(int1);

            await _dbContext.SaveChangesAsync();

            // Act
            var result = await _service.GetDoctorProfileInterest(profileId); // Use profileId now as method expects profileId

            // Assert
            result.Should().NotBeNull();

            result.Should().HaveCountGreaterThan(0);

            var item = result.FirstOrDefault();

            item.PractitionerId.Should().Be(practitionerId);
            item.DoctorProfileId.Should().Be(profileId);

            item.DoctorInterest.Should().NotBeNull();
            item.DoctorInterest.Interests.Should().Be("Cardiology, Surgery");
        }

        [Fact]
        public async Task GetDoctorProfileInterest_ShouldReturnNull_WhenNoDataExists()
        {
            long practitionerId = 9999; // Non-existent PractitionerID

            // Act
            var result = await _service.GetDoctorProfileInterest(practitionerId);

            // Assert
            result.Should().HaveCount(0); 
        }

        [Fact]
        public async Task GetDoctorDetails_ShouldReturnDoctorDetails_WhenDataExists()
        {
            // Arrange

            long practitionerId = 88888;

            var doctorProfile = new ManageDoctorProfile
            {
                Id = 90001,
                PractitionerID = practitionerId,
                Title = "Dr.",
                FirstName = "Test",
                MiddleName = "X.",
                LastName = "Person",
                GenderID = 1,
                Designation = "Test Designation",
                IsDeleted = false,
                CreatedDate = DateTime.UtcNow,
                RecordVersion = Array.Empty<byte>()
            };
            _dbContext.ManageDoctorProfiles.Add(doctorProfile);
            await _dbContext.SaveChangesAsync();

            var doctorLocation = new ManageDoctorLocation
            {
                Id = 90002,
                ManageDoctorProfileID = doctorProfile.Id,
                Location = "UniqueLocation",
                Status = true,
                CreatedDate = DateTime.UtcNow,
                IsDeleted = false,
                RecordVersion = Array.Empty<byte>()
            };
            _dbContext.ManageDoctorLocations.Add(doctorLocation);
            await _dbContext.SaveChangesAsync();


            // Act
            var result = await _service.GetDoctorPrimaryDetails(90001);

            // Assert
            result.Should().NotBeNull();
            result.PractitionerId.Should().Be(practitionerId);

            result.DoctorDetailsInfo.Should().NotBeNull();
            result.DoctorDetailsInfo.FirstName.Should().Be("Test");
            result.DoctorDetailsInfo.LastName.Should().Be("Person");
            result.DoctorDetailsInfo.MiddleName.Should().Be("X.");
            result.DoctorDetailsInfo.GenderID.Should().Be(1);
            result.DoctorDetailsInfo.Designation.Should().Be("Test Designation");
            result.DoctorDetailsInfo.Status.Should().BeTrue();
            result.DoctorDetailsInfo.RecordVersion.Should().Equal(Array.Empty<byte>());
        }

        [Fact]
        public async Task GetDoctorDetails_ShouldReturnNull_WhenPractitionerNotFound()
        {
            // Arrange
            long invalidPractitionerId = 9999;

            // Act
            var result = await _service.GetDoctorPrimaryDetails(invalidPractitionerId);

            // Assert
            result.Should().BeNull();
        }

        [Fact]
        public async Task GetDoctorProfileEducationalQualificationById_ReturnsQualifications_WhenProfileExists()
        {
            //arrang

            // Set up in-memory database
            var options = new DbContextOptionsBuilder<ReadOnlyDbContext>()
                .UseInMemoryDatabase(databaseName: "TestDatabase")
                .ConfigureWarnings(b => b.Ignore(InMemoryEventId.TransactionIgnoredWarning))
                .Options;

            var objread = new ReadOnlyDbContext(options);

            // Seed test data
            objread.EducationalQualifications.AddRange(
                new EducationalQualification
                {
                    Id = 23,
                    ManageDoctorProfileID = 1,
                    EducationalDegree = "MBBS",
                    Institute = "AIIMS",
                    YearOfPassing = 2015,
                    IsDeleted = false
                    ,CreatedDate= DateTime.UtcNow
                },
                new EducationalQualification
                {
                    Id = 24,
                    ManageDoctorProfileID = 1,
                    EducationalDegree = "MD",
                    Institute = "PGIMER",
                    YearOfPassing = 2018,
                    IsDeleted = false,
                    CreatedDate = DateTime.UtcNow
                },
                new EducationalQualification
                {
                    Id = 25,
                    ManageDoctorProfileID = 2,
                    EducationalDegree = "BDS",
                    Institute = "King's College",
                    YearOfPassing = 2012,
                    IsDeleted = false,
                    CreatedDate = DateTime.UtcNow
                }
            );

            await objread.SaveChangesAsync();

            // Act
            var result = await _service.GetDoctorProfileEducationalQualificationById(1);

            // Assert
            Assert.NotNull(result);
            Assert.All(result, q => Assert.False(string.IsNullOrEmpty(q.EducationalDegree)));
        }

        [Fact]
        public async Task GetDoctorProfileEducationalQualificationById_ReturnsEmpty_WhenNoProfileExists()
        {
            //arrang
            // Seed test data
            _dbContext.EducationalQualifications.AddRange(
                new EducationalQualification
                {
                    Id = 111,
                    ManageDoctorProfileID = 111,
                    EducationalDegree = "MBBS",
                    Institute = "AIIMS",
                    YearOfPassing = 2015,
                    IsDeleted = false
                    ,
                    CreatedDate = DateTime.UtcNow
                },
                new EducationalQualification
                {
                    Id = 222,
                    ManageDoctorProfileID = 12,
                    EducationalDegree = "MD",
                    Institute = "PGIMER",
                    YearOfPassing = 2018,
                    IsDeleted = false,
                    CreatedDate = DateTime.UtcNow
                },
                new EducationalQualification
                {
                    Id = 53,
                    ManageDoctorProfileID = 52,
                    EducationalDegree = "BDS",
                    Institute = "King's College",
                    YearOfPassing = 2012,
                    IsDeleted = false,
                    CreatedDate = DateTime.UtcNow
                }
            );

            await _dbContext.SaveChangesAsync();

            // Act
            var result = await _service.GetDoctorProfileEducationalQualificationById(99);

            // Assert
            Assert.NotNull(result);
            Assert.Empty(result); // No qualifications for doctor ID 99
        }      

        [Fact]
        public async Task GetDoctorProfileExperienceDetailById_ReturnsExperiences_WhenProfileExists()
        {
            //Arrange
            // Seed test data
            _dbContext.ExperienceDetail.AddRange(
                new ExperienceDetails
                {
                    Id = 11,
                    ManageDoctorProfileID = 1,
                    Title = "Senior Surgeon",
                    Location = "Mumbai",
                    CurrentlyWorkingHere = true,
                    Designation = "Consultant",
                    JobDurationFrom = DateTime.UtcNow.AddYears(-1),
                    JobDurationTo = DateTime.UtcNow,
                    Organization = "AIIMS",
                    IsDeleted = false,
                    CreatedDate = DateTime.UtcNow
                },
                new ExperienceDetails
                {
                    Id=12,
                    ManageDoctorProfileID = 1,
                    Title = "Junior Surgeon",
                    Location = "Delhi",
                    CurrentlyWorkingHere = false,
                    Designation = "Resident",
                    JobDurationFrom = DateTime.UtcNow.AddYears(-1),
                    JobDurationTo = DateTime.UtcNow,
                    Organization = "PGIMER",
                    IsDeleted = false,
                    CreatedDate = DateTime.UtcNow
                }
            );
             await _dbContext.SaveChangesAsync();

            // Act
            var result = await _service.GetDoctorProfileExperienceDetailById(1);

            // Assert
            Assert.NotNull(result);
            Assert.All(result, exp => Assert.False(string.IsNullOrEmpty(exp.Title)));
        }

        public async Task<List<ExperienceDetailsDto>> GetDoctorProfileExperienceDetailById(long doctorProfileId)
        {
            var experiences = await _dbContext.ExperienceDetail
                .Where(x => x.ManageDoctorProfileID == doctorProfileId && !x.IsDeleted)
                .Select(x => new ExperienceDetailsDto
                {
                    Id = x.Id,
                    Title = x.Title,
                    Location = x.Location,
                    Designation = x.Designation,
                    CurrentlyWorkingHere = x.CurrentlyWorkingHere,
                    JobDurationFrom = x.JobDurationFrom,
                    JobDurationTo = x.JobDurationTo,
                    RecordVersion = new byte[3] { 1, 2, 3 },
                    Organization = x.Organization
                })
                .ToListAsync();

            return experiences;
        }

        [Fact]
        public async Task GetDoctorProfileExperienceDetailById_ReturnsEmpty_WhenAllRecordsAreDeleted()
        {
            // Arrange
            var doctorId = 2;
            var deletedExperience = new ExperienceDetails
            {
                Id = 6,
                ManageDoctorProfileID = doctorId,
                Title = "PhD Researcher",
                Location = "Harvard",
                CurrentlyWorkingHere = false,
                Designation = "Research Fellow",
                JobDurationFrom = DateTime.UtcNow.AddYears(-1),
                JobDurationTo = DateTime.UtcNow,
                Organization = "Harvard University",
                IsDeleted = true,
                CreatedDate = DateTime.Now,
            };
            _dbContext.ExperienceDetail.Add(deletedExperience);
            await _dbContext.SaveChangesAsync();

            // Act
            var result = await _service.GetDoctorProfileExperienceDetailById(doctorId);

            // Assert
            Assert.NotNull(result);
            Assert.Empty(result); // No records because it's marked as deleted
        }
        [Fact]
        public async Task CheckInAsync_ReturnsNull_WhenNoData()
        {
            // Arrange
            DoctorProfileSearchFilterDto searchObj = new DoctorProfileSearchFilterDto()
            {
                Speciality = "test",
                Locations = "test",
                Organization = "test",
                Status = true,
            };
            var result = await _service.GetDoctorProfileBySearch(searchObj);
            Assert.False(result.Count > 0);
        }

        [Fact]
        public async Task CheckInAsync_ReturnsNull_WhenRankSpokenLanguageIsEmpty()
        {
            // Arrange
            DoctorProfileSearchFilterDto searchObj = new DoctorProfileSearchFilterDto()
            {
                Rank = "5",
                SpokenLanguage = "Tamil",
            };
            var result = await _service.GetDoctorProfileBySearch(searchObj);
            Assert.False(result.Count > 0);
        }
        [Fact]
        public void ApplyDoctorProfileFilters_ShouldReturnOriginalList_WhenFiltersAreNull()
        {
            // Arrange
            var profiles = GetSampleProfiles();

            // Act
            var result = DoctorProfileQueryService.ApplyDoctorProfileFilters(profiles, null);

            // Assert
            result.Should().BeEquivalentTo(profiles);
        }

        [Fact]
        public void ApplyDoctorProfileFilters_ShouldFilterByName()
        {
            // Arrange
            var profiles = GetSampleProfiles();
            var filters = new DoctorProfileSearchFilterDto { Name = "John" };

            // Act
            var result = DoctorProfileQueryService.ApplyDoctorProfileFilters(profiles, filters);

            // Assert
            result.Should().OnlyContain(x => x.Name.Contains("John", StringComparison.OrdinalIgnoreCase));
        }

        [Fact]
        public void ApplyDoctorProfileFilters_ShouldFilterBySpeciality()
        {
            var profiles = GetSampleProfiles();
            var filters = new DoctorProfileSearchFilterDto { Speciality = "Cardiology" };

            var result = DoctorProfileQueryService.ApplyDoctorProfileFilters(profiles, filters);

            result.Should().OnlyContain(x => x.Speciality.Contains("Cardiology", StringComparison.OrdinalIgnoreCase));
        }

        [Fact]
        public void ApplyDoctorProfileFilters_ShouldFilterByRank()
        {
            var profiles = GetSampleProfiles();
            var filters = new DoctorProfileSearchFilterDto { Rank = "Senior" };

            var result = DoctorProfileQueryService.ApplyDoctorProfileFilters(profiles, filters);

            result.Should().OnlyContain(x => x.Rank.Contains("Senior", StringComparison.OrdinalIgnoreCase));
        }

        [Fact]
        public void ApplyDoctorProfileFilters_ShouldFilterByLocations()
        {
            var profiles = GetSampleProfiles();
            var filters = new DoctorProfileSearchFilterDto { Locations = "New York" };

            var result = DoctorProfileQueryService.ApplyDoctorProfileFilters(profiles, filters);

            result.Should().OnlyContain(x => x.Locations.Contains("New York", StringComparison.OrdinalIgnoreCase));
        }

        [Fact]
        public void ApplyDoctorProfileFilters_ShouldFilterByOrganization()
        {
            var profiles = GetSampleProfiles();
            var filters = new DoctorProfileSearchFilterDto { Organization = "City Hospital" };

            var result = DoctorProfileQueryService.ApplyDoctorProfileFilters(profiles, filters);

            result.Should().OnlyContain(x => x.Organization.Contains("City Hospital", StringComparison.OrdinalIgnoreCase));
        }

        [Fact]
        public void ApplyDoctorProfileFilters_ShouldFilterBySpokenLanguage()
        {
            var profiles = GetSampleProfiles();
            var filters = new DoctorProfileSearchFilterDto { SpokenLanguage = "English" };

            var result = DoctorProfileQueryService.ApplyDoctorProfileFilters(profiles, filters);

            result.Should().OnlyContain(x => x.SpokenLanguage.Contains("English", StringComparison.OrdinalIgnoreCase));
        }

        [Fact]
        public void ApplyDoctorProfileFilters_ShouldFilterByStatus()
        {
            var profiles = GetSampleProfiles();
            var filters = new DoctorProfileSearchFilterDto { Status = true };

            var result = DoctorProfileQueryService.ApplyDoctorProfileFilters(profiles, filters);

            result.Should().OnlyContain(static x => x.Status == true);
        }

        private static List<DoctorProfileDto> GetSampleProfiles()
        {
            return new List<DoctorProfileDto>
        {
            new DoctorProfileDto
            {
                Name = "John Doe",
                Speciality = "Cardiology",
                Rank = "Senior",
                Locations = "New York",
                Organization = "City Hospital",
                SpokenLanguage = "English",
                Status  = true
            },
            new DoctorProfileDto
            {
                Name = "Jane Smith",
                Speciality = "Neurology",
                Rank = "Junior",
                Locations = "Los Angeles",
                Organization = "County Hospital",
                SpokenLanguage = "Spanish",
                Status  = false
            }
          };
       }
    }
}
