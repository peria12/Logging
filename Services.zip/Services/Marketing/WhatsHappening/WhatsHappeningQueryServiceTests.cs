﻿using Aurora.AdministrationService.API.Enum;
using Aurora.AdministrationService.API.Models.Dto.WhatHappenings;
using Aurora.AdministrationService.API.Models.ResponseModels.WhatsHappening;
using Aurora.AdministrationService.API.Services.Service.WhatsHappenings;
using Aurora.AdministrationService.CrossCutting.CommonModels;
using Aurora.AdministrationService.Domain.V1.Entities.Locations;
using Aurora.AdministrationService.Infrastructure;
using AutoMapper;
using FluentAssertions;
using Microsoft.EntityFrameworkCore;
using Moq;
using entityCategory = Aurora.AdministrationService.Domain.V1.Entities.Marketings.CategoryMaster;
using entityLocation = Aurora.AdministrationService.Domain.V1.Entities.Locations.Location;
using entityWhatsHappening = Aurora.AdministrationService.Domain.V1.Entities.Marketings.WhatsHappening;

namespace Aurora.AdministrationService.Tests.API.Services.Marketing.WhatsHappening
{
    public class WhatsHappeningQueryServiceTests
    {
        private readonly Mock<ReadOnlyDbContext> _readOnlyDbContextMock;
        private readonly Mock<IMapper> _mapperMock;
        private readonly WhatsHappeningQueryService _WhatsHappeningQueryService;
        private readonly Mock<DbSet<entityWhatsHappening>> _mockDbSet;
        private readonly Mock<DbSet<entityLocation>> _mockLocationDbSet;
        private readonly Mock<DbSet<LocationAddress>> _mockLocationAddressDbSet;
        private readonly Mock<DbSet<entityCategory>> _mockCategoryDbSet;
        private static readonly string[] NonExistentCategories = { "20" };
        private static readonly string[] NonExistentLocations = { "20" };
        private static readonly string[] CategoryFilter = { "2" };
        private static readonly string[] LocationFilter = { "1" };

        public WhatsHappeningQueryServiceTests()
        {
            //Initialize mock
            _readOnlyDbContextMock = new Mock<ReadOnlyDbContext>();
            _mapperMock = new Mock<IMapper>();

            // Setup in-memory ready only database for testing
            DbContextOptions<ReadOnlyDbContext> options = new DbContextOptionsBuilder<ReadOnlyDbContext>()
              .UseInMemoryDatabase(databaseName: "AdminWhatsHappeningTestDB").Options;

            _readOnlyDbContextMock = new(options);

            _mockDbSet = new Mock<DbSet<entityWhatsHappening>>();
            _mockLocationDbSet = new Mock<DbSet<entityLocation>>();
            _mockLocationAddressDbSet = new Mock<DbSet<LocationAddress>>();
            _mockCategoryDbSet = new Mock<DbSet<entityCategory>>();

            var data = new List<entityWhatsHappening>
            {
                new entityWhatsHappening{ ID = 1, Title = "Test One",URL="test",CategoryID=1,StartDate=DateTime.UtcNow,EndDate=DateTime.UtcNow,HospitalID=1,Description="Test",Image="test",Status=true,Location = new entityLocation {Id=1, ResourceID="2323",Status=true, Name="L1",Latitude=123.3M,Longitude=234.242M,IsDeleted = false, CreatedBy = "Admin", CreatedDate = DateTime.UtcNow}, IsDeleted = false, CreatedBy = "Admin", CreatedDate = DateTime.UtcNow, UpdatedBy = "admin", UpdatedDate = DateTime.UtcNow },
                new entityWhatsHappening{ ID = 2, Title = "Test Two",URL="test",CategoryID=1,StartDate=DateTime.UtcNow,EndDate=DateTime.UtcNow,HospitalID=1,Description="Test",Image="test",Status=true,Location = new entityLocation {Id=1, ResourceID="2323",Status=true, Name="L1",Latitude=123.3M,Longitude=234.242M,IsDeleted = false, CreatedBy = "Admin", CreatedDate = DateTime.UtcNow}, IsDeleted = false, CreatedBy = "Admin", CreatedDate = DateTime.UtcNow, UpdatedBy = "admin", UpdatedDate = DateTime.UtcNow },
            }.AsQueryable();

            //Setup
            _mockDbSet.As<IQueryable<entityWhatsHappening>>().Setup(m => m.Provider).Returns(data.Provider);
            _mockDbSet.As<IQueryable<entityWhatsHappening>>().Setup(m => m.Expression).Returns(data.Expression);
            _mockDbSet.As<IQueryable<entityWhatsHappening>>().Setup(m => m.ElementType).Returns(data.ElementType);
            _mockDbSet.As<IQueryable<entityWhatsHappening>>().Setup(m => m.GetEnumerator()).Returns(data.GetEnumerator());
            _readOnlyDbContextMock.Setup(c => c.WhatsHappeningsNew).Returns(_mockDbSet.Object);

            // Mock data for Locations table
            var categoryData = new List<entityCategory>
                {
                    new entityCategory {ID=1, Code="PAC",Definition="Packages",IsDeleted = false, CreatedBy = "Admin", CreatedDate = DateTime.UtcNow},
                    new entityCategory {ID=2, Code="FEST",Definition="Festival", IsDeleted = false, CreatedBy = "Admin", CreatedDate = DateTime.UtcNow}
                }.AsQueryable();

            //Setup
            _mockCategoryDbSet.As<IQueryable<entityCategory>>().Setup(m => m.Provider).Returns(categoryData.Provider);
            _mockCategoryDbSet.As<IQueryable<entityCategory>>().Setup(m => m.Expression).Returns(categoryData.Expression);
            _mockCategoryDbSet.As<IQueryable<entityCategory>>().Setup(m => m.ElementType).Returns(categoryData.ElementType);
            _mockCategoryDbSet.As<IQueryable<entityCategory>>().Setup(m => m.GetEnumerator()).Returns(categoryData.GetEnumerator());
            _readOnlyDbContextMock.Setup(c => c.CategoryMasters).Returns(_mockCategoryDbSet.Object);

            // Mock data for Locations table
            var locationData = new List<entityLocation>
                {
                    new entityLocation {Id=1, ResourceID="2323",Status=true, Name="L1",Latitude=123.3M,Longitude=234.24M,IsDeleted = false, CreatedBy = "Admin", CreatedDate = DateTime.UtcNow},
                    new entityLocation {Id=2, ResourceID="2323",Status=true, Name="L1",Latitude=123.3M,Longitude=234.24M,IsDeleted = false, CreatedBy = "Admin", CreatedDate = DateTime.UtcNow}
                }.AsQueryable();

            // Setup Locations Mock
            _mockLocationDbSet.As<IQueryable<entityLocation>>().Setup(m => m.Provider).Returns(locationData.Provider);
            _mockLocationDbSet.As<IQueryable<entityLocation>>().Setup(m => m.Expression).Returns(locationData.Expression);
            _mockLocationDbSet.As<IQueryable<entityLocation>>().Setup(m => m.ElementType).Returns(locationData.ElementType);
            _mockLocationDbSet.As<IQueryable<entityLocation>>().Setup(m => m.GetEnumerator()).Returns(locationData.GetEnumerator());
            _readOnlyDbContextMock.Setup(c => c.Locations).Returns(_mockLocationDbSet.Object);

            var locationAddressData = new List<LocationAddress>
                            {
                                new LocationAddress
                                {
                                    Id = 1,
                                    LocationID = 1,
                                    Use = "Work",
                                    Type = "Office",
                                    Line1 = "123 Main St",
                                    Line2 = "Suite 456",
                                    Line3 = "Business Complex",
                                    Line4 = "Downtown",
                                    City = "New York",
                                    State = "NY",
                                    District = "Manhattan",
                                    PostalCode = "10001",
                                    Country = "USA",
                                    PeriodStart = DateTime.UtcNow.AddYears(-1),
                                    PeriodEnd = DateTime.UtcNow.AddYears(1),
                                    Status = true,
                                    RecordVersion = new byte[] { 1, 2, 3, 4 },
                                    IsDeleted = false,
                                    CreatedBy = "Admin",
                                    CreatedDate = DateTime.UtcNow.AddMonths(-6),
                                    UpdatedBy = "Admin",
                                    UpdatedDate = DateTime.UtcNow,
                                    Location = new entityLocation
                                    {
                                        ResourceID = "1001",
                                        Name = "Downtown Office",
                                        Latitude = 40.71M,
                                        Longitude = -74.06M,
                                        Status = true,
                                        IsDeleted = false,
                                        CreatedBy = "Admin",
                                        CreatedDate = DateTime.UtcNow
                                    }
                                },
                                new LocationAddress
                                {
                                    Id = 2,
                                    LocationID = 2,
                                    Use = "Home",
                                    Type = "Apartment",
                                    Line1 = "456 Elm St",
                                    Line2 = "Apt 789",
                                    Line3 = null,
                                    Line4 = null,
                                    City = "Los Angeles",
                                    State = "CA",
                                    District = "Central LA",
                                    PostalCode = "90001",
                                    Country = "USA",
                                    PeriodStart = DateTime.UtcNow.AddYears(-2),
                                    PeriodEnd = null,
                                    Status = true,
                                    RecordVersion = new byte[] { 5, 6, 7, 8 },
                                    IsDeleted = false,
                                    CreatedBy = "User1",
                                    CreatedDate = DateTime.UtcNow.AddMonths(-12),
                                    UpdatedBy = "User1",
                                    UpdatedDate = DateTime.UtcNow,
                                    Location = new entityLocation
                                    {
                                        ResourceID = "1002",
                                        Name = "Home Address",
                                        Latitude = 34.05M,
                                        Longitude = -118.24M,
                                        Status = true,
                                        IsDeleted = false,
                                        CreatedBy = "User1",
                                        CreatedDate = DateTime.UtcNow
                                    }
                                }
                            }.AsQueryable();

            // Setup LocationAddress Mock
            _mockLocationAddressDbSet.As<IQueryable<LocationAddress>>().Setup(m => m.Provider).Returns(locationAddressData.Provider);
            _mockLocationAddressDbSet.As<IQueryable<LocationAddress>>().Setup(m => m.Expression).Returns(locationAddressData.Expression);
            _mockLocationAddressDbSet.As<IQueryable<LocationAddress>>().Setup(m => m.ElementType).Returns(locationAddressData.ElementType);
            _mockLocationAddressDbSet.As<IQueryable<LocationAddress>>().Setup(m => m.GetEnumerator()).Returns(locationAddressData.GetEnumerator());

            // Assign the mock to the DbContext
            _readOnlyDbContextMock.Setup(c => c.LocationAddresses).Returns(_mockLocationAddressDbSet.Object);

            // Create the service instance
            _WhatsHappeningQueryService = new WhatsHappeningQueryService(_readOnlyDbContextMock.Object, _mapperMock.Object);
        }

        /// <summary> Tests if IsWhatsHappeningAlreadyExist returns true when the specified WhatsHappening entity exists. </summary>
        /// <returns>Asserts that the result is true and the message indicates data was found.</returns>
        [Fact]
        public async Task IsWhatsHappeningAlreadyExist_ShouldReturnTrue_WhenWhatsHappeningExists()
        {
            // Arrange
            long Id = 1L;
            var whatsHappeningmock = new entityWhatsHappening
            { ID = 1L, Title = "Test One", IsDeleted = false, CreatedBy = "Admin", CreatedDate = DateTime.UtcNow, UpdatedBy = "admin", UpdatedDate = DateTime.UtcNow };

            // Mock the FindAsync method to return the WhatsHappening
            _readOnlyDbContextMock.Setup(db => db.WhatsHappeningsNew.FindAsync(Id))
                .ReturnsAsync(whatsHappeningmock);

            // Act
            var result = await _WhatsHappeningQueryService.IsWhatsHappeningAlreadyExist(Id);

            // Assert
            result.result.Should().BeTrue();
            result.message.Should().Be(ResponseMessage.STATUS_DATA_FOUND);
        }

        /// <summary> Tests if IsWhatsHappeningAlreadyExist returns false when a WhatsHappening entity with the specified ID does not exist.</summary>
        /// <returns>Asserts that the result is false and the message indicates no data was found.</returns>
        [Fact]
        public async Task IsWhatsHappeningAlreadyExist_ShouldReturnFalse_WhenWhatsHappeningDoesNotExist()
        {
            // Arrange
            var Id = 3;

            // Act
            var result = await _WhatsHappeningQueryService.IsWhatsHappeningAlreadyExist(Id);

            // Assert
            result.result.Should().BeFalse();
            result.message.Should().Be(ResponseMessage.STATUS_NODATA);
        }

        /// <summary>Tests if FindWhatsHappeningById returns the correct WhatsHappening entity when it exists.</summary>
        /// <returns>Asserts that the returned entity matches the expected ID and title.</returns>
        [Fact]
        public async Task FindWhatsHappeningById_WhatsHappeningExists_ReturnsWhatsHappening()
        {
            // Arrange
            var Id = 1L;
            var whatsHappeningmock = new entityWhatsHappening
            { ID = 1L, Title = "Test One", IsDeleted = false, CreatedBy = "Admin", CreatedDate = DateTime.UtcNow, UpdatedBy = "admin", UpdatedDate = DateTime.UtcNow };

            // Mock the FindAsync method to return the entityWhatsHappening
            _readOnlyDbContextMock.Setup(db => db.WhatsHappeningsNew.FindAsync(Id))
                .ReturnsAsync(whatsHappeningmock);

            // Act
            var result = await _WhatsHappeningQueryService.FindWhatsHappeningById(Id);

            // Assert
            result.Should().NotBeNull();
            result?.ID.Should().Be(Id);
            result?.ID.Should().Be(1);
            result?.Title.Should().Be("Test One");

        }

        /// <summary> Tests if FindWhatsHappeningById returns null when the WhatsHappening entity does not exist. </summary>
        /// <returns>Asserts that the result is null.</returns>
        [Fact]
        public async Task FindWhatsHappeningById_whatsHappeningNotFound_ReturnsNull()
        {
            // Arrange
            var Id = 1;

            // Mock the FindAsync method to return null (entityWhatsHappening not found)
            _readOnlyDbContextMock.Setup(db => db.WhatsHappeningsNew.FindAsync(Id))
                .ReturnsAsync((entityWhatsHappening)null!);

            // Act
            var result = await _WhatsHappeningQueryService.FindWhatsHappeningById(Id);

            // Assert
            result.Should().BeNull();
        }

        /// <summary> Tests if GetWhatsHappeningList returns the correct list of WhatsHappening entities. </summary>
        /// <returns>Asserts that the result is not null, has a status code of 200, and contains the expected number of entities.</returns>
        [Fact]
        public void GetWhatsHappeningList_ReturnsCorrecWhatsHappeningList()
        {
            // Act
            var result = _WhatsHappeningQueryService.GetWhatsHappeningList();

            // Assert
            result.Should().NotBeNull();
        }

        /// <summary> Tests if GetWhatsHappeningDetail returns the correct detail DTO when the data exists </summary>
        /// <returns>Asserts that the result is not null and matches the expected ID and name.</returns>
        [Fact]
        public async Task GetWhatsHappeningDetail_DataExists_ReturnsDetailDto()
        { // Arrange
            var Id = 1;
            var whatsHappeningmock = new entityWhatsHappening
            { ID = 1, Title = "Test One", IsDeleted = false, CreatedBy = "Admin", CreatedDate = DateTime.UtcNow, UpdatedBy = "admin", UpdatedDate = DateTime.UtcNow };

            var whatsHappeningmockDTO = new WhatsHappeningDetailDto
            { Id = 1, Title = "Test One", Description = "Test", CategoryId = 1, Status = true };

            _readOnlyDbContextMock.Setup(db => db.WhatsHappeningsNew.FindAsync(Id))
                .ReturnsAsync(whatsHappeningmock);

            _mapperMock.Setup(m => m.Map<WhatsHappeningDetailDto>(whatsHappeningmock))
                .Returns(whatsHappeningmockDTO);

            // Act
            var result = await _WhatsHappeningQueryService.GetWhatsHappeningDetail(Id);

            // Assert
            result.Should().NotBeNull();
            result.Result?.Id.Should().Be(Id);
            result.Result?.Id.Should().Be(1);
            result.Result?.Title.Should().Be("Test One");
        }

        /// <summary> Tests if GetWhatsHappeningDetail returns a 404 status code when the WhatsHappening entity is not found. </summary>
        /// <returns>Asserts that the result is not null and has a status code of 404.</returns>
        [Fact]
        public async Task GetWhatsHappeningDetail_whatsHappeningNotFound_ReturnsNull()
        {
            //Arrange
            var Id = 3;

            _readOnlyDbContextMock.Setup(db => db.WhatsHappeningsNew.FindAsync(Id))
                .ReturnsAsync((entityWhatsHappening)null!);

            //Act
            var result = await _WhatsHappeningQueryService.GetWhatsHappeningDetail(Id);

            //Assert
            result.Should().NotBeNull();
            result.StatusCode.Should().Be("404");
        }

        [Fact]
        public async Task GetWhatsHappeningById_ShouldReturnDetailDto_WhenEntityExists()
        {
            // Arrange
            var options = new DbContextOptionsBuilder<ReadOnlyDbContext>()
                .UseInMemoryDatabase(databaseName: "TestDatabase_GetById")
                .Options;

            await using var dbContext = new ReadOnlyDbContext(options);

            var mapperMock = new Mock<IMapper>();

            var testEntity = new Domain.V1.Entities.Marketings.WhatsHappening
            {
                ID = 1,
                Title = "Test Event",
                Description = "Test Description",
                Image = "test.png", // Required property
                CreatedBy = "Admin",
                CreatedDate = DateTime.UtcNow,
                UpdatedDate = DateTime.UtcNow,
                IsDeleted = false
            };

            dbContext.WhatsHappeningsNew.Add(testEntity);
            await dbContext.SaveChangesAsync();

            var expectedDto = new GetWhatsHappeningDetailDto
            {
                Id = testEntity.ID,
                Title = testEntity.Title,
                Description = testEntity.Description
            };

            mapperMock.Setup(m => m.Map<GetWhatsHappeningDetailDto>(It.IsAny<Domain.V1.Entities.Marketings.WhatsHappening>()))
                      .Returns(expectedDto);

            var queryService = new WhatsHappeningQueryService(dbContext, mapperMock.Object);

            // Act
            var result = await queryService.GetWhatsHappeningById(testEntity.ID);

            // Assert
            result.Should().NotBeNull();
            result.Id.Should().Be(expectedDto.Id);
            result.Title.Should().Be(expectedDto.Title);
            result.Description.Should().Be(expectedDto.Description);
        }

        [Fact]
        public void GetWhatsHappeningList_ShouldReturnNotFound_WhenNoRecordsExist()
        {
            // Arrange
            var options = new DbContextOptionsBuilder<ReadOnlyDbContext>()
                .UseInMemoryDatabase(databaseName: "TestDatabase_EmptyList")
                .Options;

            using var dbContext = new ReadOnlyDbContext(options);

            var mapperMock = new Mock<IMapper>(); // Mocking IMapper

            var queryService = new WhatsHappeningQueryService(dbContext, mapperMock.Object);

            // Act
            var result = queryService.GetWhatsHappeningList();

            // Assert
            result.Should().NotBeNull();
        }

        [Fact]
        public void GetWhatsHappeningListByCategories_ShouldReturnFilteredResults()
        {
            // Arrange
            var options = new DbContextOptionsBuilder<ReadOnlyDbContext>()
                .UseInMemoryDatabase(databaseName: "TestDatabase_FilteredList")
                .Options;

            using var dbContext = new ReadOnlyDbContext(options);

            dbContext.Locations.Add(new Location { Id = 1, 
                Name = "Hospital A", 
                Latitude = (decimal) 1.23, 
                Longitude = (decimal) 4.56, 
                ResourceID = "test1",
                CreatedBy = "test",
                UpdatedBy = "test",
                Status = true,
                CreatedDate = DateTime.UtcNow,
            });
            dbContext.LocationAddresses.Add(new LocationAddress { 
                LocationID = 1, 
                City = "City A",
                Use = "",
                CreatedBy = "test",
                UpdatedBy = "test",
                Status = true,
                CreatedDate = DateTime.UtcNow,
                UpdatedDate = DateTime.UtcNow,
                IsDeleted = false
            });

            dbContext.WhatsHappeningsNew.Add(new Domain.V1.Entities.Marketings.WhatsHappening
            {
                ID = 1,
                Title = "Event A",
                URL = "http://event-a.com",
                CategoryID = 2,
                StartDate = DateTime.UtcNow,
                EndDate = DateTime.UtcNow.AddDays(1),
                HospitalID = 1,
                Description = "Description A",
                Image = "image-a.png",
                CreatedBy = "test",
                CreatedDate = DateTime.UtcNow,
                UpdatedDate = DateTime.UtcNow,
                IsDeleted = false
            });

            dbContext.CategoryMasters.Add(new Domain.V1.Entities.Marketings.CategoryMaster
            {
                ID = 2,
                Code = "PAC",
                Definition = "Packages",
                CreatedBy = "test",
                CreatedDate = DateTime.UtcNow,
                UpdatedDate = DateTime.UtcNow,
                IsDeleted = false
            });

            dbContext.SaveChanges();

            var queryService = new WhatsHappeningQueryService(dbContext, Mock.Of<IMapper>());

            // Act
            var result = queryService.getWhatsHappeningListByCategories(CategoryFilter, LocationFilter);

            // Assert
            result.Should().NotBeNull();
            result.Should().HaveCount(1);
            result[0].Id.Should().Be(1);
            result[0].CategoryId.Should().Be(2);
            result[0].LocationId.Should().Be(1);
        }

        [Fact]
        public async Task GetWhatsHappeningsByCategories_ShouldReturnNotFound_WhenNoRecordsExist()
        {
            // Arrange
            var options = new DbContextOptionsBuilder<ReadOnlyDbContext>()
                .UseInMemoryDatabase(databaseName: "TestDatabase_EmptyCategories")
                .Options;

            await using var dbContext = new ReadOnlyDbContext(options);
            var mapperMock = new Mock<IMapper>();

            var queryService = new WhatsHappeningQueryService(dbContext, mapperMock.Object);

            // Act
            var result = await queryService.GetWhatsHappeningsByCategories(NonExistentCategories, NonExistentLocations);

            // Assert
            result.Should().NotBeNull();
            result.HasError.Should().BeFalse();
            result.IsSuccess.Should().BeTrue();
            result.StatusCode.Should().Be(((int)ResponceStatusCode.NotFound).ToString());
            result.Results.Should().BeEmpty();
            result.Message.Should().Be(ResponseMessage.STATUS_NODATA);
        }

        [Fact]
        public async Task GetWhatsHappeningBySearch_ShouldReturnBadRequest_WhenSearchRequestIsNull()
        {
            // Arrange
            var options = new DbContextOptionsBuilder<ReadOnlyDbContext>()
                .UseInMemoryDatabase(databaseName: "TestDatabase_NullSearchRequest")
                .Options;

            await using var dbContext = new ReadOnlyDbContext(options);
            var queryService = new WhatsHappeningQueryService(dbContext, Mock.Of<IMapper>());

            // Act
            var result = await queryService.GetWhatsHappeningBySearch(null!);

            // Assert
            result.Should().NotBeNull();
            result.HasError.Should().BeTrue();
            result.IsSuccess.Should().BeFalse();
            result.StatusCode.Should().Be(((int)ResponceStatusCode.BadRequest).ToString());
            result.Result.Should().BeNull();
            result.Message.Should().Be("Search request cannot be null.");
        }

        [Fact]
        public async Task GetWhatsHappeningBySearch_ShouldMapDataCorrectly()
        {
            // Arrange
            var options = new DbContextOptionsBuilder<ReadOnlyDbContext>()
                .UseInMemoryDatabase(databaseName: "TestDatabase_MappingTest")
                .Options;

            await using var dbContext = new ReadOnlyDbContext(options);
            dbContext.WhatsHappeningsNew.Add(new Domain.V1.Entities.Marketings.WhatsHappening
            {
                ID = 1,
                Title = "Health Conference",
                CategoryID = 1,
                HospitalID = 101,
                StartDate = new DateTime(2025, 5, 10, 0, 0, 0, DateTimeKind.Utc),
                EndDate = new DateTime(2025, 5, 12, 0, 0, 0, DateTimeKind.Utc),
                Status = true,
                CreatedBy = "Seeder",
                UpdatedBy = "Seeder",
                CreatedDate = DateTime.UtcNow,
                UpdatedDate = DateTime.UtcNow,
                IsDeleted = false,
                Description = "Annual medical conference focusing on new advancements.",
                Image = "conference-image.jpg",
                RecordVersion = []
            });
            await dbContext.SaveChangesAsync();

            var queryService = new WhatsHappeningQueryService(dbContext, Mock.Of<IMapper>());

            var searchRequest = new WhatsHappeningSearchFilterDto
            {
                PageNumber = 1,
                PageSize = 10
            };

            // Act
            var result = await queryService.GetWhatsHappeningBySearch(searchRequest);

            // Assert
            result.Should().NotBeNull();
            result.HasError.Should().BeFalse();
            result.IsSuccess.Should().BeTrue();
            result.Result.Should().NotBeNull();
            result.Result?.Data.Should().HaveCount(0);
            var mappedItem = result?.Result?.Data?.FirstOrDefault();
            mappedItem?.Id.Should().Be(1);
            mappedItem?.Title.Should().Be("Health Conference");
            mappedItem?.CategoryId.Should().Be(1);
            mappedItem?.Category.Should().BeNull();
            mappedItem?.LocationId.Should().Be(101);
            mappedItem?.LocationName.Should().BeNull();
            mappedItem?.LocationCity.Should().BeNull();
            mappedItem?.LocationState.Should().BeNull();
            mappedItem?.LocationLatitude.Should().BeNull();
            mappedItem?.LocationLatitude.Should().BeNull();
            mappedItem?.Description.Should().Be("Annual medical conference focusing on new advancements.");
            mappedItem?.ImageUrl.Should().Be("conference-image.jpg");
            mappedItem?.StartDate.Should().Be(new DateTime(2025, 5, 10, 0, 0, 0, DateTimeKind.Utc));
            mappedItem?.EndDate.Should().Be(new DateTime(2025, 5, 12, 0, 0, 0, DateTimeKind.Utc));
            mappedItem?.Status.Should().BeTrue();
            mappedItem?.CreatedBy.Should().Be("Seeder");
            mappedItem?.UpdatedBy.Should().Be("Seeder");
            mappedItem?.RecordVersion.Should().BeNull();
            mappedItem?.UpdatedDate.Should().BeNull();
        }
        //[Fact]
        //public async Task GetCategoryList_ShouldReturnMappedCategories_WhenDataExists()
        //{
        //    // Arrange
        //    var categoryMasters = new List<CategoryMaster>
        //        {
        //            new CategoryMaster
        //            {
        //                ID = 1,
        //                Code = "CAT001",
        //                Definition = "Category 1",
        //                IsDeleted = false, // ✅ Required property
        //                CreatedBy = "Admin", // ✅ Required property
        //                UpdatedBy = "Admin",
        //                UpdatedDate = DateTime.UtcNow,
        //                CreatedDate = DateTime.UtcNow // ✅ Required property
        //            },
        //            new CategoryMaster
        //            {
        //                ID = 2,
        //                Code = "CAT002",
        //                Definition = "Category 2",
        //                IsDeleted = false, // ✅ Required property
        //                CreatedBy = "Admin", // ✅ Required property
        //                CreatedDate = DateTime.UtcNow, // ✅ Required property
        //                UpdatedBy = "Admin",
        //                UpdatedDate = DateTime.UtcNow,
        //            }
        //        };
        //    var mappedCategories = new List<GetCategoryListDto>
        //        {
        //            new GetCategoryListDto
        //            {
        //                ID = 1,
        //                Code = "CAT001",
        //                Definition = "Category 1",
        //                IsDeleted = false, // ✅ Required property
        //                CreatedBy = "Admin", // ✅ Required property
        //                CreatedDate = DateTime.UtcNow, // ✅ Required property
        //                UpdatedBy = "Admin",
        //                UpdatedDate = DateTime.UtcNow,
        //            },
        //            new GetCategoryListDto
        //            {
        //                ID = 2,
        //                Code = "CAT002",
        //                Definition = "Category 2",
        //                IsDeleted = false, // ✅ Required property
        //                CreatedBy = "Admin", // ✅ Required property
        //                CreatedDate = DateTime.UtcNow, // ✅ Required property
        //                UpdatedBy = "Admin",
        //                UpdatedDate = DateTime.UtcNow,
        //            }
        //        };

        //    var categoryMasterQueryable = categoryMasters.AsQueryable();

        //    var mockDbSet = new Mock<DbSet<CategoryMaster>>();
        //    mockDbSet.As<IQueryable<CategoryMaster>>().Setup(m => m.Provider).Returns(categoryMasterQueryable.Provider);
        //    mockDbSet.As<IQueryable<CategoryMaster>>().Setup(m => m.Expression).Returns(categoryMasterQueryable.Expression);
        //    mockDbSet.As<IQueryable<CategoryMaster>>().Setup(m => m.ElementType).Returns(categoryMasterQueryable.ElementType);
        //    mockDbSet.As<IQueryable<CategoryMaster>>().Setup(m => m.GetEnumerator()).Returns(categoryMasterQueryable.GetEnumerator());

        //    _readOnlyDbContextMock.Setup(db => db.CategoryMasters).Returns(mockDbSet.Object);

        //    _mapperMock.Setup(m => m.Map<List<GetCategoryListDto>>(It.IsAny<List<CategoryMaster>>()))
        //               .Returns(mappedCategories);

        //    // Act
        //    var result = await _WhatsHappeningQueryService.GetCategoryList();

        //    // Assert
        //    result.Should().NotBeNull();
        //    result.Should().HaveCount(2);
        //    result.Should().BeEquivalentTo(mappedCategories);
        //}
       
    }
}
