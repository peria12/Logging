﻿using Aurora.AdministrationService.API.Enum;
using Aurora.AdministrationService.API.Models.Dto.WhatHappenings;
using Aurora.AdministrationService.API.Services.Service.WhatsHappenings;
using Aurora.AdministrationService.CrossCutting.CommonModels;
using Aurora.AdministrationService.Infrastructure;
using AutoMapper;
using FluentAssertions;
using Microsoft.EntityFrameworkCore;
using Moq;
using entityWhatsHappening = Aurora.AdministrationService.Domain.V1.Entities.Marketings.WhatsHappening;

namespace Aurora.AdministrationService.Tests.API.Services.Marketing.WhatsHappening
{
    public class WhatsHappeningCommandServiceTests
    {
        private readonly Mock<ReadWriteDbContext> _readWriteDbContextMock;
        private readonly Mock<IMapper> _mapperMock;
        private WhatsHappeningCommandService _whatsHappeningCommandService;
        private readonly Mock<WhatsHappeningQueryService> _whatsHappeningQueryService;

        public WhatsHappeningCommandServiceTests()
        {
            // Initialize the mocks
            _mapperMock = new Mock<IMapper>();
            _readWriteDbContextMock = new Mock<ReadWriteDbContext>();
            _whatsHappeningQueryService = new Mock<WhatsHappeningQueryService>();


            // Setup in-memory ready only database for testing
            DbContextOptions<ReadWriteDbContext> options = new DbContextOptionsBuilder<ReadWriteDbContext>()
              .UseInMemoryDatabase(databaseName: "AdminWhatsHappeningTestDB").Options;

            _readWriteDbContextMock = new(options);

            // Initialize the service being tested
            _whatsHappeningCommandService = new WhatsHappeningCommandService(_readWriteDbContextMock.Object, _mapperMock.Object);
        }

        /// <summary> Tests that CreateWhatsHappeningAsync returns true when a new WhatsHappening entity is created successfully. </summary>
        /// <returns> Asserts that the result is <see langword="true"/> and verifies that the entity was added to the DbContext once. </returns>
        [Fact]
        public async Task CreateWhatsHappeningAsync_ShouldReturnTrue_WhenWhatsHappeningIsCreatedSuccessfully()
        {
            // Arrange
            var newWhatsHappening = new CreateWhatsHappeningRequest
            {
                Id = 1,
                CategoryId = 1,
                Description = "test",
                StartDate = DateTime.UtcNow,
                EndDate = DateTime.UtcNow.AddDays(3),
                Status = true,
                Title = "test",
                URL = "test"
            };

            // Mock AutoMapper to return a WhatsHappening entity
             var whatsHappeningEntity = new entityWhatsHappening
            {
                ID = 1,
                CategoryID = 1,
                Description = "test",
                StartDate = DateTime.UtcNow,
                EndDate = DateTime.UtcNow.AddDays(3),
                Status = true,
                Title = "test",
                URL = "test",
                Image = "test.png",
                IsDeleted = false,
                CreatedBy = "Admin",
                CreatedDate = DateTime.UtcNow,
                UpdatedBy = "Admin",  // Adding the missing property
                UpdatedDate = DateTime.UtcNow,// Assuming UpdatedDate is required as well
            };

            // Mock AutoMapper to return the WhatsHappening entity
            _mapperMock.Setup(m => m.Map<entityWhatsHappening>(newWhatsHappening)).Returns(whatsHappeningEntity);

            // Mock DbContext to simulate saving the entity without actually hitting the database
            _readWriteDbContextMock.Setup(db => db.WhatsHappeningsNew.Add(It.IsAny<entityWhatsHappening>()));

            // Act
            var result = await _whatsHappeningCommandService.CreateWhatsHappeningAsync(newWhatsHappening);

            // Assert
            Assert.True(result.IsSuccess);
            _readWriteDbContextMock.Verify(db => db.WhatsHappeningsNew.Add(It.Is<entityWhatsHappening>(l => l.Title == "test")), Times.Once);
        }

        /// <summary> Tests that CreateWhatsHappeningAsync returns false when an exception occurs during the creation process.</summary>
        /// <returns> Asserts that the result is <see langword="false"/>. </returns>
        [Fact]
        public async Task CreateWhatsHappeningAsync_ShouldReturnFalse_WhenExceptionOccurs()
        {
            // Arrange
            var newWhatsHappening = new CreateWhatsHappeningRequest
            {
                Id = 1,
                //CategoryID = 1,
                Description = "test",
                StartDate = DateTime.UtcNow,
                EndDate = DateTime.UtcNow.AddDays(3),
                Status = true,
                Title = "test",
                URL = "test"
            };

            // Mock AutoMapper to return a WhatsHappening entity
             var whatsHappeningEntity = new entityWhatsHappening
            {
                ID = 1,
                CategoryID = 1,
                Description = "test",
                StartDate = DateTime.UtcNow,
                EndDate = DateTime.UtcNow.AddDays(3),
                Status = true,
                Title = "test",
                URL = "test",
                Image = "test.png",
                IsDeleted = false,
                CreatedBy = "Admin",
                CreatedDate = DateTime.UtcNow,
                UpdatedBy = "Admin",  // Adding the missing property
                UpdatedDate = DateTime.UtcNow,// Assuming UpdatedDate is required as well
            };

            //Setup
            _mapperMock.Setup(m => m.Map<entityWhatsHappening>(newWhatsHappening)).Returns(whatsHappeningEntity);

            // Act
            var result = await _whatsHappeningCommandService.CreateWhatsHappeningAsync(newWhatsHappening);

            // Assert
            Assert.False(result.IsSuccess);
        }

        /// <summary> Tests that UpdateWhatsHappeningAsync returns true when an existing WhatsHappening entity is updated successfully. </summary>
        /// <returns> Asserts that the result is <see langword="true"/> </returns>
        [Fact]
        public async Task Test_UpdateWhatsHappening_Returns_Success()
        {
            //Arrange
            DbContextOptions<ReadWriteDbContext> options = new DbContextOptionsBuilder<ReadWriteDbContext>()
               .UseInMemoryDatabase(databaseName: "UpdateWhatsHappening").Options;

            byte[] concurrencyToken = new byte[8] { byte.MinValue, byte.MinValue, byte.MinValue, byte.MinValue, byte.MinValue, byte.MinValue, byte.MinValue, byte.MaxValue };
            var whatsHappening = new entityWhatsHappening
            {
                ID = 1,
                CategoryID = 1,
                Description = "test",
                StartDate = DateTime.UtcNow,
                EndDate = DateTime.UtcNow.AddDays(3),
                Status = true,
                Title = "test",
                URL = "test",
                Image = "test.png",
                IsDeleted = false,
                CreatedBy = "Admin",
                CreatedDate = DateTime.UtcNow,
                UpdatedBy = "Admin",  // Adding the missing property
                UpdatedDate = DateTime.UtcNow,// Assuming UpdatedDate is required as well
                RecordVersion = concurrencyToken
            };

            //Arrange
            using ReadWriteDbContext dbContext = new(options);
            dbContext.WhatsHappeningsNew.Add(whatsHappening);
            await dbContext.SaveChangesAsync();

            UpdateWhatsHappeningRequest updateModel = new UpdateWhatsHappeningRequest
            {
                Id = 1,
                RecordVersion = Array.Empty<byte>(),
                Description = "test",
                StartDate = DateTime.UtcNow,
                EndDate = DateTime.UtcNow.AddDays(3),
                Status = true,
                Title = "test",
                URL = "test",
                CategoryId = 1,
                Image = "test.png",
                UpdatedBy = "Admin"
            };

             updateModel.RecordVersion = whatsHappening.RecordVersion;
            _whatsHappeningCommandService = new WhatsHappeningCommandService(dbContext, _mapperMock.Object);

            // Act
            GenericResponse<string> response = await _whatsHappeningCommandService.UpdateWhatsHappeningAsync(updateModel, whatsHappening);
            Assert.True(response.IsSuccess);
        }

        /// <summary> Tests the deletion functionality of the WhatsHappeningCommandService. </summary>
        /// <remarks>
        /// This test verifies that a WhatsHappening entity can be successfully deleted.
        /// It sets up an in-memory database, adds a sample entity, and then attempts to delete it.
        /// The test passes if the deletion is successful.
        /// </remarks>
        [Fact]
        public async Task Test_DeleteWhatsHappening_Returns_Success()
        {
            //Arrange
            DbContextOptions<ReadWriteDbContext> options = new DbContextOptionsBuilder<ReadWriteDbContext>()
               .UseInMemoryDatabase(databaseName: "DeleteWhatsHappening").Options;

            byte[] concurrencyToken = new byte[8] { byte.MinValue, byte.MinValue, byte.MinValue, byte.MinValue, byte.MinValue, byte.MinValue, byte.MinValue, byte.MaxValue };
            var whatsHappening = new entityWhatsHappening
            {
                ID = 1,
                Image = "test.png",
                CategoryID = 1,
                Description = "test",
                StartDate = DateTime.UtcNow,
                EndDate = DateTime.UtcNow.AddDays(3),
                Status = true,
                Title = "test",
                URL = "test",
                IsDeleted = false,
                CreatedBy = "Admin",
                CreatedDate = DateTime.UtcNow,
                UpdatedBy = "Admin",  // Adding the missing property
                UpdatedDate = DateTime.UtcNow,// Assuming UpdatedDate is required as well
                RecordVersion = concurrencyToken
            };

            using ReadWriteDbContext dbContext = new(options);
            dbContext.WhatsHappeningsNew.Add(whatsHappening);
            await dbContext.SaveChangesAsync();

            _whatsHappeningCommandService = new WhatsHappeningCommandService(dbContext, _mapperMock.Object);

            // Act
            var result = await _whatsHappeningCommandService.DeleteWhatsHappeningByIdAsync(concurrencyToken, whatsHappening.ID);

            // Assert
            result.Should().NotBeNull();
            result.IsSuccess.Should().BeTrue();
        }

        [Fact]
        public async Task DeleteWhatsHappeningByIdAsync_ShouldReturnNotFound_WhenEntityDoesNotExist()
        {
            // Arrange
            var options = new DbContextOptionsBuilder<ReadWriteDbContext>()
                .UseInMemoryDatabase(databaseName: "TestDatabase")
                .Options;

            await using var dbContext = new ReadWriteDbContext(options);

            _whatsHappeningCommandService = new WhatsHappeningCommandService(dbContext, _mapperMock.Object);

            byte[] concurrencyToken = new byte[8] { byte.MinValue, byte.MinValue, byte.MinValue, byte.MinValue, byte.MinValue, byte.MinValue, byte.MinValue, byte.MaxValue };
            long nonExistentId = 999; // ID that doesn't exist in DB

            // Act
            var result = await _whatsHappeningCommandService.DeleteWhatsHappeningByIdAsync(concurrencyToken, nonExistentId);

            // Assert
            result.Should().NotBeNull();
            result.IsSuccess.Should().BeTrue();
            result.HasError.Should().BeFalse();
            result.StatusCode.Should().Be(((int)ResponceStatusCode.NotFound).ToString());
            result.Message.Should().Be(ResponseMessage.STATUS_NODATA);
        }

    }
}
