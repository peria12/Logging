﻿using Aurora.AdministrationService.API.Models.RequestModels.Logos;
using Aurora.AdministrationService.API.Services.Service.Logos;
using Aurora.AdministrationService.CrossCutting.Constants;
using Aurora.AdministrationService.Infrastructure;
using AutoMapper;
using FluentAssertions;
using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.ChangeTracking;
using Moq;

namespace Aurora.AdministrationService.Tests.API.Services.Logos
{
    public class LogoCommandServiceTests
    {
        private readonly ReadWriteDbContext _dbContext;
        private readonly Mock<IMapper> _mockMapper;
        private readonly LogoCommandService _logoCommandService;

        public LogoCommandServiceTests()
        {
            var options = new DbContextOptionsBuilder<ReadWriteDbContext>()
                .UseInMemoryDatabase(databaseName: Guid.NewGuid().ToString()) // Create a unique database per test
                .Options;

            _dbContext = new ReadWriteDbContext(options);
            _mockMapper = new Mock<IMapper>();
            _logoCommandService = new LogoCommandService(_dbContext, _mockMapper.Object);
        }

        [Fact]
        public async Task CreateLogoImageAsync_ReturnsTrue_WhenLogoIsCreatedSuccessfully()
        {
            // Arrange
            var request = new AddLogoImageRequest
            {
                OrganizationId = 1,
                ImageURL = "logo.png",
                Status = true
            };
            var logoEntity = new Domain.Old.Entities.Logo
            {
                Id = 1,
                OrganizationId = 1,
                CreatedBy = "Admin",
                CreatedDate = DateTime.UtcNow,
                ImageUrl = "logo.png",
                IsDeleted = false
            };

            _mockMapper.Setup(m => m.Map<Domain.Old.Entities.Logo>(request)).Returns(logoEntity);

            // Act
            var result = await _logoCommandService.CreateLogoImageAsync(request);

            // Assert
            result.Should().BeTrue();
            _dbContext.Logos.Should().Contain(logo => logo.ImageUrl == "logo.png");
        }

        [Fact]
        public async Task CreateLogoImageAsync_ReturnsFalse_WhenExceptionOccurs()
        {
            // Arrange
            var request = new AddLogoImageRequest
            {
                OrganizationId = 1,
                ImageURL = "logo.png",
                Status = true
            };
            _mockMapper.Setup(m => m.Map<Domain.Old.Entities.Logo>(request)).Throws(new Exception("Database error"));

            // Act
            var result = await _logoCommandService.CreateLogoImageAsync(request);

            // Assert
            result.Should().BeFalse();
        }

        [Fact]
        public async Task UpdateLogoImageAsync_ReturnsTrue_WhenUpdateIsSuccessful()
        {
            // Arrange
            var logo = new Domain.Old.Entities.Logo
            {
                Id = 1,
                OrganizationId = 1,
                CreatedBy = "Admin",
                CreatedDate = DateTime.UtcNow,
                UpdatedBy = "Admin",
                ImageUrl = "old.png",
                RecordVersion = new byte[] { 1, 2, 3 },
                IsDeleted = false
            };
            _dbContext.Logos.Add(logo);
            await _dbContext.SaveChangesAsync();

            var updateRequest = new UpdateLogoImageRequest
            {
                OrganizationId = 1,
                Status = true,
                ImageURL = "new.png",
                RecordVersion = new byte[] { 1, 2, 3 }
            };

            _mockMapper.Setup(m => m.Map(updateRequest, logo));

            // Act
            var result = await _logoCommandService.UpdateLogoImageAsync(logo, updateRequest);

            // Assert
            result.Should().BeTrue();
            logo.ImageUrl.Should().Be("old.png"); // AutoMapper is mocked, so no real change happens
        }

        [Fact]
        public async Task UpdateLogoImageAsync_ThrowsArgumentNullException_WhenUpdateRequestIsNull()
        {
            // Arrange
            var logo = new Domain.Old.Entities.Logo { Id = 1, OrganizationId = 1, CreatedBy = "Admin", CreatedDate = DateTime.UtcNow, ImageUrl = "old.png", IsDeleted = false };

            // Act
            Func<Task> act = async () => await _logoCommandService.UpdateLogoImageAsync(logo, null!);

            // Assert
            await act.Should().ThrowAsync<ArgumentNullException>().WithMessage("*updateLogoImage*");
        }

        [Fact]
        public async Task UpdateLogoImageAsync_ThrowsArgumentNullException_WhenLogoIsNull()
        {
            // Arrange
            var updateRequest = new UpdateLogoImageRequest
            {
                OrganizationId = 1,
                Status = true,
                ImageURL = "new.png",
                RecordVersion = new byte[] { 1, 2, 3 }
            };

            // Act
            Func<Task> act = async () => await _logoCommandService.UpdateLogoImageAsync(null!, updateRequest);

            // Assert
            await act.Should().ThrowAsync<ArgumentNullException>().WithMessage("*logo*");
        }  

        [Fact]
        public async Task DeleteLogoImageByIdAsync_ReturnsTrue_WhenSoftDeleteIsSuccessful()
        {
            // Arrange
            var logo = new Domain.Old.Entities.Logo
            {
                Id = 1,
                OrganizationId = 1,
                CreatedBy = "Admin",
                CreatedDate = DateTime.UtcNow,
                UpdatedBy = "Admin",
                RecordVersion = new byte[] { 1, 2, 3 },
                IsDeleted = false
            };
            _dbContext.Logos.Add(logo);
            await _dbContext.SaveChangesAsync();

            var recordVersion = new byte[] { 1, 2, 3 };

            // Act
            var result = await _logoCommandService.DeleteLogoImageByIdAsync(recordVersion, logo);

            // Assert
            result.Should().BeTrue();
            logo.IsDeleted.Should().BeTrue();
            logo.UpdatedDate.Should().BeCloseTo(DateTime.UtcNow, TimeSpan.FromSeconds(1));
        }

        [Fact]
        public async Task DeleteLogoImageByIdAsync_ThrowsArgumentNullException_WhenLogoIsNull()
        {
            // Arrange
            var recordVersion = new byte[] { 1, 2, 3 };

            // Act
            Func<Task> act = async () => await _logoCommandService.DeleteLogoImageByIdAsync(recordVersion, null!);

            // Assert
            await act.Should().ThrowAsync<ArgumentNullException>().WithMessage("*existingLogo*");
        }

        [Fact]
        public async Task DeleteLogoImageByIdAsync_ReturnsFalse_When_ConcurrencyExceptionOccurs()
        {
            // Arrange: Setup in-memory database
            var options = new DbContextOptionsBuilder<ReadWriteDbContext>()
                .UseInMemoryDatabase(databaseName: "TestDb")
                .Options;

            using var dbContext = new ReadWriteDbContext(options);

            var logo = new Domain.Old.Entities.Logo
            {
                Id = 2,
                OrganizationId = 1,
                CreatedBy = "Admin",
                CreatedDate = DateTime.UtcNow,
                UpdatedBy = "Admin",
                RecordVersion = new byte[] { 4, 5, 6 },
                IsDeleted = false
            };

            dbContext.Logos.Add(logo);
            await dbContext.SaveChangesAsync();

            var recordVersion = new byte[] { 4, 5, 6 };

            // Simulate concurrency issue by setting the OriginalValue different from the record version
            dbContext.Entry(logo).Property(AppConstants.RecordVersion).OriginalValue = new byte[] { 9, 9, 9 };

            // Mock IMapper (not used in this method, but required by constructor)
            var mockMapper = new Mock<IMapper>();

            var logoCommandService = new LogoCommandService(dbContext, mockMapper.Object);

            // Act
            var result = await logoCommandService.DeleteLogoImageByIdAsync(recordVersion, logo);

            // Assert
            result.Should().BeTrue();
        }


        [Fact]
        public async Task DeleteLogoImageByIdAsync_ReturnsFalse_When_NoRowsAffected()
        {
            // Arrange
            var logo = new Domain.Old.Entities.Logo
            {
                Id = 3,
                OrganizationId = 1,
                CreatedBy = "Admin",
                CreatedDate = DateTime.UtcNow,
                UpdatedBy = "Admin",
                RecordVersion = new byte[] { 7, 8, 9 },
                IsDeleted = false
            };

            var recordVersion = new byte[] { 7, 8, 9 };

            // Act
            var result = await _logoCommandService.DeleteLogoImageByIdAsync(recordVersion, logo);

            // Assert
            result.Should().BeFalse();
        }
    }
}
