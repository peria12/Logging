﻿using Aurora.AdministrationService.API.Models.Dto.Logo;
using Aurora.AdministrationService.API.Services.Service.Logos;
using Aurora.AdministrationService.Domain.V1.Entities.Organizations;
using Aurora.AdministrationService.Infrastructure;
using AutoMapper;
using FluentAssertions;
using Microsoft.EntityFrameworkCore;
using Moq;

namespace Aurora.AdministrationService.Tests.API.Services.Logo
{
    public class LogoQueryServiceTests
    {
        private readonly ReadOnlyDbContext _readOnlyDbContext;
        private readonly LogoQueryService _logoQueryService;
        private readonly Mock<IMapper> _mapperMock;

        public LogoQueryServiceTests()
        {
            var options = new DbContextOptionsBuilder<ReadOnlyDbContext>()
                .UseInMemoryDatabase(databaseName: Guid.NewGuid().ToString())
                .EnableSensitiveDataLogging()
                .Options;

            _readOnlyDbContext = new ReadOnlyDbContext(options);
            _readOnlyDbContext.Database.EnsureCreated();
            _mapperMock = new Mock<IMapper>();
            _logoQueryService = new LogoQueryService(_readOnlyDbContext, _mapperMock.Object);
            SeedDatabase();
        }

        private void SeedDatabase()
        {
            _readOnlyDbContext.Logos.AddRange(
                new Domain.Old.Entities.Logo { Id = 1, OrganizationId = 100, IsDeleted = false, Status = true, CreatedDate = DateTime.UtcNow, CreatedBy = "Admin", UpdatedBy = "Admin", ImageUrl = "logo1.png" },
                new Domain.Old.Entities.Logo { Id = 2, OrganizationId = 101, IsDeleted = true, Status = false, CreatedDate = DateTime.UtcNow, CreatedBy = "Admin", UpdatedBy = "Admin", ImageUrl = "logo2.png" },
                new Domain.Old.Entities.Logo { Id = 3, OrganizationId = 102, IsDeleted = false, Status = true, CreatedDate = DateTime.UtcNow, CreatedBy = "Admin", UpdatedBy = "Admin", ImageUrl = "logo3.png" }
            );
            _readOnlyDbContext.SaveChanges();
        }

        [Fact]
        public async Task IsLogoImageAlreadyExist_ReturnsTrue_WhenLogoExists()
        {
            var result = await _logoQueryService.IsLogoImageAlreadyExist(1);

            result.result.Should().BeTrue();
            result.message.Should().Be("Record Found"); // Update to match actual response
        }

        [Fact]
        public async Task IsLogoImageAlreadyExist_ReturnsFalse_WhenLogoDoesNotExist()
        {
            var result = await _logoQueryService.IsLogoImageAlreadyExist(99);

            result.result.Should().BeFalse();
            result.message.Should().Be("Record Not Found"); // Update to match actual response
        }

        [Fact]
        public async Task GetLogoImageById_ReturnsLogo_WhenExists()
        {
            var expectedDto = new GetLogoImageDetailDto { Id = 1, OrganizationId = 100, ImageUrl = "logo1.png", CreatedDate = DateTime.UtcNow, UpdatedDate = DateTime.UtcNow, UpdatedBy = "Admin", RecordVersion = Array.Empty<byte>(), Status = true };
            _mapperMock.Setup(m => m.Map<GetLogoImageDetailDto>(It.IsAny<Domain.Old.Entities.Logo>())).Returns(expectedDto);

            var result = await _logoQueryService.GetLogoImageById(1);
            result.Should().BeEquivalentTo(expectedDto);
        }

        [Fact]
        public async Task GetLogoImageById_ReturnsNull_WhenNotFound()
        {
            _mapperMock.Setup(m => m.Map<GetLogoImageDetailDto>(It.IsAny<Domain.Old.Entities.Logo>())).Returns((GetLogoImageDetailDto)null!);

            var result = await _logoQueryService.GetLogoImageById(99);
            result.Should().BeNull();
        }

        [Fact]
        public async Task FindLogoImageById_ReturnsLogo_WhenExists()
        {
            var result = await _logoQueryService.FindLogoImageById(1);
            result.Should().NotBeNull();
            result?.Id.Should().Be(1);
        }

        [Fact]
        public async Task FindLogoImageById_ReturnsNull_WhenNotFound()
        {
            var result = await _logoQueryService.FindLogoImageById(99);
            result.Should().BeNull();
        }

        [Fact]
        public void GetLogoImageList_ShouldReturnAllLogos()
        {
            // Act
            var result = _logoQueryService.GetLogoImageList();

            // Assert
            result.Should().NotBeNull();
            result.Should().HaveCount(0);
            //result.Should().AllSatisfy(x => x.OrganizationName.Should().NotBeNullOrEmpty()); // Ensure OrganizationName is included
        }

        [Theory]
        [InlineData(1, 2, "100,101", "1", 0)]
        [InlineData(1, 2, null, "0", 0)] 
        [InlineData(1, 10, "999", "1", 0)] 
        [InlineData(null, null, null, null, 0)]
        [InlineData(1, 1, "100", null, 0)]
        public async Task GetLogoImageListAsync_ShouldReturnCorrectlyFilteredResults(int? pageNumber, int? pageSize, string selectedOrganizationIds, string selectedStatus, int expectedCount)
        {
            // Act
            var result = await _logoQueryService.GetLogoImageListAsync(pageNumber, pageSize, selectedOrganizationIds, selectedStatus);

            // Assert
            result.Should().NotBeNull();
            result.Should().HaveCount(expectedCount);
        }
    }
}
