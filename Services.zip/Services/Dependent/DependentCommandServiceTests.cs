﻿using System.Globalization;
using Aurora.AdministrationService.API.Enum;
using Aurora.AdministrationService.API.Models.Dto.Dependent;
using Aurora.AdministrationService.API.Models.Dto.Dependents;
using Aurora.AdministrationService.API.Models.Dto.Users;
using Aurora.AdministrationService.API.Models.ResponseModels.Dependent;
using Aurora.AdministrationService.API.Resources;
using Aurora.AdministrationService.API.Services.IService.Dependent;
using Aurora.AdministrationService.API.Services.IService.Users;
using Aurora.AdministrationService.API.Services.IService.Users.UserIdentifiers;
using Aurora.AdministrationService.API.Services.IService.Users.UserNames;
using Aurora.AdministrationService.API.Services.IService.Users.UserTelecoms;
using Aurora.AdministrationService.API.Services.Service.Dependent;
using Aurora.AdministrationService.API.Services.Service.Users;
using Aurora.AdministrationService.CrossCutting.CommonModels;
using Aurora.AdministrationService.CrossCutting.Constants;
using Aurora.AdministrationService.Domain.V1.Entities.Users;
using Aurora.AdministrationService.Infrastructure;
using FluentAssertions;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using Microsoft.Graph;
using Microsoft.VisualBasic;
using Microsoft.VisualStudio.TestPlatform.CommunicationUtilities.Resources;
using Moq;
using ResponseStatus = Aurora.AdministrationService.CrossCutting.CommonModels.ResponseStatus;

namespace Aurora.AdministrationService.Tests.API.Services.Dependent;

public class DependentCommandServiceTests : TestsBase<DependentCommandService>
{
    private readonly Mock<IDependentQueryService> _mockQueryService;
    private readonly Mock<IUserCommandService> _mockUserCommandService;
    private readonly Mock<IUserQueryService> _mockUserQueryService;
    private readonly Mock<IUserTelecomQueryService> _mockTelecomQueryService;
    private readonly Mock<IUserIdentifierQueryService> _mockUserIdentifierQueryService;
    private readonly DependentCommandService _service;
    private readonly ReadWriteDbContext readWriteDbContext;

    public DependentCommandServiceTests()
    {
        _mockQueryService = new Mock<IDependentQueryService>();
        _mockUserCommandService = new Mock<IUserCommandService>();
        _mockUserQueryService = new Mock<IUserQueryService>();
        _mockQueryService = new Mock<IDependentQueryService>();
        _mockTelecomQueryService = new Mock<IUserTelecomQueryService>();
        _mockUserIdentifierQueryService = new Mock<IUserIdentifierQueryService>();
        readWriteDbContext = GetReadWriteDBContextInMemory();
        _service = new DependentCommandService
                          (
                            readWriteDbContext
                          , _mockMapper.Object
                          , _mockQueryService.Object
                          , _mockUserQueryService.Object
                          , _mockUserCommandService.Object
                          , _mockTelecomQueryService.Object
                          , _mockUserIdentifierQueryService.Object

                          );
    }

    [Fact]
    public async Task DeactivateUserDependent_ShouldReturnExpectedResult()
    {
        // Arrange
        Domain.V1.Entities.Dependent.Dependent dependent = new()
        {
            CreatedDate = DateTime.UtcNow,
            DependentUserID = 123,
            ID = 132,
            IsDeleted = false,
            Relationship = "test",
            Status = true,
            UserID = 123,
            RecordVersion = [1]
        };

        readWriteDbContext.Dependents.Add(dependent);
        await readWriteDbContext.SaveChangesAsync();

        // Act
        bool result = await _service.DeactivateUserDependent(dependent);

        // Assert
        Assert.True(result);
    }

    public class AddDependentTestCase
    {
        public string RelationshipCategory { get; set; }
        public string DOB { get; set; }
        public bool EmailExists { get; set; }
        public bool PhoneExists { get; set; }
        public string Email { get; set; }
        public string PhoneNumber { get; set; }
        public bool DependentAlreadyExists { get; set; }
        public string ExpectedStatus { get; set; }
        public bool IsByPassport { get; set; }
    }

    public static IEnumerable<object[]> GetAddDependentTestData()
    {
        yield return new object[] {
        new AddDependentTestCase {
            RelationshipCategory = "Adult",
            DOB = "2010-01-01",
            EmailExists = false,
            PhoneExists = false,
            Email = "wrongage1@example.com",
            PhoneNumber = "1000000001",
            DependentAlreadyExists = false,
            ExpectedStatus = ResponseStatus.STATUS_Conflict,
            IsByPassport = false
        }
    };

        yield return new object[] {
        new AddDependentTestCase {
            RelationshipCategory = "Adult",
            DOB = "1990-01-01",
            EmailExists = true,
            PhoneExists = false,
            Email = "existing1@example.com",
            PhoneNumber = "1000000002",
            DependentAlreadyExists = false,
            ExpectedStatus = ResponseStatus.STATUS_BadRequest,
            IsByPassport = false
        }
    };

        yield return new object[] {
        new AddDependentTestCase {
            RelationshipCategory = "Adult",
            DOB = "1990-01-01",
            EmailExists = false,
            PhoneExists = true,
            Email = "new2@example.com",
            PhoneNumber = "1000000003",
            DependentAlreadyExists = false,
            ExpectedStatus = ResponseStatus.STATUS_BadRequest,
            IsByPassport = false
        }
    };

        yield return new object[] {
        new AddDependentTestCase {
            RelationshipCategory = "Child",
            DOB = "2020-01-01",
            EmailExists = false,
            PhoneExists = false,
            Email = "child@example.com",
            PhoneNumber = "1000000004",
            DependentAlreadyExists = false,
            ExpectedStatus = ResponseStatus.STATUS_SUCCESS,
            IsByPassport = false
        }
    };

        yield return new object[] {
        new AddDependentTestCase {
            RelationshipCategory = "Child",
            DOB = "2000-01-01",
            EmailExists = false,
            PhoneExists = false,
            Email = "tooOldChild@example.com",
            PhoneNumber = "1000000005",
            DependentAlreadyExists = false,
            ExpectedStatus = ResponseStatus.STATUS_Conflict,
            IsByPassport = false
        }
    };

        yield return new object[] {
        new AddDependentTestCase {
            RelationshipCategory = "Child",
            DOB = "2015-01-01",
            EmailExists = false,
            PhoneExists = false,
            Email = "existingdependent@example.com",
            PhoneNumber = "1000000006",
            DependentAlreadyExists = true,
            ExpectedStatus = ResponseStatus.STATUS_BadRequest,
            IsByPassport = false
        }
    };

        yield return new object[] {
        new AddDependentTestCase {
            RelationshipCategory = "Child",
            DOB = "2015-01-01",
            EmailExists = false,
            PhoneExists = false,
            Email = "existingdependent@example.com",
            PhoneNumber = "1000000006",
            DependentAlreadyExists = true,
            ExpectedStatus = ResponseStatus.STATUS_BadRequest,
            IsByPassport = true
        }
    };
    }

    [Theory]
    [MemberData(nameof(GetAddDependentTestData))]
    public async Task AddDependentOthersAsync_ShouldReturnExpectedResponse(AddDependentTestCase testCase)
    {
        const string dateFormat = "yyyy-MM-dd";
        var userId = "123";
        var parsedUserId = long.Parse(userId);
        var dependentUserId = 123;

        if (testCase.DependentAlreadyExists)
        {
            var existingDependent = new Domain.V1.Entities.Dependent.Dependent
            {
                ID = 999,
                UserID = parsedUserId,
                DependentUserID = dependentUserId,
                Status = true,
                Relationship = "Test",
                RelationshipCategory = testCase.RelationshipCategory,
                CreatedDate = DateTime.UtcNow,
                CreatedBy = "test",
                UpdatedDate = DateTime.UtcNow,
                UpdatedBy = "test",
                IsDeleted = false,
                RecordVersion = [1]
            };

            readWriteDbContext.Dependents.Add(existingDependent);
            await readWriteDbContext.SaveChangesAsync();

            _mockQueryService
                .Setup(q => q.GetChildAndOtherByUhidAsync(parsedUserId, dependentUserId))
                .ReturnsAsync(existingDependent);
        }
        else
        {
            _mockQueryService
                .Setup(q => q.GetChildAndOtherByUhidAsync(It.IsAny<long>(), It.IsAny<int>()))
                .ReturnsAsync((Domain.V1.Entities.Dependent.Dependent)null);
        }

        var request = new DependentOtherRequestDto
        {
            RelationshipCategory = testCase.RelationshipCategory,
            DateOfBirth = DateTime.ParseExact(testCase.DOB, dateFormat, CultureInfo.InvariantCulture),
            Email = testCase.Email,
            PhoneNumber = testCase.PhoneNumber,
            Country = "MYS",
            Gender = "Male",
            IdentifierType = "test",
            IdentifierNumber = "123",
            IdentifierPassport = "test",
            Name = "test",
            Nationality = "MYS",
            PassportExpiryDate = DateTime.Now.AddYears(1),
            PassportIssueCountry = "MYS",
            PhoneCountryCode = "91",
            Relationship = "Test"
        };

        var user = new Domain.V1.Entities.Users.User
        {
            BioAuthenticationEnabled = true,
            CreatedBy = "test",
            CreatedDate = DateTime.Now,
            IsDeleted = false,
            IsTempAccount = true,
            NotificationsEnabled = true,
            SOSButtonEnabled = true,
            Status = true,
            UpdatedBy = "test",
            UserName = "123",
            UserType = "test",
            RecordVersion = [1]
        };

        var patientSignUpResponseDto = new PatientSignUpResponseDto { UserId = "123", UserUniqueId = "123" };

        _mockQueryService.Setup(q => q.GetUserByUserIdAsync(userId)).ReturnsAsync(user);
        _mockMapper.Setup(m => m.Map<Domain.V1.Entities.Users.User>(It.IsAny<DependentOtherRequestDto>())).Returns(user);
        _mockTelecomQueryService.Setup(u => u.IsUserPhoneNumberAlreadyExist(It.IsAny<string>())).Returns(testCase.PhoneExists);
        _mockTelecomQueryService.Setup(u => u.IsUserEmailIdAlreadyExist(It.IsAny<string>())).Returns(testCase.EmailExists);
        _mockUserCommandService.Setup(u => u.NewPatientSignup(It.IsAny<PatientRegistrationRequest>())).ReturnsAsync(patientSignUpResponseDto);

        if (testCase.IsByPassport)
        {
            _mockUserIdentifierQueryService
                .Setup(x => x.IsUserIdentifierAlreadyExist(It.IsAny<string>()))
                .Returns((true, 123));
        }
        else
        {
            _mockUserIdentifierQueryService
                .Setup(x => x.IsUserIdentifierAlreadyExist(It.IsAny<string>(), It.IsAny<string>()))
                .Returns((true, 123));
        }

        // Act
        var result = await _service.AddDependentOthersAsync(request, userId, "region", "idType");

        // Assert using FluentAssertions
        result.StatusCode.Should().Be(testCase.ExpectedStatus);
    }




    #region Update Dependent Command Service Test Cases

    /// <summary>
    /// Test when parent user is not found
    /// </summary>
    [Fact]
    public async Task UpdateDependentOthersAsync_ShouldReturnNotFound_WhenParentUserDoesNotExist()
    {
        // Arrange
        var request = CreateMockUpdateDependentRequest();

        _mockQueryService.Setup(x => x.GetUserByUserIdAsync(It.IsAny<string>()))
                         .ReturnsAsync((Domain.V1.Entities.Users.User)null);

        // Act
        var result = await _service.UpdateDependentOthersAsync(1, request);

        // Assert
        result.Should().NotBeNull();
        result.HasError.Should().BeTrue();
        result.StatusCode.Should().Be(ResponseStatus.STATUS_NotFound);
        result.Message.Should().Be(Resource.UserNotFound);
    }

    /// <summary>
    /// Test when new dependent user is not found
    /// </summary>
    [Fact]
    public async Task UpdateDependentOthersAsync_ShouldReturnNotFound_WhenNewUserDoesNotExist()
    {
        // Arrange
        var request = CreateMockUpdateDependentRequest();

        _mockQueryService.Setup(x => x.GetUserByUserIdAsync(request.Id.ToString()))
                         .ReturnsAsync((Domain.V1.Entities.Users.User)null);

        // Act
        var result = await _service.UpdateDependentOthersAsync(1, request);

        // Assert
        result.Should().NotBeNull();
        result.HasError.Should().BeTrue();
        result.StatusCode.Should().Be(ResponseStatus.STATUS_NotFound);
        result.Message.Should().Be(Resource.UserNotFound);
    }

    /// <summary>
    /// Test when age validation fails for child
    /// </summary>
    [Fact]
    public async Task UpdateDependentOthersAsync_ShouldReturnConflict_WhenAgeValidationFailsForChild()
    {
        // Arrange
        var request = CreateMockUpdateDependentRequest();
        request.RelationshipCategory = "Child";
        request.DateOfBirth = DateTime.UtcNow.AddYears(-25); // Age less than 1 year, invalid for child

        _mockQueryService.Setup(x => x.GetUserByUserIdAsync(It.IsAny<string>()))
                         .ReturnsAsync(new Domain.V1.Entities.Users.User
                         {
                             BioAuthenticationEnabled = true,
                             CreatedBy = "test",
                             CreatedDate = DateTime.Now,
                             IsDeleted = false,
                             IsTempAccount = true,
                             NotificationsEnabled = true,
                             SOSButtonEnabled = true,
                             Status = true,
                             UpdatedBy = "test",
                             UserName = "123",
                             UserType = "test",
                             RecordVersion = [1]
                         });

        // Act
        var result = await _service.UpdateDependentOthersAsync(1, request);

        // Assert
        result.Should().NotBeNull();
        result.HasError.Should().BeTrue();
        result.StatusCode.Should().Be(ResponseStatus.STATUS_Conflict);
        result.Message.Should().Be(Resource.AgeValidation);
    }

    /// <summary>
    /// Test when age validation fails for others
    /// </summary>
    [Fact]
    public async Task UpdateDependentOthersAsync_ShouldReturnConflict_WhenAgeValidationFailsForOthers()
    {
        // Arrange
        var request = CreateMockUpdateDependentRequest();
        request.RelationshipCategory = "Other";
        request.DateOfBirth = DateTime.UtcNow.AddYears(-6); // Invalid age

        _mockQueryService.Setup(x => x.GetUserByUserIdAsync(It.IsAny<string>()))
                         .ReturnsAsync(new Domain.V1.Entities.Users.User
                         {
                             BioAuthenticationEnabled = true,
                             CreatedBy = "test",
                             CreatedDate = DateTime.Now,
                             IsDeleted = false,
                             IsTempAccount = true,
                             NotificationsEnabled = true,
                             SOSButtonEnabled = true,
                             Status = true,
                             UpdatedBy = "test",
                             UserName = "123",
                             UserType = "test",
                             RecordVersion = [1]
                         });

        // Act
        var result = await _service.UpdateDependentOthersAsync(1, request);

        // Assert
        result.Should().NotBeNull();
        result.HasError.Should().BeTrue();
        result.StatusCode.Should().Be(ResponseStatus.STATUS_Conflict);
        result.Message.Should().Be(Resource.AgeValidationOther);
    }

    /// <summary>
    /// Test when existing dependent is not found
    /// </summary>
    [Fact]
    public async Task UpdateDependentOthersAsync_ShouldReturnNotFound_WhenDependentNotFound()
    {
        // Arrange
        var request = CreateMockUpdateDependentRequest();

        _mockQueryService.Setup(x => x.GetUserByUserIdAsync(It.IsAny<string>()))
                         .ReturnsAsync(new Domain.V1.Entities.Users.User
                         {
                             BioAuthenticationEnabled = true,
                             CreatedBy = "test",
                             CreatedDate = DateTime.Now,
                             IsDeleted = false,
                             IsTempAccount = true,
                             NotificationsEnabled = true,
                             SOSButtonEnabled = true,
                             Status = true,
                             UpdatedBy = "test",
                             UserName = "123",
                             UserType = "test",
                             RecordVersion = [1]
                         });

        _mockQueryService.Setup(x => x.GetChildAndOtherByUhidAsync(request.Id, 1))
                         .ReturnsAsync((Domain.V1.Entities.Dependent.Dependent)null);

        // Act
        var result = await _service.UpdateDependentOthersAsync(1, request);

        // Assert
        result.Should().NotBeNull();
        result.HasError.Should().BeTrue();
        result.StatusCode.Should().Be(ResponseStatus.STATUS_NotFound);
        result.Message.Should().Be(Resource.RecordNotFound);
    }

    /// <summary>
    /// Test when update is successful
    /// </summary>
    [Fact]
    public async Task UpdateDependentOthersAsync_ShouldReturnSuccess_WhenUpdatedSuccessfully()
    {
        // Arrange
        var request = CreateMockUpdateDependentRequest();

        _mockQueryService.Setup(x => x.GetUserByUserIdAsync(It.IsAny<string>()))
                         .ReturnsAsync(new Domain.V1.Entities.Users.User
                         {
                             BioAuthenticationEnabled = true,
                             CreatedBy = "test",
                             CreatedDate = DateTime.Now,
                             IsDeleted = false,
                             IsTempAccount = true,
                             NotificationsEnabled = true,
                             SOSButtonEnabled = true,
                             Status = true,
                             UpdatedBy = "test",
                             UserName = "123",
                             UserType = "test",
                             RecordVersion = [1]
                         });

        _mockQueryService.Setup(x => x.GetChildAndOtherByUhidAsync(request.Id, 1))
                         .ReturnsAsync(new Domain.V1.Entities.Dependent.Dependent
                         {
                             ID = 1,
                             UserID = 101,
                             Status = true,
                             DependentUserID = 201,
                             Source = "System",
                             RelationshipCategory = "Child",
                             Relationship = "Son",
                             RecordVersion = [1, 0, 0, 0],
                             IsDeleted = false,
                             CreatedBy = "Admin",
                             CreatedDate = DateTime.UtcNow.AddDays(-10),
                             UpdatedBy = "Admin",
                             UpdatedDate = DateTime.UtcNow,
                         });

        // Act
        var result = await _service.UpdateDependentOthersAsync(1, request);

        // Assert
        result.Should().NotBeNull();
        result.HasError.Should().BeFalse();
        result.IsSuccess.Should().BeTrue();
        result.StatusCode.Should().Be(ResponseStatus.STATUS_SUCCESS);
        result.Message.Should().Be(Resource.RecordUpdationMessage);
    }

    [Fact]
    public async Task UpdateUserPhoneNumber_ShouldReturnTrue_WhenPhoneNumberIsUpdatedSuccessfully()
    {
        // Arrange
        var userId = 1L;
        var newPhoneNumber = "+91 9876543210";

        // Add mock user telecom record
        var userTelecom = new UserTelecom
        {
            UserID = userId,
            System = UserTelecomType.Phone.ToString(),
            Value = "1234567890",
            UpdatedDate = DateTime.UtcNow.AddDays(-1),
            CreatedBy = "admin",
            CreatedDate = DateTime.Now,
            UpdatedBy = "admin",
            Use = "",
            IsDeleted = false
        };

        readWriteDbContext.UserTelecoms.Add(userTelecom);
        await readWriteDbContext.SaveChangesAsync();

        // Act
        var result = await _service.UpdateUserPhoneNumber(userId, newPhoneNumber);

        // Assert
        result.Should().BeTrue();  // Verify the method returns true

        // Retrieve updated record from the database
        var updatedTelecom = await readWriteDbContext.UserTelecoms.FirstOrDefaultAsync(u => u.UserID == userId);

        updatedTelecom.Should().NotBeNull();
        updatedTelecom!.Value.Should().Be(newPhoneNumber);
        updatedTelecom.UpdatedDate.Should().BeCloseTo(DateTime.UtcNow, TimeSpan.FromSeconds(5));
    }

    [Fact]
    public async Task UpdateUserEmail_ShouldReturnTrue_WhenEmailIsUpdatedSuccessfully()
    {
        // Arrange
        var userId = 1L;
        var newEmail = "updatedemail@test.com";

        // Add mock user telecom record
        var userTelecom = new UserTelecom
        {
            UserID = userId,
            System = UserTelecomType.Email.ToString(),
            Value = "oldemail@test.com",               // Initial email
            UpdatedDate = DateTime.UtcNow.AddDays(-1), // Previous update date
            CreatedBy = "admin",
            CreatedDate = DateTime.Now,
            UpdatedBy = "admin",
            Use = "",
            IsDeleted = false
        };

        // Insert mock data into in-memory DbContext
        readWriteDbContext.UserTelecoms.Add(userTelecom);
        await readWriteDbContext.SaveChangesAsync();

        // Act
        var result = await _service.UpdateUserEmail(userId, newEmail);

        // Assert
        result.Should().BeTrue();  // Verify the method returns true

        // Retrieve the updated record from the database
        var updatedTelecom = await readWriteDbContext.UserTelecoms.FirstOrDefaultAsync(u => u.UserID == userId);

        updatedTelecom.Should().NotBeNull();
        updatedTelecom!.Value.Should().Be(newEmail);  // Ensure email is updated
        updatedTelecom.UpdatedDate.Should().BeCloseTo(DateTime.UtcNow, TimeSpan.FromSeconds(5));  // Ensure timestamp is updated
    }

    [Fact]
    public async Task UpdateUserGivenName_ShouldReturnTrue_WhenNameIsUpdatedSuccessfully()
    {
        // Arrange
        var userId = 1L;
        var newName = "UpdatedName";

        // Add mock user name record
        var userName = new UserNames
        {
            UserID = userId,
            GivenName = "OldName",
            UpdatedDate = DateTime.UtcNow.AddDays(-1),  // Previous update date
            CreatedBy = "admin",
            CreatedDate = DateTime.Now,
            UpdatedBy = "admin",
            IsDeleted = false
        };

        // Insert mock data into in-memory DbContext
        readWriteDbContext.UserNames.Add(userName);
        await readWriteDbContext.SaveChangesAsync();

        // Act
        var result = await _service.UpdateUserGivenName(userId, newName);

        // Assert
        result.Should().BeTrue();  // Verify the method returns true

        // Retrieve updated record from the database
        var updatedName = await readWriteDbContext.UserNames.FirstOrDefaultAsync(u => u.UserID == userId);

        updatedName.Should().NotBeNull();
        updatedName!.GivenName.Should().Be(newName);  // Ensure name is updated
        updatedName.UpdatedDate.Should().BeCloseTo(DateTime.UtcNow, TimeSpan.FromSeconds(5));  // Verify timestamp
    }

    [Fact]
    public async Task UpdateuserMetadata_ShouldReturnTrue_WhenMetadataIsUpdatedSuccessfully()
    {
        // Arrange
        var userId = 1L;
        var newGender = "Male";
        var newDob = new DateTime(1990, 5, 15, 0, 0, 0, DateTimeKind.Utc);
        var newNationality = "Malaysia";

        // Add mock user metadata record
        var userMetadata = new Domain.V1.Entities.Users.User
        {
            BioAuthenticationEnabled = true,
            CreatedBy = "test",
            CreatedDate = DateTime.Now,
            IsDeleted = false,
            IsTempAccount = true,
            NotificationsEnabled = true,
            SOSButtonEnabled = true,
            Status = true,
            UpdatedBy = "test",
            UserName = "123",
            UserType = "test",
            RecordVersion = [1]
        };

        // Insert mock data into in-memory DbContext
        readWriteDbContext.UserNew.Add(userMetadata);
        await readWriteDbContext.SaveChangesAsync();

        // Act
        var result = await _service.UpdateuserMetadata(userId, newGender, newDob, newNationality);

        // Assert
        result.Should().BeTrue();  // Verify the method returns true

        // Retrieve updated record from the database
        var updatedMetadata = await readWriteDbContext.UserNew.FirstOrDefaultAsync(u => u.Id == userId);

        updatedMetadata.Should().NotBeNull();
        updatedMetadata!.Gender.Should().Be(newGender);  // Ensure gender is updated
        updatedMetadata.BirthDate.Should().Be(newDob);   // Ensure DOB is updated
        updatedMetadata.UpdatedDate.Should().BeCloseTo(DateTime.UtcNow, TimeSpan.FromSeconds(5));  // Verify timestamp
    }

    [Fact]
    public async Task UpdateUserIdentifier_ShouldReturnTrue_WhenIdentifierIsUpdatedSuccessfully()
    {
        // Arrange
        var userId = 1L;
        var newCountry = "USA";
        var newIdentifier = "9876543210";
        var newIdentifierType = "Passport";

        // Add mock user identifier record
        var userIdentifier = new UserIdentifier
        {
            Id = userId,
            System = "IND",
            Value = "1234567890",
            IdentifierType = "Aadhar",
            UpdatedDate = DateTime.UtcNow.AddDays(-1),  // Previous update date
            CreatedBy = "admin",
            CreatedDate = DateTime.Now,
            UpdatedBy = "admin",
            IsDeleted = false,
            UserID = 23,
            Status = false
        };

        // Insert mock data into in-memory DbContext
        readWriteDbContext.UserIdentifiers.Add(userIdentifier);
        await readWriteDbContext.SaveChangesAsync();

        // Act
        var result = await _service.UpdateUserIdentifier(userId, newCountry, newIdentifier, newIdentifierType);

        // Assert
        result.Should().BeTrue();  // Verify the method returns true

        // Retrieve updated record from the database
        var updatedIdentifier = await readWriteDbContext.UserIdentifiers.FirstOrDefaultAsync(u => u.Id == userId);

        updatedIdentifier.Should().NotBeNull();
        updatedIdentifier!.System.Should().Be(newCountry);               // Ensure country is updated
        updatedIdentifier.Value.Should().Be(newIdentifier);              // Ensure identifier value is updated
        updatedIdentifier.IdentifierType.Should().Be(newIdentifierType); // Ensure identifier type is updated
        updatedIdentifier.UpdatedDate.Should().BeCloseTo(DateTime.UtcNow, TimeSpan.FromSeconds(5));  // Verify timestamp
    }

    [Fact]
    public async Task UpdateDependentOthersAsync_ShouldUpdateFields_WhenDependentExists()
    {
        // Arrange
        var request = CreateMockUpdateDependentRequest();
        request.Relationship = "Updated Relationship";
        request.RelationshipCategory = "Updated Category";

        var existingDependent = new Domain.V1.Entities.Dependent.Dependent
        {
            ID = 1,
            UserID = request.Id,
            DependentUserID = 1,
            Relationship = "Old Relationship",
            RelationshipCategory = "Old Category",
            CreatedBy = "Admin",
            CreatedDate = DateTime.UtcNow.AddDays(-5),
            UpdatedBy = "Admin",
            UpdatedDate = DateTime.UtcNow.AddDays(-2),
            RecordVersion = [1, 2, 3],
            Status = true,
            IsDeleted = false
        };

        await readWriteDbContext.Dependents.AddAsync(existingDependent);
        await readWriteDbContext.SaveChangesAsync();

        _mockQueryService.Setup(x => x.GetUserByUserIdAsync(It.IsAny<string>()))
                         .ReturnsAsync(new Domain.V1.Entities.Users.User
                         {
                             UserName = "john_doe",
                             BioAuthenticationEnabled = true,
                             CreatedBy = "test",
                             CreatedDate = DateTime.Now,
                             IsDeleted = false,
                             IsTempAccount = true,
                             NotificationsEnabled = true,
                             SOSButtonEnabled = true,
                             Status = true,
                             UpdatedBy = "test",
                             UserType = "test",
                             RecordVersion = [1]
                         });

        _mockQueryService.Setup(x => x.GetChildAndOtherByUhidAsync(request.Id, 1))
                         .ReturnsAsync(existingDependent);

        // Act
        var result = await _service.UpdateDependentOthersAsync(1, request);

        // Assert
        result.Should().NotBeNull();
        result.HasError.Should().BeFalse();
        result.IsSuccess.Should().BeTrue();
        result.StatusCode.Should().Be(ResponseStatus.STATUS_SUCCESS);
        result.Message.Should().Be(Resource.RecordUpdationMessage);

        // Verify that properties are actually updated
        existingDependent.Relationship.Should().Be(existingDependent.Relationship);
        existingDependent.RelationshipCategory.Should().Be(existingDependent.RelationshipCategory);
    }



    /// <summary>
    /// Helper method to create mock DTO
    /// </summary>
    private static UpdateDependentandOthersDto CreateMockUpdateDependentRequest()
    {
        return new UpdateDependentandOthersDto
        {
            Id = 1,
            Name = "John Doe",
            Gender = "Male",
            PhoneNumber = "1234567890",
            PhoneCountryCode = "+91",
            Email = "john.doe@example.com",
            DateOfBirth = DateTime.UtcNow.AddYears(-30),
            Relationship = "Spouse",
            RelationshipCategory = "Family",
            Country = "India",
            IdentifierNumber = "ID123456",
            IdentificationType = "Passport"
        };
    }

    #endregion



}