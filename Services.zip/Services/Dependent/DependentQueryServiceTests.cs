﻿using Aurora.AdministrationService.API.Services.Service.Dependent;
using Aurora.AdministrationService.Infrastructure;
using Microsoft.EntityFrameworkCore;

namespace Aurora.AdministrationService.Tests.API.Services.Dependent;

public class DependentQueryServiceTests : TestsBase<DependentQueryService>
{
    private readonly ReadOnlyDbContext _readOnlyDBContext;
    private readonly DependentQueryService _service;

    public DependentQueryServiceTests()
    {
        _readOnlyDBContext = GetReadOnlyDBContextInMemory();
        _service = new DependentQueryService(_readOnlyDBContext);
        SeedData();
    }

    [Fact]
    public void GetUserByIdAsync_ShouldReturnExpectedResult()
    {
        // Act
        var result = _service.GetUserByUserIdAsync("123");

        // Assert
        Assert.NotNull(result);
    }

    [Fact]
    public void GetUserByPhoneNoAsync_ShouldReturnExpectedResult()
    {
        // Act
        var result = _service.GetUserByPhoneNoAsync("123");

        // Assert
        Assert.NotNull(result);
    }

    [Fact]
    public void GetUserByEmailAsync_ShouldReturnExpectedResult()
    {
        // Act
        var result = _service.GetUserByEmailAsync("123@test.com");

        // Assert
        Assert.NotNull(result);
    }

    [Fact]
    public void GetDependentByUserId_ShouldReturnExpectedResult()
    {
        // Act
        var result = _service.GetDependentByUserId(123);

        // Assert
        Assert.NotNull(result);
    }

    [Fact]
    public void GetDependentByUserIdandDependentId_ShouldReturnExpectedResult()
    {
        // Act
        var result = _service.GetDependentByUserIdandDependentId(123, 123);

        // Assert
        Assert.NotNull(result);
    }

    [Theory]
    [InlineData(123, "200")]
    [InlineData(123456, "RecordNotFound")]
    [InlineData(123, "RecordNotFound", true)]
    public void GetDependentsWithCategory_ShouldReturnExpectedResult(long userId, string response, bool isDependentNull = false)
    {
        //Arrange
        if (isDependentNull)
            DeleteDependent();

        // Act
        var result = _service.GetDependentsWithCategory(userId);

        // Assert
        Assert.NotNull(result);
        Assert.Equal(response, result.StatusCode);
    }

    [Theory]
    [InlineData(123, "200")]
    [InlineData(123456, "RecordNotFound")]
    [InlineData(123, "RecordNotFound", true)]
    public void GetDependentProfileById_ShouldReturnExpectedResult(long dependentId, string response, bool isUserNull = false)
    {
        //Arrange
        if (isUserNull)
            DeleteUserNew();

        // Act
        var result = _service.GetDependentProfileById(dependentId);

        // Assert
        Assert.NotNull(result);
        Assert.Equal(response, result.StatusCode);
    }

    private void SeedData()
    {
        using (var _readWriteDBContext = GetReadWriteDBContextInMemory())
        {
            List<Domain.V1.Entities.Dependent.Dependent> dependent = new(){ new Domain.V1.Entities.Dependent.Dependent()
                {
                    CreatedDate = DateTime.UtcNow,
                    DependentUserID = 123,
                    ID = 123,
                    IsDeleted = false,
                    Relationship = "test",
                    Status = true,
                    UserID = 123,
                    RecordVersion = new byte[] { 1 }
                },
                new Domain.V1.Entities.Dependent.Dependent()
                {
                    CreatedDate = DateTime.UtcNow,
                    DependentUserID = 123,
                    ID = 1234,
                    IsDeleted = false,
                    Relationship = "child",
                    Status = true,
                    UserID = 123,
                    RecordVersion = new byte[] { 1 },
                    RelationshipCategory = "child",
                    CreatedBy = "test"
                }
            };

            Domain.V1.Entities.Users.User user = new Domain.V1.Entities.Users.User()
            {
                CreatedDate = DateTime.UtcNow,
                IsDeleted = false,
                Status = true,
                RecordVersion = new byte[] { 1 },
                BioAuthenticationEnabled = true,
                CreatedBy = "test",
                IsTempAccount = true,
                NotificationsEnabled = true,
                SOSButtonEnabled = true,
                UpdatedBy = "test",
                UserName = "123",
                UserType = "test",
                Id = 123
            };

            Domain.V1.Entities.Users.UserNames userNames = new Domain.V1.Entities.Users.UserNames()
            {
                CreatedDate = DateTime.UtcNow,
                IsDeleted = false,
                Status = true,
                RecordVersion = new byte[] { 1 },
                CreatedBy = "test",
                UpdatedBy = "test",
                Id = 123,
                UserID = 123
            };

            Domain.V1.Entities.Users.UserIdentifier userIdentifier = new Domain.V1.Entities.Users.UserIdentifier()
            {
                CreatedDate = DateTime.UtcNow,
                IsDeleted = false,
                Status = true,
                RecordVersion = new byte[] { 1 },
                CreatedBy = "test",
                UpdatedBy = "test",
                Id = 123,
                UserID = 123,
                System = "test",
                Value = "test"
            };

            List<Domain.V1.Entities.Users.UserTelecom> userTelecoms = new(){ new Domain.V1.Entities.Users.UserTelecom()
                {
                    CreatedDate = DateTime.UtcNow,
                    IsDeleted = false,
                    Status = true,
                    RecordVersion = new byte[] { 1 },
                    CreatedBy = "test",
                    UpdatedBy = "test",
                    Id = 123,
                    UserID = 123,
                    System = "test",
                    Use = "PhoneNo",
                    Value = "123"
                },
                new Domain.V1.Entities.Users.UserTelecom() {
                    CreatedDate = DateTime.UtcNow,
                    IsDeleted = false,
                    Status = true,
                    RecordVersion = new byte[] { 1 },
                    CreatedBy = "test",
                    UpdatedBy = "test",
                    Id = 1234,
                    UserID = 1234,
                    System = "test",
                    Use = "Email",
                    Value = "123@test.com"
                }
            };

            _readWriteDBContext.Dependents.AddRange(dependent);
            _readWriteDBContext.UserNew.Add(user);
            _readWriteDBContext.UserNames.Add(userNames);
            _readWriteDBContext.UserIdentifiers.Add(userIdentifier);
            _readWriteDBContext.UserTelecoms.AddRange(userTelecoms);

            Task.Run(() => _readWriteDBContext.SaveChangesAsync()).GetAwaiter().GetResult();
        }
    }

    private void DeleteUserNew()
    {
        using (var _readWriteDBContext = GetReadWriteDBContextInMemory())
        {
            var record = _readWriteDBContext.UserNew.Where(u => u.Id > 0).FirstOrDefault();
            record.IsDeleted = true;
            _readWriteDBContext.UserNew.Update(record);
            Task.Run(() => _readWriteDBContext.SaveChangesAsync()).GetAwaiter().GetResult();
        }
    }

    private void DeleteDependent()
    {
        using (var _readWriteDBContext = GetReadWriteDBContextInMemory())
        {
            var records = _readWriteDBContext.Dependents.Where(u => u.ID > 0).ToList();
            records.ForEach(record => record.IsDeleted = true);
            _readWriteDBContext.Dependents.UpdateRange(records);
            Task.Run(() => _readWriteDBContext.SaveChangesAsync()).GetAwaiter().GetResult();
        }
    }
}