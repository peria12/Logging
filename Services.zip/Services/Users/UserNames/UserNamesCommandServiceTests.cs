﻿using Aurora.AdministrationService.API.Models.Dto.Users.PayLoads;
using Aurora.AdministrationService.API.Models.Dto.Users.UserNames;
using Aurora.AdministrationService.API.Services.IService.AzureBus;
using Aurora.AdministrationService.API.Services.Service.Users.UserNames;
using Aurora.AdministrationService.CrossCutting.CommonModels;
using Aurora.AdministrationService.Infrastructure;
using AutoMapper;
using FluentAssertions;
using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.Configuration;
using Moq;

namespace Aurora.AdministrationService.Tests.API.Services.Users.UserNames
{
    public class UserNamesCommandServiceTests
    {
        private readonly Mock<ReadWriteDbContext> _readWriteDbContextMock;
        private readonly Mock<ReadOnlyDbContext> _readOnlyDbContextMock;
        private readonly Mock<IMapper> _mapperMock;
        private UserNamesCommandService _userNamesCommandService;
        private readonly Mock<UserNamesQueryService> _userNamesQueryService;
        private readonly Mock<IAzureBusCommandServices> _azureBusCommandServicesMock;
        private readonly Mock<IConfiguration> _mockConfiguration;
        public UserNamesCommandServiceTests()
        {
            // Initialize the mocks
            _mapperMock = new Mock<IMapper>();
            _readWriteDbContextMock = new Mock<ReadWriteDbContext>();
            _readOnlyDbContextMock = new Mock<ReadOnlyDbContext>();
            _userNamesQueryService = new Mock<UserNamesQueryService>();
            _azureBusCommandServicesMock = new Mock<IAzureBusCommandServices>();
            _mockConfiguration = new Mock<IConfiguration>();

            // Setup in-memory ready only database for testing
            DbContextOptions<ReadWriteDbContext> options = new DbContextOptionsBuilder<ReadWriteDbContext>()
              .UseInMemoryDatabase(databaseName: "AdminUserNamesTestDB").Options;

            _readWriteDbContextMock = new(options);

            // Initialize the service being tested
            _userNamesCommandService = new UserNamesCommandService(_readWriteDbContextMock.Object, _mapperMock.Object, _azureBusCommandServicesMock.Object, _mockConfiguration.Object);
        }

        [Fact]
        public async Task CreateUserNamesAsync_ShouldReturnTrue_WhenUserNamesIsCreatedSuccessfully()
        {
            // Arrange
            var newUserNames = new UserNamesDto
            {
                UserID = 1,
                Status = true,
                FamilyName = "family",
                GivenName = "test",
                MiddleName = "test",
                NameUse = "test",
                Prefix = "test",
                Suffix = "test",
                PeriodEnd = DateTime.UtcNow,
                PeriodStart = DateTime.UtcNow,
            };

            // Mock AutoMapper to return a UserNames entity
            long userNamesId = 1L;
            var userNamesEntity = new Domain.V1.Entities.Users.UserNames
            {
                Id = userNamesId,
                UserID = 1,
                Status = true,
                FamilyName = "family",
                GivenName = "test",
                MiddleName = "test",
                NameUse = "test",
                Prefix = "test",
                Suffix = "test",
                PeriodEnd = DateTime.UtcNow,
                PeriodStart = DateTime.UtcNow,
                IsDeleted = false,
                CreatedBy = "Admin",
                CreatedDate = DateTime.UtcNow,
                UpdatedBy = "Admin",  // Adding the missing property
                UpdatedDate = DateTime.UtcNow,// Assuming UpdatedDate is required as well
            };


            // Mock AutoMapper to return the UserNames entity
            _mapperMock.Setup(m => m.Map<Domain.V1.Entities.Users.UserNames>(newUserNames)).Returns(userNamesEntity);

            // Mock DbContext to simulate saving the entity without actually hitting the database
            _readWriteDbContextMock.Setup(db => db.UserNames.Add(It.IsAny<Domain.V1.Entities.Users.UserNames>()));

            // Act
            var result = await _userNamesCommandService.CreateUserNamesAsync(newUserNames);

            // Assert
            Assert.True(result);
            _readWriteDbContextMock.Verify(db => db.UserNames.Add(It.Is<Domain.V1.Entities.Users.UserNames>(l => l.CreatedBy == "Admin")), Times.Once);
        }


        [Fact]
        public async Task CreateUserNamesAsync_ShouldReturnFalse_WhenExceptionOccurs()
        {
            // Arrange
            var newUserNames = new UserNamesDto
            {
                UserID = 1,
                Status = true,
                FamilyName = "family",
                GivenName = "test",
                MiddleName = "test",
                NameUse = "test",
                Prefix = "test",
                Suffix = "test",
                PeriodEnd = DateTime.UtcNow,
                PeriodStart = DateTime.UtcNow,
            };

            // Mock AutoMapper to return a UserNames entity
            var userNamesId = 1;
            var userNamesEntity = new Domain.V1.Entities.Users.UserNames
            {
                Id = userNamesId,
                UserID = 1,
                Status = true,
                FamilyName = "family",
                GivenName = "test",
                MiddleName = "test",
                NameUse = "test",
                Prefix = "test",
                Suffix = "test",
                PeriodEnd = DateTime.UtcNow,
                PeriodStart = DateTime.UtcNow,
                IsDeleted = false,
                CreatedBy = "Admin",
                CreatedDate = DateTime.UtcNow,
                UpdatedBy = "Admin",  // Adding the missing property
                UpdatedDate = DateTime.UtcNow,// Assuming UpdatedDate is required as well
            };

            //Setup
            _mapperMock.Setup(m => m.Map<Domain.V1.Entities.Users.UserNames>(newUserNames)).Returns(userNamesEntity);

            // Act
            var result = await _userNamesCommandService.CreateUserNamesAsync(newUserNames);

            // Assert
            Assert.False(result);
        }
        [Fact]
        public async Task Test_UpdateUserNames_Returns_Success()
        {
            //Arrange
            DbContextOptions<ReadWriteDbContext> options = new DbContextOptionsBuilder<ReadWriteDbContext>()
               .UseInMemoryDatabase(databaseName: "UpdateUserNames").Options;

            byte[] concurrencyToken = new byte[8] { byte.MinValue, byte.MinValue, byte.MinValue, byte.MinValue, byte.MinValue, byte.MinValue, byte.MinValue, byte.MaxValue };
            var userNames = new Domain.V1.Entities.Users.UserNames
            {
                Id = 1,
                UserID = 1,
                Status = true,
                FamilyName = "family",
                GivenName = "test",
                MiddleName = "test",
                NameUse = "test",
                Prefix = "test",
                Suffix = "test",
                PeriodEnd = DateTime.UtcNow,
                PeriodStart = DateTime.UtcNow,
                IsDeleted = false,
                CreatedBy = "Admin",
                CreatedDate = DateTime.UtcNow,
                UpdatedBy = "Admin",  // Adding the missing property
                UpdatedDate = DateTime.UtcNow,// Assuming UpdatedDate is required as well
                RecordVersion = concurrencyToken
            };


            //Arrange
            using ReadWriteDbContext dbContext = new(options);
            dbContext.UserNames.Add(userNames);
            await dbContext.SaveChangesAsync();


            UpdateUserNamesRequest updateModel = new UpdateUserNamesRequest
            {
                Id = 1,
                UserID = 1,
                Status = true,
                FamilyName = "family",
                GivenName = "test",
                MiddleName = "test",
                NameUse = "test",
                Prefix = "test",
                Suffix = "test",
                PeriodEnd = DateTime.UtcNow,
                PeriodStart = DateTime.UtcNow,
                RecordVersion = concurrencyToken
            };

            updateModel.RecordVersion = userNames.RecordVersion;

            _userNamesCommandService = new UserNamesCommandService(dbContext, _mapperMock.Object, _azureBusCommandServicesMock.Object, _mockConfiguration.Object);

            // Act
            bool result = await _userNamesCommandService.UpdateUserNamesAsync(updateModel, userNames);

            Assert.True(result);
        }
        [Fact]
        public async Task Test_DeleteUserNames_Returns_Success()
        {
            //Arrange
            DbContextOptions<ReadWriteDbContext> options = new DbContextOptionsBuilder<ReadWriteDbContext>()
               .UseInMemoryDatabase(databaseName: "DeleteUserNames").Options;

            byte[] concurrencyToken = new byte[8] { byte.MinValue, byte.MinValue, byte.MinValue, byte.MinValue, byte.MinValue, byte.MinValue, byte.MinValue, byte.MaxValue };
            var userNames = new Domain.V1.Entities.Users.UserNames
            {
                Id = 1,
                UserID = 1,
                Status = true,
                FamilyName = "family",
                GivenName = "test",
                MiddleName = "test",
                NameUse = "test",
                Prefix = "test",
                Suffix = "test",
                PeriodEnd = DateTime.UtcNow,
                PeriodStart = DateTime.UtcNow,
                IsDeleted = false,
                CreatedBy = "Admin",
                CreatedDate = DateTime.UtcNow,
                UpdatedBy = "Admin",  // Adding the missing property
                UpdatedDate = DateTime.UtcNow,// Assuming UpdatedDate is required as well
                RecordVersion = concurrencyToken
            };



            //Arrange
            using ReadWriteDbContext dbContext = new(options);
            dbContext.UserNames.Add(userNames);
            await dbContext.SaveChangesAsync();

            _userNamesCommandService = new UserNamesCommandService(dbContext, _mapperMock.Object, _azureBusCommandServicesMock.Object, _mockConfiguration.Object);

            // Act
            bool result = await _userNamesCommandService.DeleteUserNamesByIdAsync(concurrencyToken, userNames);

            Assert.True(result);
        }
        [Fact]
        public async Task UpdatePreferredNameAndSaluation_ShouldUpdateFieldsAndSaveChanges()
        {
            // Arrange
            var options = new DbContextOptionsBuilder<ReadWriteDbContext>()
                .UseInMemoryDatabase(databaseName: Guid.NewGuid().ToString())
                .Options;

            var testUserId = "TestUser123";
            byte[] concurrencyToken = new byte[8] { 0, 0, 0, 0, 0, 0, 0, 255 };

            var request = new UpdatePreferredNameAndSaluationRequest
            {
                Salutation = "Dr.",
                PreferredName = "Alex"
            };
            var userId = 1L;
            var userNames = new Domain.V1.Entities.Users.UserNames
            {
                Id = 1,
                UserID = 1,
                Status = true,
                FamilyName = "family",
                GivenName = "test",
                MiddleName = "test",
                NameUse = "test",
                Prefix = "test",
                Suffix = "test",
                PeriodEnd = DateTime.UtcNow,
                PeriodStart = DateTime.UtcNow,
                IsDeleted = false,
                CreatedBy = "Admin",
                CreatedDate = DateTime.UtcNow,
                UpdatedBy = "Admin",
                UpdatedDate = DateTime.UtcNow,
                RecordVersion = concurrencyToken
            };
            var user = new Domain.V1.Entities.Users.User
            {
                Id = userId,
                UserName = "admin",
                Status = true,
                Gender = "Male",
                BirthDate = DateTime.UtcNow,
                ManagingOrganization = "1",
                Source = "Aurora",
                IsTempAccount = true,
                UserType = "Patient",
                Passcode = "1234",
                Language = 1,
                NotificationsEnabled = true,
                BioAuthenticationEnabled = true,
                SOSButtonEnabled = true,
                AppVersion = "v1",
                Password = "1234",
                IsMarketingConsentEnable = true,
                Salt = "salt",
                LocationEnable = true,
                IsDeleted = false,
                CreatedBy = "Admin",
                CreatedDate = DateTime.UtcNow,
                UpdatedBy = "Admin",  // Adding the missing property
                UpdatedDate = DateTime.UtcNow,// Assuming UpdatedDate is required as well
            };

            using var dbContext = new ReadWriteDbContext(options);
            dbContext.UserNames.Add(userNames);
            dbContext.UserNew.Add(user);
            await dbContext.SaveChangesAsync();

            var mapperMock = new Mock<IMapper>();
            var service = new UserNamesCommandService(dbContext, mapperMock.Object, _azureBusCommandServicesMock.Object, _mockConfiguration.Object);

            typeof(UserNamesCommandService)
                .GetField("_userId", System.Reflection.BindingFlags.NonPublic | System.Reflection.BindingFlags.Instance)
                ?.SetValue(service, testUserId);

            _azureBusCommandServicesMock.Setup(x => x.SendData(It.IsAny<PatientSignUpPayloadDto>(), "MYS", It.IsAny<string>()))
             .ReturnsAsync(new GenericResponse<string>
             {
                 IsSuccess = true,
                 HasError = false,
             });


            // Act
            var result = await service.UpdatePreferredNameAndSaluation(request, userNames, user,"MYS");

            // Assert
            result.Should().BeTrue();
            userNames.Prefix.Should().Be("Dr.");
            userNames.NameUse.Should().Be("Alex");
            userNames.UpdatedBy.Should().Be(testUserId);
        }
        [Fact]
        public async Task UpdatePreferredNameAndSaluation_WhenServiceBusNotConnect()
        {
            // Arrange
            var options = new DbContextOptionsBuilder<ReadWriteDbContext>()
                .UseInMemoryDatabase(databaseName: Guid.NewGuid().ToString())
                .Options;

            var testUserId = "TestUser123";
            byte[] concurrencyToken = new byte[8] { 0, 0, 0, 0, 0, 0, 0, 255 };

            var request = new UpdatePreferredNameAndSaluationRequest
            {
                Salutation = "Dr.",
                PreferredName = "Alex"
            };
            var userId = 1L;
            var userNames = new Domain.V1.Entities.Users.UserNames
            {
                Id = 1,
                UserID = 1,
                Status = true,
                FamilyName = "family",
                GivenName = "test",
                MiddleName = "test",
                NameUse = "test",
                Prefix = "test",
                Suffix = "test",
                PeriodEnd = DateTime.UtcNow,
                PeriodStart = DateTime.UtcNow,
                IsDeleted = false,
                CreatedBy = "Admin",
                CreatedDate = DateTime.UtcNow,
                UpdatedBy = "Admin",
                UpdatedDate = DateTime.UtcNow,
                RecordVersion = concurrencyToken
            };
            var user = new Domain.V1.Entities.Users.User
            {
                Id = userId,
                UserName = "admin",
                Status = true,
                Gender = "Male",
                BirthDate = DateTime.UtcNow,
                ManagingOrganization = "1",
                Source = "Aurora",
                IsTempAccount = true,
                UserType = "Patient",
                Passcode = "1234",
                Language = 1,
                NotificationsEnabled = true,
                BioAuthenticationEnabled = true,
                SOSButtonEnabled = true,
                AppVersion = "v1",
                Password = "1234",
                IsMarketingConsentEnable = true,
                Salt = "salt",
                LocationEnable = true,
                IsDeleted = false,
                CreatedBy = "Admin",
                CreatedDate = DateTime.UtcNow,
                UpdatedBy = "Admin",  // Adding the missing property
                UpdatedDate = DateTime.UtcNow,// Assuming UpdatedDate is required as well
            };

            using var dbContext = new ReadWriteDbContext(options);
            dbContext.UserNames.Add(userNames);
            dbContext.UserNew.Add(user);
            await dbContext.SaveChangesAsync();

            var mapperMock = new Mock<IMapper>();
            var service = new UserNamesCommandService(dbContext, mapperMock.Object, _azureBusCommandServicesMock.Object, _mockConfiguration.Object);

            typeof(UserNamesCommandService)
                .GetField("_userId", System.Reflection.BindingFlags.NonPublic | System.Reflection.BindingFlags.Instance)
                ?.SetValue(service, testUserId);

            _azureBusCommandServicesMock.Setup(x => x.SendData(It.IsAny<PatientSignUpPayloadDto>(), "MYS", It.IsAny<string>()))
             .ReturnsAsync(new GenericResponse<string>
             {
                 IsSuccess = false,
                 HasError = true,
             });


            // Act
            var result = await service.UpdatePreferredNameAndSaluation(request, userNames, user, "MYS");

            // Assert
            result.Should().BeTrue();
            userNames.Prefix.Should().Be("Dr.");
            userNames.NameUse.Should().Be("Alex");
            userNames.UpdatedBy.Should().Be(testUserId);
        }


    }
}
