﻿using Aurora.AdministrationService.API.Models.Dto.Users.UserNames;
using Aurora.AdministrationService.API.Services.Service.Users;
using Aurora.AdministrationService.API.Services.Service.Users.UserNames;
using Aurora.AdministrationService.CrossCutting.CommonModels;
using Aurora.AdministrationService.Infrastructure;
using AutoMapper;
using Microsoft.AspNetCore.Http.HttpResults;
using Microsoft.EntityFrameworkCore;
using Microsoft.Graph;
using Moq;

namespace Aurora.AdministrationService.Tests.API.Services.Users.UserNames
{
    public class UserNamesQueryServiceTests
    {
        private readonly Mock<ReadOnlyDbContext> _readOnlyDbContextMock;
        private readonly Mock<IMapper> _mapperMock;
        private readonly UserNamesQueryService _userNamesQueryService;
        private Mock<DbSet<Domain.V1.Entities.Users.UserNames>> _mockDbSet;

        public UserNamesQueryServiceTests()
        {
            //Initialize mock
            _readOnlyDbContextMock = new Mock<ReadOnlyDbContext>();
            _mapperMock = new Mock<IMapper>();

            // Setup in-memory ready only database for testing
            DbContextOptions<ReadOnlyDbContext> options = new DbContextOptionsBuilder<ReadOnlyDbContext>()
              .UseInMemoryDatabase(databaseName: "UserNamesTestDB").Options;

            _readOnlyDbContextMock = new(options);

            _mockDbSet = new Mock<DbSet<Domain.V1.Entities.Users.UserNames>>();

            var data = new List<Domain.V1.Entities.Users.UserNames>
            {
               new Domain.V1.Entities.Users.UserNames {
                Id = 1,
                UserID = 1,
                Status = true,
                FamilyName = "family",
                GivenName = "test",
                MiddleName = "test",
                NameUse = "test",
                Prefix = "test",
                Suffix = "test",
                PeriodEnd = DateTime.UtcNow,
                PeriodStart = DateTime.UtcNow,
                IsDeleted = false,
                CreatedBy = "Admin",
                CreatedDate = DateTime.UtcNow,
                UpdatedBy = "Admin",  // Adding the missing property
                UpdatedDate = DateTime.UtcNow,// Assuming UpdatedDate is required as well
            },
               new Domain.V1.Entities.Users.UserNames {
                Id = 2,
                UserID = 1,
                Status = true,
                FamilyName = "family",
                GivenName = "test",
                MiddleName = "test",
                NameUse = "test",
                Prefix = "test",
                Suffix = "test",
                PeriodEnd = DateTime.UtcNow,
                PeriodStart = DateTime.UtcNow,
                IsDeleted = false,
                CreatedBy = "Admin",
                CreatedDate = DateTime.UtcNow,
                UpdatedBy = "Admin",  // Adding the missing property
                UpdatedDate = DateTime.UtcNow,// Assuming UpdatedDate is required as well
            }

            }.AsQueryable();


            //Setup
            _mockDbSet.As<IQueryable<Domain.V1.Entities.Users.UserNames>>().Setup(m => m.Provider).Returns(data.Provider);
            _mockDbSet.As<IQueryable<Domain.V1.Entities.Users.UserNames>>().Setup(m => m.Expression).Returns(data.Expression);
            _mockDbSet.As<IQueryable<Domain.V1.Entities.Users.UserNames>>().Setup(m => m.ElementType).Returns(data.ElementType);
            _mockDbSet.As<IQueryable<Domain.V1.Entities.Users.UserNames>>().Setup(m => m.GetEnumerator()).Returns(data.GetEnumerator());
            _readOnlyDbContextMock.Setup(c => c.UserNames).Returns(_mockDbSet.Object);

            // Create the service instance
            _userNamesQueryService = new UserNamesQueryService(_readOnlyDbContextMock.Object, _mapperMock.Object);
        }

        [Fact]
        public async Task GetUserNamesById_LogoExists_ReturnsLogoDetailDto()
        {
            // Arrange
            var userNamesId = 1L;
            var userNames = new Domain.V1.Entities.Users.UserNames
            {
                Id = 1,
                UserID = 1,
                Status = true,
                FamilyName = "family",
                GivenName = "test",
                MiddleName = "test",
                NameUse = "test",
                Prefix = "test",
                Suffix = "test",
                PeriodEnd = DateTime.UtcNow,
                PeriodStart = DateTime.UtcNow,
                IsDeleted = false,
                CreatedBy = "Admin",
                CreatedDate = DateTime.UtcNow,
                UpdatedBy = "Admin",  // Adding the missing property
                UpdatedDate = DateTime.UtcNow,// Assuming UpdatedDate is required as well
            };
            byte[] concurrencyToken = new byte[8] { byte.MinValue, byte.MinValue, byte.MinValue, byte.MinValue, byte.MinValue, byte.MinValue, byte.MinValue, byte.MaxValue };

            var userNamesDto = new GetUserNamesDetailDto
            {
                Id = 1,
                UserID = 1,
                Status = true,
                FamilyName = "family",
                GivenName = "test",
                MiddleName = "test",
                NameUse = "test",
                Prefix = "test",
                Suffix = "test",
                PeriodEnd = DateTime.UtcNow,
                PeriodStart = DateTime.UtcNow,
                RecordVersion = concurrencyToken,
            };

            _readOnlyDbContextMock.Setup(db => db.UserNames.FindAsync(userNamesId))
                .ReturnsAsync(userNames);

            _mapperMock.Setup(m => m.Map<GetUserNamesDetailDto>(userNames))
                .Returns(userNamesDto);

            // Act
            var result = await _userNamesQueryService.GetUserNamesById(userNamesId);

            // Assert
            Assert.NotNull(result);
            Assert.Equal(userNamesId, result.Id);
            Assert.Equal("test", result.GivenName);
        }

        [Fact]
        public async Task GetUserNamesById_userNamesNotFound_ReturnsNull()
        {
            //Arrange
            var userNamesId = 1;
            var userNames = new Domain.V1.Entities.Users.UserNames
            {
                Id = 1,
                UserID = 1,
                Status = true,
                FamilyName = "family",
                GivenName = "test",
                MiddleName = "test",
                NameUse = "test",
                Prefix = "test",
                Suffix = "test",
                PeriodEnd = DateTime.UtcNow,
                PeriodStart = DateTime.UtcNow,
                IsDeleted = false,
                CreatedBy = "Admin",
                CreatedDate = DateTime.UtcNow,
                UpdatedBy = "Admin",  // Adding the missing property
                UpdatedDate = DateTime.UtcNow,// Assuming UpdatedDate is required as well
            };

            _readOnlyDbContextMock.Setup(db => db.UserNames.FindAsync(userNamesId))
                .ReturnsAsync(userNames);

            //Act
            var result = await _userNamesQueryService.GetUserNamesById(userNamesId);

            //Assert
            Assert.Null(result);
        }

        [Fact]
        public async Task GetUserNamesById_userNamesExists_BindingError_ReturnsNull()
        {
            // Arrange
            byte[] concurrencyToken = new byte[8] { byte.MinValue, byte.MinValue, byte.MinValue, byte.MinValue, byte.MinValue, byte.MinValue, byte.MinValue, byte.MaxValue };
            var userNamesId = 1L;
            var userNames = new Domain.V1.Entities.Users.UserNames
            {
                Id = 1,
                UserID = 1,
                Status = true,
                FamilyName = "family",
                GivenName = "test",
                MiddleName = "test",
                NameUse = "test",
                Prefix = "test",
                Suffix = "test",
                PeriodEnd = DateTime.UtcNow,
                PeriodStart = DateTime.UtcNow,
                IsDeleted = false,
                CreatedBy = "Admin",
                CreatedDate = DateTime.UtcNow,
                UpdatedBy = "Admin",  // Adding the missing property
                UpdatedDate = DateTime.UtcNow,// Assuming UpdatedDate is required as well
                RecordVersion = concurrencyToken
            };

            _readOnlyDbContextMock.Setup(db => db.UserNames.FindAsync(userNamesId))
                .ReturnsAsync(userNames);

            _mapperMock.Setup(m => m.Map<GetUserNamesDetailDto>(userNames))
                .Throws(new AutoMapperMappingException("Error mapping entity to DTO"));

            // Act & Assert
            var exception = await Assert.ThrowsAsync<AutoMapperMappingException>(
                () => _userNamesQueryService.GetUserNamesById(userNamesId)
            );

            Assert.Equal("Error mapping entity to DTO", exception.Message);
        }

        [Fact]
        public async Task FindUserNamesById_userNamesExists_ReturnsuserNames()
        {
            // Arrange
            byte[] concurrencyToken = new byte[8] { byte.MinValue, byte.MinValue, byte.MinValue, byte.MinValue, byte.MinValue, byte.MinValue, byte.MinValue, byte.MaxValue };
            long userNamesId = 1;
            var userNames = new Domain.V1.Entities.Users.UserNames
            {
                Id = userNamesId,
                UserID = 1,
                Status = true,
                FamilyName = "family",
                GivenName = "test",
                MiddleName = "test",
                NameUse = "test",
                Prefix = "test",
                Suffix = "test",
                PeriodEnd = DateTime.UtcNow,
                PeriodStart = DateTime.UtcNow,
                IsDeleted = false,
                CreatedBy = "Admin",
                CreatedDate = DateTime.UtcNow,
                UpdatedBy = "Admin",  // Adding the missing property
                UpdatedDate = DateTime.UtcNow,// Assuming UpdatedDate is required as well
                RecordVersion = concurrencyToken
            };

            // Mock the FindAsync method to return the userNames
            _readOnlyDbContextMock.Setup(db => db.UserNames.FindAsync(userNamesId))
                .ReturnsAsync(userNames);

            // Act
            var result = await _userNamesQueryService.FindUserNamesById(userNamesId);

            // Assert
            Assert.NotNull(result);
        }

        [Fact]
        public async Task FindUserNamesById_userNamesNotFound_ReturnsNull()
        {
            // Arrange
            var userNamesId = 1L;
            var userNames = new Domain.V1.Entities.Users.UserNames
            {
                Id = userNamesId,
                UserID = 1,
                Status = true,
                FamilyName = "family",
                GivenName = "test",
                MiddleName = "test",
                NameUse = "test",
                Prefix = "test",
                Suffix = "test",
                PeriodEnd = DateTime.UtcNow,
                PeriodStart = DateTime.UtcNow,
                IsDeleted = false,
                CreatedBy = "Admin",
                CreatedDate = DateTime.UtcNow,
                UpdatedBy = "Admin",  // Adding the missing property
                UpdatedDate = DateTime.UtcNow,// Assuming UpdatedDate is required as well
            };

            // Mock the FindAsync method to return null (userNames not found)
            _readOnlyDbContextMock.Setup(db => db.UserNames.FindAsync(userNamesId))
                .ReturnsAsync(userNames);

            // Act
            var result = await _userNamesQueryService.FindUserNamesById(userNamesId);

            // Assert
            Assert.NotNull(result);
        }

        [Fact]
        public void GetUserNamesList_ReturnsCorrectUserNamesList()
        {
            // Act
            var result = _userNamesQueryService.GetUserNamesList();

            // Assert
            Assert.NotNull(result);
            Assert.Equal(2, result.Count); // Verifying that 3 items are returned

            // Verifying that the returned items are mapped correctly
            Assert.Contains(result, r => r.Id == 1 && r.GivenName == "test");
            Assert.Contains(result, r => r.Id == 2 && r.GivenName == "test");
        }

        [Fact]
        public async Task IsUserNamesAlreadyExist_ShouldReturnTrue_WhenuserNamesExists()
        {
            // Arrange
            var userNamesId = 1L;
            var userNames = new Domain.V1.Entities.Users.UserNames
            {
                Id = 1,
                UserID = 1,
                Status = true,
                FamilyName = "family",
                GivenName = "test",
                MiddleName = "test",
                NameUse = "test",
                Prefix = "test",
                Suffix = "test",
                PeriodEnd = DateTime.UtcNow,
                PeriodStart = DateTime.UtcNow,
                IsDeleted = false,
                CreatedBy = "Admin",
                CreatedDate = DateTime.UtcNow,
                UpdatedBy = "Admin",  // Adding the missing property
                UpdatedDate = DateTime.UtcNow,// Assuming UpdatedDate is required as well
            };

            // Mock the FindAsync method to return the userNames
            _readOnlyDbContextMock.Setup(db => db.UserNames.FindAsync(userNamesId))
                .ReturnsAsync(userNames);

            // Act
            var result = await _userNamesQueryService.IsUserNamesAlreadyExist(userNamesId);

            // Assert
            Assert.True(result.result);
            Assert.Equal(ResponseMessage.STATUS_DATA_FOUND, result.message);
        }

        [Fact]
        public async Task IsUserNamesAlreadyExist_ShouldReturnFalse_WhenuserNamesDoesNotExist()
        {
            // Arrange
            var userNamesId = 3;

            // Act
            var result = await _userNamesQueryService.IsUserNamesAlreadyExist(userNamesId);

            // Assert
            Assert.False(result.result);
            Assert.Equal(ResponseMessage.STATUS_NODATA, result.message);
        }
       
        [Fact]
        public async Task GetUserNamesByUserUniqueId_ReturnsDefault_WhenUserNameIsEmpty()
        {
            // Arrange: Create an in-memory database with a unique name
            var options = new DbContextOptionsBuilder<ReadOnlyDbContext>()
                .UseInMemoryDatabase(databaseName: Guid.NewGuid().ToString())
                .Options;

            using var context = new ReadOnlyDbContext(options);

            var service = new UserNamesQueryService(context, _mapperMock.Object); // Fix: use .Object for Mock

            // Act
            var result = await service.GetUserNamesByUserUniqueId(string.Empty); // FIXED: use local service

            // Assert
            Assert.False(result.Item1);
            Assert.Equal(0L, result.Item2.UserID);
            Assert.Equal(string.Empty, result.Item2.CreatedBy);
        }

    }


}

