﻿using Aurora.AdministrationService.API.Models.Dto.Users.UserTelecoms;
using Aurora.AdministrationService.API.Services.Service.Users.UserTelecoms;
using Aurora.AdministrationService.Infrastructure;
using AutoMapper;
using Microsoft.EntityFrameworkCore;
using Moq;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Aurora.AdministrationService.Tests.API.Services.Users.UserTelecoms
{
    public class UserTelecomCommandServiceTests
    {
        private readonly Mock<ReadWriteDbContext> _readWriteDbContextMock;
        private readonly Mock<ReadOnlyDbContext> _readOnlyDbContextMock;
        private readonly Mock<IMapper> _mapperMock;
        private UserTelecomCommandService _userTelecomCommandService;
        private readonly Mock<UserTelecomQueryService> _userTelecomQueryService;

        public UserTelecomCommandServiceTests()
        {
            // Initialize the mocks
            _mapperMock = new Mock<IMapper>();
            _readWriteDbContextMock = new Mock<ReadWriteDbContext>();
            _readOnlyDbContextMock = new Mock<ReadOnlyDbContext>();
            _userTelecomQueryService = new Mock<UserTelecomQueryService>();


            // Setup in-memory ready only database for testing
            DbContextOptions<ReadWriteDbContext> options = new DbContextOptionsBuilder<ReadWriteDbContext>()
              .UseInMemoryDatabase(databaseName: "AdminUserTelecomTestDB").Options;

            _readWriteDbContextMock = new(options);

            // Initialize the service being tested
            _userTelecomCommandService = new UserTelecomCommandService(_readWriteDbContextMock.Object, _mapperMock.Object);
        }

        [Fact]
        public async Task CreateUserTelecomAsync_ShouldReturnTrue_WhenUserTelecomIsCreatedSuccessfully()
        {
            // Arrange
            var newUserTelecom = new UserTelecomDto
            {
                UserID = 1,
                Status = true,
                System = "test",
                Value = "test",
                PeriodEnd = DateTime.UtcNow,
                PeriodStart = DateTime.UtcNow,
                Rank = 1,
                Use = "test",
            };

            // Mock AutoMapper to return a UserTelecom entity
            long userTelecomId = 1L;
            var userTelecomEntity = new Domain.V1.Entities.Users.UserTelecom
            {
                Id = userTelecomId,
                UserID = 1,
                Status = true,
                System = "test",
                Value = "test",
                PeriodEnd = DateTime.UtcNow,
                PeriodStart = DateTime.UtcNow,
                Rank = 1,
                Use = "test",
                IsDeleted = false,
                CreatedBy = "Admin",
                CreatedDate = DateTime.UtcNow,
                UpdatedBy = "Admin",  // Adding the missing property
                UpdatedDate = DateTime.UtcNow,// Assuming UpdatedDate is required as well
            };


            // Mock AutoMapper to return the UserTelecom entity
            _mapperMock.Setup(m => m.Map<Domain.V1.Entities.Users.UserTelecom>(newUserTelecom)).Returns(userTelecomEntity);

            // Mock DbContext to simulate saving the entity without actually hitting the database
            _readWriteDbContextMock.Setup(db => db.UserTelecoms.Add(It.IsAny<Domain.V1.Entities.Users.UserTelecom>()));

            // Act
            var result = await _userTelecomCommandService.CreateUserTelecomAsync(newUserTelecom);

            // Assert
            Assert.True(result);
            _readWriteDbContextMock.Verify(db => db.UserTelecoms.Add(It.Is<Domain.V1.Entities.Users.UserTelecom>(l => l.CreatedBy == "Admin")), Times.Once);
        }


        [Fact]
        public async Task CreateUserTelecomAsync_ShouldReturnFalse_WhenExceptionOccurs()
        {
            // Arrange
            var newUserTelecom = new UserTelecomDto
            {
                UserID = 1,
                Status = true,
                System = "test",
                Value = "test",
                PeriodEnd = DateTime.UtcNow,
                PeriodStart = DateTime.UtcNow,
                Rank = 1,
                Use = "test",
            };

            // Mock AutoMapper to return a UserTelecom entity
            var userTelecomId = 1;
            var userTelecomEntity = new Domain.V1.Entities.Users.UserTelecom
            {
                Id = userTelecomId,
                UserID = 1,
                Status = true,
                System = "test",
                Value = "test",
                PeriodEnd = DateTime.UtcNow,
                PeriodStart = DateTime.UtcNow,
                Rank = 1,
                Use = "test",
                IsDeleted = false,
                CreatedBy = "Admin",
                CreatedDate = DateTime.UtcNow,
                UpdatedBy = "Admin",  // Adding the missing property
                UpdatedDate = DateTime.UtcNow,// Assuming UpdatedDate is required as well
            };

            //Setup
            _mapperMock.Setup(m => m.Map<Domain.V1.Entities.Users.UserTelecom>(newUserTelecom)).Returns(userTelecomEntity);

            // Act
            var result = await _userTelecomCommandService.CreateUserTelecomAsync(newUserTelecom);

            // Assert
            Assert.False(result);
        }
        [Fact]
        public async Task Test_UpdateUserTelecom_Returns_Success()
        {
            //Arrange
            DbContextOptions<ReadWriteDbContext> options = new DbContextOptionsBuilder<ReadWriteDbContext>()
               .UseInMemoryDatabase(databaseName: "UpdateUserTelecom").Options;

            byte[] concurrencyToken = new byte[8] { byte.MinValue, byte.MinValue, byte.MinValue, byte.MinValue, byte.MinValue, byte.MinValue, byte.MinValue, byte.MaxValue };
            var userTelecom = new Domain.V1.Entities.Users.UserTelecom
            {
                Id = 1,
                UserID = 1,
                Status = true,
                System = "test",
                Value = "test",
                PeriodEnd = DateTime.UtcNow,
                PeriodStart = DateTime.UtcNow,
                Rank = 1,
                Use = "test",
                IsDeleted = false,
                CreatedBy = "Admin",
                CreatedDate = DateTime.UtcNow,
                UpdatedBy = "Admin",  // Adding the missing property
                UpdatedDate = DateTime.UtcNow,// Assuming UpdatedDate is required as well
                RecordVersion = concurrencyToken
            };


            //Arrange
            using ReadWriteDbContext dbContext = new(options);
            dbContext.UserTelecoms.Add(userTelecom);
            await dbContext.SaveChangesAsync();


            UpdateUserTelecomRequest updateModel = new UpdateUserTelecomRequest
            {
                Id = 1,
                UserID = 1,
                Status = true,
                System = "test",
                Value = "test",
                PeriodEnd = DateTime.UtcNow,
                PeriodStart = DateTime.UtcNow,
                Rank = 1,
                Use = "test",
                RecordVersion = concurrencyToken
            };

            updateModel.RecordVersion = userTelecom.RecordVersion;

            _userTelecomCommandService = new UserTelecomCommandService(dbContext, _mapperMock.Object);

            // Act
            bool result = await _userTelecomCommandService.UpdateUserTelecomAsync(updateModel, userTelecom);

            Assert.True(result);
        }
        [Fact]
        public async Task Test_DeleteUserTelecom_Returns_Success()
        {
            //Arrange
            DbContextOptions<ReadWriteDbContext> options = new DbContextOptionsBuilder<ReadWriteDbContext>()
               .UseInMemoryDatabase(databaseName: "DeleteUserTelecom").Options;

            byte[] concurrencyToken = new byte[8] { byte.MinValue, byte.MinValue, byte.MinValue, byte.MinValue, byte.MinValue, byte.MinValue, byte.MinValue, byte.MaxValue };
            var userTelecom = new Domain.V1.Entities.Users.UserTelecom
            {
                Id = 1,
                UserID = 1,
                Status = true,
                System = "test",
                Value = "test",
                PeriodEnd = DateTime.UtcNow,
                PeriodStart = DateTime.UtcNow,
                Rank = 1,
                Use = "test",
                IsDeleted = false,
                CreatedBy = "Admin",
                CreatedDate = DateTime.UtcNow,
                UpdatedBy = "Admin",  // Adding the missing property
                UpdatedDate = DateTime.UtcNow,// Assuming UpdatedDate is required as well
                RecordVersion = concurrencyToken
            };



            //Arrange
            using ReadWriteDbContext dbContext = new(options);
            dbContext.UserTelecoms.Add(userTelecom);
            await dbContext.SaveChangesAsync();

            _userTelecomCommandService = new UserTelecomCommandService(dbContext, _mapperMock.Object);

            // Act
            bool result = await _userTelecomCommandService.DeleteUserTelecomByIdAsync(concurrencyToken, userTelecom);

            Assert.True(result);
        }
    }
}
