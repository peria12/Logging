﻿using Aurora.AdministrationService.API.Enum;
using Aurora.AdministrationService.API.Models.Dto.Users.UserTelecoms;
using Aurora.AdministrationService.API.Services.Service.Users;
using Aurora.AdministrationService.API.Services.Service.Users.UserTelecoms;
using Aurora.AdministrationService.CrossCutting.CommonModels;
using Aurora.AdministrationService.Domain.V1.Entities.Users;
using Aurora.AdministrationService.Infrastructure;
using AutoMapper;
using FluentAssertions;
using Microsoft.EntityFrameworkCore;
using Moq;

namespace Aurora.AdministrationService.Tests.API.Services.Users.UserTelecoms
{
    public class UserTelecomQueryServiceTests
    {
        private readonly Mock<ReadOnlyDbContext> _readOnlyDbContextMock;
        private readonly Mock<IMapper> _mapperMock;
        private readonly UserTelecomQueryService _userTelecomQueryService;
        private Mock<DbSet<Domain.V1.Entities.Users.UserTelecom>> _mockDbSet;

        public UserTelecomQueryServiceTests()
        {
            //Initialize mock
            _readOnlyDbContextMock = new Mock<ReadOnlyDbContext>();
            _mapperMock = new Mock<IMapper>();

            // Setup in-memory ready only database for testing
            DbContextOptions<ReadOnlyDbContext> options = new DbContextOptionsBuilder<ReadOnlyDbContext>()
              .UseInMemoryDatabase(databaseName: "UserTelecomTestDB").Options;

            _readOnlyDbContextMock = new(options);

            _mockDbSet = new Mock<DbSet<Domain.V1.Entities.Users.UserTelecom>>();

            var data = new List<Domain.V1.Entities.Users.UserTelecom>
            {
               new Domain.V1.Entities.Users.UserTelecom {
                Id = 1,
                UserID = 1,
                Status = true,
                System = "test",
                Value = "test",
                PeriodEnd = DateTime.UtcNow,
                PeriodStart = DateTime.UtcNow,
                Rank= 1,
                Use="test",
                IsDeleted = false,
                CreatedBy = "Admin",
                CreatedDate = DateTime.UtcNow,
                UpdatedBy = "Admin",  // Adding the missing property
                UpdatedDate = DateTime.UtcNow,// Assuming UpdatedDate is required as well
            },
               new Domain.V1.Entities.Users.UserTelecom {
                Id = 2,
                UserID = 1,
                Status = true,
                System = "test",
                Value = "test",
                PeriodEnd = DateTime.UtcNow,
                PeriodStart = DateTime.UtcNow,
                Rank= 1,
                Use="test",
                IsDeleted = false,
                CreatedBy = "Admin",
                CreatedDate = DateTime.UtcNow,
                UpdatedBy = "Admin",  // Adding the missing property
                UpdatedDate = DateTime.UtcNow,// Assuming UpdatedDate is required as well
            }

            }.AsQueryable();


            //Setup
            _mockDbSet.As<IQueryable<Domain.V1.Entities.Users.UserTelecom>>().Setup(m => m.Provider).Returns(data.Provider);
            _mockDbSet.As<IQueryable<Domain.V1.Entities.Users.UserTelecom>>().Setup(m => m.Expression).Returns(data.Expression);
            _mockDbSet.As<IQueryable<Domain.V1.Entities.Users.UserTelecom>>().Setup(m => m.ElementType).Returns(data.ElementType);
            _mockDbSet.As<IQueryable<Domain.V1.Entities.Users.UserTelecom>>().Setup(m => m.GetEnumerator()).Returns(data.GetEnumerator());
            _readOnlyDbContextMock.Setup(c => c.UserTelecoms).Returns(_mockDbSet.Object);

            // Create the service instance
            _userTelecomQueryService = new UserTelecomQueryService(_readOnlyDbContextMock.Object, _mapperMock.Object);
        }

        [Fact]
        public async Task GetUserTelecomById_LogoExists_ReturnsLogoDetailDto()
        {
            // Arrange
            var userTelecomId = 1L;
            var userTelecom = new Domain.V1.Entities.Users.UserTelecom
            {
                Id = 1,
                UserID = 1,
                Status = true,
                System = "test",
                Value = "test",
                PeriodEnd = DateTime.UtcNow,
                PeriodStart = DateTime.UtcNow,
                Rank = 1,
                Use = "test",
                IsDeleted = false,
                CreatedBy = "Admin",
                CreatedDate = DateTime.UtcNow,
                UpdatedBy = "Admin",  // Adding the missing property
                UpdatedDate = DateTime.UtcNow,// Assuming UpdatedDate is required as well
            };
            byte[] concurrencyToken = new byte[8] { byte.MinValue, byte.MinValue, byte.MinValue, byte.MinValue, byte.MinValue, byte.MinValue, byte.MinValue, byte.MaxValue };

            var userTelecomDto = new GetUserTelecomDetailDto
            {
                Id = 1,
                UserID = 1,
                Status = true,
                System = "test",
                Value = "test",
                PeriodEnd = DateTime.UtcNow,
                PeriodStart = DateTime.UtcNow,
                Rank = 1,
                Use = "test",
                RecordVersion = concurrencyToken,
            };

            _readOnlyDbContextMock.Setup(db => db.UserTelecoms.FindAsync(userTelecomId))
                .ReturnsAsync(userTelecom);

            _mapperMock.Setup(m => m.Map<GetUserTelecomDetailDto>(userTelecom))
                .Returns(userTelecomDto);

            // Act
            var result = await _userTelecomQueryService.GetUserTelecomById(userTelecomId);

            // Assert
            Assert.NotNull(result);
            Assert.Equal(userTelecomId, result.Id);
            Assert.Equal("test", result.Value);
        }

        [Fact]
        public async Task GetUserTelecomById_userTelecomNotFound_ReturnsNull()
        {
            //Arrange
            var userTelecomId = 1;
            var userTelecom = new Domain.V1.Entities.Users.UserTelecom
            {
                Id = 1,
                UserID = 1,
                Status = true,
                System = "test",
                Value = "test",
                PeriodEnd = DateTime.UtcNow,
                PeriodStart = DateTime.UtcNow,
                Rank = 1,
                Use = "test",
                IsDeleted = false,
                CreatedBy = "Admin",
                CreatedDate = DateTime.UtcNow,
                UpdatedBy = "Admin",  // Adding the missing property
                UpdatedDate = DateTime.UtcNow,// Assuming UpdatedDate is required as well
            };

            _readOnlyDbContextMock.Setup(db => db.UserTelecoms.FindAsync(userTelecomId))
                .ReturnsAsync(userTelecom);

            //Act
            var result = await _userTelecomQueryService.GetUserTelecomById(userTelecomId);

            //Assert
            Assert.Null(result);
        }

        [Fact]
        public async Task GetUserTelecomById_userTelecomExists_BindingError_ReturnsNull()
        {
            // Arrange
            byte[] concurrencyToken = new byte[8] { byte.MinValue, byte.MinValue, byte.MinValue, byte.MinValue, byte.MinValue, byte.MinValue, byte.MinValue, byte.MaxValue };
            var userTelecomId = 1L;
            var userTelecom = new Domain.V1.Entities.Users.UserTelecom
            {
                Id = 1,
                UserID = 1,
                Status = true,
                System = "test",
                Value = "test",
                PeriodEnd = DateTime.UtcNow,
                PeriodStart = DateTime.UtcNow,
                Rank = 1,
                Use = "test",
                IsDeleted = false,
                CreatedBy = "Admin",
                CreatedDate = DateTime.UtcNow,
                UpdatedBy = "Admin",  // Adding the missing property
                UpdatedDate = DateTime.UtcNow,// Assuming UpdatedDate is required as well
                RecordVersion = concurrencyToken
            };

            _readOnlyDbContextMock.Setup(db => db.UserTelecoms.FindAsync(userTelecomId))
                .ReturnsAsync(userTelecom);

            _mapperMock.Setup(m => m.Map<GetUserTelecomDetailDto>(userTelecom))
                .Throws(new AutoMapperMappingException("Error mapping entity to DTO"));

            // Act & Assert
            var exception = await Assert.ThrowsAsync<AutoMapperMappingException>(
                () => _userTelecomQueryService.GetUserTelecomById(userTelecomId)
            );

            Assert.Equal("Error mapping entity to DTO", exception.Message);
        }

        [Fact]
        public async Task FindUserTelecomById_userTelecomExists_ReturnsuserTelecom()
        {
            // Arrange
            byte[] concurrencyToken = new byte[8] { byte.MinValue, byte.MinValue, byte.MinValue, byte.MinValue, byte.MinValue, byte.MinValue, byte.MinValue, byte.MaxValue };
            long userTelecomId = 1;
            var userTelecom = new Domain.V1.Entities.Users.UserTelecom
            {
                Id = userTelecomId,
                UserID = 1,
                Status = true,
                System = "test",
                Value = "test",
                PeriodEnd = DateTime.UtcNow,
                PeriodStart = DateTime.UtcNow,
                Rank = 1,
                Use = "test",
                IsDeleted = false,
                CreatedBy = "Admin",
                CreatedDate = DateTime.UtcNow,
                UpdatedBy = "Admin",  // Adding the missing property
                UpdatedDate = DateTime.UtcNow,// Assuming UpdatedDate is required as well
                RecordVersion = concurrencyToken
            };

            // Mock the FindAsync method to return the userTelecom
            _readOnlyDbContextMock.Setup(db => db.UserTelecoms.FindAsync(userTelecomId))
                .ReturnsAsync(userTelecom);

            // Act
            var result = await _userTelecomQueryService.FindUserTelecomById(userTelecomId);

            // Assert
            Assert.NotNull(result);
        }

        [Fact]
        public async Task FindUserTelecomById_userTelecomNotFound_ReturnsNull()
        {
            // Arrange
            var userTelecomId = 1L;
            var userTelecom = new Domain.V1.Entities.Users.UserTelecom
            {
                Id = userTelecomId,
                UserID = 1,
                Status = true,
                System = "test",
                Value = "test",
                PeriodEnd = DateTime.UtcNow,
                PeriodStart = DateTime.UtcNow,
                Rank = 1,
                Use = "test",
                IsDeleted = false,
                CreatedBy = "Admin",
                CreatedDate = DateTime.UtcNow,
                UpdatedBy = "Admin",  // Adding the missing property
                UpdatedDate = DateTime.UtcNow,// Assuming UpdatedDate is required as well
            };

            // Mock the FindAsync method to return null (userTelecom not found)
            _readOnlyDbContextMock.Setup(db => db.UserTelecoms.FindAsync(userTelecomId))
                .ReturnsAsync(userTelecom);

            // Act
            var result = await _userTelecomQueryService.FindUserTelecomById(userTelecomId);

            // Assert
            Assert.NotNull(result);
        }

        [Fact]
        public void GetUserTelecomList_ReturnsCorrectUserTelecomList()
        {
            // Act
            var result = _userTelecomQueryService.GetUserTelecomList();

            // Assert
            Assert.NotNull(result);
            Assert.Equal(2, result.Count); // Verifying that 3 items are returned

            // Verifying that the returned items are mapped correctly
            Assert.Contains(result, r => r.Id == 1 && r.Value == "test");
            Assert.Contains(result, r => r.Id == 2 && r.Value == "test");
        }
        [Fact]
        public void IsUserEmailIdAlreadyExist_NullEmailId_ReturnsFalse()
        {
            // Arrange
            string emailId = null;

            // Act
            var result = _userTelecomQueryService.IsUserEmailIdAlreadyExist(emailId);

            // Assert
            result.Should().BeFalse();
        }
        [Fact]
        public void IsUserPhoneNumberAlreadyExist_ShouldReturnTrue_WhenPhoneNumberExists()
        {
            // Arrange
            var options = new DbContextOptionsBuilder<ReadOnlyDbContext>()
                .UseInMemoryDatabase(databaseName: "PhoneExistsTestDB")
                .Options;

            using var context = new ReadOnlyDbContext(options);

            context.UserTelecoms.Add(new UserTelecom
            {
                Id = 1,
                UserID = 1,
                System = UserTelecomType.Phone.ToString(),
                Status = true,
                Value = "12345678",
                Use = "Mobile",
                IsDeleted = false,CreatedBy="admin",
                UpdatedBy="admin",
                CreatedDate=DateTime.Now,
            });

            context.SaveChanges();

          // or whichever service contains the method

            // Act
            var result = _userTelecomQueryService.IsUserPhoneNumberAlreadyExist("12345678");
            result.Should().BeFalse();
        }

        [Fact]
        public async Task IsUserTelecomAlreadyExist_ShouldReturnTrue_WhenuserTelecomExists()
        {
            // Arrange
            var userTelecomId = 1L;
            var userTelecom = new Domain.V1.Entities.Users.UserTelecom
            {
                Id = 1,
                UserID = 1,
                Status = true,
                System = "test",
                Value = "test",
                PeriodEnd = DateTime.UtcNow,
                PeriodStart = DateTime.UtcNow,
                Rank = 1,
                Use = "test",
                IsDeleted = false,
                CreatedBy = "Admin",
                CreatedDate = DateTime.UtcNow,
                UpdatedBy = "Admin",  // Adding the missing property
                UpdatedDate = DateTime.UtcNow,// Assuming UpdatedDate is required as well
            };

            // Mock the FindAsync method to return the userTelecom
            _readOnlyDbContextMock.Setup(db => db.UserTelecoms.FindAsync(userTelecomId))
                .ReturnsAsync(userTelecom);

            // Act
            var result = await _userTelecomQueryService.IsUserTelecomAlreadyExist(userTelecomId);

            // Assert
            Assert.True(result.result);
            Assert.Equal(ResponseMessage.STATUS_DATA_FOUND, result.message);
        }

        [Fact]
        public async Task IsUserTelecomAlreadyExist_ShouldReturnFalse_WhenuserTelecomDoesNotExist()
        {
            // Arrange
            var userTelecomId = 3;

            // Act
            var result = await _userTelecomQueryService.IsUserTelecomAlreadyExist(userTelecomId);

            // Assert
            Assert.False(result.result);
            Assert.Equal(ResponseMessage.STATUS_NODATA, result.message);
        }
    }
}
