﻿using Aurora.AdministrationService.API.Models.Dto.Users.ForgetPasswords;
using Aurora.AdministrationService.API.Services.Service.Users.ForgetPasswords;
using Aurora.AdministrationService.CrossCutting.CommonModels;
using Aurora.AdministrationService.Infrastructure;
using AutoMapper;
using Microsoft.EntityFrameworkCore;
using Moq;

namespace Aurora.AdministrationService.Tests.API.Services.Users.ForgetPasswords
{
    public class ForgetPasswordQueryServiceTests
    {
        private readonly Mock<ReadOnlyDbContext> _readOnlyDbContextMock;
        private readonly Mock<IMapper> _mapperMock;
        private readonly ForgetPasswordQueryService _forgetPasswordQueryService;
        private Mock<DbSet<Domain.V1.Entities.Users.ForgetPassword>> _mockDbSet;

        public ForgetPasswordQueryServiceTests()
        {
            //Initialize mock
            _readOnlyDbContextMock = new Mock<ReadOnlyDbContext>();
            _mapperMock = new Mock<IMapper>();

            // Setup in-memory ready only database for testing
            DbContextOptions<ReadOnlyDbContext> options = new DbContextOptionsBuilder<ReadOnlyDbContext>()
              .UseInMemoryDatabase(databaseName: "ForgetPasswordTestDB").Options;

            _readOnlyDbContextMock = new(options);

            _mockDbSet = new Mock<DbSet<Domain.V1.Entities.Users.ForgetPassword>>();

            var data = new List<Domain.V1.Entities.Users.ForgetPassword>
            {
               new Domain.V1.Entities.Users.ForgetPassword {
                Id = 1,
                UserID = 2,
                RequestedDate = DateTime.UtcNow,
                IsDeleted = false,
                CreatedBy = "Admin",
                CreatedDate = DateTime.UtcNow,
                UpdatedBy = "Admin",  // Adding the missing property
                UpdatedDate = DateTime.UtcNow,// Assuming UpdatedDate is required as well
            },
               new Domain.V1.Entities.Users.ForgetPassword {
                Id = 2,
                UserID = 2,
                RequestedDate = DateTime.UtcNow,
                IsDeleted = false,
                CreatedBy = "Admin",
                CreatedDate = DateTime.UtcNow,
                UpdatedBy = "Admin",  // Adding the missing property
                UpdatedDate = DateTime.UtcNow,// Assuming UpdatedDate is required as well
            }

            }.AsQueryable();


            //Setup
            _mockDbSet.As<IQueryable<Domain.V1.Entities.Users.ForgetPassword>>().Setup(m => m.Provider).Returns(data.Provider);
            _mockDbSet.As<IQueryable<Domain.V1.Entities.Users.ForgetPassword>>().Setup(m => m.Expression).Returns(data.Expression);
            _mockDbSet.As<IQueryable<Domain.V1.Entities.Users.ForgetPassword>>().Setup(m => m.ElementType).Returns(data.ElementType);
            _mockDbSet.As<IQueryable<Domain.V1.Entities.Users.ForgetPassword>>().Setup(m => m.GetEnumerator()).Returns(data.GetEnumerator());
            _readOnlyDbContextMock.Setup(c => c.ForgetPassword).Returns(_mockDbSet.Object);

            // Create the service instance
            _forgetPasswordQueryService = new ForgetPasswordQueryService(_readOnlyDbContextMock.Object, _mapperMock.Object);
        }

        [Fact]
        public async Task GetForgetPasswordById_LogoExists_ReturnsLogoDetailDto()
        {
            // Arrange
            var forgetPasswordId = 1L;
            var forgetPassword = new Domain.V1.Entities.Users.ForgetPassword
            {
                Id = 1,
                RequestedDate = DateTime.UtcNow,
                IsDeleted = false,
                CreatedBy = "Admin",
                CreatedDate = DateTime.UtcNow,
                UpdatedBy = "Admin",  // Adding the missing property
                UpdatedDate = DateTime.UtcNow,// Assuming UpdatedDate is required as well
            };
            byte[] concurrencyToken = new byte[8] { byte.MinValue, byte.MinValue, byte.MinValue, byte.MinValue, byte.MinValue, byte.MinValue, byte.MinValue, byte.MaxValue };

            var forgetPasswordDto = new GetForgetPasswordDetailDto
            {
                Id = 1,
                RequestedDate = DateTime.UtcNow,
                UserID = 2,
                RecordVersion = concurrencyToken,
            };

            _readOnlyDbContextMock.Setup(db => db.ForgetPassword.FindAsync(forgetPasswordId))
                .ReturnsAsync(forgetPassword);

            _mapperMock.Setup(m => m.Map<GetForgetPasswordDetailDto>(forgetPassword))
                .Returns(forgetPasswordDto);

            // Act
            var result = await _forgetPasswordQueryService.GetForgetPasswordById(forgetPasswordId);

            // Assert
            Assert.NotNull(result);
            Assert.Equal(forgetPasswordId, result.Id);
            Assert.Equal(2, result.UserID);
        }

        [Fact]
        public async Task GetForgetPasswordById_forgetPasswordNotFound_ReturnsNull()
        {
            //Arrange
            var forgetPasswordId = 1;
            var forgetPassword = new Domain.V1.Entities.Users.ForgetPassword
            {
                Id = 1,
                RequestedDate = DateTime.UtcNow,
                UserID = 2,
                IsDeleted = false,
                CreatedBy = "Admin",
                CreatedDate = DateTime.UtcNow,
                UpdatedBy = "Admin",  // Adding the missing property
                UpdatedDate = DateTime.UtcNow,// Assuming UpdatedDate is required as well
            };

            _readOnlyDbContextMock.Setup(db => db.ForgetPassword.FindAsync(forgetPasswordId))
                .ReturnsAsync(forgetPassword);

            //Act
            var result = await _forgetPasswordQueryService.GetForgetPasswordById(forgetPasswordId);

            //Assert
            Assert.Null(result);
        }

        [Fact]
        public async Task GetForgetPasswordById_forgetPasswordExists_BindingError_ReturnsNull()
        {
            // Arrange
            byte[] concurrencyToken = new byte[8] { byte.MinValue, byte.MinValue, byte.MinValue, byte.MinValue, byte.MinValue, byte.MinValue, byte.MinValue, byte.MaxValue };
            var forgetPasswordId = 1L;
            var forgetPassword = new Domain.V1.Entities.Users.ForgetPassword
            {
                Id = 1,
                RequestedDate = DateTime.UtcNow,
                UserID = 2,
                IsDeleted = false,
                CreatedBy = "Admin",
                CreatedDate = DateTime.UtcNow,
                UpdatedBy = "Admin",  // Adding the missing property
                UpdatedDate = DateTime.UtcNow,// Assuming UpdatedDate is required as well
                RecordVersion = concurrencyToken
            };

            _readOnlyDbContextMock.Setup(db => db.ForgetPassword.FindAsync(forgetPasswordId))
                .ReturnsAsync(forgetPassword);

            _mapperMock.Setup(m => m.Map<GetForgetPasswordDetailDto>(forgetPassword))
                .Throws(new AutoMapperMappingException("Error mapping entity to DTO"));

            // Act & Assert
            var exception = await Assert.ThrowsAsync<AutoMapperMappingException>(
                () => _forgetPasswordQueryService.GetForgetPasswordById(forgetPasswordId)
            );

            Assert.Equal("Error mapping entity to DTO", exception.Message);
        }

        [Fact]
        public async Task FindForgetPasswordById_forgetPasswordExists_ReturnsforgetPassword()
        {
            // Arrange
            byte[] concurrencyToken = new byte[8] { byte.MinValue, byte.MinValue, byte.MinValue, byte.MinValue, byte.MinValue, byte.MinValue, byte.MinValue, byte.MaxValue };
            long forgetPasswordId = 1;
            var forgetPassword = new Domain.V1.Entities.Users.ForgetPassword
            {
                Id = forgetPasswordId,
                RequestedDate = DateTime.UtcNow,
                UserID = 2,
                IsDeleted = false,
                CreatedBy = "Admin",
                CreatedDate = DateTime.UtcNow,
                UpdatedBy = "Admin",  // Adding the missing property
                UpdatedDate = DateTime.UtcNow,// Assuming UpdatedDate is required as well
                RecordVersion = concurrencyToken
            };

            // Mock the FindAsync method to return the forgetPassword
            _readOnlyDbContextMock.Setup(db => db.ForgetPassword.FindAsync(forgetPasswordId))
                .ReturnsAsync(forgetPassword);

            // Act
            var result = await _forgetPasswordQueryService.FindForgetPasswordById(forgetPasswordId);

            // Assert
            Assert.NotNull(result);
        }

        [Fact]
        public async Task FindForgetPasswordById_forgetPasswordNotFound_ReturnsNull()
        {
            // Arrange
            var forgetPasswordId = 1L;
            var forgetPassword = new Domain.V1.Entities.Users.ForgetPassword
            {
                Id = forgetPasswordId,
                RequestedDate = DateTime.UtcNow,
                UserID = 2,
                IsDeleted = false,
                CreatedBy = "Admin",
                CreatedDate = DateTime.UtcNow,
                UpdatedBy = "Admin",  // Adding the missing property
                UpdatedDate = DateTime.UtcNow,// Assuming UpdatedDate is required as well
            };

            // Mock the FindAsync method to return null (forgetPassword not found)
            _readOnlyDbContextMock.Setup(db => db.ForgetPassword.FindAsync(forgetPasswordId))
                .ReturnsAsync(forgetPassword);

            // Act
            var result = await _forgetPasswordQueryService.FindForgetPasswordById(forgetPasswordId);

            // Assert
            Assert.NotNull(result);
        }

        [Fact]
        public void GetForgetPasswordList_ReturnsCorrectForgetPasswordList()
        {
            // Act
            var result = _forgetPasswordQueryService.GetForgetPasswordList();

            // Assert
            Assert.NotNull(result);
            Assert.Equal(2, result.Count); // Verifying that 3 items are returned

            // Verifying that the returned items are mapped correctly
            Assert.Contains(result, r => r.Id == 1 && r.UserID == 2);
            Assert.Contains(result, r => r.Id == 2 && r.UserID == 2);
        }

        [Fact]
        public async Task IsForgetPasswordAlreadyExist_ShouldReturnTrue_WhenforgetPasswordExists()
        {
            // Arrange
            var forgetPasswordId = 1L;
            var forgetPassword = new Domain.V1.Entities.Users.ForgetPassword
            {
                Id = 1,
                RequestedDate = DateTime.UtcNow,
                UserID = 2,
                IsDeleted = false,
                CreatedBy = "Admin",
                CreatedDate = DateTime.UtcNow,
                UpdatedBy = "Admin",  // Adding the missing property
                UpdatedDate = DateTime.UtcNow,// Assuming UpdatedDate is required as well
            };

            // Mock the FindAsync method to return the forgetPassword
            _readOnlyDbContextMock.Setup(db => db.ForgetPassword.FindAsync(forgetPasswordId))
                .ReturnsAsync(forgetPassword);

            // Act
            var result = await _forgetPasswordQueryService.IsForgetPasswordAlreadyExist(forgetPasswordId);

            // Assert
            Assert.True(result.result);
            Assert.Equal(ResponseMessage.STATUS_DATA_FOUND, result.message);
        }

        [Fact]
        public async Task IsForgetPasswordAlreadyExist_ShouldReturnFalse_WhenforgetPasswordDoesNotExist()
        {
            // Arrange
            var forgetPasswordId = 3;

            // Act
            var result = await _forgetPasswordQueryService.IsForgetPasswordAlreadyExist(forgetPasswordId);

            // Assert
            Assert.False(result.result);
            Assert.Equal(ResponseMessage.STATUS_NODATA, result.message);
        }
    }
}
