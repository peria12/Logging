﻿using Aurora.AdministrationService.API.Models.Dto.Users.ForgetPasswords;
using Aurora.AdministrationService.API.Services.Service.Users.ForgetPasswords;
using Aurora.AdministrationService.Infrastructure;
using AutoMapper;
using Microsoft.EntityFrameworkCore;
using Moq;

namespace Aurora.AdministrationService.Tests.API.Services.Users.ForgetPasswords
{
    public class ForgetPasswordCommandServiceTests
    {
        private readonly Mock<ReadWriteDbContext> _readWriteDbContextMock;
        private readonly Mock<ReadOnlyDbContext> _readOnlyDbContextMock;
        private readonly Mock<IMapper> _mapperMock;
        private ForgetPasswordCommandService _forgetPasswordCommandService;
        private readonly Mock<ForgetPasswordQueryService> _forgetPasswordQueryService;

        public ForgetPasswordCommandServiceTests()
        {
            // Initialize the mocks
            _mapperMock = new Mock<IMapper>();
            _readWriteDbContextMock = new Mock<ReadWriteDbContext>();
            _readOnlyDbContextMock = new Mock<ReadOnlyDbContext>();
            _forgetPasswordQueryService = new Mock<ForgetPasswordQueryService>();


            // Setup in-memory ready only database for testing
            DbContextOptions<ReadWriteDbContext> options = new DbContextOptionsBuilder<ReadWriteDbContext>()
              .UseInMemoryDatabase(databaseName: "AdminForgetPasswordTestDB").Options;

            _readWriteDbContextMock = new(options);

            // Initialize the service being tested
            _forgetPasswordCommandService = new ForgetPasswordCommandService(_readWriteDbContextMock.Object, _mapperMock.Object);
        }

        [Fact]
        public async Task CreateForgetPasswordAsync_ShouldReturnTrue_WhenForgetPasswordIsCreatedSuccessfully()
        {
            // Arrange
            var newForgetPassword = new ForgetPasswordDto
            {
                UserID=1,
                RequestedDate= DateTime.UtcNow,
            };

            // Mock AutoMapper to return a ForgetPassword entity
            long forgetPasswordId = 1L;
            var forgetPasswordEntity = new Domain.V1.Entities.Users.ForgetPassword
            {
                Id = forgetPasswordId,
                RequestedDate = DateTime.UtcNow,
                IsDeleted = false,
                CreatedBy = "Admin",
                CreatedDate = DateTime.UtcNow,
                UpdatedBy = "Admin",  // Adding the missing property
                UpdatedDate = DateTime.UtcNow,// Assuming UpdatedDate is required as well
            };


            // Mock AutoMapper to return the ForgetPassword entity
            _mapperMock.Setup(m => m.Map<Domain.V1.Entities.Users.ForgetPassword>(newForgetPassword)).Returns(forgetPasswordEntity);

            // Mock DbContext to simulate saving the entity without actually hitting the database
            _readWriteDbContextMock.Setup(db => db.ForgetPassword.Add(It.IsAny<Domain.V1.Entities.Users.ForgetPassword>()));

            // Act
            var result = await _forgetPasswordCommandService.CreateForgetPasswordAsync(newForgetPassword);

            // Assert
            Assert.True(result);
            _readWriteDbContextMock.Verify(db => db.ForgetPassword.Add(It.Is<Domain.V1.Entities.Users.ForgetPassword>(l => l.CreatedBy == "Admin")), Times.Once);
        }


        [Fact]
        public async Task CreateForgetPasswordAsync_ShouldReturnFalse_WhenExceptionOccurs()
        {
            // Arrange
            var newForgetPassword = new ForgetPasswordDto
            {
                RequestedDate = DateTime.UtcNow,
            };

            // Mock AutoMapper to return a ForgetPassword entity
            var forgetPasswordId = 1;
            var forgetPasswordEntity = new Domain.V1.Entities.Users.ForgetPassword
            {
                Id = forgetPasswordId,
                RequestedDate = DateTime.UtcNow,
                IsDeleted = false,
                CreatedBy = "Admin",
                CreatedDate = DateTime.UtcNow,
                UpdatedBy = "Admin",  // Adding the missing property
                UpdatedDate = DateTime.UtcNow,// Assuming UpdatedDate is required as well
            };

            //Setup
            _mapperMock.Setup(m => m.Map<Domain.V1.Entities.Users.ForgetPassword>(newForgetPassword)).Returns(forgetPasswordEntity);

            // Act
            var result = await _forgetPasswordCommandService.CreateForgetPasswordAsync(newForgetPassword);

            // Assert
            Assert.False(result);
        }
        [Fact]
        public async Task Test_UpdateForgetPassword_Returns_Success()
        {
            //Arrange
            DbContextOptions<ReadWriteDbContext> options = new DbContextOptionsBuilder<ReadWriteDbContext>()
               .UseInMemoryDatabase(databaseName: "UpdateForgetPassword").Options;

            byte[] concurrencyToken = new byte[8] { byte.MinValue, byte.MinValue, byte.MinValue, byte.MinValue, byte.MinValue, byte.MinValue, byte.MinValue, byte.MaxValue };
            var forgetPassword = new Domain.V1.Entities.Users.ForgetPassword
            {
                Id = 1,
                RequestedDate = DateTime.UtcNow,
                IsDeleted = false,
                CreatedBy = "Admin",
                CreatedDate = DateTime.UtcNow,
                UpdatedBy = "Admin",  // Adding the missing property
                UpdatedDate = DateTime.UtcNow,// Assuming UpdatedDate is required as well
                RecordVersion = concurrencyToken
            };


            //Arrange
            using ReadWriteDbContext dbContext = new(options);
            dbContext.ForgetPassword.Add(forgetPassword);
            await dbContext.SaveChangesAsync();


            UpdateForgetPasswordRequest updateModel = new UpdateForgetPasswordRequest
            {
                Id = 1,
                RequestedDate = DateTime.UtcNow,
                RecordVersion = concurrencyToken
            };

            updateModel.RecordVersion = forgetPassword.RecordVersion;

            _forgetPasswordCommandService = new ForgetPasswordCommandService(dbContext, _mapperMock.Object);

            // Act
            bool result = await _forgetPasswordCommandService.UpdateForgetPasswordAsync(updateModel, forgetPassword);

            Assert.True(result);
        }
        [Fact]
        public async Task Test_DeleteForgetPassword_Returns_Success()
        {
            //Arrange
            DbContextOptions<ReadWriteDbContext> options = new DbContextOptionsBuilder<ReadWriteDbContext>()
               .UseInMemoryDatabase(databaseName: "DeleteForgetPassword").Options;

            byte[] concurrencyToken = new byte[8] { byte.MinValue, byte.MinValue, byte.MinValue, byte.MinValue, byte.MinValue, byte.MinValue, byte.MinValue, byte.MaxValue };
            var forgetPassword = new Domain.V1.Entities.Users.ForgetPassword
            {
                Id = 1,
                RequestedDate = DateTime.UtcNow,
                IsDeleted = false,
                CreatedBy = "Admin",
                CreatedDate = DateTime.UtcNow,
                UpdatedBy = "Admin",  // Adding the missing property
                UpdatedDate = DateTime.UtcNow,// Assuming UpdatedDate is required as well
                RecordVersion = concurrencyToken
            };



            //Arrange
            using ReadWriteDbContext dbContext = new(options);
            dbContext.ForgetPassword.Add(forgetPassword);
            await dbContext.SaveChangesAsync();

            _forgetPasswordCommandService = new ForgetPasswordCommandService(dbContext, _mapperMock.Object);

            // Act
            bool result = await _forgetPasswordCommandService.DeleteForgetPasswordByIdAsync(concurrencyToken, forgetPassword);

            Assert.True(result);
        }
    }
}
