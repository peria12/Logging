﻿using Aurora.AdministrationService.API.Models.Dto.Users;
using Aurora.AdministrationService.API.Services.Service.Users;
using Aurora.AdministrationService.Domain.V1.Entities.Users;
using Aurora.AdministrationService.Infrastructure;
using AutoMapper;
using Microsoft.EntityFrameworkCore;
using Moq;
using Microsoft.EntityFrameworkCore.Diagnostics;
using FluentAssertions;
using Microsoft.EntityFrameworkCore.Infrastructure;
using Microsoft.EntityFrameworkCore.Storage;
using Aurora.AdministrationService.CrossCutting.Constants;
using Aurora.AdministrationService.API.Enum;
using Aurora.AdministrationService.API.Services.IService.AzureBus;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.Options;
using Aurora.AdministrationService.API.Models.Dto.Users.PayLoads;
using Aurora.AdministrationService.CrossCutting.CommonModels;
using Microsoft.Extensions.Logging;
using Aurora.AdministrationService.API.Models.RequestModels.V1.User;

namespace Aurora.AdministrationService.Tests.API.Services.Users
{
    public class UserCommandServiceTests
    {
        private readonly Mock<ReadWriteDbContext> _readWriteDbContextMock;
        private readonly Mock<ReadOnlyDbContext> _readOnlyDbContextMock;
        private readonly Mock<IMapper> _mapperMock;
        private UserCommandService _userCommandService;
        private readonly Mock<UserQueryService> _userQueryService;
        private readonly Mock<DatabaseFacade> _databaseMock;
        private readonly Mock<IDbContextTransaction> _transactionMock;
        private readonly Mock<IAzureBusCommandServices> _azureBusCommandServicesMock;
        private readonly Mock<IConfiguration> _mockConfiguration;
        private readonly Mock<ILogger<UserCommandService>> _loggerMock;

        public UserCommandServiceTests()
        {

            _readOnlyDbContextMock = new Mock<ReadOnlyDbContext>();
            _mapperMock = new Mock<IMapper>();
            _userQueryService = new Mock<UserQueryService>();
            _azureBusCommandServicesMock = new Mock<IAzureBusCommandServices>();
            _mockConfiguration = new Mock<IConfiguration>();
            _transactionMock = new Mock<IDbContextTransaction>();
            _loggerMock = new Mock<ILogger<UserCommandService>>();





            // Initialize the mocks
            _mapperMock = new Mock<IMapper>();
            _readWriteDbContextMock = new Mock<ReadWriteDbContext>();
            _readOnlyDbContextMock = new Mock<ReadOnlyDbContext>();
            _userQueryService = new Mock<UserQueryService>();


            // Setup in-memory ready only database for testing
            DbContextOptions<ReadWriteDbContext> options = new DbContextOptionsBuilder<ReadWriteDbContext>()
              .UseInMemoryDatabase(databaseName: "AdminUserTestDB").Options;

            _readWriteDbContextMock = new(options);
            _databaseMock = new Mock<DatabaseFacade>(_readWriteDbContextMock.Object);
            // Initialize the service being tested
            _userCommandService = new UserCommandService(_readWriteDbContextMock.Object, _mapperMock.Object, _azureBusCommandServicesMock.Object, _mockConfiguration.Object, _loggerMock.Object);
        }

        [Fact]
        public async Task CreateUserAsync_ShouldReturnTrue_WhenUserIsCreatedSuccessfully()
        {
            // Arrange
            var newUser = new CreateUserRequest
            {
                UserName = "admin",
                Status = true,
                Gender = "Male",
                BirthDate = DateTime.UtcNow,
                ManagingOrganization = "1",
                Source = "Aurora",
                IsTempAccount = true,
                UserType = "Patient",
                Passcode = "1234",
                Language = 1,
                NotificationsEnabled = true,
                BioAuthenticationEnabled = true,
                SOSButtonEnabled = true,
                AppVersion = "v1",
                Password = "1234",
                IsMarketingConsentEnable = true,
                Salt = "salt",
                LocationEnable = true,
            };

            // Mock AutoMapper to return a User entity
            long userId = 1L;
            var userEntity = new Domain.V1.Entities.Users.User
            {
                Id = userId,
                UserName = "admin",
                Status = true,
                Gender = "Male",
                BirthDate = DateTime.UtcNow,
                ManagingOrganization = "1",
                Source = "Aurora",
                IsTempAccount = true,
                UserType = "Patient",
                Passcode = "1234",
                Language = 1,
                NotificationsEnabled = true,
                BioAuthenticationEnabled = true,
                SOSButtonEnabled = true,
                AppVersion = "v1",
                Password = "1234",
                IsMarketingConsentEnable = true,
                Salt = "salt",
                LocationEnable = true,
                IsDeleted = false,
                CreatedBy = "Admin",
                CreatedDate = DateTime.UtcNow,
                UpdatedBy = "Admin",  // Adding the missing property
                UpdatedDate = DateTime.UtcNow,// Assuming UpdatedDate is required as well
            };


            // Mock AutoMapper to return the User entity
            _mapperMock.Setup(m => m.Map<Domain.V1.Entities.Users.User>(newUser)).Returns(userEntity);

            // Mock DbContext to simulate saving the entity without actually hitting the database
            _readWriteDbContextMock.Setup(db => db.UserNew.Add(It.IsAny<Domain.V1.Entities.Users.User>()));

            // Act
            var result = await _userCommandService.CreateUserAsync(newUser);

            // Assert
            Assert.True(result);
            _readWriteDbContextMock.Verify(db => db.UserNew.Add(It.Is<Domain.V1.Entities.Users.User>(l => l.Source == "Aurora")), Times.Once);
        }

        [Fact]
        public async Task CreateUserAsync_ShouldReturnFalse_WhenExceptionOccurs()
        {
            // Arrange
            var newUser = new CreateUserRequest
            {
                UserName = "admin",
                Status = true,
                Gender = "Male",
                BirthDate = DateTime.UtcNow,
                ManagingOrganization = "1",
                Source = "Aurora",
                IsTempAccount = true,
                UserType = "Patient",
                Passcode = "1234",
                Language = 1,
                NotificationsEnabled = true,
                BioAuthenticationEnabled = true,
                SOSButtonEnabled = true,
                AppVersion = "v1",
                Password = "1234",
                IsMarketingConsentEnable = true,
                Salt = "salt",
                LocationEnable = true,
            };

            // Mock AutoMapper to return a User entity
            var userId = 1;
            var userEntity = new Domain.V1.Entities.Users.User
            {
                Id = userId,
                UserName = "admin",
                Status = true,
                Gender = "Male",
                BirthDate = DateTime.UtcNow,
                ManagingOrganization = "1",
                Source = "Aurora",
                IsTempAccount = true,
                UserType = "Patient",
                Passcode = "1234",
                Language = 1,
                NotificationsEnabled = true,
                BioAuthenticationEnabled = true,
                SOSButtonEnabled = true,
                AppVersion = "v1",
                Password = "1234",
                IsMarketingConsentEnable = true,
                Salt = "salt",
                LocationEnable = true,
                IsDeleted = false,
                CreatedBy = "Admin",
                CreatedDate = DateTime.UtcNow,
                UpdatedBy = "Admin",  // Adding the missing property
                UpdatedDate = DateTime.UtcNow,// Assuming UpdatedDate is required as well
            };

            //Setup
            _mapperMock.Setup(m => m.Map<Domain.V1.Entities.Users.User>(newUser)).Returns(userEntity);

            // Act
            var result = await _userCommandService.CreateUserAsync(newUser);

            // Assert
            Assert.False(result);
        }

        [Fact]
        public async Task Test_UpdateUser_Returns_Success()
        {
            //Arrange
            DbContextOptions<ReadWriteDbContext> options = new DbContextOptionsBuilder<ReadWriteDbContext>()
               .UseInMemoryDatabase(databaseName: "UpdateUser").Options;

            byte[] concurrencyToken = new byte[8] { byte.MinValue, byte.MinValue, byte.MinValue, byte.MinValue, byte.MinValue, byte.MinValue, byte.MinValue, byte.MaxValue };
            var user = new Domain.V1.Entities.Users.User
            {
                Id = 1,
                UserName = "admin",
                Status = true,
                Gender = "Male",
                BirthDate = DateTime.UtcNow,
                ManagingOrganization = "1",
                Source = "Aurora",
                IsTempAccount = true,
                UserType = "Patient",
                Passcode = "1234",
                Language = 1,
                NotificationsEnabled = true,
                BioAuthenticationEnabled = true,
                SOSButtonEnabled = true,
                AppVersion = "v1",
                Password = "1234",
                IsMarketingConsentEnable = true,
                Salt = "salt",
                LocationEnable = true,
                IsDeleted = false,
                CreatedBy = "Admin",
                CreatedDate = DateTime.UtcNow,
                UpdatedBy = "Admin",  // Adding the missing property
                UpdatedDate = DateTime.UtcNow,// Assuming UpdatedDate is required as well
                RecordVersion = concurrencyToken
            };
            //Arrange
            using ReadWriteDbContext dbContext = new(options);
            dbContext.UserNew.Add(user);
            await dbContext.SaveChangesAsync();
            UpdateUserRequest updateModel = new UpdateUserRequest
            {
                Id = 1,
                UserName = "admin",
                Status = true,
                Gender = "Male",
                BirthDate = DateTime.UtcNow,
                ManagingOrganization = "1",
                Source = "Aurora",
                IsTempAccount = true,
                UserType = "Patient",
                Passcode = "1234",
                Language = 1,
                NotificationsEnabled = true,
                BioAuthenticationEnabled = true,
                SOSButtonEnabled = true,
                AppVersion = "v1",
                Password = "1234",
                IsMarketingConsentEnable = true,
                Salt = "salt",
                LocationEnable = true,
                RecordVersion = concurrencyToken
            };

            updateModel.RecordVersion = user.RecordVersion;

            _userCommandService = new UserCommandService(dbContext, _mapperMock.Object, _azureBusCommandServicesMock.Object, _mockConfiguration.Object,_loggerMock.Object);

            // Act
            bool result = await _userCommandService.UpdateUserAsync(updateModel, user);

            Assert.True(result);
        }

        [Fact]
        public async Task Test_DeleteUser_Returns_Success()
        {
            //Arrange
            DbContextOptions<ReadWriteDbContext> options = new DbContextOptionsBuilder<ReadWriteDbContext>()
               .UseInMemoryDatabase(databaseName: "DeleteUser").Options;

            byte[] concurrencyToken = new byte[8] { byte.MinValue, byte.MinValue, byte.MinValue, byte.MinValue, byte.MinValue, byte.MinValue, byte.MinValue, byte.MaxValue };
            var user = new Domain.V1.Entities.Users.User
            {
                Id = 1,
                UserName = "admin",
                Status = true,
                Gender = "Male",
                BirthDate = DateTime.UtcNow,
                ManagingOrganization = "1",
                Source = "Aurora",
                IsTempAccount = true,
                UserType = "Patient",
                Passcode = "1234",
                Language = 1,
                NotificationsEnabled = true,
                BioAuthenticationEnabled = true,
                SOSButtonEnabled = true,
                AppVersion = "v1",
                Password = "1234",
                IsMarketingConsentEnable = true,
                Salt = "salt",
                LocationEnable = true,
                IsDeleted = false,
                CreatedBy = "Admin",
                CreatedDate = DateTime.UtcNow,
                UpdatedBy = "Admin",  // Adding the missing property
                UpdatedDate = DateTime.UtcNow,// Assuming UpdatedDate is required as well
                RecordVersion = concurrencyToken
            };

            //Arrange
            using ReadWriteDbContext dbContext = new(options);
            dbContext.UserNew.Add(user);
            await dbContext.SaveChangesAsync();

            _userCommandService = new UserCommandService(dbContext, _mapperMock.Object, _azureBusCommandServicesMock.Object, _mockConfiguration.Object, _loggerMock.Object);

            // Act
            bool result = await _userCommandService.DeleteUserByIdAsync(concurrencyToken, user);

            Assert.True(result);
        }

        [Fact]
        public async Task Test_UpdateUserSettingsAsync_Returns_Success()
        {
            //Arrange
            DbContextOptions<ReadWriteDbContext> options = new DbContextOptionsBuilder<ReadWriteDbContext>()
               .UseInMemoryDatabase(databaseName: "UpdateUserSettingsAsync").Options;

            byte[] concurrencyToken = new byte[8] { byte.MinValue, byte.MinValue, byte.MinValue, byte.MinValue, byte.MinValue, byte.MinValue, byte.MinValue, byte.MaxValue };
            var user = new Domain.V1.Entities.Users.User
            {
                Id = 1,
                UserName = "admin",
                Status = true,
                Gender = "Male",
                BirthDate = DateTime.UtcNow,
                ManagingOrganization = "1",
                Source = "Aurora",
                IsTempAccount = true,
                UserType = "Patient",
                Passcode = "1234",
                Language = 1,
                NotificationsEnabled = true,
                BioAuthenticationEnabled = true,
                SOSButtonEnabled = true,
                AppVersion = "v1",
                Password = "1234",
                IsMarketingConsentEnable = true,
                Salt = "salt",
                LocationEnable = true,
                IsDeleted = false,
                CreatedBy = "Admin",
                CreatedDate = DateTime.UtcNow,
                UpdatedBy = "Admin",  // Adding the missing property
                UpdatedDate = DateTime.UtcNow,// Assuming UpdatedDate is required as well
                RecordVersion = concurrencyToken
            };
            //Arrange
            using ReadWriteDbContext dbContext = new(options);
            dbContext.UserNew.Add(user);
            await dbContext.SaveChangesAsync();

            UserSettingDetailDto  userSettingDetailDto = new UserSettingDetailDto() { IsBioAuthenticationEnabled=true, IsMarketingConsentEnabled=true, IsNotificationsEnabled=true, IsSOSButtonEnabled=true };
            _userCommandService = new UserCommandService(dbContext, _mapperMock.Object, _azureBusCommandServicesMock.Object, _mockConfiguration.Object, _loggerMock.Object);

            // Act
            bool result = await _userCommandService.UpdateUserSettingsAsync(userSettingDetailDto, user);

            Assert.True(result);
        }

        [Fact]
        public async Task NewPatientSignupAsync_ShouldReturnTrue_WhenUserIsCreatedSuccessfully()
        {
            //Arrange
            DbContextOptions<ReadWriteDbContext> options = new DbContextOptionsBuilder<ReadWriteDbContext>()
                            .UseInMemoryDatabase(databaseName: "NewPatientSignup_DB")
                            .ConfigureWarnings(b => b.Ignore(InMemoryEventId.TransactionIgnoredWarning)).Options;

            byte[] concurrencyToken = new byte[8] { byte.MinValue, byte.MinValue, byte.MinValue, byte.MinValue, byte.MinValue, byte.MinValue, byte.MinValue, byte.MaxValue };
            using ReadWriteDbContext dbContext = new(options);

            // Initialize the service being tested
            _userCommandService = new UserCommandService(dbContext, _mapperMock.Object, _azureBusCommandServicesMock.Object, _mockConfiguration.Object, _loggerMock.Object);

            // Arrange
            var newUser = new PatientRegistrationRequest
            {
                Nationality = "Malaysian",
                IdentificationType = "Passport",
                PassportIssueCountry = "Malaysia",
                PhoneCountryCode = "+60",
                UHID = string.Empty,
                DateOfBirth = DateTime.UtcNow,
                CreatedAt = DateTime.UtcNow,
                UpdatedAt = DateTime.UtcNow,
                Email = "Test1223@gmail.com",
                Gender = "M",
                PassportExpiryDate = DateTime.UtcNow,
                IdentifierPassport = "1212121212",
                Name = "test",
                UserID = "1",
                Region = "MYS",
                PhoneNumber = "12121212"
            };

            // Mock AutoMapper to return a User entity
            long userId = 1L;
            var userEntity = new Domain.V1.Entities.Users.User
            {
                Id = userId,
                UserName = "admin",
                Status = true,
                Gender = "Male",
                BirthDate = DateTime.UtcNow,
                ManagingOrganization = "1",
                Source = "Aurora",
                IsTempAccount = true,
                UserType = "Patient",
                Passcode = "1234",
                Language = 1,
                NotificationsEnabled = true,
                BioAuthenticationEnabled = true,
                SOSButtonEnabled = true,
                AppVersion = "v1",
                Password = "1234",
                IsMarketingConsentEnable = true,
                Salt = "salt",
                LocationEnable = true,
                IsDeleted = false,
                CreatedBy = "Admin",
                CreatedDate = DateTime.UtcNow,
                UpdatedBy = "Admin",  // Adding the missing property
                UpdatedDate = DateTime.UtcNow,// Assuming UpdatedDate is required as well
            };



            // Act
            var result = await _userCommandService.NewPatientSignup(newUser);

            // Assert
            Assert.NotNull(result);
        }

        [Fact]
        public async Task RegisterPatientAsync_ShouldReturnError_WhenFirstSaveFails()
        {
            // Arrange
            var options = new DbContextOptionsBuilder<ReadWriteDbContext>()
                .UseInMemoryDatabase(databaseName: "NewPatientSignup_DB")
                .ConfigureWarnings(b => b.Ignore(InMemoryEventId.TransactionIgnoredWarning))
                .Options;

            using var dbContext = new ReadWriteDbContext(options);
            _userCommandService = new UserCommandService(dbContext, _mapperMock.Object, _azureBusCommandServicesMock.Object, _mockConfiguration.Object, _loggerMock.Object);

            var newUser = new PatientRegistrationRequest
            {
                Nationality = "",
                IdentificationType = "",
                PassportIssueCountry = "",
                PhoneCountryCode = "+",
                UHID = string.Empty,
                DateOfBirth = DateTime.UtcNow,
                CreatedAt = DateTime.UtcNow,
                UpdatedAt = DateTime.UtcNow,
                Email = "",
                Gender = "M",
                PassportExpiryDate = DateTime.UtcNow,
                IdentifierPassport = "",
                Name = "",
                UserID = "0",
                Region = "",
                PhoneNumber = ""
            };

            // Act
            var result = await _userCommandService.NewPatientSignup(newUser);

            // Assert
            result.Should().NotBeNull();
        }

        [Fact]
        public async Task NewPatientSignupAsync_ShouldReturnTrue_WhenUserRegisterWithIdentifierNumberCreatedSuccessfully()
        {
            // Arrange
            var options = new DbContextOptionsBuilder<ReadWriteDbContext>()
                .UseInMemoryDatabase(databaseName: "NewPatientSignupNew_DB")
                .ConfigureWarnings(b => b.Ignore(InMemoryEventId.TransactionIgnoredWarning))
                .Options;

            using var dbContext = new ReadWriteDbContext(options);
            _userCommandService = new UserCommandService(dbContext, _mapperMock.Object, _azureBusCommandServicesMock.Object, _mockConfiguration.Object, _loggerMock.Object);

            var newUser = new PatientRegistrationRequest
            {
                Nationality = "Malaysian",
                IdentificationType = "IC_Number",
                PhoneCountryCode = "+60",
                UHID = string.Empty,
                DateOfBirth = DateTime.UtcNow,
                CreatedAt = DateTime.UtcNow,
                UpdatedAt = DateTime.UtcNow,
                Email = "Test1223@gmail.com",
                Gender = "M",
                PassportExpiryDate = DateTime.UtcNow,
                Name = "test",
                UserID = "1",
                Region = "MYS",
                PhoneNumber = "12121212",
                PassportIssueCountry = "Malaysian",
                IdentifierNumber = "010101299993"
            };

            // Act
            var result = await _userCommandService.NewPatientSignup(newUser);

            // Assert
            result.Should().NotBeNull();
            result.UserUniqueId.Should().NotBeNullOrWhiteSpace();
        }

        #region Create User Test
        private static CreateUserRequestDto GetValidDto() => new()
        {
            UserName = "john_doe",
            Password = "securepassword",
            UserType = "Admin",
            UserGroup = "Operations",
            FirstName = "John",
            LastName = "Doe",
            Mobile = "9876543210",
            Email = "john@example.com",
            Gender = "Male",
            BirthDate = new DateTime(1990, 1, 1, 0, 0, 0, DateTimeKind.Utc)
        };

        private static Domain.V1.Entities.Users.User GetMappedUser() => new()
        {
            Id = 123,
            UserName = "john_doe",
            Status = true,
            UserType = "Admin",
            NotificationsEnabled = true,
            BioAuthenticationEnabled = false,
            SOSButtonEnabled = false,
            IsTempAccount = false,
            IsDeleted = false,
            CreatedBy = "test-user-id",
            CreatedDate = DateTime.UtcNow,
            UpdatedBy = "test-user-id",
            RecordVersion = Array.Empty<byte>()
        };

        [Fact]
        public async Task CreateAsync_ShouldCommit_WhenAllStepsSucceed()
        {
            // Arrange
            var dto = GetValidDto();
            var user = GetMappedUser();

            DbContextOptions<ReadWriteDbContext> options = new DbContextOptionsBuilder<ReadWriteDbContext>()
                          .UseInMemoryDatabase(databaseName: "CreateUser_DB1")
                          .ConfigureWarnings(b => b.Ignore(InMemoryEventId.TransactionIgnoredWarning)).Options;

            byte[] concurrencyToken = new byte[8] { byte.MinValue, byte.MinValue, byte.MinValue, byte.MinValue, byte.MinValue, byte.MinValue, byte.MinValue, byte.MaxValue };
            using ReadWriteDbContext dbContext = new(options);

            

            _mapperMock.Setup(m => m.Map<Domain.V1.Entities.Users.User>(dto))
                       .Returns(user);

            _databaseMock.Setup(d => d.BeginTransactionAsync(default))
                         .ReturnsAsync(_transactionMock.Object);

            _databaseMock.Setup(d => d.BeginTransactionAsync(It.IsAny<CancellationToken>()))
              .ReturnsAsync(_transactionMock.Object);

            _readWriteDbContextMock.Setup(x => x.UserNew.Add(It.IsAny<Domain.V1.Entities.Users.User>()));
            _readWriteDbContextMock.Setup(x => x.UserNames.AddRange(It.IsAny<IEnumerable<Domain.V1.Entities.Users.UserNames>>()));
            _readWriteDbContextMock.Setup(x => x.UserTelecoms.AddRange(It.IsAny<IEnumerable<Domain.V1.Entities.Users.UserTelecom>>()));

            _readWriteDbContextMock.SetupSequence(x => x.SaveChangesAsync(default))
                .ReturnsAsync(1) // user added
                .ReturnsAsync(1) // names added
                .ReturnsAsync(1); // telecoms added

            // Initialize the service being tested
            _userCommandService = new UserCommandService(dbContext, _mapperMock.Object, _azureBusCommandServicesMock.Object, _mockConfiguration.Object, _loggerMock.Object);
            // Act
            var result = await _userCommandService.CreateAsync(dto);

            // Assert
            Assert.True(result);
        }
               
        [Fact]
        public async Task CreateAsync_ShouldRollback_WhenExceptionOccurs()
        {
            var dto = GetValidDto();

            _mapperMock.Setup(m => m.Map<Domain.V1.Entities.Users.User>(dto))
                       .Throws(new Exception("mapping error"));

            _databaseMock.Setup(d => d.BeginTransactionAsync(default)).ReturnsAsync(_transactionMock.Object);

            DbContextOptions<ReadWriteDbContext> options = new DbContextOptionsBuilder<ReadWriteDbContext>()
                          .UseInMemoryDatabase(databaseName: "CreateUser_DB4")
                          .ConfigureWarnings(b => b.Ignore(InMemoryEventId.TransactionIgnoredWarning)).Options;

            byte[] concurrencyToken = new byte[8] { byte.MinValue, byte.MinValue, byte.MinValue, byte.MinValue, byte.MinValue, byte.MinValue, byte.MinValue, byte.MaxValue };
            using ReadWriteDbContext dbContext = new(options);

            // Initialize the service being tested
            _userCommandService = new UserCommandService(dbContext, _mapperMock.Object, _azureBusCommandServicesMock.Object, _mockConfiguration.Object, _loggerMock.Object);

            var result = await _userCommandService.CreateAsync(dto);

            Assert.False(result);
        }

        #endregion

        #region Reset Password Tests

        [Fact]
        public async Task ResetPassword_ValidUser_UpdatesPasswordAndReturnsTrue()
        {
            // Arrange
            byte[] concurrencyToken = new byte[8] { byte.MinValue, byte.MinValue, byte.MinValue, byte.MinValue, byte.MinValue, byte.MinValue, byte.MinValue, byte.MaxValue };

            var user = new Domain.V1.Entities.Users.User
            {
                Id = 1,
                UserName = "admin",
                Status = true,
                Gender = "Male",
                BirthDate = DateTime.UtcNow,
                ManagingOrganization = "1",
                Source = "Aurora",
                IsTempAccount = true,
                UserType = "Patient",
                Passcode = "1234",
                Language = 1,
                NotificationsEnabled = true,
                BioAuthenticationEnabled = true,
                SOSButtonEnabled = true,
                AppVersion = "v1",
                Password = "1234",
                IsMarketingConsentEnable = true,
                Salt = "salt",
                LocationEnable = true,
                IsDeleted = false,
                CreatedBy = "Admin",
                CreatedDate = DateTime.UtcNow,
                UpdatedBy = "Admin",  // Adding the missing property
                UpdatedDate = DateTime.UtcNow,// Assuming UpdatedDate is required as well
                RecordVersion = concurrencyToken
            };

            var request = new UserResetPasswordRequest
            {
                Id=1,
                password = "newsecurepassword"
            };

            var dbContextOptions = new DbContextOptionsBuilder<ReadWriteDbContext>()
                .UseInMemoryDatabase(databaseName: "ResetPasswordDb")
                .Options;

            using var context = new ReadWriteDbContext(dbContextOptions);
            context.UserNew.Add(user);
            await context.SaveChangesAsync();

            _userCommandService = new UserCommandService(context, _mapperMock.Object, _azureBusCommandServicesMock.Object, _mockConfiguration.Object, _loggerMock.Object);

            // Act
            var result = await _userCommandService.ResetPassword(request, user);

            // Assert
            result.Should().BeTrue();

            var updatedUser = await context.UserNew.FindAsync(user.Id);
            Assert.Equal("newsecurepassword", updatedUser.Password);
        }

        #endregion

        #region Update User Status

        [Fact]
        public async Task UpdateUserStatusAsync_ShouldReturnNotFound_WhenUserIsNull()
        {
            byte[] recordVersion = new byte[] { 1, 0, 0, 0 };
            // Arrange
            var updateRequest = new UpdateUserRequest { Status = true, BioAuthenticationEnabled = true, Id = 1, IsTempAccount = true, NotificationsEnabled = true, SOSButtonEnabled = true, UserName = "test1", UserType = "test2", RecordVersion = recordVersion };
            Domain.V1.Entities.Users.User user = null;

            // Act
            var result = await _userCommandService.UpdateUserStatusAsync(updateRequest, user);

            // Assert
            Assert.False(result.IsSuccess);
            Assert.Equal(Aurora.AdministrationService.CrossCutting.CommonModels.ResponseStatus.STATUS_NotFound, result.StatusCode);
            Assert.Equal("User not found.", result.Message);
            Assert.True(result.HasError);
        }

        [Fact]
        public async Task UpdateUserStatusAsync_ShouldReturnSuccess_WhenUserIsUpdatedSuccessfully()
        {
            byte[] recordVersion = new byte[] { 1, 0, 0, 0 };
            // Arrange
            var user = new Domain.V1.Entities.Users.User
            {
                Id = 1,
                Status = false,
                UserType = "UserType",
                BioAuthenticationEnabled = false,
                IsTempAccount = false,
                NotificationsEnabled = false,
                SOSButtonEnabled = false,
                UserName = "testUser",
                RecordVersion = recordVersion,
                CreatedBy = "Admin",
                CreatedDate = DateTime.UtcNow,
                IsDeleted = false,
                UpdatedBy = "Admin"

            };
            var updateRequest = new UpdateUserRequest
            {
                Status = true,
                BioAuthenticationEnabled = true,
                Id = 1,
                IsTempAccount = true,
                NotificationsEnabled = true,
                SOSButtonEnabled = true,
                UserName = "testUserUpdated",
                UserType = "UpdatedType",
                RecordVersion = recordVersion
            };

            _readWriteDbContextMock.Setup(db => db.UserNew.Update(It.IsAny<Domain.V1.Entities.Users.User>()));
            // Act
            var result = await _userCommandService.UpdateUserStatusAsync(updateRequest, user);

            // Assert
            Assert.True(result.IsSuccess);
            Assert.Equal(AdministrationService.CrossCutting.CommonModels.ResponseStatus.STATUS_SUCCESS, result.StatusCode);
            Assert.Equal("User status updated successfully.", result.Message);
            Assert.False(result.HasError);
        }

        [Fact]
        public async Task UpdateUserStatusAsync_ShouldReturnBadRequest_WhenDbUpdateConcurrencyExceptionOccurs()
        {
            byte[] recordVersion = new byte[] { 1, 0, 0, 0 };
            // Arrange
            var user = new Domain.V1.Entities.Users.User
            {
                Id = 1,
                Status = false,
                UserType = "UserType",
                BioAuthenticationEnabled = false,
                IsTempAccount = false,
                NotificationsEnabled = false,
                SOSButtonEnabled = false,
                UserName = "testUser",
                RecordVersion = recordVersion,
                CreatedBy = "Admin",
                CreatedDate = DateTime.UtcNow,
                IsDeleted = false,
                UpdatedBy = "Admin"

            };
            var updateRequest = new UpdateUserRequest
            {
                Status = true,
                BioAuthenticationEnabled = true,
                Id = 1,
                IsTempAccount = true,
                NotificationsEnabled = true,
                SOSButtonEnabled = true,
                UserName = "testUserUpdated",
                UserType = "UpdatedType",
                RecordVersion = recordVersion
            };

            _readWriteDbContextMock.Setup(db => db.UserNew.Update(It.IsAny<Domain.V1.Entities.Users.User>()))
                .Throws(new DbUpdateConcurrencyException());

            // Act
            var result = await _userCommandService.UpdateUserStatusAsync(updateRequest, user);

            // Assert
            Assert.False(result.IsSuccess);
            Assert.Equal(AdministrationService.CrossCutting.CommonModels.ResponseStatus.STATUS_BadRequest, result.StatusCode);
            Assert.Equal(CommonConstants.ERROR_DB_CONCURRENCY, result.Message);
            Assert.True(result.HasError);
        }

        [Fact]
        public async Task UpdateUserStatusAsync_ShouldReturnBadRequest_WhenUserIsInvalid()
        {
            byte[] recordVersion = new byte[] { 1, 0, 0, 0 };
            // Arrange
            Domain.V1.Entities.Users.User user = null;
            var updateRequest = new UpdateUserRequest
            {
                Status = true,
                BioAuthenticationEnabled = true,
                Id = 1,
                IsTempAccount = true,
                NotificationsEnabled = true,
                SOSButtonEnabled = true,
                UserName = "test1",
                UserType = "test2",
                RecordVersion = recordVersion
            };

            // Act
            var result = await _userCommandService.UpdateUserStatusAsync(updateRequest, user);

            // Assert
            Assert.False(result.IsSuccess);
            Assert.Equal(Aurora.AdministrationService.CrossCutting.CommonModels.ResponseStatus.STATUS_NotFound, result.StatusCode);
            Assert.Equal("User not found.", result.Message);
            Assert.True(result.HasError);
        }

        #endregion

        #region Update User Tests

        private static UpdateUserRequestDto GetValidUserDto() => new()
        {
            Id = 1,
            UserName = "testuser",
            Password = "password123",
            UserType = "Admin",
            UserGroup = "Group1",
            FirstName = "John",
            LastName = "Doe",
            Mobile = "1234567890",
            Email = "test@example.com",
            BirthDate = new DateTime(1990, 1, 1),
            Gender = "Male"
        };

        [Fact]
        public async Task UpdateAsync_ReturnsTrue_WhenEverythingSucceeds()
        {
            // Arrange
            var dto = GetValidUserDto();
            var userEntity = new Domain.V1.Entities.Users.User
            {
                Id = 1,
                BioAuthenticationEnabled = true,
                CreatedBy = string.Empty,
                CreatedDate = DateTime.UtcNow,
                IsDeleted = false,
                IsTempAccount = false,
                NotificationsEnabled = false,
                SOSButtonEnabled = false,
                Status = true,
                UpdatedBy = string.Empty,
                UserName = string.Empty,
                UserType = "Patient"
            };

            _mapperMock.Setup(m => m.Map<Domain.V1.Entities.Users.User>(dto)).Returns(userEntity);

            DbContextOptions<ReadWriteDbContext> options = new DbContextOptionsBuilder<ReadWriteDbContext>()
                           .UseInMemoryDatabase(databaseName: "UpdateUser1")
                           .ConfigureWarnings(b => b.Ignore(InMemoryEventId.TransactionIgnoredWarning)).Options;

            using var _context = new ReadWriteDbContext(options);
            _context.UserNew.Add(userEntity);

            _context.UserNames.Add(new Domain.V1.Entities.Users.UserNames
            {
                UserID = 1,
                NameUse = AdministrationService.API.Enum.UserName.FirstName.ToString(),
                GivenName = "OldFirst",
                IsDeleted = false,
                CreatedBy = "test-user-id",
                CreatedDate = DateTime.UtcNow,
                UpdatedBy = "test-user-id",
            });
            _context.UserNames.Add(new Domain.V1.Entities.Users.UserNames
            {
                UserID = 1,
                NameUse = AdministrationService.API.Enum.UserName.LastName.ToString(),
                GivenName = "OldLast",
                IsDeleted = false,
                CreatedBy = "test-user-id",
                CreatedDate = DateTime.UtcNow,
                UpdatedBy = "test-user-id",
            });
            _context.UserTelecoms.Add(new UserTelecom
            {
                UserID = 1,
                System = UserTelecomType.Email.ToString(),
                Value = "old@example.com",
                IsDeleted = false,
                 CreatedBy = "test-user-id",
                CreatedDate = DateTime.UtcNow,
                UpdatedBy = "test-user-id",
                Use = "abc"
            });
            _context.UserTelecoms.Add(new UserTelecom
            {
                UserID = 1,
                System = UserTelecomType.Phone.ToString(),
                Value = "0000000000",
                IsDeleted = false,
                CreatedBy = "test-user-id",
                CreatedDate = DateTime.UtcNow,
                UpdatedBy = "test-user-id",
                Use="abc"
            });

            await _context.SaveChangesAsync();

            _userCommandService = new UserCommandService(_context, _mapperMock.Object, _azureBusCommandServicesMock.Object, _mockConfiguration.Object, _loggerMock.Object);

            // Act
            var result = await _userCommandService.UpdateAsync(dto, userEntity);

            // Assert
            Assert.True(result);
        }

        [Fact]
        public async Task UpdateAsync_ReturnsFalse_WhenSavingUserFails()
        {
            var dto = GetValidUserDto();
            var mappedUser = new Domain.V1.Entities.Users.User
            {
                Id = 1,
                BioAuthenticationEnabled = true,
                CreatedBy = string.Empty,
                CreatedDate = DateTime.UtcNow,
                IsDeleted = false,
                IsTempAccount = false,
                NotificationsEnabled = false,
                SOSButtonEnabled = false,
                Status = true,
                UpdatedBy = string.Empty,
                UserName = string.Empty,
                UserType = "Patient"
            };
            ;

            _mapperMock.Setup(m => m.Map<Domain.V1.Entities.Users.User>(dto)).Returns(mappedUser);
            DbContextOptions<ReadWriteDbContext> options = new DbContextOptionsBuilder<ReadWriteDbContext>()
                           .UseInMemoryDatabase(databaseName: "UpdateUser4")
                           .ConfigureWarnings(b => b.Ignore(InMemoryEventId.TransactionIgnoredWarning)).Options;

            using var _context = new ReadWriteDbContext(options);
            _userCommandService = new UserCommandService(_context, _mapperMock.Object, _azureBusCommandServicesMock.Object, _mockConfiguration.Object, _loggerMock.Object);

            // Simulate failure by not adding user to context
            var result = await _userCommandService.UpdateAsync(dto, mappedUser);

            Assert.False(result);
        }

        [Fact]
        public async Task UpdateAsync_ReturnsFalse_WhenUpdateUserNamesFails()
        {
            // Arrange
            var dto = GetValidUserDto();
            var mappedUser = new Domain.V1.Entities.Users.User
            {
                Id = 1,
                BioAuthenticationEnabled = true,
                CreatedBy = string.Empty,
                CreatedDate = DateTime.UtcNow,
                IsDeleted = false,
                IsTempAccount = false,
                NotificationsEnabled = false,
                SOSButtonEnabled = false,
                Status = true,
                UpdatedBy = string.Empty,
                UserName = string.Empty,
                UserType = "Patient"
            };


            _mapperMock.Setup(m => m.Map<Domain.V1.Entities.Users.User>(dto)).Returns(mappedUser);

            DbContextOptions<ReadWriteDbContext> options = new DbContextOptionsBuilder<ReadWriteDbContext>()
                            .UseInMemoryDatabase(databaseName: "UpdateUser2")
                            .ConfigureWarnings(b => b.Ignore(InMemoryEventId.TransactionIgnoredWarning)).Options;

            using var _context = new ReadWriteDbContext(options);
            _context.UserNew.Add(mappedUser);

            // simulate failure by NOT adding any UserNames
            _userCommandService = new UserCommandService(_context, _mapperMock.Object, _azureBusCommandServicesMock.Object, _mockConfiguration.Object, _loggerMock.Object);
            var result = await _userCommandService.UpdateAsync(dto, mappedUser);

            Assert.False(result);
        }

        [Fact]
        public async Task UpdateAsync_ReturnsFalse_WhenUpdateUserTelecomsFails()
        {
            var dto = GetValidUserDto();
            var mappedUser = new Domain.V1.Entities.Users.User
            {
                Id = 1,
                BioAuthenticationEnabled = true,
                CreatedBy = string.Empty,
                CreatedDate = DateTime.UtcNow,
                IsDeleted = false,
                IsTempAccount = false,
                NotificationsEnabled = false,
                SOSButtonEnabled = false,
                Status = true,
                UpdatedBy = string.Empty,
                UserName = string.Empty,
                UserType = "Patient"
            };


            _mapperMock.Setup(m => m.Map<Domain.V1.Entities.Users.User>(dto)).Returns(mappedUser);

            DbContextOptions<ReadWriteDbContext> options = new DbContextOptionsBuilder<ReadWriteDbContext>()
                           .UseInMemoryDatabase(databaseName: "UpdateUser3")
                           .ConfigureWarnings(b => b.Ignore(InMemoryEventId.TransactionIgnoredWarning)).Options;

            using var _context = new ReadWriteDbContext(options);
            _context.UserNew.Add(mappedUser);

            // Add UserNames but no telecoms
            _context.UserNames.Add(new Domain.V1.Entities.Users.UserNames
            {
                UserID = 4,
                NameUse = AdministrationService.API.Enum.UserName.FirstName.ToString(),
                GivenName = "Test",
                IsDeleted = false,
                CreatedBy = "test-user-id",
                CreatedDate = DateTime.UtcNow,
                UpdatedBy = "test-user-id",
            });
            _context.UserNames.Add(new Domain.V1.Entities.Users.UserNames
            {
                UserID = 4,
                NameUse = AdministrationService.API.Enum.UserName.LastName.ToString(),
                GivenName = "Test",
                IsDeleted = false,
                CreatedBy = "test-user-id",
                CreatedDate = DateTime.UtcNow,
                UpdatedBy = "test-user-id",
            });

            await _context.SaveChangesAsync();

            // Simulate SaveChangesAsync returning 0 inside UpdateUserTelecoms by removing Save logic
            _context.ChangeTracker.Clear(); // make it forget previous state

            _userCommandService = new UserCommandService(_context, _mapperMock.Object, _azureBusCommandServicesMock.Object, _mockConfiguration.Object, _loggerMock.Object);
            var result = await _userCommandService.UpdateAsync(dto, mappedUser);

            Assert.False(result);
        }
       
        [Fact]
        public async Task UpdateAsync_ReturnsFalse_WhenSaveUserFails()
        {
            var dto = new UpdateUserRequestDto
            {
                Id = 1,
                UserName = "testuser",
                Password = "password123",
                UserType = "Admin",
                UserGroup = "Group1",
                FirstName = "John",
                LastName = "Doe",
                Mobile = "1234567890",
                Email = "test@example.com",
                BirthDate = new DateTime(1990, 1, 1),
                Gender = "Male"
            };

            var mappedUser = new Domain.V1.Entities.Users.User
            {
                Id = 1,
                BioAuthenticationEnabled = true,
                CreatedBy = string.Empty,
                CreatedDate = DateTime.UtcNow,
                IsDeleted = false,
                IsTempAccount = false,
                NotificationsEnabled = false,
                SOSButtonEnabled = false,
                Status = true,
                UpdatedBy = string.Empty,
                UserName = string.Empty,
                UserType = "Patient"
            };

            _mapperMock.Setup(x => x.Map<Domain.V1.Entities.Users.User>(dto)).Returns(mappedUser);

            DbContextOptions<ReadWriteDbContext> options = new DbContextOptionsBuilder<ReadWriteDbContext>()
                              .UseInMemoryDatabase(databaseName: "UpdateUser5")
                              .ConfigureWarnings(b => b.Ignore(InMemoryEventId.TransactionIgnoredWarning)).Options;

            using var context = new ReadWriteDbContext(options);
            context.UserNew.Add(mappedUser);
            await context.SaveChangesAsync();

            // Force failure by removing tracking
            context.ChangeTracker.Clear();

            _userCommandService = new UserCommandService(context, _mapperMock.Object, _azureBusCommandServicesMock.Object, _mockConfiguration.Object, _loggerMock.Object);

            var result = await _userCommandService.UpdateAsync(dto, mappedUser);

            Assert.False(result);
        }

        [Fact]
        public async Task UpdateAsync_ReturnsFalse_WhenExceptionOccurs()
        {
            var dto = new UpdateUserRequestDto 
            {
                Id = 1, UserName = "testuser", Password = "password123", UserType = "Admin", UserGroup = "Group1", 
                FirstName = "John", LastName = "Doe", Mobile = "1234567890", Email = "test@example.com", 
                BirthDate = new DateTime(1990, 1, 1), Gender = "Male" 
            };

            var mappedUser = new Domain.V1.Entities.Users.User
            {
                Id = 1,
                BioAuthenticationEnabled = true,
                CreatedBy = string.Empty,
                CreatedDate = DateTime.UtcNow,
                IsDeleted = false,
                IsTempAccount = false,
                NotificationsEnabled = false,
                SOSButtonEnabled = false,
                Status = true,
                UpdatedBy = string.Empty,
                UserName = string.Empty,
                UserType = "Patient"
            };

            DbContextOptions<ReadWriteDbContext> options = new DbContextOptionsBuilder<ReadWriteDbContext>()
                              .UseInMemoryDatabase(databaseName: "UpdateUser6")
                              .ConfigureWarnings(b => b.Ignore(InMemoryEventId.TransactionIgnoredWarning)).Options;

            using var context = new ReadWriteDbContext(options);
            context.UserNew.Add(mappedUser);
            await context.SaveChangesAsync();

            _mapperMock.Setup(x => x.Map<Domain.V1.Entities.Users.User>(dto))
                .Throws(new Exception("Unexpected"));

            _userCommandService = new UserCommandService(context, _mapperMock.Object, _azureBusCommandServicesMock.Object, _mockConfiguration.Object, _loggerMock.Object);

            var result = await _userCommandService.UpdateAsync(dto, mappedUser);

            Assert.False(result);
        }

        #endregion

        [Fact]
        public async Task Test_DeletePatientAccount_Returns_Success()
        {
            //Arrange
            DeletePatientAccountRequestDto deletePatientAccountRequestDto = new DeletePatientAccountRequestDto()
            {
                otherReason = string.Empty,
                selectedReason = string.Empty,
                LocationId = "KLAN",
                PatientMrnId = "KLAN-0000000001"
            };

            DbContextOptions<ReadWriteDbContext> options = new DbContextOptionsBuilder<ReadWriteDbContext>()
               .UseInMemoryDatabase(databaseName: "DeletePatientAccountDB").Options;

            byte[] concurrencyToken = new byte[8] { byte.MinValue, byte.MinValue, byte.MinValue, byte.MinValue, byte.MinValue, byte.MinValue, byte.MinValue, byte.MaxValue };
            var user = new Domain.V1.Entities.Users.User
            {
                Id = 1,
                UserName = "admin",
                UserType = (System.Enum.GetName(UserRoleType.Patient) ?? string.Empty),
                Status = true,
                Gender = "Male",
                BirthDate = DateTime.UtcNow,
                ManagingOrganization = "1",
                Source = "Aurora",
                IsTempAccount = true,
                Passcode = "1234",
                Language = 1,
                NotificationsEnabled = true,
                BioAuthenticationEnabled = true,
                SOSButtonEnabled = true,
                AppVersion = "v1",
                Password = "1234",
                IsMarketingConsentEnable = true,
                Salt = "salt",
                LocationEnable = true,
                IsDeleted = false,
                CreatedBy = "Admin",
                CreatedDate = DateTime.UtcNow,
                UpdatedBy = "Admin",  // Adding the missing property
                UpdatedDate = DateTime.UtcNow,// Assuming UpdatedDate is required as well
                RecordVersion = concurrencyToken
            };

            //Arrange
            using ReadWriteDbContext dbContext = new(options);
            dbContext.UserNew.Add(user);
            await dbContext.SaveChangesAsync();

            _azureBusCommandServicesMock.Setup(x => x.SendData(It.IsAny<DeletePatientAccountPayloadDto>(),"MYS", It.IsAny<string>()))
               .ReturnsAsync(new GenericResponse<string>
               {
                   IsSuccess = true,
                   HasError = false,
               } );

            _userCommandService = new UserCommandService(dbContext, _mapperMock.Object, _azureBusCommandServicesMock.Object, _mockConfiguration.Object, _loggerMock.Object);

            // Act
            bool result = await _userCommandService.DeletePatientAccountAsync(user, deletePatientAccountRequestDto, "MYS");

            Assert.True(result);
        }
        [Fact]
        public async Task Test_DeletePatientAccount_Returns_Fail()
        {
            //Arrange
            DeletePatientAccountRequestDto deletePatientAccountRequestDto = new DeletePatientAccountRequestDto()
            {
                otherReason = string.Empty,
                selectedReason = string.Empty,
                LocationId = "KLAN",
                PatientMrnId = "KLAN-0000000001"
            };

            DbContextOptions<ReadWriteDbContext> options = new DbContextOptionsBuilder<ReadWriteDbContext>()
               .UseInMemoryDatabase(databaseName: "DeletePatientAccountNewDB").Options;

            byte[] concurrencyToken = new byte[8] { byte.MinValue, byte.MinValue, byte.MinValue, byte.MinValue, byte.MinValue, byte.MinValue, byte.MinValue, byte.MaxValue };
            var user = new Domain.V1.Entities.Users.User
            {
                Id = 1,
                UserName = "admin",
                UserType = (System.Enum.GetName(UserRoleType.Practitioner) ?? string.Empty),
                Status = true,
                Gender = "Male",
                BirthDate = DateTime.UtcNow,
                ManagingOrganization = "1",
                Source = "Aurora",
                IsTempAccount = true,
                Passcode = "1234",
                Language = 1,
                NotificationsEnabled = true,
                BioAuthenticationEnabled = true,
                SOSButtonEnabled = true,
                AppVersion = "v1",
                Password = "1234",
                IsMarketingConsentEnable = true,
                Salt = "salt",
                LocationEnable = true,
                IsDeleted = false,
                CreatedBy = "Admin",
                CreatedDate = DateTime.UtcNow,
                UpdatedBy = "Admin",  // Adding the missing property
                UpdatedDate = DateTime.UtcNow,// Assuming UpdatedDate is required as well
                RecordVersion = concurrencyToken
            };

            //Arrange
            using ReadWriteDbContext dbContext = new(options);
            dbContext.UserNew.Add(user);
            await dbContext.SaveChangesAsync();

            _userCommandService = new UserCommandService(dbContext, _mapperMock.Object, _azureBusCommandServicesMock.Object, _mockConfiguration.Object, _loggerMock.Object);

            // Act
            bool result = await _userCommandService.DeletePatientAccountAsync(user, deletePatientAccountRequestDto, "MYS");

            Assert.False(result);
        }

        [Fact]
        public async Task DeletePatientAccountServiceBusConnect_ShouldSuccess()
        {
            //Arrange
            var deletePatientAccountPayloadDto = new DeletePatientAccountPayloadDto()
            {
                PatientID = "1",
                PatientIDResourceId = "CFDRERY",
                LocationId = "KLAN",
                PatientMrnId = "KLNA_0000000001",
                Reason = string.Empty
            };
            _azureBusCommandServicesMock.Setup(x => x.SendData(It.IsAny<DeletePatientAccountPayloadDto>(), "MYS", It.IsAny<string>()))
              .ReturnsAsync(new GenericResponse<string>
              {
                  IsSuccess = true,
                  HasError = false,
              });

            // Act
            var result = await _userCommandService.DeletePatientAccountServiceBusConnect(deletePatientAccountPayloadDto,"MYS");

            // Assert
            Assert.Equal(1, result);

        }
        [Fact]
        public async Task DeletePatientAccountServiceBusConnect_ShouldFail()
        {
            //Arrange
            var deletePatientAccountPayloadDto = new DeletePatientAccountPayloadDto()
            {
                PatientID = "1",
                PatientIDResourceId = "CFDRERY",
                LocationId = "KLAN",
                PatientMrnId = "KLNA_0000000001",
                Reason = string.Empty
            };
            _azureBusCommandServicesMock.Setup(x => x.SendData(It.IsAny<DeletePatientAccountPayloadDto>(), "MYS", It.IsAny<string>()))
              .ReturnsAsync(new GenericResponse<string>
              {
                  IsSuccess = false,
                  HasError = true,
              });

            // Act
            var result = await _userCommandService.DeletePatientAccountServiceBusConnect(deletePatientAccountPayloadDto, "MYS");

            // Assert
            Assert.Equal(0, result);

        }

        #region Enable Bio Matric Authentication
        [Fact]
        public async Task UpdateBiometricSettingAsync_UserNotFound_ReturnsFalse()
        {
            // Arrange
            var userId = 99; // Non-existing user ID
            var dbContextOptions = new DbContextOptionsBuilder<ReadWriteDbContext>()
                .UseInMemoryDatabase(databaseName: "BiometricUpdate_UserNotFound")
                .Options;

            using var context = new ReadWriteDbContext(dbContextOptions);

            var service = new UserCommandService(context, _mapperMock.Object, _azureBusCommandServicesMock.Object, _mockConfiguration.Object, _loggerMock.Object);

            // Act
            var result = await service.UpdateBiometricSettingAsync(userId, true);

            // Assert
            result.Should().BeFalse(); // Since the user is not found, it should return false
        }

        #endregion

        #region Create Passcode
        [Fact]
        public async Task CreatePasscodeAsync_ShouldReturnBadRequest_WhenPasscodesDoNotMatch()
        {
            // Arrange
            var request = new CreatePasscodeRequest
            {
                Passcode = "123456",
                ConfirmPasscode = "654321"
            };
            int userId = 1;

            // Act
            var result = await _userCommandService.CreatePasscodeAsync(request, userId);

            // Assert
            result.Should().NotBeNull();
            result.HasError.Should().BeTrue();
            result.IsSuccess.Should().BeFalse();
            result.StatusCode.Should().Be(ResponseStatus.STATUS_BadRequest);
            result.Message.Should().Be("Passcodes do not match.");
            result.Result.Should().BeNull();
        }
        [Fact]
        public async Task CreatePasscodeAsync_ShouldReturnBadRequest_WhenPasscodeLengthIsInvalid()
        {
            var request = new CreatePasscodeRequest
            {
                Passcode = "123",
                ConfirmPasscode = "123"
            };
            int userId = 1;

            var result = await _userCommandService.CreatePasscodeAsync(request, userId);

            result.HasError.Should().BeTrue();
            result.IsSuccess.Should().BeFalse();
            result.StatusCode.Should().Be(ResponseStatus.STATUS_BadRequest);
            result.Message.Should().Be("Passcode must be exactly 6 digits.");
        }

        [Fact]
        public async Task CreatePasscodeAsync_ShouldReturnBadRequest_WhenUserIsNotFound()
        {
            var options = new DbContextOptionsBuilder<ReadWriteDbContext>()
                .UseInMemoryDatabase(databaseName: Guid.NewGuid().ToString())
                .Options;

            await using var dbContext = new ReadWriteDbContext(options);
            var service = new UserCommandService(dbContext, _mapperMock.Object, _azureBusCommandServicesMock.Object, _mockConfiguration.Object, _loggerMock.Object);

            var request = new CreatePasscodeRequest
            {
                Passcode = "123456",
                ConfirmPasscode = "123456"
            };
            int userId = 999; // user not found

            var result = await service.CreatePasscodeAsync(request, userId);

            result.HasError.Should().BeTrue();
            result.StatusCode.Should().Be(ResponseStatus.STATUS_BadRequest);
            result.Message.Should().Be("User not found.");
        }
        [Fact]
        public async Task CreatePasscodeAsync_ShouldUpdateUserAndReturnSuccess_WhenUserFound()
        {
            var options = new DbContextOptionsBuilder<ReadWriteDbContext>()
                .UseInMemoryDatabase(Guid.NewGuid().ToString())
                .Options;

            await using var dbContext = new ReadWriteDbContext(options);
            var service = new UserCommandService(dbContext, _mapperMock.Object, _azureBusCommandServicesMock.Object, _mockConfiguration.Object, _loggerMock.Object);

            var user = new Domain.V1.Entities.Users.User
            {
                Id = 1,
                UserName = "Test",
                CreatedBy = "Admin",
                CreatedDate = DateTime.UtcNow,
                BioAuthenticationEnabled = true,
                IsDeleted = false,
                IsTempAccount = false,
                NotificationsEnabled = false,
                SOSButtonEnabled = false,
                Status = false,
                UpdatedBy = "Admin",
                UserType = "test",

            };

            await dbContext.UserNew.AddAsync(user);
            await dbContext.SaveChangesAsync();

            var request = new CreatePasscodeRequest
            {
                Passcode = "123456",
                ConfirmPasscode = "123456"
            };

            int userId = 1;

            var result = await service.CreatePasscodeAsync(request, userId);

            result.HasError.Should().BeFalse();
            result.IsSuccess.Should().BeTrue();
            result.StatusCode.Should().Be(ResponseStatus.STATUS_SUCCESS_Create);
            result.Message.Should().Be("Passcode created successfully!");
            result.Result.Should().NotBeNull();

            var updatedUser = await dbContext.UserNew.FirstOrDefaultAsync(u => u.Id == 1);
            updatedUser.Passcode.Should().Be(result.Result);
            updatedUser.UpdatedBy.Should().Be("System");
        }

        [Fact]
        public async Task CreatePasscodeAsync_ShouldHandleException_AndReturnInternalServerError()
        {
            // Arrange
            var loggerMock = new Mock<ILogger<UserCommandService>>();

            var options = new DbContextOptionsBuilder<ReadWriteDbContext>()
                .UseInMemoryDatabase(Guid.NewGuid().ToString())
                .Options;

            var dbContextMock = new Mock<ReadWriteDbContext>(options);
            dbContextMock.Setup(db => db.SaveChangesAsync(It.IsAny<CancellationToken>()))
                         .ThrowsAsync(new Exception("Simulated DB failure"));

            var service = new UserCommandService(
                dbContextMock.Object,
                _mapperMock.Object,
                _azureBusCommandServicesMock.Object,
                _mockConfiguration.Object,
                loggerMock.Object
            );

            var request = new CreatePasscodeRequest
            {
                Passcode = "123456",
                ConfirmPasscode = "123456"
            };

            int userId = 1;

            // Act
            var result = await service.CreatePasscodeAsync(request, userId);

            // Assert
            result.Should().NotBeNull();
            result.HasError.Should().BeTrue();
            result.StatusCode.Should().Be(ResponseStatus.STATUS_InternalServerError); // 500
            result.Message.Should().Be("Failed to create passcode.");
            loggerMock.Verify(
                x => x.Log(
                    LogLevel.Error,
                    It.IsAny<EventId>(),
                    It.Is<It.IsAnyType>((v, t) => v.ToString().Contains("An error occurred while creating the passcode.")),
                    It.IsAny<Exception>(),
                    It.IsAny<Func<It.IsAnyType, Exception, string>>()),
                Times.Once);
        }

        #endregion
    }
}
