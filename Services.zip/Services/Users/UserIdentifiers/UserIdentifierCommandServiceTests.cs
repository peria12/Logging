﻿using Aurora.AdministrationService.API.Models.Dto.Users.UserIdentifiers;
using Aurora.AdministrationService.API.Services.Service.Users.UserIdentifiers;
using Aurora.AdministrationService.Infrastructure;
using AutoMapper;
using Microsoft.EntityFrameworkCore;
using Moq;

namespace Aurora.AdministrationService.Tests.API.Services.Users.UserIdentifiers
{
    public class UserIdentifierCommandServiceTests
    {
        private readonly Mock<ReadWriteDbContext> _readWriteDbContextMock;
        private readonly Mock<ReadOnlyDbContext> _readOnlyDbContextMock;
        private readonly Mock<IMapper> _mapperMock;
        private UserIdentifierCommandService _userIdentifierCommandService;
        private readonly Mock<UserIdentifierQueryService> _userIdentifierQueryService;

        public UserIdentifierCommandServiceTests()
        {
            // Initialize the mocks
            _mapperMock = new Mock<IMapper>();
            _readWriteDbContextMock = new Mock<ReadWriteDbContext>();
            _readOnlyDbContextMock = new Mock<ReadOnlyDbContext>();
            _userIdentifierQueryService = new Mock<UserIdentifierQueryService>();


            // Setup in-memory ready only database for testing
            DbContextOptions<ReadWriteDbContext> options = new DbContextOptionsBuilder<ReadWriteDbContext>()
              .UseInMemoryDatabase(databaseName: "AdminUserIdentifierTestDB").Options;

            _readWriteDbContextMock = new(options);

            // Initialize the service being tested
            _userIdentifierCommandService = new UserIdentifierCommandService(_readWriteDbContextMock.Object, _mapperMock.Object);
        }

        [Fact]
        public async Task CreateUserIdentifierAsync_ShouldReturnTrue_WhenUserIdentifierIsCreatedSuccessfully()
        {
            // Arrange
            var newUserIdentifier = new UserIdentifierDto
            {
                UserID = 1,
                Status = true,
                IdentifierType = "type",
                IdentifierUse = "use",
                System = "test",
                Value = "test",
                PeriodEnd = DateTime.UtcNow,
                PeriodStart = DateTime.UtcNow,
            };

            // Mock AutoMapper to return a UserIdentifier entity
            long userIdentifierId = 1L;
            var userIdentifierEntity = new Domain.V1.Entities.Users.UserIdentifier
            {
                Id = userIdentifierId,
                UserID = 1,
                Status = true,
                IdentifierType = "type",
                IdentifierUse = "use",
                System = "test",
                Value = "test",
                PeriodEnd = DateTime.UtcNow,
                PeriodStart = DateTime.UtcNow,
                IsDeleted = false,
                CreatedBy = "Admin",
                CreatedDate = DateTime.UtcNow,
                UpdatedBy = "Admin",  // Adding the missing property
                UpdatedDate = DateTime.UtcNow,// Assuming UpdatedDate is required as well
            };


            // Mock AutoMapper to return the UserIdentifier entity
            _mapperMock.Setup(m => m.Map<Domain.V1.Entities.Users.UserIdentifier>(newUserIdentifier)).Returns(userIdentifierEntity);

            // Mock DbContext to simulate saving the entity without actually hitting the database
            _readWriteDbContextMock.Setup(db => db.UserIdentifiers.Add(It.IsAny<Domain.V1.Entities.Users.UserIdentifier>()));

            // Act
            var result = await _userIdentifierCommandService.CreateUserIdentifierAsync(newUserIdentifier);

            // Assert
            Assert.True(result);
            _readWriteDbContextMock.Verify(db => db.UserIdentifiers.Add(It.Is<Domain.V1.Entities.Users.UserIdentifier>(l => l.CreatedBy == "Admin")), Times.Once);
        }


        [Fact]
        public async Task CreateUserIdentifierAsync_ShouldReturnFalse_WhenExceptionOccurs()
        {
            // Arrange
            var newUserIdentifier = new UserIdentifierDto
            {
                UserID = 1,
                Status = true,
                IdentifierType = "type",
                IdentifierUse = "use",
                System = "test",
                Value = "test",
                PeriodEnd = DateTime.UtcNow,
                PeriodStart = DateTime.UtcNow,
            };

            // Mock AutoMapper to return a UserIdentifier entity
            var userIdentifierId = 1;
            var userIdentifierEntity = new Domain.V1.Entities.Users.UserIdentifier
            {
                Id = userIdentifierId,
                UserID = 1,
                Status = true,
                IdentifierType = "type",
                IdentifierUse = "use",
                System = "test",
                Value = "test",
                PeriodEnd = DateTime.UtcNow,
                PeriodStart = DateTime.UtcNow,
                IsDeleted = false,
                CreatedBy = "Admin",
                CreatedDate = DateTime.UtcNow,
                UpdatedBy = "Admin",  // Adding the missing property
                UpdatedDate = DateTime.UtcNow,// Assuming UpdatedDate is required as well
            };

            //Setup
            _mapperMock.Setup(m => m.Map<Domain.V1.Entities.Users.UserIdentifier>(newUserIdentifier)).Returns(userIdentifierEntity);

            // Act
            var result = await _userIdentifierCommandService.CreateUserIdentifierAsync(newUserIdentifier);

            // Assert
            Assert.False(result);
        }
        [Fact]
        public async Task Test_UpdateUserIdentifier_Returns_Success()
        {
            //Arrange
            DbContextOptions<ReadWriteDbContext> options = new DbContextOptionsBuilder<ReadWriteDbContext>()
               .UseInMemoryDatabase(databaseName: "UpdateUserIdentifier").Options;

            byte[] concurrencyToken = new byte[8] { byte.MinValue, byte.MinValue, byte.MinValue, byte.MinValue, byte.MinValue, byte.MinValue, byte.MinValue, byte.MaxValue };
            var userIdentifier = new Domain.V1.Entities.Users.UserIdentifier
            {
                Id = 1,
                UserID = 1,
                Status = true,
                IdentifierType = "type",
                IdentifierUse = "use",
                System = "test",
                Value = "test",
                PeriodEnd = DateTime.UtcNow,
                PeriodStart = DateTime.UtcNow,
                IsDeleted = false,
                CreatedBy = "Admin",
                CreatedDate = DateTime.UtcNow,
                UpdatedBy = "Admin",  // Adding the missing property
                UpdatedDate = DateTime.UtcNow,// Assuming UpdatedDate is required as well
                RecordVersion = concurrencyToken
            };


            //Arrange
            using ReadWriteDbContext dbContext = new(options);
            dbContext.UserIdentifiers.Add(userIdentifier);
            await dbContext.SaveChangesAsync();


            UpdateUserIdentifierRequest updateModel = new UpdateUserIdentifierRequest
            {
                Id = 1,
                UserID = 1,
                Status = true,
                IdentifierType = "type",
                IdentifierUse = "use",
                System = "test",
                Value = "test",
                PeriodEnd = DateTime.UtcNow,
                PeriodStart = DateTime.UtcNow,
                RecordVersion = concurrencyToken
            };

            updateModel.RecordVersion = userIdentifier.RecordVersion;

            _userIdentifierCommandService = new UserIdentifierCommandService(dbContext, _mapperMock.Object);

            // Act
            bool result = await _userIdentifierCommandService.UpdateUserIdentifierAsync(updateModel, userIdentifier);

            Assert.True(result);
        }
        [Fact]
        public async Task Test_DeleteUserIdentifier_Returns_Success()
        {
            //Arrange
            DbContextOptions<ReadWriteDbContext> options = new DbContextOptionsBuilder<ReadWriteDbContext>()
               .UseInMemoryDatabase(databaseName: "DeleteUserIdentifier").Options;

            byte[] concurrencyToken = new byte[8] { byte.MinValue, byte.MinValue, byte.MinValue, byte.MinValue, byte.MinValue, byte.MinValue, byte.MinValue, byte.MaxValue };
            var userIdentifier = new Domain.V1.Entities.Users.UserIdentifier
            {
                Id = 1,
                UserID = 1,
                Status = true,
                IdentifierType = "type",
                IdentifierUse = "use",
                System = "test",
                Value = "test",
                PeriodEnd = DateTime.UtcNow,
                PeriodStart = DateTime.UtcNow,
                IsDeleted = false,
                CreatedBy = "Admin",
                CreatedDate = DateTime.UtcNow,
                UpdatedBy = "Admin",  // Adding the missing property
                UpdatedDate = DateTime.UtcNow,// Assuming UpdatedDate is required as well
                RecordVersion = concurrencyToken
            };



            //Arrange
            using ReadWriteDbContext dbContext = new(options);
            dbContext.UserIdentifiers.Add(userIdentifier);
            await dbContext.SaveChangesAsync();

            _userIdentifierCommandService = new UserIdentifierCommandService(dbContext, _mapperMock.Object);

            // Act
            bool result = await _userIdentifierCommandService.DeleteUserIdentifierByIdAsync(concurrencyToken, userIdentifier);

            Assert.True(result);
        }
    }
}
