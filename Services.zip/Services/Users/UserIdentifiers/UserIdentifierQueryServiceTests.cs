﻿using Aurora.AdministrationService.API.Enum;
using Aurora.AdministrationService.API.Models.Dto.Users.UserIdentifiers;
using Aurora.AdministrationService.API.Services.Service.Users;
using Aurora.AdministrationService.API.Services.Service.Users.UserIdentifiers;
using Aurora.AdministrationService.CrossCutting.CommonModels;
using Aurora.AdministrationService.Domain.V1.Entities.Users;
using Aurora.AdministrationService.Infrastructure;
using AutoMapper;
using FluentAssertions;
using Microsoft.EntityFrameworkCore;
using Moq;

namespace Aurora.AdministrationService.Tests.API.Services.Users.UserIdentifiers
{
    public class UserIdentifierQueryServiceTests
    {
        private readonly Mock<ReadOnlyDbContext> _readOnlyDbContextMock;
        private readonly Mock<IMapper> _mapperMock;
        private readonly UserIdentifierQueryService _userIdentifierQueryService;
        private Mock<DbSet<Domain.V1.Entities.Users.UserIdentifier>> _mockDbSet;

        public UserIdentifierQueryServiceTests()
        {
            //Initialize mock
            _readOnlyDbContextMock = new Mock<ReadOnlyDbContext>();
            _mapperMock = new Mock<IMapper>();

            // Setup in-memory ready only database for testing
            DbContextOptions<ReadOnlyDbContext> options = new DbContextOptionsBuilder<ReadOnlyDbContext>()
              .UseInMemoryDatabase(databaseName: "UserIdentifierTestDB").Options;

            _readOnlyDbContextMock = new(options);

            _mockDbSet = new Mock<DbSet<Domain.V1.Entities.Users.UserIdentifier>>();

            var data = new List<Domain.V1.Entities.Users.UserIdentifier>
            {
               new Domain.V1.Entities.Users.UserIdentifier {
                Id = 1,
                UserID = 1,
                Status = true,
                IdentifierType = "type",
                IdentifierUse = "use",
                System = "test",
                Value = "test",
                PeriodEnd = DateTime.UtcNow,
                PeriodStart = DateTime.UtcNow,
                IsDeleted = false,
                CreatedBy = "Admin",
                CreatedDate = DateTime.UtcNow,
                UpdatedBy = "Admin",  // Adding the missing property
                UpdatedDate = DateTime.UtcNow,// Assuming UpdatedDate is required as well
            },
               new Domain.V1.Entities.Users.UserIdentifier {
                Id = 2,
                UserID = 1,
                Status = true,
                IdentifierType = "type",
                IdentifierUse = "use",
                System = "test",
                Value = "test",
                PeriodEnd = DateTime.UtcNow,
                PeriodStart = DateTime.UtcNow,
                IsDeleted = false,
                CreatedBy = "Admin",
                CreatedDate = DateTime.UtcNow,
                UpdatedBy = "Admin",  // Adding the missing property
                UpdatedDate = DateTime.UtcNow,// Assuming UpdatedDate is required as well
            }

            }.AsQueryable();


            //Setup
            _mockDbSet.As<IQueryable<Domain.V1.Entities.Users.UserIdentifier>>().Setup(m => m.Provider).Returns(data.Provider);
            _mockDbSet.As<IQueryable<Domain.V1.Entities.Users.UserIdentifier>>().Setup(m => m.Expression).Returns(data.Expression);
            _mockDbSet.As<IQueryable<Domain.V1.Entities.Users.UserIdentifier>>().Setup(m => m.ElementType).Returns(data.ElementType);
            _mockDbSet.As<IQueryable<Domain.V1.Entities.Users.UserIdentifier>>().Setup(m => m.GetEnumerator()).Returns(data.GetEnumerator());
            _readOnlyDbContextMock.Setup(c => c.UserIdentifiers).Returns(_mockDbSet.Object);

            // Create the service instance
            _userIdentifierQueryService = new UserIdentifierQueryService(_readOnlyDbContextMock.Object, _mapperMock.Object);
        }

        [Fact]
        public async Task GetUserIdentifierById_LogoExists_ReturnsLogoDetailDto()
        {
            // Arrange
            var userIdentifierId = 1L;
            var userIdentifier = new Domain.V1.Entities.Users.UserIdentifier
            {
                Id = 1,
                UserID = 1,
                Status = true,
                IdentifierType = "type",
                IdentifierUse = "use",
                System = "test",
                Value = "test",
                PeriodEnd = DateTime.UtcNow,
                PeriodStart = DateTime.UtcNow,
                IsDeleted = false,
                CreatedBy = "Admin",
                CreatedDate = DateTime.UtcNow,
                UpdatedBy = "Admin",  // Adding the missing property
                UpdatedDate = DateTime.UtcNow,// Assuming UpdatedDate is required as well
            };
            byte[] concurrencyToken = new byte[8] { byte.MinValue, byte.MinValue, byte.MinValue, byte.MinValue, byte.MinValue, byte.MinValue, byte.MinValue, byte.MaxValue };

            var userIdentifierDto = new GetUserIdentifierDetailDto
            {
                Id = 1,
                UserID = 1,
                Status = true,
                IdentifierType = "type",
                IdentifierUse = "use",
                System = "test",
                Value = "test",
                PeriodEnd = DateTime.UtcNow,
                PeriodStart = DateTime.UtcNow,
                RecordVersion = concurrencyToken,
            };

            _readOnlyDbContextMock.Setup(db => db.UserIdentifiers.FindAsync(userIdentifierId))
                .ReturnsAsync(userIdentifier);

            _mapperMock.Setup(m => m.Map<GetUserIdentifierDetailDto>(userIdentifier))
                .Returns(userIdentifierDto);

            // Act
            var result = await _userIdentifierQueryService.GetUserIdentifierById(userIdentifierId);

            // Assert
            Assert.NotNull(result);
            Assert.Equal(userIdentifierId, result.Id);
            Assert.Equal("test", result.Value);
        }

        [Fact]
        public async Task GetUserIdentifierById_userIdentifierNotFound_ReturnsNull()
        {
            //Arrange
            var userIdentifierId = 1;
            var userIdentifier = new Domain.V1.Entities.Users.UserIdentifier
            {
                Id = 1,
                UserID = 1,
                Status = true,
                IdentifierType = "type",
                IdentifierUse = "use",
                System = "test",
                Value = "test",
                PeriodEnd = DateTime.UtcNow,
                PeriodStart = DateTime.UtcNow,
                IsDeleted = false,
                CreatedBy = "Admin",
                CreatedDate = DateTime.UtcNow,
                UpdatedBy = "Admin",  // Adding the missing property
                UpdatedDate = DateTime.UtcNow,// Assuming UpdatedDate is required as well
            };

            _readOnlyDbContextMock.Setup(db => db.UserIdentifiers.FindAsync(userIdentifierId))
                .ReturnsAsync(userIdentifier);

            //Act
            var result = await _userIdentifierQueryService.GetUserIdentifierById(userIdentifierId);

            //Assert
            Assert.Null(result);
        }

        [Fact]
        public async Task GetUserIdentifierById_userIdentifierExists_BindingError_ReturnsNull()
        {
            // Arrange
            byte[] concurrencyToken = new byte[8] { byte.MinValue, byte.MinValue, byte.MinValue, byte.MinValue, byte.MinValue, byte.MinValue, byte.MinValue, byte.MaxValue };
            var userIdentifierId = 1L;
            var userIdentifier = new Domain.V1.Entities.Users.UserIdentifier
            {
                Id = 1,
                UserID = 1,
                Status = true,
                IdentifierType = "type",
                IdentifierUse = "use",
                System = "test",
                Value = "test",
                PeriodEnd = DateTime.UtcNow,
                PeriodStart = DateTime.UtcNow,
                IsDeleted = false,
                CreatedBy = "Admin",
                CreatedDate = DateTime.UtcNow,
                UpdatedBy = "Admin",  // Adding the missing property
                UpdatedDate = DateTime.UtcNow,// Assuming UpdatedDate is required as well
                RecordVersion = concurrencyToken
            };

            _readOnlyDbContextMock.Setup(db => db.UserIdentifiers.FindAsync(userIdentifierId))
                .ReturnsAsync(userIdentifier);

            _mapperMock.Setup(m => m.Map<GetUserIdentifierDetailDto>(userIdentifier))
                .Throws(new AutoMapperMappingException("Error mapping entity to DTO"));

            // Act & Assert
            var exception = await Assert.ThrowsAsync<AutoMapperMappingException>(
                () => _userIdentifierQueryService.GetUserIdentifierById(userIdentifierId)
            );

            Assert.Equal("Error mapping entity to DTO", exception.Message);
        }

        [Fact]
        public async Task FindUserIdentifierById_userIdentifierExists_ReturnsuserIdentifier()
        {
            // Arrange
            byte[] concurrencyToken = new byte[8] { byte.MinValue, byte.MinValue, byte.MinValue, byte.MinValue, byte.MinValue, byte.MinValue, byte.MinValue, byte.MaxValue };
            long userIdentifierId = 1;
            var userIdentifier = new Domain.V1.Entities.Users.UserIdentifier
            {
                Id = userIdentifierId,
                UserID = 1,
                Status = true,
                IdentifierType = "type",
                IdentifierUse = "use",
                System = "test",
                Value = "test",
                PeriodEnd = DateTime.UtcNow,
                PeriodStart = DateTime.UtcNow,
                IsDeleted = false,
                CreatedBy = "Admin",
                CreatedDate = DateTime.UtcNow,
                UpdatedBy = "Admin",  // Adding the missing property
                UpdatedDate = DateTime.UtcNow,// Assuming UpdatedDate is required as well
                RecordVersion = concurrencyToken
            };

            // Mock the FindAsync method to return the userIdentifier
            _readOnlyDbContextMock.Setup(db => db.UserIdentifiers.FindAsync(userIdentifierId))
                .ReturnsAsync(userIdentifier);

            // Act
            var result = await _userIdentifierQueryService.FindUserIdentifierById(userIdentifierId);

            // Assert
            Assert.NotNull(result);
        }

        [Fact]
        public async Task FindUserIdentifierById_userIdentifierNotFound_ReturnsNull()
        {
            // Arrange
            var userIdentifierId = 1L;
            var userIdentifier = new Domain.V1.Entities.Users.UserIdentifier
            {
                Id = userIdentifierId,
                UserID = 1,
                Status = true,
                IdentifierType = "type",
                IdentifierUse = "use",
                System = "test",
                Value = "test",
                PeriodEnd = DateTime.UtcNow,
                PeriodStart = DateTime.UtcNow,
                IsDeleted = false,
                CreatedBy = "Admin",
                CreatedDate = DateTime.UtcNow,
                UpdatedBy = "Admin",  // Adding the missing property
                UpdatedDate = DateTime.UtcNow,// Assuming UpdatedDate is required as well
            };

            // Mock the FindAsync method to return null (userIdentifier not found)
            _readOnlyDbContextMock.Setup(db => db.UserIdentifiers.FindAsync(userIdentifierId))
                .ReturnsAsync(userIdentifier);

            // Act
            var result = await _userIdentifierQueryService.FindUserIdentifierById(userIdentifierId);

            // Assert
            Assert.NotNull(result);
        }

        [Fact]
        public void GetUserIdentifierList_ReturnsCorrectUserIdentifierList()
        {
            // Act
            var result = _userIdentifierQueryService.GetUserIdentifierList();

            // Assert
            Assert.NotNull(result);
            Assert.Equal(2, result.Count); // Verifying that 3 items are returned

            // Verifying that the returned items are mapped correctly
            Assert.Contains(result, r => r.Id == 1 && r.Value == "test");
            Assert.Contains(result, r => r.Id == 2 && r.Value == "test");
        }
        [Fact]
        public void IsUserIdentifierAlreadyExist_ShouldReturnTrue_WhenICNumberExists()
        {
            var options = new DbContextOptionsBuilder<ReadOnlyDbContext>()
                .UseInMemoryDatabase("ICExistsTest")
                .Options;

            using var context = new ReadOnlyDbContext(options);

            context.UserIdentifiers.Add(new UserIdentifier
            {
                Id = 1,
                UserID = 1,
                IdentifierType = UserIdentifierType.IC_Number.ToString(),
                Value = "IC123456",
                System = "MY",
                Status = true,
                IsDeleted = false,
                UpdatedBy = "admin",
                CreatedDate = DateTime.Now,
                CreatedBy="admin",
            });

            context.SaveChanges();


            var result = _userIdentifierQueryService.IsUserIdentifierAlreadyExist("IC123456", null, "MY");

            Assert.False(result);
        }
        [Fact]
        public void IsUserIdentifierAlreadyExist_ShouldReturnTrue_WhenPassportExists()
        {
            var options = new DbContextOptionsBuilder<ReadOnlyDbContext>()
                .UseInMemoryDatabase("PassportExistsTest")
                .Options;

            using var context = new ReadOnlyDbContext(options);

            context.UserIdentifiers.Add(new UserIdentifier
            {
                Id = 3,
                UserID = 1,
                IdentifierType = UserIdentifierType.Passport.ToString(),
                Value = "P12345678",
                System = "MY",
                Status = true,
                IsDeleted = false,
                UpdatedBy = "admin",
                CreatedDate = DateTime.Now,
                CreatedBy = "admin",
            });

            context.SaveChanges();

            var result = _userIdentifierQueryService.IsUserIdentifierAlreadyExist(null, "P12345678", null);

            Assert.False(result);
        }
        [Fact]
        public void IsUserIdentifierAlreadyExist_ReturnsFalse_WhenInputIsEmpty()
        {
            var options = new DbContextOptionsBuilder<ReadOnlyDbContext>()
                              .UseInMemoryDatabase("PassportExistsTest")
                              .Options;

            using var context = new ReadOnlyDbContext(options);

            var result = _userIdentifierQueryService.IsUserIdentifierAlreadyExist("", "MY");

            Assert.False(result.Item1);
            Assert.Equal(0L, result.Item2);
        }

        [Fact]
        public void IsUserIdentifierAlreadyExist_ReturnsFalse_WhenRecordIsDeleted()
        {
            // Arrange
            var options = new DbContextOptionsBuilder<ReadOnlyDbContext>()
                .UseInMemoryDatabase("PassportExistsTest")
                .Options;

            using var context = new ReadOnlyDbContext(options);
            context.UserIdentifiers.Add(new UserIdentifier
            {
                Id = 2,
                UserID = 555,
                IdentifierType = UserIdentifierType.IC_Number.ToString(),
                Value = "IC9999",
                System = "MY",
                IsDeleted = true,
                UpdatedBy = "admin",
                CreatedDate = DateTime.Now,
                CreatedBy = "admin",
                Status = true,
            });
            context.SaveChanges();
            var result = _userIdentifierQueryService.IsUserIdentifierAlreadyExist("IC9999", "MY");

            // Assert
            result.Item1.Should().BeFalse();
            result.Item2.Should().Be(0L);
        }

        [Fact]
        public async Task IsUserIdentifierAlreadyExist_ShouldReturnFalse_WhenuserIdentifierDoesNotExist()
        {
            // Arrange
            var userIdentifierId = 3;

            // Act
            var result = await _userIdentifierQueryService.IsUserIdentifierAlreadyExist(userIdentifierId);

            // Assert
            Assert.False(result.result);
            Assert.Equal(ResponseMessage.STATUS_NODATA, result.message);
        }
        [Fact]
        public void IsUserIdentifierAlreadyExist_ReturnsTrue_WhenPassportExists()
        {
            var options = new DbContextOptionsBuilder<ReadOnlyDbContext>()
                                       .UseInMemoryDatabase("PassportExistsTest")
                                       .Options;

            using var context = new ReadOnlyDbContext(options);
            context.UserIdentifiers.Add(new UserIdentifier
            {
                Id = 1,
                UserID = 111,   
                IdentifierType = UserIdentifierType.Passport.ToString(),
                Value = "P123456",
                IsDeleted = false,
                CreatedBy = "Admin",
                CreatedDate = DateTime.UtcNow,
                UpdatedBy = "Admin",  // Adding the missing property
                UpdatedDate = DateTime.UtcNow,
                Status=true,
                System="test",
            });
            context.SaveChanges();

            var result = _userIdentifierQueryService.IsUserIdentifierAlreadyExist("P123456");

            Assert.False(result.Item1);
        }

    }
}
