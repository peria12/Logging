﻿using Aurora.AdministrationService.API.Enum;
using Aurora.AdministrationService.API.Models.Dto.Users;
using Aurora.AdministrationService.API.Services.IService.Users;
using Aurora.AdministrationService.API.Services.Service.Faq;
using Aurora.AdministrationService.API.Services.Service.Users;
using Aurora.AdministrationService.API.Services.Service.Users.UserNames;
using Aurora.AdministrationService.CrossCutting.CommonModels;
using Aurora.AdministrationService.Infrastructure;
using AutoMapper;
using FluentAssertions;
using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Infrastructure;
using Moq;

namespace Aurora.AdministrationService.Tests.API.Services.Users
{
    public class UserQueryServiceTests
    {
        private readonly Mock<ReadOnlyDbContext> _readOnlyDbContextMock;
        private readonly Mock<IMapper> _mapperMock;
        private readonly UserQueryService _userQueryService;
        private Mock<DbSet<Domain.V1.Entities.Users.User>> _mockDbSet;
        private Mock<DbSet<Domain.V1.Entities.Users.UserNames>> _mockUserNamesDbSet;
        public UserQueryServiceTests()
        {
            //Initialize mock
            _readOnlyDbContextMock = new Mock<ReadOnlyDbContext>();
            _mapperMock = new Mock<IMapper>();

            // Setup in-memory ready only database for testing
            DbContextOptions<ReadOnlyDbContext> options = new DbContextOptionsBuilder<ReadOnlyDbContext>()
              .UseInMemoryDatabase(databaseName: "UserTestDB").Options;

            _readOnlyDbContextMock = new(options);

            _mockDbSet = new Mock<DbSet<Domain.V1.Entities.Users.User>>();

            var data = new List<Domain.V1.Entities.Users.User>
            {
               new Domain.V1.Entities.Users.User {
                Id = 1,
                UserName = "admin",
                Status = true,
                Gender = "Male",
                BirthDate = DateTime.UtcNow,
                ManagingOrganization = "1",
                Source = "Aurora",
                IsTempAccount = true,
                UserType = "Patient",
                Passcode = "1234",
                Language = 1,
                NotificationsEnabled = true,
                BioAuthenticationEnabled = true,
                SOSButtonEnabled = true,
                AppVersion = "v1",
                Password = "1234",
                IsMarketingConsentEnable = true,
                Salt = "salt",
                LocationEnable = true,
                IsDeleted = false,
                CreatedBy = "Admin",
                CreatedDate = DateTime.UtcNow,
                UpdatedBy = "Admin",  // Adding the missing property
                UpdatedDate = DateTime.UtcNow,// Assuming UpdatedDate is required as well
            },
               new Domain.V1.Entities.Users.User {
                Id = 2,
                UserName = "admin",
                Status = true,
                Gender = "Male",
                BirthDate = DateTime.UtcNow,
                ManagingOrganization = "1",
                Source = "Aurora",
                IsTempAccount = true,
                UserType = "Patient",
                Passcode = "1234",
                Language = 1,
                NotificationsEnabled = true,
                BioAuthenticationEnabled = true,
                SOSButtonEnabled = true,
                AppVersion = "v1",
                Password = "1234",
                IsMarketingConsentEnable = true,
                Salt = "salt",
                LocationEnable = true,
                IsDeleted = false,
                CreatedBy = "Admin",
                CreatedDate = DateTime.UtcNow,
                UpdatedBy = "Admin",  // Adding the missing property
                UpdatedDate = DateTime.UtcNow,// Assuming UpdatedDate is required as well
            }

            }.AsQueryable();


            //Setup
            _mockDbSet.As<IQueryable<Domain.V1.Entities.Users.User>>().Setup(m => m.Provider).Returns(data.Provider);
            _mockDbSet.As<IQueryable<Domain.V1.Entities.Users.User>>().Setup(m => m.Expression).Returns(data.Expression);
            _mockDbSet.As<IQueryable<Domain.V1.Entities.Users.User>>().Setup(m => m.ElementType).Returns(data.ElementType);
            _mockDbSet.As<IQueryable<Domain.V1.Entities.Users.User>>().Setup(m => m.GetEnumerator()).Returns(data.GetEnumerator());
            _readOnlyDbContextMock.Setup(c => c.UserNew).Returns(_mockDbSet.Object);

            _mockUserNamesDbSet = new Mock<DbSet<Domain.V1.Entities.Users.UserNames>>();

            var userNamedata = new List<Domain.V1.Entities.Users.UserNames>
            {
               new Domain.V1.Entities.Users.UserNames {
                Id = 1,
                UserID = 1,
                Status = true,
                FamilyName = "family",
                GivenName = "test",
                MiddleName = "test",
                NameUse = "test",
                Prefix = "test",
                Suffix = "test",
                PeriodEnd = DateTime.UtcNow,
                PeriodStart = DateTime.UtcNow,
                IsDeleted = false,
                CreatedBy = "Admin",
                CreatedDate = DateTime.UtcNow,
                UpdatedBy = "Admin",  // Adding the missing property
                UpdatedDate = DateTime.UtcNow,// Assuming UpdatedDate is required as well
            },
               new Domain.V1.Entities.Users.UserNames {
                Id = 2,
                UserID = 1,
                Status = true,
                FamilyName = "family",
                GivenName = "test",
                MiddleName = "test",
                NameUse = "test",
                Prefix = "test",
                Suffix = "test",
                PeriodEnd = DateTime.UtcNow,
                PeriodStart = DateTime.UtcNow,
                IsDeleted = false,
                CreatedBy = "Admin",
                CreatedDate = DateTime.UtcNow,
                UpdatedBy = "Admin",  // Adding the missing property
                UpdatedDate = DateTime.UtcNow,// Assuming UpdatedDate is required as well
            }

            }.AsQueryable();


            //Setup
            _mockUserNamesDbSet.As<IQueryable<Domain.V1.Entities.Users.UserNames>>().Setup(m => m.Provider).Returns(userNamedata.Provider);
            _mockUserNamesDbSet.As<IQueryable<Domain.V1.Entities.Users.UserNames>>().Setup(m => m.Expression).Returns(userNamedata.Expression);
            _mockUserNamesDbSet.As<IQueryable<Domain.V1.Entities.Users.UserNames>>().Setup(m => m.ElementType).Returns(userNamedata.ElementType);
            _mockUserNamesDbSet.As<IQueryable<Domain.V1.Entities.Users.UserNames>>().Setup(m => m.GetEnumerator()).Returns(userNamedata.GetEnumerator());
            _readOnlyDbContextMock.Setup(c => c.UserNames).Returns(_mockUserNamesDbSet.Object);


            // Create the service instance
            _userQueryService = new UserQueryService(_readOnlyDbContextMock.Object, _mapperMock.Object);
        }

        [Fact]
        public async Task GetUserById_LogoExists_ReturnsLogoDetailDto()
        {
            // Arrange
            var userId = 1L;
            var user = new Domain.V1.Entities.Users.User
            {
                Id = 1,
                UserName = "admin",
                Status = true,
                Gender = "Male",
                BirthDate = DateTime.UtcNow,
                ManagingOrganization = "1",
                Source = "Aurora",
                IsTempAccount = true,
                UserType = "Patient",
                Passcode = "1234",
                Language = 1,
                NotificationsEnabled = true,
                BioAuthenticationEnabled = true,
                SOSButtonEnabled = true,
                AppVersion = "v1",
                Password = "1234",
                IsMarketingConsentEnable = true,
                Salt = "salt",
                LocationEnable = true,
                IsDeleted = false,
                CreatedBy = "Admin",
                CreatedDate = DateTime.UtcNow,
                UpdatedBy = "Admin",  // Adding the missing property
                UpdatedDate = DateTime.UtcNow,// Assuming UpdatedDate is required as well
            };

            var userDto = new GetUserDetailDto
            {
                Id = 1,
                UserName = "admin",
                Status = true,
                Gender = "Male",
                BirthDate = DateTime.UtcNow,
                ManagingOrganization = "1",
                Source = "Aurora",
                IsTempAccount = true,
                UserType = "Patient",
                Passcode = "1234",
                Language = 1,
                NotificationsEnabled = true,
                BioAuthenticationEnabled = true,
                SOSButtonEnabled = true,
                AppVersion = "v1",
                Password = "1234",
                IsMarketingConsentEnable = true,
                Salt = "salt",
                LocationEnable = true,
            };

            _readOnlyDbContextMock.Setup(db => db.UserNew.FindAsync(userId))
                .ReturnsAsync(user);

            _mapperMock.Setup(m => m.Map<GetUserDetailDto>(user))
                .Returns(userDto);

            // Act
            var result = await _userQueryService.GetUserById(userId);

            // Assert
            Assert.NotNull(result);
            Assert.Equal(userId, result.Id);
            Assert.Equal("Patient", result.UserType);
        }

        [Fact]
        public async Task GetUserById_userNotFound_ReturnsNull()
        {
            //Arrange
            var userId = 1;
            var user = new Domain.V1.Entities.Users.User
            {
                Id = 1,
                UserName = "admin",
                Status = true,
                Gender = "Male",
                BirthDate = DateTime.UtcNow,
                ManagingOrganization = "1",
                Source = "Aurora",
                IsTempAccount = true,
                UserType = "Patient",
                Passcode = "1234",
                Language = 1,
                NotificationsEnabled = true,
                BioAuthenticationEnabled = true,
                SOSButtonEnabled = true,
                AppVersion = "v1",
                Password = "1234",
                IsMarketingConsentEnable = true,
                Salt = "salt",
                LocationEnable = true,
                IsDeleted = false,
                CreatedBy = "Admin",
                CreatedDate = DateTime.UtcNow,
                UpdatedBy = "Admin",  // Adding the missing property
                UpdatedDate = DateTime.UtcNow,// Assuming UpdatedDate is required as well
            };

            _readOnlyDbContextMock.Setup(db => db.UserNew.FindAsync(userId))
                .ReturnsAsync(user);

            //Act
            var result = await _userQueryService.GetUserById(userId);

            //Assert
            Assert.Null(result);
        }

        [Fact]
        public async Task GetUserById_userExists_BindingError_ReturnsNull()
        {
            // Arrange
            byte[] concurrencyToken = new byte[8] { byte.MinValue, byte.MinValue, byte.MinValue, byte.MinValue, byte.MinValue, byte.MinValue, byte.MinValue, byte.MaxValue };
            var userId = 1L;
            var user = new Domain.V1.Entities.Users.User
            {
                Id = 1,
                UserName = "admin",
                Status = true,
                Gender = "Male",
                BirthDate = DateTime.UtcNow,
                ManagingOrganization = "1",
                Source = "Aurora",
                IsTempAccount = true,
                UserType = "Patient",
                Passcode = "1234",
                Language = 1,
                NotificationsEnabled = true,
                BioAuthenticationEnabled = true,
                SOSButtonEnabled = true,
                AppVersion = "v1",
                Password = "1234",
                IsMarketingConsentEnable = true,
                Salt = "salt",
                LocationEnable = true,
                IsDeleted = false,
                CreatedBy = "Admin",
                CreatedDate = DateTime.UtcNow,
                UpdatedBy = "Admin",  // Adding the missing property
                UpdatedDate = DateTime.UtcNow,// Assuming UpdatedDate is required as well
                RecordVersion = concurrencyToken
            };

            _readOnlyDbContextMock.Setup(db => db.UserNew.FindAsync(userId))
                .ReturnsAsync(user);

            _mapperMock.Setup(m => m.Map<GetUserDetailDto>(user))
                .Throws(new AutoMapperMappingException("Error mapping entity to DTO"));

            // Act & Assert
            var exception = await Assert.ThrowsAsync<AutoMapperMappingException>(
                () => _userQueryService.GetUserById(userId)
            );

            Assert.Equal("Error mapping entity to DTO", exception.Message);
        }

        [Fact]
        public async Task FindUserById_userExists_Returnsuser()
        {
            // Arrange
            byte[] concurrencyToken = new byte[8] { byte.MinValue, byte.MinValue, byte.MinValue, byte.MinValue, byte.MinValue, byte.MinValue, byte.MinValue, byte.MaxValue };
            long userId = 1;
            var user = new Domain.V1.Entities.Users.User
            {
                Id = userId,
                UserName = "admin",
                Status = true,
                Gender = "Male",
                BirthDate = DateTime.UtcNow,
                ManagingOrganization = "1",
                Source = "Aurora",
                IsTempAccount = true,
                UserType = "Patient",
                Passcode = "1234",
                Language = 1,
                NotificationsEnabled = true,
                BioAuthenticationEnabled = true,
                SOSButtonEnabled = true,
                AppVersion = "v1",
                Password = "1234",
                IsMarketingConsentEnable = true,
                Salt = "salt",
                LocationEnable = true,
                IsDeleted = false,
                CreatedBy = "Admin",
                CreatedDate = DateTime.UtcNow,
                UpdatedBy = "Admin",  // Adding the missing property
                UpdatedDate = DateTime.UtcNow,// Assuming UpdatedDate is required as well
                RecordVersion = concurrencyToken
            };

            // Mock the FindAsync method to return the user
            _readOnlyDbContextMock.Setup(db => db.UserNew.FindAsync(userId))
                .ReturnsAsync(user);

            // Act
            var result = await _userQueryService.FindUserById(userId);

            // Assert
            Assert.NotNull(result);
        }

        [Fact]
        public async Task FindUserById_userNotFound_ReturnsNull()
        {
            // Arrange
            var userId = 1L;
            var user = new Domain.V1.Entities.Users.User
            {
                Id = userId,
                UserName = "admin",
                Status = true,
                Gender = "Male",
                BirthDate = DateTime.UtcNow,
                ManagingOrganization = "1",
                Source = "Aurora",
                IsTempAccount = true,
                UserType = "Patient",
                Passcode = "1234",
                Language = 1,
                NotificationsEnabled = true,
                BioAuthenticationEnabled = true,
                SOSButtonEnabled = true,
                AppVersion = "v1",
                Password = "1234",
                IsMarketingConsentEnable = true,
                Salt = "salt",
                LocationEnable = true,
                IsDeleted = false,
                CreatedBy = "Admin",
                CreatedDate = DateTime.UtcNow,
                UpdatedBy = "Admin",  // Adding the missing property
                UpdatedDate = DateTime.UtcNow,// Assuming UpdatedDate is required as well
            };

            // Mock the FindAsync method to return null (user not found)
            _readOnlyDbContextMock.Setup(db => db.UserNew.FindAsync(userId))
                .ReturnsAsync(user);

            // Act
            var result = await _userQueryService.FindUserById(userId);

            // Assert
            Assert.NotNull(result);
        }

        [Fact]
        public void GetUserList_ReturnsCorrectUserList()
        {
            // Act
            var result = _userQueryService.GetUserList();

            // Assert
            Assert.NotNull(result);
            Assert.Equal(2, result.Count); // Verifying that 3 items are returned

            // Verifying that the returned items are mapped correctly
            Assert.Contains(result, r => r.Id == 1 && r.UserType == "Patient");
            Assert.Contains(result, r => r.Id == 2 && r.UserType == "Patient");
        }

        [Fact]
        public async Task IsUserAlreadyExist_ShouldReturnTrue_WhenuserExists()
        {
            // Arrange
            var userId = 1L;
            var user = new Domain.V1.Entities.Users.User
            {
                Id = 1,
                UserName = "admin",
                Status = true,
                Gender = "Male",
                BirthDate = DateTime.UtcNow,
                ManagingOrganization = "1",
                Source = "Aurora",
                IsTempAccount = true,
                UserType = "Patient",
                Passcode = "1234",
                Language = 1,
                NotificationsEnabled = true,
                BioAuthenticationEnabled = true,
                SOSButtonEnabled = true,
                AppVersion = "v1",
                Password = "1234",
                IsMarketingConsentEnable = true,
                Salt = "salt",
                LocationEnable = true,
                IsDeleted = false,
                CreatedBy = "Admin",
                CreatedDate = DateTime.UtcNow,
                UpdatedBy = "Admin",  // Adding the missing property
                UpdatedDate = DateTime.UtcNow,// Assuming UpdatedDate is required as well
            };

            // Mock the FindAsync method to return the user
            _readOnlyDbContextMock.Setup(db => db.UserNew.FindAsync(userId))
                .ReturnsAsync(user);

            // Act
            var result = await _userQueryService.IsUserAlreadyExist(userId);

            // Assert
            Assert.True(result.result);
            Assert.Equal(ResponseMessage.STATUS_DATA_FOUND, result.message);
        }

        [Fact]
        public async Task IsUserAlreadyExist_ShouldReturnFalse_WhenuserDoesNotExist()
        {
            // Arrange
            var userId = 3;

            // Act
            var result = await _userQueryService.IsUserAlreadyExist(userId);

            // Assert
            Assert.False(result.result);
            Assert.Equal(ResponseMessage.STATUS_NODATA, result.message);
        }
        [Fact]
        public void GetUserSettings_ReturnsUserSettingDto()
        {
            // Arrange
            var userId = 1L;
            var user = new Domain.V1.Entities.Users.User
            {
                Id = 1,
                UserName = "admin",
                Status = true,
                Gender = "Male",
                BirthDate = DateTime.UtcNow,
                ManagingOrganization = "1",
                Source = "Aurora",
                IsTempAccount = true,
                UserType = "Patient",
                Passcode = "1234",
                Language = 1,
                NotificationsEnabled = true,
                BioAuthenticationEnabled = true,
                SOSButtonEnabled = true,
                AppVersion = "v1",
                Password = "1234",
                IsMarketingConsentEnable = true,
                Salt = "salt",
                LocationEnable = true,
                IsDeleted = false,
                CreatedBy = "Admin",
                CreatedDate = DateTime.UtcNow,
                UpdatedBy = "Admin",  // Adding the missing property
                UpdatedDate = DateTime.UtcNow,// Assuming UpdatedDate is required as well
            };

            var userDto = new GetUserDetailDto
            {
                Id = 1,
                UserName = "admin",
                Status = true,
                Gender = "Male",
                BirthDate = DateTime.UtcNow,
                ManagingOrganization = "1",
                Source = "Aurora",
                IsTempAccount = true,
                UserType = "Patient",
                Passcode = "1234",
                Language = 1,
                NotificationsEnabled = true,
                BioAuthenticationEnabled = true,
                SOSButtonEnabled = true,
                AppVersion = "v1",
                Password = "1234",
                IsMarketingConsentEnable = true,
                Salt = "salt",
                LocationEnable = true,
            };

            _readOnlyDbContextMock.Setup(db => db.UserNew.FindAsync(userId))
                .ReturnsAsync(user);

            // Act
            var result = _userQueryService.GetUserSettingDetails(userId);

            // Assert
            Assert.NotNull(result);
            Assert.Equal(true, result.IsSOSButtonEnabled);
        }
        [Fact]
        public void GetUserSettings_ReturnsEmptyUserSettingDto()
        {
            // Arrange
            var userId = 3L;
            var user = new Domain.V1.Entities.Users.User
            {
                Id = 1,
                UserName = "admin",
                Status = true,
                Gender = "Male",
                BirthDate = DateTime.UtcNow,
                ManagingOrganization = "1",
                Source = "Aurora",
                IsTempAccount = true,
                UserType = "Patient",
                Passcode = "1234",
                Language = 1,
                NotificationsEnabled = true,
                BioAuthenticationEnabled = true,
                SOSButtonEnabled = true,
                AppVersion = "v1",
                Password = "1234",
                IsMarketingConsentEnable = true,
                Salt = "salt",
                LocationEnable = true,
                IsDeleted = false,
                CreatedBy = "Admin",
                CreatedDate = DateTime.UtcNow,
                UpdatedBy = "Admin",  // Adding the missing property
                UpdatedDate = DateTime.UtcNow,// Assuming UpdatedDate is required as well
            };

            var userDto = new GetUserDetailDto
            {
                Id = 1,
                UserName = "admin",
                Status = true,
                Gender = "Male",
                BirthDate = DateTime.UtcNow,
                ManagingOrganization = "1",
                Source = "Aurora",
                IsTempAccount = true,
                UserType = "Patient",
                Passcode = "1234",
                Language = 1,
                NotificationsEnabled = true,
                BioAuthenticationEnabled = true,
                SOSButtonEnabled = true,
                AppVersion = "v1",
                Password = "1234",
                IsMarketingConsentEnable = true,
                Salt = "salt",
                LocationEnable = true,
            };

            _readOnlyDbContextMock.Setup(db => db.UserNew.FindAsync(userId))
                .ReturnsAsync(user);

            // Act
            var result = _userQueryService.GetUserSettingDetails(userId);

            // Assert
            Assert.Null(result);
        }

        #region AdminSignInAsync Query Service Test cases 
        [Fact]
        public void AdminSignInAsync_Should_Return_False_When_User_Does_Not_Exist()
        {
            // Arrange
            var userName = "NonExistentAdmin";
            var password = "password123";

            // Mock the UserNew DbSet to return an empty dataset
            var users = new List<Domain.V1.Entities.Users.User>().AsQueryable();

            _mockDbSet.As<IQueryable<Domain.V1.Entities.Users.User>>().Setup(m => m.Provider).Returns(users.Provider);
            _mockDbSet.As<IQueryable<Domain.V1.Entities.Users.User>>().Setup(m => m.Expression).Returns(users.Expression);
            _mockDbSet.As<IQueryable<Domain.V1.Entities.Users.User>>().Setup(m => m.ElementType).Returns(users.ElementType);
            _mockDbSet.As<IQueryable<Domain.V1.Entities.Users.User>>().Setup(m => m.GetEnumerator()).Returns(users.GetEnumerator());

            _readOnlyDbContextMock.Setup(c => c.UserNew).Returns(_mockDbSet.Object);

            // Act
            var (resultUser, isSuccess) = _userQueryService.AdminSignInAsync(userName, password);

            // Assert
            isSuccess.Should().BeFalse();
            resultUser.Should().NotBeNull();
            resultUser.Id.Should().Be(0); // Default value for long
            resultUser.UserName.Should().Be(string.Empty);
            resultUser.UserType.Should().Be(string.Empty);
            resultUser.Password.Should().Be(string.Empty);
        }

        [Fact]
        public void AdminSignInAsync_Should_Return_True_When_Credentials_Are_Correct()
        {
            // Arrange
            var userName = "admin";
            var password = "correctPassword";

            var users = new List<Domain.V1.Entities.Users.User>
        {
            new Domain.V1.Entities.Users.User
            {
                Id = 1,
                UserName = "admin",
                Status = true,
                UserType = "Admin",
                Password = password,
                IsTempAccount = true,
                NotificationsEnabled = true,
                BioAuthenticationEnabled = true,
                SOSButtonEnabled = true,
                 IsDeleted = false,
                CreatedBy = "Admin",
                CreatedDate = DateTime.UtcNow,
                UpdatedBy = "Admin",  // Adding the missing property
            }
        }.AsQueryable();

            _mockDbSet.As<IQueryable<Domain.V1.Entities.Users.User>>().Setup(m => m.Provider).Returns(users.Provider);
            _mockDbSet.As<IQueryable<Domain.V1.Entities.Users.User>>().Setup(m => m.Expression).Returns(users.Expression);
            _mockDbSet.As<IQueryable<Domain.V1.Entities.Users.User>>().Setup(m => m.ElementType).Returns(users.ElementType);
            _mockDbSet.As<IQueryable<Domain.V1.Entities.Users.User>>().Setup(m => m.GetEnumerator()).Returns(users.GetEnumerator());

            _readOnlyDbContextMock.Setup(c => c.UserNew).Returns(_mockDbSet.Object);

            // Act
            var (resultUser, isSuccess) = _userQueryService.AdminSignInAsync(userName, password);

            // Assert
            isSuccess.Should().BeTrue();
            resultUser.Should().NotBeNull();
            resultUser.Id.Should().Be(1);
            resultUser.UserName.Should().Be("admin");
            resultUser.UserType.Should().Be("Admin");
            resultUser.Password.Should().Be(password);
        }
        #endregion

        #region SignInAsync Query Service Test cases   
        [Fact]
        public void SignInAsync_Should_Return_True_When_Credentials_Are_Correct()
        {
            // Arrange
            var userId = 1L;
            var password = "1234";

            // Act
            var (resultUser, isSuccess) = _userQueryService.SignInAsync(userId, password);

            // Assert
            isSuccess.Should().BeTrue();
            resultUser.Should().NotBeNull();
            resultUser.Id.Should().Be(userId);
            resultUser.UserName.Should().Be("admin");
            resultUser.UserType.Should().Be("Patient");
            resultUser.Password.Should().Be(password);
        }

        [Fact]
        public void SignInAsync_Should_Return_False_When_Credentials_Are_Incorrect()
        {
            // Arrange
            var userId = 1L;
            var password = "wrongPassword";

            // Act
            var (resultUser, isSuccess) = _userQueryService.SignInAsync(userId, password);

            // Assert
            isSuccess.Should().BeFalse();
            resultUser.Should().NotBeNull();
            resultUser.Id.Should().Be(userId);
        }

        [Fact]
        public void SignInAsync_Should_Return_False_When_User_Not_Found()
        {
            // Arrange
            var userId = 99L;
            var password = "somePassword";

            // Act
            var (resultUser, isSuccess) = _userQueryService.SignInAsync(userId, password);

            // Assert
            isSuccess.Should().BeFalse();
            resultUser.Should().NotBeNull();
            resultUser.Id.Should().Be(0L);
        }
        #endregion

        [Fact]
        public async void GetUserPersonalInformation_ReturnsUserPersonalInformation()
        {
            // Arrange
            var options = new DbContextOptionsBuilder<ReadOnlyDbContext>()
                .UseInMemoryDatabase(databaseName: "UserInfoDatabase")
                .Options;

            var dbContext = new ReadOnlyDbContext(options);

            dbContext.UserNew.RemoveRange(dbContext.UserNew);
            dbContext.UserNames.RemoveRange(dbContext.UserNames);
            dbContext.UserTelecoms.AddRange(dbContext.UserTelecoms);
            dbContext.SaveChanges();


            var userData = new List<Domain.V1.Entities.Users.User>
            {
               new Domain.V1.Entities.Users.User {
                Id = 1,
                UserName = "admin",
                Status = true,
                Gender = "Male",
                BirthDate = DateTime.UtcNow,
                ManagingOrganization = "1",
                Source = "Aurora",
                IsTempAccount = true,
                UserType = "Patient",
                Passcode = "1234",
                Language = 1,
                NotificationsEnabled = true,
                BioAuthenticationEnabled = true,
                SOSButtonEnabled = true,
                AppVersion = "v1",
                Password = "1234",
                IsMarketingConsentEnable = true,
                Salt = "salt",
                LocationEnable = true,
                IsDeleted = false,
                CreatedBy = "Admin",
                CreatedDate = DateTime.UtcNow,
                UpdatedBy = "Admin",  // Adding the missing property
                UpdatedDate = DateTime.UtcNow,// Assuming UpdatedDate is required as well
            },
               new Domain.V1.Entities.Users.User {
                Id = 2,
                UserName = "admin",
                Status = true,
                Gender = "Male",
                BirthDate = DateTime.UtcNow,
                ManagingOrganization = "1",
                Source = "Aurora",
                IsTempAccount = true,
                UserType = "Patient",
                Passcode = "1234",
                Language = 1,
                NotificationsEnabled = true,
                BioAuthenticationEnabled = true,
                SOSButtonEnabled = true,
                AppVersion = "v1",
                Password = "1234",
                IsMarketingConsentEnable = true,
                Salt = "salt",
                LocationEnable = true,
                IsDeleted = false,
                CreatedBy = "Admin",
                CreatedDate = DateTime.UtcNow,
                UpdatedBy = "Admin",  // Adding the missing property
                UpdatedDate = DateTime.UtcNow,// Assuming UpdatedDate is required as well
            }

            };
            var userNamesData = new List<Domain.V1.Entities.Users.UserNames>
            {
               new Domain.V1.Entities.Users.UserNames {
                Id = 1,
                UserID = 1,
                Status = true,
                FamilyName = "family",
                GivenName = "test",
                MiddleName = "test",
                NameUse = "test",
                Prefix = "test",
                Suffix = "test",
                PeriodEnd = DateTime.UtcNow,
                PeriodStart = DateTime.UtcNow,
                IsDeleted = false,
                CreatedBy = "Admin",
                CreatedDate = DateTime.UtcNow,
                UpdatedBy = "Admin",  // Adding the missing property
                UpdatedDate = DateTime.UtcNow,// Assuming UpdatedDate is required as well
            },
               new Domain.V1.Entities.Users.UserNames {
                Id = 2,
                UserID = 1,
                Status = true,
                FamilyName = "family",
                GivenName = "test",
                MiddleName = "test",
                NameUse = "test",
                Prefix = "test",
                Suffix = "test",
                PeriodEnd = DateTime.UtcNow,
                PeriodStart = DateTime.UtcNow,
                IsDeleted = false,
                CreatedBy = "Admin",
                CreatedDate = DateTime.UtcNow,
                UpdatedBy = "Admin",  // Adding the missing property
                UpdatedDate = DateTime.UtcNow,// Assuming UpdatedDate is required as well
            }

            };

            var userTelecomData = new List<Domain.V1.Entities.Users.UserTelecom>
            {
               new Domain.V1.Entities.Users.UserTelecom {
                Id = 1,
                UserID = 1,
                Status = true,
                System = System.Enum.GetName(UserTelecomType.Phone),
                Value = "+91 123456789",
                PeriodEnd = DateTime.UtcNow,
                PeriodStart = DateTime.UtcNow,
                Rank= 1,
                Use="test",
                IsDeleted = false,
                CreatedBy = "Admin",
                CreatedDate = DateTime.UtcNow,
                UpdatedBy = "Admin",  // Adding the missing property
                UpdatedDate = DateTime.UtcNow,// Assuming UpdatedDate is required as well
            },
               new Domain.V1.Entities.Users.UserTelecom {
                Id = 2,
                UserID = 1,
                Status = true,
                System = System.Enum.GetName(UserTelecomType.Email),
                Value = "test@test.com",
                PeriodEnd = DateTime.UtcNow,
                PeriodStart = DateTime.UtcNow,
                Rank= 1,
                Use="test",
                IsDeleted = false,
                CreatedBy = "Admin",
                CreatedDate = DateTime.UtcNow,
                UpdatedBy = "Admin",  // Adding the missing property
                UpdatedDate = DateTime.UtcNow,// Assuming UpdatedDate is required as well
            }

            };

            dbContext.UserNew.AddRange(userData);
            dbContext.UserNames.AddRange(userNamesData);
            dbContext.UserTelecoms.AddRange(userTelecomData);
            dbContext.SaveChanges();

            var userId = 1L;

            var userQueryService = new UserQueryService(dbContext, _mapperMock.Object);

            // Act
            var (isUserInfoLoaded, _) = await userQueryService.GetUserPersonalInformation(userId);

            // Assert
            Assert.True(isUserInfoLoaded);

        }
        [Fact]
        public async void GetUserPersonalInformation_ReturnsEmptyUserPersonalInformation()
        {
            // Arrange
            var options = new DbContextOptionsBuilder<ReadOnlyDbContext>()
                .UseInMemoryDatabase(databaseName: "UserPersonalInformationDatabase")
                .Options;

            var dbContext = new ReadOnlyDbContext(options);

            dbContext.UserNew.RemoveRange(dbContext.UserNew);
            dbContext.UserNames.RemoveRange(dbContext.UserNames);
            dbContext.UserTelecoms.AddRange(dbContext.UserTelecoms);
            dbContext.SaveChanges();


            var userData = new List<Domain.V1.Entities.Users.User>
            {
               new Domain.V1.Entities.Users.User {
                Id = 1,
                UserName = "admin",
                Status = true,
                Gender = "Male",
                BirthDate = DateTime.UtcNow,
                ManagingOrganization = "1",
                Source = "Aurora",
                IsTempAccount = true,
                UserType = "Patient",
                Passcode = "1234",
                Language = 1,
                NotificationsEnabled = true,
                BioAuthenticationEnabled = true,
                SOSButtonEnabled = true,
                AppVersion = "v1",
                Password = "1234",
                IsMarketingConsentEnable = true,
                Salt = "salt",
                LocationEnable = true,
                IsDeleted = false,
                CreatedBy = "Admin",
                CreatedDate = DateTime.UtcNow,
                UpdatedBy = "Admin",  // Adding the missing property
                UpdatedDate = DateTime.UtcNow,// Assuming UpdatedDate is required as well
            },
               new Domain.V1.Entities.Users.User {
                Id = 2,
                UserName = "admin",
                Status = true,
                Gender = "Male",
                BirthDate = DateTime.UtcNow,
                ManagingOrganization = "1",
                Source = "Aurora",
                IsTempAccount = true,
                UserType = "Patient",
                Passcode = "1234",
                Language = 1,
                NotificationsEnabled = true,
                BioAuthenticationEnabled = true,
                SOSButtonEnabled = true,
                AppVersion = "v1",
                Password = "1234",
                IsMarketingConsentEnable = true,
                Salt = "salt",
                LocationEnable = true,
                IsDeleted = false,
                CreatedBy = "Admin",
                CreatedDate = DateTime.UtcNow,
                UpdatedBy = "Admin",  // Adding the missing property
                UpdatedDate = DateTime.UtcNow,// Assuming UpdatedDate is required as well
            }

            };
            var userNamesData = new List<Domain.V1.Entities.Users.UserNames>
            {
               new Domain.V1.Entities.Users.UserNames {
                Id = 1,
                UserID = 1,
                Status = true,
                FamilyName = "family",
                GivenName = "test",
                MiddleName = "test",
                NameUse = "test",
                Prefix = "test",
                Suffix = "test",
                PeriodEnd = DateTime.UtcNow,
                PeriodStart = DateTime.UtcNow,
                IsDeleted = false,
                CreatedBy = "Admin",
                CreatedDate = DateTime.UtcNow,
                UpdatedBy = "Admin",  // Adding the missing property
                UpdatedDate = DateTime.UtcNow,// Assuming UpdatedDate is required as well
            },
               new Domain.V1.Entities.Users.UserNames {
                Id = 2,
                UserID = 1,
                Status = true,
                FamilyName = "family",
                GivenName = "test",
                MiddleName = "test",
                NameUse = "test",
                Prefix = "test",
                Suffix = "test",
                PeriodEnd = DateTime.UtcNow,
                PeriodStart = DateTime.UtcNow,
                IsDeleted = false,
                CreatedBy = "Admin",
                CreatedDate = DateTime.UtcNow,
                UpdatedBy = "Admin",  // Adding the missing property
                UpdatedDate = DateTime.UtcNow,// Assuming UpdatedDate is required as well
            }

            };

            var userTelecomData = new List<Domain.V1.Entities.Users.UserTelecom>
            {
               new Domain.V1.Entities.Users.UserTelecom {
                Id = 1,
                UserID = 1,
                Status = true,
                System = System.Enum.GetName(UserTelecomType.Phone),
                Value = "+91 123456789",
                PeriodEnd = DateTime.UtcNow,
                PeriodStart = DateTime.UtcNow,
                Rank= 1,
                Use="test",
                IsDeleted = false,
                CreatedBy = "Admin",
                CreatedDate = DateTime.UtcNow,
                UpdatedBy = "Admin",  // Adding the missing property
                UpdatedDate = DateTime.UtcNow,// Assuming UpdatedDate is required as well
            },
               new Domain.V1.Entities.Users.UserTelecom {
                Id = 2,
                UserID = 1,
                Status = true,
                System = System.Enum.GetName(UserTelecomType.Email),
                Value = "test@test.com",
                PeriodEnd = DateTime.UtcNow,
                PeriodStart = DateTime.UtcNow,
                Rank= 1,
                Use="test",
                IsDeleted = false,
                CreatedBy = "Admin",
                CreatedDate = DateTime.UtcNow,
                UpdatedBy = "Admin",  // Adding the missing property
                UpdatedDate = DateTime.UtcNow,// Assuming UpdatedDate is required as well
            }

            };

            dbContext.UserNew.AddRange(userData);
            dbContext.UserNames.AddRange(userNamesData);
            dbContext.UserTelecoms.AddRange(userTelecomData);
            dbContext.SaveChanges();

            var userId = 3L;

            var userQueryService = new UserQueryService(dbContext, _mapperMock.Object);

            // Act
            var (isUserInfoLoaded, _) = await userQueryService.GetUserPersonalInformation(userId);

            // Assert
            Assert.False(isUserInfoLoaded);
        }
        [Fact]
        public async Task SearchUsers_ReturnsFilteredResults_WhenStatusFilterIsApplied()
        {
            // Arrange
            var mockUserList = new List<UserSearchResponseDto>
            {
                new UserSearchResponseDto { Id = 1, Name = "admin", UserName = "admin", Email = "test@test.com", Phone = "+91 123456789", UserType = "Patient", Status = true },
            }.AsQueryable();

            var options = new DbContextOptionsBuilder<ReadOnlyDbContext>()
                .UseInMemoryDatabase(databaseName: "UserInfoDatabase")
                .Options;

            var dbContext = new ReadOnlyDbContext(options);

            dbContext.UserNew.RemoveRange(dbContext.UserNew);
            dbContext.UserTelecoms.RemoveRange(dbContext.UserTelecoms);
            dbContext.SaveChanges();


            var userData = new List<Domain.V1.Entities.Users.User>
            {
                new Domain.V1.Entities.Users.User {
                    Id = 1,
                    UserName = "admin",
                    Status = true,
                    Gender = "Male",
                    BirthDate = DateTime.UtcNow,
                    ManagingOrganization = "1",
                    Source = "Aurora",
                    IsTempAccount = true,
                    UserType = "Patient",
                    Passcode = "1234",
                    Language = 1,
                    NotificationsEnabled = true,
                    BioAuthenticationEnabled = true,
                    SOSButtonEnabled = true,
                    AppVersion = "v1",
                    Password = "1234",
                    IsMarketingConsentEnable = true,
                    Salt = "salt",
                    LocationEnable = true,
                    IsDeleted = false,
                    CreatedBy = "Admin",
                    CreatedDate = DateTime.UtcNow,
                    UpdatedBy = "Admin",  // Adding the missing property
                    UpdatedDate = DateTime.UtcNow,// Assuming UpdatedDate is required as well
                },

                new Domain.V1.Entities.Users.User {
                 Id = 2,
                 UserName = "John",
                 Status = true,
                 Gender = "Male",
                 BirthDate = DateTime.UtcNow,
                 ManagingOrganization = "1",
                 Source = "Aurora",
                 IsTempAccount = true,
                 UserType = "Patient",
                 Passcode = "1234",
                 Language = 1,
                 NotificationsEnabled = true,
                 BioAuthenticationEnabled = true,
                 SOSButtonEnabled = true,
                 AppVersion = "v1",
                 Password = "1234",
                 IsMarketingConsentEnable = true,
                 Salt = "salt",
                 LocationEnable = true,
                 IsDeleted = false,
                 CreatedBy = "Admin",
                 CreatedDate = DateTime.UtcNow,
                 UpdatedBy = "Admin",  // Adding the missing property
                 UpdatedDate = DateTime.UtcNow,// Assuming UpdatedDate is required as well
                }
            };

            var userTelecomData = new List<Domain.V1.Entities.Users.UserTelecom>
            {
                new Domain.V1.Entities.Users.UserTelecom 
                {
                    Id = 1,
                    UserID = 1,
                    Status = true,
                    System = System.Enum.GetName(UserTelecomType.Phone),
                    Value = "+91 123456789",
                    PeriodEnd = DateTime.UtcNow,
                    PeriodStart = DateTime.UtcNow,
                    Rank= 1,
                    Use="test",
                    IsDeleted = false,
                    CreatedBy = "Admin",
                    CreatedDate = DateTime.UtcNow,
                    UpdatedBy = "Admin",  // Adding the missing property
                    UpdatedDate = DateTime.UtcNow,// Assuming UpdatedDate is required as well
                },
                new Domain.V1.Entities.Users.UserTelecom 
                {
                    Id = 2,
                    UserID = 1,
                    Status = true,
                    System = System.Enum.GetName(UserTelecomType.Email),
                    Value = "test@test.com",
                    PeriodEnd = DateTime.UtcNow,
                    PeriodStart = DateTime.UtcNow,
                    Rank= 1,
                    Use="test",
                    IsDeleted = false,
                    CreatedBy = "Admin",
                    CreatedDate = DateTime.UtcNow,
                    UpdatedBy = "Admin",  // Adding the missing property
                    UpdatedDate = DateTime.UtcNow,// Assuming UpdatedDate is required as well
                }
            };

            dbContext.UserNew.AddRange(userData);
            dbContext.UserTelecoms.AddRange(userTelecomData);
            dbContext.SaveChanges();

            var userQueryService = new UserQueryService(dbContext, _mapperMock.Object);

            // Act
            var result = await userQueryService.SearchUsers(1, 3, "admin", "Patient", "true");

            // Assert
            Assert.Single(result);
            Assert.True(result.First().Status);
            Assert.Equal(mockUserList.First().Name, result.First().Name);
            Assert.Equal(mockUserList.First().Email, result.First().Email);
            Assert.Equal(mockUserList.First().Phone, result.First().Phone);
            Assert.Equal(mockUserList.First().UserType, result.First().UserType);
        }
    }
}
