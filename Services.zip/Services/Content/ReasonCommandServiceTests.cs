﻿using Aurora.AdministrationService.API.Resources;
using Aurora.AdministrationService.API.Services.IService.Content;
using Aurora.AdministrationService.API.Services.Service.Content;
using Aurora.AdministrationService.CrossCutting.CommonModels;
using Aurora.AdministrationService.Infrastructure;
using AutoMapper;
using Microsoft.EntityFrameworkCore;
using Moq;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Aurora.AdministrationService.Tests.API.Services.Content
{
   public class ReasonCommandServiceTests
    {
        private readonly ReadWriteDbContext _readWriteDbContextMock;
        private readonly Mock<ReadOnlyDbContext> _readOnlyDbContextMock;       
        private ReasonCommandservice _reasonCommandService;
        public ReasonCommandServiceTests()
        {          
            _readOnlyDbContextMock = new Mock<ReadOnlyDbContext>();

            // Setup in-memory ready only database for testing

            DbContextOptions<ReadWriteDbContext> options = new DbContextOptionsBuilder<ReadWriteDbContext>()
              .UseInMemoryDatabase(databaseName: "TestDatabase").Options;
            _readWriteDbContextMock = new(options);

            // Initialize the service being tested
            _reasonCommandService = new ReasonCommandservice(_readWriteDbContextMock);

        }
        [Fact]
        public async Task DeleteReason_ShouldReturnSuccess_WhenValidRequestAndRecordVersionMatches()
        {
            // Arrange
            byte[] concurrencyToken = new byte[8] { byte.MinValue, byte.MinValue, byte.MinValue, byte.MinValue, byte.MinValue, byte.MinValue, byte.MinValue, byte.MaxValue };
            var reasonDelete = new Domain.V1.Entities.Contents.Reasons
            {
                Id = 12,
                Status = false,              
                IsDeleted = false,
                ContentID=2,
                ResonType = "Reason1",
                CreatedBy = "Admin",
                CreatedDate = DateTime.UtcNow,
                UpdatedBy = "Admin",  // Adding the missing property
                UpdatedDate = DateTime.UtcNow,// Assuming UpdatedDate is required as well
                RecordVersion = concurrencyToken
            };

            _readWriteDbContextMock.ContentReasons.Add(reasonDelete);
            await _readWriteDbContextMock.SaveChangesAsync();

            var recordVersion = reasonDelete.RecordVersion;

            // Act
            var result = await _reasonCommandService.DeleteReasonAsync(recordVersion, reasonDelete);

            // Assert
            Assert.True(result.IsSuccess);
            var deletedcontent = await _readWriteDbContextMock.ContentReasons.FindAsync(reasonDelete.Id);
            Assert.NotNull(deletedcontent);
            Assert.True(deletedcontent.IsDeleted);
        }

        [Fact]
        public async Task DeleteReason_ShouldReturnError_WhenRecordVersionDoesNotMatch()
        {
            byte[] concurrencyToken = new byte[8] { byte.MinValue, byte.MinValue, byte.MinValue, byte.MinValue, byte.MinValue, byte.MinValue, byte.MinValue, byte.MaxValue };
            var reasonDelete = new Domain.V1.Entities.Contents.Reasons
            {
                Id = 2,
                Status = false,
                IsDeleted = false,
                ContentID = 2,
                ResonType = "Reason1",
                CreatedBy = "Admin",
                CreatedDate = DateTime.UtcNow,
                UpdatedBy = "Admin",  // Adding the missing property
                UpdatedDate = DateTime.UtcNow,// Assuming UpdatedDate is required as well
                RecordVersion = concurrencyToken
            };

            _readWriteDbContextMock.ContentReasons.Add(reasonDelete);
            await _readWriteDbContextMock.SaveChangesAsync();

            var incorrectRecordVersion = new byte[] { 5, 6, 7, 8 };

            // Act
            var result = await _reasonCommandService.DeleteReasonAsync(incorrectRecordVersion, reasonDelete);

            // Assert
            Assert.False(result.IsSuccess);
            Assert.Equal(ResponseStatus.STATUS_InternalServerError, result.StatusCode);
            Assert.Equal(Resource.RecordDeletionFailureMessage, result.Message);
        }


        [Fact]
        public async Task DeleteReasons_ShouldReturnSuccess_Test()
        {
            // Arrange
            byte[] concurrencyToken = new byte[8] { byte.MinValue, byte.MinValue, byte.MinValue, byte.MinValue, byte.MinValue, byte.MinValue, byte.MinValue, byte.MaxValue };
            var reasonDelete = new Domain.V1.Entities.Contents.Reasons
            {
                Id = 1,
                Status = false,
                IsDeleted = false,
                CreatedBy = "Admin",
                ContentID = 1,
                CreatedDate = DateTime.UtcNow,
                UpdatedBy = "Admin",  // Adding the missing property
                UpdatedDate = DateTime.UtcNow,// Assuming UpdatedDate is required as well
                RecordVersion = concurrencyToken
            };

            _readWriteDbContextMock.ContentReasons.Add(reasonDelete);
            await _readWriteDbContextMock.SaveChangesAsync();

            var recordVersion = reasonDelete.RecordVersion;

            // Act
            var result = await _reasonCommandService.DeleteReasonAsync(recordVersion, reasonDelete);

            // Assert
            Assert.True(result.IsSuccess);
            var deletedReasons = await _readWriteDbContextMock.ContentReasons.FindAsync(reasonDelete.Id);
            Assert.NotNull(deletedReasons);
            Assert.True(deletedReasons.IsDeleted);
        }
        [Fact]
        public async Task DeleteReasons_ShouldReturnError_WhenRecordVersionDoesNotMatch()
        {
            byte[] concurrencyToken = new byte[8] { byte.MinValue, byte.MinValue, byte.MinValue, byte.MinValue, byte.MinValue, byte.MinValue, byte.MinValue, byte.MaxValue };
            var reasonDelete = new Domain.V1.Entities.Contents.Reasons
            {
                Id = 14,
                Status = false,
                IsDeleted = false,
                CreatedBy = "Admin",
                ContentID = 14,
                CreatedDate = DateTime.UtcNow,
                UpdatedBy = "Admin",  // Adding the missing property
                UpdatedDate = DateTime.UtcNow,// Assuming UpdatedDate is required as well
                RecordVersion = concurrencyToken
            };

            _readWriteDbContextMock.ContentReasons.Add(reasonDelete);
            await _readWriteDbContextMock.SaveChangesAsync();

            var incorrectRecordVersion = new byte[] { 5, 6, 7, 8 };

            // Act
            var result = await _reasonCommandService.DeleteReasonAsync(incorrectRecordVersion, reasonDelete);

            // Assert
            Assert.False(result.IsSuccess);
            Assert.Equal(ResponseStatus.STATUS_InternalServerError, result.StatusCode);
            Assert.Equal(Resource.RecordDeletionFailureMessage, result.Message);
        }
    }
}
