﻿using Aurora.AdministrationService.API.Enum;
using Aurora.AdministrationService.API.Models.Dto.Content;
using Aurora.AdministrationService.API.Models.Dto.Dependent;
using Aurora.AdministrationService.API.Resources;
using Aurora.AdministrationService.API.Services.Service.Content;
using Aurora.AdministrationService.API.Services.Service.Users;
using Aurora.AdministrationService.CrossCutting.CommonModels;
using Aurora.AdministrationService.CrossCutting.Constants;
using Aurora.AdministrationService.Domain.V1.Entities.Contents;
using Aurora.AdministrationService.Infrastructure;
using AutoMapper;
using FluentAssertions;
using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Diagnostics;
using Microsoft.VisualStudio.TestPlatform.Common;
using Moq;
using System.ComponentModel.DataAnnotations;

namespace Aurora.AdministrationService.Tests.API.Services.Content
{
    public class ContentCommandServiceTests
    {
        private readonly ReadWriteDbContext _readWriteDbContextMock;
        private readonly Mock<ReadOnlyDbContext> _readOnlyDbContextMock;
        private readonly Mock<IMapper> _mapperMock;
        private readonly ContentCommandService _contentCommandService;

        public ContentCommandServiceTests()
        {
            _mapperMock = new Mock<IMapper>();
            _readOnlyDbContextMock = new Mock<ReadOnlyDbContext>();
            DbContextOptions<ReadWriteDbContext> options = new DbContextOptionsBuilder<ReadWriteDbContext>()
                .UseInMemoryDatabase(databaseName: Guid.NewGuid().ToString())
                .ConfigureWarnings(b => b.Ignore(InMemoryEventId.TransactionIgnoredWarning))
                .Options;
            _readWriteDbContextMock = new ReadWriteDbContext(options);

            // Initialize the service being tested
            _contentCommandService = new ContentCommandService(_readWriteDbContextMock, _mapperMock.Object);
        }


        [Fact]
        public async Task CreateContentAsync_ShouldMapReasonsCorrectly()
        {
            // Arrange
            byte[] concurrencyToken = new byte[8] { byte.MinValue, byte.MinValue, byte.MinValue, byte.MinValue, byte.MinValue, byte.MinValue, byte.MinValue, byte.MaxValue };

            var newContentRecord = new AddContentDto
            {
                Module = "Test Module",
                Header = "Test Header",
                PlatformsID = new List<ContentPlatformDto> { new ContentPlatformDto { PlatformsID = "WEB" } },
                ReasonsDto = new List<AddReasonsDto>

            {
            new AddReasonsDto { ResonType = "Reason 1" }
            }
            };

            var contentEntity = new Domain.V1.Entities.Contents.Content { Id = 1, CreatedDate = DateTime.UtcNow, IsDeleted = true, Status = true, RecordVersion = concurrencyToken };
            _mapperMock.Setup(m => m.Map<Domain.V1.Entities.Contents.Content>(It.IsAny<AddContentDto>())).Returns(contentEntity);
            _mapperMock.Setup(m => m.Map<Reasons>(It.IsAny<AddReasonsDto>())).Returns((AddReasonsDto dto) => new Reasons { ResonType = "reasion", ContentID = 12, CreatedDate = DateTime.UtcNow, IsDeleted = true, RecordVersion = concurrencyToken, Status = true });

            _readOnlyDbContextMock.Setup(db => db.Contents.Add(It.IsAny<Domain.V1.Entities.Contents.Content>()));
            _readOnlyDbContextMock.Setup(db => db.ContentReasons.Add(It.IsAny<Reasons>()));
            _readOnlyDbContextMock.Setup(db => db.SaveChangesAsync(default)).ReturnsAsync(1);

            // Act
            var result = await _contentCommandService.CreateContentAsync(newContentRecord);
            // Assert

            _mapperMock.Verify(m => m.Map<Reasons>(It.IsAny<AddReasonsDto>()), Times.Once);
        }

        [Fact]
        public async Task CreateContent_ShouldReturnError_WhenExceptionOccurs()
        {
            // Arrange
            var newContentRecord = new AddContentDto
            {
                Module = "Test Module",
                Header = "Test Header",
                PlatformsID = new List<ContentPlatformDto> { new ContentPlatformDto { PlatformsID = "WEB" } },
                ReasonsDto = new List<AddReasonsDto>
            {
            new AddReasonsDto { ResonType = "Reason 1" }
            }
            };
            _mapperMock.Setup(m => m.Map<Domain.V1.Entities.Contents.Content>(It.IsAny<AddContentDto>()))
                       .Throws(new Exception("Simulated error"));
            // Act
            var result = await _contentCommandService.CreateContentAsync(newContentRecord);
            // Assert
            Assert.False(result.IsSuccess);
            Assert.Equal(ResponseStatus.STATUS_InternalServerError, result.StatusCode);
            Assert.Equal(Resource.LogMessage, result.Message);
        }

        [Fact]
        public async Task CreateContentAsync_MappingFails_ThrowsException_ReturnsInternalServerError()
        {
            // Arrange
            var newContentRecord = new AddContentDto
            {
                Module = "TestModule",
                Header = "TestHeader",
                PlatformsID = new List<ContentPlatformDto> { new ContentPlatformDto { PlatformsID = "WEB" } },
                ReasonsDto = new List<AddReasonsDto>()
            };
            _mapperMock.Setup(m => m.Map<Domain.V1.Entities.Contents.Content>(newContentRecord)).Throws(new Exception("Mapping failed"));

            // Act
            var result = await _contentCommandService.CreateContentAsync(newContentRecord);

            // Assert
            Assert.False(result.IsSuccess);
            Assert.True(result.HasError);
            Assert.Equal(ResponseStatus.STATUS_InternalServerError, result.StatusCode);
            Assert.Null(result.Result);
            Assert.Equal(Resource.LogMessage, result.Message);
        }

        [Fact]
        public async Task Create_ShouldReturnSuccess_WhenValidRequest()
        {
            // Arrange
            byte[] concurrencyToken = new byte[8] { byte.MinValue, byte.MinValue, byte.MinValue, byte.MinValue, byte.MinValue, byte.MinValue, byte.MinValue, byte.MaxValue };

            var newContentRecord = new AddContentDto
            {
                Module = "Test Module",
                Header = "Test Header",
                PlatformsID = new List<ContentPlatformDto> { new ContentPlatformDto { PlatformsID = "WEB" } },
                ReasonsDto = new List<AddReasonsDto>
            {
            new AddReasonsDto { ResonType = "Reason 1" }
            }

            };

            // Setup mock mapping to return a content
            _mapperMock.Setup(m => m.Map<Domain.V1.Entities.Contents.Content>(It.IsAny<AddContentDto>()))
                       .Returns(new Domain.V1.Entities.Contents.Content
                       {
                           Id = 113,
                           RecordVersion = concurrencyToken,
                           Header = "Test Header",
                           Module = "Test Module",
                           Status = true,
                           ContentPlatform = new List<ContentPlatform>
                {
                    new ContentPlatform
                    {
                        ID = 3,
                        ContentID = 113,
                        PlatformsID = "Web",
                        RecordVersion = new byte[] { 1, 2, 3, 5 },
                        IsDeleted = false,
                        CreatedDate = DateTime.UtcNow
                    }
                },
                           IsDeleted = false,
                           CreatedBy = "testUser",
                           CreatedDate = DateTime.Now,
                           UpdatedBy = "testUser",
                           UpdatedDate = DateTime.Now,
                       });
            _mapperMock.Setup(m => m.Map<Reasons>(It.IsAny<AddReasonsDto>()))
                       .Returns(new Reasons
                       {
                           ContentID = 113,
                           RecordVersion = concurrencyToken,
                           Status = true,
                           IsDeleted = false,
                           CreatedBy = "testUser",
                           CreatedDate = DateTime.Now,
                           UpdatedBy = "testUser",
                           UpdatedDate = DateTime.Now,
                       });
            _mapperMock.Setup(m => m.Map<ContentPlatform>(It.IsAny<ContentPlatformDto>()))
                       .Returns(new ContentPlatform
                       {
                           ContentID = 113,
                           RecordVersion = concurrencyToken,
                           PlatformsID = "WEB",
                           IsDeleted = false,
                           CreatedBy = "testUser",
                           CreatedDate = DateTime.Now,
                           UpdatedBy = "testUser",
                           UpdatedDate = DateTime.Now,
                       });

            // Act
            var result = await _contentCommandService.CreateContentAsync(newContentRecord);

            // Assert
            Assert.Equal(ResponseStatus.STATUS_SUCCESS_Create, result.StatusCode);
            Assert.Equal(Resource.RecordInsertionMessage, result.Message);
        }
        [Fact]
        public void UpdateContentRequestDto_Should_SetPropertiesCorrectly()
        {
            // Arrange
            var expectedHeader = "Test Header";
            var expectedModule = "Appointment";
            var expectedRecordVersion = new byte[] { 1, 2, 3, 4 };
            var expectedUpdateReasons = new List<UpdateReasonsDto>
            {
                new UpdateReasonsDto
                {
                    Id = 1,
                    RecordVersion = new byte[] { 5, 6, 7, 8 }
                }
            };
            var expectedUpdatePlatformsID = new List<UpdateContentPlatformDto>
            {
                new UpdateContentPlatformDto
                {
                    ID = 1,
                    PlatformsID = "Patient App",
                    RecordVersion = new byte[] { 5, 6, 7, 8 }
                }
            };

            // Act
            var dto = new UpdateContentRequestDto
            {
                Header = expectedHeader,
                UpdateContentPlatformDto = expectedUpdatePlatformsID,
                Module = expectedModule,
                RecordVersion = expectedRecordVersion,
                UpdateReasonDto = expectedUpdateReasons
            };

            // Assert
            dto.Header.Should().Be(expectedHeader);
            dto.Module.Should().Be(expectedModule);
            dto.RecordVersion.Should().BeEquivalentTo(expectedRecordVersion);
            dto.UpdateReasonDto.Should().BeEquivalentTo(expectedUpdateReasons);
        }

        [Fact]
        public void UpdateContentRequestDto_RecordVersion_Should_Have_Timestamp_Attribute()
        {
            // Arrange & Act
            var propertyInfo = typeof(UpdateContentRequestDto).GetProperty(nameof(UpdateContentRequestDto.RecordVersion));
            var attributes = propertyInfo?.GetCustomAttributes(typeof(TimestampAttribute), false);

            // Assert
            (attributes?.Length > 0).Should().BeTrue("RecordVersion should have the [Timestamp] attribute.");
        }

        [Fact]
        public async Task UpdateContent_ShouldReturnSuccess_WhenValidRequestAndValidRecordVersion()
        {
            // Arrange
            var content = new Domain.V1.Entities.Contents.Content
            {
                Id = 112,
                RecordVersion = new byte[] { 1, 2, 3, 4 },
                Header = "Test Header",
                Module = "Test Module",
                Status = true,
                ContentPlatform = new List<ContentPlatform>
                {
                    new ContentPlatform
                    {
                        ID = 3,
                        ContentID = 112,
                        PlatformsID = "Web",
                        RecordVersion = new byte[] { 5,6,7,8 },
                        IsDeleted = false,
                        CreatedDate = DateTime.UtcNow
                    }
                },
                IsDeleted = false,
                CreatedBy = "testUser",
                CreatedDate = DateTime.Now,
                UpdatedBy = "testUser",
                UpdatedDate = DateTime.Now,
                Reasons = new List<Reasons>
                {
                    new Reasons
                    {
                        Id = 3,
                        ContentID = 112,
                        Status = true,
                        RecordVersion = new byte[] { 1, 2, 3, 5 },
                        IsDeleted = false,
                        CreatedDate = DateTime.UtcNow
                    }
                }
            };

            var updateRequest = new UpdateContentRequestDto
            {
                RecordVersion = new byte[] { 1, 2, 3, 4 },
                Header = "Updated Header",
                UpdateContentPlatformDto = new List<UpdateContentPlatformDto>
            {
                new UpdateContentPlatformDto
                {
                    ID = 3,
                    PlatformsID = "Web",
                    RecordVersion = new byte[] { 5, 6, 7, 8 }
                }
            },
                Module = "Test Module Updated",
                UpdateReasonDto = new List<UpdateReasonsDto>
                {
                    new UpdateReasonsDto { Id = 3,  ResonType = "Reason 1", RecordVersion = new byte[] { 1, 2, 3, 5 } }
                }
            };

            _readWriteDbContextMock.Contents.Add(content);
            await _readWriteDbContextMock.SaveChangesAsync();

            // Act
            var result = await _contentCommandService.UpdateContentAsync(content, updateRequest);

            // Assert
            Assert.NotNull(result);
            Assert.False(result.HasError);
            Assert.True(result.IsSuccess);
            Assert.Equal(((int)ResponceStatusCode.Success).ToString(), result.StatusCode);
            Assert.Equal(ResponseMessage.CONTENT_UPDATION_SUCCESS, result.Message);
        }
        [Fact]
        public async Task UpdateContent_ShouldReturnSuccess_WhenValidRequestWithNoExistingRecord()
        {
            // Arrange
            var content = new Domain.V1.Entities.Contents.Content
            {
                Id = 112,
                RecordVersion = new byte[] { 1, 2, 3, 4 },
                Header = "Test Header",
                Module = "Test Module",
                ContentPlatform = new List<ContentPlatform>
                {
                    new ContentPlatform
                    {
                        ID = 3,
                        ContentID = 112,
                        PlatformsID = "Web",
                        RecordVersion = new byte[] { 1, 2, 3, 5 },
                        IsDeleted = false,
                        CreatedDate = DateTime.UtcNow
                    }
                },
                Status = true,
                IsDeleted = false,
                CreatedBy = "testUser",
                CreatedDate = DateTime.Now,
                UpdatedBy = "testUser",
                UpdatedDate = DateTime.Now,
                Reasons = new List<Reasons>
                {
                    new Reasons
                    {
                        Id = 3,
                        ContentID = 112,
                        Status = true,
                        RecordVersion = new byte[] { 1, 2, 3, 5 },
                        IsDeleted = false,
                        CreatedDate = DateTime.UtcNow
                    }
                }
            };
            var updateRequest = new UpdateContentRequestDto
            {
                RecordVersion = new byte[] { 1, 2, 3, 4 },
                Header = "Updated Header",
                UpdateContentPlatformDto = new List<UpdateContentPlatformDto>
                { new UpdateContentPlatformDto{
                    ID=3,
                        PlatformsID = "Web",
                        RecordVersion = new byte[] { 1, 2, 3, 5 },
                        IsDeleted = false}
                },
                Module = "Test Module Updated",
                UpdateReasonDto = new List<UpdateReasonsDto>
                {
                    new UpdateReasonsDto { Id = 3,  ResonType = "Reason 1", RecordVersion = new byte[] { 1, 2, 3, 5 } },
                    new UpdateReasonsDto {ResonType = "Reason 2"}
                }
            };
            _readWriteDbContextMock.Contents.Add(content);
            await _readWriteDbContextMock.SaveChangesAsync();
            _mapperMock.Setup(m => m.Map<Reasons>(It.IsAny<UpdateReasonsDto>()))
                       .Returns(new Reasons
                       {
                           ContentID = 113,
                           RecordVersion = MockRecordVersion.Generate(),
                           Status = true,
                           IsDeleted = false,
                           CreatedBy = "testUser",
                           CreatedDate = DateTime.Now,
                           UpdatedBy = "testUser",
                           UpdatedDate = DateTime.Now,
                       });
            // Act
            var result = await _contentCommandService.UpdateContentAsync(content, updateRequest);

            // Assert
            Assert.NotNull(result);
            Assert.False(result.HasError);
            Assert.True(result.IsSuccess);
            Assert.Equal(((int)ResponceStatusCode.Success).ToString(), result.StatusCode);
            Assert.Equal(ResponseMessage.CONTENT_UPDATION_SUCCESS, result.Message);
        }

        [Fact]
        public async Task UpdateContent_ShouldReturnNotFound_WhenPassedNullDto()
        {
            // Arrange
            var content = new Domain.V1.Entities.Contents.Content
            {
                Id = 112,
                RecordVersion = new byte[] { 1, 2, 3, 4 },
                Header = "Test Header",
                Module = "Test Module",
                ContentPlatform = new List<ContentPlatform>
                {
                    new ContentPlatform
                    {
                        ID = 3,
                        ContentID = 112,
                        PlatformsID = "Web",
                        RecordVersion = new byte[] { 1, 2, 3, 5 },
                        IsDeleted = false,
                        CreatedDate = DateTime.UtcNow
                    }
                },
                Status = true,
                IsDeleted = false,
                CreatedBy = "testUser",
                CreatedDate = DateTime.Now,
                UpdatedBy = "testUser",
                UpdatedDate = DateTime.Now,
                Reasons = new List<Reasons>
                {
                    new Reasons
                    {
                        Id = 3,
                        ContentID = 112,
                        Status = true,
                        RecordVersion = new byte[] { 1, 2, 3, 5 },
                        IsDeleted = false,
                        CreatedDate = DateTime.UtcNow
                    }
                }
            };

            // Act
            var result = await _contentCommandService.UpdateContentAsync(content, null);

            // Assert
            Assert.NotNull(result);
            Assert.True(result.HasError);
            Assert.False(result.IsSuccess);
            Assert.Equal(((int)ResponceStatusCode.NotFound).ToString(), result.StatusCode);
            Assert.Equal(CommonConstants.ERROR_NULL_EXCEPTION, result.Message);
        }
        [Fact]
        public async Task UpdateContent_ShouldReturnDbConcurrencyException_WhenPassedInValidRecordVersion()
        {
            // Arrange
            var content = new Domain.V1.Entities.Contents.Content
            {
                Id = 112,
                RecordVersion = new byte[] { 1, 2, 3, 4 },
                Header = "Test Header",
                Module = "Test Module",
                ContentPlatform = new List<ContentPlatform>
                {
                    new ContentPlatform
                    {
                        ID = 3,
                        ContentID = 112,
                        PlatformsID = "Web",
                        RecordVersion = new byte[] { 1, 2, 3, 5 },
                        IsDeleted = false,
                        CreatedDate = DateTime.UtcNow
                    }
                },
                Status = true,
                IsDeleted = false,
                CreatedBy = "testUser",
                CreatedDate = DateTime.Now,
                UpdatedBy = "testUser",
                UpdatedDate = DateTime.Now,
                Reasons = new List<Reasons>
                {
                    new Reasons
                    {
                        Id = 3,
                        ContentID = 112,
                        Status = true,
                        RecordVersion = new byte[] { 1, 2, 3, 5 },
                        IsDeleted = false,
                        CreatedDate = DateTime.UtcNow
                    }
                }
            };
            var updateRequest = new UpdateContentRequestDto
            {
                RecordVersion = new byte[] { 1, 2, 3, 5 },
                Header = "Updated Header",
                //PlatformIDs = new List<ContentPlatformDto> { new ContentPlatformDto { PlatformsID = "WEB" } },
                Module = "Test Module Updated",
                UpdateReasonDto = new List<UpdateReasonsDto>
                {
                    new UpdateReasonsDto { Id = 3,  ResonType = "Reason 1", RecordVersion = new byte[] { 1, 2, 3, 5 } }
                }
            };

            _readWriteDbContextMock.Contents.Add(content);
            await _readWriteDbContextMock.SaveChangesAsync();

            // Act
            var result = await _contentCommandService.UpdateContentAsync(content, updateRequest);

            // Assert
            Assert.NotNull(result);
            Assert.True(result.HasError);
            Assert.False(result.IsSuccess);
            Assert.Equal(((int)ResponceStatusCode.BadRequest).ToString(), result.StatusCode);
            Assert.Equal(CommonConstants.ERROR_DB_CONCURRENCY, result.Message);
        }
        [Fact]
        public async Task DeleteContent_ShouldReturnSuccess_WhenValidRequestAndRecordVersionMatches()
        {
            // Arrange
            byte[] concurrencyToken = new byte[8] { byte.MinValue, byte.MinValue, byte.MinValue, byte.MinValue, byte.MinValue, byte.MinValue, byte.MinValue, byte.MaxValue };
            var contentDelete = new Domain.V1.Entities.Contents.Content
            {
                Id = 5,
                Status = false,
                Header = "test",
                ContentPlatform = new List<ContentPlatform>
                {
                    new ContentPlatform
                    {
                        ID = 3,
                        ContentID = 112,
                        PlatformsID = "Web",
                        RecordVersion = new byte[] { 1, 2, 3, 5 },
                        IsDeleted = false,
                        CreatedDate = DateTime.UtcNow
                    }
                },
                IsDeleted = false,
                Module = "test",
                CreatedBy = "Admin",
                CreatedDate = DateTime.UtcNow,
                UpdatedBy = "Admin",  // Adding the missing property
                UpdatedDate = DateTime.UtcNow,// Assuming UpdatedDate is required as well
                RecordVersion = concurrencyToken
            };

            _readWriteDbContextMock.Contents.Add(contentDelete);
            await _readWriteDbContextMock.SaveChangesAsync();

            var recordVersion = contentDelete.RecordVersion;

            // Act
            var result = await _contentCommandService.DeleteContentAsync(recordVersion, contentDelete);

            // Assert
            Assert.True(result.IsSuccess);
            var deletedcontent = await _readWriteDbContextMock.Contents.FindAsync(contentDelete.Id);
            Assert.NotNull(deletedcontent);
            Assert.True(deletedcontent.IsDeleted);
        }



        [Fact]
        public async Task DeleteContent_ShouldReturnError_WhenRecordVersionDoesNotMatch()
        {
            byte[] concurrencyToken = new byte[8] { byte.MinValue, byte.MinValue, byte.MinValue, byte.MinValue, byte.MinValue, byte.MinValue, byte.MinValue, byte.MaxValue };
            var contentDelete = new Domain.V1.Entities.Contents.Content
            {
                Id = 2,
                Status = false,
                Header = "test",
                ContentPlatform = new List<ContentPlatform> { new ContentPlatform { ID = 3, ContentID = 112, PlatformsID = "Web", RecordVersion = new byte[] { 1, 2, 3, 5 }, IsDeleted = false, CreatedDate = DateTime.UtcNow } },
                IsDeleted = false,
                Module = "test",
                CreatedBy = "Admin",
                CreatedDate = DateTime.UtcNow,
                UpdatedBy = "Admin",  // Adding the missing property
                UpdatedDate = DateTime.UtcNow,// Assuming UpdatedDate is required as well
                RecordVersion = concurrencyToken
            };

            _readWriteDbContextMock.Contents.Add(contentDelete);
            await _readWriteDbContextMock.SaveChangesAsync();

            var incorrectRecordVersion = new byte[] { 5, 6, 7, 8 };

            // Act
            var result = await _contentCommandService.DeleteContentAsync(incorrectRecordVersion, contentDelete);
            // Assert
            Assert.False(result.IsSuccess);
            Assert.Equal(ResponseStatus.STATUS_InternalServerError, result.StatusCode);
            Assert.Equal(Resource.RecordDeletionFailureMessage, result.Message);
        }

        [Fact]
        public async Task DeleteReasons_ShouldReturnSuccess_Test()
        {
            // Arrange
            byte[] concurrencyToken = new byte[8] { byte.MinValue, byte.MinValue, byte.MinValue, byte.MinValue, byte.MinValue, byte.MinValue, byte.MinValue, byte.MaxValue };
            var reasonDelete = new Domain.V1.Entities.Contents.Reasons
            {
                Id = 3,
                Status = false,
                IsDeleted = false,
                CreatedBy = "Admin",
                ContentID = 1,
                CreatedDate = DateTime.UtcNow,
                UpdatedBy = "Admin",  // Adding the missing property
                UpdatedDate = DateTime.UtcNow,// Assuming UpdatedDate is required as well
                RecordVersion = concurrencyToken
            };

            _readWriteDbContextMock.ContentReasons.Add(reasonDelete);
            await _readWriteDbContextMock.SaveChangesAsync();

            var recordVersion = reasonDelete.RecordVersion;

            // Act
            var result = await _contentCommandService.DeleteReasonAsync(recordVersion, reasonDelete);

            // Assert
            Assert.True(result.IsSuccess);
            var deletedReasons = await _readWriteDbContextMock.ContentReasons.FindAsync(reasonDelete.Id);
            Assert.NotNull(deletedReasons);
            Assert.True(deletedReasons.IsDeleted);
        }

        [Fact]
        public async Task DeleteReasons_ShouldReturnError_WhenRecordVersionDoesNotMatch()
        {
            byte[] concurrencyToken = new byte[8] { byte.MinValue, byte.MinValue, byte.MinValue, byte.MinValue, byte.MinValue, byte.MinValue, byte.MinValue, byte.MaxValue };
            var reasonDelete = new Domain.V1.Entities.Contents.Reasons
            {
                Id = 7,
                Status = false,
                IsDeleted = false,
                CreatedBy = "Admin",
                ContentID = 1,
                CreatedDate = DateTime.UtcNow,
                UpdatedBy = "Admin",  // Adding the missing property
                UpdatedDate = DateTime.UtcNow,// Assuming UpdatedDate is required as well
                RecordVersion = concurrencyToken
            };

            _readWriteDbContextMock.ContentReasons.Add(reasonDelete);
            await _readWriteDbContextMock.SaveChangesAsync();

            var incorrectRecordVersion = new byte[] { 5, 6, 7, 8 };
            // Act
            var result = await _contentCommandService.DeleteReasonAsync(incorrectRecordVersion, reasonDelete);

            // Assert
            Assert.False(result.IsSuccess);
            Assert.Equal(ResponseStatus.STATUS_InternalServerError, result.StatusCode);
        }

        [Fact]
        public async Task DeleteContentplatform_ShouldReturnSuccess_Test()
        {
            // Arrange
            byte[] concurrencyToken = new byte[8] { byte.MinValue, byte.MinValue, byte.MinValue, byte.MinValue, byte.MinValue, byte.MinValue, byte.MinValue, byte.MaxValue };
            var contentPlatformDelete = new Domain.V1.Entities.Contents.ContentPlatform
            {
                ID = 3,
                PlatformsID = "Web",
                IsDeleted = false,
                CreatedBy = "Admin",
                ContentID = 1,
                CreatedDate = DateTime.UtcNow,
                UpdatedBy = "Admin",  // Adding the missing property
                UpdatedDate = DateTime.UtcNow,// Assuming UpdatedDate is required as well
                RecordVersion = concurrencyToken
            };

            _readWriteDbContextMock.ContentPlatforms.Add(contentPlatformDelete);
            await _readWriteDbContextMock.SaveChangesAsync();

            var recordVersion = contentPlatformDelete.RecordVersion;

            // Act
            var result = await _contentCommandService.DeleteContentPlateformAsync(recordVersion, contentPlatformDelete);

            // Assert
            Assert.True(result.IsSuccess);
            var deletedReasons = await _readWriteDbContextMock.ContentPlatforms.FindAsync(contentPlatformDelete.ID);
            Assert.NotNull(deletedReasons);
            Assert.True(deletedReasons.IsDeleted);
        }
    }
}
