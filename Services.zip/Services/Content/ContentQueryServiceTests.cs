﻿using Aurora.AdministrationService.API.Enum;
using Aurora.AdministrationService.API.Models.Dto.Content;
using Aurora.AdministrationService.API.Services.Service.Content;
using Aurora.AdministrationService.CrossCutting.Extensions;
using Aurora.AdministrationService.Domain.V1.Entities.Contents;
using Aurora.AdministrationService.Infrastructure;
using Azure;
using FluentAssertions;
using Microsoft.EntityFrameworkCore;
using Moq;
using System.Reflection;
using entityContent = Aurora.AdministrationService.Domain.V1.Entities.Contents.Content;

namespace Aurora.AdministrationService.Tests.API.Services.Content
{
    public class ContentQueryServiceTests
    {
        private readonly DbContextOptions<ReadOnlyDbContext> _options;
        private readonly ReadOnlyDbContext _context;
        private readonly ContentQueryService _contentQueryService;
        private Mock<DbSet<Domain.V1.Entities.Contents.Content>> _mockDbSet;

        public ContentQueryServiceTests()
        {
            // Use a unique database name for each test to avoid shared state
            _options = new DbContextOptionsBuilder<ReadOnlyDbContext>()
                .UseInMemoryDatabase(databaseName: Guid.NewGuid().ToString()) // Unique name
                .Options;

            // Create a context that uses the InMemoryDatabase
            _context = new ReadOnlyDbContext(_options);
            _context.Database.EnsureCreated();

            SeedTestData(_context);
            // Create the service instance
            _contentQueryService = new ContentQueryService(_context);

            _mockDbSet = new Mock<DbSet<Domain.V1.Entities.Contents.Content>>();
        }
        private static void SeedTestData(ReadOnlyDbContext context)
        {
            var Contents = new entityContent
            {
                Id = 1,
                Module = "module1",
                Header = "header1",
                ContentPlatform = new List<ContentPlatform> { new ContentPlatform { ID = 3, ContentID = 112, PlatformsID = "Web", RecordVersion = new byte[] { 1, 2, 3, 5 }, IsDeleted = false, CreatedDate = DateTime.UtcNow } },
                Status = true,
                RecordVersion = new byte[] { 1 },
                CreatedBy = "Tester",
                CreatedDate = DateTime.UtcNow,
                UpdatedBy = "Tester",
                UpdatedDate = DateTime.UtcNow,
                IsDeleted = false
            };

            context.Contents.Add(Contents);
            context.SaveChanges();
        }

        [Fact]
        public async Task GetAllContentAsync_ReturnsListOfGetContentDto()
        {
            // Arrange
            var mockDbContext = new Mock<ReadOnlyDbContext>();
            var contents = new List<Domain.V1.Entities.Contents.Content>
            {
            new Domain.V1.Entities.Contents.Content
            {
                Id = 1,
                Header = "Test Header 1",
                Module = "Module 1",
                ContentPlatform = new List < ContentPlatform > { new ContentPlatform { ID = 3, ContentID = 112, PlatformsID = "Web", RecordVersion = new byte[] { 1, 2, 3, 5 }, IsDeleted = false, CreatedDate = DateTime.UtcNow } },
                Status = true,
                RecordVersion = new byte[8] { 1, 2, 3, 4, 5, 6, 7, 8 },
                IsDeleted = false,
                CreatedDate =  (DateTime.UtcNow),

            },
            new Domain.V1.Entities.Contents.Content
            {
                Id = 2,
                Header = "Test Header 2",
                Module = "Module 2",
                ContentPlatform = new List < ContentPlatform > { new ContentPlatform { ID = 3, ContentID = 112, PlatformsID = "App", RecordVersion = new byte[] { 1, 2, 3, 5 }, IsDeleted = false, CreatedDate = DateTime.UtcNow } },
                Status = false,
                RecordVersion = new byte[8] { 8, 7, 6, 5, 4, 3, 2, 1 },
                IsDeleted = true,
                CreatedDate =  (DateTime.UtcNow),
            }
        }.AsQueryable();

            var reasons = new List<Domain.V1.Entities.Contents.Reasons>
        {
            new Domain.V1.Entities.Contents.Reasons
            { Id = 1, ContentID = 1, ResonType = "Reason 1",CreatedDate=DateTime.UtcNow,
             IsDeleted=false,RecordVersion=new byte[8] { byte.MinValue, byte.MinValue, byte.MinValue, byte.MinValue, byte.MinValue, byte.MinValue, byte.MinValue, byte.MaxValue },
            Status=true},
            new Domain.V1.Entities.Contents.Reasons { Id = 2, ContentID = 2, ResonType = "Reason 2",CreatedDate=DateTime.UtcNow,
             IsDeleted=false,RecordVersion=new byte[8] { byte.MinValue, byte.MinValue, byte.MinValue, byte.MinValue, byte.MinValue, byte.MinValue, byte.MinValue, byte.MaxValue },
            Status=true}
        }.AsQueryable();
            var query = new PaginationQuery(); // Define the missing 'query' parameter

            var mockContentsDbSet = new Mock<DbSet<Domain.V1.Entities.Contents.Content>>();
            mockContentsDbSet.As<IQueryable<Domain.V1.Entities.Contents.Content>>().Setup(m => m.Provider).Returns(contents.Provider);
            mockContentsDbSet.As<IQueryable<Domain.V1.Entities.Contents.Content>>().Setup(m => m.Expression).Returns(contents.Expression);
            mockContentsDbSet.As<IQueryable<Domain.V1.Entities.Contents.Content>>().Setup(m => m.ElementType).Returns(contents.ElementType);
            mockContentsDbSet.As<IQueryable<Domain.V1.Entities.Contents.Content>>().Setup(m => m.GetEnumerator()).Returns(contents.GetEnumerator());

            var mockReasonsDbSet = new Mock<DbSet<Domain.V1.Entities.Contents.Reasons>>();
            mockReasonsDbSet.As<IQueryable<Domain.V1.Entities.Contents.Reasons>>().Setup(m => m.Provider).Returns(reasons.Provider);
            mockReasonsDbSet.As<IQueryable<Domain.V1.Entities.Contents.Reasons>>().Setup(m => m.Expression).Returns(reasons.Expression);
            mockReasonsDbSet.As<IQueryable<Domain.V1.Entities.Contents.Reasons>>().Setup(m => m.ElementType).Returns(reasons.ElementType);
            mockReasonsDbSet.As<IQueryable<Domain.V1.Entities.Contents.Reasons>>().Setup(m => m.GetEnumerator()).Returns(reasons.GetEnumerator());

            mockDbContext.Setup(x => x.Contents).Returns(mockContentsDbSet.Object);
            mockDbContext.Setup(x => x.ContentReasons).Returns(mockReasonsDbSet.Object);

            // Act          
            var result = await _contentQueryService.GetAllContentAsync(query);

            // Assert
            Assert.False(result.Count < 0);
        }

        [Fact]
        public async Task GetContentById_ContentDoesNotExist_ReturnsNull()
        {
            // Arrange
            var mockDbContext = new Mock<ReadOnlyDbContext>();
            var contents = new List<Domain.V1.Entities.Contents.Content>
            {
            new Domain.V1.Entities.Contents.Content
            {
                Id = 15,
                Header = "Test Header 1",
                Module = "Module 1",
                ContentPlatform = new List < ContentPlatform > { new ContentPlatform { ID = 3, ContentID = 112, PlatformsID = "Web", RecordVersion = new byte[] { 1, 2, 3, 5 }, IsDeleted = false, CreatedDate = DateTime.UtcNow } },
                Status = true,
                RecordVersion = new byte[8] { 1, 2, 3, 4, 5, 6, 7, 8 },
                IsDeleted = false,
                CreatedDate =  (DateTime.UtcNow),

            },
            new Domain.V1.Entities.Contents.Content
            {
                Id = 20,
                Header = "Test Header 2",
                Module = "Module 2",
                ContentPlatform = new List < ContentPlatform > { new ContentPlatform { ID = 3, ContentID = 112, PlatformsID = "Web", RecordVersion = new byte[] { 1, 2, 3, 5 }, IsDeleted = false, CreatedDate = DateTime.UtcNow } },
                Status = false,
                RecordVersion = new byte[8] { 8, 7, 6, 5, 4, 3, 2, 1 },
                IsDeleted = true,
                CreatedDate =  (DateTime.UtcNow),
            }
        }.AsQueryable();
            var reasons = new List<Domain.V1.Entities.Contents.Reasons>
        {
            new Domain.V1.Entities.Contents.Reasons
            { Id = 5, ContentID = 15, ResonType = "Reason 1",CreatedDate=DateTime.UtcNow,
             IsDeleted=false,RecordVersion=new byte[8] { byte.MinValue, byte.MinValue, byte.MinValue, byte.MinValue, byte.MinValue, byte.MinValue, byte.MinValue, byte.MaxValue },
            Status=true},
            new Domain.V1.Entities.Contents.Reasons { Id = 6, ContentID = 20, ResonType = "Reason 2",CreatedDate=DateTime.UtcNow,
             IsDeleted=false,RecordVersion=new byte[8] { byte.MinValue, byte.MinValue, byte.MinValue, byte.MinValue, byte.MinValue, byte.MinValue, byte.MinValue, byte.MaxValue },
            Status=true}
        }.AsQueryable();
            var mockContentsDbSet = new Mock<DbSet<Domain.V1.Entities.Contents.Content>>();
            mockContentsDbSet.As<IQueryable<Domain.V1.Entities.Contents.Content>>().Setup(m => m.Provider).Returns(contents.Provider);
            mockContentsDbSet.As<IQueryable<Domain.V1.Entities.Contents.Content>>().Setup(m => m.Expression).Returns(contents.Expression);
            mockContentsDbSet.As<IQueryable<Domain.V1.Entities.Contents.Content>>().Setup(m => m.ElementType).Returns(contents.ElementType);
            mockContentsDbSet.As<IQueryable<Domain.V1.Entities.Contents.Content>>().Setup(m => m.GetEnumerator()).Returns(contents.GetEnumerator());

            var mockReasonsDbSet = new Mock<DbSet<Domain.V1.Entities.Contents.Reasons>>();
            mockReasonsDbSet.As<IQueryable<Domain.V1.Entities.Contents.Reasons>>().Setup(m => m.Provider).Returns(reasons.Provider);
            mockReasonsDbSet.As<IQueryable<Domain.V1.Entities.Contents.Reasons>>().Setup(m => m.Expression).Returns(reasons.Expression);
            mockReasonsDbSet.As<IQueryable<Domain.V1.Entities.Contents.Reasons>>().Setup(m => m.ElementType).Returns(reasons.ElementType);
            mockReasonsDbSet.As<IQueryable<Domain.V1.Entities.Contents.Reasons>>().Setup(m => m.GetEnumerator()).Returns(reasons.GetEnumerator());

            mockDbContext.Setup(x => x.Contents).Returns(mockContentsDbSet.Object);
            mockDbContext.Setup(x => x.ContentReasons).Returns(mockReasonsDbSet.Object);

            // Act

            var result = await _contentQueryService.GetContentById(15);

            // Assert
            Assert.Null(result);
        }

        [Fact]
        public async Task FindContentById_ContentDoesNotExist_ReturnsNull()
        {
            // Arrange
            var id = 10L;

            var mockSet = new Mock<DbSet<Domain.V1.Entities.Contents.Content>>();
            mockSet.Setup(m => m.FindAsync(id)).ReturnsAsync((Domain.V1.Entities.Contents.Content)null);

            var mockContext = new Mock<DbContext>();
            mockContext.Setup(c => c.Set<Domain.V1.Entities.Contents.Content>()).Returns(mockSet.Object);
            // mockContext.Setup(c => c.Contents.).Returns(mockSet.Object); // Ensure Contents property is set

            // var repository = new _contentQueryService.(mockContext.Object);

            // Act
            var result = await _contentQueryService.FindContentById(id);

            // Assert
            Assert.Null(result);
        }
        [Fact]
        public async Task FindReasonsById_ContentDoesNotExist_ReturnsNull()
        {
            // Arrange
            var id = 1L;

            var mockSet = new Mock<DbSet<Domain.V1.Entities.Contents.Reasons>>();
            mockSet.Setup(m => m.FindAsync(id)).ReturnsAsync((Domain.V1.Entities.Contents.Reasons)null);

            var mockContext = new Mock<DbContext>();
            mockContext.Setup(c => c.Set<Domain.V1.Entities.Contents.Reasons>()).Returns(mockSet.Object);
            // mockContext.Setup(c => c.Contents.).Returns(mockSet.Object); // Ensure Contents property is set

            // var repository = new _contentQueryService.(mockContext.Object);

            // Act
            var result = await _contentQueryService.FindReasonsById(id);

            // Assert
            Assert.True(result.Count == 0);
        }

        [Fact]
        public async Task GetContentSearch_ShouldReturnBadRequest_WhenSearchRequestIsNull()
        {
            var result = await _contentQueryService.GetContentSearch(null);

            result.Should().NotBeNull();
            result.IsSuccess.Should().BeFalse();
            result.HasError.Should().BeTrue();
            result.StatusCode.Should().Be(((int)ResponceStatusCode.BadRequest).ToString());
            result.Result.Should().BeNull();
        }
        [Fact]
        public async Task GetContentBySearch_ShouldReturnData_WhenNoFiltersApplied()
        {
            var request = new ContentSearchRequest
            {
                PageNumber = 1,
                PageSize = 10,
            };

            var result = await _contentQueryService.GetContentSearch(request);

            result.IsSuccess.Should().BeTrue();
            result.Result.Should().NotBeNull();
            if (result.Result.Data.Count > 0)
            {
                result.Result.Data.Should().HaveCount(1);
                result.Result.Data.First().Module.Should().Be("module1");
            }
        }
        [Fact]
        public async Task GetWhatsHappeningBySearch_ShouldFilterByTitle()
        {
            var request = new ContentSearchRequest
            {
                SelectedModule = "module1",
                PageNumber = 1,
                PageSize = 10
            };

            var result = await _contentQueryService.GetContentSearch(request);

            result.IsSuccess.Should().BeTrue();
            if (result.Result.Data.Count > 0)
            {
                result.Result.Data.Should().OnlyContain(x => x.Module.Contains("module1"));
            }
        }
        [Fact]
        public async Task GetContentBySearch_ShouldFilterByPlatformId()
        {
            var request = new ContentSearchRequest
            {
                SelectedPlatformsID = "platform1",
                PageNumber = 1,
                PageSize = 10
            };

            var result = await _contentQueryService.GetContentSearch(request);

            result.IsSuccess.Should().BeTrue();          
        }
        
        [Fact]
        public async Task FindContentById_ReturnsContent_WhenFound()
        {
            // Arrange
            var content = new Domain.V1.Entities.Contents.Content
            {
                Id = 10,
                Header = "Test",
                IsDeleted = false,
                RecordVersion = [1, 2, 3],
                Status = false,
                CreatedDate = DateTime.UtcNow,
            };
            await _context.Contents.AddAsync(content);
            await _context.SaveChangesAsync();

            var service = new ContentQueryService(_context);

            // Act
            var result = await service.FindContentById(10);

            // Assert
            result.Should().NotBeNull();
            result.Id.Should().Be(10);
        }
        [Fact]
        public async Task GetContentById_ReturnsNull_WhenContentNotFound()
        {
            var result = await _contentQueryService.GetContentById(999); // ID not added to DB
            result.Should().BeNull();
        }
        [Fact]
        public async Task FindReasonsById_ReturnsReason_WhenFound()
        {
            var reason = new Domain.V1.Entities.Contents.Reasons
            {
                Id = 5,
                ContentID = 1,
                ResonType = "Sample Reason",
                CreatedDate = DateTime.UtcNow,
                Status = true,
                IsDeleted = false,
                RecordVersion = new byte[8],
            };
            await _context.ContentReasons.AddAsync(reason);
            await _context.SaveChangesAsync();

            var result = await _contentQueryService.FindReasonsById(5);

            result.Should().NotBeNull();
        }
        [Fact]
        public async Task GetContentMasters_ShouldReturnData()
        {
            // Arrange
            string selectedModule = "module1";
            string selectedPlatformsID = "platform1";

            // Act
            var result = await _contentQueryService.GetContentMasters(selectedModule, selectedPlatformsID);

            // Assert
            result.Should().NotBeNull();
            if (result.Count > 0)
            {
                result.Count.Should().Be(1);
            }
        }
    }
}
