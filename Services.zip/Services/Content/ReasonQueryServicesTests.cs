﻿using Aurora.AdministrationService.API.Services.Service.Content;
using Aurora.AdministrationService.Infrastructure;
using Microsoft.EntityFrameworkCore;
using Moq;

namespace Aurora.AdministrationService.Tests.API.Services.Content
{   
   public  class ReasonQueryServicesTests
    {
        private readonly DbContextOptions<ReadOnlyDbContext> _options;
        private readonly ReadOnlyDbContext _context;
        private readonly ReasonQueryServices _reasonQueryService;
        public ReasonQueryServicesTests()
        {
            // Use a unique database name for each test to avoid shared state
            _options = new DbContextOptionsBuilder<ReadOnlyDbContext>()
                .UseInMemoryDatabase(databaseName: Guid.NewGuid().ToString()) // Unique name
                .Options;

            // Create a context that uses the InMemoryDatabase
            _context = new ReadOnlyDbContext(_options);
            // Create the service instance
            _reasonQueryService = new ReasonQueryServices(_context);
        }
       
        [Fact]
        public async Task FindReasonsById_ReasonDoesNotExist_ReturnsNull()
        {
            // Arrange
            var id = 1L;

            var mockSet = new Mock<DbSet<Domain.V1.Entities.Contents.Reasons>>();
            mockSet.Setup(m => m.FindAsync(id)).ReturnsAsync((Domain.V1.Entities.Contents.Reasons)null);

            var mockContext = new Mock<DbContext>();
            mockContext.Setup(c => c.Set<Domain.V1.Entities.Contents.Reasons>()).Returns(mockSet.Object);
            // mockContext.Setup(c => c.Contents.).Returns(mockSet.Object); // Ensure Contents property is set

            // var repository = new _contentQueryService.(mockContext.Object);

            // Act
            var result = await _reasonQueryService.FindReasonsById(id);

            // Assert
            Assert.Null(result);
        }


        [Fact]
        public async Task GetReasonsById_Returnsok()
        {
            // Arrange
            var id = 1L;
            var mockDbContext = new Mock<ReadOnlyDbContext>();
            var reasons = new List<Domain.V1.Entities.Contents.Reasons>
        {
            new Domain.V1.Entities.Contents.Reasons
            { Id = 1, ContentID = 15, ResonType = "Reason 1",CreatedDate=DateTime.UtcNow,
             IsDeleted=false,RecordVersion=new byte[8] { byte.MinValue, byte.MinValue, byte.MinValue, byte.MinValue, byte.MinValue, byte.MinValue, byte.MinValue, byte.MaxValue },
            Status=true},
            new Domain.V1.Entities.Contents.Reasons { Id = 6, ContentID = 20, ResonType = "Reason 2",CreatedDate=DateTime.UtcNow,
             IsDeleted=false,RecordVersion=new byte[8] { byte.MinValue, byte.MinValue, byte.MinValue, byte.MinValue, byte.MinValue, byte.MinValue, byte.MinValue, byte.MaxValue },
            Status=true}
        }.AsQueryable();
            var mockReasonsDbSet = new Mock<DbSet<Domain.V1.Entities.Contents.Reasons>>();
            mockReasonsDbSet.As<IQueryable<Domain.V1.Entities.Contents.Reasons>>().Setup(m => m.Provider).Returns(reasons.Provider);
            mockReasonsDbSet.As<IQueryable<Domain.V1.Entities.Contents.Reasons>>().Setup(m => m.Expression).Returns(reasons.Expression);
            mockReasonsDbSet.As<IQueryable<Domain.V1.Entities.Contents.Reasons>>().Setup(m => m.ElementType).Returns(reasons.ElementType);
            mockReasonsDbSet.As<IQueryable<Domain.V1.Entities.Contents.Reasons>>().Setup(m => m.GetEnumerator()).Returns(reasons.GetEnumerator());

             mockDbContext.Setup(x => x.ContentReasons).Returns(mockReasonsDbSet.Object);
            
            // Act
            var result = await _reasonQueryService.GetReasonsById(id);

            // Assert
            Assert.Null(result);
        }
    }
}
