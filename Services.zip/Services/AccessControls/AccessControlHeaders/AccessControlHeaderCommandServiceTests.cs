﻿using Aurora.AdministrationService.API.Models.Dto.AccessControls.AccessControlHeaders;
using Aurora.AdministrationService.API.Services.Service.AccessControls.AccessControlHeaders;
using Aurora.AdministrationService.Domain.V1.Entities.AccessControls;
using Aurora.AdministrationService.Infrastructure;
using AutoMapper;
using Microsoft.EntityFrameworkCore;
using Moq;

namespace Aurora.AdministrationService.Tests.API.Services.AccessControls.AccessControlHeaders
{
    public class AccessControlHeaderCommandServiceTests
    {
        private readonly Mock<ReadWriteDbContext> _readWriteDbContextMock;
        private readonly Mock<ReadOnlyDbContext> _readOnlyDbContextMock;
        private readonly Mock<IMapper> _mapperMock;
        private AccessControlHeaderCommandService _accessControlHeaderCommandService;
        private readonly Mock<AccessControlHeaderQueryService> _accessControlHeaderQueryService;

        public AccessControlHeaderCommandServiceTests()
        {
            // Initialize the mocks
            _mapperMock = new Mock<IMapper>();
            _readWriteDbContextMock = new Mock<ReadWriteDbContext>();
            _readOnlyDbContextMock = new Mock<ReadOnlyDbContext>();
            _accessControlHeaderQueryService = new Mock<AccessControlHeaderQueryService>();


            // Setup in-memory ready only database for testing
            DbContextOptions<ReadWriteDbContext> options = new DbContextOptionsBuilder<ReadWriteDbContext>()
              .UseInMemoryDatabase(databaseName: "AdminAccessControlHeaderTestDB").Options;

            _readWriteDbContextMock = new(options);

            // Initialize the service being tested
            _accessControlHeaderCommandService = new AccessControlHeaderCommandService(_readWriteDbContextMock.Object, _mapperMock.Object);
        }

        [Fact]
        public async Task CreateAccessControlHeaderAsync_ShouldReturnTrue_WhenAccessControlHeaderIsCreatedSuccessfully()
        {
            // Arrange
            var newAccessControlHeader = new AccessControlHeaderDto
            {
                RoleID = 1,
                AccessControlMasterID = 1,
            };

            // Mock AutoMapper to return a AccessControlHeader entity
            var accessControlHeaderId = 1;
            var accessControlHeaderEntity = new AccessControlHeader
            {
                Id = accessControlHeaderId,
                RoleID = 1,
                AccessControlMasterID = 1,
                IsDeleted = false,
                CreatedBy = "Admin",
                CreatedDate = DateTime.UtcNow,
                UpdatedBy = "Admin",  // Adding the missing property
                UpdatedDate = DateTime.UtcNow,// Assuming UpdatedDate is required as well
            };


            // Mock AutoMapper to return the AccessControlHeader entity
            _mapperMock.Setup(m => m.Map<AccessControlHeader>(newAccessControlHeader)).Returns(accessControlHeaderEntity);

            // Mock DbContext to simulate saving the entity without actually hitting the database
            _readWriteDbContextMock.Setup(db => db.AccessControlHeaders.Add(It.IsAny<AccessControlHeader>()));

            // Act
            var result = await _accessControlHeaderCommandService.CreateAccessControlHeaderAsync(newAccessControlHeader);

            // Assert
            Assert.True(result);
            _readWriteDbContextMock.Verify(db => db.AccessControlHeaders.Add(It.Is<AccessControlHeader>(l => l.RoleID == 1)), Times.Once);
        }


        [Fact]
        public async Task CreateAccessControlHeaderAsync_ShouldReturnFalse_WhenExceptionOccurs()
        {
            // Arrange
            var newAccessControlHeader = new AccessControlHeaderDto
            {
                RoleID = 1,
                AccessControlMasterID = 1,
            };

            // Mock AutoMapper to return a AccessControlHeader entity
            var accessControlHeaderId = 1;
            var accessControlHeaderEntity = new AccessControlHeader
            {
                Id = accessControlHeaderId,
                RoleID = 1,
                AccessControlMasterID = 1,
                IsDeleted = false,
                CreatedBy = "Admin",
                CreatedDate = DateTime.UtcNow,
                UpdatedBy = "Admin",  // Adding the missing property
                UpdatedDate = DateTime.UtcNow,// Assuming UpdatedDate is required as well
            };

            //Setup
            _mapperMock.Setup(m => m.Map<AccessControlHeader>(newAccessControlHeader)).Returns(accessControlHeaderEntity);

            // Act
            var result = await _accessControlHeaderCommandService.CreateAccessControlHeaderAsync(newAccessControlHeader);

            // Assert
            Assert.False(result);
        }
        [Fact]
        public async Task Test_UpdateAccessControlHeader_Returns_Success()
        {
            //Arrange
            DbContextOptions<ReadWriteDbContext> options = new DbContextOptionsBuilder<ReadWriteDbContext>()
               .UseInMemoryDatabase(databaseName: "UpdateAccessControlHeader").Options;

            byte[] concurrencyToken = new byte[8] { byte.MinValue, byte.MinValue, byte.MinValue, byte.MinValue, byte.MinValue, byte.MinValue, byte.MinValue, byte.MaxValue };
            var accessControlHeader = new AccessControlHeader
            {
                Id = 1,
                RoleID = 1,
                AccessControlMasterID = 1,
                IsDeleted = false,
                CreatedBy = "Admin",
                CreatedDate = DateTime.UtcNow,
                UpdatedBy = "Admin",  // Adding the missing property
                UpdatedDate = DateTime.UtcNow,// Assuming UpdatedDate is required as well
                RecordVersion = concurrencyToken
            };


            //Arrange
            using ReadWriteDbContext dbContext = new(options);
            dbContext.AccessControlHeaders.Add(accessControlHeader);
            await dbContext.SaveChangesAsync();


            UpdateAccessControlHeaderRequest updateModel = new UpdateAccessControlHeaderRequest
            {
                Id = 1,
                RoleID = 1,
                AccessControlMasterID = 1,
                RecordVersion = concurrencyToken
            };

            //updateModel.ID = 1;
            updateModel.RecordVersion = accessControlHeader.RecordVersion;

            _accessControlHeaderCommandService = new AccessControlHeaderCommandService(dbContext, _mapperMock.Object);

            // Act
            bool result = await _accessControlHeaderCommandService.UpdateAccessControlHeaderAsync(updateModel, accessControlHeader);

            Assert.True(result);
        }
        [Fact]
        public async Task Test_DeleteAccessControlHeader_Returns_Success()
        {
            //Arrange
            DbContextOptions<ReadWriteDbContext> options = new DbContextOptionsBuilder<ReadWriteDbContext>()
               .UseInMemoryDatabase(databaseName: "DeleteAccessControlHeader").Options;

            byte[] concurrencyToken = new byte[8] { byte.MinValue, byte.MinValue, byte.MinValue, byte.MinValue, byte.MinValue, byte.MinValue, byte.MinValue, byte.MaxValue };
            var accessControlHeader = new AccessControlHeader
            {
                Id = 1,
                RoleID = 1,
                AccessControlMasterID = 1,
                IsDeleted = false,
                CreatedBy = "Admin",
                CreatedDate = DateTime.UtcNow,
                UpdatedBy = "Admin",  // Adding the missing property
                UpdatedDate = DateTime.UtcNow,// Assuming UpdatedDate is required as well
                RecordVersion = concurrencyToken
            };



            //Arrange
            using ReadWriteDbContext dbContext = new(options);
            dbContext.AccessControlHeaders.Add(accessControlHeader);
            await dbContext.SaveChangesAsync();

            _accessControlHeaderCommandService = new AccessControlHeaderCommandService(dbContext, _mapperMock.Object);

            // Act
            bool result = await _accessControlHeaderCommandService.DeleteAccessControlHeaderByIdAsync(concurrencyToken, accessControlHeader);

            Assert.True(result);
        }
    }
}
