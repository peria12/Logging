﻿using Aurora.AdministrationService.API.Models.Dto.AccessControls.AccessControlHeaders;
using Aurora.AdministrationService.API.Services.Service.AccessControls.AccessControlHeaders;
using Aurora.AdministrationService.CrossCutting.CommonModels;
using Aurora.AdministrationService.Domain.V1.Entities.AccessControls;
using Aurora.AdministrationService.Infrastructure;
using AutoMapper;
using Microsoft.EntityFrameworkCore;
using Moq;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Aurora.AdministrationService.Tests.API.Services.AccessControls.AccessControlHeaders
{
    public class AccessControlHeaderQueryServiceTests
    {
        private readonly Mock<ReadOnlyDbContext> _readOnlyDbContextMock;
        private readonly Mock<IMapper> _mapperMock;
        private readonly AccessControlHeaderQueryService _accessControlHeaderQueryService;
        private Mock<DbSet<AccessControlHeader>> _mockDbSet;

        public AccessControlHeaderQueryServiceTests()
        {
            //Initialize mock
            _readOnlyDbContextMock = new Mock<ReadOnlyDbContext>();
            _mapperMock = new Mock<IMapper>();

            // Setup in-memory ready only database for testing
            DbContextOptions<ReadOnlyDbContext> options = new DbContextOptionsBuilder<ReadOnlyDbContext>()
              .UseInMemoryDatabase(databaseName: "AccessControlHeaderTestDB").Options;

            _readOnlyDbContextMock = new(options);

            _mockDbSet = new Mock<DbSet<AccessControlHeader>>();

            var data = new List<AccessControlHeader>
            {
               new AccessControlHeader {
                Id = 1,
                RoleID = 1,
                AccessControlMasterID = 1,
                IsDeleted = false,
                CreatedBy = "Admin",
                CreatedDate = DateTime.UtcNow,
                UpdatedBy = "Admin",  // Adding the missing property
                UpdatedDate = DateTime.UtcNow,// Assuming UpdatedDate is required as well
            },
               new AccessControlHeader {
                Id = 2,
                RoleID = 1,
                AccessControlMasterID = 1,
                IsDeleted = false,
                CreatedBy = "Admin",
                CreatedDate = DateTime.UtcNow,
                UpdatedBy = "Admin",  // Adding the missing property
                UpdatedDate = DateTime.UtcNow,// Assuming UpdatedDate is required as well
            }

            }.AsQueryable();


            //Setup
            _mockDbSet.As<IQueryable<AccessControlHeader>>().Setup(m => m.Provider).Returns(data.Provider);
            _mockDbSet.As<IQueryable<AccessControlHeader>>().Setup(m => m.Expression).Returns(data.Expression);
            _mockDbSet.As<IQueryable<AccessControlHeader>>().Setup(m => m.ElementType).Returns(data.ElementType);
            _mockDbSet.As<IQueryable<AccessControlHeader>>().Setup(m => m.GetEnumerator()).Returns(data.GetEnumerator());
            _readOnlyDbContextMock.Setup(c => c.AccessControlHeaders).Returns(_mockDbSet.Object);

            // Create the service instance
            _accessControlHeaderQueryService = new AccessControlHeaderQueryService(_readOnlyDbContextMock.Object, _mapperMock.Object);
        }

        [Fact]
        public async Task GetAccessControlHeaderById_LogoExists_ReturnsLogoDetailDto()
        {
            // Arrange
            var accessControlHeaderId = 1L;
            var accessControlHeader = new AccessControlHeader
            {
                Id = 1,
                RoleID = 1,
                AccessControlMasterID = 1,
                IsDeleted = false,
                CreatedBy = "Admin",
                CreatedDate = DateTime.UtcNow,
                UpdatedBy = "Admin",  // Adding the missing property
                UpdatedDate = DateTime.UtcNow,// Assuming UpdatedDate is required as well
            };

            var accessControlHeaderDto = new GetAccessControlHeaderDetailDto
            {
                Id = 1,
                RoleID = 1,
                AccessControlMasterID = 1,
            };

            _readOnlyDbContextMock.Setup(db => db.AccessControlHeaders.FindAsync(accessControlHeaderId))
                .ReturnsAsync(accessControlHeader);

            _mapperMock.Setup(m => m.Map<GetAccessControlHeaderDetailDto>(accessControlHeader))
                .Returns(accessControlHeaderDto);

            // Act
            var result = await _accessControlHeaderQueryService.GetAccessControlHeaderById(accessControlHeaderId);

            // Assert
            Assert.NotNull(result);
            Assert.Equal(accessControlHeaderId, result.Id);
            Assert.Equal(1, result.RoleID);
        }

        [Fact]
        public async Task GetAccessControlHeaderById_accessControlHeaderNotFound_ReturnsNull()
        {
            //Arrange
            var accessControlHeaderId = 1;
            var accessControlHeader = new AccessControlHeader
            {
                Id = 1,
                RoleID = 1,
                AccessControlMasterID = 1,
                IsDeleted = false,
                CreatedBy = "Admin",
                CreatedDate = DateTime.UtcNow,
                UpdatedBy = "Admin",  // Adding the missing property
                UpdatedDate = DateTime.UtcNow,// Assuming UpdatedDate is required as well
            };

            _readOnlyDbContextMock.Setup(db => db.AccessControlHeaders.FindAsync(accessControlHeaderId))
                .ReturnsAsync(accessControlHeader);

            //Act
            var result = await _accessControlHeaderQueryService.GetAccessControlHeaderById(accessControlHeaderId);

            //Assert
            Assert.Null(result);
        }

        [Fact]
        public async Task GetAccessControlHeaderById_accessControlHeaderExists_BindingError_ReturnsNull()
        {
            // Arrange
            byte[] concurrencyToken = new byte[8] { byte.MinValue, byte.MinValue, byte.MinValue, byte.MinValue, byte.MinValue, byte.MinValue, byte.MinValue, byte.MaxValue };
            var accessControlHeaderId = 1L;
            var accessControlHeader = new AccessControlHeader
            {
                Id = 1,
                RoleID = 1,
                AccessControlMasterID = 1,
                IsDeleted = false,
                CreatedBy = "Admin",
                CreatedDate = DateTime.UtcNow,
                UpdatedBy = "Admin",  // Adding the missing property
                UpdatedDate = DateTime.UtcNow,// Assuming UpdatedDate is required as well
                RecordVersion = concurrencyToken
            };

            _readOnlyDbContextMock.Setup(db => db.AccessControlHeaders.FindAsync(accessControlHeaderId))
                .ReturnsAsync(accessControlHeader);

            _mapperMock.Setup(m => m.Map<GetAccessControlHeaderDetailDto>(accessControlHeader))
                .Throws(new AutoMapperMappingException("Error mapping entity to DTO"));

            // Act & Assert
            var exception = await Assert.ThrowsAsync<AutoMapperMappingException>(
                () => _accessControlHeaderQueryService.GetAccessControlHeaderById(accessControlHeaderId)
            );

            Assert.Equal("Error mapping entity to DTO", exception.Message);
        }

        [Fact]
        public async Task FindAccessControlHeaderById_accessControlHeaderExists_ReturnsaccessControlHeader()
        {
            // Arrange
            byte[] concurrencyToken = new byte[8] { byte.MinValue, byte.MinValue, byte.MinValue, byte.MinValue, byte.MinValue, byte.MinValue, byte.MinValue, byte.MaxValue };
            long accessControlHeaderId = 1L;
            var accessControlHeader = new AccessControlHeader
            {
                Id = accessControlHeaderId,
                RoleID = 1,
                AccessControlMasterID = 1,
                IsDeleted = false,
                CreatedBy = "Admin",
                CreatedDate = DateTime.UtcNow,
                UpdatedBy = "Admin",  // Adding the missing property
                UpdatedDate = DateTime.UtcNow,// Assuming UpdatedDate is required as well
                RecordVersion = concurrencyToken
            };

            // Mock the FindAsync method to return the accessControlHeader
            _readOnlyDbContextMock.Setup(db => db.AccessControlHeaders.FindAsync(accessControlHeaderId))
                .ReturnsAsync(accessControlHeader);

            // Act
            var result = await _accessControlHeaderQueryService.FindAccessControlHeaderById(accessControlHeaderId);

            // Assert
            Assert.NotNull(result);
        }

        [Fact]
        public async Task FindAccessControlHeaderById_accessControlHeaderNotFound_ReturnsNull()
        {
            // Arrange
            var accessControlHeaderId = 1L;
            var accessControlHeader = new AccessControlHeader
            {
                Id = accessControlHeaderId,
                RoleID = 1,
                AccessControlMasterID = 1,
                IsDeleted = false,
                CreatedBy = "Admin",
                CreatedDate = DateTime.UtcNow,
                UpdatedBy = "Admin",  // Adding the missing property
                UpdatedDate = DateTime.UtcNow,// Assuming UpdatedDate is required as well
            };

            // Mock the FindAsync method to return null (accessControlHeader not found)
            _readOnlyDbContextMock.Setup(db => db.AccessControlHeaders.FindAsync(accessControlHeaderId))
                .ReturnsAsync(accessControlHeader);

            // Act
            var result = await _accessControlHeaderQueryService.FindAccessControlHeaderById(accessControlHeaderId);

            // Assert
            Assert.NotNull(result);
        }

        [Fact]
        public void GetAccessControlHeaderList_ReturnsCorrectAccessControlHeaderList()
        {
            // Act
            var result = _accessControlHeaderQueryService.GetAccessControlHeaderList();

            // Assert
            Assert.NotNull(result);
            Assert.Equal(2, result.Count); // Verifying that 3 items are returned

            // Verifying that the returned items are mapped correctly
            Assert.Contains(result, r => r.Id == 1 && r.RoleID == 1);
            Assert.Contains(result, r => r.Id == 2 && r.RoleID == 1);
        }

        [Fact]
        public async Task IsAccessControlHeaderAlreadyExist_ShouldReturnTrue_WhenaccessControlHeaderExists()
        {
            // Arrange
            var accessControlHeaderId = 1L;
            var accessControlHeader = new AccessControlHeader
            {
                Id = 1L,
                RoleID = 1,
                AccessControlMasterID = 1,
                IsDeleted = false,
                CreatedBy = "Admin",
                CreatedDate = DateTime.UtcNow,
                UpdatedBy = "Admin",  // Adding the missing property
                UpdatedDate = DateTime.UtcNow,// Assuming UpdatedDate is required as well
            };

            // Mock the FindAsync method to return the accessControlHeader
            _readOnlyDbContextMock.Setup(db => db.AccessControlHeaders.FindAsync(accessControlHeaderId))
                .ReturnsAsync(accessControlHeader);

            // Act
            var result = await _accessControlHeaderQueryService.IsAccessControlHeaderAlreadyExist(accessControlHeaderId);

            // Assert
            Assert.True(result.result);
            Assert.Equal(ResponseMessage.STATUS_DATA_FOUND, result.message);
        }

        [Fact]
        public async Task IsAccessControlHeaderAlreadyExist_ShouldReturnFalse_WhenaccessControlHeaderDoesNotExist()
        {
            // Arrange
            var accessControlHeaderId = 3;

            // Act
            var result = await _accessControlHeaderQueryService.IsAccessControlHeaderAlreadyExist(accessControlHeaderId);

            // Assert
            Assert.False(result.result);
            Assert.Equal(ResponseMessage.STATUS_NODATA, result.message);
        }
    }
}
