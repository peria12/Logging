﻿using Aurora.AdministrationService.API.Models.Dto.AccessControls.AccessControlParameters;
using Aurora.AdministrationService.API.Services.Service.AccessControls.AccessControlParameters;
using Aurora.AdministrationService.CrossCutting.CommonModels;
using Aurora.AdministrationService.Domain.V1.Entities.AccessControls;
using Aurora.AdministrationService.Infrastructure;
using AutoMapper;
using Microsoft.EntityFrameworkCore;
using Moq;

namespace Aurora.AdministrationService.Tests.API.Services.AccessControls.AccessControlParameters
{
    public class AccessControlParameterQueryServiceTests
    {
        private readonly Mock<ReadOnlyDbContext> _readOnlyDbContextMock;
        private readonly Mock<IMapper> _mapperMock;
        private readonly AccessControlParameterQueryService _accessControlParameterQueryService;
        private Mock<DbSet<Domain.V1.Entities.AccessControls.AccessControlParameter>> _mockDbSet;

        public AccessControlParameterQueryServiceTests()
        {
            //Initialize mock
            _readOnlyDbContextMock = new Mock<ReadOnlyDbContext>();
            _mapperMock = new Mock<IMapper>();

            // Setup in-memory ready only database for testing
            DbContextOptions<ReadOnlyDbContext> options = new DbContextOptionsBuilder<ReadOnlyDbContext>()
              .UseInMemoryDatabase(databaseName: "AccessControlParameterTestDB").Options;

            _readOnlyDbContextMock = new(options);

            _mockDbSet = new Mock<DbSet<Domain.V1.Entities.AccessControls.AccessControlParameter>>();

            var data = new List<Domain.V1.Entities.AccessControls.AccessControlParameter>
            {
               new Domain.V1.Entities.AccessControls.AccessControlParameter {
                Id = 1,
                AccessControlHeaderID = 1,
                Value="test",
                IsDeleted = false,
                CreatedBy = "Admin",
                CreatedDate = DateTime.UtcNow,
                UpdatedBy = "Admin",  // Adding the missing property
                UpdatedDate = DateTime.UtcNow,// Assuming UpdatedDate is required as well
            },
               new Domain.V1.Entities.AccessControls.AccessControlParameter {
                Id = 2,
                AccessControlHeaderID = 1,
                Value="test",
                IsDeleted = false,
                CreatedBy = "Admin",
                CreatedDate = DateTime.UtcNow,
                UpdatedBy = "Admin",  // Adding the missing property
                UpdatedDate = DateTime.UtcNow,// Assuming UpdatedDate is required as well
            }

            }.AsQueryable();


            //Setup
            _mockDbSet.As<IQueryable<Domain.V1.Entities.AccessControls.AccessControlParameter>>().Setup(m => m.Provider).Returns(data.Provider);
            _mockDbSet.As<IQueryable<Domain.V1.Entities.AccessControls.AccessControlParameter>>().Setup(m => m.Expression).Returns(data.Expression);
            _mockDbSet.As<IQueryable<Domain.V1.Entities.AccessControls.AccessControlParameter>>().Setup(m => m.ElementType).Returns(data.ElementType);
            _mockDbSet.As<IQueryable<Domain.V1.Entities.AccessControls.AccessControlParameter>>().Setup(m => m.GetEnumerator()).Returns(data.GetEnumerator());
            _readOnlyDbContextMock.Setup(c => c.AccessControlParameters).Returns(_mockDbSet.Object);

            // Create the service instance
            _accessControlParameterQueryService = new AccessControlParameterQueryService(_readOnlyDbContextMock.Object, _mapperMock.Object);
        }

        [Fact]
        public async Task GetAccessControlParameterById_LogoExists_ReturnsLogoDetailDto()
        {
            // Arrange
            var accessControlParameterId = 1L;
            var accessControlParameter = new Domain.V1.Entities.AccessControls.AccessControlParameter
            {
                Id = 1,
                AccessControlHeaderID = 1,
                Value = "test",
                IsDeleted = false,
                CreatedBy = "Admin",
                CreatedDate = DateTime.UtcNow,
                UpdatedBy = "Admin",  // Adding the missing property
                UpdatedDate = DateTime.UtcNow,// Assuming UpdatedDate is required as well
            };

            var accessControlParameterDto = new GetAccessControlParameterDetailDto
            {
                Id = 1,
                AccessControlHeaderID = 1,
                Value = "test",
            };

            _readOnlyDbContextMock.Setup(db => db.AccessControlParameters.FindAsync(accessControlParameterId))
                .ReturnsAsync(accessControlParameter);

            _mapperMock.Setup(m => m.Map<GetAccessControlParameterDetailDto>(accessControlParameter))
                .Returns(accessControlParameterDto);

            // Act
            var result = await _accessControlParameterQueryService.GetAccessControlParameterById(accessControlParameterId);

            // Assert
            Assert.NotNull(result);
            Assert.Equal(accessControlParameterId, result.Id);
            Assert.Equal("test", result.Value);
        }

        [Fact]
        public async Task GetAccessControlParameterById_accessControlParameterNotFound_ReturnsNull()
        {
            //Arrange
            var accessControlParameterId = 1;
            var accessControlParameter = new Domain.V1.Entities.AccessControls.AccessControlParameter
            {
                Id = 1,
                AccessControlHeaderID = 1,
                Value = "test",
                IsDeleted = false,
                CreatedBy = "Admin",
                CreatedDate = DateTime.UtcNow,
                UpdatedBy = "Admin",  // Adding the missing property
                UpdatedDate = DateTime.UtcNow,// Assuming UpdatedDate is required as well
            };

            _readOnlyDbContextMock.Setup(db => db.AccessControlParameters.FindAsync(accessControlParameterId))
                .ReturnsAsync(accessControlParameter);

            //Act
            var result = await _accessControlParameterQueryService.GetAccessControlParameterById(accessControlParameterId);

            //Assert
            Assert.Null(result);
        }

        [Fact]
        public async Task GetAccessControlParameterById_accessControlParameterExists_BindingError_ReturnsNull()
        {
            // Arrange
            byte[] concurrencyToken = new byte[8] { byte.MinValue, byte.MinValue, byte.MinValue, byte.MinValue, byte.MinValue, byte.MinValue, byte.MinValue, byte.MaxValue };
            var accessControlParameterId = 1L;
            var accessControlParameter = new Domain.V1.Entities.AccessControls.AccessControlParameter
            {
                Id = 1,
                AccessControlHeaderID = 1,
                Value = "test",
                IsDeleted = false,
                CreatedBy = "Admin",
                CreatedDate = DateTime.UtcNow,
                UpdatedBy = "Admin",  // Adding the missing property
                UpdatedDate = DateTime.UtcNow,// Assuming UpdatedDate is required as well
                RecordVersion = concurrencyToken
            };

            _readOnlyDbContextMock.Setup(db => db.AccessControlParameters.FindAsync(accessControlParameterId))
                .ReturnsAsync(accessControlParameter);

            _mapperMock.Setup(m => m.Map<GetAccessControlParameterDetailDto>(accessControlParameter))
                .Throws(new AutoMapperMappingException("Error mapping entity to DTO"));

            // Act & Assert
            var exception = await Assert.ThrowsAsync<AutoMapperMappingException>(
                () => _accessControlParameterQueryService.GetAccessControlParameterById(accessControlParameterId)
            );

            Assert.Equal("Error mapping entity to DTO", exception.Message);
        }

        [Fact]
        public async Task FindAccessControlParameterById_accessControlParameterExists_ReturnsaccessControlParameter()
        {
            // Arrange
            byte[] concurrencyToken = new byte[8] { byte.MinValue, byte.MinValue, byte.MinValue, byte.MinValue, byte.MinValue, byte.MinValue, byte.MinValue, byte.MaxValue };
            long accessControlParameterId = 1;
            var accessControlParameter = new Domain.V1.Entities.AccessControls.AccessControlParameter
            {
                Id = accessControlParameterId,
                AccessControlHeaderID = 1,
                Value = "test",
                IsDeleted = false,
                CreatedBy = "Admin",
                CreatedDate = DateTime.UtcNow,
                UpdatedBy = "Admin",  // Adding the missing property
                UpdatedDate = DateTime.UtcNow,// Assuming UpdatedDate is required as well
                RecordVersion = concurrencyToken
            };

            // Mock the FindAsync method to return the accessControlParameter
            _readOnlyDbContextMock.Setup(db => db.AccessControlParameters.FindAsync(accessControlParameterId))
                .ReturnsAsync(accessControlParameter);

            // Act
            var result = await _accessControlParameterQueryService.FindAccessControlParameterById(accessControlParameterId);

            // Assert
            Assert.NotNull(result);
        }

        [Fact]
        public async Task FindAccessControlParameterById_accessControlParameterNotFound_ReturnsNull()
        {
            // Arrange
            var accessControlParameterId = 1L;
            var accessControlParameter = new Domain.V1.Entities.AccessControls.AccessControlParameter
            {
                Id = accessControlParameterId,
                AccessControlHeaderID = 1,
                Value = "test",
                IsDeleted = false,
                CreatedBy = "Admin",
                CreatedDate = DateTime.UtcNow,
                UpdatedBy = "Admin",  // Adding the missing property
                UpdatedDate = DateTime.UtcNow,// Assuming UpdatedDate is required as well
            };

            // Mock the FindAsync method to return null (accessControlParameter not found)
            _readOnlyDbContextMock.Setup(db => db.AccessControlParameters.FindAsync(accessControlParameterId))
                .ReturnsAsync(accessControlParameter);

            // Act
            var result = await _accessControlParameterQueryService.FindAccessControlParameterById(accessControlParameterId);

            // Assert
            Assert.NotNull(result);
        }

        [Fact]
        public void GetAccessControlParameterList_ReturnsCorrectAccessControlParameterList()
        {
            // Act
            var result = _accessControlParameterQueryService.GetAccessControlParameterList();

            // Assert
            Assert.NotNull(result);
            Assert.Equal(2, result.Count); // Verifying that 3 items are returned

            // Verifying that the returned items are mapped correctly
            Assert.Contains(result, r => r.Id == 1 && r.Value == "test");
            Assert.Contains(result, r => r.Id == 2 && r.Value == "test");
        }

        [Fact]
        public async Task IsAccessControlParameterAlreadyExist_ShouldReturnTrue_WhenaccessControlParameterExists()
        {
            // Arrange
            var accessControlParameterId = 1L;
            var accessControlParameter = new Domain.V1.Entities.AccessControls.AccessControlParameter
            {
                Id = 1L,
                AccessControlHeaderID = 1,
                Value = "test",
                IsDeleted = false,
                CreatedBy = "Admin",
                CreatedDate = DateTime.UtcNow,
                UpdatedBy = "Admin",  // Adding the missing property
                UpdatedDate = DateTime.UtcNow,// Assuming UpdatedDate is required as well
            };

            // Mock the FindAsync method to return the accessControlParameter
            _readOnlyDbContextMock.Setup(db => db.AccessControlParameters.FindAsync(accessControlParameterId))
                .ReturnsAsync(accessControlParameter);

            // Act
            var result = await _accessControlParameterQueryService.IsAccessControlParameterAlreadyExist(accessControlParameterId);

            // Assert
            Assert.True(result.result);
            Assert.Equal(ResponseMessage.STATUS_DATA_FOUND, result.message);
        }

        [Fact]
        public async Task IsAccessControlParameterAlreadyExist_ShouldReturnFalse_WhenaccessControlParameterDoesNotExist()
        {
            // Arrange
            var accessControlParameterId = 3;

            // Act
            var result = await _accessControlParameterQueryService.IsAccessControlParameterAlreadyExist(accessControlParameterId);

            // Assert
            Assert.False(result.result);
            Assert.Equal(ResponseMessage.STATUS_NODATA, result.message);
        }
    }
}
