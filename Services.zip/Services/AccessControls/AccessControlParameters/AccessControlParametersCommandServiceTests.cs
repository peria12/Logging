﻿using Aurora.AdministrationService.API.Models.Dto.AccessControls.AccessControlParameters;
using Aurora.AdministrationService.API.Services.Service.AccessControls.AccessControlParameters;
using Aurora.AdministrationService.Infrastructure;
using AutoMapper;
using Microsoft.EntityFrameworkCore;
using Moq;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Aurora.AdministrationService.Tests.API.Services.AccessControls.AccessControlParameter
{
    public class AccessControlParameterCommandServiceTests
    {
        private readonly Mock<ReadWriteDbContext> _readWriteDbContextMock;
        private readonly Mock<ReadOnlyDbContext> _readOnlyDbContextMock;
        private readonly Mock<IMapper> _mapperMock;
        private AccessControlParameterCommandService _AccessControlParameterCommandService;
        private readonly Mock<AccessControlParameterQueryService> _AccessControlParameterQueryService;

        public AccessControlParameterCommandServiceTests()
        {
            // Initialize the mocks
            _mapperMock = new Mock<IMapper>();
            _readWriteDbContextMock = new Mock<ReadWriteDbContext>();
            _readOnlyDbContextMock = new Mock<ReadOnlyDbContext>();
            _AccessControlParameterQueryService = new Mock<AccessControlParameterQueryService>();


            // Setup in-memory ready only database for testing
            DbContextOptions<ReadWriteDbContext> options = new DbContextOptionsBuilder<ReadWriteDbContext>()
              .UseInMemoryDatabase(databaseName: "AdminAccessControlParameterTestDB").Options;

            _readWriteDbContextMock = new(options);

            // Initialize the service being tested
            _AccessControlParameterCommandService = new AccessControlParameterCommandService(_readWriteDbContextMock.Object, _mapperMock.Object);
        }

        [Fact]
        public async Task CreateAccessControlParameterAsync_ShouldReturnTrue_WhenAccessControlParameterIsCreatedSuccessfully()
        {
            // Arrange
            var newAccessControlParameter = new AccessControlParameterDto
            {
                AccessControlHeaderID = 1,
                Value="test",
            };

            // Mock AutoMapper to return a AccessControlParameter entity
            var AccessControlParameterId = 1;
            var AccessControlParameterEntity = new Domain.V1.Entities.AccessControls.AccessControlParameter
            {
                Id = AccessControlParameterId,
                AccessControlHeaderID = 1,
                Value = "test",
                IsDeleted = false,
                CreatedBy = "Admin",
                CreatedDate = DateTime.UtcNow,
                UpdatedBy = "Admin",  // Adding the missing property
                UpdatedDate = DateTime.UtcNow,// Assuming UpdatedDate is required as well
            };


            // Mock AutoMapper to return the AccessControlParameter entity
            _mapperMock.Setup(m => m.Map<Domain.V1.Entities.AccessControls.AccessControlParameter>(newAccessControlParameter)).Returns(AccessControlParameterEntity);

            // Mock DbContext to simulate saving the entity without actually hitting the database
            _readWriteDbContextMock.Setup(db => db.AccessControlParameters.Add(It.IsAny<Domain.V1.Entities.AccessControls.AccessControlParameter>()));

            // Act
            var result = await _AccessControlParameterCommandService.CreateAccessControlParameterAsync(newAccessControlParameter);

            // Assert
            Assert.True(result);
            _readWriteDbContextMock.Verify(db => db.AccessControlParameters.Add(It.Is<Domain.V1.Entities.AccessControls.AccessControlParameter>(l => l.Value == "test")), Times.Once);
        }


        [Fact]
        public async Task CreateAccessControlParameterAsync_ShouldReturnFalse_WhenExceptionOccurs()
        {
            // Arrange
            var newAccessControlParameter = new AccessControlParameterDto
            {
                AccessControlHeaderID = 1,
                Value = "test",
            };

            // Mock AutoMapper to return a AccessControlParameter entity
            var AccessControlParameterId = 1;
            var AccessControlParameterEntity = new Domain.V1.Entities.AccessControls.AccessControlParameter
            {
                Id = AccessControlParameterId,
                AccessControlHeaderID = 1,
                Value = "test",
                IsDeleted = false,
                CreatedBy = "Admin",
                CreatedDate = DateTime.UtcNow,
                UpdatedBy = "Admin",  // Adding the missing property
                UpdatedDate = DateTime.UtcNow,// Assuming UpdatedDate is required as well
            };

            //Setup
            _mapperMock.Setup(m => m.Map<Domain.V1.Entities.AccessControls.AccessControlParameter>(newAccessControlParameter)).Returns(AccessControlParameterEntity);

            // Act
            var result = await _AccessControlParameterCommandService.CreateAccessControlParameterAsync(newAccessControlParameter);

            // Assert
            Assert.False(result);
        }
        [Fact]
        public async Task Test_UpdateAccessControlParameter_Returns_Success()
        {
            //Arrange
            DbContextOptions<ReadWriteDbContext> options = new DbContextOptionsBuilder<ReadWriteDbContext>()
               .UseInMemoryDatabase(databaseName: "UpdateAccessControlParameter").Options;

            byte[] concurrencyToken = new byte[8] { byte.MinValue, byte.MinValue, byte.MinValue, byte.MinValue, byte.MinValue, byte.MinValue, byte.MinValue, byte.MaxValue };
            var AccessControlParameter = new Domain.V1.Entities.AccessControls.AccessControlParameter
            {
                Id = 1,
                AccessControlHeaderID = 1,
                Value = "test",
                IsDeleted = false,
                CreatedBy = "Admin",
                CreatedDate = DateTime.UtcNow,
                UpdatedBy = "Admin",  // Adding the missing property
                UpdatedDate = DateTime.UtcNow,// Assuming UpdatedDate is required as well
                RecordVersion = concurrencyToken
            };


            //Arrange
            using ReadWriteDbContext dbContext = new(options);
            dbContext.AccessControlParameters.Add(AccessControlParameter);
            await dbContext.SaveChangesAsync();


            UpdateAccessControlParameterRequest updateModel = new UpdateAccessControlParameterRequest
            {
                Id = 1,
                AccessControlHeaderID = 1,
                Value = "test",
                RecordVersion = concurrencyToken
            };

            //updateModel.ID = 1;
            updateModel.RecordVersion = AccessControlParameter.RecordVersion;

            _AccessControlParameterCommandService = new AccessControlParameterCommandService(dbContext, _mapperMock.Object);

            // Act
            bool result = await _AccessControlParameterCommandService.UpdateAccessControlParameterAsync(updateModel, AccessControlParameter);

            Assert.True(result);
        }
        [Fact]
        public async Task Test_DeleteAccessControlParameter_Returns_Success()
        {
            //Arrange
            DbContextOptions<ReadWriteDbContext> options = new DbContextOptionsBuilder<ReadWriteDbContext>()
               .UseInMemoryDatabase(databaseName: "DeleteAccessControlParameter").Options;

            byte[] concurrencyToken = new byte[8] { byte.MinValue, byte.MinValue, byte.MinValue, byte.MinValue, byte.MinValue, byte.MinValue, byte.MinValue, byte.MaxValue };
            var AccessControlParameter = new Domain.V1.Entities.AccessControls.AccessControlParameter
            {
                Id = 1,
                AccessControlHeaderID = 1,
                Value = "test",
                IsDeleted = false,
                CreatedBy = "Admin",
                CreatedDate = DateTime.UtcNow,
                UpdatedBy = "Admin",  // Adding the missing property
                UpdatedDate = DateTime.UtcNow,// Assuming UpdatedDate is required as well
                RecordVersion = concurrencyToken
            };



            //Arrange
            using ReadWriteDbContext dbContext = new(options);
            dbContext.AccessControlParameters.Add(AccessControlParameter);
            await dbContext.SaveChangesAsync();

            _AccessControlParameterCommandService = new AccessControlParameterCommandService(dbContext, _mapperMock.Object);

            // Act
            bool result = await _AccessControlParameterCommandService.DeleteAccessControlParameterByIdAsync(concurrencyToken, AccessControlParameter);

            Assert.True(result);
        }
    }
}
