﻿using Aurora.AdministrationService.API.Models.Dto.AccessControls.AccessControlMasters;
using Aurora.AdministrationService.API.Services.Service.AccessControls.AccessControlMasters;
using Aurora.AdministrationService.Domain.V1.Entities.AccessControls;
using Aurora.AdministrationService.Infrastructure;
using AutoMapper;
using Microsoft.EntityFrameworkCore;
using Moq;

namespace Aurora.AdministrationService.Tests.API.Services.AccessControls.AccessControlMasters
{
    public class AccessControlMasterCommandServiceTests
    {
        private readonly Mock<ReadWriteDbContext> _readWriteDbContextMock;
        private readonly Mock<ReadOnlyDbContext> _readOnlyDbContextMock;
        private readonly Mock<IMapper> _mapperMock;
        private AccessControlMasterCommandService _accessControlMasterCommandService;
        private readonly Mock<AccessControlMasterQueryService> _accessControlMasterQueryService;

        public AccessControlMasterCommandServiceTests()
        {
            // Initialize the mocks
            _mapperMock = new Mock<IMapper>();
            _readWriteDbContextMock = new Mock<ReadWriteDbContext>();
            _readOnlyDbContextMock = new Mock<ReadOnlyDbContext>();
            _accessControlMasterQueryService = new Mock<AccessControlMasterQueryService>();


            // Setup in-memory ready only database for testing
            DbContextOptions<ReadWriteDbContext> options = new DbContextOptionsBuilder<ReadWriteDbContext>()
              .UseInMemoryDatabase(databaseName: "AdminAccessControlMasterTestDB").Options;

            _readWriteDbContextMock = new(options);

            // Initialize the service being tested
            _accessControlMasterCommandService = new AccessControlMasterCommandService(_readWriteDbContextMock.Object, _mapperMock.Object);
        }

        [Fact]
        public async Task CreateAccessControlMasterAsync_ShouldReturnTrue_WhenAccessControlMasterIsCreatedSuccessfully()
        {
            // Arrange
            var newAccessControlMaster = new AccessControlMasterDto
            {
                Key = "test",
            };

            // Mock AutoMapper to return a AccessControlMaster entity
            var accessControlMasterId = 1;
            var accessControlMasterEntity = new AccessControlMaster
            {
                Id = accessControlMasterId,
                Key = "test",
                IsDeleted = false,
                CreatedBy = "Admin",
                CreatedDate = DateTime.UtcNow,
                UpdatedBy = "Admin",  // Adding the missing property
                UpdatedDate = DateTime.UtcNow,// Assuming UpdatedDate is required as well
            };


            // Mock AutoMapper to return the AccessControlMaster entity
            _mapperMock.Setup(m => m.Map<AccessControlMaster>(newAccessControlMaster)).Returns(accessControlMasterEntity);

            // Mock DbContext to simulate saving the entity without actually hitting the database
            _readWriteDbContextMock.Setup(db => db.AccessControlMasters.Add(It.IsAny<AccessControlMaster>()));

            // Act
            var result = await _accessControlMasterCommandService.CreateAccessControlMasterAsync(newAccessControlMaster);

            // Assert
            Assert.True(result);
            _readWriteDbContextMock.Verify(db => db.AccessControlMasters.Add(It.Is<AccessControlMaster>(l => l.Key == "test")), Times.Once);
        }


        [Fact]
        public async Task CreateAccessControlMasterAsync_ShouldReturnFalse_WhenExceptionOccurs()
        {
            // Arrange
            var newAccessControlMaster = new AccessControlMasterDto
            {
                Key = "test",
            };

            // Mock AutoMapper to return a AccessControlMaster entity
            var accessControlMasterId = 1;
            var accessControlMasterEntity = new AccessControlMaster
            {
                Id = accessControlMasterId,
                Key = "test",
                IsDeleted = false,
                CreatedBy = "Admin",
                CreatedDate = DateTime.UtcNow,
                UpdatedBy = "Admin",  // Adding the missing property
                UpdatedDate = DateTime.UtcNow,// Assuming UpdatedDate is required as well
            };

            //Setup
            _mapperMock.Setup(m => m.Map<AccessControlMaster>(newAccessControlMaster)).Returns(accessControlMasterEntity);

            // Act
            var result = await _accessControlMasterCommandService.CreateAccessControlMasterAsync(newAccessControlMaster);

            // Assert
            Assert.False(result);
        }
        [Fact]
        public async Task Test_UpdateAccessControlMaster_Returns_Success()
        {
            //Arrange
            DbContextOptions<ReadWriteDbContext> options = new DbContextOptionsBuilder<ReadWriteDbContext>()
               .UseInMemoryDatabase(databaseName: "UpdateAccessControlMaster").Options;

            byte[] concurrencyToken = new byte[8] { byte.MinValue, byte.MinValue, byte.MinValue, byte.MinValue, byte.MinValue, byte.MinValue, byte.MinValue, byte.MaxValue };
            var accessControlMaster = new AccessControlMaster
            {
                Id = 1,
                Key = "test",
                IsDeleted = false,
                CreatedBy = "Admin",
                CreatedDate = DateTime.UtcNow,
                UpdatedBy = "Admin",  // Adding the missing property
                UpdatedDate = DateTime.UtcNow,// Assuming UpdatedDate is required as well
                RecordVersion = concurrencyToken
            };


            //Arrange
            using ReadWriteDbContext dbContext = new(options);
            dbContext.AccessControlMasters.Add(accessControlMaster);
            await dbContext.SaveChangesAsync();


            UpdateAccessControlMasterRequest updateModel = new UpdateAccessControlMasterRequest
            {
                Id = 1,
                Key = "test",
                RecordVersion = concurrencyToken
            };

            //updateModel.ID = 1;
            updateModel.RecordVersion = accessControlMaster.RecordVersion;

            _accessControlMasterCommandService = new AccessControlMasterCommandService(dbContext, _mapperMock.Object);

            // Act
            bool result = await _accessControlMasterCommandService.UpdateAccessControlMasterAsync(updateModel, accessControlMaster);

            Assert.True(result);
        }
        [Fact]
        public async Task Test_DeleteAccessControlMaster_Returns_Success()
        {
            //Arrange
            DbContextOptions<ReadWriteDbContext> options = new DbContextOptionsBuilder<ReadWriteDbContext>()
               .UseInMemoryDatabase(databaseName: "DeleteAccessControlMaster").Options;

            byte[] concurrencyToken = new byte[8] { byte.MinValue, byte.MinValue, byte.MinValue, byte.MinValue, byte.MinValue, byte.MinValue, byte.MinValue, byte.MaxValue };
            var accessControlMaster = new AccessControlMaster
            {
                Id = 1,
                Key = "test",
                IsDeleted = false,
                CreatedBy = "Admin",
                CreatedDate = DateTime.UtcNow,
                UpdatedBy = "Admin",  // Adding the missing property
                UpdatedDate = DateTime.UtcNow,// Assuming UpdatedDate is required as well
                RecordVersion = concurrencyToken
            };



            //Arrange
            using ReadWriteDbContext dbContext = new(options);
            dbContext.AccessControlMasters.Add(accessControlMaster);
            await dbContext.SaveChangesAsync();

            _accessControlMasterCommandService = new AccessControlMasterCommandService(dbContext, _mapperMock.Object);

            // Act
            bool result = await _accessControlMasterCommandService.DeleteAccessControlMasterByIdAsync(concurrencyToken, accessControlMaster);

            Assert.True(result);
        }
    }
}
