﻿using Aurora.AdministrationService.API.Models.Dto.AccessControls.AccessControlMasters;
using Aurora.AdministrationService.API.Services.Service.AccessControls.AccessControlMasters;
using Aurora.AdministrationService.CrossCutting.CommonModels;
using Aurora.AdministrationService.Domain.V1.Entities.AccessControls;
using Aurora.AdministrationService.Infrastructure;
using AutoMapper;
using Microsoft.EntityFrameworkCore;
using Moq;

namespace Aurora.AdministrationService.Tests.API.Services.AccessControls.AccessControlMasters
{
    public class AccessControlMasterQueryServiceTests
    {
        private readonly Mock<ReadOnlyDbContext> _readOnlyDbContextMock;
        private readonly Mock<IMapper> _mapperMock;
        private readonly AccessControlMasterQueryService _accessControlMasterQueryService;
        private Mock<DbSet<AccessControlMaster>> _mockDbSet;

        public AccessControlMasterQueryServiceTests()
        {
            //Initialize mock
            _readOnlyDbContextMock = new Mock<ReadOnlyDbContext>();
            _mapperMock = new Mock<IMapper>();

            // Setup in-memory ready only database for testing
            DbContextOptions<ReadOnlyDbContext> options = new DbContextOptionsBuilder<ReadOnlyDbContext>()
              .UseInMemoryDatabase(databaseName: "AccessControlMasterTestDB").Options;

            _readOnlyDbContextMock = new(options);

            _mockDbSet = new Mock<DbSet<AccessControlMaster>>();

            var data = new List<AccessControlMaster>
            {
               new AccessControlMaster {
                Id = 1,
                Key="test",
                IsDeleted = false,
                CreatedBy = "Admin",
                CreatedDate = DateTime.UtcNow,
                UpdatedBy = "Admin",  // Adding the missing property
                UpdatedDate = DateTime.UtcNow,// Assuming UpdatedDate is required as well
            },
               new AccessControlMaster {
                Id = 2,
                Key="test",
                IsDeleted = false,
                CreatedBy = "Admin",
                CreatedDate = DateTime.UtcNow,
                UpdatedBy = "Admin",  // Adding the missing property
                UpdatedDate = DateTime.UtcNow,// Assuming UpdatedDate is required as well
            }

            }.AsQueryable();


            //Setup
            _mockDbSet.As<IQueryable<AccessControlMaster>>().Setup(m => m.Provider).Returns(data.Provider);
            _mockDbSet.As<IQueryable<AccessControlMaster>>().Setup(m => m.Expression).Returns(data.Expression);
            _mockDbSet.As<IQueryable<AccessControlMaster>>().Setup(m => m.ElementType).Returns(data.ElementType);
            _mockDbSet.As<IQueryable<AccessControlMaster>>().Setup(m => m.GetEnumerator()).Returns(data.GetEnumerator());
            _readOnlyDbContextMock.Setup(c => c.AccessControlMasters).Returns(_mockDbSet.Object);

            // Create the service instance
            _accessControlMasterQueryService = new AccessControlMasterQueryService(_readOnlyDbContextMock.Object, _mapperMock.Object);
        }

        [Fact]
        public async Task GetAccessControlMasterById_LogoExists_ReturnsLogoDetailDto()
        {
            // Arrange
            var accessControlMasterId = 1L;
            var accessControlMaster = new AccessControlMaster
            {
                Id = 1,
                Key = "test",
                IsDeleted = false,
                CreatedBy = "Admin",
                CreatedDate = DateTime.UtcNow,
                UpdatedBy = "Admin",  // Adding the missing property
                UpdatedDate = DateTime.UtcNow,// Assuming UpdatedDate is required as well
            };

            var accessControlMasterDto = new GetAccessControlMasterDetailDto
            {
                Id = 1,
                Key = "test",
            };

            _readOnlyDbContextMock.Setup(db => db.AccessControlMasters.FindAsync(accessControlMasterId))
                .ReturnsAsync(accessControlMaster);

            _mapperMock.Setup(m => m.Map<GetAccessControlMasterDetailDto>(accessControlMaster))
                .Returns(accessControlMasterDto);

            // Act
            var result = await _accessControlMasterQueryService.GetAccessControlMasterById(accessControlMasterId);

            // Assert
            Assert.NotNull(result);
            Assert.Equal(accessControlMasterId, result.Id);
            Assert.Equal("test", result.Key);
        }

        [Fact]
        public async Task GetAccessControlMasterById_accessControlMasterNotFound_ReturnsNull()
        {
            //Arrange
            var accessControlMasterId = 1;
            var accessControlMaster = new AccessControlMaster
            {
                Id = 1,
                Key = "test",
                IsDeleted = false,
                CreatedBy = "Admin",
                CreatedDate = DateTime.UtcNow,
                UpdatedBy = "Admin",  // Adding the missing property
                UpdatedDate = DateTime.UtcNow,// Assuming UpdatedDate is required as well
            };

            _readOnlyDbContextMock.Setup(db => db.AccessControlMasters.FindAsync(accessControlMasterId))
                .ReturnsAsync(accessControlMaster);

            //Act
            var result = await _accessControlMasterQueryService.GetAccessControlMasterById(accessControlMasterId);

            //Assert
            Assert.Null(result);
        }

        [Fact]
        public async Task GetAccessControlMasterById_accessControlMasterExists_BindingError_ReturnsNull()
        {
            // Arrange
            byte[] concurrencyToken = new byte[8] { byte.MinValue, byte.MinValue, byte.MinValue, byte.MinValue, byte.MinValue, byte.MinValue, byte.MinValue, byte.MaxValue };
            var accessControlMasterId = 1L;
            var accessControlMaster = new AccessControlMaster
            {
                Id = 1,
                Key = "test",
                IsDeleted = false,
                CreatedBy = "Admin",
                CreatedDate = DateTime.UtcNow,
                UpdatedBy = "Admin",  // Adding the missing property
                UpdatedDate = DateTime.UtcNow,// Assuming UpdatedDate is required as well
                RecordVersion = concurrencyToken
            };

            _readOnlyDbContextMock.Setup(db => db.AccessControlMasters.FindAsync(accessControlMasterId))
                .ReturnsAsync(accessControlMaster);

            _mapperMock.Setup(m => m.Map<GetAccessControlMasterDetailDto>(accessControlMaster))
                .Throws(new AutoMapperMappingException("Error mapping entity to DTO"));

            // Act & Assert
            var exception = await Assert.ThrowsAsync<AutoMapperMappingException>(
                () => _accessControlMasterQueryService.GetAccessControlMasterById(accessControlMasterId)
            );

            Assert.Equal("Error mapping entity to DTO", exception.Message);
        }

        [Fact]
        public async Task FindAccessControlMasterById_accessControlMasterExists_ReturnsaccessControlMaster()
        {
            // Arrange
            byte[] concurrencyToken = new byte[8] { byte.MinValue, byte.MinValue, byte.MinValue, byte.MinValue, byte.MinValue, byte.MinValue, byte.MinValue, byte.MaxValue };
            long accessControlMasterId = 1;
            var accessControlMaster = new AccessControlMaster
            {
                Id = accessControlMasterId,
                Key = "test",
                IsDeleted = false,
                CreatedBy = "Admin",
                CreatedDate = DateTime.UtcNow,
                UpdatedBy = "Admin",  // Adding the missing property
                UpdatedDate = DateTime.UtcNow,// Assuming UpdatedDate is required as well
                RecordVersion = concurrencyToken
            };

            // Mock the FindAsync method to return the accessControlMaster
            _readOnlyDbContextMock.Setup(db => db.AccessControlMasters.FindAsync(accessControlMasterId))
                .ReturnsAsync(accessControlMaster);

            // Act
            var result = await _accessControlMasterQueryService.FindAccessControlMasterById(accessControlMasterId);

            // Assert
            Assert.NotNull(result);
        }

        [Fact]
        public async Task FindAccessControlMasterById_accessControlMasterNotFound_ReturnsNull()
        {
            // Arrange
            var accessControlMasterId = 1L;
            var accessControlMaster = new AccessControlMaster
            {
                Id = accessControlMasterId,
                Key = "test",
                IsDeleted = false,
                CreatedBy = "Admin",
                CreatedDate = DateTime.UtcNow,
                UpdatedBy = "Admin",  // Adding the missing property
                UpdatedDate = DateTime.UtcNow,// Assuming UpdatedDate is required as well
            };

            // Mock the FindAsync method to return null (accessControlMaster not found)
            _readOnlyDbContextMock.Setup(db => db.AccessControlMasters.FindAsync(accessControlMasterId))
                .ReturnsAsync(accessControlMaster);

            // Act
            var result = await _accessControlMasterQueryService.FindAccessControlMasterById(accessControlMasterId);

            // Assert
            Assert.NotNull(result);
        }

        [Fact]
        public void GetAccessControlMasterList_ReturnsCorrectAccessControlMasterList()
        {
            // Act
            var result = _accessControlMasterQueryService.GetAccessControlMasterList();

            // Assert
            Assert.NotNull(result);
            Assert.Equal(2, result.Count); // Verifying that 3 items are returned

            // Verifying that the returned items are mapped correctly
            Assert.Contains(result, r => r.Id == 1 && r.Key == "test");
            Assert.Contains(result, r => r.Id == 2 && r.Key == "test");
        }

        [Fact]
        public async Task IsAccessControlMasterAlreadyExist_ShouldReturnTrue_WhenaccessControlMasterExists()
        {
            // Arrange
            var accessControlMasterId = 1L;
            var accessControlMaster = new AccessControlMaster
            {
                Id = 1L,
                Key = "test",
                IsDeleted = false,
                CreatedBy = "Admin",
                CreatedDate = DateTime.UtcNow,
                UpdatedBy = "Admin",  // Adding the missing property
                UpdatedDate = DateTime.UtcNow,// Assuming UpdatedDate is required as well
            };

            // Mock the FindAsync method to return the accessControlMaster
            _readOnlyDbContextMock.Setup(db => db.AccessControlMasters.FindAsync(accessControlMasterId))
                .ReturnsAsync(accessControlMaster);

            // Act
            var result = await _accessControlMasterQueryService.IsAccessControlMasterAlreadyExist(accessControlMasterId);

            // Assert
            Assert.True(result.result);
            Assert.Equal(ResponseMessage.STATUS_DATA_FOUND, result.message);
        }

        [Fact]
        public async Task IsAccessControlMasterAlreadyExist_ShouldReturnFalse_WhenaccessControlMasterDoesNotExist()
        {
            // Arrange
            var accessControlMasterId = 3;

            // Act
            var result = await _accessControlMasterQueryService.IsAccessControlMasterAlreadyExist(accessControlMasterId);

            // Assert
            Assert.False(result.result);
            Assert.Equal(ResponseMessage.STATUS_NODATA, result.message);
        }
    }
}
