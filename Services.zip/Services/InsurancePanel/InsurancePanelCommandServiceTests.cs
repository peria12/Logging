﻿using Moq;
using Aurora.AdministrationService.API.Services.Service.InsurancePanels;
using Aurora.AdministrationService.API.Models.RequestModels.InsurancePanels;
using Aurora.AdministrationService.API.Models.Dto.InsurancePanels;
using Aurora.AdministrationService.Domain.V1.Entities.InsurancePanels;
using Aurora.AdministrationService.Infrastructure;
using AutoMapper;
using Microsoft.EntityFrameworkCore;
using System;
using System.Threading.Tasks;
using Xunit;

namespace Aurora.AdministrationService.Tests.API.Services
{
    public class InsurancePanelCommandServiceTests
    {
        private readonly InsurancePanelCommandService _service;
        private readonly Mock<IMapper> _mockMapper;
        private readonly ReadWriteDbContext _dbContext;

        public InsurancePanelCommandServiceTests()
        {
            var options = new DbContextOptionsBuilder<ReadWriteDbContext>()
                .UseInMemoryDatabase(databaseName: Guid.NewGuid().ToString())
                .Options;

            _dbContext = new ReadWriteDbContext(options);
            _mockMapper = new Mock<IMapper>(); 

            // Initialize InsurancePanelCommandService with mocked IMapper and in-memory DbContext
            _service = new InsurancePanelCommandService(_dbContext, _mockMapper.Object);
        }

        // Test for CreateInsurancePanelAsync
        [Fact]
        public async Task CreateInsurancePanelAsync_ShouldReturnTrue_WhenSuccess()
        {
            // Arrange
            var newInsurancePanel = new CreateInsurancePanelRequest
            {
                DebtorName = "New Panel",
                ResourceID ="232323",
                Status=true,

            };

            var insurancePanelEntity = new InsurancePanel
            {
                DebtorName = "New Panel",
                ResourceID = "232323",
                Status = true,
                CreatedBy ="user1",
                CreatedDate = DateTime.UtcNow,
                IsDeleted = false,
                Logo = string.Empty,
                
            };

            _mockMapper.Setup(m => m.Map<InsurancePanel>(It.IsAny<CreateInsurancePanelRequest>()))
                .Returns(insurancePanelEntity);

            // Act
            var result = await _service.CreateInsurancePanelAsync(newInsurancePanel);

            // Assert
            Assert.True(result);
            var createdEntity = await _dbContext.InsurancePanels.FindAsync(insurancePanelEntity.Id);
            Assert.NotNull(createdEntity);
            Assert.Equal("New Panel", createdEntity.DebtorName);
        }

        [Fact]
        public async Task CreateInsurancePanelAsync_ShouldReturnFalse_WhenExceptionOccurs()
        {
            // Arrange
            var newInsurancePanel = new CreateInsurancePanelRequest
            {
                DebtorName = "New Panel",
                ResourceID = "232323",
                Status = true,

            };

            _mockMapper.Setup(m => m.Map<InsurancePanel>(It.IsAny<CreateInsurancePanelRequest>()))
                .Throws(new Exception("Mapping exception"));

            // Act
            var result = await _service.CreateInsurancePanelAsync(newInsurancePanel);

            // Assert
            Assert.False(result);
        }

        // Test for DeleteInsurancePanelByIdAsync
        [Fact]
        public async Task DeleteInsurancePanelByIdAsync_ShouldReturnTrue_WhenSuccess()
        {
            // Arrange
            var insurancePanel = new InsurancePanel
            {
                Id = 1,
                DebtorName = "New Panel",
                ResourceID = "232323",
                Status = true,
                IsDeleted = false,
                CreatedDate = DateTime.UtcNow,
                CreatedBy = "Admin",
                Logo = string.Empty,
                UpdatedBy = "user"
            };

            _dbContext.InsurancePanels.Add(insurancePanel);
            await _dbContext.SaveChangesAsync();

            var recordVersion = insurancePanel.RecordVersion; // Simulated record version

            // Act
            var result = await _service.DeleteInsurancePanelByIdAsync(recordVersion, insurancePanel);

            // Assert
            Assert.True(result);
            var deletedEntity = await _dbContext.InsurancePanels.FindAsync(insurancePanel.Id);
            Assert.NotNull(deletedEntity);
            Assert.True(deletedEntity.IsDeleted);
        }


        // Test for UpdateInsurancePanelAsync
        [Fact]
        public async Task UpdateInsurancePanelAsync_ShouldReturnTrue_WhenSuccess()
        {
            // Arrange
            var insurancePanel = new InsurancePanel
            {
                Id = 1,
                DebtorName = "New Panel",
                ResourceID = "232323",
                Status = true,
                CreatedBy ="user1",
                CreatedDate= DateTime.UtcNow,
                IsDeleted =false,
                Logo = string.Empty,
                UpdatedBy = "user1",
                UpdatedDate = DateTime.UtcNow,
            };

            _dbContext.InsurancePanels.Add(insurancePanel);
            await _dbContext.SaveChangesAsync();

            var updateRequest = new UpdateInsurancePanelRequest
            {
                DebtorName = "New Panel",
                ResourceID = "232323",
                Status = true,
                RecordVersion = insurancePanel.RecordVersion
            };

            _mockMapper.Setup(m => m.Map(It.IsAny<UpdateInsurancePanelRequest>(), It.IsAny<InsurancePanel>()))
                .Callback<UpdateInsurancePanelRequest, InsurancePanel>((req, entity) =>
                {
                    entity.DebtorName = req.DebtorName;
                    entity.DebtorName = req.DebtorName;
                    entity.ResourceID = req.ResourceID; 
                    entity.Status = req.Status;
                    entity.RecordVersion = req.RecordVersion;
                   
                });

            // Act
            var result = await _service.UpdateInsurancePanelAsync(updateRequest, insurancePanel);

            // Assert
            Assert.True(result);
            var updatedEntity = await _dbContext.InsurancePanels.FindAsync(insurancePanel.Id);
            Assert.NotNull(updatedEntity);
        }
    }
}
