﻿using Moq;
using Aurora.AdministrationService.API.Services.Service.InsurancePanels;
using Aurora.AdministrationService.API.Models.Dto.InsurancePanels.InsurancePanel;
using Aurora.AdministrationService.API.Models.ResponseModels.InsurancePanels;
using Aurora.AdministrationService.Domain.V1.Entities.InsurancePanels;
using Aurora.AdministrationService.Infrastructure;
using AutoMapper;
using Microsoft.EntityFrameworkCore;
using Xunit;
using System.Collections.Generic;
using System.Threading.Tasks;
using System.Linq;
using Aurora.AdministrationService.CrossCutting.CommonModels;
using Microsoft.VisualBasic;
using Aurora.AdministrationService.API.Enum;
using Aurora.AdministrationService.API.Services.Service.AdminInsurance;
using Microsoft.EntityFrameworkCore.Infrastructure;
using FluentAssertions;

namespace Aurora.AdministrationService.Tests.API.Services.Service.InsurancePanels
{
    public class InsurancePanelQueryServiceTests
    {
        private readonly InsurancePanelQueryService _service;
        private readonly Mock<IMapper> _mockMapper;
        private readonly ReadOnlyDbContext _dbContext;
        private readonly DbContextOptions<ReadOnlyDbContext> _dbContextOptions;

        public InsurancePanelQueryServiceTests()
        {
            var options = new DbContextOptionsBuilder<ReadOnlyDbContext>()
                .UseInMemoryDatabase(databaseName: Guid.NewGuid().ToString()) // In-memory DB for testing
                .Options;

            _dbContext = new ReadOnlyDbContext(options);  // Initialize DbContext with in-memory options
            _mockMapper = new Mock<IMapper>();  // Mock the IMapper

            // Initialize InsurancePanelQueryService with mocked IMapper and in-memory DbContext
            _service = new InsurancePanelQueryService(_dbContext, _mockMapper.Object);
            _dbContextOptions = new DbContextOptionsBuilder<ReadOnlyDbContext>()
           .UseInMemoryDatabase(databaseName: Guid.NewGuid().ToString())
           .Options;
        }

        // Test for IsInsurancePanelAlreadyExist
        [Fact]
        public async Task IsInsurancePanelAlreadyExist_ShouldReturnTrue_WhenExist()
        {
            // Arrange
            var existingInsurancePanel = new InsurancePanel
            {
                Id = 1,
                DebtorName = "Existing Panel",
                CreatedBy = "user1",
                CreatedDate = DateTime.UtcNow,
                IsDeleted = false,
                ResourceID = "user1",
                Status = true,
                Logo = string.Empty,
                UpdatedBy = "user1",
            };
            _dbContext.InsurancePanels.Add(existingInsurancePanel);
            await _dbContext.SaveChangesAsync();

            // Act
            var result = await _service.IsInsurancePanelAlreadyExist(1);

            // Assert
            Assert.True(result.result);
            Assert.Equal(ResponseMessage.STATUS_DATA_FOUND, result.message);
        }

        [Fact]
        public async Task IsInsurancePanelAlreadyExist_ShouldReturnFalse_WhenNotExist()
        {
            // Act
            var result = await _service.IsInsurancePanelAlreadyExist(999); // Non-existing ID

            // Assert
            Assert.False(result.result);
            Assert.Equal(ResponseMessage.STATUS_NODATA, result.message);
        }

        // Test for GetInsurancePanelById
        [Fact]
        public async Task GetInsurancePanelById_ShouldReturnCorrectDetail_WhenExist()
        {
            // Arrange
            var existingInsurancePanel = new InsurancePanel
            {
                Id = 1,
                DebtorName = "Existing Panel",
                CreatedBy = "user1",
                CreatedDate = DateTime.UtcNow,
                IsDeleted = false,
                ResourceID = "user1",
                Status = true,
                Logo = string.Empty,
                UpdatedBy = "user1",
            };
            _dbContext.InsurancePanels.Add(existingInsurancePanel);
            await _dbContext.SaveChangesAsync();

            _mockMapper.Setup(m => m.Map<GetInsurancePanelDetailDto>(It.IsAny<InsurancePanel>()))
                .Returns(new GetInsurancePanelDetailDto { Id = 1, DebtorName = "Existing Panel" });

            // Act
            var result = await _service.GetInsurancePanelById(1);

            // Assert
            Assert.NotNull(result);
            Assert.Equal("Existing Panel", result.DebtorName);
        }

        [Fact]
        public async Task GetInsurancePanelById_ShouldReturnNull_WhenNotExist()
        {
            // Act
            var result = await _service.GetInsurancePanelById(999); // Non-existing ID

            // Assert
            Assert.Null(result);
        }

        // Test for FindInsurancePanelById
        [Fact]
        public async Task FindInsurancePanelById_ShouldReturnInsurancePanel_WhenExist()
        {
            // Arrange
            var existingInsurancePanel = new InsurancePanel
            {
                Id = 1,
                DebtorName = "Existing Panel",
                CreatedBy = "user1",
                CreatedDate = DateTime.UtcNow,
                IsDeleted = false,
                ResourceID = "user1",
                Status = true,
                Logo = string.Empty,
                UpdatedBy = "user1",
            };
            _dbContext.InsurancePanels.Add(existingInsurancePanel);
            await _dbContext.SaveChangesAsync();

            // Act
            var result = await _service.FindInsurancePanelById(1);

            // Assert
            Assert.NotNull(result);
            Assert.Equal(1, result.Id);
            Assert.Equal("Existing Panel", result.DebtorName);
        }

        [Fact]
        public async Task FindInsurancePanelById_ShouldReturnNull_WhenNotExist()
        {
            // Act
            var result = await _service.FindInsurancePanelById(999); // Non-existing ID

            // Assert
            Assert.Null(result);
        }

        // Test for GetInsurancePanelList
        [Fact]
        public void GetInsurancePanelList_ShouldReturnListOfInsurancePanels()
        {
            // Arrange
            var insurancePanels = new List<InsurancePanel>
            {

                new InsurancePanel {
                    Id = 34,
                    DebtorName = "Panel 1",
                    CreatedBy = "user1",
                    CreatedDate = DateTime.UtcNow,
                    IsDeleted = false,
                    ResourceID ="user1",
                    Status =true,
                    Logo=string.Empty,
                    UpdatedBy ="user1",
                },
                new InsurancePanel {
                    Id = 23,
                    DebtorName = "Panel 2",
                    CreatedBy = "user1",
                    CreatedDate = DateTime.UtcNow,
                    IsDeleted = false,
                    ResourceID ="user1",
                    Status =true,
                    Logo=string.Empty,
                    UpdatedBy ="user1",
                },
            };

            _dbContext.InsurancePanels.AddRange(insurancePanels);
            _dbContext.SaveChanges();

            _mockMapper.Setup(m => m.Map<GetInsurancePanelDto>(It.IsAny<InsurancePanel>()))
                .Returns(new GetInsurancePanelDto { Id = 23, DebtorName = "Panel 1" });

            // Act
            var result = _service.GetInsurancePanelList();

            // Assert
            Assert.NotNull(result);
            Assert.Equal(2, result.Count);
            Assert.Contains(result, x => x.DebtorName == "Panel 1");
            Assert.Contains(result, x => x.DebtorName == "Panel 2");
        }

        // Test for GetInsurancePanelMasterList
        [Fact]
        public void GetInsurancePanelMasterList_ShouldReturnList_WhenDataExist()
        {
            // Arrange
            var insurancePanels = new List<InsurancePanel>
            {

                new InsurancePanel {
                    Id = 56,
                    DebtorName = "Panel 1",
                    CreatedBy = "user1",
                    CreatedDate = DateTime.UtcNow,
                    IsDeleted = false,
                    ResourceID ="user1",
                    Status =true,
                    Logo="Logo1",
                    UpdatedBy ="user1",
                },
                new InsurancePanel {
                    Id = 341,
                    DebtorName = "Panel 2",
                    CreatedBy = "user1",
                    CreatedDate = DateTime.UtcNow,
                    IsDeleted = false,
                    ResourceID ="user1",
                    Status =true,
                    Logo="Logo1",
                    UpdatedBy ="user1",
                },
            };

            _dbContext.InsurancePanels.AddRange(insurancePanels);
            _dbContext.SaveChanges();

            _mockMapper.Setup(m => m.Map<GetInsurancePanelMasterDto>(It.IsAny<InsurancePanel>()))
                .Returns(new GetInsurancePanelMasterDto { Id = 341, DebtorName = "Panel 2", Logo = "Logo1" });

            // Act
            var result = _service.GetInsurancePanelMasterList();

            // Assert
            Assert.NotNull(result);
            Assert.Equal(2, result?.Results?.Count());
            Assert.Contains(result.Results, x => x.DebtorName == "Panel 1");
            Assert.Contains(result.Results, x => x.DebtorName == "Panel 2");
        }

        [Fact]
        public void GetInsurancePanelMasterList_ShouldReturnEmptyList_WhenNoData()
        {
            // Arrange
            // No data added to the database

            // Act
            var result = _service.GetInsurancePanelMasterList();

            // Assert
            Assert.NotNull(result);
            Assert.Empty(result.Results);
            Assert.Equal(ResponseMessage.STATUS_NODATA, result.Message);
        }

        [Fact]
        public void SearchInsuranceList_ShouldReturnAll_WhenSearchIsNull()
        {
            var options = new DbContextOptionsBuilder<ReadOnlyDbContext>()
                .UseInMemoryDatabase(Guid.NewGuid().ToString())
                .EnableSensitiveDataLogging()
                .Options;

            using var context = new ReadOnlyDbContext(options);
            var mockMapper = new Mock<IMapper>();
            var service = new InsurancePanelQueryService(context, mockMapper.Object);

            context.InsurancePanels.AddRange(
                new InsurancePanel
                {
                    Id = 1,
                    DebtorName = "HealthCare Inc",
                    Logo = "logo1.png",
                    IsDeleted = false,
                    ResourceID = "r1",
                    Status = true,
                    CreatedBy = "u",
                    CreatedDate = DateTime.UtcNow,
                    UpdatedBy = "u",
                    UpdatedDate = DateTime.UtcNow
                },
                new InsurancePanel
                {
                    Id = 2,
                    DebtorName = "MediPlan",
                    Logo = "logo2.png",
                    IsDeleted = false,
                    ResourceID = "r2",
                    Status = true,
                    CreatedBy = "u",
                    CreatedDate = DateTime.UtcNow,
                    UpdatedBy = "u",
                    UpdatedDate = DateTime.UtcNow
                }
            );
            context.SaveChanges();

            var result = service.SearchInsuranceList(null);

            result.IsSuccess.Should().BeTrue();
            result.Results.Should().HaveCount(2);
            result.StatusCode.Should().Be(ResponceStatusCode.Success.ToString());
            result.Message.Should().Be(ResponseMessage.STATUS_SUCCESS);
        }

        [Fact]
        public void SearchInsuranceList_ShouldReturnFilteredResult_WhenSearchMatches()
        {
            var options = new DbContextOptionsBuilder<ReadOnlyDbContext>()
                .UseInMemoryDatabase(Guid.NewGuid().ToString())
                .EnableSensitiveDataLogging()
                .Options;

            using var context = new ReadOnlyDbContext(options);
            var mockMapper = new Mock<IMapper>();
            var service = new InsurancePanelQueryService(context, mockMapper.Object);

            context.InsurancePanels.AddRange(
                new InsurancePanel
                {
                    Id = 1,
                    DebtorName = "Alpha Health",
                    Logo = "logo1.png",
                    IsDeleted = false,
                    ResourceID = "r1",
                    Status = true,
                    CreatedBy = "u",
                    CreatedDate = DateTime.UtcNow,
                    UpdatedBy = "u",
                    UpdatedDate = DateTime.UtcNow
                },
                new InsurancePanel
                {
                    Id = 2,
                    DebtorName = "Beta Care",
                    Logo = "logo2.png",
                    IsDeleted = false,
                    ResourceID = "r2",
                    Status = true,
                    CreatedBy = "u",
                    CreatedDate = DateTime.UtcNow,
                    UpdatedBy = "u",
                    UpdatedDate = DateTime.UtcNow
                }
            );
            context.SaveChanges();

            var result = service.SearchInsuranceList("Alpha");

            result.IsSuccess.Should().BeTrue();
            result.Results.Should().HaveCount(1);
            result.Results.First().DebtorName.Should().Contain("Alpha");
        }

        [Fact]
        public void SearchInsuranceList_ShouldReturnNoData_WhenNoMatchFound()
        {
            var options = new DbContextOptionsBuilder<ReadOnlyDbContext>()
                .UseInMemoryDatabase(Guid.NewGuid().ToString())
                .EnableSensitiveDataLogging()
                .Options;

            using var context = new ReadOnlyDbContext(options);
            var mockMapper = new Mock<IMapper>();
            var service = new InsurancePanelQueryService(context, mockMapper.Object);

            context.InsurancePanels.Add(
                new InsurancePanel
                {
                    Id = 1,
                    DebtorName = "ZetaCare",
                    Logo = "logo.png",
                    IsDeleted = false,
                    ResourceID = "r1",
                    Status = true,
                    CreatedBy = "u",
                    CreatedDate = DateTime.UtcNow,
                    UpdatedBy = "u",
                    UpdatedDate = DateTime.UtcNow
                }
            );
            context.SaveChanges();

            var result = service.SearchInsuranceList("XYZ");

            result.IsSuccess.Should().BeTrue();
            result.Results.Should().BeEmpty();
            result.StatusCode.Should().Be(ResponceStatusCode.RecordNotFound.ToString());
            result.Message.Should().Be(ResponseMessage.STATUS_NODATA);
        }

        [Fact]
        public void SearchInsuranceList_ShouldIgnoreDeletedRecords()
        {
            var options = new DbContextOptionsBuilder<ReadOnlyDbContext>()
                .UseInMemoryDatabase(Guid.NewGuid().ToString())
                .EnableSensitiveDataLogging()
                .Options;

            using var context = new ReadOnlyDbContext(options);
            var mockMapper = new Mock<IMapper>();
            var service = new InsurancePanelQueryService(context, mockMapper.Object);

            context.InsurancePanels.AddRange(
                new InsurancePanel
                {
                    Id = 1,
                    DebtorName = "Valid Co",
                    Logo = "logo.png",
                    IsDeleted = false,
                    ResourceID = "r1",
                    Status = true,
                    CreatedBy = "u",
                    CreatedDate = DateTime.UtcNow,
                    UpdatedBy = "u",
                    UpdatedDate = DateTime.UtcNow
                },
                new InsurancePanel
                {
                    Id = 2,
                    DebtorName = "Deleted Co",
                    Logo = "logo.png",
                    IsDeleted = true,
                    ResourceID = "r2",
                    Status = true,
                    CreatedBy = "u",
                    CreatedDate = DateTime.UtcNow,
                    UpdatedBy = "u",
                    UpdatedDate = DateTime.UtcNow
                }
            );
            context.SaveChanges();

            var result = service.SearchInsuranceList(null);

            result.Results.Should().HaveCount(1);
            result.Results.First().DebtorName.Should().Be("Valid Co");
        }

    }
}