﻿using Moq;
using Aurora.AdministrationService.API.Helper;
using Aurora.AdministrationService.API.Models.Dto.InsurancePanelLocations;
using Aurora.AdministrationService.API.Models.ResponseModels.InsurancePanelLocations;
using Aurora.AdministrationService.API.Services.Service.InsurancePanelLocations;
using Aurora.AdministrationService.Infrastructure;
using Aurora.AdministrationService.Domain.V1.Entities.InsurancePanels;
using Aurora.AdministrationService.CrossCutting.CommonModels;
using AutoMapper;
using Microsoft.EntityFrameworkCore;
using Xunit;
namespace Aurora.AdministrationService.API.Tests.Services;
public class InsurancePanelLocationQueryServiceTests
{
    private readonly InsurancePanelLocationQueryService _service;
    private readonly Mock<IMapper> _mockMapper;
    private readonly ReadOnlyDbContext inMemoryDbContext;

    public InsurancePanelLocationQueryServiceTests()
    {
        var options = new DbContextOptionsBuilder<ReadOnlyDbContext>()
            .UseInMemoryDatabase(databaseName:Guid.NewGuid().ToString()) // Create an in-memory database
            .Options;

        inMemoryDbContext = new ReadOnlyDbContext(options);

        _mockMapper = new Mock<IMapper>();

        _service = new InsurancePanelLocationQueryService(inMemoryDbContext, _mockMapper.Object);
    }

    // Test for IsInsurancePanelLocationAlreadyExist
    [Fact]
    public async Task IsInsurancePanelLocationAlreadyExist_ReturnsTrue_WhenLocationExists()
    {
        // Arrange
        var existingId = 1;

        var insurancePanelLocation = new InsurancePanelLocation
        {
            Id = existingId,
            InsurancePanelID = 101,
            LocationID = "202",
            IsDeleted = false,
            CreatedBy = "user",
            CreatedDate = DateTime.UtcNow,
            UpdatedBy = "user",
        };


        inMemoryDbContext.InsurancePanelLocations.Add(insurancePanelLocation); // Add mock data
        await inMemoryDbContext.SaveChangesAsync(); // Save data

        // Act
        var result = await _service.IsInsurancePanelLocationAlreadyExist(existingId);

        // Assert
        Assert.True(result.result);  // Should return true
        Assert.Equal(ResponseMessage.STATUS_DATA_FOUND, result.message);
    }

    [Fact]
    public async Task IsInsurancePanelLocationAlreadyExist_ReturnsFalse_WhenLocationDoesNotExist()
    {
        // Arrange
        var nonExistingId = 2;

        // Act
        var result = await _service.IsInsurancePanelLocationAlreadyExist(nonExistingId);

        // Assert
        Assert.False(result.result);  // Should return false
        Assert.Equal(ResponseMessage.STATUS_NODATA, result.message);
    }

    // Test for GetInsurancePanelLocationById
    [Fact]
    public async Task GetInsurancePanelLocationById_ReturnsMappedDto_WhenLocationExists()
    {
        // Arrange
        var locationId = 1;
        var insurancePanelLocation = new InsurancePanelLocation
        {
            Id = locationId,
            InsurancePanelID = 101,
            LocationID = "202",
            IsDeleted = false,
            CreatedBy = "user",
            CreatedDate = DateTime.UtcNow,
            UpdatedBy = "user",
            RecordVersion = new byte[] { 1, 2, 3 }
        };

        inMemoryDbContext.InsurancePanelLocations.Add(insurancePanelLocation); // Add mock data
        await inMemoryDbContext.SaveChangesAsync(); // Save data

        var mockDto = new GetInsurancePanelLocationDetailDto
        {
            Id = locationId,
            InsurancePanelID = 101,
            LocationID = "202",
            IsDeleted = false
        };

        _mockMapper.Setup(m => m.Map<GetInsurancePanelLocationDetailDto>(insurancePanelLocation))
            .Returns(mockDto);

        // Act
        var result = await _service.GetInsurancePanelLocationById(locationId);

        // Assert
        Assert.NotNull(result);  // Should return a valid dto
        Assert.Equal(locationId, result.Id);
        Assert.Equal(101, result.InsurancePanelID);
        Assert.Equal("202", result.LocationID);
    }

    // Test for FindInsurancePanelLocationById
    [Fact]
    public async Task FindInsurancePanelLocationById_ReturnsLocation_WhenLocationExists()
    {
        // Arrange
        var locationId = 1;
        var insurancePanelLocation = new InsurancePanelLocation
        {
            Id = locationId,
            InsurancePanelID = 101,
            LocationID = "202",
            CreatedBy = "user",
            CreatedDate = DateTime.UtcNow,
            UpdatedBy = "user",
            IsDeleted = false
        };

        inMemoryDbContext.InsurancePanelLocations.Add(insurancePanelLocation); // Add mock data
        await inMemoryDbContext.SaveChangesAsync(); // Save data

        // Act
        var result = await _service.FindInsurancePanelLocationById(locationId);

        // Assert
        Assert.NotNull(result);  // Should return the location entity
        Assert.Equal(locationId, result?.Id);
    }

    [Fact]
    public async Task FindInsurancePanelLocationById_ReturnsNull_WhenLocationDoesNotExist()
    {
        // Arrange
        var locationId = 1;

        // Act
        var result = await _service.FindInsurancePanelLocationById(locationId);

        // Assert
        Assert.Null(result);  // Should return null
    }

    // Test for GetInsurancePanelLocationList
    [Fact]
    public void GetInsurancePanelLocationList_ReturnsListOfDtos()
    {
        // Arrange
        var insurancePanelLocations = new List<InsurancePanelLocation>
        {
            new InsurancePanelLocation { 
                Id = 1, 
                InsurancePanelID = 101,
                CreatedBy="user",
                CreatedDate = DateTime.UtcNow,
                LocationID = "202", 
                IsDeleted = false,
                UpdatedBy="user",
            },
            new InsurancePanelLocation {
                Id = 2,
                InsurancePanelID = 102,
                CreatedBy="user",
                UpdatedBy = "user",
                CreatedDate = DateTime.UtcNow,
                LocationID = "203", IsDeleted = false,

            }
        };

        inMemoryDbContext.InsurancePanelLocations.AddRange(insurancePanelLocations); // Add mock data
        inMemoryDbContext.SaveChanges(); // Save data

        var mockDtos = new List<GetInsurancePanelLocationDto>
        {
            new GetInsurancePanelLocationDto { Id = 1, InsurancePanelID = 101, LocationID = "202", IsDeleted = false },
            new GetInsurancePanelLocationDto { Id = 2, InsurancePanelID = 102, LocationID = "203", IsDeleted = false }
        };

        _mockMapper.Setup(m => m.Map<List<GetInsurancePanelLocationDto>>(insurancePanelLocations))
            .Returns(mockDtos);

        // Act
        var result = _service.GetInsurancePanelLocationList();

        // Assert
        Assert.NotNull(result);
        Assert.Equal(2, result.Count);  // Should return 2 records
        Assert.Equal(1, result[0].Id);  // First record ID should be 1
        Assert.Equal(2, result[1].Id);  // Second record ID should be 2
    }
}
