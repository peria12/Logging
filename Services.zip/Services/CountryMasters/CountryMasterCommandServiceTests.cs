﻿using Aurora.AdministrationService.API.Models.Dto.CountryMasters;
using Aurora.AdministrationService.API.Services.Service.CountryMasters;
using Aurora.AdministrationService.Domain.Entities;
using Aurora.AdministrationService.Domain.Old.Entities;
using Aurora.AdministrationService.Domain.V1.Entities.CountryMasters;
using Aurora.AdministrationService.Infrastructure;
using AutoMapper;
using Microsoft.EntityFrameworkCore;
using Moq;

namespace Aurora.AdministrationService.Tests.API.Services.CountryMasters
{
    public class CountryMasterCommandServiceTests
    {
        private readonly Mock<ReadWriteDbContext> _readWriteDbContextMock;
        private readonly Mock<IMapper> _mapperMock;
        private CountryMasterCommandService _countryMasterCommandService;

        public CountryMasterCommandServiceTests()
        {
            // Initialize the mocks
            _mapperMock = new Mock<IMapper>();
            _readWriteDbContextMock = new Mock<ReadWriteDbContext>();


            // Setup in-memory ready only database for testing
            DbContextOptions<ReadWriteDbContext> options = new DbContextOptionsBuilder<ReadWriteDbContext>()
              .UseInMemoryDatabase(databaseName: "AdminCountryMasterTestDB").Options;

            _readWriteDbContextMock = new(options);

            // Initialize the service being tested
            _countryMasterCommandService = new CountryMasterCommandService(_readWriteDbContextMock.Object, _mapperMock.Object);
        }

        [Fact]
        public async Task CreateCountryMasterAsync_ShouldReturnTrue_WhenCountryMasterIsCreatedSuccessfully()
        {
            // Arrange
            var newCountryMaster = new CountryMasterDto
            {
                Code = "test",
                Definition = "Definition",
                Source = "test",
                ResourceId = "test",
            };

            // Mock AutoMapper to return a CountryMaster entity
            var countryMasterId = 1;
            var countryMasterEntity = new CountryMaster
            {
                Id = countryMasterId,
                Code = "test",
                Definition = "Definition",
                Source = "test",
                ResourceId = "test",
                Display = "test",
                ImageUrl = "test",
                Nationality = "test",
                IsDeleted = false,
                CreatedBy = "Admin",
                CreatedDate = DateTime.UtcNow,
                UpdatedBy = "Admin",  // Adding the missing property
                UpdatedDate = DateTime.UtcNow,// Assuming UpdatedDate is required as well
            };


            // Mock AutoMapper to return the CountryMaster entity
            _mapperMock.Setup(m => m.Map<CountryMaster>(newCountryMaster)).Returns(countryMasterEntity);

            // Mock DbContext to simulate saving the entity without actually hitting the database
            _readWriteDbContextMock.Setup(db => db.CountryMasters.Add(It.IsAny<CountryMaster>()));

            // Act
            var result = await _countryMasterCommandService.CreateCountryMasterAsync(newCountryMaster);

            // Assert
            Assert.True(result);
            _readWriteDbContextMock.Verify(db => db.CountryMasters.Add(It.Is<CountryMaster>(l => l.Source == "test")), Times.Once);
        }


        [Fact]
        public async Task CreateCountryMasterAsync_ShouldReturnFalse_WhenExceptionOccurs()
        {
            // Arrange
            var newCountryMaster = new CountryMasterDto
            {
                Code = "test",
                Definition = "Definition",
                Source = "test",
                ResourceId = "test",
                Display = "test",
                ImageUrl = "test",
                Nationality = "test",
            };

            // Mock AutoMapper to return a CountryMaster entity
            var countryMasterId = 1;
            var countryMasterEntity = new CountryMaster
            {
                Id = countryMasterId,
                Code = "test",
                Definition = "Definition",
                Source = "test",
                ResourceId = "test",
                Display = "test",
                ImageUrl = "test",
                Nationality = "test",
                IsDeleted = false,
                CreatedBy = "Admin",
                CreatedDate = DateTime.UtcNow,
                UpdatedBy = "Admin",  // Adding the missing property
                UpdatedDate = DateTime.UtcNow,// Assuming UpdatedDate is required as well
            };

            //Setup
            _mapperMock.Setup(m => m.Map<CountryMaster>(newCountryMaster)).Returns(countryMasterEntity);

            // Act
            var result = await _countryMasterCommandService.CreateCountryMasterAsync(newCountryMaster);

            // Assert
            Assert.False(result);
        }
        [Fact]
        public async Task Test_UpdateCountryMaster_Returns_Success()
        {
            //Arrange
            DbContextOptions<ReadWriteDbContext> options = new DbContextOptionsBuilder<ReadWriteDbContext>()
               .UseInMemoryDatabase(databaseName: "UpdateCountryMaster").Options;

            byte[] concurrencyToken = new byte[8] { byte.MinValue, byte.MinValue, byte.MinValue, byte.MinValue, byte.MinValue, byte.MinValue, byte.MinValue, byte.MaxValue };
            var countryMaster = new CountryMaster
            {
                Id = 1,
                Code = "test",
                Definition = "Definition",
                Source = "test",
                ResourceId = "test",
                Display = "test",
                ImageUrl = "test",
                Nationality = "test",
                IsDeleted = false,
                CreatedBy = "Admin",
                CreatedDate = DateTime.UtcNow,
                UpdatedBy = "Admin",  // Adding the missing property
                UpdatedDate = DateTime.UtcNow,// Assuming UpdatedDate is required as well
                RecordVersion = concurrencyToken
            };


            //Arrange
            using ReadWriteDbContext dbContext = new(options);
            dbContext.CountryMasters.Add(countryMaster);
            await dbContext.SaveChangesAsync();


            UpdateCountryMasterRequest updateModel = new UpdateCountryMasterRequest
            {
                Id = 1,
                Code = "test",
                Definition = "Definition",
                Source = "test",
                ResourceId = "test",
                Display = "test",
                ImageUrl = "test",
                Nationality = "test",
                RecordVersion = concurrencyToken
            };

            updateModel.RecordVersion = countryMaster.RecordVersion;

            _countryMasterCommandService = new CountryMasterCommandService(dbContext, _mapperMock.Object);

            // Act
            bool result = await _countryMasterCommandService.UpdateCountryMasterAsync(updateModel, countryMaster);

            Assert.True(result);
        }
        [Fact]
        public async Task Test_DeleteCountryMaster_Returns_Success()
        {
            //Arrange
            DbContextOptions<ReadWriteDbContext> options = new DbContextOptionsBuilder<ReadWriteDbContext>()
               .UseInMemoryDatabase(databaseName: "DeleteCountryMaster").Options;

            byte[] concurrencyToken = new byte[8] { byte.MinValue, byte.MinValue, byte.MinValue, byte.MinValue, byte.MinValue, byte.MinValue, byte.MinValue, byte.MaxValue };
            var countryMaster = new CountryMaster
            {
                Id = 1,
                Code = "test",
                Definition = "Definition",
                Source = "test",
                ResourceId = "test",
                Display = "test",
                ImageUrl = "test",
                Nationality = "test",
                IsDeleted = false,
                CreatedBy = "Admin",
                CreatedDate = DateTime.UtcNow,
                UpdatedBy = "Admin",  // Adding the missing property
                UpdatedDate = DateTime.UtcNow,// Assuming UpdatedDate is required as well
                RecordVersion = concurrencyToken
            };



            //Arrange
            using ReadWriteDbContext dbContext = new(options);
            dbContext.CountryMasters.Add(countryMaster);
            await dbContext.SaveChangesAsync();

            _countryMasterCommandService = new CountryMasterCommandService(dbContext, _mapperMock.Object);

            // Act
            bool result = await _countryMasterCommandService.DeleteCountryMasterByIdAsync(concurrencyToken, countryMaster);

            Assert.True(result);
        }
        [Fact]
        public void CountryList_ShouldSetAndGetProperties()
        {
            // Arrange
            var country = new CountryList
            {
                Id = 1,
                CountryName = "India",
                CountryCode = "IN",
                Nationality = "Indian",
                ImageUrl = "https://example.com/flag-in.png"
            };

            // Assert
            Assert.Equal(1, country.Id);
            Assert.Equal("India", country.CountryName);
            Assert.Equal("IN", country.CountryCode);
            Assert.Equal("Indian", country.Nationality);
            Assert.Equal("https://example.com/flag-in.png", country.ImageUrl);
        }

        [Fact]
        public void CountryList_ShouldAllowNulls()
        {
            // Arrange
            var country = new CountryList
            {
                Id = 2,
                CountryName = null,
                CountryCode = null,
                Nationality = null,
                ImageUrl = null
            };

            // Assert
            Assert.Equal(2, country.Id);
            Assert.Null(country.CountryName);
            Assert.Null(country.CountryCode);
            Assert.Null(country.Nationality);
            Assert.Null(country.ImageUrl);
        }
    }
}
