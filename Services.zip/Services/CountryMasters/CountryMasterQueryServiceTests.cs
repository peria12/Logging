﻿using Aurora.AdministrationService.API.Models.Dto.CountryMasters;
using Aurora.AdministrationService.API.Services.Service.CountryMasters;
using Aurora.AdministrationService.CrossCutting.CommonModels;
using Aurora.AdministrationService.Domain.V1.Entities.CountryMasters;
using Aurora.AdministrationService.Infrastructure;
using AutoMapper;
using Microsoft.EntityFrameworkCore;
using Moq;

namespace Aurora.AdministrationService.Tests.API.Services.CountryMasters
{
    public class CountryMasterQueryServiceTests
    {
        private readonly Mock<ReadOnlyDbContext> _readOnlyDbContextMock;
        private readonly Mock<IMapper> _mapperMock;
        private readonly CountryMasterQueryService _countryMasterQueryService;
        private Mock<DbSet<CountryMaster>> _mockDbSet;

        public CountryMasterQueryServiceTests()
        {
            //Initialize mock
            _readOnlyDbContextMock = new Mock<ReadOnlyDbContext>();
            _mapperMock = new Mock<IMapper>();

            // Setup in-memory ready only database for testing
            DbContextOptions<ReadOnlyDbContext> options = new DbContextOptionsBuilder<ReadOnlyDbContext>()
              .UseInMemoryDatabase(databaseName: "CountryMasterTestDB").Options;

            _readOnlyDbContextMock = new(options);

            _mockDbSet = new Mock<DbSet<CountryMaster>>();

            var data = new List<CountryMaster>
            {
               new CountryMaster {
                Id = 1,
                Code = "test",
                Definition = "Definition",
                Source = "test",
                ResourceId = "test",
                Display = "test",
                ImageUrl = "test",
                Nationality = "test",
                IsDeleted = false,
                CreatedBy = "Admin",
                CreatedDate = DateTime.UtcNow,
                UpdatedBy = "Admin",  // Adding the missing property
                UpdatedDate = DateTime.UtcNow,// Assuming UpdatedDate is required as well
            },
               new CountryMaster {
                Id = 2,
                Code = "test",
                Definition = "Definition",
                Source = "test",
                ResourceId = "test",
                Display = "test",
                ImageUrl = "test",
                Nationality = "test",
                IsDeleted = false,
                CreatedBy = "Admin",
                CreatedDate = DateTime.UtcNow,
                UpdatedBy = "Admin",  // Adding the missing property
                UpdatedDate = DateTime.UtcNow,// Assuming UpdatedDate is required as well
            }

            }.AsQueryable();


            //Setup
            _mockDbSet.As<IQueryable<CountryMaster>>().Setup(m => m.Provider).Returns(data.Provider);
            _mockDbSet.As<IQueryable<CountryMaster>>().Setup(m => m.Expression).Returns(data.Expression);
            _mockDbSet.As<IQueryable<CountryMaster>>().Setup(m => m.ElementType).Returns(data.ElementType);
            _mockDbSet.As<IQueryable<CountryMaster>>().Setup(m => m.GetEnumerator()).Returns(data.GetEnumerator());
            _readOnlyDbContextMock.Setup(c => c.CountryMasters).Returns(_mockDbSet.Object);

            // Create the service instance
            _countryMasterQueryService = new CountryMasterQueryService(_readOnlyDbContextMock.Object, _mapperMock.Object);
        }

        [Fact]
        public async Task GetCountryMasterById_LogoExists_ReturnsLogoDetailDto()
        {
            // Arrange
            var countryMasterId = 1L;
            var countryMaster = new CountryMaster
            {
                Id = 1,
                Code = "test",
                Definition = "Definition",
                Source = "test",
                ResourceId = "test",
                Display = "test",
                ImageUrl = "test",
                Nationality = "test",
                IsDeleted = false,
                CreatedBy = "Admin",
                CreatedDate = DateTime.UtcNow,
                UpdatedBy = "Admin",  // Adding the missing property
                UpdatedDate = DateTime.UtcNow,// Assuming UpdatedDate is required as well
            };

            var countryMasterDto = new GetCountryMasterDetailDto
            {
                Id = 1,
                Code = "test",
                Definition = "Definition",
                Source = "test",
                ResourceId = "test",
                Display = "test",
                ImageUrl = "test",
                Nationality = "test",

            };

            _readOnlyDbContextMock.Setup(db => db.CountryMasters.FindAsync(countryMasterId))
                .ReturnsAsync(countryMaster);

            _mapperMock.Setup(m => m.Map<GetCountryMasterDetailDto>(countryMaster))
                .Returns(countryMasterDto);

            // Act
            var result = await _countryMasterQueryService.GetCountryMasterById(countryMasterId);

            // Assert
            Assert.NotNull(result);
            Assert.Equal(countryMasterId, result.Id);
            Assert.Equal("test", result.Code);
        }

        [Fact]
        public async Task GetCountryMasterById_countryMasterNotFound_ReturnsNull()
        {
            //Arrange
            var countryMasterId = 1L;
            var countryMaster = new CountryMaster
            {
                Id = 1,
                Code = "test",
                Definition = "Definition",
                Source = "test",
                ResourceId = "test",
                Display = "test",
                ImageUrl = "test",
                Nationality = "test",
                IsDeleted = false,
                CreatedBy = "Admin",
                CreatedDate = DateTime.UtcNow,
                UpdatedBy = "Admin",  // Adding the missing property
                UpdatedDate = DateTime.UtcNow,// Assuming UpdatedDate is required as well
            };

            _readOnlyDbContextMock.Setup(db => db.CountryMasters.FindAsync(countryMasterId))
                .ReturnsAsync(countryMaster);

            //Act
            var result = await _countryMasterQueryService.GetCountryMasterById(countryMasterId);

            //Assert
            Assert.Null(result);
        }

        [Fact]
        public async Task GetCountryMasterById_countryMasterExists_BindingError_ReturnsNull()
        {
            // Arrange
            byte[] concurrencyToken = new byte[8] { byte.MinValue, byte.MinValue, byte.MinValue, byte.MinValue, byte.MinValue, byte.MinValue, byte.MinValue, byte.MaxValue };
            var countryMasterId = 1L;
            var countryMaster = new CountryMaster
            {
                Id = 1,
                Code = "test",
                Definition = "Definition",
                Source = "test",
                ResourceId = "test",
                Display = "test",
                ImageUrl = "test",
                Nationality = "test",
                IsDeleted = false,
                CreatedBy = "Admin",
                CreatedDate = DateTime.UtcNow,
                UpdatedBy = "Admin",  // Adding the missing property
                UpdatedDate = DateTime.UtcNow,// Assuming UpdatedDate is required as well
                RecordVersion = concurrencyToken
            };

            _readOnlyDbContextMock.Setup(db => db.CountryMasters.FindAsync(countryMasterId))
                .ReturnsAsync(countryMaster);

            _mapperMock.Setup(m => m.Map<GetCountryMasterDetailDto>(countryMaster))
                .Throws(new AutoMapperMappingException("Error mapping entity to DTO"));

            // Act & Assert
            var exception = await Assert.ThrowsAsync<AutoMapperMappingException>(
                () => _countryMasterQueryService.GetCountryMasterById(countryMasterId)
            );

            Assert.Equal("Error mapping entity to DTO", exception.Message);
        }

        [Fact]
        public async Task FindCountryMasterById_countryMasterExists_ReturnscountryMaster()
        {
            // Arrange
            byte[] concurrencyToken = new byte[8] { byte.MinValue, byte.MinValue, byte.MinValue, byte.MinValue, byte.MinValue, byte.MinValue, byte.MinValue, byte.MaxValue };
            long countryMasterId = 1L;
            var countryMaster = new CountryMaster
            {
                Id = countryMasterId,
                Code = "test",
                Definition = "Definition",
                Source = "test",
                ResourceId = "test",
                Display = "test",
                ImageUrl = "test",
                Nationality = "test",
                IsDeleted = false,
                CreatedBy = "Admin",
                CreatedDate = DateTime.UtcNow,
                UpdatedBy = "Admin",  // Adding the missing property
                UpdatedDate = DateTime.UtcNow,// Assuming UpdatedDate is required as well
                RecordVersion = concurrencyToken
            };

            // Mock the FindAsync method to return the countryMaster
            _readOnlyDbContextMock.Setup(db => db.CountryMasters.FindAsync(countryMasterId))
                .ReturnsAsync(countryMaster);

            // Act
            var result = await _countryMasterQueryService.FindCountryMasterById(countryMasterId);

            // Assert
            Assert.NotNull(result);
        }

        [Fact]
        public async Task FindCountryMasterById_countryMasterNotFound_ReturnsNull()
        {
            // Arrange
            var countryMasterId = 1L;
            var countryMaster = new CountryMaster
            {
                Id = countryMasterId,
                Code = "test",
                Definition = "Definition",
                Source = "test",
                ResourceId = "test",
                Display = "test",
                ImageUrl = "test",
                Nationality = "test",
                IsDeleted = false,
                CreatedBy = "Admin",
                CreatedDate = DateTime.UtcNow,
                UpdatedBy = "Admin",  // Adding the missing property
                UpdatedDate = DateTime.UtcNow,// Assuming UpdatedDate is required as well
            };

            // Mock the FindAsync method to return null (countryMaster not found)
            _readOnlyDbContextMock.Setup(db => db.CountryMasters.FindAsync(countryMasterId))
                .ReturnsAsync(countryMaster);

            // Act
            var result = await _countryMasterQueryService.FindCountryMasterById(countryMasterId);

            // Assert
            Assert.NotNull(result);
        }

        [Fact]
        public void GetCountryMasterList_ReturnsCorrectCountryMasterList()
        {
            // Act
            var result = _countryMasterQueryService.GetCountryMasterList();

            // Assert
            Assert.NotNull(result);
            Assert.Equal(2, result.Count); // Verifying that 3 items are returned

            // Verifying that the returned items are mapped correctly
            Assert.Contains(result, r => r.Id == 1 && r.Code == "test");
            Assert.Contains(result, r => r.Id == 2 && r.Code == "test");
        }

        [Fact]
        public void GetCountryMasters_ReturnsCorrectCountryMasterList()
        {
            // Act
            var result = _countryMasterQueryService.GetCountryMasters();

            // Assert
            Assert.NotNull(result);
            Assert.Equal(2, result.Count); // Verifying that 3 items are returned

            // Verifying that the returned items are mapped correctly
            Assert.Contains(result, r => r.Id == 1 && r.CountryCode == "test");
            Assert.Contains(result, r => r.Id == 2 && r.CountryCode == "test");
        }
        [Fact]
        public async Task IsCountryMasterAlreadyExist_ShouldReturnTrue_WhencountryMasterExists()
        {
            // Arrange
            var countryMasterId = 1L;
            var countryMaster = new CountryMaster
            {
                Id = 1,
                Code = "test",
                Definition = "Definition",
                Source = "test",
                ResourceId = "test",
                Display = "test",
                ImageUrl = "test",
                Nationality = "test",
                IsDeleted = false,
                CreatedBy = "Admin",
                CreatedDate = DateTime.UtcNow,
                UpdatedBy = "Admin",  // Adding the missing property
                UpdatedDate = DateTime.UtcNow,// Assuming UpdatedDate is required as well
            };

            // Mock the FindAsync method to return the countryMaster
            _readOnlyDbContextMock.Setup(db => db.CountryMasters.FindAsync(countryMasterId))
                .ReturnsAsync(countryMaster);

            // Act
            var result = await _countryMasterQueryService.IsCountryMasterAlreadyExist(countryMasterId);

            // Assert
            Assert.True(result.result);
            Assert.Equal(ResponseMessage.STATUS_DATA_FOUND, result.message);
        }

        [Fact]
        public async Task IsCountryMasterAlreadyExist_ShouldReturnFalse_WhencountryMasterDoesNotExist()
        {
            // Arrange
            var countryMasterId = 3L;

            // Act
            var result = await _countryMasterQueryService.IsCountryMasterAlreadyExist(countryMasterId);

            // Assert
            Assert.False(result.result);
            Assert.Equal(ResponseMessage.STATUS_NODATA, result.message);
        }
    }
}
