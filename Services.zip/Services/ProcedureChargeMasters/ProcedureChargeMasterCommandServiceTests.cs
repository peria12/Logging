﻿using Aurora.AdministrationService.API.Models.Dto.ProcedureChargeMasters;
using Aurora.AdministrationService.API.Services.Service.ProcedureChargeMasters;
using Aurora.AdministrationService.Domain.V1.Entities.ProcedureChargeMasters;
using Aurora.AdministrationService.Infrastructure;
using Aurora.AdministrationService.Tests.API.Controllers.ProcedureChargeMasters;
using AutoMapper;
using FluentAssertions;
using Microsoft.EntityFrameworkCore;
using Moq;
using System.Reflection;
using System.Text;

namespace Aurora.AdministrationService.Tests.API.Services.ProcedureChargeMasters
{
    public class ProcedureChargeMasterCommandServiceTests
    {
        private readonly ProcedureChargeMasterCommandService _service;
        private readonly ReadWriteDbContext _dbContext;
        private readonly IMapper _mapper;

        public ProcedureChargeMasterCommandServiceTests()
        {
            var options = new DbContextOptionsBuilder<ReadWriteDbContext>()
                .UseInMemoryDatabase(databaseName: "TestDatabase")
                .Options;

            _dbContext = new ReadWriteDbContext(options);

            var mapperConfig = new MapperConfiguration(cfg =>
            {
                cfg.CreateMap<ProcedureChargeMasterDto, ProcedureChargeMaster>();
                cfg.CreateMap<UpdateProcedureChargeMasterRequest, ProcedureChargeMaster>();
                cfg.CreateMap<ProcedureChargeMaster, ProcedureChargeMasterDto>()
                        .ForMember(dest => dest.ItemCode, opt => opt.MapFrom(src => src.ItemCode));
                        //.ForMember(dest => dest.TestCode, opt => opt.MapFrom(src => src.TestCode));
            });
            _mapper = mapperConfig.CreateMapper();

            _service = new ProcedureChargeMasterCommandService(_dbContext, _mapper);
        }


        [Fact]
        public async Task AddProcedureChargeMasterAsync_ShouldAddProcedureChargeMasterSuccessfully()
        {
            // Arrange
            var request = CommonMockData.GetMockCreateProcedureChargeMasterRequest();
            // Ensure required fields are set

            // Act
            var result = await _service.CreateProcedureChargeMasterAsync(request);
            var service = await _dbContext.ProcedureChargeMasters.FirstOrDefaultAsync(d => d.ItemCode == request.ItemCode);

            // Assert
            service.Should().NotBeNull();
            service?.CreatedBy.Should().Be("Admin");
            result.Should().BeTrue();
        }
        [Fact]
        public async Task AddProcedureChargeMasterAsync_ShouldReturnFalse_WhenExceptionOccurs()
        {
            // Arrange
            var request = CommonMockData.GetMockCreateProcedureChargeMasterRequest();
            request.ItemCode = null; // Simulating invalid data to trigger exception

            // Act
            var result = await _service.CreateProcedureChargeMasterAsync(request);

            // Assert
            result.Should().BeFalse("because the input data was invalid and an exception should have been thrown during SaveChanges");
        }


        [Fact]
        public async Task UpdateProcedureChargeMasterAsync_ShouldUpdateProcedureChargeMasterSuccessfully()
        {
            // Arrange
            await ClearDatabaseAsync();

            // Create a mock entity with a specific ID
            var serviceCharge = CommonMockData.GetMockProcedureChargeMaster3(id: 5);

            // Add the entity to the in-memory database and save changes
            _dbContext.ProcedureChargeMasters.Add(serviceCharge);
            await _dbContext.SaveChangesAsync();

            // Retrieve the entity to ensure it exists and is being tracked
            var existingService = await _dbContext.ProcedureChargeMasters
                .FirstOrDefaultAsync(s => s.Id == serviceCharge.Id); // Use ID to locate the entity

            existingService.Should().NotBeNull(); // Ensure the entity exists

            // Create an update request with the same RecordVersion for concurrency control
            var request = CommonMockData.GetMockUpdateProcedureChargeMasterRequest(
                itemCode: serviceCharge.ItemCode,
                recordVersion: existingService?.RecordVersion // Pass the existing RecordVersion
            );

            // Ensure the request contains the correct ID
            request.Id = existingService!.Id; // Use the existing ID

            // Act
            var result = await _service.UpdateProcedureChargeMasterAsync(request, existingService);

            // Assert
            var updatedService = await _dbContext.ProcedureChargeMasters
                .AsNoTracking() // Fetch a fresh copy without tracking
                .FirstOrDefaultAsync(s => s.Id == serviceCharge.Id); // Use ID to locate the updated entity

            // Verify the entity is updated correctly
            updatedService.Should().NotBeNull();
            updatedService?.Id.Should().Be(serviceCharge.Id); // Ensure the ID is unchanged
            updatedService?.UpdatedBy.Should().Be("Admin"); // Verify the updated user ID
            updatedService?.UpdatedDate.Should().BeCloseTo(DateTime.UtcNow, TimeSpan.FromSeconds(1)); // Verify the timestamp

            // Verify the result (DTO)
            result.Should().BeTrue();
        }

        [Fact]
        public async Task DeleteProcedureChargeMasterAsync_ShouldSoftDelete_WhenRecordExists()
        {
            // Arrange
            var service = new ProcedureChargeMaster
            {
                ItemCode = "Ser123",
                MasterType = "General",
                IsDeleted = false,
                CreatedDate = DateTime.UtcNow,
                CreatedBy = "TestUser",
                RecordVersion = Encoding.UTF8.GetBytes("1"),
            };

            await _dbContext.ProcedureChargeMasters.AddAsync(service);
            await _dbContext.SaveChangesAsync();

            var existingService = await _dbContext.ProcedureChargeMasters.FirstOrDefaultAsync(d => d.ItemCode == service.ItemCode);
            existingService.Should().NotBeNull();
            var originalRecordVersion = existingService?.RecordVersion;

            // Act
            var result = await _service.DeleteProcedureChargeMasterByIdAsync(originalRecordVersion!, existingService!);

            // Assert
            result.Should().BeTrue();

            var deletedService = await _dbContext.ProcedureChargeMasters.FirstOrDefaultAsync(d => d.ItemCode == service.ItemCode);
            deletedService.Should().NotBeNull();
            deletedService?.IsDeleted.Should().BeTrue();
            deletedService?.UpdatedBy.Should().Be("Admin");
            deletedService?.UpdatedDate.Should().BeCloseTo(DateTime.UtcNow, TimeSpan.FromSeconds(1));
        }

        [Fact]
        public async Task DeleteProcedureChargeMasterAsync_ShouldThrowException_WhenRecordVersionMismatch()
        {
            // Arrange
            var service = new ProcedureChargeMaster
            {
                ItemCode = "Ser123",
                MasterType = "General",
                IsDeleted = false,
                CreatedDate = DateTime.UtcNow,
                CreatedBy = "TestUser",
                RecordVersion = Encoding.UTF8.GetBytes("1"),
            };


            await _dbContext.ProcedureChargeMasters.AddAsync(service);
            await _dbContext.SaveChangesAsync();

            var existingService = await _dbContext.ProcedureChargeMasters.FirstOrDefaultAsync(d => d.ItemCode == service.ItemCode);
            existingService.Should().NotBeNull();

            // Act
            Func<Task> act = async () => await _service.DeleteProcedureChargeMasterByIdAsync(Encoding.UTF8.GetBytes("2"), existingService!);

            // Assert
            await act.Should().ThrowAsync<DbUpdateConcurrencyException>();
        }

        private static async Task ClearDatabaseAsync()
        {
            var options = new DbContextOptionsBuilder<ReadWriteDbContext>()
                .UseInMemoryDatabase(databaseName: Guid.NewGuid().ToString())
                .Options;

            using var dbContext = new ReadWriteDbContext(options);
            dbContext.ProcedureChargeMasters.RemoveRange(dbContext.ProcedureChargeMasters);
            await dbContext.SaveChangesAsync();
        }
    }
}
