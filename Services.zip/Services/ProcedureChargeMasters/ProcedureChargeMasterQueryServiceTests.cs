﻿using Aurora.AdministrationService.API.Models.Dto.ProcedureChargeMasters;
using Aurora.AdministrationService.API.Services.Service.ProcedureChargeMasters;
using Aurora.AdministrationService.CrossCutting.CommonModels;
using Aurora.AdministrationService.Domain.V1.Entities.ProcedureChargeMasters;
using Aurora.AdministrationService.Infrastructure;
using Aurora.AdministrationService.Tests.API.Controllers.ProcedureChargeMasters;
using AutoMapper;
using FluentAssertions;
using Microsoft.EntityFrameworkCore;
using Moq;

namespace Aurora.AdministrationService.Tests.API.Services.ProcedureChargeMasters
{
    public class ProcedureChargeMasterQueryServiceTests
    {
        private readonly ReadOnlyDbContext _dbContext;
        private readonly Mock<IMapper> _mockMapper;
        private readonly ProcedureChargeMasterQueryService _service;

        public ProcedureChargeMasterQueryServiceTests()
        {
            var options = new DbContextOptionsBuilder<ReadOnlyDbContext>()
                .UseInMemoryDatabase(databaseName: Guid.NewGuid().ToString()) // Use a unique DB per test
                .Options;

            _dbContext = new ReadOnlyDbContext(options);
            _mockMapper = new Mock<IMapper>();
            _service = new ProcedureChargeMasterQueryService(_dbContext, _mockMapper.Object);
        }


        [Fact]
        public async Task CheckExistingProcedureChargeMasterAsync_ReturnsProcedureChargeMaster_WhenItemCodeExists()
        {
            // Arrange
            var mockProcedureChargeMaster = CommonMockData.GetMockProcedureChargeMaster();
            _dbContext.ProcedureChargeMasters.Add(mockProcedureChargeMaster);
            await _dbContext.SaveChangesAsync();

            // Act
            var result = await _service.CheckExistingProcedureChargeMasterAsync("Item001");

            // Assert
            result.Should().NotBeNull();
            result?.ItemCode.Should().Be("Item001");
        }

        [Fact]
        public async Task GetProcedureChargeMasterById_ReturnProcedureChargeMasterDto_WhenIdExists()
        {
            // Arrange
            var mockProcedureChargeMaster = CommonMockData.GetMockProcedureChargeMaster();
            mockProcedureChargeMaster.Id = 1; // Explicitly set the ID

            // Ensure the database context is tracking the entity properly
            _dbContext.ProcedureChargeMasters.Add(mockProcedureChargeMaster);
            await _dbContext.SaveChangesAsync();

            // Retrieve the entity from the database to ensure tracking
            var savedProcedureChargeMaster = await _dbContext.ProcedureChargeMasters.FirstOrDefaultAsync(d => d.Id == 1);
            savedProcedureChargeMaster.Should().NotBeNull(); // Sanity check

            // Setup AutoMapper mock
            var mockProcedureChargeMasterDto = new GetProcedureChargeMasterDetailDto
            {
                ItemCode = "Item001",
                ProcedureCode = "test",
                FacilityCode = "test",
                ProcedureDesc = "test",
                ItemDescription = "test",
                ItemTypeCode = "test",
                ItemTypeDescription = "test",
                MasterType = "test",
                IsDeleted = false,
                Id = 1,
                RecordVersion= new byte[] {1,1,1,1 }
            };
            _mockMapper.Setup(m => m.Map<GetProcedureChargeMasterDetailDto>(It.IsAny<ProcedureChargeMaster>())).Returns(mockProcedureChargeMasterDto);

            // Act
            var result = await _service.GetProcedureChargeMasterById(1);

            // Assert
            result.Should().NotBeNull();
            result.ItemCode.Should().Be("Item001");
        }
        [Fact]
        public async Task IsProcedureChargeMasterAlreadyExist_ShouldReturnFalse_WhenRecordDoesNotExist()
        {
            // Arrange
            var options = new DbContextOptionsBuilder<ReadOnlyDbContext>()
                .UseInMemoryDatabase(databaseName: "ProcedureChargeMasterNotExistDb")
                .Options;

            using var context = new ReadOnlyDbContext(options);
          //  var service = new ProcedureChargeMasterQueryService(context); // Your actual query service

            // Act
            var (result, message) = await _service.IsProcedureChargeMasterAlreadyExist(999); // Non-existing ID

            // Assert
            result.Should().BeFalse();
            message.Should().Be(ResponseMessage.STATUS_NODATA);
        }
        [Fact]
        public async Task IsProcedureChargeMasterAlreadyExist_ShouldReturnTrue_WhenRecordExists()
        {
            // Arrange
            var options = new DbContextOptionsBuilder<ReadOnlyDbContext>()
                .UseInMemoryDatabase(databaseName: "ProcedureChargeMaster_Exist_True")
                .Options;

            var expectedId = 1001L;

            // Add a record to the in-memory database
            using (var context = new ReadOnlyDbContext(options))
            {
                context.ProcedureChargeMasters.Add(new ProcedureChargeMaster
                {
                    Id = expectedId,
                    ItemCode = "TEST1001",
                    IsDeleted=false,
                    CreatedBy = "Admin",
                    CreatedDate = DateTime.UtcNow
                });

                await context.SaveChangesAsync();
            }

            // Use a new context instance for isolation (optional)
            using (var context = new ReadOnlyDbContext(options))
            {
                var service = new ProcedureChargeMasterQueryService(context,_mockMapper.Object); // Your actual query service

                // Act
                var (result, message) = await service.IsProcedureChargeMasterAlreadyExist(expectedId);

                // Assert
                result.Should().BeTrue();
                message.Should().Be(ResponseMessage.STATUS_DATA_FOUND);
            }
        }



        [Fact]
        public async Task GetProcedureChargeMasterList_ReturnsListOfProcedureChargeMasterDto()
        {
            // Arrange: Add mock data to the in-memory database
            var mockProcedureChargeMasters = new List<ProcedureChargeMaster>
            {
                CommonMockData.GetMockProcedureChargeMaster(),
                CommonMockData.GetMockProcedureChargeMaster2(),
                CommonMockData.GetMockProcedureChargeMaster3()
            };

            await _dbContext.ProcedureChargeMasters.AddRangeAsync(mockProcedureChargeMasters);
            await _dbContext.SaveChangesAsync();

            // Ensure database has records
            var count = await _dbContext.ProcedureChargeMasters.CountAsync();
            count.Should().Be(3, "Database should contain exactly two ProcedureChargeMaster records.");

            // Setup AutoMapper to map DrugMaster -> GetDrugMasterDto
            _mockMapper.Setup(m => m.Map<List<GetProcedureChargeMasterDto>>(It.IsAny<List<ProcedureChargeMaster>>()))
                       .Returns((List<ProcedureChargeMaster> dms) => dms.Select(dm => new GetProcedureChargeMasterDto
                       {
                           ItemCode = dm.ItemCode,
                           ItemDescription = dm.ItemDescription,
                           IsDeleted = false,
                           MasterType = dm.MasterType,
                           ItemTypeDescription = dm.ItemTypeDescription,
                           ItemTypeCode = dm.ItemTypeCode,
                           ProcedureDesc = dm.ProcedureDesc,
                           FacilityCode = dm.FacilityCode,
                           ProcedureCode = dm.ProcedureCode,
                           RecordVersion = new byte[] { 1, 1, 1, 1 }
                       }).ToList());

            // Act: Call the service method
            var result = await _service.GetProcedureChargeMasterList();

            // Assert: Verify the results
            result.Should().NotBeNull();
            result.Should().HaveCount(3, "The service should return exactly two ProcedureChargeMasterDto records.");

            result[0].ItemCode.Should().Be(mockProcedureChargeMasters[0].ItemCode);
            result[1].ItemCode.Should().Be(mockProcedureChargeMasters[1].ItemCode);
            result[2].ItemCode.Should().Be(mockProcedureChargeMasters[2].ItemCode);
        }
        [Fact]
        public async Task FindProcedureChargeMasterById_ShouldReturnNull_WhenRecordDoesNotExist()
        {
            // Arrange
            var options = new DbContextOptionsBuilder<ReadOnlyDbContext>()
                .UseInMemoryDatabase(databaseName: "ProcedureChargeMasterDb_NotExists")
                .Options;

            using var context = new ReadOnlyDbContext(options);
           // var service = new ProcedureChargeMasterQueryService(context); // Replace with your actual service class

            // Act
            var result = await _service.FindProcedureChargeMasterById(999); // Non-existing ID

            // Assert
            result.Should().BeNull("because no record exists with the provided ID");
        }

    }
}
