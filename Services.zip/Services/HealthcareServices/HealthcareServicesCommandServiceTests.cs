using Aurora.AdministrationService.API.Models.Dto.HealthcareServices;
using Aurora.AdministrationService.API.Resources;
using Aurora.AdministrationService.API.Services.IService.HealthcareService;
using Aurora.AdministrationService.API.Services.Service.HealthcareService;
using Aurora.AdministrationService.CrossCutting.CommonModels;
using Aurora.AdministrationService.Domain.V1.Entities.HealthcareService;
using Aurora.AdministrationService.Infrastructure;
using Aurora.AdministrationService.Tests.API.CommonMock;
using AutoMapper;
using FluentAssertions;
using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Diagnostics;
using Moq;
namespace Aurora.AdministrationService.Tests.API.Services.HealthcareServices
{
    public class HealthcareServicesCommandServiceTests
    {
        private readonly HealthcareServicesCommandService _service;
        private readonly ReadWriteDbContext _dbReadWriteContext;
        private readonly Mock<IMapper> _mapperMock;

        public HealthcareServicesCommandServiceTests()
        {
            // Set up an in-memory database
            DbContextOptions<ReadWriteDbContext> options = new DbContextOptionsBuilder<ReadWriteDbContext>()
                .UseInMemoryDatabase(databaseName: Guid.NewGuid().ToString())
                .ConfigureWarnings(b => b.Ignore(InMemoryEventId.TransactionIgnoredWarning))
                .Options;

            _dbReadWriteContext = new ReadWriteDbContext(options);

            _mapperMock = new Mock<IMapper>();

            _service = new HealthcareServicesCommandService(_dbReadWriteContext, _mapperMock.Object);
        }

        [Fact]
        public async Task CreateHealthcareServiceAsync_ShouldReturnSuccess_WhenHealthcareServiceIsCreated()
        {
            // Arrange
            CreateHealthcareServicesDto request = GetHealthcareServiceMockData();

            var healthcareService = new Domain.V1.Entities.HealthcareService.HealthcareServices
            {
                ID = 1,
                Name = "Darmotologie",
                CreatedDate = DateTime.UtcNow,
                Status = true,
                CreatedBy = "user123",
                UpdatedBy = "user123",
                IsDeleted = false,
                RecordVersion = Array.Empty<byte>()
            };

            // Mock the mapping behavior
            _mapperMock.Setup(m => m.Map<Domain.V1.Entities.HealthcareService.HealthcareServices>(It.IsAny<CreateHealthcareServicesDto>()))
                .Returns(healthcareService);

            _mapperMock.Setup(m => m.Map<HealthcareServicesKeyWords>(It.IsAny<HealthcareServicesKeyWordsDto>()))
                .Returns(new HealthcareServicesKeyWords { Keyword = "Skin", RecordVersion = Array.Empty<byte>(), IsDeleted = false, HealthcareServicesID = 1, CreatedDate = DateTime.UtcNow });

            // Mock saving changes
            await _dbReadWriteContext.SaveChangesAsync();

            // Act
            var result = await _service.CreateHealthcareServiceAsync(request);

            // Assert
            result.HasError.Should().BeFalse();
            result.IsSuccess.Should().BeTrue();
            result.StatusCode.Should().Be(ResponseStatus.STATUS_SUCCESS);
            result.Message.Should().Be(Resource.RecordInsertionMessage);
            result.Result.Should().BeEquivalentTo(request);
        }

        [Fact]
        public async Task CreateHealthcareServicesAsync_ShouldAddHealthcareServicesuccessfully()
        {
            // Arrange
            CreateHealthcareServicesDto request = GetHealthcareServiceMockData();

            // Act
            var result = await _service.CreateHealthcareServiceAsync(request);

            // Assert
            result.Should().NotBeNull();
        }

        [Fact]
        public async Task UpdateHealthcareServicesStatus_ShouldReturnSuccess_WhenValidRequestAndValidRecordVersion()
        {
            // Arrange
            _dbReadWriteContext.Database.EnsureDeleted();
            var HealthcareService = new Domain.V1.Entities.HealthcareService.HealthcareServices
            {
                ID = 14,
                Name = "Name1",
                LaymanDescription = "DESC1",
                Location = "Columbia",
                Status = false,
                IsDeleted = false,
                CreatedBy = "testUser",
                CreatedDate = DateTime.Now,
                UpdatedBy = "testUser",
                UpdatedDate = DateTime.Now,
                RecordVersion = new byte[] { 1, 2, 3, 4 }
            };

            _dbReadWriteContext.HealthcareServices.Add(HealthcareService);
            await _dbReadWriteContext.SaveChangesAsync();

            var updateRequest = new UpdateHealthcareRequest
            {
                Name = "Name1",
                LaymanDescription = "DESC2",
                Location = "Columbia",
                Status = true,
                RecordVersion = new byte[] { 1, 2, 3, 4 } // Simulate a concurrency conflict
            };

            // Act
            var result = await _service.UpdatHealthcareServiceStatusAsync(updateRequest, HealthcareService);

            // Assert
            Assert.True(result.IsSuccess);
            Assert.Equal(Resource.RecordUpdationMessage, result.Message);
        }

        [Fact]
        public async Task CreateHealthcareServiceAsync_ShouldRollbackAndReturnError_WhenGeneralExceptionOccurs()
        {
            // Arrange
            var healthcareService = It.IsAny<Domain.V1.Entities.HealthcareService.HealthcareServices>();
            var healthcareKeywords = It.IsAny<HealthcareServicesKeyWords>();
            var createRequest = It.IsAny<CreateHealthcareServicesDto>();

            // Simulate general exception
            _mapperMock
                .Setup(m => m.Map(createRequest, healthcareService))
                .Throws(new Exception("Simulated error"));

            // Act
            var result = await _service.CreateHealthcareServiceAsync(createRequest);

            // Assert
            result.Should().NotBeNull();
            result.IsSuccess.Should().BeFalse();
            result.HasError.Should().BeTrue();
            result.StatusCode.Should().Be(ResponseStatus.STATUS_InternalServerError);
            result.Message.Should().Be(Resource.RecordInsertionFailureMessage);
        }

        [Fact]
        public async Task UpdateHealthcareServicesStatus_ShouldReturnError_WhenExceptionOccurs()
        {
            // Arrange
            _dbReadWriteContext.Database.EnsureDeleted();
            var HealthcareService = new Domain.V1.Entities.HealthcareService.HealthcareServices
            {
                ID = 15,
                Name = "Name1",
                LaymanDescription = "DESC1",
                Location = "Columbia",
                Status = false,
                IsDeleted = false,
                CreatedBy = "testUser",
                CreatedDate = DateTime.Now,
                UpdatedBy = "testUser",
                UpdatedDate = DateTime.Now,
                RecordVersion = new byte[] { 1, 2, 3, 4 }
            };

            _dbReadWriteContext.HealthcareServices.Add(HealthcareService);
            await _dbReadWriteContext.SaveChangesAsync();

            var updateRequest = new UpdateHealthcareRequest
            {
                Name = "Name1",
                LaymanDescription = "DESC2",
                Location = "Columbia",
                Status = true,
                RecordVersion = new byte[] { 5, 6, 7, 8 } // Simulate a concurrency conflict
            };

            // Simulate an exception during the update process
            _mapperMock.Setup(m => m.Map(It.IsAny<UpdateHealthcareRequest>(), It.IsAny<Domain.V1.Entities.HealthcareService.HealthcareServices>()))
                       .Throws(new Exception("Simulated error"));

            // Act
            var result = await _service.UpdatHealthcareServiceStatusAsync(updateRequest, HealthcareService);

            // Assert
            Assert.False(result.IsSuccess);
            Assert.Equal(ResponseStatus.STATUS_InternalServerError, result.StatusCode);
            Assert.Equal(Resource.RecordUpdationFailureMessage, result.Message);
        }

        [Fact]
        public async Task UpdateHealthcareServicesStatus_ShouldThrowDbUpdateConcurrencyException_WhenConcurrencyConflictOccurs()
        {
            // Arrange
            _dbReadWriteContext.Database.EnsureDeleted();
            var HealthcareService = new Domain.V1.Entities.HealthcareService.HealthcareServices
            {
                ID = 16,
                Name = "Name1",
                LaymanDescription = "DESC1",
                Location = "Columbia",
                Status = false,
                IsDeleted = false,
                CreatedBy = "testUser",
                CreatedDate = DateTime.Now,
                UpdatedBy = "testUser",
                UpdatedDate = DateTime.Now,
                RecordVersion = new byte[] { 1, 2, 3, 4 }
            };

            _dbReadWriteContext.HealthcareServices.Add(HealthcareService);
            await _dbReadWriteContext.SaveChangesAsync();

            var updateRequest = new UpdateHealthcareRequest
            {
                Name = "Name1",
                LaymanDescription = "DESC2",
                Location = "Columbia",
                Status = true,
                RecordVersion = new byte[] { 5, 6, 7, 8 } // Simulate a concurrency conflict
            };

            // Act & Assert
            await Assert.ThrowsAsync<DbUpdateConcurrencyException>(() => _service.UpdatHealthcareServiceStatusAsync(updateRequest, HealthcareService));
        }

        [Fact]
        public async Task UpdateHealthcareService_ShouldReturnSuccess_WhenValidRequestAndValidRecordVersion()
        {
            // Arrange
            _dbReadWriteContext.Database.EnsureDeleted();
            var healthcareService = new Domain.V1.Entities.HealthcareService.HealthcareServices
            {
                ID = 1,
                Name = "Initial Name",
                LaymanDescription = "Initial Description",
                Location = "Initial Location",
                Status = true,
                IsDeleted = false,
                CreatedBy = "testUser",
                CreatedDate = DateTime.UtcNow,
                UpdatedBy = "testUser",
                UpdatedDate = DateTime.UtcNow,
                RecordVersion = Convert.FromBase64String("ASSSSSS=")
            };

            var healthcareServicesKeywords = new HealthcareServicesKeyWords
            {
                ID = 1,
                HealthcareServicesID = 1,
                Keyword = "Initial Keyword",
                CreatedBy = "testUser",
                CreatedDate = DateTime.UtcNow,
                IsDeleted = false,
                UpdatedDate = DateTime.UtcNow,
                RecordVersion = Convert.FromBase64String("ASSSSSS=")
            };

            _dbReadWriteContext.HealthcareServices.Add(healthcareService);
            _dbReadWriteContext.HealthcareServicesKeyWords.Add(healthcareServicesKeywords);
            await _dbReadWriteContext.SaveChangesAsync();

            // API request model
            var updateRequest = new UpdateHealthcareServicesDto
            {
                Id = 1,
                Name = "NM1",
                LaymanDescription = "DESC1",
                Location = "KLAN",
                Status = true,
                HealthcareServicesKeyWords = new UpdateHealthcareServicesKeyWordsDto
                {
                    Id = 1,
                    Keyword = "NM",
                    RecordVersion = Convert.FromBase64String("ASSSSSS=")
                },
                RecordVersion = Convert.FromBase64String("ASSSSSS=")
            };
            _mapperMock
           .Setup(m => m.Map<Domain.V1.Entities.HealthcareService.HealthcareServices>(It.IsAny<UpdateHealthcareServicesDto>()))
           .Returns(healthcareService);

            _mapperMock
                .Setup(m => m.Map(It.IsAny<UpdateHealthcareServicesDto>(), It.IsAny<Domain.V1.Entities.HealthcareService.HealthcareServices>()))
                .Returns(healthcareService);
            _mapperMock
           .Setup(m => m.Map<HealthcareServicesKeyWords>(It.IsAny<UpdateHealthcareServicesKeyWordsDto>()))
           .Returns(healthcareServicesKeywords);

            _mapperMock
                .Setup(m => m.Map(It.IsAny<UpdateHealthcareServicesKeyWordsDto>(), It.IsAny<HealthcareServicesKeyWords>()))
                .Returns(healthcareServicesKeywords);


            // Act
            var result = await _service.UpdateHealthcareServiceAsync(updateRequest, healthcareService, healthcareServicesKeywords);

            // Assert
            Assert.True(result.IsSuccess);
            Assert.Equal(Resource.RecordUpdationMessage, result.Message);


        }

        [Fact]
        public async Task UpdateHealthcareService_ShouldReturnError_WhenExceptionOccurs()
        {
            // Arrange
            _dbReadWriteContext.Database.EnsureDeleted();
            var HealthcareService = new Domain.V1.Entities.HealthcareService.HealthcareServices
            {
                ID = 15,
                Name = "Name1",
                LaymanDescription = "DESC1",
                Location = "Columbia",
                Status = false,
                IsDeleted = false,
                CreatedBy = "testUser",
                CreatedDate = DateTime.Now,
                UpdatedBy = "testUser",
                UpdatedDate = DateTime.Now,
                RecordVersion = new byte[] { 1, 2, 3, 4 }
            };

            var HealthcareServicesKeywords = new HealthcareServicesKeyWords
            {
                ID = 1,
                HealthcareServicesID = 1,
                Keyword = "HealthcareServices",
                CreatedBy = "testUser",
                CreatedDate = DateTime.UtcNow,
                IsDeleted = false,
                UpdatedDate = DateTime.UtcNow,
                RecordVersion = new byte[] { 1, 2, 3, 4 }
            };

            _dbReadWriteContext.HealthcareServices.Add(HealthcareService);
            _dbReadWriteContext.HealthcareServicesKeyWords.Add(HealthcareServicesKeywords);
            await _dbReadWriteContext.SaveChangesAsync();

            var updateRequest = new UpdateHealthcareServicesDto
            {
                Id = 1,
                Name = "Updated Test HealthcareServices",
                Status = true,
                LaymanDescription = "Updated Description",
                Location = "Updated Location",
                RecordVersion = new byte[] { 1, 2, 3, 4 },
                HealthcareServicesKeyWords = new() { Id = 1, Keyword = "TestKey", RecordVersion = new byte[] { 1, 2, 3, 4, 5 } }
            };

            // Simulate an exception during the update process
            _mapperMock.Setup(m => m.Map(It.IsAny<UpdateHealthcareRequest>(), It.IsAny<Domain.V1.Entities.HealthcareService.HealthcareServices>()))
                       .Throws(new Exception("Simulated error"));

            // Act
            var result = await _service.UpdateHealthcareServiceAsync(updateRequest, HealthcareService, HealthcareServicesKeywords);

            // Assert
            Assert.False(result.IsSuccess);
            Assert.Equal(ResponseStatus.STATUS_BadRequest, result.StatusCode);
            Assert.Equal(Resource.RecordUpdationFailureMessage, result.Message);
        }

        [Fact]
        public async Task UpdateHealthcareService_ShouldRollbackTransaction_WhenException()
        {
            // Arrange
            _dbReadWriteContext.Database.EnsureDeleted();
            var healthcareService = new Domain.V1.Entities.HealthcareService.HealthcareServices
            {
                ID = 1,
                Name = "Initial Name",
                LaymanDescription = "Initial Description",
                Location = "Initial Location",
                Status = true,
                IsDeleted = false,
                CreatedBy = "testUser",
                CreatedDate = DateTime.UtcNow,
                UpdatedBy = "testUser",
                UpdatedDate = DateTime.UtcNow,
                RecordVersion = Convert.FromBase64String("ASSSSSS=")
            };

            var healthcareServicesKeywords = new HealthcareServicesKeyWords
            {
                ID = 1,
                HealthcareServicesID = 1,
                Keyword = "Initial Keyword",
                CreatedBy = "testUser",
                CreatedDate = DateTime.UtcNow,
                IsDeleted = false,
                UpdatedDate = DateTime.UtcNow,
                RecordVersion = Convert.FromBase64String("ASSSSSS=")
            };

            _dbReadWriteContext.HealthcareServices.Add(healthcareService);
            _dbReadWriteContext.HealthcareServicesKeyWords.Add(healthcareServicesKeywords);
            await _dbReadWriteContext.SaveChangesAsync();

            // API request model
            var updateRequest = new UpdateHealthcareServicesDto
            {
                Id = 1,
                Name = "NM1",
                LaymanDescription = "DESC1",
                Location = "KLAN",
                Status = true,
                HealthcareServicesKeyWords = new UpdateHealthcareServicesKeyWordsDto
                {
                    Id = 1,
                    Keyword = "NM",
                    RecordVersion = Convert.FromBase64String("BBBBBBB=")
                },
                RecordVersion = Convert.FromBase64String("BBBBBBB=")
            };

            _mapperMock
           .Setup(m => m.Map<HealthcareServicesKeyWords>(It.IsAny<UpdateHealthcareServicesKeyWordsDto>()))
           .Returns(healthcareServicesKeywords);

            _mapperMock
                .Setup(m => m.Map(It.IsAny<UpdateHealthcareServicesKeyWordsDto>(), It.IsAny<HealthcareServicesKeyWords>()))
                .Returns(healthcareServicesKeywords);
            var result = await _service.UpdateHealthcareServiceAsync(updateRequest, healthcareService, healthcareServicesKeywords);


            // Verify the exception message (optional)
            Assert.NotNull(result);
        }

        [Fact]
        public async Task UpdateHealthcareServiceAsync_ShouldRollbackAndReturnError_WhenGeneralExceptionOccurs()
        {
            // Arrange
            var healthcareService = It.IsAny<Domain.V1.Entities.HealthcareService.HealthcareServices>();
            var healthcareKeywords = It.IsAny<HealthcareServicesKeyWords>();
            var updateRequest = It.IsAny<UpdateHealthcareServicesDto>();

            // Simulate general exception
            _mapperMock
                .Setup(m => m.Map(updateRequest, healthcareService))
                .Throws(new Exception("Simulated error"));

            // Act
            var result = await _service.UpdateHealthcareServiceAsync(updateRequest, healthcareService, healthcareKeywords);

            // Assert
            result.Should().NotBeNull();
            result.IsSuccess.Should().BeFalse();
            result.HasError.Should().BeTrue();
            result.StatusCode.Should().Be(ResponseStatus.STATUS_InternalServerError);
            result.Message.Should().Be(Resource.RecordUpdationFailureMessage);
        }

        [Fact]
        public async Task UpdateHealthcareServiceAsync_ShouldThrowConcurrencyException_WhenDbUpdateConflictOccurs()
        {
            // Arrange
            var healthcareService = It.IsAny<Domain.V1.Entities.HealthcareService.HealthcareServices>();
            var healthcareKeywords = It.IsAny<HealthcareServicesKeyWords>();
            var updateRequest = It.IsAny<UpdateHealthcareServicesDto>();

            _mapperMock
                .Setup(m => m.Map(updateRequest, healthcareService))
                .Throws(new DbUpdateConcurrencyException("Simulated concurrency issue"));

            // Act & Assert
            await Assert.ThrowsAsync<DbUpdateConcurrencyException>(() =>
                _service.UpdateHealthcareServiceAsync(updateRequest, healthcareService, healthcareKeywords));
        }



        private static CreateHealthcareServicesDto GetHealthcareServiceMockData()
        {
            return new CreateHealthcareServicesDto
            {
                Name = "Dermatology",
                LaymanDescription = "Skin Doctor",
                Location = "KLAN",
                HealthcareServicesKeyWords = new HealthcareServicesKeyWordsDto
                { Keyword = "Skin" }
            };
        }

        [Fact]
        public async Task DeleteHealthcareServiceAsync_ShouldReturnTrue_WhenDeletionIsSuccessful()
        {
            //Arrange 
            _dbReadWriteContext.Database.EnsureDeleted();
            var healthcareService = new Domain.V1.Entities.HealthcareService.HealthcareServices
            {
                ID = 1,
                Name = "Initial Name",
                LaymanDescription = "Initial Description",
                Location = "Initial Location",
                Status = true,
                IsDeleted = false,
                CreatedBy = "testUser",
                CreatedDate = DateTime.UtcNow,
                UpdatedBy = "testUser",
                UpdatedDate = DateTime.UtcNow,
                RecordVersion = Convert.FromBase64String("ASSSSSS=")
            };

            var healthcareServicesKeywords = new HealthcareServicesKeyWords
            {
                ID = 1,
                HealthcareServicesID = 1,
                Keyword = "Initial Keyword",
                CreatedBy = "testUser",
                CreatedDate = DateTime.UtcNow,
                IsDeleted = false,
                UpdatedDate = DateTime.UtcNow,
                RecordVersion = Convert.FromBase64String("ASSSSSS=")
            };

            _dbReadWriteContext.HealthcareServices.Add(healthcareService);
            _dbReadWriteContext.HealthcareServicesKeyWords.Add(healthcareServicesKeywords);
            await _dbReadWriteContext.SaveChangesAsync();

            // Act
            var result = await _service.DeleteHealthcareServiceAsync(healthcareService.RecordVersion, healthcareService);

            // Assert
            result.Should().BeTrue();
            healthcareService.IsDeleted.Should().BeTrue();
            healthcareService.UpdatedBy.Should().NotBeNullOrWhiteSpace();
        }

        [Fact]
        public async Task DeleteHealthcareServiceAsync_ShouldReturnFalse_WhenExceptionOccurs()
        {
            // Arrange
            var dbContextOptions = new DbContextOptionsBuilder<ReadWriteDbContext>()
                .UseInMemoryDatabase(databaseName: Guid.NewGuid().ToString())
                .ConfigureWarnings(x => x.Ignore(InMemoryEventId.TransactionIgnoredWarning)) // Ignore transaction warning
                .Options;

            var dbContext = new ReadWriteDbContext(dbContextOptions);

            // Add a valid HealthcareService
            var healthcareService = new Domain.V1.Entities.HealthcareService.HealthcareServices
            {
                ID = 1,
                Name = "Initial Name",
                LaymanDescription = "Initial Description",
                Location = "Initial Location",
                Status = true,
                IsDeleted = false,
                CreatedBy = "testUser",
                CreatedDate = DateTime.UtcNow,
                UpdatedBy = "testUser",
                UpdatedDate = DateTime.UtcNow,
                RecordVersion = new byte[] { 1, 2, 3, 4 }
            };

            await dbContext.HealthcareServices.AddAsync(healthcareService);
            await dbContext.SaveChangesAsync();

            var service = new HealthcareServicesCommandService(dbContext, _mapperMock.Object);

            // Simulate failure: corrupt the entity by setting required property to null
            healthcareService.Name = null; // Assuming Name is [Required] in your model

            // Act
            var result = await service.DeleteHealthcareServiceAsync(healthcareService.RecordVersion, healthcareService);

            // Assert
            result.Should().BeFalse(); // Expect rollback and false return due to exception
        }




    }
}
