﻿using Aurora.AdministrationService.API.Models.Dto.HealthcareServices;
using Aurora.AdministrationService.API.Services.Service.HealthcareService;
using Aurora.AdministrationService.Infrastructure;
using FluentAssertions;
using Microsoft.EntityFrameworkCore;

namespace Aurora.AdministrationService.Tests.API.Services.HealthcareServices
{
   public class HealthcareServicesQueryServiceTests
    {
        private readonly HealthcareServiceQueryService _healthcareServiceQueryService;
        private readonly DbContextOptions<ReadOnlyDbContext> _options;
        private readonly ReadOnlyDbContext _readOnlyDbContext;

        public HealthcareServicesQueryServiceTests()
        {
            // Use a unique database name for each test to avoid shared state
            _options = new DbContextOptionsBuilder<ReadOnlyDbContext>()
                .UseInMemoryDatabase(databaseName: Guid.NewGuid().ToString()) // Unique name
                .Options;

            // Create a context that uses the InMemoryDatabase
            _readOnlyDbContext = new ReadOnlyDbContext(_options);

            // Create the service instance
            _healthcareServiceQueryService = new HealthcareServiceQueryService(_readOnlyDbContext);
        }

        [Fact]
        public void GetHealthcareServiceSearch_ShouldReturnEmptyList_WhenNoHealthcareServicesExist()
        {
            // Arrange
            _readOnlyDbContext.Database.EnsureDeleted();
            var searchRequest = new GetHealthcareSearchRequest
            {
                Speciality = "Name1",
                Location = "Columbia",
                SelectedStatus = ""

            };

            // Act
            var result = _healthcareServiceQueryService.GetHealthcareServiceSearch(searchRequest);

            // Assert
            Assert.Empty(result);  // No HealthcareServices should match the search criteria
        }

        [Fact]
        public async Task GetHealthcareServiceSearch_ShouldReturnHealthcareServices_WhenHealthcareServicesExist()
        {
            // Arrange: Adding HealthcareServices to the database
            _readOnlyDbContext.Database.EnsureDeleted();
            using (var context = new ReadOnlyDbContext(_options))
            {
                context.HealthcareServices.AddRange(
                   new Aurora.AdministrationService.Domain.V1.Entities.HealthcareService.HealthcareServices { ID = 1, Status = true, Name = "Name1", LaymanDescription = "DESC1", Location = "Columbia", IsDeleted = false, CreatedDate = DateTime.UtcNow, CreatedBy = "testUser", UpdatedDate = DateTime.UtcNow, RecordVersion = new byte[8] },
                    new Aurora.AdministrationService.Domain.V1.Entities.HealthcareService.HealthcareServices { ID = 2, Status = false, Name = "Name2", LaymanDescription = "DESC2", Location = "Columbia", IsDeleted = false, CreatedDate = DateTime.UtcNow, CreatedBy = "testUser", UpdatedDate = DateTime.UtcNow, RecordVersion = new byte[8] }
               );
                await context.SaveChangesAsync();
            }

            // Act
            var searchRequest = new GetHealthcareSearchRequest
            {
                Speciality = "Name1",
                Location = "",
                SelectedStatus = "Active"

            };
            var result = _healthcareServiceQueryService.GetHealthcareServiceSearch(searchRequest);

            // Assert
            Assert.Single(result);  // Only one HealthcareService should match the search criteria
            result[0].Speciality.Should().Be("Name1");  // HealthcareService 1 should be returned
        }

        [Fact]
        public async Task GetHealthcareServiceSearch_ShouldReturnEmptyList_WhenStatusDoesNotMatch()
        {
            // Arrange: Adding HealthcareServices to the database
            _readOnlyDbContext.Database.EnsureDeleted();
            using (var context = new ReadOnlyDbContext(_options))
            {
                context.HealthcareServices.AddRange(
                  new Domain.V1.Entities.HealthcareService.HealthcareServices { ID = 1, Status = true, Name = "Name1", LaymanDescription = "DESC1", Location = "Columbia", IsDeleted = false, CreatedDate = DateTime.UtcNow, CreatedBy = "testUser", UpdatedDate = DateTime.UtcNow, RecordVersion = new byte[8] },
                   new Domain.V1.Entities.HealthcareService.HealthcareServices { ID = 2, Status = false, Name = "Name2", LaymanDescription = "DESC2", Location = "Columbia", IsDeleted = false, CreatedDate = DateTime.UtcNow, CreatedBy = "testUser", UpdatedDate = DateTime.UtcNow, RecordVersion = new byte[8] }
                );
                await context.SaveChangesAsync();
            }

            // Act
            var searchRequest = new GetHealthcareSearchRequest
            {
                Speciality = "Name2",
                Location = "",
                SelectedStatus = "InActive"

            };
            var result = _healthcareServiceQueryService.GetHealthcareServiceSearch(searchRequest);

            // Assert
            Assert.Single(result);  // Only HealthcareService 2 should match as inactive
            result[0].Status.Should().BeFalse();  // HealthcareService 2 should have a status of 'false' (inactive)
        }

        [Fact]
        public async Task GetHealthcareServiceSearch_ShouldReturnHealthcareServices_WhenspecialityandloccationAreProvided()
        {
            // Arrange: Adding HealthcareServices to the database
            _readOnlyDbContext.Database.EnsureDeleted();
            using (var context = new ReadOnlyDbContext(_options))
            {
                context.HealthcareServices.AddRange(
                  new Aurora.AdministrationService.Domain.V1.Entities.HealthcareService.HealthcareServices { ID = 1, Status = true, Name = "Name1", LaymanDescription = "DESC1", Location = "Columbia", IsDeleted = false, CreatedDate = DateTime.UtcNow, CreatedBy = "testUser", UpdatedDate = DateTime.UtcNow, RecordVersion = new byte[8] },
                    new Aurora.AdministrationService.Domain.V1.Entities.HealthcareService.HealthcareServices { ID = 2, Status = false, Name = "Name2", LaymanDescription = "DESC2", Location = "Columbia", IsDeleted = false, CreatedDate = DateTime.UtcNow, CreatedBy = "testUser", UpdatedDate = DateTime.UtcNow, RecordVersion = new byte[8] }
              );
                await context.SaveChangesAsync();
            }

            // Act
            var searchRequest = new GetHealthcareSearchRequest
            {
                Speciality = "Name1",
                Location = "Columbia",
                SelectedStatus = "Active"

            };
            var result = _healthcareServiceQueryService.GetHealthcareServiceSearch(searchRequest);

            // Assert
            Assert.Single(result);  // Only HealthcareService 1 should match the date filter
            result[0].Speciality.Should().Be("Name1");  // HealthcareService 1 should be returned
        }

        [Fact]
        public async Task GetHealthcareServiceSearch_ShouldReturnHealthcareServices_WhenOnlyspecialityIsProvided()
        {
            // Adding HealthcareServices with start dates to the in-memory DB
            _readOnlyDbContext.Database.EnsureDeleted();
            using (var context = new ReadOnlyDbContext(_options))
            {
                context.HealthcareServices.AddRange(
                   new Domain.V1.Entities.HealthcareService.HealthcareServices { ID = 1, Status = true, Name = "Name1", LaymanDescription = "DESC1", Location = "Columbia", IsDeleted = false, CreatedDate = DateTime.UtcNow, CreatedBy = "testUser", UpdatedDate = DateTime.UtcNow, RecordVersion = new byte[8] },
                new Domain.V1.Entities.HealthcareService.HealthcareServices { ID = 2, Status = false, Name = "Name2", LaymanDescription = "DESC2", Location = "Columbia", IsDeleted = false, CreatedDate = DateTime.UtcNow, CreatedBy = "testUser", UpdatedDate = DateTime.UtcNow, RecordVersion = new byte[8] }
               );
                await context.SaveChangesAsync();
            }

            var searchRequest = new GetHealthcareSearchRequest
            {
                Speciality = "Name1",
                Location = "",
                SelectedStatus = "Active"

            };
            var result = _healthcareServiceQueryService.GetHealthcareServiceSearch(searchRequest);

            Assert.Single(result);  // Only HealthcareService 1 should match since its start date is before the selected start date
            Assert.Equal("Name1", result[0].Speciality);  // HealthcareService 1 should be returned
        }


        [Fact]
        public async Task GetHealthcareServiceSearch_ShouldApplyPaginationCorrectly()
        {
            // Adding HealthcareServices to the in-memory DB
            _readOnlyDbContext.Database.EnsureDeleted();
            using (var context = new ReadOnlyDbContext(_options))
            {
                context.HealthcareServices.AddRange(
                    new Domain.V1.Entities.HealthcareService.HealthcareServices { ID = 1, Status = true, Name = "Name1", LaymanDescription = "DESC1", Location = "Columbia", IsDeleted = false, CreatedDate = DateTime.UtcNow, CreatedBy = "testUser", UpdatedDate = DateTime.UtcNow, RecordVersion = new byte[8] },
                    new Domain.V1.Entities.HealthcareService.HealthcareServices { ID = 2, Status = false, Name = "Name2", LaymanDescription = "DESC2", Location = "Columbia", IsDeleted = false, CreatedDate = DateTime.UtcNow, CreatedBy = "testUser", UpdatedDate = DateTime.UtcNow, RecordVersion = new byte[8] },
             new Domain.V1.Entities.HealthcareService.HealthcareServices { ID = 3, Status = true, Name = "Name3", LaymanDescription = "DESC1", Location = "Columbia", IsDeleted = false, CreatedDate = DateTime.UtcNow, CreatedBy = "testUser", UpdatedDate = DateTime.UtcNow, RecordVersion = new byte[8] }
                     );
                await context.SaveChangesAsync();
            }
            var searchRequest = new GetHealthcareSearchRequest
            {
                PageNumber = 1,
                PageSize = 2,
                Speciality = "",
                Location = "",
                SelectedStatus = ""

            };

            var result = _healthcareServiceQueryService.GetHealthcareServiceSearch(searchRequest);

            Assert.Equal(2, result.Count);  // Only two HealthcareServices should be returned due to pagination
        }


        [Fact]
        public async Task FindHealthcareServiceById_ShouldReturnHealthcareService_WhenHealthcareServiceExists()
        {
            // Arrange
            _readOnlyDbContext.Database.EnsureDeleted();
            var HealthcareService = new Domain.V1.Entities.HealthcareService.HealthcareServices
            {
                ID = 1,
                Name = "Name1",
                LaymanDescription = "DESC1",
                Location = "Columbia",
                Status = true,
                RecordVersion = [1, 2, 3, 4],
                CreatedBy = "testUser",
                CreatedDate = DateTime.UtcNow,
                IsDeleted = false,
                UpdatedDate = DateTime.UtcNow,
                UpdatedBy = "testUser"
            };

            _readOnlyDbContext.HealthcareServices.Add(HealthcareService);
            await _readOnlyDbContext.SaveChangesAsync();

            // Act
            var result = await _healthcareServiceQueryService.FindHealthcareServiceById(HealthcareService.ID);

            // Assert
            Assert.NotNull(result);
            Assert.Equal(HealthcareService.ID, result.ID);
            Assert.Equal(HealthcareService.Name, result.Name);
            Assert.Equal(HealthcareService.Location, result.Location);
            Assert.Equal(HealthcareService.LaymanDescription, result.LaymanDescription);
            Assert.Equal(HealthcareService.Status, result.Status);
        }

        [Fact]
        public async Task FindHealthcareServiceById_ShouldReturnNull_WhenHealthcareServiceDoesNotExist()
        {
            // Arrange: ID does not exist in the database
            long nonExistingHealthcareServiceId = 9999;

            // Act
            var result = await _healthcareServiceQueryService.FindHealthcareServiceById(nonExistingHealthcareServiceId);

            // Assert
            Assert.Null(result);
        }

        [Fact]
        public async Task FindHealthcareServiceById_ShouldReturnNull_WhenDatabaseIsEmpty()
        {
            // Act: Call the service when no HealthcareServices are in the database
            var result = await _healthcareServiceQueryService.FindHealthcareServiceById(1);

            // Assert
            Assert.Null(result);
        }

        [Fact]
        public async Task FindHealthcareServiceById_ShouldReturnCorrectHealthcareService_WhenMultipleHealthcareServicesExist()
        {
            // Arrange
            _readOnlyDbContext.Database.EnsureDeleted();
            using (var context = new ReadOnlyDbContext(_options))
            {
                context.HealthcareServices.AddRange(
                    new Aurora.AdministrationService.Domain.V1.Entities.HealthcareService.HealthcareServices { ID = 1, Status = true, Name = "Name1", LaymanDescription = "DESC1", Location = "Columbia", IsDeleted = false, CreatedDate = DateTime.UtcNow, CreatedBy = "testUser", UpdatedDate = DateTime.UtcNow, RecordVersion = new byte[8] },
                    new Aurora.AdministrationService.Domain.V1.Entities.HealthcareService.HealthcareServices { ID = 2, Status = false, Name = "Name2", LaymanDescription = "DESC2", Location = "Columbia", IsDeleted = false, CreatedDate = DateTime.UtcNow, CreatedBy = "testUser", UpdatedDate = DateTime.UtcNow, RecordVersion = new byte[8] },
             new Aurora.AdministrationService.Domain.V1.Entities.HealthcareService.HealthcareServices { ID = 3, Status = true, Name = "Name3", LaymanDescription = "DESC1", Location = "Columbia", IsDeleted = false, CreatedDate = DateTime.UtcNow, CreatedBy = "testUser", UpdatedDate = DateTime.UtcNow, RecordVersion = new byte[8] }
                     );
                await context.SaveChangesAsync();
            }

            // Act: Fetch the first HealthcareService
            var result = await _healthcareServiceQueryService.FindHealthcareServiceById(1);

            // Assert
            Assert.NotNull(result);
            Assert.Equal(1, result.ID);
            Assert.Equal("Name1", result.Name);
            Assert.Equal("Columbia", result.Location);
        }
        [Fact]
        public async Task GetHealthcareServiceKeyWordsById_ShouldReturnCorrectHealthcareService_WhenMultipleHealthcareServicesExist()
        {
            // Arrange
            _readOnlyDbContext.Database.EnsureDeleted();
            using (var context = new ReadOnlyDbContext(_options))
            {
                context.HealthcareServicesKeyWords.AddRange(
                    new Domain.V1.Entities.HealthcareService.HealthcareServicesKeyWords { ID = 1,HealthcareServicesID=1, Keyword = "Name1",  IsDeleted = false, CreatedDate = DateTime.UtcNow, CreatedBy = "testUser", UpdatedDate = DateTime.UtcNow, RecordVersion = new byte[8] },
                    new Domain.V1.Entities.HealthcareService.HealthcareServicesKeyWords { ID = 2, HealthcareServicesID = 2, Keyword = "Name2",  IsDeleted = false, CreatedDate = DateTime.UtcNow, CreatedBy = "testUser", UpdatedDate = DateTime.UtcNow, RecordVersion = new byte[8] }
                );
                await context.SaveChangesAsync();
            }

            // Act: Fetch the first HealthcareService
            var result = await _healthcareServiceQueryService.GetHealthcareServiceKeyWordsById(1);

            // Assert
            Assert.NotNull(result);
            Assert.Equal(1, result.ID);
            Assert.Equal("Name1", result.Keyword);
        }

        [Fact]
        public async Task GetHealthcareServiceAsync_ReturnsCorrectHealthcareService_WhenIdIsValid()
        {
            // Arrange
            _readOnlyDbContext.Database.EnsureDeleted();
            var HealthcareService = new Domain.V1.Entities.HealthcareService.HealthcareServices
            {
                ID = 1,
                Name = "Health Service 1",
                LaymanDescription = "Description 1",
                Location = "Columbia",
                Status = true,
                RecordVersion = [1, 2, 3, 4],
                CreatedBy = "testUser",
                CreatedDate = DateTime.UtcNow,
                IsDeleted = false,
                UpdatedDate = DateTime.UtcNow,
                UpdatedBy = "testUser"
            };
          
            _readOnlyDbContext.HealthcareServices.Add(HealthcareService);
            await _readOnlyDbContext.SaveChangesAsync();
            _readOnlyDbContext.HealthcareServicesKeyWords.AddRange(
                 new Domain.V1.Entities.HealthcareService.HealthcareServicesKeyWords { ID = 1, HealthcareServicesID = 1, Keyword = "Keyword 1", IsDeleted = false, CreatedDate = DateTime.UtcNow, CreatedBy = "testUser", UpdatedDate = DateTime.UtcNow, RecordVersion = new byte[8] }

             );
            await _readOnlyDbContext.SaveChangesAsync();

            // Act
            var result = await _healthcareServiceQueryService.GetHealthcareServiceAsync(1);

            // Assert
            result.Should().NotBeNull();
            result.Id.Should().Be(1);
            result.Name.Should().Be("Health Service 1");
            result.LaymanDescription.Should().Be("Description 1");
            result.Location.Should().Be("Columbia");
            result.Status.Should().Be(true);
            result.HealthcareServicesKeyWords.Should().NotBeNull();
            result.HealthcareServicesKeyWords.Id.Should().Be(1);
            result.HealthcareServicesKeyWords.Keyword.Should().Be("Keyword 1");
        }

        [Fact]
        public async Task GetHealthcareServiceAsync_ReturnsNull_WhenHealthcareServiceNotFound()
        {
            // Act
            var result = await _healthcareServiceQueryService.GetHealthcareServiceAsync(999);  // Non-existent ID

            // Assert
            result.Should().BeNull();
        }
    }
}

