﻿using Aurora.AdministrationService.Domain.V1.Entities.Practitioners;
using Aurora.AdministrationService.Domain.V1.Entities;
using Aurora.AdministrationService.Infrastructure;
using Aurora.AdministrationService.API.Services.Service.DashBoard;
using Microsoft.EntityFrameworkCore;
using Aurora.AdministrationService.Domain.V1.Entities.Locations;
using Aurora.AdministrationService.Domain.V1.Entities.PractitionerRoles;
using Aurora.AdministrationService.Domain.V1.Entities.Organizations;
using FluentAssertions;

namespace Aurora.AdministrationService.Tests.API.Services.Dashboard
{
    public class DashboardPostLoginQueryServicetests
    {
        private readonly ReadOnlyDbContext _mockDbContext;
        private readonly DashboardPostLoginQueryService _dashboardPostLoginQueryService;

        public DashboardPostLoginQueryServicetests()
        {
            // Set up in-memory database
            var options = new DbContextOptionsBuilder<ReadOnlyDbContext>()
                .UseInMemoryDatabase(databaseName: Guid.NewGuid().ToString())
                .Options;

            _mockDbContext = new ReadOnlyDbContext(options);

            // Initialize the service
            _dashboardPostLoginQueryService = new DashboardPostLoginQueryService(_mockDbContext);
            SeedData(_mockDbContext);

        }

        private static void SeedData(ReadOnlyDbContext dbContext)
        {
            var practitioner = new Practitioner
            {
                Id = 1,
                ResourceID = "PRAC123",
                Status = true,
                Gender = "Male",
                BirthDate = DateTime.UtcNow.AddMonths(-250),
                Source = "Test",
                IsDeleted = false,
                CreatedBy = "Seeder",
                CreatedDate = DateTime.UtcNow
            };
            dbContext.Practitioners.Add(practitioner);
            dbContext.SaveChanges();

            var manageDoctorProfile = new ManageDoctorProfile
            {
                Id = 1,
                PractitionerID = practitioner.Id,
                FirstName = "John",
                LastName = "Doe",
                IsDeleted = false,
                CreatedBy = "Admin",
                CreatedDate = DateTime.UtcNow,
                UpdatedBy = "Admin",
                UpdatedDate = DateTime.UtcNow,
            };
            dbContext.ManageDoctorProfiles.Add(manageDoctorProfile);

            var practitionerName = new PractitionerNames
            {
                Id= 1,
                PractitionerID = practitioner.Id,
                Use = "official",
                GivenName = "John",
                MiddleName = "M",
                FamilyName = "Doe",
                Prefix = "Dr",
                Suffix = "MD",
                Language = "en",
                Status = true,
                IsDeleted = false,
                CreatedBy = "Admin",
                CreatedDate = DateTime.UtcNow,
                UpdatedBy = "Admin",
                UpdatedDate = DateTime.UtcNow,
                PeriodStart = DateTime.UtcNow.AddYears(-10),
                PeriodEnd = DateTime.UtcNow.AddYears(10),
                
                
            };
            dbContext.PractitionerName.Add(practitionerName);

            var practitionerPhoto = new PractitionerPhotos
            {
                PractitionerID = practitioner.Id,
                ContentType = "image/jpeg",
                Data = new byte[] { 1, 2, 3 },
                URL = "http://example.com/photo.jpg",
                Size = "100KB",
                Hash = "abc123",
                Title = "Profile Photo",
                Status = true,
                IsDeleted = false,
                CreatedBy = "Admin",
                CreatedDate = DateTime.UtcNow,
                UpdatedBy = "Admin",
                UpdatedDate = DateTime.UtcNow
            };
            dbContext.PractitionerPhoto.Add(practitionerPhoto);

            // RoleMaster
            var roleMaster = new RoleMaster
            {
                Id = 1,
                Code = "Doctor",
                Definition = "Doctor",
                IsDeleted = false,
                CreatedBy = "Admin",
                CreatedDate = DateTime.UtcNow,
                UpdatedBy = "Admin",
                UpdatedDate = DateTime.UtcNow
            };
            dbContext.RoleMasters.Add(roleMaster);
            dbContext.SaveChanges();

            // Organization
            var organization = new Organization
            {
                Id = 1,
                ResourceID = "ORG001",
                Name = "MedCare",
                Alias = "TestOrg",
                Source = "Aurora",
                Type = "test",
                IsDeleted = false,
                CreatedBy = "Admin",
                CreatedDate = DateTime.UtcNow,
                UpdatedBy = "Admin",
                UpdatedDate = DateTime.UtcNow
            };
            dbContext.Organizations.Add(organization);
            dbContext.SaveChanges();

            // Location
            var location = new Location
            {
                Id = 1,
                ResourceID = "LOC001",
                Name = "Columbia Asia",
                Status = true,
                IsDeleted = false,
                CreatedBy = "Admin",
                CreatedDate = DateTime.UtcNow,
                UpdatedBy = "Admin",
                UpdatedDate = DateTime.UtcNow
            };
            dbContext.Locations.Add(location);
            dbContext.SaveChanges();

            // Location Address
            var locationAddress = new LocationAddress
            {
                LocationID = location.Id,
                City = "Pune",
                IsDeleted = false,
                Status = true,
                Use = "Test",
                CreatedBy = "Admin",
                CreatedDate = DateTime.UtcNow,
                UpdatedBy = "Admin",
                UpdatedDate = DateTime.UtcNow
            };
            dbContext.LocationAddresses.Add(locationAddress);

            // Healthcare Service
            var healthcareService = new Domain.V1.Entities.HealthcareService.HealthcareServices
            {
                ID = 1,
                Location = location.ResourceID,
                Name = "Cardio",
                LaymanDescription = " Cardiology - Related to Heart",
                Status = true,
                RecordVersion = Array.Empty<byte>(),
                IsDeleted = false,
                CreatedBy = "Admin",
                CreatedDate = DateTime.UtcNow,
                UpdatedBy = "Admin",
                UpdatedDate = DateTime.UtcNow
            };
            dbContext.HealthcareServices.Add(healthcareService);
            dbContext.SaveChanges();

            // PractitionerRole
            var practitionerRole = new PractitionerRole
            {
                Id = 1,
                UUID = Guid.NewGuid(),
                PractitionerID = practitioner.ResourceID,
                OrganizationID = organization.Id,
                LocationID = location.ResourceID,
                AvailabilityExceptions = "Testdata",
                IsDeleted = false,
                CreatedBy = "Admin",
                CreatedDate = DateTime.UtcNow,
                UpdatedBy = "Admin",
                UpdatedDate = DateTime.UtcNow
            };
            dbContext.PractitionerRoles.Add(practitionerRole);
            dbContext.SaveChanges();

            // PractitionerRoleCode
            var roleCode = new PractitionerRoleCode
            {
                Id = 1,
                PractitionerRoleID = practitionerRole.Id,
                Code = "Doctor",
                IsDeleted = false,
                CreatedBy = "Admin",
                CreatedDate = DateTime.UtcNow,
                UpdatedBy = "Admin",
                UpdatedDate = DateTime.UtcNow
            };
            dbContext.PractitionerRoleCodes.Add(roleCode);

            // PractitionerRoleSpecialty
            var roleSpecialty = new PractitionerRoleSpecialty
            {
                Id = 1,
                PractitionerRoleID = practitionerRole.Id,
                Specialty = "Cardio",
                IsDeleted = false,
                CreatedBy = "Admin",
                CreatedDate = DateTime.UtcNow,
                UpdatedBy = "Admin",
                UpdatedDate = DateTime.UtcNow
            };
            dbContext.PractitionerRoleSpecialty.Add(roleSpecialty);


            dbContext.SaveChanges();
        }

        [Fact]
        public async Task SearchPractitionerByNameAndRole_ShouldReturnEmptyList_WhenNoPractitionersFound()
        {
            // Act
            var result = await _dashboardPostLoginQueryService.SearchPractitionerByNameAndRole("NonExistent", "Doctor");

            // Assert
            result.Should().BeEmpty();
        }

        [Fact]
        public async Task SearchPractitionerByNameAndRole_ShouldReturnCorrectDoctorDetails_WhenPractitionersFound()
        {
            // Act
            var result = await _dashboardPostLoginQueryService.SearchPractitionerByNameAndRole("John", "Doctor");

            // Assert
            result.Should().NotBeEmpty();
            result.Should().HaveCount(1);  // Assuming only one doctor is returned
        }



    }
}
