﻿using Aurora.AdministrationService.API.Enum;
using Aurora.AdministrationService.API.Helper;
using Aurora.AdministrationService.API.Models.RequestModels.BannerClickReport;
using Aurora.AdministrationService.API.Services.Service.BannerClickReports;
using Aurora.AdministrationService.CrossCutting.CommonModels;
using Aurora.AdministrationService.Domain.Old.Entities;
using Aurora.AdministrationService.Infrastructure.IRepository.BannerClickReports;
using AutoMapper;
using FluentAssertions;
using Moq;

namespace Aurora.AdministrationService.Tests.API.Services.BannerClick
{
    public class BannerClickReportServiceTests
    {
        private readonly Mock<IBannerClickReportRepository> _mockBannerClickReportRepository;
        private readonly Mock<IMapper> _mockMapper;
        private readonly Mock<IResponseMessageHelper> _mockResponseMessageHelper;
        private readonly BannerClickReportService _bannerClickReportService;

        public BannerClickReportServiceTests()
        {
            _mockBannerClickReportRepository = new Mock<IBannerClickReportRepository>();
            _mockMapper = new Mock<IMapper>();
            _mockResponseMessageHelper = new Mock<IResponseMessageHelper>();
            _bannerClickReportService = new BannerClickReportService(
                _mockBannerClickReportRepository.Object,
                _mockMapper.Object,
                _mockResponseMessageHelper.Object
            );
        }

        [Fact]
        public async Task AddBannerClickReportAsync_ShouldReturnSuccess_WhenBannerClickReportIsAdded()
        {
            // Arrange
            var request = new CreateBannerClickReportRequest
            {
                BannerId = 123,
            };

            var bannerClickReport = new BannerClickReport();
            _mockMapper.Setup(mapper => mapper.Map<BannerClickReport>(request))
                       .Returns(bannerClickReport);

            _mockBannerClickReportRepository.Setup(repo => repo.AddBannerClickReport(bannerClickReport))
                                             .ReturnsAsync((int)AddNewRecordStatus.Added);

            _mockResponseMessageHelper.Setup(helper => helper.GetSuccessCreateResponseMessage(It.IsAny<string>()))
                                      .Returns(new GenericResponse<string> { IsSuccess = true, Message = ResponseMessage.STATUS_DATA_ADDED });

            // Act
            var result = await _bannerClickReportService.AddBannerClickReportAsync(request);

            // Assert
            result.Should().NotBeNull();
            result.IsSuccess.Should().BeTrue();
            result.Message.Should().Be(ResponseMessage.STATUS_DATA_ADDED);
        }

        [Fact]
        public async Task AddBannerClickReportAsync_ShouldReturnFailure_WhenBannerClickReportCreationFails()
        {
            // Arrange
            var request = new CreateBannerClickReportRequest
            {
                BannerId = 123,
                
            };

            var bannerClickReport = new BannerClickReport();
            _mockMapper.Setup(mapper => mapper.Map<BannerClickReport>(request))
                       .Returns(bannerClickReport);

            _mockBannerClickReportRepository.Setup(repo => repo.AddBannerClickReport(bannerClickReport))
                                             .ReturnsAsync((int)AddNewRecordStatus.NotAdded);

            _mockResponseMessageHelper.Setup(helper => helper.GetRecordCreationFailedResponseMessage(It.IsAny<string>()))
                                      .Returns(new GenericResponse<string> { IsSuccess = false, Message = ResponseMessage.STATUS_DATA_ADD_FAIL });

            // Act
            var result = await _bannerClickReportService.AddBannerClickReportAsync(request);

            // Assert
            result.Should().NotBeNull();
            result.IsSuccess.Should().BeFalse();
            result.Message.Should().Be(ResponseMessage.STATUS_DATA_ADD_FAIL);
        }
    }
}
