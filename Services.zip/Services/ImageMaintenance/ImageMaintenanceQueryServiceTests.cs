﻿using Aurora.AdministrationService.API.Enum.ImageMaintenance;
using Aurora.AdministrationService.API.Models.Dto.ImageMaintenance;
using Aurora.AdministrationService.API.Services.Service.ImageMaintenance;
using Aurora.AdministrationService.CrossCutting.CommonModels;
using FluentAssertions;
using global::Aurora.AdministrationService.Infrastructure;
using Microsoft.EntityFrameworkCore;

namespace Aurora.AdministrationService.Tests.API.Services.ImageMaintenance;

public class ImageMaintenanceQueryServiceTests
{
    private readonly ImageMaintenanceQueryService _service;
    private readonly ReadOnlyDbContext _context;

    public ImageMaintenanceQueryServiceTests()
    {
        var options = new DbContextOptionsBuilder<ReadOnlyDbContext>()
            .UseInMemoryDatabase(databaseName: Guid.NewGuid().ToString())
            .Options;
        _context = new ReadOnlyDbContext(options);
        _service = new ImageMaintenanceQueryService(_context);
    }

    [Fact]
    public async Task FindImageMaintenanceById_Should_Return_Null_When_Not_Found()
    {
        // Act
        var result = await _service.FindImageMaintenanceById(999);

        // Assert
        result.Should().BeNull();
    }

    [Fact]
    public async Task FindImageMaintenanceById_Should_Return_Record_When_Found()
    {
        // Arrange
        var entity = new Domain.V1.Entities.ImageMaintenance
        {
            Id = 1,
            ScreenType = 1,
            Status = true,
            Header = "Test Header",
            Description = "Test Description",
            ImageURL = "http://test.url",
            IsDeleted = false,
            CreatedDate = DateTime.Now,
            UpdatedDate = DateTime.Now,
            UpdatedBy = "user1",
            CreatedBy = "user1"
        };
        _context.ImageMaintenances.Add(entity);
        await _context.SaveChangesAsync();

        // Act
        var result = await _service.FindImageMaintenanceById(1);

        // Assert
        result.Should().NotBeNull();
        result?.Id.Should().Be(1);
    }

    [Fact]
    public async Task GetImageMaintenancesBySearch_Should_Return_Inactive_Records()
    {
        // Arrange
        var searchRequest = new ImageMaintenanceSearchRequest
        {
            SelectedStatus = Enum.GetName(ImageMaintenanceStatusType.InActive)!,
            SelectedScreenTypes = new List<string> { "1" },
            PageNumber = 1,
            PageSize = 10
        };

        _context.ImageMaintenances.Add(new Domain.V1.Entities.ImageMaintenance
        {
            Id = 2,
            ScreenType = 1,
            Status = false,
            Header = "Inactive Header",
            Description = "Inactive Description",
            ImageURL = "http://inactive.url",
            IsDeleted = false,
            CreatedDate = DateTime.Now,
            UpdatedDate = DateTime.Now,
            UpdatedBy = "user1",
            CreatedBy = "user1"
        });
        await _context.SaveChangesAsync();

        // Act
        var result = await _service.GetImageMaintenancesBySearch(searchRequest);

        // Assert
        result.IsSuccess.Should().BeTrue();
        result.Results.Should().NotBeNull();
        result.Results.Should().HaveCount(1);
        result.Results?.First().Header.Should().Be("Inactive Header");
    }


    [Fact]
    public async Task GetImageMaintenancesBySearch_Should_Filter_By_CreatedDate()
    {
        // Arrange
        var createdDate = DateTime.UtcNow.Date;
        var searchRequest = new ImageMaintenanceSearchRequest
        {
            SelectedStatus = "All",
            SelectedCreatedDate = createdDate
        };

        _context.ImageMaintenances.Add(new Domain.V1.Entities.ImageMaintenance
        {
            Id = 3,
            ScreenType = 1,
            Status = true,
            Header = "Date Filter Header",
            Description = "Date Filter Description",
            ImageURL = "http://datefilter.url",
            IsDeleted = false,
            CreatedDate = createdDate,
            UpdatedDate = DateTime.UtcNow,
            UpdatedBy = "user1",
            CreatedBy = "user1"
        });
        await _context.SaveChangesAsync();

        // Act
        var result = await _service.GetImageMaintenancesBySearch(searchRequest);

        // Assert
        result.IsSuccess.Should().BeTrue();
        result.Results.Should().NotBeNull();
        result.Results.Should().HaveCount(1);
        result.Results?.First().Header.Should().Be("Date Filter Header");
    }

    [Fact]
    public async Task GetImageMaintenancesBySearch_Should_Handle_Pagination()
    {
        // Arrange
        for (int i = 1; i <= 15; i++)
        {
            _context.ImageMaintenances.Add(new Domain.V1.Entities.ImageMaintenance
            {
                Id = i,
                ScreenType = 1,
                Status = true,
                Header = $"Header {i}",
                Description = $"Description {i}",
                ImageURL = $"http://image{i}.url",
                IsDeleted = false,
                CreatedDate = DateTime.Now,
                UpdatedDate = DateTime.Now,
                UpdatedBy = "user1",
                CreatedBy = "user1"
            });
        }
        await _context.SaveChangesAsync();

        var searchRequest = new ImageMaintenanceSearchRequest
        {
            SelectedStatus = "Active",
            PageNumber = 2,
            PageSize = 5
        };

        // Act
        var result = await _service.GetImageMaintenancesBySearch(searchRequest);

        // Assert
        result.IsSuccess.Should().BeTrue();
        result.Results.Should().NotBeNull();
        result.Results.Should().HaveCount(5);
        result.CurrentPage.Should().Be(2);
        result.PageSize.Should().Be(5);
    }

    [Fact]
    public async Task GetImageMaintenancesByScreenType_Should_Return_Matching_Records()
    {
        // Arrange
        var screenType = "1"; // Use correct type that matches stored ScreenType
        _context.ImageMaintenances.Add(new Domain.V1.Entities.ImageMaintenance
        {
            Id = 4,
            ScreenType = 1,  // Ensure this matches what we search for
            Status = true,
            Header = "Screen Type Header",
            Description = "Screen Type Description",
            ImageURL = "http://screentype.url",
            IsDeleted = false,
            CreatedDate = DateTime.Now,
            UpdatedDate = DateTime.Now,
            UpdatedBy = "user1",
            CreatedBy = "user1"
        });
        await _context.SaveChangesAsync();

        // Act
        var result = await _service.GetImageMaintenancesByScreenType(new[] { screenType });

        // Assert
        result.Should().NotBeNull();
        result.Should().HaveCount(1);
        result[0].Header.Should().Be("Screen Type Header");
    }


    [Fact]
    public async Task GetImageMaintenancesBySearch_Should_Return_No_Data_When_No_Matches()
    {
        // Arrange
        var searchRequest = new ImageMaintenanceSearchRequest
        {
            SelectedStatus = "Active",
            SelectedScreenTypes = new List<string> { "Home" },
            PageNumber = 1,
            PageSize = 10
        };

        // Act
        var result = await _service.GetImageMaintenancesBySearch(searchRequest);

        // Assert
        Assert.True(result.IsSuccess);
        Assert.Null(result.Results); // Should return no results since the list is empty
        Assert.Equal(ResponseMessage.STATUS_NODATA, result.Message); // Assuming 'STATUS_NODATA' means no data found.
    }     

    [Fact]
    public async Task GetOnBoardImageMaintenanceDetail_Should_Return_NotFound_When_No_Record()
    {
        // Arrange
        var imageMaintenanceId = 999; // Assuming this ID doesn't exist

        // Act
        var result = await _service.GetOnBoardImageMaintenanceDetailAsync(imageMaintenanceId);

        // Assert
        Assert.True(result.IsSuccess);
        Assert.Equal(ResponseStatus.STATUS_NotFound, result.StatusCode); // Status code should be NotFound
        Assert.Equal(ResponseMessage.STATUS_NODATA, result.Message); // Message should indicate no data found
    }

    [Fact]
    public async Task FindImageMaintenanceById_Should_Return_Null_When_NotFound()
    {
        // Act
        var result = await _service.FindImageMaintenanceById(999);

        // Assert
        Assert.Null(result);
    }

    [Fact]
    public async Task FindImageMaintenanceById_Should_Return_Record_WhenFound()
    {
        // Arrange
        var record = new Domain.V1.Entities.ImageMaintenance
        {
            Id = 1,
            ScreenType = 1,
            Status = true,
            Header = "Header 1",
            Description = "Description 1",
            ImageURL = "http://image1.url",
            IsDeleted = false,
            CreatedDate = DateTime.Now,
            UpdatedDate = DateTime.Now,
            UpdatedBy = "user1",
            CreatedBy = "user1"
        };

        _context.ImageMaintenances.Add(record);
        await _context.SaveChangesAsync(); // ✅ Await the async save operation

        // Act
        var result = await _service.FindImageMaintenanceById(1);

        // Assert
        result.Should().NotBeNull();
        result?.Id.Should().Be(1);
    }


    [Fact]
    public async Task GetImageMaintenancesBySearch_Should_Return_No_Data_WhenNoMatches()
    {
        // Arrange
        var searchRequest = new ImageMaintenanceSearchRequest
        {
            SelectedStatus = "Active",
            SelectedScreenTypes = new List<string> { "Home" },
            PageNumber = 1,
            PageSize = 10
        };

        // Act
        var result = await _service.GetImageMaintenancesBySearch(searchRequest);

        // Assert
        Assert.True(result.IsSuccess);
        Assert.Null(result.Results);
    }

    [Fact]
    public async Task GetImageMaintenancesBySearch_Should_Return_List_When_MatchesFound()
    {
        // Arrange
        _context.ImageMaintenances.Add(new Domain.V1.Entities.ImageMaintenance
        {
            Id = 1,
            ScreenType = 1,
            Status = true,
            Header = "Header 1",
            Description = "Description 1",
            ImageURL = "http://image1.url",
            IsDeleted = false,
            CreatedDate = DateTime.Now,
            UpdatedDate = DateTime.Now,
            UpdatedBy = "user1",
            CreatedBy = "user1",
        });
        await _context.SaveChangesAsync();

        var searchRequest = new ImageMaintenanceSearchRequest
        {
            SelectedStatus = "Active",
            SelectedScreenTypes = new List<string> { "1" },
            PageNumber = 1,
            PageSize = 10
        };

        // Act
        var result = await _service.GetImageMaintenancesBySearch(searchRequest);

        // Assert
        result.IsSuccess.Should().BeTrue();
        result.Results.Should().NotBeNull();
        result.Results.Should().HaveCount(1);
    }

    [Fact]
    public async Task GetOnBoardImageMaintenanceDetail_Should_Return_Success_WhenFound()
    {
        // Arrange
        var imageMaintenanceId = 1;
        _context.ImageMaintenances.Add(new Domain.V1.Entities.ImageMaintenance
        {
            Id = imageMaintenanceId,
            ScreenType = 1,
            Status = true,
            Header = "Header 1",
            Description = "Description 1",
            ImageURL = "http://image1.url",
            IsDeleted = false,
            CreatedDate = DateTime.Now,
            UpdatedDate = DateTime.Now,
            UpdatedBy = "user1",
            CreatedBy = "user1"
        });
        await _context.SaveChangesAsync(); // ✅ Await the async save operation

        // Act
        var result = await _service.GetOnBoardImageMaintenanceDetailAsync(imageMaintenanceId);

        // Assert
        result.IsSuccess.Should().BeTrue();
        result.Result.Should().NotBeNull();
        result.Result?.Header.Should().Be("Header 1");
    }


    [Fact]
    public async Task GetImageMaintenancesByScreenType_Should_Return_Empty_When_No_Matches()
    {
        // Arrange
        var selectedScreenTypes = new string[] { "Home" };

        // Act
        var result = await _service.GetImageMaintenancesByScreenType(selectedScreenTypes);

        // Assert
        Assert.Empty(result);
    }


    [Fact]
    public async Task GetImageMaintenancesByScreenType_Should_Return_Results_When_Matches_Found()
    {
        // Arrange
        _context.ImageMaintenances.Add(new Domain.V1.Entities.ImageMaintenance
        {
            Id = 1,
            ScreenType = 1,
            Status = true,
            CreatedBy = "Admin",
            CreatedDate = DateTime.Now,
            Description = "test",
            UpdatedBy = "Admin",
            Header = "Header 1",
            ImageURL = "http://image1.url",
            IsDeleted = false
        });
        await _context.SaveChangesAsync();
        var selectedScreenTypes = new string[] { "1" };

        // Act
        var result = await _service.GetImageMaintenancesByScreenType(selectedScreenTypes);

        // Assert
        Assert.NotEmpty(result);
        Assert.Single(result);
        Assert.Equal("Header 1", result[0].Header);
    }
}
