﻿using Aurora.AdministrationService.API.Models.Dto.ImageMaintenance;
using Aurora.AdministrationService.API.Services.Service.ImageMaintenance;
using Aurora.AdministrationService.CrossCutting.CommonModels;
using Aurora.AdministrationService.Infrastructure;
using AutoMapper;
using Microsoft.AspNetCore.Http;
using Microsoft.EntityFrameworkCore;
using Moq;

namespace Aurora.AdministrationService.Tests.API.Services.ImageMaintenance;

public class ImageMaintenanceCommandServiceTests
{
    private readonly Mock<IMapper> _mapperMock;
    private readonly ReadWriteDbContext _context;
    private readonly ImageMaintenanceCommandService _service;

    public ImageMaintenanceCommandServiceTests()
    {
        // Set up the in-memory database
        var options = new DbContextOptionsBuilder<ReadWriteDbContext>()
                        .UseInMemoryDatabase(Guid.NewGuid().ToString())  // Unique database per test
                        .Options;

        _context = new ReadWriteDbContext(options);
        _mapperMock = new Mock<IMapper>();

        // Initialize the service
        _service = new ImageMaintenanceCommandService(_context, _mapperMock.Object);
    }

    [Fact]
    public async Task CreateImageMaintenance_ShouldReturnSuccess_WhenDataIsValid()
    {
        // Arrange
        var userId = "testuser";
        var newImageMaintenance = new AdministrationService.API.Models.RequestModels.ImageMaintenance.CreateImageMaintenanceRequest
        {
            Description= "description",
            Header= "header",
            ScreenType="0",
        };

        _mapperMock.Setup(m => m.Map<Domain.V1.Entities.ImageMaintenance>(newImageMaintenance))
            .Returns(new Domain.V1.Entities.ImageMaintenance()
            {

                CreatedBy = userId,
                CreatedDate = DateTime.UtcNow,
                IsDeleted = false,
                Status  =true,
                ScreenType=0,
                Header= "header",
                Description= "description",
                Id=34,
                ImageURL="test.com",
                UpdatedBy=userId,
                UpdatedDate=DateTime.UtcNow,
                RecordVersion=Array.Empty<byte>(),

            });

        // Act
        var result = await _service.CreateImageMaintenance(userId, newImageMaintenance);

        // Assert
        Assert.True(result.IsSuccess);
        Assert.False(result.HasError);
        Assert.Equal(StatusCodes.Status200OK.ToString(), result.StatusCode);
        Assert.Equal(ResponseMessage.STATUS_DATA_ADDED, result.Message);
    }

    [Fact]
    public async Task DeleteImageMaintenanceById_ShouldReturnSuccess_WhenImageMaintenanceExists()
    {
        // Arrange
        var userId = "testuser";
        var existingImageMaintenance = new Domain.V1.Entities.ImageMaintenance
        {

            CreatedBy = userId,
            CreatedDate = DateTime.UtcNow,
            IsDeleted = false,
            Status = true,
            ScreenType = 0,
            Header = "header",
            Description = "description",
            Id = 45,
            ImageURL = "test.com",
            UpdatedBy = userId,
            UpdatedDate = DateTime.UtcNow,
            RecordVersion = Array.Empty<byte>(),
        };
        _context.ImageMaintenances.Add(existingImageMaintenance);
        await _context.SaveChangesAsync();

        // Act
        var result = await _service.DeleteImageMaintenanceById(userId, It.IsAny<byte[]>(), existingImageMaintenance);

        // Assert
        Assert.True(result.IsSuccess);
        Assert.False(result.HasError);
        Assert.Equal(StatusCodes.Status200OK.ToString(), result.StatusCode);
        Assert.Equal(ResponseMessage.STATUS_DATA_DELETED, result.Message);
        var deletedEntity = await _context.ImageMaintenances.FindAsync(existingImageMaintenance.Id);
        Assert.True(deletedEntity?.IsDeleted);
    }

    [Fact]
    public async Task UpdateImageMaintenance_ShouldReturnSuccess_WhenDataIsValid()
    {
        // Arrange
        var userId = "testuser";
        var existingImageMaintenance = new Domain.V1.Entities.ImageMaintenance
        {

            CreatedBy = userId,
            CreatedDate = DateTime.UtcNow,
            IsDeleted = false,
            Status = true,
            ScreenType = 0,
            Header = "header",
            Description = "description",
            Id = 346,
            ImageURL = "test.com",
            UpdatedBy = userId,
            UpdatedDate = DateTime.UtcNow,
            RecordVersion = Array.Empty<byte>(),
        };
        _context.ImageMaintenances.Add(existingImageMaintenance);
        await _context.SaveChangesAsync();

        var updateRequest = new UpdateImageMaintainanceRequests
        {
           Description = "description",
           Header = "header",
           ScreenType ="1",
           ImageURL="image.jpg",
           Status=true,
        };

        _mapperMock.Setup(m => m.Map(updateRequest, existingImageMaintenance));

        // Act
        var result = await _service.UpdateImageMaintenance(userId, updateRequest, existingImageMaintenance);

        // Assert
        Assert.True(result.IsSuccess);
        Assert.False(result.HasError);
        Assert.Equal(StatusCodes.Status200OK.ToString(), result.StatusCode);
        Assert.Equal(ResponseMessage.STATUS_DATA_UPDATED, result.Message);
    }

    [Fact]
    public async Task UpdateStatusImageMaintenance_ShouldReturnSuccess_WhenDataIsValid()
    {
        // Arrange
        var userId = "testuser";
        var existingImageMaintenance = new Domain.V1.Entities.ImageMaintenance
        {

            CreatedBy = userId,
            CreatedDate = DateTime.UtcNow,
            IsDeleted = false,
            Status = true,
            ScreenType = 0,
            Header = "header",
            Description = "description",
            Id = 234,
            ImageURL = "test.com",
            UpdatedBy = userId,
            UpdatedDate = DateTime.UtcNow,
            RecordVersion = Array.Empty<byte>(),
        };
        _context.ImageMaintenances.Add(existingImageMaintenance);
        await _context.SaveChangesAsync();

        var updateRequest = new UpdateImageMaintenanceStatusRequests
        {
            Status = true,
            Id= 234
        };

        // Act
        var result = await _service.UpdateStatusImageMaintenance(userId, updateRequest, existingImageMaintenance);

        // Assert
        Assert.True(result.IsSuccess);
        Assert.False(result.HasError);
        Assert.Equal(StatusCodes.Status200OK.ToString(), result.StatusCode);
        Assert.Equal(ResponseMessage.STATUS_DATA_UPDATED, result.Message);
    }
}

