﻿using Aurora.AdministrationService.API.Enum;
using Aurora.AdministrationService.API.Enum.ImageMaintenance;
using Aurora.AdministrationService.API.Helper;
using Aurora.AdministrationService.API.Models.RequestModels.ImageMaintenance;
using Aurora.AdministrationService.API.Models.ResponseModels.ImageMaintenance;
using Aurora.AdministrationService.API.Resources;
using Aurora.AdministrationService.API.Services.Service.Old.ImageMaintenance;
using Aurora.AdministrationService.CrossCutting.CommonModels;
using Aurora.AdministrationService.Domain.Old.Entities;
using Aurora.AdministrationService.Infrastructure.IRepository.ImageMaintenances;
using Aurora.PatientLifeCycleService.Infrastructure.Repository.ImageMaintenances;
using AutoMapper;
using FluentAssertions;
using FluentAssertions.Common;
using Moq;

namespace Aurora.AdministrationService.Tests.API.Services.ImageMaintenance;


/// <summary>
/// Test Cases for  ImageMaintenanceService
/// </summary>
public class ImageMaintenanceServiceTests
{

    private readonly Mock<IImageMaintenanceRepository> _imageMaintenanceRepositoryMock;
    private readonly Mock<ILogoImageMaintenanceRepository> _logoImageMaintenanceRepositoryMock;
    private readonly Mock<IResponseMessageHelper> _responseMessageHelper;
    private readonly Mock<IResponseMessageHelper<ImageMaintenanceDetailDTO>> _listResponseMessageHelperMock;
    private readonly Mock<IResponseMessageHelper<LogoImageMaintenanceDetailDTO>> _logoListResponseMessageHelperMock;
    private readonly ImageMaintenanceService _imageMaintenanceService;
    private readonly Mock<IMapper> _mapperMock;

    /// <summary>
    /// Initializing required services for ImageMaintenanceService
    /// </summary>
    public ImageMaintenanceServiceTests()
    {
        _imageMaintenanceRepositoryMock = new Mock<IImageMaintenanceRepository>();
        _logoImageMaintenanceRepositoryMock = new Mock<ILogoImageMaintenanceRepository>();
        _mapperMock = new Mock<IMapper>();
        _listResponseMessageHelperMock = new Mock<IResponseMessageHelper<ImageMaintenanceDetailDTO>>();
        _logoListResponseMessageHelperMock = new Mock<IResponseMessageHelper<LogoImageMaintenanceDetailDTO>>();
        _responseMessageHelper = new Mock<IResponseMessageHelper>();
        _imageMaintenanceService = new ImageMaintenanceService(_imageMaintenanceRepositoryMock.Object, _logoImageMaintenanceRepositoryMock.Object, _mapperMock.Object, _responseMessageHelper.Object, _listResponseMessageHelperMock.Object, _logoListResponseMessageHelperMock.Object);
    }
    #region GetImageMaintenancesBySearch Unit test

    /// <summary>
    /// Test Case for GetImageMaintenancesBySearch Should return null when it doesnt exists
    /// </summary>
    /// <returns>Should return null when ImageMaintenances data doesnt exists</returns>
    [Fact]
    public async Task GetImageMaintenancesBySearch_ShouldReturnNull_WhenImageMaintenacnenotExists()
    {
        // Arrange
        var searchRequest = MockData.GetImageMaintenanceSerachRequest();
        var imageSourceTypeName = System.Enum.GetName(searchRequest.SelectedImageSourceType);


        _imageMaintenanceRepositoryMock.Setup(repo => repo.GetImageMaintenanceSearch(imageSourceTypeName!, searchRequest.SelectedScreenTypes, searchRequest.SelectedCreatedDate, true, false, false))
            .ReturnsAsync(new List<AdminImageMaintenance>());

        // Act
        var result = await _imageMaintenanceService.GetImageMaintenancesBySearch(searchRequest);

        // Assert
        result.Should().NotBeNull();
        result.IsSuccess.Should().BeTrue();
        result.Results.Should().BeNull();
    }

    /// <summary>
    /// Test Case for GetImageMaintenancesBySearch ShouldReturnSuccessResponse WhenImageMaintenacnesFound
    /// </summary>
    /// <returns>Should return ImageMaintenances information  when ImageMaintenances data  exists</returns>
    [Fact]
    public async Task GetImageMaintenancesBySearch_ShouldReturnSuccessResponse_WhenImageMaintenacnesFound()
    {
        // Arrange
        var searchRequest = MockData.GetImageMaintenanceSerachRequest();
        var imageSourceTypeName = System.Enum.GetName(searchRequest.SelectedImageSourceType);
        var imageresponse = MockData.GetImageMaintenancesData();
        var detailResposne = MockData.GetImageMaintenancesDetailData();

        _imageMaintenanceRepositoryMock.Setup(repo => repo.GetImageMaintenanceSearch(imageSourceTypeName!, searchRequest.SelectedScreenTypes, searchRequest.SelectedCreatedDate, true, false, true))
            .ReturnsAsync(imageresponse);

        _mapperMock.Setup(mapper => mapper.Map<List<ImageMaintenanceDetailDTO>>(imageresponse))
                  .Returns(detailResposne);
        // Act
        var response = await _imageMaintenanceService.GetImageMaintenancesBySearch(searchRequest);

        // Assert
        response.IsSuccess.Should().BeTrue();
        response.HasError.Should().BeFalse();
        response.Results.Should().HaveCount(1);


        _imageMaintenanceRepositoryMock.Verify(repo => repo.GetImageMaintenanceSearch(imageSourceTypeName!, searchRequest.SelectedScreenTypes, searchRequest.SelectedCreatedDate, true, false, true), Times.Once);
    }

    [Fact]
    public async Task GetImageMaintenancesBySearch_ShouldReturnSuccessResponse_WhenImageMaintenacnesFoundButPageSizeEmpty()
    {
        // Arrange
        var searchRequest = MockData.GetImageMaintenanceSerachRequestNoPage();
      
        var imageSourceTypeName = System.Enum.GetName(searchRequest.SelectedImageSourceType);
        var imageresponse = MockData.GetImageMaintenancesData();
        var detailResposne = MockData.GetImageMaintenancesDetailData();

        _imageMaintenanceRepositoryMock.Setup(repo => repo.GetImageMaintenanceSearch(imageSourceTypeName!, searchRequest.SelectedScreenTypes, searchRequest.SelectedCreatedDate, true, false, true))
            .ReturnsAsync(imageresponse);

        _mapperMock.Setup(mapper => mapper.Map<List<ImageMaintenanceDetailDTO>>(imageresponse))
                  .Returns(detailResposne);
        // Act
        var response = await _imageMaintenanceService.GetImageMaintenancesBySearch(searchRequest);

        // Assert
        response.IsSuccess.Should().BeTrue();
        response.HasError.Should().BeFalse();
        response.Results.Should().HaveCount(1);


        _imageMaintenanceRepositoryMock.Verify(repo => repo.GetImageMaintenanceSearch(imageSourceTypeName!, searchRequest.SelectedScreenTypes, searchRequest.SelectedCreatedDate, true, false, true), Times.Once);
    }

    [Theory]
    [InlineData(ImageMaintenanceStatusType.Active, false, true)]
    [InlineData(ImageMaintenanceStatusType.InActive, false, false)]
    public async Task GetImageMaintenancesBySearch_ShouldCallRepository_WithCorrectStatusFilters(ImageMaintenanceStatusType status, bool includeInactive, bool includeActive)
    {
        // Arrange
        var searchRequest = MockData.GetImageMaintenanceSerachRequest();
        searchRequest.SelectedStatus = System.Enum.GetName(status) ?? string.Empty;
        var imageSourceTypeName = System.Enum.GetName(searchRequest.SelectedImageSourceType);
        var imageresponse = MockData.GetImageMaintenancesData();
        var detailResponse = MockData.GetImageMaintenancesDetailData();

        _imageMaintenanceRepositoryMock
            .Setup(repo => repo.GetImageMaintenanceSearch(
                imageSourceTypeName!,
                searchRequest.SelectedScreenTypes,
                searchRequest.SelectedCreatedDate,
                includeInactive,
                includeActive,
                It.IsAny<bool>()))
            .ReturnsAsync(imageresponse);

        _mapperMock.Setup(mapper => mapper.Map<List<ImageMaintenanceDetailDTO>>(imageresponse))
                   .Returns(detailResponse);

        // Act
        var response = await _imageMaintenanceService.GetImageMaintenancesBySearch(searchRequest);

        // Assert
        response.Should().NotBeNull();
        response.IsSuccess.Should().BeTrue();
        response.HasError.Should().BeFalse();
        response.Results.Should().NotBeNull();
        response.Results.Should().HaveCount(detailResponse.Count);

        _imageMaintenanceRepositoryMock.Verify(repo => repo.GetImageMaintenanceSearch(
            imageSourceTypeName!,
            searchRequest.SelectedScreenTypes,
            searchRequest.SelectedCreatedDate,
            includeInactive,
            includeActive,
            It.IsAny<bool>()), Times.Once);
    }

    [Fact]
    public async Task GetImageMaintenancesBySearch_ShouldReturnSuccessResponse_WhenDataIsAvailable()
    {
        // Arrange
        var searchRequest = MockData.GetImageMaintenanceSerachRequest();
        var imageSourceTypeName = Enum.GetName(searchRequest.SelectedImageSourceType);
        var mockData = MockData.GetImageMaintenancesData(); // Mock list of AdminImageMaintenance
        var expectedResult = MockData.GetImageMaintenancesDetailData(); // Mapped DTO list

        _imageMaintenanceRepositoryMock
            .Setup(repo => repo.GetImageMaintenanceSearch(
                imageSourceTypeName!,
                searchRequest.SelectedScreenTypes,
                searchRequest.SelectedCreatedDate,
                It.IsAny<bool>(),
                It.IsAny<bool>(),
                It.IsAny<bool>()))
            .ReturnsAsync(mockData);

        _mapperMock
            .Setup(mapper => mapper.Map<List<ImageMaintenanceDetailDTO>>(mockData))
            .Returns(expectedResult);

        // Act
        var response = await _imageMaintenanceService.GetImageMaintenancesBySearch(searchRequest);

        // Assert
        response.Should().NotBeNull();
        response.IsSuccess.Should().BeTrue();
        response.HasError.Should().BeFalse();
        response.StatusCode.Should().Be(((int)ResponceStatusCode.Success).ToString());
        response.Results.Should().NotBeNull();
        response.Results.Should().BeEquivalentTo(expectedResult);
        response.TotalCount.Should().Be(expectedResult.Count);

        _imageMaintenanceRepositoryMock.Verify(repo => repo.GetImageMaintenanceSearch(
            imageSourceTypeName!,
            searchRequest.SelectedScreenTypes,
            searchRequest.SelectedCreatedDate,
            It.IsAny<bool>(),
            It.IsAny<bool>(),
            It.IsAny<bool>()), Times.Once);
    }

    [Fact]
    public async Task GetImageMaintenancesBySearch_ShouldReturnErrorResponse_WhenExceptionOccurs()
    {
        // Arrange
        var searchRequest = MockData.GetImageMaintenanceSerachRequest();

        _imageMaintenanceRepositoryMock
            .Setup(repo => repo.GetImageMaintenanceSearch(
                It.IsAny<string>(),
                It.IsAny<List<string>>(),
                It.IsAny<DateTime?>(),
                It.IsAny<bool>(),
                It.IsAny<bool>(),
                It.IsAny<bool>()))
            .ThrowsAsync(new Exception("Database error"));

        // Act
        var response = await _imageMaintenanceService.GetImageMaintenancesBySearch(searchRequest);

        // Assert
        response.Should().NotBeNull();
        response.IsSuccess.Should().BeFalse();
        response.HasError.Should().BeTrue();
        response.StatusCode.Should().Be(((int)ResponceStatusCode.Errored).ToString());
        response.Results.Should().BeNull();
        response.Message.Should().Be(Resource.LogMessage);
    }

    #endregion


    #region Logo Add 
    [Fact]
    public async Task AddNewLogoImageMaintenanceAsync_ValidUserId_ReturnsSuccessResponse()
    {
        // Arrange
        string userId = "123";
        var newImageMaintenance = new CreateLogoImageMaintenanceRequest{ OrganizationId = 1 };
        var imageMaintenance = new Domain.Old.Entities.AdminLogoImageMaintenance();
        _mapperMock.Setup(m => m.Map(newImageMaintenance, imageMaintenance));
        _logoImageMaintenanceRepositoryMock.Setup(r => r.AddLogoImageAsync(It.IsAny<AdminLogoImageMaintenance>())).ReturnsAsync((int)AddNewRecordStatus.Added);
        _responseMessageHelper.Setup(r => r.GetSuccessCreateResponseMessage(It.IsAny<string>())).Returns(new GenericResponse<string> { IsSuccess = true });

        // Act
        var result = await _imageMaintenanceService.AddNewLogoImageMaintenanceAsync(userId, newImageMaintenance);

        // Assert
        result.IsSuccess.Should().BeTrue();
        _mapperMock.Verify(m => m.Map(newImageMaintenance, It.IsAny<AdminLogoImageMaintenance>()), Times.Once);
        _logoImageMaintenanceRepositoryMock.Verify(r => r.AddLogoImageAsync(It.IsAny<AdminLogoImageMaintenance>()), Times.Once);
        _responseMessageHelper.Verify(r => r.GetSuccessCreateResponseMessage(It.IsAny<string>()), Times.Once);
    }

    [Fact]
    public async Task AddNewLogoImageMaintenanceAsync_InvalidUserId_ReturnsFailedResponse()
    {
        // Arrange
        string userId = "invalid";
        var newImageMaintenance = new CreateLogoImageMaintenanceRequest{ OrganizationId = 1 };
        var imageMaintenance = new Domain.Old.Entities.AdminLogoImageMaintenance();
        _mapperMock.Setup(m => m.Map(newImageMaintenance, imageMaintenance));
        _logoImageMaintenanceRepositoryMock.Setup(r => r.AddLogoImageAsync(It.IsAny<AdminLogoImageMaintenance>())).ReturnsAsync((int)AddNewRecordStatus.NotAdded);
        _responseMessageHelper.Setup(r => r.GetRecordCreationFailedResponseMessage(It.IsAny<string>())).Returns(new GenericResponse<string> { IsSuccess = false });

        // Act
        var result = await _imageMaintenanceService.AddNewLogoImageMaintenanceAsync(userId, newImageMaintenance);

        // Assert
        result.IsSuccess.Should().BeFalse();
        _mapperMock.Verify(m => m.Map(newImageMaintenance, It.IsAny<AdminLogoImageMaintenance>()), Times.Once);
        _logoImageMaintenanceRepositoryMock.Verify(r => r.AddLogoImageAsync(It.IsAny<AdminLogoImageMaintenance>()), Times.Once);
        _responseMessageHelper.Verify(r => r.GetRecordCreationFailedResponseMessage(""), Times.Once);
    }

    [Fact]
    public async Task AddNewLogoImageMaintenanceAsync_EmptyUserId_ReturnsFailedResponse()
    {
        // Arrange
        string userId = "";
        var newImageMaintenance = new CreateLogoImageMaintenanceRequest { OrganizationId = 1};
        var imageMaintenance = new Domain.Old.Entities.AdminLogoImageMaintenance();
        _mapperMock.Setup(m => m.Map(newImageMaintenance, imageMaintenance));
        _logoImageMaintenanceRepositoryMock.Setup(r => r.AddLogoImageAsync(It.IsAny<AdminLogoImageMaintenance>())).ReturnsAsync((int)AddNewRecordStatus.NotAdded);
        _responseMessageHelper.Setup(r => r.GetRecordCreationFailedResponseMessage("")).Returns(new GenericResponse<string> { IsSuccess = false });

        // Act
        var result = await _imageMaintenanceService.AddNewLogoImageMaintenanceAsync(userId, newImageMaintenance);

        // Assert
        result.IsSuccess.Should().BeFalse();
        _mapperMock.Verify(m => m.Map(newImageMaintenance, It.IsAny<AdminLogoImageMaintenance>()), Times.Once);
        _logoImageMaintenanceRepositoryMock.Verify(r => r.AddLogoImageAsync(It.IsAny<AdminLogoImageMaintenance>()), Times.Once);
        _responseMessageHelper.Verify(r => r.GetRecordCreationFailedResponseMessage(""), Times.Once);
    }

    [Fact]
    public async Task AddNewLogoImageMaintenanceAsync_NullUserId_ReturnsFailedResponse()
    {
        // Arrange
        string userId = null!;
        var newImageMaintenance = new CreateLogoImageMaintenanceRequest { OrganizationId = 1 };
        var imageMaintenance = new Domain.Old.Entities.AdminLogoImageMaintenance();
        _mapperMock.Setup(m => m.Map(newImageMaintenance, imageMaintenance));
        _logoImageMaintenanceRepositoryMock.Setup(r => r.AddLogoImageAsync(It.IsAny<AdminLogoImageMaintenance>())).ReturnsAsync((int)AddNewRecordStatus.NotAdded);
        _responseMessageHelper.Setup(r => r.GetRecordCreationFailedResponseMessage("")).Returns(new GenericResponse<string> { IsSuccess = false });

        // Act
        var result = await _imageMaintenanceService.AddNewLogoImageMaintenanceAsync(userId, newImageMaintenance);

        // Assert
        result.IsSuccess.Should().BeFalse();
        _mapperMock.Verify(m => m.Map(newImageMaintenance, It.IsAny<AdminLogoImageMaintenance>()), Times.Once);
        _logoImageMaintenanceRepositoryMock.Verify(r => r.AddLogoImageAsync(It.IsAny<AdminLogoImageMaintenance>()), Times.Once);
        _responseMessageHelper.Verify(r => r.GetRecordCreationFailedResponseMessage(""), Times.Once);
    }
    #endregion

    #region UpdateLogoImageMaintenanceStatusAsync
    [Fact]
    public async Task UpdateLogoImageMaintenanceStatusAsync_RecordNotFound_ReturnsNotFoundResponse()
    {
        // Arrange
        var userId = "1";
        var request = new UpdateLogoImageMaintenanceStatusRequest { Id = 1, Status = true };
        _logoImageMaintenanceRepositoryMock.Setup(repo => repo.GetLogoImageByIdAsync(request.Id)).ReturnsAsync((AdminLogoImageMaintenance)null!);
        _responseMessageHelper.Setup(helper => helper.GetRecordNotFoundResponseMessage("")).Returns(new GenericResponse<string> { Message = "Record not found" });

        // Act
        var result = await _imageMaintenanceService.UpdateLogoImageMaintenanceStatusAsync(userId, request);

        // Assert
        result.Message.Should().Be( "Record not found");
    }

    [Fact]
    public async Task UpdateLogoImageMaintenanceStatusAsync_InvalidUserId_ReturnsSuccessResponse()
    {
        // Arrange
        var userId = "invalid";
        var request = new UpdateLogoImageMaintenanceStatusRequest { Id = 1, Status = true };
        var existingImageMaintenance = new AdminLogoImageMaintenance();
        _logoImageMaintenanceRepositoryMock.Setup(repo => repo.GetLogoImageByIdAsync(request.Id)).ReturnsAsync(existingImageMaintenance);
        _logoImageMaintenanceRepositoryMock.Setup(repo => repo.UpdateLogoImageStatusAsync(request.Id, request.Status)).ReturnsAsync((int)UpdateRecordStatus.Updated);
        _responseMessageHelper.Setup(helper => helper.GetSuccessUpdationResponseMessage("")).Returns(new GenericResponse<string> { Message = "Success" });

        // Act
        var result = await _imageMaintenanceService.UpdateLogoImageMaintenanceStatusAsync(userId, request);

        // Assert
        result.Message.Should().Be("Success");
        existingImageMaintenance.UpdatedBy.Should().Be(0);
    }

    [Fact]
    public async Task UpdateLogoImageMaintenanceStatusAsync_ValidUserId_ReturnsSuccessResponse()
    {
        // Arrange
        var userId = "1";
        var request = new UpdateLogoImageMaintenanceStatusRequest { Id = 1, Status = true };
        var existingImageMaintenance = new AdminLogoImageMaintenance();
        _logoImageMaintenanceRepositoryMock.Setup(repo => repo.GetLogoImageByIdAsync(request.Id)).ReturnsAsync(existingImageMaintenance);
        _logoImageMaintenanceRepositoryMock.Setup(repo => repo.UpdateLogoImageStatusAsync(request.Id, request.Status)).ReturnsAsync((int)UpdateRecordStatus.Updated);
        _responseMessageHelper.Setup(helper => helper.GetSuccessUpdationResponseMessage("")).Returns(new GenericResponse<string> { Message = "Success" });

        // Act
        var result = await _imageMaintenanceService.UpdateLogoImageMaintenanceStatusAsync(userId, request);

        // Assert
        result.Message.Should().Be("Success");
        existingImageMaintenance.UpdatedBy.Should().Be(1);
    }

    [Fact]
    public async Task UpdateLogoImageMaintenanceStatusAsync_UpdateFailed_ReturnsFailedResponse()
    {
        // Arrange
        var userId = "1";
        var request = new UpdateLogoImageMaintenanceStatusRequest { Id = 1, Status = true };
        var existingImageMaintenance = new AdminLogoImageMaintenance();
        _logoImageMaintenanceRepositoryMock.Setup(repo => repo.GetLogoImageByIdAsync(request.Id)).ReturnsAsync(existingImageMaintenance);
        _logoImageMaintenanceRepositoryMock.Setup(repo => repo.UpdateLogoImageStatusAsync(request.Id, request.Status)).ReturnsAsync((int)UpdateRecordStatus.NotUpdated);
        _responseMessageHelper.Setup(helper => helper.GetRecordUpdationFailedResponseMessage("")).Returns(new GenericResponse<string> { Message = "Update failed" });

        // Act
        var result = await _imageMaintenanceService.UpdateLogoImageMaintenanceStatusAsync(userId, request);

        // Assert
        result.Message.Should().Be("Update failed");
    }

    [Fact]
    public async Task UpdateLogoImageMaintenanceAsync_RecordNotFound_ReturnsNotFoundResponse()
    {
        // Arrange
        int imageMaintenanceId = 1;
        string userId = "123";
        var imageMaintenance = new UpdateLogoImageMaintenanceRequest { OrganizationId = 1 };
        _logoImageMaintenanceRepositoryMock.Setup(repo => repo.GetLogoImageByIdAsync(imageMaintenanceId)).ReturnsAsync(It.IsAny<AdminLogoImageMaintenance>());
        _responseMessageHelper.Setup(helper => helper.GetRecordNotFoundResponseMessage("")).Returns(new GenericResponse<string> { Message = "Not Found" });

        // Act
        var result = await _imageMaintenanceService.UpdateLogoImageMaintenanceAsync(imageMaintenanceId, userId, imageMaintenance);

        // Assert
        result.Message.Should().Be("Not Found");
    }

    [Fact]
    public async Task UpdateLogoImageMaintenanceAsync_SuccessfulUpdate_ReturnsSuccessResponse()
    {
        // Arrange
        int imageMaintenanceId = 1;
        string userId = "123";
        var imageMaintenance = new UpdateLogoImageMaintenanceRequest { OrganizationId = 1 };
        var existingImageMaintenance = new AdminLogoImageMaintenance();
        _logoImageMaintenanceRepositoryMock.Setup(repo => repo.GetLogoImageByIdAsync(imageMaintenanceId)).ReturnsAsync(existingImageMaintenance);
        _logoImageMaintenanceRepositoryMock.Setup(repo => repo.UpdateLogoImageAsync(existingImageMaintenance)).ReturnsAsync((int)UpdateRecordStatus.Updated);
        _responseMessageHelper.Setup(helper => helper.GetSuccessUpdationResponseMessage("")).Returns(new GenericResponse<string> { Message = "Success" });

        // Act
        var result = await _imageMaintenanceService.UpdateLogoImageMaintenanceAsync(imageMaintenanceId, userId, imageMaintenance);

        // Assert
        result.Message.Should().Be("Success");
    }

    [Fact]
    public async Task UpdateLogoImageMaintenanceAsync_UpdateFailed_ReturnsFailedResponse()
    {
        // Arrange
        int imageMaintenanceId = 1;
        string userId = "123";
        var imageMaintenance = new UpdateLogoImageMaintenanceRequest { OrganizationId = 1 };
        var existingImageMaintenance = new AdminLogoImageMaintenance();
        _logoImageMaintenanceRepositoryMock.Setup(repo => repo.GetLogoImageByIdAsync(imageMaintenanceId)).ReturnsAsync(existingImageMaintenance);
        _logoImageMaintenanceRepositoryMock.Setup(repo => repo.UpdateLogoImageAsync(existingImageMaintenance)).ReturnsAsync((int)UpdateRecordStatus.NotUpdated);
        _responseMessageHelper.Setup(helper => helper.GetRecordUpdationFailedResponseMessage("")).Returns(new GenericResponse<string> { Message = "Failed" });

        // Act
        var result = await _imageMaintenanceService.UpdateLogoImageMaintenanceAsync(imageMaintenanceId, userId, imageMaintenance);

        // Assert
        result.Message.Should().Be("Failed");
    }

    [Fact]
    public async Task UpdateLogoImageMaintenanceAsync_ExceptionThrown_ReturnsErrorResponse()
    {
        // Arrange
        int imageMaintenanceId = 1;
        string userId = "123";
        var imageMaintenance = new UpdateLogoImageMaintenanceRequest { OrganizationId = 1 };
        _logoImageMaintenanceRepositoryMock.Setup(repo => repo.GetLogoImageByIdAsync(imageMaintenanceId)).ThrowsAsync(new Exception());
        _responseMessageHelper.Setup(helper => helper.GetInternalServerErrorResponseMessage("")).Returns(new GenericResponse<string> { Message = "Error" });

        // Act
        var result = await _imageMaintenanceService.UpdateLogoImageMaintenanceAsync(imageMaintenanceId, userId, imageMaintenance);

        // Assert
        result.Message.Should().Be("Error");
    }

    [Fact]
    public async Task DeleteLogoImageMaintenanceAsync_SuccessfulDeletion_ReturnsSuccessResponse()
    {
        // Arrange
        int imageMaintenanceId = 1;
        _logoImageMaintenanceRepositoryMock.Setup(repo => repo.DeleteLogoImageAsync(imageMaintenanceId)).ReturnsAsync((int)DeleteRecordStatus.Deleted);
        _responseMessageHelper.Setup(helper => helper.GetSuccessDeletionResponseMessage("")).Returns(new GenericResponse<string> { Message = "Success" });

        // Act
        var result = await _imageMaintenanceService.DeleteLogoImageMaintenanceAsync(imageMaintenanceId);

        // Assert
        result.Message.Should().Be("Success");
    }

    [Fact]
    public async Task DeleteLogoImageMaintenanceAsync_DeletionFailed_ReturnsFailedResponse()
    {
        // Arrange
        int imageMaintenanceId = 1;
        _logoImageMaintenanceRepositoryMock.Setup(repo => repo.DeleteLogoImageAsync(imageMaintenanceId)).ReturnsAsync((int)DeleteRecordStatus.NotDeleted);
        _responseMessageHelper.Setup(helper => helper.GetRecordDeletionFailedResponseMessage("")).Returns(new GenericResponse<string> { Message = "Failed" });

        // Act
        var result = await _imageMaintenanceService.DeleteLogoImageMaintenanceAsync(imageMaintenanceId);

        // Assert
        result.Message.Should().Be("Failed");
    }

    [Fact]
    public async Task DeleteLogoImageMaintenanceAsync_ExceptionThrown_ReturnsErrorResponse()
    {
        // Arrange
        int imageMaintenanceId = 1;
        _logoImageMaintenanceRepositoryMock.Setup(repo => repo.DeleteLogoImageAsync(imageMaintenanceId)).ThrowsAsync(new Exception());
        _responseMessageHelper.Setup(helper => helper.GetInternalServerErrorResponseMessage("")).Returns(new GenericResponse<string> { Message = "Error" });

        // Act
        var result = await _imageMaintenanceService.DeleteLogoImageMaintenanceAsync(imageMaintenanceId);

        // Assert
        result.Message.Should().Be("Error");
    }

    [Fact]
    public async Task GetLogoImageMaintenanceDetailAsync_RecordNotFound_ReturnsNotFoundResponse()
    {
        // Arrange
        int imageMaintenanceId = 1;
        _logoImageMaintenanceRepositoryMock.Setup(repo => repo.GetLogoImageByIdAsync(imageMaintenanceId)).ReturnsAsync(It.IsAny<AdminLogoImageMaintenance>());
        _logoListResponseMessageHelperMock.Setup(helper => helper.GetRecordNotFoundResponseMessage("")).Returns(new GenericResponse<LogoImageMaintenanceDetailDTO> { Message = "Not Found" });

        // Act
        var result = await _imageMaintenanceService.GetLogoImageMaintenanceDetailAsync(imageMaintenanceId);

        // Assert
        result.Message.Should().Be("Not Found");
    }

    [Fact]
    public async Task GetLogoImageMaintenanceDetailAsync_SuccessfulRetrieval_ReturnsSuccessResponse()
    {
        // Arrange
        int imageMaintenanceId = 1;
        var imageMaintenance = new AdminLogoImageMaintenance();
        var imageMaintenanceDetail = new LogoImageMaintenanceDetailDTO();
        _logoImageMaintenanceRepositoryMock.Setup(repo => repo.GetLogoImageByIdAsync(imageMaintenanceId)).ReturnsAsync(imageMaintenance);
        _mapperMock.Setup(mapper => mapper.Map<LogoImageMaintenanceDetailDTO>(imageMaintenance)).Returns(imageMaintenanceDetail);
        _logoListResponseMessageHelperMock.Setup(helper => helper.GetRecordDetailSuccessResponseMessage(imageMaintenanceDetail,"")).Returns(new GenericResponse<LogoImageMaintenanceDetailDTO> { Message = "Success" });

        // Act
        var result = await _imageMaintenanceService.GetLogoImageMaintenanceDetailAsync(imageMaintenanceId);

        // Assert
        result.Message.Should().Be("Success");
    }

    [Fact]
    public async Task GetLogoImageMaintenanceDetailAsync_ExceptionThrown_ReturnsErrorResponse()
    {
        // Arrange
        int imageMaintenanceId = 1;
        _logoImageMaintenanceRepositoryMock.Setup(repo => repo.GetLogoImageByIdAsync(imageMaintenanceId)).ThrowsAsync(new Exception());
        _logoListResponseMessageHelperMock.Setup(helper => helper.GetRecordDetailErrorResponseMessage("")).Returns(new GenericResponse<LogoImageMaintenanceDetailDTO> { Message = "Error" });

        // Act
        var result = await _imageMaintenanceService.GetLogoImageMaintenanceDetailAsync(imageMaintenanceId);

        // Assert
        result.Message.Should().Be("Error");
    }
    #endregion
}
