﻿using Aurora.AdministrationService.API.Enum.ImageMaintenance;
using Aurora.AdministrationService.API.Models.RequestModels.ImageMaintenance;
using Aurora.AdministrationService.API.Models.ResponseModels.ImageMaintenance;
using Aurora.AdministrationService.Domain.Old.Entities;

namespace Aurora.AdministrationService.Tests.API.Services.ImageMaintenance
{
    /// <summary>
    /// MockData class for Image Maintenance Endpoints.
    /// </summary>
    public static class MockData
    {
        /// <summary>
        /// Get ImageMaintenance Search Request
        /// </summary>
        /// <returns>Mocked Admin Image Maintenance Search request</returns>
        public static ImageMaintenanceSearchRequest GetImageMaintenanceSerachRequest()
        {
            return new ImageMaintenanceSearchRequest()
            {
                PageNumber = 1,
                PageSize = 100,
                SelectedImageSourceType = ImageMaintenanceSourceType.All,
            };
        }
        public static ImageMaintenanceSearchRequest GetImageMaintenanceSerachRequestNoPage()
        {
            return new ImageMaintenanceSearchRequest()
            {
           
                SelectedImageSourceType = ImageMaintenanceSourceType.All,
            };
        }
        /// <summary>
        /// Get ImageMaintenance Data
        /// </summary>
        /// <returns>Mocked Admin Image Maintenance Info</returns>
        public static List<AdminImageMaintenance> GetImageMaintenancesData()
        {
            return new List<AdminImageMaintenance>
            {
                new AdminImageMaintenance{Id=25,ScreenType="onboarding",Header="header",ImageUrl="https://www.google.com/images/branding/googlelogo/2x/googlelogo_color_272x92dp.png",Description="eeettt",IsActive=true,CreatedAt=DateTime.Now,CreatedBy=1,UpdatedAt=DateTime.Now,UpdatedBy=1, CreatedByNavigation = new AdminUser
        {
            FirstName = "John",
            LastName = "Doe"
        } }
            };
        }

        /// <summary>
        /// Get ImageMaintenances DetailData
        /// </summary>
        /// <returns>Mocked Admin Image Maintenance Detailed Info</returns>
        public static List<ImageMaintenanceDetailDTO> GetImageMaintenancesDetailData()
        {
            return new List<ImageMaintenanceDetailDTO>
            {
                new ImageMaintenanceDetailDTO{Id=25,ScreenType="onboarding",Header="header",ImageURL="https://www.google.com/images/branding/googlelogo/2x/googlelogo_color_272x92dp.png",Description="eeettt",IsActive=true,CreatedAt=DateTime.Now,UpdatedAt=DateTime.Now,UpdatedBy=1 }
            };
        }

        /// <summary>
        /// Create Admin Image 
        /// </summary>
        /// <returns>Mocked Admin Image Maintenance Request</returns>
        public static AdminImageMaintenance CreateAdminImage()
        {
            return new AdminImageMaintenance { Id = 25, ScreenType = "onboarding", Header = "header", ImageUrl = "https://www.google.com/images/branding/googlelogo/2x/googlelogo_color_272x92dp.png", Description = "eeettt", IsActive = true, CreatedAt = DateTime.Now, CreatedBy = 1, UpdatedAt = DateTime.Now, UpdatedBy = 2, ImageName = "Test", ImageType = "OnBoard" };
        }

        /// <summary>
        /// Create Admin User
        /// </summary>
        /// <returns>Mocked Create Admin to utilize in adding image</returns>
        public static AdminUser CreateAdminUser()
        {
            return new AdminUser { AdminId = 2, Username = "admin", Password = "P@ssw0rd1", Email = "admin@example.com", FirstName = "test", LastName = "name", PhoneNumber = "123-456-7890", Role = "Administrator", Active = true, DateCreated = DateTime.Now, Status = true };
        }
    }
}
