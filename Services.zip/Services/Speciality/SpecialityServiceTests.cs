﻿using Aurora.AdministrationService.API.Enum;
using Aurora.AdministrationService.API.Services.Service.Old.Specialities;
using Aurora.AdministrationService.Domain.Old.Entities;
using Aurora.AdministrationService.Infrastructure.IRepository;
using AutoMapper;
using FluentAssertions;
using Moq;

namespace Aurora.AdministrationService.Tests.API.Services.V1.AdminSpecialityTests
{
    public class SpecialityServiceTests
    {
        private readonly Mock<IDoctorRepository> _doctorRepositoryMock;
        private readonly SpecialityServices _specialityService;
        private readonly Mock<IMapper> _mapperMock;

        public SpecialityServiceTests()
        {
            _doctorRepositoryMock = new Mock<IDoctorRepository>();
            _mapperMock = new Mock<IMapper>();
            _specialityService = new SpecialityServices(_doctorRepositoryMock.Object, _mapperMock.Object);
        }

        [Fact]
        public async Task GetAllSpecialities_ShouldReturnErrorResponse_WhenExceptionThrown()
        {
            // Arrange
            _doctorRepositoryMock.Setup(repo => repo.GetSpeiciality()).ThrowsAsync(new Exception("error"));

            // Act
            var response = await _specialityService.GetSpeiciality();

            // Assert
            response.IsSuccess.Should().BeFalse();
            response.HasError.Should().BeTrue();
            response.Results.Should().BeNull();
            response.StatusCode.Should().Be(((int)ResponceStatusCode.InternalServerError).ToString());
        }

        [Fact]
        public async Task GetAllSpecialities_ShouldReturnSucessResponse()
        {
            // Arrange
            var specialityList = new List<AdminSpeciality>();

            _doctorRepositoryMock.Setup(repo => repo.GetSpeiciality()).ReturnsAsync(specialityList);

            // Act
            var response = await _specialityService.GetSpeiciality();

            // Assert
            response.IsSuccess.Should().BeTrue();
            response.HasError.Should().BeFalse();
            response.StatusCode.Should().Be(((int)ResponceStatusCode.Success).ToString());

        }
    }
}
