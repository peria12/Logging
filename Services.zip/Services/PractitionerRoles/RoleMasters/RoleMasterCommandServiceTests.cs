﻿using Aurora.AdministrationService.API.Models.Dto.PractitionerRoles.RoleMasters;
using Aurora.AdministrationService.API.Services.Service.PractitionerRoles;
using Aurora.AdministrationService.Domain.V1.Entities.PractitionerRoles;
using Aurora.AdministrationService.Infrastructure;
using AutoMapper;
using Microsoft.EntityFrameworkCore;
using Moq;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Aurora.AdministrationService.Tests.API.Services.PractitionerRoles.RoleMasters
{
    public class RoleMasterCommandServiceTests
    {
        private readonly Mock<ReadWriteDbContext> _readWriteDbContextMock;
        private readonly Mock<ReadOnlyDbContext> _readOnlyDbContextMock;
        private readonly Mock<IMapper> _mapperMock;
        private RoleMasterCommandService _roleMasterCommandService;
        private readonly Mock<RoleMasterQueryService> _roleMasterQueryService;

        public RoleMasterCommandServiceTests()
        {
            // Initialize the mocks
            _mapperMock = new Mock<IMapper>();
            _readWriteDbContextMock = new Mock<ReadWriteDbContext>();
            _readOnlyDbContextMock = new Mock<ReadOnlyDbContext>();
            _roleMasterQueryService = new Mock<RoleMasterQueryService>();


            // Setup in-memory ready only database for testing
            DbContextOptions<ReadWriteDbContext> options = new DbContextOptionsBuilder<ReadWriteDbContext>()
              .UseInMemoryDatabase(databaseName: "AdminRoleMasterTestDB").Options;

            _readWriteDbContextMock = new(options);

            // Initialize the service being tested
            _roleMasterCommandService = new RoleMasterCommandService(_readWriteDbContextMock.Object, _mapperMock.Object);
        }

        [Fact]
        public async Task CreateRoleMasterAsync_ShouldReturnTrue_WhenRoleMasterIsCreatedSuccessfully()
        {
            // Arrange
            var newRoleMaster = new CreateRoleMasterRequest
            {
                Id = 1,
                Code = "test",
                Definition = "Definition",
                Source = "test",
            };

            // Mock AutoMapper to return a RoleMaster entity
            var roleMasterId = 1;
            var roleMasterEntity = new RoleMaster
            {
                Id = roleMasterId,
                Code = "test",
                Definition = "Definition",
                Source = "test",
                IsDeleted = false,
                CreatedBy = "Admin",
                CreatedDate = DateTime.UtcNow,
                UpdatedBy = "Admin",  // Adding the missing property
                UpdatedDate = DateTime.UtcNow,// Assuming UpdatedDate is required as well
            };


            // Mock AutoMapper to return the RoleMaster entity
            _mapperMock.Setup(m => m.Map<RoleMaster>(newRoleMaster)).Returns(roleMasterEntity);

            // Mock DbContext to simulate saving the entity without actually hitting the database
            _readWriteDbContextMock.Setup(db => db.RoleMasters.Add(It.IsAny<RoleMaster>()));

            // Act
            var result = await _roleMasterCommandService.CreateRoleMasterAsync(newRoleMaster);

            // Assert
            Assert.True(result);
            _readWriteDbContextMock.Verify(db => db.RoleMasters.Add(It.Is<RoleMaster>(l => l.Source == "test")), Times.Once);
        }


        [Fact]
        public async Task CreateRoleMasterAsync_ShouldReturnFalse_WhenExceptionOccurs()
        {
            // Arrange
            var newRoleMaster = new CreateRoleMasterRequest
            {
                Id = 1,
                Code = "test",
                Definition = "Definition",
                Source = "test",
            };

            // Mock AutoMapper to return a RoleMaster entity
            var roleMasterId = 1;
            var roleMasterEntity = new RoleMaster
            {
                Id = roleMasterId,
                Code = "test",
                Definition = "Definition",
                Source = "test",
                IsDeleted = false,
                CreatedBy = "Admin",
                CreatedDate = DateTime.UtcNow,
                UpdatedBy = "Admin",  // Adding the missing property
                UpdatedDate = DateTime.UtcNow,// Assuming UpdatedDate is required as well
            };

            //Setup
            _mapperMock.Setup(m => m.Map<RoleMaster>(newRoleMaster)).Returns(roleMasterEntity);

            // Act
            var result = await _roleMasterCommandService.CreateRoleMasterAsync(newRoleMaster);

            // Assert
            Assert.False(result);
        }
        [Fact]
        public async Task Test_UpdateRoleMaster_Returns_Success()
        {
            //Arrange
            DbContextOptions<ReadWriteDbContext> options = new DbContextOptionsBuilder<ReadWriteDbContext>()
               .UseInMemoryDatabase(databaseName: "UpdateRoleMaster").Options;

            byte[] concurrencyToken = new byte[8] { byte.MinValue, byte.MinValue, byte.MinValue, byte.MinValue, byte.MinValue, byte.MinValue, byte.MinValue, byte.MaxValue };
            var roleMaster = new RoleMaster
            {
                Id = 1,
                Code = "test",
                Definition = "Definition",
                Source = "test",
                IsDeleted = false,
                CreatedBy = "Admin",
                CreatedDate = DateTime.UtcNow,
                UpdatedBy = "Admin",  // Adding the missing property
                UpdatedDate = DateTime.UtcNow,// Assuming UpdatedDate is required as well
                RecordVersion = concurrencyToken
            };


            //Arrange
            using ReadWriteDbContext dbContext = new(options);
            dbContext.RoleMasters.Add(roleMaster);
            await dbContext.SaveChangesAsync();


            UpdateRoleMasterRequest updateModel = new UpdateRoleMasterRequest
            {
                Id = 1,
                Code = "test",
                Definition = "Definition",
                Source = "test",
                RecordVersion = concurrencyToken
            };

            //updateModel.ID = 1;
            updateModel.RecordVersion = roleMaster.RecordVersion;

            _roleMasterCommandService = new RoleMasterCommandService(dbContext, _mapperMock.Object);

            // Act
            bool result = await _roleMasterCommandService.UpdateRoleMasterAsync(updateModel, roleMaster);

            Assert.True(result);
        }
        [Fact]
        public async Task Test_DeleteRoleMaster_Returns_Success()
        {
            //Arrange
            DbContextOptions<ReadWriteDbContext> options = new DbContextOptionsBuilder<ReadWriteDbContext>()
               .UseInMemoryDatabase(databaseName: "DeleteRoleMaster").Options;

            byte[] concurrencyToken = new byte[8] { byte.MinValue, byte.MinValue, byte.MinValue, byte.MinValue, byte.MinValue, byte.MinValue, byte.MinValue, byte.MaxValue };
            var roleMaster = new RoleMaster
            {
                Id = 1,
                Code = "test",
                Definition = "Definition",
                Source = "test",
                IsDeleted = false,
                CreatedBy = "Admin",
                CreatedDate = DateTime.UtcNow,
                UpdatedBy = "Admin",  // Adding the missing property
                UpdatedDate = DateTime.UtcNow,// Assuming UpdatedDate is required as well
                RecordVersion = concurrencyToken
            };



            //Arrange
            using ReadWriteDbContext dbContext = new(options);
            dbContext.RoleMasters.Add(roleMaster);
            await dbContext.SaveChangesAsync();

            _roleMasterCommandService = new RoleMasterCommandService(dbContext, _mapperMock.Object);

            // Act
            bool result = await _roleMasterCommandService.DeleteRoleMasterByIdAsync(concurrencyToken, roleMaster);

            Assert.True(result);
        }
    }
}
