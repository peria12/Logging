﻿using Aurora.AdministrationService.API.Models.Dto.PractitionerRoles.RoleMasters;
using Aurora.AdministrationService.API.Services.Service.PractitionerRoles;
using Aurora.AdministrationService.CrossCutting.CommonModels;
using Aurora.AdministrationService.Domain.V1.Entities.PractitionerRoles;
using Aurora.AdministrationService.Infrastructure;
using AutoMapper;
using Microsoft.EntityFrameworkCore;
using Moq;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Aurora.AdministrationService.Tests.API.Services.PractitionerRoles.RoleMasters
{
    public class RoleMasterQueryServiceTests
    {
        private readonly Mock<ReadOnlyDbContext> _readOnlyDbContextMock;
        private readonly Mock<IMapper> _mapperMock;
        private readonly RoleMasterQueryService _roleMasterQueryService;
        private Mock<DbSet<RoleMaster>> _mockDbSet;

        public RoleMasterQueryServiceTests()
        {
            //Initialize mock
            _readOnlyDbContextMock = new Mock<ReadOnlyDbContext>();
            _mapperMock = new Mock<IMapper>();

            // Setup in-memory ready only database for testing
            DbContextOptions<ReadOnlyDbContext> options = new DbContextOptionsBuilder<ReadOnlyDbContext>()
              .UseInMemoryDatabase(databaseName: "RoleMasterTestDB").Options;

            _readOnlyDbContextMock = new(options);

            _mockDbSet = new Mock<DbSet<RoleMaster>>();

            var data = new List<RoleMaster>
            {
               new RoleMaster {
                Id = 1,
                Code = "test",
                Definition = "Definition",
                Source = "test",
                IsDeleted = false,
                CreatedBy = "Admin",
                CreatedDate = DateTime.UtcNow,
                UpdatedBy = "Admin",  // Adding the missing property
                UpdatedDate = DateTime.UtcNow,// Assuming UpdatedDate is required as well
            },
               new RoleMaster {
                Id = 2,
                Code = "test",
                Definition = "Definition",
                Source = "test",
                IsDeleted = false,
                CreatedBy = "Admin",
                CreatedDate = DateTime.UtcNow,
                UpdatedBy = "Admin",  // Adding the missing property
                UpdatedDate = DateTime.UtcNow,// Assuming UpdatedDate is required as well
            }

            }.AsQueryable();


            //Setup
            _mockDbSet.As<IQueryable<RoleMaster>>().Setup(m => m.Provider).Returns(data.Provider);
            _mockDbSet.As<IQueryable<RoleMaster>>().Setup(m => m.Expression).Returns(data.Expression);
            _mockDbSet.As<IQueryable<RoleMaster>>().Setup(m => m.ElementType).Returns(data.ElementType);
            _mockDbSet.As<IQueryable<RoleMaster>>().Setup(m => m.GetEnumerator()).Returns(data.GetEnumerator());
            _readOnlyDbContextMock.Setup(c => c.RoleMasters).Returns(_mockDbSet.Object);

            // Create the service instance
            _roleMasterQueryService = new RoleMasterQueryService(_readOnlyDbContextMock.Object, _mapperMock.Object);
        }

        [Fact]
        public async Task GetRoleMasterById_LogoExists_ReturnsLogoDetailDto()
        {
            // Arrange
            var roleMasterId = 1L;
            var roleMaster = new RoleMaster
            {
                Id = 1,
                Code = "test",
                Definition = "Definition",
                Source = "test",
                IsDeleted = false,
                CreatedBy = "Admin",
                CreatedDate = DateTime.UtcNow,
                UpdatedBy = "Admin",  // Adding the missing property
                UpdatedDate = DateTime.UtcNow,// Assuming UpdatedDate is required as well
            };

            var roleMasterDto = new GetRoleMasterDetailDto
            { 
                Id = 1,
                Code = "test",
              
            };

            _readOnlyDbContextMock.Setup(db => db.RoleMasters.FindAsync(roleMasterId))
                .ReturnsAsync(roleMaster);

            _mapperMock.Setup(m => m.Map<GetRoleMasterDetailDto>(roleMaster))
                .Returns(roleMasterDto);

            // Act
            var result = await _roleMasterQueryService.GetRoleMasterById(roleMasterId);

            // Assert
            Assert.NotNull(result);
            Assert.Equal(roleMasterId, result.Id);
            Assert.Equal("test", result.Code);
        }

        [Fact]
        public async Task GetRoleMasterById_roleMasterNotFound_ReturnsNull()
        {
            //Arrange
            var roleMasterId = 1;
            var roleMaster = new RoleMaster
            {
                Id = 1,
                Code = "test",
                Definition = "Definition",
                Source = "test",
                IsDeleted = false,
                CreatedBy = "Admin",
                CreatedDate = DateTime.UtcNow,
                UpdatedBy = "Admin",  // Adding the missing property
                UpdatedDate = DateTime.UtcNow,// Assuming UpdatedDate is required as well
            };

            _readOnlyDbContextMock.Setup(db => db.RoleMasters.FindAsync(roleMasterId))
                .ReturnsAsync(roleMaster);

            //Act
            var result = await _roleMasterQueryService.GetRoleMasterById(roleMasterId);

            //Assert
            Assert.Null(result);
        }

        [Fact]
        public async Task GetRoleMasterById_roleMasterExists_BindingError_ReturnsNull()
        {
            // Arrange
            byte[] concurrencyToken = new byte[8] { byte.MinValue, byte.MinValue, byte.MinValue, byte.MinValue, byte.MinValue, byte.MinValue, byte.MinValue, byte.MaxValue };
            var roleMasterId = 1L;
            var roleMaster = new RoleMaster
            {
                Id = 1,
                Code = "test",
                Definition = "Definition",
                Source = "test",
                IsDeleted = false,
                CreatedBy = "Admin",
                CreatedDate = DateTime.UtcNow,
                UpdatedBy = "Admin",  // Adding the missing property
                UpdatedDate = DateTime.UtcNow,// Assuming UpdatedDate is required as well
                RecordVersion = concurrencyToken
            };

            _readOnlyDbContextMock.Setup(db => db.RoleMasters.FindAsync(roleMasterId))
                .ReturnsAsync(roleMaster);

            _mapperMock.Setup(m => m.Map<GetRoleMasterDetailDto>(roleMaster))
                .Throws(new AutoMapperMappingException("Error mapping entity to DTO"));

            // Act & Assert
            var exception = await Assert.ThrowsAsync<AutoMapperMappingException>(
                () => _roleMasterQueryService.GetRoleMasterById(roleMasterId)
            );

            Assert.Equal("Error mapping entity to DTO", exception.Message);
        }

        [Fact]
        public async Task FindRoleMasterById_roleMasterExists_ReturnsroleMaster()
        {
            // Arrange
            byte[] concurrencyToken = new byte[8] { byte.MinValue, byte.MinValue, byte.MinValue, byte.MinValue, byte.MinValue, byte.MinValue, byte.MinValue, byte.MaxValue };
            long roleMasterId = 1;
            var roleMaster = new RoleMaster
            {
                Id = roleMasterId,
                Code = "test",
                Definition = "Definition",
                Source = "test",
                IsDeleted = false,
                CreatedBy = "Admin",
                CreatedDate = DateTime.UtcNow,
                UpdatedBy = "Admin",  // Adding the missing property
                UpdatedDate = DateTime.UtcNow,// Assuming UpdatedDate is required as well
                RecordVersion = concurrencyToken
            };

            // Mock the FindAsync method to return the roleMaster
            _readOnlyDbContextMock.Setup(db => db.RoleMasters.FindAsync(roleMasterId))
                .ReturnsAsync(roleMaster);

            // Act
            var result = await _roleMasterQueryService.FindRoleMasterById(roleMasterId);

            // Assert
            Assert.NotNull(result);
        }

        [Fact]
        public async Task FindRoleMasterById_roleMasterNotFound_ReturnsNull()
        {
            // Arrange
            var roleMasterId = 1L;
            var roleMaster = new RoleMaster
            {
                Id = roleMasterId,
                Code = "test",
                Definition = "Definition",
                Source = "test",
                IsDeleted = false,
                CreatedBy = "Admin",
                CreatedDate = DateTime.UtcNow,
                UpdatedBy = "Admin",  // Adding the missing property
                UpdatedDate = DateTime.UtcNow,// Assuming UpdatedDate is required as well
            };

            // Mock the FindAsync method to return null (roleMaster not found)
            _readOnlyDbContextMock.Setup(db => db.RoleMasters.FindAsync(roleMasterId))
                .ReturnsAsync(roleMaster);

            // Act
            var result = await _roleMasterQueryService.FindRoleMasterById(roleMasterId);

            // Assert
            Assert.NotNull(result);
        }

        [Fact]
        public void GetRoleMasterList_ReturnsCorrectRoleMasterList()
        {
            // Act
            var result = _roleMasterQueryService.GetRoleMasterList();

            // Assert
            Assert.NotNull(result);
            Assert.Equal(2, result.Count); // Verifying that 3 items are returned

            // Verifying that the returned items are mapped correctly
            Assert.Contains(result, r => r.Id == 1 && r.Code == "test");
            Assert.Contains(result, r => r.Id == 2 && r.Code == "test");
        }

        [Fact]
        public async Task IsRoleMasterAlreadyExist_ShouldReturnTrue_WhenroleMasterExists()
        {
            // Arrange
            var roleMasterId = 1;
            var roleMaster = new RoleMaster
            {
                Id = 1,
                Code = "test",
                Definition = "Definition",
                Source = "test",
                IsDeleted = false,
                CreatedBy = "Admin",
                CreatedDate = DateTime.UtcNow,
                UpdatedBy = "Admin",  // Adding the missing property
                UpdatedDate = DateTime.UtcNow,// Assuming UpdatedDate is required as well
            };

            // Mock the FindAsync method to return the roleMaster
            _readOnlyDbContextMock.Setup(db => db.RoleMasters.FindAsync(roleMasterId))
                .ReturnsAsync(roleMaster);

            // Act
            var result = await _roleMasterQueryService.IsRoleMasterAlreadyExist(roleMasterId);

            // Assert
            Assert.True(result.result);
            Assert.Equal(ResponseMessage.STATUS_DATA_FOUND, result.message);
        }

        [Fact]
        public async Task IsRoleMasterAlreadyExist_ShouldReturnFalse_WhenroleMasterDoesNotExist()
        {
            // Arrange
            var roleMasterId = 3;

            // Act
            var result = await _roleMasterQueryService.IsRoleMasterAlreadyExist(roleMasterId);

            // Assert
            Assert.False(result.result);
            Assert.Equal(ResponseMessage.STATUS_NODATA, result.message);
        }
    }
}
