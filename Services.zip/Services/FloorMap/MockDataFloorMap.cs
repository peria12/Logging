﻿using Aurora.AdministrationService.API.Models.RequestModels.FloorMap;

namespace Aurora.AdministrationService.Tests.API.Services.FloorMap
{
    public static class MockDataFloorMap
    {
        public static List<FloorMapRequest> FloorMapRequestMethod()
        {
            return new List<FloorMapRequest>
              {
                new FloorMapRequest
                {
                    FloorImageUrl = "img.jpg",
                    LocationId = 2,
                    HospitalId = 2,
                    BuildingName = "elante",
                    FloorLevel = 1
                }
              };
        }

        public static FloorMapRequest FloorMapRequest()
        {
            return new FloorMapRequest
            {
                FloorImageUrl = "img123.jpg",
                LocationId = 2,
                HospitalId = 2,
                BuildingName = "elante",
                FloorLevel = 1
            };
        }

        public static List<FloorMapRequest> FloorMapRequestList()
        {
            return new List<FloorMapRequest>
            {
                new FloorMapRequest
                {
                    FloorImageUrl = "img.jpg",
                    LocationId = 2,
                    HospitalId = 2,
                    BuildingName = "elante",
                    FloorLevel = 1,
                    IsDeleted = false,
                    IsActive = true
                }
            };
        }
    }
}