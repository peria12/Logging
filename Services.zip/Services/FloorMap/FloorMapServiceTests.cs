﻿using Aurora.AdministrationService.API.Enum;
using Aurora.AdministrationService.API.Helper;
using Aurora.AdministrationService.API.Models.RequestModels.FloorMap;
using Aurora.AdministrationService.API.Models.ResponseModels.FloorMap;
using Aurora.AdministrationService.API.Services.Service.Old.FloorMap;
using Aurora.AdministrationService.CrossCutting.CommonModels;
using Aurora.AdministrationService.CrossCutting.Extensions;
using Aurora.AdministrationService.Domain.Old.Entities;
using Aurora.AdministrationService.Infrastructure.IRepository;
using Aurora.AdministrationService.Tests.API.Services.FloorMap;
using AutoMapper;
using Moq;

namespace Aurora.AdministrationService.Test.Services
{
    public class FloorMapServiceTests
    {
        private readonly Mock<IMapper> _mapperMock;
        private readonly Mock<IFloorMapRepository> _floorMapRepositoryMock;
        private readonly FloorMapService _floorMapService;
        private readonly Mock<IResponseMessageHelper> _responseMessageHelper;


        public FloorMapServiceTests()
        {
            _mapperMock = new Mock<IMapper>();
            _floorMapRepositoryMock = new Mock<IFloorMapRepository>();
            _responseMessageHelper = new Mock<IResponseMessageHelper>();
            _floorMapService = new FloorMapService(_mapperMock.Object, _floorMapRepositoryMock.Object, _responseMessageHelper.Object);
        }

        [Fact]
        public async Task AddFloorMap_ValidRequest_ReturnsSuccessResponse()
        {
            // Arrange
            string userID = "123";
            List<FloorMapRequest> floorMapRequest = MockDataFloorMap.FloorMapRequestMethod();
            var floorMap = new List<FloorMap> { new FloorMap() };

            _mapperMock.Setup(m => m.Map<List<FloorMap>>(floorMapRequest)).Returns(floorMap);
            _floorMapRepositoryMock.Setup(r => r.AddFloorMap(floorMap)).ReturnsAsync((int)AddNewRecordStatus.Added);
            _responseMessageHelper.Setup(r => r.GetSuccessResponseMessage(It.IsAny<string>())).Returns(new GenericResponse<string> { IsSuccess = true, Message = "Record Inserted Successfully", StatusCode = "200" });

            // Act
            var result = await _floorMapService.AddFloorMap(userID, floorMapRequest);

            // Assert
            Assert.NotNull(result);
            _responseMessageHelper.Verify(r => r.GetSuccessResponseMessage(It.IsAny<string>()), Times.Once);
        }

        [Fact]
        public async Task AddFloorMap_RepositoryThrowsException_ReturnsErrorResponse()
        {
            // Arrange
            List<FloorMapRequest> floorMapRequest = MockDataFloorMap.FloorMapRequestMethod();
            var floorMap = new List<FloorMap> { new FloorMap() };
            _mapperMock.Setup(m => m.Map<List<FloorMap>>(floorMapRequest)).Returns(floorMap);
            _floorMapRepositoryMock.Setup(r => r.AddFloorMap(floorMap)).ThrowsAsync(new Exception());
            _responseMessageHelper.Setup(r => r.GetErrorResponseMessage(It.IsAny<string>())).Returns(new GenericResponse<string>());

            // Act
            var result = await _floorMapService.AddFloorMap("1", floorMapRequest);

            // Assert
            Assert.NotNull(result);
            _responseMessageHelper.Verify(r => r.GetErrorResponseMessage(It.IsAny<string>()), Times.Once);
        }

        [Fact]
        public async Task GetFloorMapById_ValidId_ReturnsFloorMap()
        {
            // Arrange
            var floorMap = new FloorMap();
            var floorMapResponse = new FloorMapImageResponseDTO();
            _floorMapRepositoryMock.Setup(r => r.GetFloorMapById(1)).ReturnsAsync(floorMap);
            _mapperMock.Setup(m => m.Map<FloorMapImageResponseDTO>(floorMap)).Returns(floorMapResponse);

            // Act
            var response = await _floorMapService.GetFloorMapById(1);

            // Assert
            Assert.True(response.IsSuccess);
            Assert.NotNull(response.Result);
            Assert.Equal(((int)ResponceStatusCode.Success).ToString(), response.StatusCode);
        }

        [Fact]
        public async Task GetFloorMapById_InvalidId_ReturnsNotFoundResponse()
        {
            // Arrange
            _floorMapRepositoryMock.Setup(r => r.GetFloorMapById(-1)).ReturnsAsync((FloorMap)null!);

            // Act
            var response = await _floorMapService.GetFloorMapById(-1);

            // Assert
            Assert.False(response.IsSuccess);
            Assert.Null(response.Result);
            Assert.Equal(((int)ResponceStatusCode.NotFound).ToString(), response.StatusCode);
        }

        [Fact]
        public async Task GetFloorMapById_ExceptionThrown_ReturnsErrorResponse()
        {
            // Arrange

            _floorMapRepositoryMock.Setup(r => r.GetFloorMapById(1)).Throws(new Exception());

            // Act
            var response = await _floorMapService.GetFloorMapById(1);

            // Assert
            Assert.True(response.HasError);
            Assert.Equal(((int)ResponceStatusCode.Failed).ToString(), response.StatusCode);
        }

        [Fact]
        public async Task DeleteFloorMap_ValidId_RecordDeleted_ReturnsSuccessResponse()
        {
            // Arrange
            _floorMapRepositoryMock.Setup(repo => repo.DeleteFloorMap(1)).ReturnsAsync((int)DeleteRecordStatus.Deleted);
            _responseMessageHelper.Setup(helper => helper.GetSuccessResponseMessage(It.IsAny<string>()))
                                      .Returns(new GenericResponse<string> { IsSuccess = true});

            // Act
            var response = await _floorMapService.DeleteFloorMap(1);

            // Assert
            Assert.True(response.IsSuccess);
        }

        [Fact]
        public async Task DeleteFloorMap_ValidId_RecordNotDeleted_ReturnsNotSuccessResponse()
        {
            // Arrange
            _floorMapRepositoryMock.Setup(repo => repo.DeleteFloorMap(1)).ReturnsAsync((int)DeleteRecordStatus.NotDeleted);
            _responseMessageHelper.Setup(helper => helper.GetSuccessResponseMessage(It.IsAny<string>()))
                                      .Returns(new GenericResponse<string> { IsSuccess = false });

            // Act
            var response = await _floorMapService.DeleteFloorMap(1);

            // Assert
            Assert.Null(response);
        }


        [Fact]
        public async Task DeleteFloorMap_ValidId_RecordNotDeleted_ReturnsFailureResponse()
        {
            // Arrange
            _floorMapRepositoryMock.Setup(repo => repo.DeleteFloorMap(2)).ReturnsAsync((int)DeleteRecordStatus.NotDeleted);
            _responseMessageHelper.Setup(helper => helper.GetFailureResponseMessage(It.IsAny<string>()))
                                      .Returns(new GenericResponse<string> { IsSuccess = false});

            // Act
            var response = await _floorMapService.DeleteFloorMap(2);

            // Assert
            Assert.False(response.IsSuccess);
        }

        [Fact]
        public async Task UpdateFloorMap_RecordNotFound_ReturnsRecordNotFoundResponse()
        {
            // Arrange
            FloorMapRequest floorMapRequest = MockDataFloorMap.FloorMapRequest();
            _floorMapRepositoryMock.Setup(repo => repo.GetFloorMapById(1)).ReturnsAsync((FloorMap)null!);
            _responseMessageHelper.Setup(helper => helper.GetRecordNotFoundResponseMessage(It.IsAny<string>())).Returns(new GenericResponse<string> {IsSuccess =false, StatusCode = "404" });

            // Act
            var result = await _floorMapService.UpdateFloorMap(1, "123", floorMapRequest);

            // Assert
            Assert.False(result.IsSuccess);
            Assert.Equal(((int)ResponceStatusCode.NotFound).ToString(), result.StatusCode);
        }

        [Fact]
        public async Task UpdateFloorMap_SuccessfulUpdate_ReturnsSuccessResponse()
        {
            // Arrange
            FloorMapRequest floorMapRequest = MockDataFloorMap.FloorMapRequest();
            var existingFloorMap = new FloorMap();
            _floorMapRepositoryMock.Setup(repo => repo.GetFloorMapById(1)).ReturnsAsync(existingFloorMap);
            _floorMapRepositoryMock.Setup(repo => repo.UpdateFloorMap(existingFloorMap)).ReturnsAsync((int)UpdateRecordStatus.Updated);
            _responseMessageHelper.Setup(helper => helper.GetSuccessUpdationResponseMessage(It.IsAny<string>())).Returns(new GenericResponse<string> {IsSuccess= true, StatusCode = "200" });

            // Act
            var result = await _floorMapService.UpdateFloorMap(1, "123", floorMapRequest);

            // Assert
            Assert.True(result.IsSuccess);
            Assert.Equal(((int)ResponceStatusCode.Success).ToString(), result.StatusCode);
        }

        [Fact]
        public async Task GetFloorMapList_ReturnsSuccessResponse_WhenDataExists()
        {
            // Arrange
            var paginationQuery = new PaginationQuery { PageNumber = 1, PageSize = 10 };
            var floorMaps = new List<FloorMap> { new FloorMap() };

            List<FloorMapRequest> floorMapRequests = MockDataFloorMap.FloorMapRequestList();

            _floorMapRepositoryMock.Setup(repo => repo.GetFloorMapList(1, paginationQuery))
                .ReturnsAsync(floorMaps);
            _mapperMock.Setup(mapper => mapper.Map<List<FloorMapRequest>>(floorMaps))
                .Returns(floorMapRequests);

            // Act
            var result = await _floorMapService.GetFloorMapList(1, paginationQuery);

            // Assert
            Assert.False(result.HasError);
            Assert.True(result.IsSuccess);
            Assert.Equal(((int)ResponceStatusCode.Success).ToString(), result.StatusCode);
            Assert.Equal(floorMapRequests, result.Results);
            Assert.Equal(floorMapRequests.Count, result.TotalCount);
            Assert.Equal(paginationQuery.PageNumber, result.CurrentPage);
            Assert.Equal(paginationQuery.PageSize, result.PageSize);
        }

        [Fact]
        public async Task GetFloorMapList_EmptyList_ReturnsNotFoundResponse()
        {
            // Arrange
            var paginationQuery = new PaginationQuery { PageNumber = 1, PageSize = 10 };
            var floorMapList = new List<FloorMap>();

            _floorMapRepositoryMock.Setup(r => r.GetFloorMapList(1, paginationQuery)).ReturnsAsync(floorMapList);
            _mapperMock.Setup(m => m.Map<List<FloorMapRequest>>(floorMapList)).Returns(new List<FloorMapRequest>());

            // Act
            var response = await _floorMapService.GetFloorMapList(1, paginationQuery);

            // Assert
            Assert.False(response.IsSuccess);
            Assert.Equal(0, response.TotalCount);
        }

        [Fact]
        public async Task GetFloorMapList_ExceptionThrown_ReturnsErrorResponse()
        {
            // Arrange
            var paginationQuery = new PaginationQuery { PageNumber = 1, PageSize = 10 };

            _floorMapRepositoryMock.Setup(r => r.GetFloorMapList(1, paginationQuery)).Throws(new Exception());

            // Act
            var response = await _floorMapService.GetFloorMapList(1, paginationQuery);

            // Assert
            Assert.True(response.HasError);
            Assert.Equal(((int)ResponceStatusCode.InternalServerError).ToString(), response.StatusCode);
        }
    }
}
