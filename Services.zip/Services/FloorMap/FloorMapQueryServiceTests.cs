﻿using Aurora.AdministrationService.API.Models.Dto.FloorMap;
using Aurora.AdministrationService.API.Services.Service.FloorMap;
using Aurora.AdministrationService.Infrastructure;
using Microsoft.EntityFrameworkCore;
using Moq;
using Xunit;
using Aurora.AdministrationService.CrossCutting.CommonModels;
using System.Linq;
using Aurora.AdministrationService.API.Enum;
using Aurora.AdministrationService.API.Resources;
using Aurora.AdministrationService.Domain.V1.Entities.Locations;
using FluentAssertions;

namespace Aurora.AdministrationService.Test.Services;
public class FloorMapQueryServiceTests
{
    private readonly DbContextOptions<ReadOnlyDbContext> _options;

    public FloorMapQueryServiceTests()
    {
        // Configure in-memory database options
        _options = new DbContextOptionsBuilder<ReadOnlyDbContext>()
            .UseInMemoryDatabase(databaseName: Guid.NewGuid().ToString()) // Specify a unique name for the database
            .Options;
    }

    private ReadOnlyDbContext GetInMemoryContext()
    {
        // Return a new instance of the ReadOnlyDbContext using in-memory options
        return new ReadOnlyDbContext(_options);
    }

    [Fact]
    public void GetFloorMaps_ShouldReturnPaginatedResults_WhenPageNumberAndPageSizeAreProvided()
    {
        // Arrange
        using var context = GetInMemoryContext();
        var service = new FloorMapQueryService(context);

        context.LocationImages.AddRange(new List<LocationImage>
    {
        new LocationImage { Id = 1, LocationID = 1, Category = "FloorMap", IsDeleted = false, CreatedBy = "user", UpdatedBy = "user" },
        new LocationImage { Id = 2, LocationID = 1, Category = "FloorMap", IsDeleted = false, CreatedBy = "user", UpdatedBy = "user" },
        new LocationImage { Id = 3, LocationID = 1, Category = "FloorMap", IsDeleted = false, CreatedBy = "user", UpdatedBy = "user" },
    });
        context.SaveChanges();

        var locationId = 1L;
        var pageNumber = 1;
        var pageSize = 2;

        // Act
        var response = service.GetFloorMaps(locationId, pageNumber, pageSize);

        // Assert using FluentAssertions
        response.Should().NotBeNull();
        response.IsSuccess.Should().BeTrue();
        response.CurrentPage.Should().Be(pageNumber);
        response.PageSize.Should().Be(pageSize);
        response.Results.Should().HaveCount(2);
    }



    [Fact]
    public void GetFloorMaps_ShouldReturnNotFound_WhenNoImagesExist()
    {
        // Arrange
        using var context = GetInMemoryContext(); // Create in-memory context
        var service = new FloorMapQueryService(context);

        var locationId = 999L; // An ID that doesn't exist in the database
        var pageNumber = 1;
        var pageSize = 2;

        // Act
        var response = service.GetFloorMaps(locationId, pageNumber, pageSize);

        // Assert using FluentAssertions
        response.Should().NotBeNull();
        response.HasError.Should().BeTrue();
        response.StatusCode.Should().Be(((int)ResponceStatusCode.NotFound).ToString());
        response.Message.Should().Be(Resource.RecordNotFound);
    }


    [Fact]
    public void GetFloorMaps_ShouldReturnAllResults_WhenNoPaginationIsProvided()
    {
        // Arrange
        using var context = GetInMemoryContext(); // Create in-memory context
        var service = new FloorMapQueryService(context);

        // Insert test data into the in-memory database
        context.LocationImages.AddRange(new List<LocationImage>
    {
        new LocationImage { Id = 1, LocationID = 1, Category = "FloorMap", IsDeleted = false, CreatedBy = "user", UpdatedBy = "user" },
        new LocationImage { Id = 2, LocationID = 1, Category = "FloorMap", IsDeleted = false, CreatedBy = "user", UpdatedBy = "user" },
        new LocationImage { Id = 3, LocationID = 1, Category = "FloorMap", IsDeleted = false, CreatedBy = "user", UpdatedBy = "user" },
    });
        context.SaveChanges();

        var locationId = 1L;
        int? pageNumber = null;
        int? pageSize = null;

        // Act
        var response = service.GetFloorMaps(locationId, pageNumber, pageSize);

        // Assert using FluentAssertions
        response.Should().NotBeNull();
        response.IsSuccess.Should().BeTrue();
        response.CurrentPage.Should().Be(1);
        response.PageSize.Should().Be(3);
        response.Results.Should().HaveCount(3);
    }

}
