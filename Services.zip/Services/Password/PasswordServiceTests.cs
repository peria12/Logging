﻿using Aurora.AdministrationService.API.Resources;
using Aurora.AdministrationService.API.Services.Service.Password;
using Aurora.AdministrationService.CrossCutting.CommonModels;
using Aurora.AdministrationService.Domain.V1.Entities.Users;
using Aurora.AdministrationService.Infrastructure;
using Aurora.AdministrationService.Tests.API.CommonMock;
using AutoMapper;
using FluentAssertions;
using Microsoft.EntityFrameworkCore;
using Moq;

namespace Aurora.AdministrationService.Tests.API.Services.Password
{
    public class PasswordServiceTests
    {
        private ReadWriteDbContext _dbContext;
        private readonly Mock<IMapper> _mockMapper;
        private readonly PasswordServices _passwordServices;

        public PasswordServiceTests()
        {
            var options = new DbContextOptionsBuilder<ReadWriteDbContext>()
                .UseInMemoryDatabase(databaseName: "TestDb")
                .Options;
            _dbContext = new ReadWriteDbContext(options);
            _mockMapper = new Mock<IMapper>();
            _passwordServices = new PasswordServices(_dbContext, _mockMapper.Object);
        }

        [Fact]
        public async Task GetUserContactInfoAsync_ExceptionThrown_ReturnsInternalServerError()
        {
            // Arrange
            var mockDbContext = new Mock<ReadWriteDbContext>(new DbContextOptionsBuilder<ReadWriteDbContext>()
                .UseInMemoryDatabase("ExceptionDb").Options);
            mockDbContext.Setup(m => m.Set<Aurora.AdministrationService.Domain.V1.Entities.Users.User>()).Throws(new Exception("Database error"));
            var passwordServices = new PasswordServices(mockDbContext.Object, _mockMapper.Object);

            // Act
            var result = await passwordServices.GetUserContactInfoAsync("1");

            // Assert
            result.Should().NotBeNull();
            result.IsSuccess.Should().BeFalse();
            result.StatusCode.Should().Be(ResponseStatus.STATUS_InternalServerError);
        }


        [Fact]
        public async Task ResetPassword_UserDoesNotExist_ReturnsNotFound()
        {
            // Act
            var result = await _passwordServices.ResetPassword("2", "NewPass@123", "NewPass@123");

            // Assert
            result.Should().NotBeNull();
            result.IsSuccess.Should().BeFalse();
            result.StatusCode.Should().Be(ResponseStatus.STATUS_NotFound);
        }

        [Fact]
        public async Task ResetPassword_ValidPassword_UpdatesSuccessfully()
        {
            // Arrange
            var user = new Aurora.AdministrationService.Domain.V1.Entities.Users.User { Id = 1, UserName = "admin", Password = "hashedpwd", Salt = "salt123", CreatedBy = "System", CreatedDate = System.DateTime.UtcNow, UpdatedBy = "System", IsDeleted = false, NotificationsEnabled = true, BioAuthenticationEnabled = true, SOSButtonEnabled = true, UserType = "Admin", Status = true, IsTempAccount = false };
            _dbContext.Set<Aurora.AdministrationService.Domain.V1.Entities.Users.User>().Add(user);
            await _dbContext.SaveChangesAsync();

            // Act
            var result = await _passwordServices.ResetPassword("admin", "NewPass@123", "NewPass@123");

            // Assert
            result.Should().NotBeNull();
            result.IsSuccess.Should().BeTrue();
            result.StatusCode.Should().Be(ResponseStatus.STATUS_SUCCESS);
        }

        [Fact]
        public async Task GetUserContactInfoAsync_UserNotFound_ReturnsNotFoundResponse()
        {
            // Arrange
            var options = new DbContextOptionsBuilder<ReadWriteDbContext>()
                .UseInMemoryDatabase(Guid.NewGuid().ToString()).Options;
            var mockDbContext = new Mock<ReadWriteDbContext>(options);
            var userId = "nonexistent-user-id";

            var mockUserTelecoms = new Mock<DbSet<UserTelecom>>();
            mockUserTelecoms.As<IQueryable<UserTelecom>>().Setup(m => m.Provider).Returns(new List<UserTelecom>().AsQueryable().Provider);
            mockUserTelecoms.As<IQueryable<UserTelecom>>().Setup(m => m.Expression).Returns(new List<UserTelecom>().AsQueryable().Expression);
            mockUserTelecoms.As<IQueryable<UserTelecom>>().Setup(m => m.ElementType).Returns(new List<UserTelecom>().AsQueryable().ElementType);
            mockUserTelecoms.As<IQueryable<UserTelecom>>().Setup(m => m.GetEnumerator()).Returns(new List<UserTelecom>().GetEnumerator());

            mockDbContext.Setup(db => db.UserTelecoms).Returns(mockUserTelecoms.Object);

            // Act
            var result = await _passwordServices.GetUserContactInfoAsync(userId);

            // Assert
            result.Should().NotBeNull();
            result.HasError.Should().BeTrue();
            result.IsSuccess.Should().BeFalse();
            result.StatusCode.Should().Be(ResponseStatus.STATUS_NotFound);
        }


        [Fact]
        public async Task GetUserContactInfoAsync_UserFound_ReturnsFoundResponse()
        {
            // Arrange
            var userTelecoms = UserTelecomMockData.GetUserTelecomFakeData();

            _dbContext.Set<Aurora.AdministrationService.Domain.V1.Entities.Users.UserTelecom>().AddRange(userTelecoms);
            await _dbContext.SaveChangesAsync();

            // Act
            var result = await _passwordServices.GetUserContactInfoAsync("1000");

            // Assert
            result.Should().NotBeNull();
            result.IsSuccess.Should().BeTrue();
            result.StatusCode.Should().Be(ResponseStatus.STATUS_SUCCESS);
        }

        [Fact]
        public async Task ResetPassword_PasswordsDoNotMatch_ReturnsBadRequest()
        {
            // Arrange
            DbContextOptions<ReadWriteDbContext> options = new DbContextOptionsBuilder<ReadWriteDbContext>()
              .UseInMemoryDatabase(databaseName: "User_ResetPassword").Options;

            var user = UsersMockData.GetUserFakeData();
            _dbContext = new ReadWriteDbContext(options);
            _dbContext.UserNew.Add(user);
            await _dbContext.SaveChangesAsync();

            // Act
            var result = await _passwordServices.ResetPassword("admin", "StrongPassword123", "StrongPassword");

            // Assert
            result.Should().NotBeNull();
            result.HasError.Should().BeTrue();
            result.IsSuccess.Should().BeFalse();
            result.Message.Should().Be(Resource.PasswordNotMatch);
            result.StatusCode.Should().Be(ResponseStatus.STATUS_BadRequest);
        }

        [Fact]
        public async Task ResetPassword1_PasswordsDoNotMatch_ReturnsBadRequest()
        {
            // Arrange
            // Arrange
            var user = new Aurora.AdministrationService.Domain.V1.Entities.Users.User { Id = 11, UserName = "ccm", Password = "hashedpwd", Salt = "salt123", CreatedBy = "System", CreatedDate = System.DateTime.UtcNow, UpdatedBy = "System", IsDeleted = false, NotificationsEnabled = true, BioAuthenticationEnabled = true, SOSButtonEnabled = true, UserType = "Admin", Status = true, IsTempAccount = false };
            _dbContext.Set<Aurora.AdministrationService.Domain.V1.Entities.Users.User>().Add(user);
            await _dbContext.SaveChangesAsync();

            // Act
            var result = await _passwordServices.ResetPassword("ccm", "StrongPassword", "StrongPassword");

            // Assert
            result.Should().NotBeNull();
            result.HasError.Should().BeTrue();
            result.IsSuccess.Should().BeFalse();
            result.Message.Should().Be(Resource.WeakPassword);
            result.StatusCode.Should().Be(ResponseStatus.STATUS_NotFound);
        }
    }

}


