﻿using Aurora.AdministrationService.API.Models.Dto.ServiceChargeMasters;
using Aurora.AdministrationService.API.Services.Service.ServiceChargeMasters;
using Aurora.AdministrationService.Domain.V1.Entities.ServiceChargeMasters;
using Aurora.AdministrationService.Infrastructure;
using Aurora.AdministrationService.Tests.API.Controllers.ServiceChargeMasters;
using AutoMapper;
using FluentAssertions;
using Microsoft.EntityFrameworkCore;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Aurora.AdministrationService.Tests.API.Services.ServiceChargeMasters
{
    public class ServiceChargeMasterCommandServiceTests
    {
        private readonly ServiceChargeMasterCommandService _service;
        private readonly ReadWriteDbContext _dbContext;
        private readonly IMapper _mapper;

        public ServiceChargeMasterCommandServiceTests()
        {
            var options = new DbContextOptionsBuilder<ReadWriteDbContext>()
                .UseInMemoryDatabase(databaseName: "TestDatabase")
                .Options;

            _dbContext = new ReadWriteDbContext(options);

            var mapperConfig = new MapperConfiguration(cfg =>
            {
                cfg.CreateMap<CreateServiceChargeMasterRequest, ServiceChargeMaster>();
                cfg.CreateMap<UpdateServiceChargeMasterRequest, ServiceChargeMaster>();
                cfg.CreateMap<ServiceChargeMaster, ServiceChargeMasterDto>()
                        .ForMember(dest => dest.ItemCode, opt => opt.MapFrom(src => src.ItemCode))
                        .ForMember(dest => dest.TestCode, opt => opt.MapFrom(src => src.TestCode));
            });
            _mapper = mapperConfig.CreateMapper();

            _service = new ServiceChargeMasterCommandService(_dbContext, _mapper);
        }


        [Fact]
        public async Task AddServiceChargeMasterAsync_ShouldAddServiceChargeMasterSuccessfully()
        {
            // Arrange
            var request = CommonMockData.GetMockCreateServiceChargeMasterRequest();
            // Ensure required fields are set

            // Act
            var result = await _service.AddServiceChargeMasterAsync(request);
            var service = await _dbContext.ServiceChargeMasters.FirstOrDefaultAsync(d => d.ItemCode == request.ItemCode);

            // Assert
            service.Should().NotBeNull();
            service?.CreatedBy.Should().Be("Admin");
            result.Should().NotBeNull();
        }

        [Fact]
        public async Task UpdateServiceChargeMasterAsync_ShouldUpdateServiceChargeMasterSuccessfully()
        {
            // Arrange
            await ClearDatabaseAsync(); 

            // Create a mock entity with a specific ID
            var serviceCharge = CommonMockData.GetMockServiceChargeMaster3(id: 5);

            // Add the entity to the in-memory database and save changes
            _dbContext.ServiceChargeMasters.Add(serviceCharge);
            await _dbContext.SaveChangesAsync();

            // Retrieve the entity to ensure it exists and is being tracked
            var existingService = await _dbContext.ServiceChargeMasters
                .FirstOrDefaultAsync(s => s.ID == serviceCharge.ID); // Use ID to locate the entity

            existingService.Should().NotBeNull(); // Ensure the entity exists

            // Create an update request with the same RecordVersion for concurrency control
            var request = CommonMockData.GetMockUpdateServiceChargeMasterRequest(
                itemCode: serviceCharge.ItemCode,
                recordVersion: existingService?.RecordVersion, // Pass the existing RecordVersion
                testCode: "UpdatedTestCode" // Ensure the test code is different
            );

            // Ensure the request contains the correct ID
            request.ID = existingService!.ID; // Use the existing ID

            // Act
            var result = await _service.UpdateServiceChargeMasterAsync(request, existingService);

            // Assert
            var updatedService = await _dbContext.ServiceChargeMasters
                .AsNoTracking() // Fetch a fresh copy without tracking
                .FirstOrDefaultAsync(s => s.ID == serviceCharge.ID); // Use ID to locate the updated entity

            // Verify the entity is updated correctly
            updatedService.Should().NotBeNull();
            updatedService?.ID.Should().Be(serviceCharge.ID); // Ensure the ID is unchanged
            updatedService?.UpdatedBy.Should().Be("Admin"); // Verify the updated user ID
            updatedService?.UpdatedDate.Should().BeCloseTo(DateTime.UtcNow, TimeSpan.FromSeconds(1)); // Verify the timestamp
            updatedService?.TestCode.Should().Be(request.TestCode); // Verify the updated test code

            // Verify the result (DTO)
            result.Should().NotBeNull();
            result.ItemCode.Should().Be(serviceCharge.ItemCode); // Verify the returned DTO has the correct ItemCode
            result.TestCode.Should().Be(request.TestCode); // Verify the updated test code
        }

        [Fact]
        public async Task DeleteServiceChargeMasterAsync_ShouldSoftDelete_WhenRecordExists()
        {
            // Arrange
            var service = new ServiceChargeMaster
            {
                ItemCode = "Ser123",
                TestCode = "Test123",
                MasterType = "General",
                IsDeleted = false,
                CreatedDate = DateTime.UtcNow,
                CreatedBy = "TestUser",
                RecordVersion = Encoding.UTF8.GetBytes("1"),
            };

            await _dbContext.ServiceChargeMasters.AddAsync(service);
            await _dbContext.SaveChangesAsync();

            var existingService = await _dbContext.ServiceChargeMasters.FirstOrDefaultAsync(d => d.ItemCode == service.ItemCode);
            existingService.Should().NotBeNull();
            var originalRecordVersion = existingService?.RecordVersion;

            // Act
            var result = await _service.DeleteServiceChargeMasterAsync(originalRecordVersion!, existingService!);

            // Assert
            result.Should().BeTrue();

            var deletedService = await _dbContext.ServiceChargeMasters.FirstOrDefaultAsync(d => d.ItemCode == service.ItemCode);
            deletedService.Should().NotBeNull();
            deletedService?.IsDeleted.Should().BeTrue();
            deletedService?.UpdatedBy.Should().Be("Admin");
            deletedService?.UpdatedDate.Should().BeCloseTo(DateTime.UtcNow, TimeSpan.FromSeconds(1));
        }

        [Fact]
        public async Task DeleteServiceChargeMasterAsync_ShouldThrowException_WhenRecordVersionMismatch()
        {
            // Arrange
            var service = new ServiceChargeMaster
            {
                ItemCode = "Ser123",
                TestCode = "Test123",
                MasterType = "General",
                IsDeleted = false,
                CreatedDate = DateTime.UtcNow,
                CreatedBy = "TestUser",
                RecordVersion = Encoding.UTF8.GetBytes("1"),
            };
        

            await _dbContext.ServiceChargeMasters.AddAsync(service);
            await _dbContext.SaveChangesAsync();

            var existingService = await _dbContext.ServiceChargeMasters.FirstOrDefaultAsync(d => d.ItemCode == service.ItemCode);
            existingService.Should().NotBeNull();

            // Act
            Func<Task> act = async () => await _service.DeleteServiceChargeMasterAsync(Encoding.UTF8.GetBytes("2"), existingService!);

            // Assert
            await act.Should().ThrowAsync<DbUpdateConcurrencyException>();
        }

        private static async Task ClearDatabaseAsync()
        {
            var options = new DbContextOptionsBuilder<ReadWriteDbContext>()
                .UseInMemoryDatabase(databaseName: Guid.NewGuid().ToString())
                .Options;

            using var dbContext = new ReadWriteDbContext(options);
            dbContext.ServiceChargeMasters.RemoveRange(dbContext.ServiceChargeMasters);
            await dbContext.SaveChangesAsync();
        }
    }
}