﻿using Aurora.AdministrationService.API.Models.Dto.ServiceChargeMasters;
using Aurora.AdministrationService.API.Services.Service.ServiceChargeMasters;
using Aurora.AdministrationService.Domain.V1.Entities.ServiceChargeMasters;
using Aurora.AdministrationService.Infrastructure;
using Aurora.AdministrationService.Tests.API.Controllers.ServiceChargeMasters;
using AutoMapper;
using FluentAssertions;
using Microsoft.EntityFrameworkCore;
using Moq;

namespace Aurora.AdministrationService.Tests.API.Services.ServiceChargeMasters
{
    public class ServiceChargeMasterQueryServiceTests
    {
        private readonly ReadOnlyDbContext _dbContext;
        private readonly Mock<IMapper> _mockMapper;
        private readonly ServiceChargeMasterQueryService _service;

        public ServiceChargeMasterQueryServiceTests()
        {
            var options = new DbContextOptionsBuilder<ReadOnlyDbContext>()
                .UseInMemoryDatabase(databaseName: Guid.NewGuid().ToString()) // Use a unique DB per test
                .Options;

            _dbContext = new ReadOnlyDbContext(options);
            _mockMapper = new Mock<IMapper>();
            _service = new ServiceChargeMasterQueryService(_dbContext, _mockMapper.Object);
        }


        [Fact]
        public async Task CheckExistingServiceChargeMasterAsync_ReturnsServiceChargeMaster_WhenItemCodeExists()
        {
            // Arrange
            var mockServiceChargeMaster = CommonMockData.GetMockServiceChargeMaster();
            _dbContext.ServiceChargeMasters.Add(mockServiceChargeMaster);
            await _dbContext.SaveChangesAsync();

            // Act
            var result = await _service.CheckExistingServiceChargeMasterAsync("Item001");

            // Assert
            result.Should().NotBeNull();
            result?.ItemCode.Should().Be("Item001");
        }

        [Fact]
        public async Task GetServiceChargeMasterById_ReturnServiceChargeMasterDto_WhenIdExists()
        {
            // Arrange
            var mockServiceChargeMaster = CommonMockData.GetMockServiceChargeMaster();
            mockServiceChargeMaster.ID = 1; // Explicitly set the ID

            // Ensure the database context is tracking the entity properly
            _dbContext.ServiceChargeMasters.Add(mockServiceChargeMaster);
            await _dbContext.SaveChangesAsync();

            // Retrieve the entity from the database to ensure tracking
            var savedServiceChargeMaster = await _dbContext.ServiceChargeMasters.FirstOrDefaultAsync(d => d.ID == 1);
            savedServiceChargeMaster.Should().NotBeNull(); // Sanity check

            // Setup AutoMapper mock
            var mockServiceChargeMasterDto = new GetServiceChargeMasterDto 
            { ItemCode = "Item001" ,
                TestCode = "Test1001",
                CreatedDate = DateTime.UtcNow,
                IsDeleted = false,
            };
            _mockMapper.Setup(m => m.Map<GetServiceChargeMasterDto>(It.IsAny<ServiceChargeMaster>())).Returns(mockServiceChargeMasterDto);

            // Act
            var result = await _service.GetServiceChargeMasterById(1);

            // Assert
            result.Should().NotBeNull();
            result.ItemCode.Should().Be("Item001");
        }

        [Fact]
        public async Task GetServiceChargeMasterList_ReturnsListOfServiceChargeMasterDto()
        {
            // Arrange: Add mock data to the in-memory database
            var mockServiceChargeMasters = new List<ServiceChargeMaster>
            {
                CommonMockData.GetMockServiceChargeMaster(),
                CommonMockData.GetMockServiceChargeMaster2(),
                CommonMockData.GetMockServiceChargeMaster3()
            };

            await _dbContext.ServiceChargeMasters.AddRangeAsync(mockServiceChargeMasters);
            await _dbContext.SaveChangesAsync();

            // Ensure database has records
            var count = await _dbContext.ServiceChargeMasters.CountAsync();
            count.Should().Be(3, "Database should contain exactly two ServiceChargeMaster records.");

            // Setup AutoMapper to map DrugMaster -> GetDrugMasterDto
            _mockMapper.Setup(m => m.Map<List<GetServiceChargeMasterDto>>(It.IsAny<List<ServiceChargeMaster>>()))
                       .Returns((List<ServiceChargeMaster> dms) => dms.Select(dm => new GetServiceChargeMasterDto
                       {
                           ItemCode = dm.ItemCode,
                           ItemDescription = dm.ItemDescription,
                           TestCode = dm.TestCode,
                           TestDescription = dm.TestDescription,
                           ServiceType = dm.ServiceType,
                           IsDeleted = false,
                           CreatedDate = DateTime.UtcNow,
                           CreatedBy = "testUser1"
                       }).ToList());

            // Act: Call the service method
            var result = await _service.GetServiceChargeMasterList();

            // Assert: Verify the results
            result.Should().NotBeNull();
            result.Should().HaveCount(3, "The service should return exactly two ServiceChargeMasterDto records.");

            result[0].ItemCode.Should().Be(mockServiceChargeMasters[0].ItemCode);
            result[1].ItemCode.Should().Be(mockServiceChargeMasters[1].ItemCode);
            result[2].ItemCode.Should().Be(mockServiceChargeMasters[2].ItemCode);
        }
    }
}