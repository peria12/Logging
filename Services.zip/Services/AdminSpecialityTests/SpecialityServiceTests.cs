﻿using Aurora.AdministrationService.API.Mapper;
using Aurora.AdministrationService.API.Services.IService.AdminSpecialty;
using Aurora.AdministrationService.API.Services.Service.AdminSpecialty;
using Aurora.AdministrationService.Domain.V1.Entities.PractitionerRoles;
using Aurora.AdministrationService.Domain.V1.Entities.Practitioners;
using Aurora.AdministrationService.Infrastructure;
using AutoMapper;
using FluentAssertions;
using Microsoft.EntityFrameworkCore;
using Moq;

namespace Aurora.AdministrationService.Tests.API.Services.AdminSpecialityTests
{
    /// <summary>
    /// Service layer test cases for GetAll Specialities 
    /// </summary>
    public class SpecialityServicesTests
    {
        private readonly SpecialityServices _specialityServices;
        private readonly ReadOnlyDbContext _dbContext;
        private readonly IMapper _mapper;
       

        public SpecialityServicesTests()
        {
            // Set up in-memory database
            var options = new DbContextOptionsBuilder<ReadOnlyDbContext>()
                .UseInMemoryDatabase(databaseName: Guid.NewGuid().ToString())
                .Options;

            _dbContext = new ReadOnlyDbContext(options);

            // Seed data
            SeedData();

            // Set up AutoMapper
            var configuration = new MapperConfiguration(cfg =>
            {
                cfg.AddProfile<MapProfile>(); // Assume your AutoMapper profile is named MappingProfile
            });
            _mapper = configuration.CreateMapper();

            _specialityServices = new SpecialityServices(_dbContext, _mapper);
        }

        // Seed the in-memory database with some test data
        private void SeedData()
        {
            var roleMaster = new RoleMaster { Code = "Doctor", IsDeleted = false, CreatedDate = DateTime.Today };
            var specialityMaster = new Domain.V1.Entities.HealthcareService.HealthcareServices { Name = "Cardio", LaymanDescription = "Cardiology-Related to Heart", CreatedBy = "Aurora", CreatedDate = DateTime.UtcNow, RecordVersion = Array.Empty<byte>(), Status = true, IsDeleted=false };

            _dbContext.RoleMasters.Add(roleMaster);
            _dbContext.HealthcareServices.Add(specialityMaster);

            var practitionerRole = new PractitionerRole
            {
                Id = 12345,
                UUID = Guid.NewGuid(),
                PractitionerID = "1",
                IsDeleted = false,
                CreatedBy = "admin",
                CreatedDate = DateTime.Now,
                UpdatedBy = "admin",
                UpdatedDate = DateTime.Now,
                AvailabilityExceptions = "Test"
            };
            var practitionerRoleCode = new PractitionerRoleCode
            {
                PractitionerRoleID = 12345,
                Code = "Doctor",
                IsDeleted = false,
                CreatedBy = "admin",
                CreatedDate = DateTime.Now,
                UpdatedBy = "admin",
                UpdatedDate = DateTime.Now
            };
            var practitionerRoleSpecialty = new PractitionerRoleSpecialty
            {
                PractitionerRoleID = 12345,
                Specialty = "Cardio",
                IsDeleted = false,
                CreatedBy = "admin",
                CreatedDate = DateTime.Now,
                UpdatedBy = "admin",
                UpdatedDate = DateTime.Now
            };

            var practitioners = new Practitioner
            {
                ResourceID = "1",
                Status = true,
                IsDeleted = false,
                CreatedBy = "admin",
                CreatedDate = DateTime.Now,
                UpdatedBy = "admin",
                UpdatedDate = DateTime.Now
            };
         
            _dbContext.Practitioners.Add(practitioners);
            _dbContext.PractitionerRoles.Add(practitionerRole);
            _dbContext.PractitionerRoleCodes.Add(practitionerRoleCode);
            _dbContext.PractitionerRoleSpecialty.Add(practitionerRoleSpecialty);

            _dbContext.SaveChanges();
        }

        [Fact]
        public void GetAllSpecialityList_ShouldReturnSpecialties_WhenRoleIsValid()
        {
            // Arrange
            var role = "Doctor";

            // Act
            var result =  _specialityServices.GetAllSpecialityList(role);

            // Assert
            result.Should().NotBeNull();
        }

        [Fact]
        public void GetAllSpecialityList_ShouldReturnNoData_WhenNoSpecialtiesExist()
        {
            // Arrange
            var role = "RoleNotExists"; // A role that does not exist in the seed data

            // Act
            var result =  _specialityServices.GetAllSpecialityList(role);

            // Assert
            result.Should().NotBeNull();
        }

        [Fact]
        public void GetAllSpecialityList_ShouldReturnNoData_WhenRoleIsNull()
        {
            // Arrange
            string role = null;

            // Act
            var result =  _specialityServices.GetAllSpecialityList(role);

            // Assert
            result.Should().NotBeNull();
        }
    }
}
