﻿using Aurora.AdministrationService.API.Models.Dto.UserGroups.GroupRoleMapping;
using Aurora.AdministrationService.API.Services.Service.UserGroups.GroupRoleMapping;
using Aurora.AdministrationService.Infrastructure;
using AutoMapper;
using Microsoft.EntityFrameworkCore;
using Moq;

namespace Aurora.AdministrationService.Tests.API.Services.UserGroups.GroupRoleMappings
{
    public class GroupRoleMappingCommandServiceTests
    {
        private readonly Mock<ReadWriteDbContext> _readWriteDbContextMock;
        private readonly Mock<ReadOnlyDbContext> _readOnlyDbContextMock;
        private readonly Mock<IMapper> _mapperMock;
        private GroupRoleMappingCommandService _groupRoleMappingCommandService;
        private readonly Mock<GroupRoleMappingQueryService> _groupRoleMappingQueryService;

        public GroupRoleMappingCommandServiceTests()
        {
            // Initialize the mocks
            _mapperMock = new Mock<IMapper>();
            _readWriteDbContextMock = new Mock<ReadWriteDbContext>();
            _readOnlyDbContextMock = new Mock<ReadOnlyDbContext>();
            _groupRoleMappingQueryService = new Mock<GroupRoleMappingQueryService>();


            // Setup in-memory ready only database for testing
            DbContextOptions<ReadWriteDbContext> options = new DbContextOptionsBuilder<ReadWriteDbContext>()
              .UseInMemoryDatabase(databaseName: "AdminGroupRoleMappingTestDB").Options;

            _readWriteDbContextMock = new(options);

            // Initialize the service being tested
            _groupRoleMappingCommandService = new GroupRoleMappingCommandService(_readWriteDbContextMock.Object, _mapperMock.Object);
        }

        [Fact]
        public async Task CreateGroupRoleMappingAsync_ShouldReturnTrue_WhenGroupRoleMappingIsCreatedSuccessfully()
        {
            // Arrange
            var newGroupRoleMapping = new GroupRoleMappingDto
            {
                Code = "test",
                GroupID = 1,
                RoleID = 1,
                Definition = "test",
                Display = "test",
                Source = "test",
            };

            // Mock AutoMapper to return a GroupRoleMapping entity
            var groupRoleMappingEntity = new Domain.V1.Entities.UserGroups.GroupRoleMapping
            {
                Code = "test",
                GroupID = 1,
                RoleID = 1,
                Definition = "test",
                Display = "test",
                Source = "test",
                IsDeleted = false,
                CreatedBy = "Admin",
                CreatedDate = DateTime.UtcNow,
                UpdatedBy = "Admin",  // Adding the missing property
                UpdatedDate = DateTime.UtcNow,// Assuming UpdatedDate is required as well
            };


            // Mock AutoMapper to return the GroupRoleMapping entity
            _mapperMock.Setup(m => m.Map<Domain.V1.Entities.UserGroups.GroupRoleMapping>(newGroupRoleMapping)).Returns(groupRoleMappingEntity);

            // Mock DbContext to simulate saving the entity without actually hitting the database
            _readWriteDbContextMock.Setup(db => db.GroupRoleMappings.Add(It.IsAny<Domain.V1.Entities.UserGroups.GroupRoleMapping>()));

            // Act
            var result = await _groupRoleMappingCommandService.CreateGroupRoleMappingAsync(newGroupRoleMapping);

            // Assert
            Assert.True(result);
            _readWriteDbContextMock.Verify(db => db.GroupRoleMappings.Add(It.Is<Domain.V1.Entities.UserGroups.GroupRoleMapping>(l => l.Source == "test")), Times.Once);
        }


        [Fact]
        public async Task CreateGroupRoleMappingAsync_ShouldReturnFalse_WhenExceptionOccurs()
        {
            // Arrange
            var newGroupRoleMapping = new GroupRoleMappingDto
            {
                Code = "test",
                GroupID = 1,
                RoleID = 1,
                Definition = "test",
                Display = "test",
                Source = "test",
            };

            // Mock AutoMapper to return a GroupRoleMapping entity
            var groupRoleMappingId = 1;
            var groupRoleMappingEntity = new Domain.V1.Entities.UserGroups.GroupRoleMapping
            {
                Id = groupRoleMappingId,
                Code = "test",
                GroupID = 1,
                RoleID = 1,
                Definition = "test",
                Display = "test",
                Source = "test",
                IsDeleted = false,
                CreatedBy = "Admin",
                CreatedDate = DateTime.UtcNow,
                UpdatedBy = "Admin",  // Adding the missing property
                UpdatedDate = DateTime.UtcNow,// Assuming UpdatedDate is required as well
            };

            //Setup
            _mapperMock.Setup(m => m.Map<Domain.V1.Entities.UserGroups.GroupRoleMapping>(newGroupRoleMapping)).Returns(groupRoleMappingEntity);

            // Act
            var result = await _groupRoleMappingCommandService.CreateGroupRoleMappingAsync(newGroupRoleMapping);

            // Assert
            Assert.False(result);
        }
        [Fact]
        public async Task Test_UpdateGroupRoleMapping_Returns_Success()
        {
            //Arrange
            DbContextOptions<ReadWriteDbContext> options = new DbContextOptionsBuilder<ReadWriteDbContext>()
               .UseInMemoryDatabase(databaseName: "UpdateGroupRoleMapping").Options;

            byte[] concurrencyToken = new byte[8] { byte.MinValue, byte.MinValue, byte.MinValue, byte.MinValue, byte.MinValue, byte.MinValue, byte.MinValue, byte.MaxValue };
            var groupRoleMapping = new Domain.V1.Entities.UserGroups.GroupRoleMapping
            {
                Id = 1,
                Code = "test",
                GroupID = 1,
                RoleID = 1,
                Definition = "test",
                Display = "test",
                Source = "test",
                IsDeleted = false,
                CreatedBy = "Admin",
                CreatedDate = DateTime.UtcNow,
                UpdatedBy = "Admin",  // Adding the missing property
                UpdatedDate = DateTime.UtcNow,// Assuming UpdatedDate is required as well
            };


            //Arrange
            using ReadWriteDbContext dbContext = new(options);
            dbContext.GroupRoleMappings.Add(groupRoleMapping);
            await dbContext.SaveChangesAsync();


            UpdateGroupRoleMappingRequest updateModel = new UpdateGroupRoleMappingRequest
            {
                Id = 1,
                Code = "test",
                GroupID = 1,
                RoleID = 1,
                Definition = "test",
                Display = "test",
                Source = "test",
            };

            _groupRoleMappingCommandService = new GroupRoleMappingCommandService(dbContext, _mapperMock.Object);

            // Act
            bool result = await _groupRoleMappingCommandService.UpdateGroupRoleMappingAsync(updateModel, groupRoleMapping);

            Assert.True(result);
        }
        [Fact]
        public async Task Test_DeleteGroupRoleMapping_Returns_Success()
        {
            //Arrange
            DbContextOptions<ReadWriteDbContext> options = new DbContextOptionsBuilder<ReadWriteDbContext>()
               .UseInMemoryDatabase(databaseName: "DeleteGroupRoleMapping").Options;

            var groupRoleMapping = new Domain.V1.Entities.UserGroups.GroupRoleMapping
            {
                Id = 1,
                Code = "test",
                GroupID = 1,
                RoleID = 1,
                Definition = "test",
                Display = "test",
                Source = "test",
                IsDeleted = false,
                CreatedBy = "Admin",
                CreatedDate = DateTime.UtcNow,
                UpdatedBy = "Admin",  // Adding the missing property
                UpdatedDate = DateTime.UtcNow,// Assuming UpdatedDate is required as well
            };



            //Arrange
            using ReadWriteDbContext dbContext = new(options);
            dbContext.GroupRoleMappings.Add(groupRoleMapping);
            await dbContext.SaveChangesAsync();

            _groupRoleMappingCommandService = new GroupRoleMappingCommandService(dbContext, _mapperMock.Object);

            // Act
            bool result = await _groupRoleMappingCommandService.DeleteGroupRoleMappingByIdAsync(groupRoleMapping);

            Assert.True(result);
        }
    }
}
