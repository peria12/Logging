﻿using Aurora.AdministrationService.API.Models.Dto.UserGroups.GroupRoleMapping;
using Aurora.AdministrationService.API.Services.Service.UserGroups.GroupRoleMapping;
using Aurora.AdministrationService.CrossCutting.CommonModels;
using Aurora.AdministrationService.Infrastructure;
using AutoMapper;
using Microsoft.EntityFrameworkCore;
using Moq;

namespace Aurora.AdministrationService.Tests.API.Services.UserGroups.GroupRoleMappings
{
    public class GroupRoleMappingQueryServiceTests
    {
        private readonly Mock<ReadOnlyDbContext> _readOnlyDbContextMock;
        private readonly Mock<IMapper> _mapperMock;
        private readonly GroupRoleMappingQueryService _groupRoleMappingQueryService;
        private Mock<DbSet<Domain.V1.Entities.UserGroups.GroupRoleMapping>> _mockDbSet;

        public GroupRoleMappingQueryServiceTests()
        {
            //Initialize mock
            _readOnlyDbContextMock = new Mock<ReadOnlyDbContext>();
            _mapperMock = new Mock<IMapper>();

            // Setup in-memory ready only database for testing
            DbContextOptions<ReadOnlyDbContext> options = new DbContextOptionsBuilder<ReadOnlyDbContext>()
              .UseInMemoryDatabase(databaseName: "GroupRoleMappingTestDB").Options;

            _readOnlyDbContextMock = new(options);

            _mockDbSet = new Mock<DbSet<Domain.V1.Entities.UserGroups.GroupRoleMapping>>();

            var data = new List<Domain.V1.Entities.UserGroups.GroupRoleMapping>
            {
               new Domain.V1.Entities.UserGroups.GroupRoleMapping {
                Id = 1,
                Code = "test",
                GroupID = 1,
                RoleID = 1,
                Definition = "test",
                Display="test",
                Source = "test",
                IsDeleted = false,
                CreatedBy = "Admin",
                CreatedDate = DateTime.UtcNow,
                UpdatedBy = "Admin",  // Adding the missing property
                UpdatedDate = DateTime.UtcNow,// Assuming UpdatedDate is required as well
            },
               new Domain.V1.Entities.UserGroups.GroupRoleMapping {
                Id = 2,
                Code = "test",
                GroupID = 1,
                RoleID = 1,
                Definition = "test",
                Display="test",
                Source = "test",
                IsDeleted = false,
                CreatedBy = "Admin",
                CreatedDate = DateTime.UtcNow,
                UpdatedBy = "Admin",  // Adding the missing property
                UpdatedDate = DateTime.UtcNow,// Assuming UpdatedDate is required as well
            }

            }.AsQueryable();


            //Setup
            _mockDbSet.As<IQueryable<Domain.V1.Entities.UserGroups.GroupRoleMapping>>().Setup(m => m.Provider).Returns(data.Provider);
            _mockDbSet.As<IQueryable<Domain.V1.Entities.UserGroups.GroupRoleMapping>>().Setup(m => m.Expression).Returns(data.Expression);
            _mockDbSet.As<IQueryable<Domain.V1.Entities.UserGroups.GroupRoleMapping>>().Setup(m => m.ElementType).Returns(data.ElementType);
            _mockDbSet.As<IQueryable<Domain.V1.Entities.UserGroups.GroupRoleMapping>>().Setup(m => m.GetEnumerator()).Returns(data.GetEnumerator());
            _readOnlyDbContextMock.Setup(c => c.GroupRoleMappings).Returns(_mockDbSet.Object);

            // Create the service instance
            _groupRoleMappingQueryService = new GroupRoleMappingQueryService(_readOnlyDbContextMock.Object, _mapperMock.Object);
        }

        [Fact]
        public async Task GetGroupRoleMappingById_LogoExists_ReturnsLogoDetailDto()
        {
            // Arrange
            var groupRoleMappingId = 1;
            var groupRoleMapping = new Domain.V1.Entities.UserGroups.GroupRoleMapping
            {
                Id = 1,
                Code = "test",
                GroupID = 1,
                RoleID = 1,
                Definition = "test",
                Display = "test",
                Source = "test",
                IsDeleted = false,
                CreatedBy = "Admin",
                CreatedDate = DateTime.UtcNow,
                UpdatedBy = "Admin",  // Adding the missing property
                UpdatedDate = DateTime.UtcNow,// Assuming UpdatedDate is required as well
            };

            var groupRoleMappingDto = new GetGroupRoleMappingDetailDto
            {
                Id = 1,
                Code = "test",
                GroupID = 1,
                RoleID = 1,
                Definition = "test",
                Display = "test",
                Source = "test",
            };

            _readOnlyDbContextMock.Setup(db => db.GroupRoleMappings.FindAsync(groupRoleMappingId))
                .ReturnsAsync(groupRoleMapping);

            _mapperMock.Setup(m => m.Map<GetGroupRoleMappingDetailDto>(groupRoleMapping))
                .Returns(groupRoleMappingDto);

            // Act
            var result = await _groupRoleMappingQueryService.GetGroupRoleMappingById(groupRoleMappingId);

            // Assert
            Assert.NotNull(result);
            Assert.Equal(groupRoleMappingId, result.Id);
            Assert.Equal("test", result.Code);
        }

        [Fact]
        public async Task GetGroupRoleMappingById_groupRoleMappingNotFound_ReturnsNull()
        {
            //Arrange
            var groupRoleMappingId = 1;
            var groupRoleMapping = new Domain.V1.Entities.UserGroups.GroupRoleMapping
            {
                Id = 1,
                Code = "test",
                GroupID = 1,
                RoleID = 1,
                Definition = "test",
                Display = "test",
                Source = "test",
                IsDeleted = false,
                CreatedBy = "Admin",
                CreatedDate = DateTime.UtcNow,
                UpdatedBy = "Admin",  // Adding the missing property
                UpdatedDate = DateTime.UtcNow,// Assuming UpdatedDate is required as well
            };

            _readOnlyDbContextMock.Setup(db => db.GroupRoleMappings.FindAsync(groupRoleMappingId))
                .ReturnsAsync(groupRoleMapping);

            //Act
            var result = await _groupRoleMappingQueryService.GetGroupRoleMappingById(groupRoleMappingId);

            //Assert
            Assert.Null(result);
        }

        [Fact]
        public async Task GetGroupRoleMappingById_groupRoleMappingExists_BindingError_ReturnsNull()
        {
            // Arrange
            byte[] concurrencyToken = new byte[8] { byte.MinValue, byte.MinValue, byte.MinValue, byte.MinValue, byte.MinValue, byte.MinValue, byte.MinValue, byte.MaxValue };
            var groupRoleMappingId = 1;
            var groupRoleMapping = new Domain.V1.Entities.UserGroups.GroupRoleMapping
            {
                Id = 1,
                Code = "test",
                GroupID = 1,
                RoleID = 1,
                Definition = "test",
                Display = "test",
                Source = "test",
                IsDeleted = false,
                CreatedBy = "Admin",
                CreatedDate = DateTime.UtcNow,
                UpdatedBy = "Admin",  // Adding the missing property
                UpdatedDate = DateTime.UtcNow,// Assuming UpdatedDate is required as well
            };

            _readOnlyDbContextMock.Setup(db => db.GroupRoleMappings.FindAsync(groupRoleMappingId))
                .ReturnsAsync(groupRoleMapping);

            _mapperMock.Setup(m => m.Map<GetGroupRoleMappingDetailDto>(groupRoleMapping))
                .Throws(new AutoMapperMappingException("Error mapping entity to DTO"));

            // Act & Assert
            var exception = await Assert.ThrowsAsync<AutoMapperMappingException>(
                () => _groupRoleMappingQueryService.GetGroupRoleMappingById(groupRoleMappingId)
            );

            Assert.Equal("Error mapping entity to DTO", exception.Message);
        }

        [Fact]
        public async Task FindGroupRoleMappingById_groupRoleMappingExists_ReturnsgroupRoleMapping()
        {
            // Arrange
            byte[] concurrencyToken = new byte[8] { byte.MinValue, byte.MinValue, byte.MinValue, byte.MinValue, byte.MinValue, byte.MinValue, byte.MinValue, byte.MaxValue };
            int groupRoleMappingId = 1;
            var groupRoleMapping = new Domain.V1.Entities.UserGroups.GroupRoleMapping
            {
                Id = groupRoleMappingId,
                Code = "test",
                GroupID = 1,
                RoleID = 1,
                Definition = "test",
                Display = "test",
                Source = "test",
                IsDeleted = false,
                CreatedBy = "Admin",
                CreatedDate = DateTime.UtcNow,
                UpdatedBy = "Admin",  // Adding the missing property
                UpdatedDate = DateTime.UtcNow,// Assuming UpdatedDate is required as well
            };

            // Mock the FindAsync method to return the groupRoleMapping
            _readOnlyDbContextMock.Setup(db => db.GroupRoleMappings.FindAsync(groupRoleMappingId))
                .ReturnsAsync(groupRoleMapping);

            // Act
            var result = await _groupRoleMappingQueryService.FindGroupRoleMappingById(groupRoleMappingId);

            // Assert
            Assert.NotNull(result);
        }

        [Fact]
        public async Task FindGroupRoleMappingById_groupRoleMappingNotFound_ReturnsNull()
        {
            // Arrange
            var groupRoleMappingId = 1;
            var groupRoleMapping = new Domain.V1.Entities.UserGroups.GroupRoleMapping
            {
                Id = groupRoleMappingId,
                Code = "test",
                GroupID = 1,
                RoleID = 1,
                Definition = "test",
                Display = "test",
                Source = "test",
                IsDeleted = false,
                CreatedBy = "Admin",
                CreatedDate = DateTime.UtcNow,
                UpdatedBy = "Admin",  // Adding the missing property
                UpdatedDate = DateTime.UtcNow,// Assuming UpdatedDate is required as well
            };

            // Mock the FindAsync method to return null (groupRoleMapping not found)
            _readOnlyDbContextMock.Setup(db => db.GroupRoleMappings.FindAsync(groupRoleMappingId))
                .ReturnsAsync(groupRoleMapping);

            // Act
            var result = await _groupRoleMappingQueryService.FindGroupRoleMappingById(groupRoleMappingId);

            // Assert
            Assert.NotNull(result);
        }

        [Fact]
        public void GetGroupRoleMappingList_ReturnsCorrectGroupRoleMappingList()
        {
            // Act
            var result = _groupRoleMappingQueryService.GetGroupRoleMappingList();

            // Assert
            Assert.NotNull(result);
            Assert.Equal(2, result.Count); // Verifying that 3 items are returned

            // Verifying that the returned items are mapped correctly
            Assert.Contains(result, r => r.Id == 1 && r.Code == "test");
            Assert.Contains(result, r => r.Id == 2 && r.Code == "test");
        }

        [Fact]
        public async Task IsGroupRoleMappingAlreadyExist_ShouldReturnTrue_WhengroupRoleMappingExists()
        {
            // Arrange
            var groupRoleMappingId = 1;
            var groupRoleMapping = new Domain.V1.Entities.UserGroups.GroupRoleMapping
            {
                Id = 1,
                Code = "test",
                GroupID = 1,
                RoleID = 1,
                Definition = "test",
                Display = "test",
                Source = "test",
                IsDeleted = false,
                CreatedBy = "Admin",
                CreatedDate = DateTime.UtcNow,
                UpdatedBy = "Admin",  // Adding the missing property
                UpdatedDate = DateTime.UtcNow,// Assuming UpdatedDate is required as well
            };

            // Mock the FindAsync method to return the groupRoleMapping
            _readOnlyDbContextMock.Setup(db => db.GroupRoleMappings.FindAsync(groupRoleMappingId))
                .ReturnsAsync(groupRoleMapping);

            // Act
            var result = await _groupRoleMappingQueryService.IsGroupRoleMappingAlreadyExist(groupRoleMappingId);

            // Assert
            Assert.True(result.result);
            Assert.Equal(ResponseMessage.STATUS_DATA_FOUND, result.message);
        }

        [Fact]
        public async Task IsGroupRoleMappingAlreadyExist_ShouldReturnFalse_WhengroupRoleMappingDoesNotExist()
        {
            // Arrange
            var groupRoleMappingId = 3;

            // Act
            var result = await _groupRoleMappingQueryService.IsGroupRoleMappingAlreadyExist(groupRoleMappingId);

            // Assert
            Assert.False(result.result);
            Assert.Equal(ResponseMessage.STATUS_NODATA, result.message);
        }
    }
}
