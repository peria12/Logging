﻿using Aurora.AdministrationService.API.Models.Dto.UserGroups.Groups;
using Aurora.AdministrationService.API.Services.Service.UserGroups.Groups;
using Aurora.AdministrationService.CrossCutting.CommonModels;
using Aurora.AdministrationService.Infrastructure;
using AutoMapper;
using Microsoft.EntityFrameworkCore;
using Moq;

namespace Aurora.AdministrationService.Tests.API.Services.UserGroups.Groups
{
    public class GroupQueryServiceTests
    {
        private readonly Mock<ReadOnlyDbContext> _readOnlyDbContextMock;
        private readonly Mock<IMapper> _mapperMock;
        private readonly GroupQueryService _groupQueryService;
        private Mock<DbSet<Domain.V1.Entities.UserGroups.Group>> _mockDbSet;

        public GroupQueryServiceTests()
        {
            //Initialize mock
            _readOnlyDbContextMock = new Mock<ReadOnlyDbContext>();
            _mapperMock = new Mock<IMapper>();

            // Setup in-memory ready only database for testing
            DbContextOptions<ReadOnlyDbContext> options = new DbContextOptionsBuilder<ReadOnlyDbContext>()
              .UseInMemoryDatabase(databaseName: "GroupTestDB").Options;

            _readOnlyDbContextMock = new(options);

            _mockDbSet = new Mock<DbSet<Domain.V1.Entities.UserGroups.Group>>();

            var data = new List<Domain.V1.Entities.UserGroups.Group>
            {
               new Domain.V1.Entities.UserGroups.Group {
                Id = 1,
                Code = "test",
                IsObsolete = true,
                GroupName ="test",
                Definition="test",
                Display="test",
                Source = "test",
                IsDeleted = false,
                CreatedBy = "Admin",
                CreatedDate = DateTime.UtcNow,
                UpdatedBy = "Admin",  // Adding the missing property
                UpdatedDate = DateTime.UtcNow,// Assuming UpdatedDate is required as well
            },
               new Domain.V1.Entities.UserGroups.Group {
                Id = 2,
                Code = "test",
                IsObsolete = true,
                GroupName ="test",
                Definition="test",
                Display="test",
                Source = "test",
                IsDeleted = false,
                CreatedBy = "Admin",
                CreatedDate = DateTime.UtcNow,
                UpdatedBy = "Admin",  // Adding the missing property
                UpdatedDate = DateTime.UtcNow,// Assuming UpdatedDate is required as well
            }

            }.AsQueryable();


            //Setup
            _mockDbSet.As<IQueryable<Domain.V1.Entities.UserGroups.Group>>().Setup(m => m.Provider).Returns(data.Provider);
            _mockDbSet.As<IQueryable<Domain.V1.Entities.UserGroups.Group>>().Setup(m => m.Expression).Returns(data.Expression);
            _mockDbSet.As<IQueryable<Domain.V1.Entities.UserGroups.Group>>().Setup(m => m.ElementType).Returns(data.ElementType);
            _mockDbSet.As<IQueryable<Domain.V1.Entities.UserGroups.Group>>().Setup(m => m.GetEnumerator()).Returns(data.GetEnumerator());
            _readOnlyDbContextMock.Setup(c => c.Groups).Returns(_mockDbSet.Object);

            // Create the service instance
            _groupQueryService = new GroupQueryService(_readOnlyDbContextMock.Object, _mapperMock.Object);
        }

        [Fact]
        public async Task GetGroupById_LogoExists_ReturnsLogoDetailDto()
        {
            // Arrange
            var groupId = 1;
            var group = new Domain.V1.Entities.UserGroups.Group
            {
                Id = 1,
                Code = "test",
                IsObsolete = true,
                GroupName = "test",
                Definition = "test",
                Display = "test",
                Source = "test",
                IsDeleted = false,
                CreatedBy = "Admin",
                CreatedDate = DateTime.UtcNow,
                UpdatedBy = "Admin",  // Adding the missing property
                UpdatedDate = DateTime.UtcNow,// Assuming UpdatedDate is required as well
            };

            var groupDto = new GetGroupDetailDto
            {
                Id = 1,
                Code = "test",
                IsObsolete = true,
                GroupName = "test",
                Definition = "test",
                Display = "test",
                Source = "test",
            };

            _readOnlyDbContextMock.Setup(db => db.Groups.FindAsync(groupId))
                .ReturnsAsync(group);

            _mapperMock.Setup(m => m.Map<GetGroupDetailDto>(group))
                .Returns(groupDto);

            // Act
            var result = await _groupQueryService.GetGroupById(groupId);

            // Assert
            Assert.NotNull(result);
            Assert.Equal(groupId, result.Id);
            Assert.Equal("test", result.Code);
        }

        [Fact]
        public async Task GetGroupById_groupNotFound_ReturnsNull()
        {
            //Arrange
            var groupId = 1;
            var group = new Domain.V1.Entities.UserGroups.Group
            {
                Id = 1,
                Code = "test",
                IsObsolete = true,
                GroupName = "test",
                Definition = "test",
                Display = "test",
                Source = "test",
                IsDeleted = false,
                CreatedBy = "Admin",
                CreatedDate = DateTime.UtcNow,
                UpdatedBy = "Admin",  // Adding the missing property
                UpdatedDate = DateTime.UtcNow,// Assuming UpdatedDate is required as well
            };

            _readOnlyDbContextMock.Setup(db => db.Groups.FindAsync(groupId))
                .ReturnsAsync(group);

            //Act
            var result = await _groupQueryService.GetGroupById(groupId);

            //Assert
            Assert.Null(result);
        }

        [Fact]
        public async Task GetGroupById_groupExists_BindingError_ReturnsNull()
        {
            // Arrange
            byte[] concurrencyToken = new byte[8] { byte.MinValue, byte.MinValue, byte.MinValue, byte.MinValue, byte.MinValue, byte.MinValue, byte.MinValue, byte.MaxValue };
            var groupId = 1;
            var group = new Domain.V1.Entities.UserGroups.Group
            {
                Id = 1,
                Code = "test",
                IsObsolete = true,
                GroupName = "test",
                Definition = "test",
                Display = "test",
                Source = "test",
                IsDeleted = false,
                CreatedBy = "Admin",
                CreatedDate = DateTime.UtcNow,
                UpdatedBy = "Admin",  // Adding the missing property
                UpdatedDate = DateTime.UtcNow,// Assuming UpdatedDate is required as well
            };

            _readOnlyDbContextMock.Setup(db => db.Groups.FindAsync(groupId))
                .ReturnsAsync(group);

            _mapperMock.Setup(m => m.Map<GetGroupDetailDto>(group))
                .Throws(new AutoMapperMappingException("Error mapping entity to DTO"));

            // Act & Assert
            var exception = await Assert.ThrowsAsync<AutoMapperMappingException>(
                () => _groupQueryService.GetGroupById(groupId)
            );

            Assert.Equal("Error mapping entity to DTO", exception.Message);
        }

        [Fact]
        public async Task FindGroupById_groupExists_Returnsgroup()
        {
            // Arrange
            byte[] concurrencyToken = new byte[8] { byte.MinValue, byte.MinValue, byte.MinValue, byte.MinValue, byte.MinValue, byte.MinValue, byte.MinValue, byte.MaxValue };
            int groupId = 1;
            var group = new Domain.V1.Entities.UserGroups.Group
            {
                Id = groupId,
                Code = "test",
                IsObsolete = true,
                GroupName = "test",
                Definition = "test",
                Display = "test",
                Source = "test",
                IsDeleted = false,
                CreatedBy = "Admin",
                CreatedDate = DateTime.UtcNow,
                UpdatedBy = "Admin",  // Adding the missing property
                UpdatedDate = DateTime.UtcNow,// Assuming UpdatedDate is required as well
            };

            // Mock the FindAsync method to return the group
            _readOnlyDbContextMock.Setup(db => db.Groups.FindAsync(groupId))
                .ReturnsAsync(group);

            // Act
            var result = await _groupQueryService.FindGroupById(groupId);

            // Assert
            Assert.NotNull(result);
        }

        [Fact]
        public async Task FindGroupById_groupNotFound_ReturnsNull()
        {
            // Arrange
            var groupId = 1;
            var group = new Domain.V1.Entities.UserGroups.Group
            {
                Id = groupId,
                Code = "test",
                IsObsolete = true,
                GroupName = "test",
                Definition = "test",
                Display = "test",
                Source = "test",
                IsDeleted = false,
                CreatedBy = "Admin",
                CreatedDate = DateTime.UtcNow,
                UpdatedBy = "Admin",  // Adding the missing property
                UpdatedDate = DateTime.UtcNow,// Assuming UpdatedDate is required as well
            };

            // Mock the FindAsync method to return null (group not found)
            _readOnlyDbContextMock.Setup(db => db.Groups.FindAsync(groupId))
                .ReturnsAsync(group);

            // Act
            var result = await _groupQueryService.FindGroupById(groupId);

            // Assert
            Assert.NotNull(result);
        }

        [Fact]
        public async void GetGroupList_ReturnsCorrectGroupList()
        {
            // Act
            var result = await _groupQueryService.GetGroupList();

            // Assert
            Assert.NotNull(result);
            Assert.Equal(2, result.Count); // Verifying that 3 items are returned

            // Verifying that the returned items are mapped correctly
            Assert.Contains(result, r => r.Id == 1 && r.Code == "test");
            Assert.Contains(result, r => r.Id == 2 && r.Code == "test");
        }
        [Fact]
        public async void GetGroupMasters_ReturnsCorrectGroupList()
        {
            // Act
            var result = await _groupQueryService.GetGroupMasters();

            // Assert
            Assert.NotNull(result);
            Assert.Equal(2, result.Count); // Verifying that 3 items are returned

            // Verifying that the returned items are mapped correctly
            Assert.Contains(result, r => r.Id == 1 && r.Code == "test");
            Assert.Contains(result, r => r.Id == 2 && r.Code == "test");
        }

        [Fact]
        public async Task IsGroupAlreadyExist_ShouldReturnTrue_WhengroupExists()
        {
            // Arrange
            var groupId = 1;
            var group = new Domain.V1.Entities.UserGroups.Group
            {
                Id = 1,
                Code = "test",
                IsObsolete = true,
                GroupName = "test",
                Definition = "test",
                Display = "test",
                Source = "test",
                IsDeleted = false,
                CreatedBy = "Admin",
                CreatedDate = DateTime.UtcNow,
                UpdatedBy = "Admin",  // Adding the missing property
                UpdatedDate = DateTime.UtcNow,// Assuming UpdatedDate is required as well
            };

            // Mock the FindAsync method to return the group
            _readOnlyDbContextMock.Setup(db => db.Groups.FindAsync(groupId))
                .ReturnsAsync(group);

            // Act
            var result = await _groupQueryService.IsGroupAlreadyExist(groupId);

            // Assert
            Assert.True(result.result);
            Assert.Equal(ResponseMessage.STATUS_DATA_FOUND, result.message);
        }

        [Fact]
        public async Task IsGroupAlreadyExist_ShouldReturnFalse_WhengroupDoesNotExist()
        {
            // Arrange
            var groupId = 3;

            // Act
            var result = await _groupQueryService.IsGroupAlreadyExist(groupId);

            // Assert
            Assert.False(result.result);
            Assert.Equal(ResponseMessage.STATUS_NODATA, result.message);
        }
    }
}
