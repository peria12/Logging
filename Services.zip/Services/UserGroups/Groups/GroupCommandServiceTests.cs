﻿using Aurora.AdministrationService.API.Models.Dto.UserGroups.Groups;
using Aurora.AdministrationService.API.Services.Service.UserGroups.Groups;
using Aurora.AdministrationService.Infrastructure;
using AutoMapper;
using Microsoft.EntityFrameworkCore;
using Moq;

namespace Aurora.AdministrationService.Tests.API.Services.UserGroups.Groups
{
    public class GroupCommandServiceTests
    {
        private readonly Mock<ReadWriteDbContext> _readWriteDbContextMock;
        private readonly Mock<ReadOnlyDbContext> _readOnlyDbContextMock;
        private readonly Mock<IMapper> _mapperMock;
        private GroupCommandService _groupCommandService;
        private readonly Mock<GroupQueryService> _groupQueryService;

        public GroupCommandServiceTests()
        {
            // Initialize the mocks
            _mapperMock = new Mock<IMapper>();
            _readWriteDbContextMock = new Mock<ReadWriteDbContext>();
            _readOnlyDbContextMock = new Mock<ReadOnlyDbContext>();
            _groupQueryService = new Mock<GroupQueryService>();


            // Setup in-memory ready only database for testing
            DbContextOptions<ReadWriteDbContext> options = new DbContextOptionsBuilder<ReadWriteDbContext>()
              .UseInMemoryDatabase(databaseName: "AdminGroupTestDB").Options;

            _readWriteDbContextMock = new(options);

            // Initialize the service being tested
            _groupCommandService = new GroupCommandService(_readWriteDbContextMock.Object, _mapperMock.Object);
        }

        [Fact]
        public async Task CreateGroupAsync_ShouldReturnTrue_WhenGroupIsCreatedSuccessfully()
        {
            // Arrange
            var newGroup = new GroupDto
            {
                Code = "test",
                IsObsolete = true,
                GroupName = "test",
                Definition = "test",
                Display = "test",
                Source = "test",
            };

            // Mock AutoMapper to return a Group entity
            var groupEntity = new Domain.V1.Entities.UserGroups.Group
            {
                Code = "test",
                IsObsolete = true,
                GroupName = "test",
                Definition = "test",
                Display = "test",
                Source = "test",
                IsDeleted = false,
                CreatedBy = "Admin",
                CreatedDate = DateTime.UtcNow,
                UpdatedBy = "Admin",  // Adding the missing property
                UpdatedDate = DateTime.UtcNow,// Assuming UpdatedDate is required as well
            };


            // Mock AutoMapper to return the Group entity
            _mapperMock.Setup(m => m.Map<Domain.V1.Entities.UserGroups.Group>(newGroup)).Returns(groupEntity);

            // Mock DbContext to simulate saving the entity without actually hitting the database
            _readWriteDbContextMock.Setup(db => db.Groups.Add(It.IsAny<Domain.V1.Entities.UserGroups.Group>()));

            // Act
            var result = await _groupCommandService.CreateGroupAsync(newGroup);

            // Assert
            Assert.True(result);
            _readWriteDbContextMock.Verify(db => db.Groups.Add(It.Is<Domain.V1.Entities.UserGroups.Group>(l => l.Source == "test")), Times.Once);
        }


        [Fact]
        public async Task CreateGroupAsync_ShouldReturnFalse_WhenExceptionOccurs()
        {
            // Arrange
            var newGroup = new GroupDto
            {
                Code = "test",
                IsObsolete = true,
                GroupName = "test",
                Definition = "test",
                Display = "test",
                Source = "test",
            };

            // Mock AutoMapper to return a Group entity
            var groupId = 1;
            var groupEntity = new Domain.V1.Entities.UserGroups.Group
            {
                Id = groupId,
                Code = "test",
                IsObsolete = true,
                GroupName = "test",
                Definition = "test",
                Display = "test",
                Source = "test",
                IsDeleted = false,
                CreatedBy = "Admin",
                CreatedDate = DateTime.UtcNow,
                UpdatedBy = "Admin",  // Adding the missing property
                UpdatedDate = DateTime.UtcNow,// Assuming UpdatedDate is required as well
            };

            //Setup
            _mapperMock.Setup(m => m.Map<Domain.V1.Entities.UserGroups.Group>(newGroup)).Returns(groupEntity);

            // Act
            var result = await _groupCommandService.CreateGroupAsync(newGroup);

            // Assert
            Assert.False(result);
        }
        [Fact]
        public async Task Test_UpdateGroup_Returns_Success()
        {
            //Arrange
            DbContextOptions<ReadWriteDbContext> options = new DbContextOptionsBuilder<ReadWriteDbContext>()
               .UseInMemoryDatabase(databaseName: "UpdateGroup").Options;

            byte[] concurrencyToken = new byte[8] { byte.MinValue, byte.MinValue, byte.MinValue, byte.MinValue, byte.MinValue, byte.MinValue, byte.MinValue, byte.MaxValue };
            var group = new Domain.V1.Entities.UserGroups.Group
            {
                Id = 1,
                Code = "test",
                IsObsolete = true,
                GroupName = "test",
                Definition = "test",
                Display = "test",
                Source = "test",
                IsDeleted = false,
                CreatedBy = "Admin",
                CreatedDate = DateTime.UtcNow,
                UpdatedBy = "Admin",  // Adding the missing property
                UpdatedDate = DateTime.UtcNow,// Assuming UpdatedDate is required as well
            };


            //Arrange
            using ReadWriteDbContext dbContext = new(options);
            dbContext.Groups.Add(group);
            await dbContext.SaveChangesAsync();


            UpdateGroupRequest updateModel = new UpdateGroupRequest
            {
                Id = 1,
                Code = "test",
                IsObsolete = true,
                GroupName = "test",
                Definition = "test",
                Display = "test",
                Source = "test",
            };

            _groupCommandService = new GroupCommandService(dbContext, _mapperMock.Object);

            // Act
            bool result = await _groupCommandService.UpdateGroupAsync(updateModel, group);

            Assert.True(result);
        }
        [Fact]
        public async Task Test_DeleteGroup_Returns_Success()
        {
            //Arrange
            DbContextOptions<ReadWriteDbContext> options = new DbContextOptionsBuilder<ReadWriteDbContext>()
               .UseInMemoryDatabase(databaseName: "DeleteGroup").Options;

            var group = new Domain.V1.Entities.UserGroups.Group
            {
                Id = 1,
                Code = "test",
                IsObsolete = true,
                GroupName = "test",
                Definition = "test",
                Display = "test",
                Source = "test",
                IsDeleted = false,
                CreatedBy = "Admin",
                CreatedDate = DateTime.UtcNow,
                UpdatedBy = "Admin",  // Adding the missing property
                UpdatedDate = DateTime.UtcNow,// Assuming UpdatedDate is required as well
            };



            //Arrange
            using ReadWriteDbContext dbContext = new(options);
            dbContext.Groups.Add(group);
            await dbContext.SaveChangesAsync();

            _groupCommandService = new GroupCommandService(dbContext, _mapperMock.Object);

            // Act
            bool result = await _groupCommandService.DeleteGroupByIdAsync( group);

            Assert.True(result);
        }
    }
}
