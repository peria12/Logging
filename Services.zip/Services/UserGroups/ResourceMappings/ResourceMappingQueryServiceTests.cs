﻿using Aurora.AdministrationService.API.Models.Dto.UserGroups.ResourceMapping;
using Aurora.AdministrationService.API.Services.Service.UserGroups.ResourceMapping;
using Aurora.AdministrationService.CrossCutting.CommonModels;
using Aurora.AdministrationService.Infrastructure;
using AutoMapper;
using Microsoft.EntityFrameworkCore;
using Moq;

namespace Aurora.AdministrationService.Tests.API.Services.UserGroups.ResourceMappings
{
    public class ResourceMappingQueryServiceTests
    {
        private readonly Mock<ReadOnlyDbContext> _readOnlyDbContextMock;
        private readonly Mock<IMapper> _mapperMock;
        private readonly ResourceMappingQueryService _resourceMappingQueryService;
        private Mock<DbSet<Domain.V1.Entities.UserGroups.ResourceMapping>> _mockDbSet;

        public ResourceMappingQueryServiceTests()
        {
            //Initialize mock
            _readOnlyDbContextMock = new Mock<ReadOnlyDbContext>();
            _mapperMock = new Mock<IMapper>();

            // Setup in-memory ready only database for testing
            DbContextOptions<ReadOnlyDbContext> options = new DbContextOptionsBuilder<ReadOnlyDbContext>()
              .UseInMemoryDatabase(databaseName: "ResourceMappingTestDB").Options;

            _readOnlyDbContextMock = new(options);

            _mockDbSet = new Mock<DbSet<Domain.V1.Entities.UserGroups.ResourceMapping>>();

            var data = new List<Domain.V1.Entities.UserGroups.ResourceMapping>
            {
               new Domain.V1.Entities.UserGroups.ResourceMapping {
                Id = 1,
                Code = "test",
                ParentID=1,
                IsScreenRequired = true,
                ResourceName = "test",
                CategoryID = 1,
                CSS="test",
                ControllerAction="test",
                Definition="test",
                Display="test",
                ICON="test",
                ResourceTypeID=1,
                SEQ=1,
                SubCategoryID=1,
                URL="test",
                Source = "test",
                IsDeleted = false,
                CreatedBy = "Admin",
                CreatedDate = DateTime.UtcNow,
                UpdatedBy = "Admin",  // Adding the missing property
                UpdatedDate = DateTime.UtcNow,// Assuming UpdatedDate is required as well
            },
               new Domain.V1.Entities.UserGroups.ResourceMapping {
                Id = 2,
                Code = "test",
                ParentID=1,
                IsScreenRequired = true,
                ResourceName = "test",
                CategoryID = 1,
                CSS="test",
                ControllerAction="test",
                Definition="test",
                Display="test",
                ICON="test",
                ResourceTypeID=1,
                SEQ=1,
                SubCategoryID=1,
                URL="test",
                Source = "test",
                IsDeleted = false,
                CreatedBy = "Admin",
                CreatedDate = DateTime.UtcNow,
                UpdatedBy = "Admin",  // Adding the missing property
                UpdatedDate = DateTime.UtcNow,// Assuming UpdatedDate is required as well
            }

            }.AsQueryable();


            //Setup
            _mockDbSet.As<IQueryable<Domain.V1.Entities.UserGroups.ResourceMapping>>().Setup(m => m.Provider).Returns(data.Provider);
            _mockDbSet.As<IQueryable<Domain.V1.Entities.UserGroups.ResourceMapping>>().Setup(m => m.Expression).Returns(data.Expression);
            _mockDbSet.As<IQueryable<Domain.V1.Entities.UserGroups.ResourceMapping>>().Setup(m => m.ElementType).Returns(data.ElementType);
            _mockDbSet.As<IQueryable<Domain.V1.Entities.UserGroups.ResourceMapping>>().Setup(m => m.GetEnumerator()).Returns(data.GetEnumerator());
            _readOnlyDbContextMock.Setup(c => c.ResourceMappings).Returns(_mockDbSet.Object);

            // Create the service instance
            _resourceMappingQueryService = new ResourceMappingQueryService(_readOnlyDbContextMock.Object, _mapperMock.Object);
        }

        [Fact]
        public async Task GetResourceMappingById_LogoExists_ReturnsLogoDetailDto()
        {
            // Arrange
            var resourceMappingId = 1;
            var resourceMapping = new Domain.V1.Entities.UserGroups.ResourceMapping
            {
                Id = 1,
                Code = "test",
                ParentID = 1,
                IsScreenRequired = true,
                ResourceName = "test",
                CategoryID = 1,
                CSS = "test",
                ControllerAction = "test",
                Definition = "test",
                Display = "test",
                ICON = "test",
                ResourceTypeID = 1,
                SEQ = 1,
                SubCategoryID = 1,
                URL = "test",
                Source = "test",
                IsDeleted = false,
                CreatedBy = "Admin",
                CreatedDate = DateTime.UtcNow,
                UpdatedBy = "Admin",  // Adding the missing property
                UpdatedDate = DateTime.UtcNow,// Assuming UpdatedDate is required as well
            };

            var resourceMappingDto = new GetResourceMappingDetailDto
            {
                Id = 1,
                Code = "test",
                ParentID = 1,
                IsScreenRequired = true,
                ResourceName = "test",
                CategoryID = 1,
                CSS = "test",
                ControllerAction = "test",
                Definition = "test",
                Display = "test",
                ICON = "test",
                ResourceTypeID = 1,
                SEQ = 1,
                SubCategoryID = 1,
                URL = "test",
                Source = "test",
            };

            _readOnlyDbContextMock.Setup(db => db.ResourceMappings.FindAsync(resourceMappingId))
                .ReturnsAsync(resourceMapping);

            _mapperMock.Setup(m => m.Map<GetResourceMappingDetailDto>(resourceMapping))
                .Returns(resourceMappingDto);

            // Act
            var result = await _resourceMappingQueryService.GetResourceMappingById(resourceMappingId);

            // Assert
            Assert.NotNull(result);
            Assert.Equal(resourceMappingId, result.Id);
            Assert.Equal("test", result.Code);
        }

        [Fact]
        public async Task GetResourceMappingById_resourceMappingNotFound_ReturnsNull()
        {
            //Arrange
            var resourceMappingId = 1;
            var resourceMapping = new Domain.V1.Entities.UserGroups.ResourceMapping
            {
                Id = 1,
                Code = "test",
                ParentID = 1,
                IsScreenRequired = true,
                ResourceName = "test",
                CategoryID = 1,
                CSS = "test",
                ControllerAction = "test",
                Definition = "test",
                Display = "test",
                ICON = "test",
                ResourceTypeID = 1,
                SEQ = 1,
                SubCategoryID = 1,
                URL = "test",
                Source = "test",
                IsDeleted = false,
                CreatedBy = "Admin",
                CreatedDate = DateTime.UtcNow,
                UpdatedBy = "Admin",  // Adding the missing property
                UpdatedDate = DateTime.UtcNow,// Assuming UpdatedDate is required as well
            };

            _readOnlyDbContextMock.Setup(db => db.ResourceMappings.FindAsync(resourceMappingId))
                .ReturnsAsync(resourceMapping);

            //Act
            var result = await _resourceMappingQueryService.GetResourceMappingById(resourceMappingId);

            //Assert
            Assert.Null(result);
        }

        [Fact]
        public async Task GetResourceMappingById_resourceMappingExists_BindingError_ReturnsNull()
        {
            // Arrange
            byte[] concurrencyToken = new byte[8] { byte.MinValue, byte.MinValue, byte.MinValue, byte.MinValue, byte.MinValue, byte.MinValue, byte.MinValue, byte.MaxValue };
            var resourceMappingId = 1;
            var resourceMapping = new Domain.V1.Entities.UserGroups.ResourceMapping
            {
                Id = 1,
                Code = "test",
                ParentID = 1,
                IsScreenRequired = true,
                ResourceName = "test",
                CategoryID = 1,
                CSS = "test",
                ControllerAction = "test",
                Definition = "test",
                Display = "test",
                ICON = "test",
                ResourceTypeID = 1,
                SEQ = 1,
                SubCategoryID = 1,
                URL = "test",
                Source = "test",
                IsDeleted = false,
                CreatedBy = "Admin",
                CreatedDate = DateTime.UtcNow,
                UpdatedBy = "Admin",  // Adding the missing property
                UpdatedDate = DateTime.UtcNow,// Assuming UpdatedDate is required as well
            };

            _readOnlyDbContextMock.Setup(db => db.ResourceMappings.FindAsync(resourceMappingId))
                .ReturnsAsync(resourceMapping);

            _mapperMock.Setup(m => m.Map<GetResourceMappingDetailDto>(resourceMapping))
                .Throws(new AutoMapperMappingException("Error mapping entity to DTO"));

            // Act & Assert
            var exception = await Assert.ThrowsAsync<AutoMapperMappingException>(
                () => _resourceMappingQueryService.GetResourceMappingById(resourceMappingId)
            );

            Assert.Equal("Error mapping entity to DTO", exception.Message);
        }

        [Fact]
        public async Task FindResourceMappingById_resourceMappingExists_ReturnsresourceMapping()
        {
            // Arrange
            byte[] concurrencyToken = new byte[8] { byte.MinValue, byte.MinValue, byte.MinValue, byte.MinValue, byte.MinValue, byte.MinValue, byte.MinValue, byte.MaxValue };
            int resourceMappingId = 1;
            var resourceMapping = new Domain.V1.Entities.UserGroups.ResourceMapping
            {
                Id = resourceMappingId,
                Code = "test",
                ParentID = 1,
                IsScreenRequired = true,
                ResourceName = "test",
                CategoryID = 1,
                CSS = "test",
                ControllerAction = "test",
                Definition = "test",
                Display = "test",
                ICON = "test",
                ResourceTypeID = 1,
                SEQ = 1,
                SubCategoryID = 1,
                URL = "test",
                Source = "test",
                IsDeleted = false,
                CreatedBy = "Admin",
                CreatedDate = DateTime.UtcNow,
                UpdatedBy = "Admin",  // Adding the missing property
                UpdatedDate = DateTime.UtcNow,// Assuming UpdatedDate is required as well
            };

            // Mock the FindAsync method to return the resourceMapping
            _readOnlyDbContextMock.Setup(db => db.ResourceMappings.FindAsync(resourceMappingId))
                .ReturnsAsync(resourceMapping);

            // Act
            var result = await _resourceMappingQueryService.FindResourceMappingById(resourceMappingId);

            // Assert
            Assert.NotNull(result);
        }

        [Fact]
        public async Task FindResourceMappingById_resourceMappingNotFound_ReturnsNull()
        {
            // Arrange
            var resourceMappingId = 1;
            var resourceMapping = new Domain.V1.Entities.UserGroups.ResourceMapping
            {
                Id = resourceMappingId,
                Code = "test",
                ParentID = 1,
                IsScreenRequired = true,
                ResourceName = "test",
                CategoryID = 1,
                CSS = "test",
                ControllerAction = "test",
                Definition = "test",
                Display = "test",
                ICON = "test",
                ResourceTypeID = 1,
                SEQ = 1,
                SubCategoryID = 1,
                URL = "test",
                Source = "test",
                IsDeleted = false,
                CreatedBy = "Admin",
                CreatedDate = DateTime.UtcNow,
                UpdatedBy = "Admin",  // Adding the missing property
                UpdatedDate = DateTime.UtcNow,// Assuming UpdatedDate is required as well
            };

            // Mock the FindAsync method to return null (resourceMapping not found)
            _readOnlyDbContextMock.Setup(db => db.ResourceMappings.FindAsync(resourceMappingId))
                .ReturnsAsync(resourceMapping);

            // Act
            var result = await _resourceMappingQueryService.FindResourceMappingById(resourceMappingId);

            // Assert
            Assert.NotNull(result);
        }

        [Fact]
        public void GetResourceMappingList_ReturnsCorrectResourceMappingList()
        {
            // Act
            var result = _resourceMappingQueryService.GetResourceMappingList();

            // Assert
            Assert.NotNull(result);
            Assert.Equal(2, result.Count); // Verifying that 3 items are returned

            // Verifying that the returned items are mapped correctly
            Assert.Contains(result, r => r.Id == 1 && r.Code == "test");
            Assert.Contains(result, r => r.Id == 2 && r.Code == "test");
        }

        [Fact]
        public async Task IsResourceMappingAlreadyExist_ShouldReturnTrue_WhenresourceMappingExists()
        {
            // Arrange
            var resourceMappingId = 1;
            var resourceMapping = new Domain.V1.Entities.UserGroups.ResourceMapping
            {
                Id = 1,
                Code = "test",
                ParentID = 1,
                IsScreenRequired = true,
                ResourceName = "test",
                CategoryID = 1,
                CSS = "test",
                ControllerAction = "test",
                Definition = "test",
                Display = "test",
                ICON = "test",
                ResourceTypeID = 1,
                SEQ = 1,
                SubCategoryID = 1,
                URL = "test",
                Source = "test",
                IsDeleted = false,
                CreatedBy = "Admin",
                CreatedDate = DateTime.UtcNow,
                UpdatedBy = "Admin",  // Adding the missing property
                UpdatedDate = DateTime.UtcNow,// Assuming UpdatedDate is required as well
            };

            // Mock the FindAsync method to return the resourceMapping
            _readOnlyDbContextMock.Setup(db => db.ResourceMappings.FindAsync(resourceMappingId))
                .ReturnsAsync(resourceMapping);

            // Act
            var result = await _resourceMappingQueryService.IsResourceMappingAlreadyExist(resourceMappingId);

            // Assert
            Assert.True(result.result);
            Assert.Equal(ResponseMessage.STATUS_DATA_FOUND, result.message);
        }

        [Fact]
        public async Task IsResourceMappingAlreadyExist_ShouldReturnFalse_WhenresourceMappingDoesNotExist()
        {
            // Arrange
            var resourceMappingId = 3;

            // Act
            var result = await _resourceMappingQueryService.IsResourceMappingAlreadyExist(resourceMappingId);

            // Assert
            Assert.False(result.result);
            Assert.Equal(ResponseMessage.STATUS_NODATA, result.message);
        }
    }
}
