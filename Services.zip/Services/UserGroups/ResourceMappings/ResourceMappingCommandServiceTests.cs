﻿using Aurora.AdministrationService.API.Models.Dto.UserGroups.ResourceMapping;
using Aurora.AdministrationService.API.Services.Service.UserGroups.ResourceMapping;
using Aurora.AdministrationService.Infrastructure;
using AutoMapper;
using Microsoft.EntityFrameworkCore;
using Moq;

namespace Aurora.AdministrationService.Tests.API.Services.UserGroups.ResourceMappings
{
    public class ResourceMappingCommandServiceTests
    {
        private readonly Mock<ReadWriteDbContext> _readWriteDbContextMock;
        private readonly Mock<ReadOnlyDbContext> _readOnlyDbContextMock;
        private readonly Mock<IMapper> _mapperMock;
        private ResourceMappingCommandService _resourceMappingCommandService;
        private readonly Mock<ResourceMappingQueryService> _resourceMappingQueryService;

        public ResourceMappingCommandServiceTests()
        {
            // Initialize the mocks
            _mapperMock = new Mock<IMapper>();
            _readWriteDbContextMock = new Mock<ReadWriteDbContext>();
            _readOnlyDbContextMock = new Mock<ReadOnlyDbContext>();
            _resourceMappingQueryService = new Mock<ResourceMappingQueryService>();


            // Setup in-memory ready only database for testing
            DbContextOptions<ReadWriteDbContext> options = new DbContextOptionsBuilder<ReadWriteDbContext>()
              .UseInMemoryDatabase(databaseName: "AdminResourceMappingTestDB").Options;

            _readWriteDbContextMock = new(options);

            // Initialize the service being tested
            _resourceMappingCommandService = new ResourceMappingCommandService(_readWriteDbContextMock.Object, _mapperMock.Object);
        }

        [Fact]
        public async Task CreateResourceMappingAsync_ShouldReturnTrue_WhenResourceMappingIsCreatedSuccessfully()
        {
            // Arrange
            var newResourceMapping = new ResourceMappingDto
            {
                Code = "test",
                ParentID = 1,
                IsScreenRequired = true,
                ResourceName = "test",
                CategoryID = 1,
                CSS = "test",
                ControllerAction = "test",
                Definition = "test",
                Display = "test",
                ICON = "test",
                ResourceTypeID = 1,
                SEQ = 1,
                SubCategoryID = 1,
                URL = "test",
                Source = "test",
            };

            // Mock AutoMapper to return a ResourceMapping entity
            var resourceMappingEntity = new Domain.V1.Entities.UserGroups.ResourceMapping
            {
                Code = "test",
                ParentID = 1,
                IsScreenRequired = true,
                ResourceName = "test",
                CategoryID = 1,
                CSS = "test",
                ControllerAction = "test",
                Definition = "test",
                Display = "test",
                ICON = "test",
                ResourceTypeID = 1,
                SEQ = 1,
                SubCategoryID = 1,
                URL = "test",
                Source = "test",
                IsDeleted = false,
                CreatedBy = "Admin",
                CreatedDate = DateTime.UtcNow,
                UpdatedBy = "Admin",  // Adding the missing property
                UpdatedDate = DateTime.UtcNow,// Assuming UpdatedDate is required as well
            };


            // Mock AutoMapper to return the ResourceMapping entity
            _mapperMock.Setup(m => m.Map<Domain.V1.Entities.UserGroups.ResourceMapping>(newResourceMapping)).Returns(resourceMappingEntity);

            // Mock DbContext to simulate saving the entity without actually hitting the database
            _readWriteDbContextMock.Setup(db => db.ResourceMappings.Add(It.IsAny<Domain.V1.Entities.UserGroups.ResourceMapping>()));

            // Act
            var result = await _resourceMappingCommandService.CreateResourceMappingAsync(newResourceMapping);

            // Assert
            Assert.True(result);
            _readWriteDbContextMock.Verify(db => db.ResourceMappings.Add(It.Is<Domain.V1.Entities.UserGroups.ResourceMapping>(l => l.Source == "test")), Times.Once);
        }


        [Fact]
        public async Task CreateResourceMappingAsync_ShouldReturnFalse_WhenExceptionOccurs()
        {
            // Arrange
            var newResourceMapping = new ResourceMappingDto
            {
                Code = "test",
                ParentID = 1,
                IsScreenRequired = true,
                ResourceName = "test",
                CategoryID = 1,
                CSS = "test",
                ControllerAction = "test",
                Definition = "test",
                Display = "test",
                ICON = "test",
                ResourceTypeID = 1,
                SEQ = 1,
                SubCategoryID = 1,
                URL = "test",
                Source = "test",
            };

            // Mock AutoMapper to return a ResourceMapping entity
            var resourceMappingId = 1;
            var resourceMappingEntity = new Domain.V1.Entities.UserGroups.ResourceMapping
            {
                Id = resourceMappingId,
                Code = "test",
                ParentID = 1,
                IsScreenRequired = true,
                ResourceName = "test",
                CategoryID = 1,
                CSS = "test",
                ControllerAction = "test",
                Definition = "test",
                Display = "test",
                ICON = "test",
                ResourceTypeID = 1,
                SEQ = 1,
                SubCategoryID = 1,
                URL = "test",
                Source = "test",
                IsDeleted = false,
                CreatedBy = "Admin",
                CreatedDate = DateTime.UtcNow,
                UpdatedBy = "Admin",  // Adding the missing property
                UpdatedDate = DateTime.UtcNow,// Assuming UpdatedDate is required as well
            };

            //Setup
            _mapperMock.Setup(m => m.Map<Domain.V1.Entities.UserGroups.ResourceMapping>(newResourceMapping)).Returns(resourceMappingEntity);

            // Act
            var result = await _resourceMappingCommandService.CreateResourceMappingAsync(newResourceMapping);

            // Assert
            Assert.False(result);
        }
        [Fact]
        public async Task Test_UpdateResourceMapping_Returns_Success()
        {
            //Arrange
            DbContextOptions<ReadWriteDbContext> options = new DbContextOptionsBuilder<ReadWriteDbContext>()
               .UseInMemoryDatabase(databaseName: "UpdateResourceMapping").Options;

            byte[] concurrencyToken = new byte[8] { byte.MinValue, byte.MinValue, byte.MinValue, byte.MinValue, byte.MinValue, byte.MinValue, byte.MinValue, byte.MaxValue };
            var resourceMapping = new Domain.V1.Entities.UserGroups.ResourceMapping
            {
                Id = 1,
                Code = "test",
                ParentID = 1,
                IsScreenRequired = true,
                ResourceName = "test",
                CategoryID = 1,
                CSS = "test",
                ControllerAction = "test",
                Definition = "test",
                Display = "test",
                ICON = "test",
                ResourceTypeID = 1,
                SEQ = 1,
                SubCategoryID = 1,
                URL = "test",
                Source = "test",
                IsDeleted = false,
                CreatedBy = "Admin",
                CreatedDate = DateTime.UtcNow,
                UpdatedBy = "Admin",  // Adding the missing property
                UpdatedDate = DateTime.UtcNow,// Assuming UpdatedDate is required as well
            };


            //Arrange
            using ReadWriteDbContext dbContext = new(options);
            dbContext.ResourceMappings.Add(resourceMapping);
            await dbContext.SaveChangesAsync();


            UpdateResourceMappingRequest updateModel = new UpdateResourceMappingRequest
            {
                Id = 1,
                Code = "test",
                ParentID = 1,
                IsScreenRequired = true,
                ResourceName = "test",
                CategoryID = 1,
                CSS = "test",
                ControllerAction = "test",
                Definition = "test",
                Display = "test",
                ICON = "test",
                ResourceTypeID = 1,
                SEQ = 1,
                SubCategoryID = 1,
                URL = "test",
                Source = "test",
            };

            _resourceMappingCommandService = new ResourceMappingCommandService(dbContext, _mapperMock.Object);

            // Act
            bool result = await _resourceMappingCommandService.UpdateResourceMappingAsync(updateModel, resourceMapping);

            Assert.True(result);
        }
        [Fact]
        public async Task Test_DeleteResourceMapping_Returns_Success()
        {
            //Arrange
            DbContextOptions<ReadWriteDbContext> options = new DbContextOptionsBuilder<ReadWriteDbContext>()
               .UseInMemoryDatabase(databaseName: "DeleteResourceMapping").Options;

            var resourceMapping = new Domain.V1.Entities.UserGroups.ResourceMapping
            {
                Id = 1,
                Code = "test",
                ParentID = 1,
                IsScreenRequired = true,
                ResourceName = "test",
                CategoryID = 1,
                CSS = "test",
                ControllerAction = "test",
                Definition = "test",
                Display = "test",
                ICON = "test",
                ResourceTypeID = 1,
                SEQ = 1,
                SubCategoryID = 1,
                URL = "test",
                Source = "test",
                IsDeleted = false,
                CreatedBy = "Admin",
                CreatedDate = DateTime.UtcNow,
                UpdatedBy = "Admin",  // Adding the missing property
                UpdatedDate = DateTime.UtcNow,// Assuming UpdatedDate is required as well
            };



            //Arrange
            using ReadWriteDbContext dbContext = new(options);
            dbContext.ResourceMappings.Add(resourceMapping);
            await dbContext.SaveChangesAsync();

            _resourceMappingCommandService = new ResourceMappingCommandService(dbContext, _mapperMock.Object);

            // Act
            bool result = await _resourceMappingCommandService.DeleteResourceMappingByIdAsync(resourceMapping);

            Assert.True(result);
        }
    }
}
