﻿using Aurora.AdministrationService.API.Models.Dto.UserGroups.DependentResource;
using Aurora.AdministrationService.API.Services.Service.UserGroups.DependentResource;
using Aurora.AdministrationService.Infrastructure;
using AutoMapper;
using Microsoft.EntityFrameworkCore;
using Moq;

namespace Aurora.AdministrationService.Tests.API.Services.UserGroups.DependentResourcess
{
    public class DependentResourcesCommandServiceTests
    {
        private readonly Mock<ReadWriteDbContext> _readWriteDbContextMock;
        private readonly Mock<ReadOnlyDbContext> _readOnlyDbContextMock;
        private readonly Mock<IMapper> _mapperMock;
        private DependentResourcesCommandService _DependentResourcesCommandService;
        private readonly Mock<DependentResourcesQueryService> _DependentResourcesQueryService;

        public DependentResourcesCommandServiceTests()
        {
            // Initialize the mocks
            _mapperMock = new Mock<IMapper>();
            _readWriteDbContextMock = new Mock<ReadWriteDbContext>();
            _readOnlyDbContextMock = new Mock<ReadOnlyDbContext>();
            _DependentResourcesQueryService = new Mock<DependentResourcesQueryService>();


            // Setup in-memory ready only database for testing
            DbContextOptions<ReadWriteDbContext> options = new DbContextOptionsBuilder<ReadWriteDbContext>()
              .UseInMemoryDatabase(databaseName: "AdminDependentResourcesTestDB").Options;

            _readWriteDbContextMock = new(options);

            // Initialize the service being tested
            _DependentResourcesCommandService = new DependentResourcesCommandService(_readWriteDbContextMock.Object, _mapperMock.Object);
        }

        [Fact]
        public async Task CreateDependentResourcesAsync_ShouldReturnTrue_WhenDependentResourcesIsCreatedSuccessfully()
        {
            // Arrange
            var newDependentResources = new DependentResourcesDto
            {
                DependentResourceID = 1,
                ResourceID = 1,
                DependentResourceName = "test",
                DependentResourceTypeID = 1,
                ParentID = 1,
                ResourceMappingID = 1,
            };

            // Mock AutoMapper to return a DependentResources entity
            var DependentResourcesId = 1;
            var DependentResourcesEntity = new Domain.V1.Entities.UserGroups.DependentResources
            {
                DependentResourceID = DependentResourcesId,
                ResourceID = 1,
                DependentResourceName = "test",
                DependentResourceTypeID = 1,
                ParentID = 1,
                ResourceMappingID = 1,
                IsDeleted = false,
                CreatedBy = "Admin",
                CreatedDate = DateTime.UtcNow,
                UpdatedBy = "Admin",  // Adding the missing property
                UpdatedDate = DateTime.UtcNow,// Assuming UpdatedDate is required as well
            };


            // Mock AutoMapper to return the DependentResources entity
            _mapperMock.Setup(m => m.Map<Domain.V1.Entities.UserGroups.DependentResources>(newDependentResources)).Returns(DependentResourcesEntity);

            // Mock DbContext to simulate saving the entity without actually hitting the database
            _readWriteDbContextMock.Setup(db => db.DependentResources.Add(It.IsAny<Domain.V1.Entities.UserGroups.DependentResources>()));

            // Act
            var result = await _DependentResourcesCommandService.CreateDependentResourcesAsync(newDependentResources);

            // Assert
            Assert.True(result);
            _readWriteDbContextMock.Verify(db => db.DependentResources.Add(It.Is<Domain.V1.Entities.UserGroups.DependentResources>(l => l.DependentResourceName == "test")), Times.Once);
        }


        [Fact]
        public async Task CreateDependentResourcesAsync_ShouldReturnFalse_WhenExceptionOccurs()
        {
            // Arrange
            var newDependentResources = new DependentResourcesDto
            {
                DependentResourceID = 1,
                ResourceID = 1,
                DependentResourceName = "test",
                DependentResourceTypeID = 1,
                ParentID = 1,
                ResourceMappingID = 1,
            };

            // Mock AutoMapper to return a DependentResources entity
            var DependentResourcesId = 1;
            var DependentResourcesEntity = new Domain.V1.Entities.UserGroups.DependentResources
            {
                Id = DependentResourcesId,
                DependentResourceID = 1,
                ResourceID = 1,
                DependentResourceName = "test",
                DependentResourceTypeID = 1,
                ParentID = 1,
                ResourceMappingID = 1,
                IsDeleted = false,
                CreatedBy = "Admin",
                CreatedDate = DateTime.UtcNow,
                UpdatedBy = "Admin",  // Adding the missing property
                UpdatedDate = DateTime.UtcNow,// Assuming UpdatedDate is required as well
            };

            //Setup
            _mapperMock.Setup(m => m.Map<Domain.V1.Entities.UserGroups.DependentResources>(newDependentResources)).Returns(DependentResourcesEntity);

            // Act
            var result = await _DependentResourcesCommandService.CreateDependentResourcesAsync(newDependentResources);

            // Assert
            Assert.False(result);
        }
        [Fact]
        public async Task Test_UpdateDependentResources_Returns_Success()
        {
            //Arrange
            DbContextOptions<ReadWriteDbContext> options = new DbContextOptionsBuilder<ReadWriteDbContext>()
               .UseInMemoryDatabase(databaseName: "UpdateDependentResources").Options;

            byte[] concurrencyToken = new byte[8] { byte.MinValue, byte.MinValue, byte.MinValue, byte.MinValue, byte.MinValue, byte.MinValue, byte.MinValue, byte.MaxValue };
            var DependentResources = new Domain.V1.Entities.UserGroups.DependentResources
            {
                Id = 1,
                DependentResourceID = 1,
                ResourceID = 1,
                DependentResourceName = "test",
                DependentResourceTypeID = 1,
                ParentID = 1,
                ResourceMappingID = 1,
                IsDeleted = false,
                CreatedBy = "Admin",
                CreatedDate = DateTime.UtcNow,
                UpdatedBy = "Admin",  // Adding the missing property
                UpdatedDate = DateTime.UtcNow,// Assuming UpdatedDate is required as well
            };


            //Arrange
            using ReadWriteDbContext dbContext = new(options);
            dbContext.DependentResources.Add(DependentResources);
            await dbContext.SaveChangesAsync();


            UpdateDependentResourcesRequest updateModel = new UpdateDependentResourcesRequest
            {
                Id = 1,
                DependentResourceID = 1,
                ResourceID = 1,
                DependentResourceName = "test",
                DependentResourceTypeID = 1,
                ParentID = 1,
                ResourceMappingID = 1,
            };

            _DependentResourcesCommandService = new DependentResourcesCommandService(dbContext, _mapperMock.Object);

            // Act
            bool result = await _DependentResourcesCommandService.UpdateDependentResourcesAsync(updateModel, DependentResources);

            Assert.True(result);
        }
        [Fact]
        public async Task Test_DeleteDependentResources_Returns_Success()
        {
            //Arrange
            DbContextOptions<ReadWriteDbContext> options = new DbContextOptionsBuilder<ReadWriteDbContext>()
               .UseInMemoryDatabase(databaseName: "DeleteDependentResources").Options;

            var DependentResources = new Domain.V1.Entities.UserGroups.DependentResources
            {
                Id = 1,
                DependentResourceID = 1,
                ResourceID = 1,
                DependentResourceName = "test",
                DependentResourceTypeID = 1,
                ParentID = 1,
                ResourceMappingID = 1,
                IsDeleted = false,
                CreatedBy = "Admin",
                CreatedDate = DateTime.UtcNow,
                UpdatedBy = "Admin",  // Adding the missing property
                UpdatedDate = DateTime.UtcNow,// Assuming UpdatedDate is required as well
            };



            //Arrange
            using ReadWriteDbContext dbContext = new(options);
            dbContext.DependentResources.Add(DependentResources);
            await dbContext.SaveChangesAsync();

            _DependentResourcesCommandService = new DependentResourcesCommandService(dbContext, _mapperMock.Object);

            // Act
            bool result = await _DependentResourcesCommandService.DeleteDependentResourcesByIdAsync(DependentResources);

            Assert.True(result);
        }
    }
}
