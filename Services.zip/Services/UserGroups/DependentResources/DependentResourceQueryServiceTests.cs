﻿using Aurora.AdministrationService.API.Models.Dto.UserGroups.DependentResource;
using Aurora.AdministrationService.API.Services.Service.UserGroups.DependentResource;
using Aurora.AdministrationService.CrossCutting.CommonModels;
using Aurora.AdministrationService.Infrastructure;
using AutoMapper;
using Microsoft.EntityFrameworkCore;
using Moq;

namespace Aurora.AdministrationService.Tests.API.Services.UserGroups.DependentResourcess
{
    public class DependentResourcesQueryServiceTests
    {
        private readonly Mock<ReadOnlyDbContext> _readOnlyDbContextMock;
        private readonly Mock<IMapper> _mapperMock;
        private readonly DependentResourcesQueryService _DependentResourcesQueryService;
        private readonly Mock<DbSet<Domain.V1.Entities.UserGroups.DependentResources>> _mockDbSet;

        public DependentResourcesQueryServiceTests()
        {
            //Initialize mock
            _readOnlyDbContextMock = new Mock<ReadOnlyDbContext>();
            _mapperMock = new Mock<IMapper>();

            // Setup in-memory ready only database for testing
            DbContextOptions<ReadOnlyDbContext> options = new DbContextOptionsBuilder<ReadOnlyDbContext>()
              .UseInMemoryDatabase(databaseName: "DependentResourcesTestDB").Options;

            _readOnlyDbContextMock = new(options);

            _mockDbSet = new Mock<DbSet<Domain.V1.Entities.UserGroups.DependentResources>>();

            var data = new List<Domain.V1.Entities.UserGroups.DependentResources>
            {
               new() {
                Id = 1,
                DependentResourceID = 1,
                ResourceID = 1,
                DependentResourceName="test",
                DependentResourceTypeID=1,
                ParentID=1,
                ResourceMappingID=1,
                IsDeleted = false,
                CreatedBy = "Admin",
                CreatedDate = DateTime.UtcNow,
                UpdatedBy = "Admin",  // Adding the missing property
                UpdatedDate = DateTime.UtcNow,// Assuming UpdatedDate is required as well
            },
               new() {
                Id = 2,
                DependentResourceID = 1,
                ResourceID = 1,
                DependentResourceName="test",
                DependentResourceTypeID=1,
                ParentID=1,
                ResourceMappingID=1,
                IsDeleted = false,
                CreatedBy = "Admin",
                CreatedDate = DateTime.UtcNow,
                UpdatedBy = "Admin",  // Adding the missing property
                UpdatedDate = DateTime.UtcNow,// Assuming UpdatedDate is required as well
            }

            }.AsQueryable();


            //Setup
            _mockDbSet.As<IQueryable<Domain.V1.Entities.UserGroups.DependentResources>>().Setup(m => m.Provider).Returns(data.Provider);
            _mockDbSet.As<IQueryable<Domain.V1.Entities.UserGroups.DependentResources>>().Setup(m => m.Expression).Returns(data.Expression);
            _mockDbSet.As<IQueryable<Domain.V1.Entities.UserGroups.DependentResources>>().Setup(m => m.ElementType).Returns(data.ElementType);
            _mockDbSet.As<IQueryable<Domain.V1.Entities.UserGroups.DependentResources>>().Setup(m => m.GetEnumerator()).Returns(data.GetEnumerator());
            _readOnlyDbContextMock.Setup(c => c.DependentResources).Returns(_mockDbSet.Object);

            // Create the service instance
            _DependentResourcesQueryService = new DependentResourcesQueryService(_readOnlyDbContextMock.Object, _mapperMock.Object);
        }

        [Fact]
        public async Task GetDependentResourcesById_LogoExists_ReturnsLogoDetailDto()
        {
            // Arrange
            var DependentResourcesId = 1;
            var DependentResources = new Domain.V1.Entities.UserGroups.DependentResources
            {
                Id = 1,
                DependentResourceID = 1,
                ResourceID = 1,
                DependentResourceName = "test",
                DependentResourceTypeID = 1,
                ParentID = 1,
                ResourceMappingID = 1,
                IsDeleted = false,
                CreatedBy = "Admin",
                CreatedDate = DateTime.UtcNow,
                UpdatedBy = "Admin",  // Adding the missing property
                UpdatedDate = DateTime.UtcNow,// Assuming UpdatedDate is required as well
            };

            var DependentResourcesDto = new GetDependentResourcesDetailDto
            {
                Id = 1,
                DependentResourceID = 1,
                ResourceID = 1,
                DependentResourceName = "test",
                DependentResourceTypeID = 1,
                ParentID = 1,
                ResourceMappingID = 1,
                IsDeleted = false,
                CreatedOn = DateTime.UtcNow,
                UpdateBy = "Admin",  // Adding the missing property
            };

            _readOnlyDbContextMock.Setup(db => db.DependentResources.FindAsync(DependentResourcesId))
                .ReturnsAsync(DependentResources);

            _mapperMock.Setup(m => m.Map<GetDependentResourcesDetailDto>(DependentResources))
                .Returns(DependentResourcesDto);

            // Act
            var result = await _DependentResourcesQueryService.GetDependentResourcesById(DependentResourcesId);

            // Assert
            Assert.NotNull(result);
            Assert.Equal(DependentResourcesId, result.Id);
            Assert.Equal("test", result.DependentResourceName);
        }

        [Fact]
        public async Task GetDependentResourcesById_DependentResourcesNotFound_ReturnsNull()
        {
            //Arrange
            var DependentResourcesId = 1;
            var DependentResources = new Domain.V1.Entities.UserGroups.DependentResources
            {
                Id = 1,
                DependentResourceID = 1,
                ResourceID = 1,
                DependentResourceName = "test",
                DependentResourceTypeID = 1,
                ParentID = 1,
                ResourceMappingID = 1,
                IsDeleted = false,
                CreatedBy = "Admin",
                CreatedDate = DateTime.UtcNow,
                UpdatedBy = "Admin",  // Adding the missing property
                UpdatedDate = DateTime.UtcNow,// Assuming UpdatedDate is required as well
            };

            _readOnlyDbContextMock.Setup(db => db.DependentResources.FindAsync(DependentResourcesId))
                .ReturnsAsync(DependentResources);

            //Act
            var result = await _DependentResourcesQueryService.GetDependentResourcesById(DependentResourcesId);

            //Assert
            Assert.Null(result);
        }

        [Fact]
        public async Task GetDependentResourcesById_DependentResourcesExists_BindingError_ReturnsNull()
        {
            // Arrange
            byte[] concurrencyToken = new byte[8] { byte.MinValue, byte.MinValue, byte.MinValue, byte.MinValue, byte.MinValue, byte.MinValue, byte.MinValue, byte.MaxValue };
            var DependentResourcesId = 1;
            var DependentResources = new Domain.V1.Entities.UserGroups.DependentResources
            {
                Id = 1,
                DependentResourceID = 1,
                ResourceID = 1,
                DependentResourceName = "test",
                DependentResourceTypeID = 1,
                ParentID = 1,
                ResourceMappingID = 1,
                IsDeleted = false,
                CreatedBy = "Admin",
                CreatedDate = DateTime.UtcNow,
                UpdatedBy = "Admin",  // Adding the missing property
                UpdatedDate = DateTime.UtcNow,// Assuming UpdatedDate is required as well
            };

            _readOnlyDbContextMock.Setup(db => db.DependentResources.FindAsync(DependentResourcesId))
                .ReturnsAsync(DependentResources);

            _mapperMock.Setup(m => m.Map<GetDependentResourcesDetailDto>(DependentResources))
                .Throws(new AutoMapperMappingException("Error mapping entity to DTO"));

            // Act & Assert
            var exception = await Assert.ThrowsAsync<AutoMapperMappingException>(
                () => _DependentResourcesQueryService.GetDependentResourcesById(DependentResourcesId)
            );

            Assert.Equal("Error mapping entity to DTO", exception.Message);
        }

        [Fact]
        public async Task FindDependentResourcesById_DependentResourcesExists_ReturnsDependentResources()
        {
            // Arrange
            byte[] concurrencyToken = new byte[8] { byte.MinValue, byte.MinValue, byte.MinValue, byte.MinValue, byte.MinValue, byte.MinValue, byte.MinValue, byte.MaxValue };
            int DependentResourcesId = 1;
            var DependentResources = new Domain.V1.Entities.UserGroups.DependentResources
            {
                Id = DependentResourcesId,
                DependentResourceID = 1,
                ResourceID = 1,
                DependentResourceName = "test",
                DependentResourceTypeID = 1,
                ParentID = 1,
                ResourceMappingID = 1,
                IsDeleted = false,
                CreatedBy = "Admin",
                CreatedDate = DateTime.UtcNow,
                UpdatedBy = "Admin",  // Adding the missing property
                UpdatedDate = DateTime.UtcNow,// Assuming UpdatedDate is required as well
            };

            // Mock the FindAsync method to return the DependentResources
            _readOnlyDbContextMock.Setup(db => db.DependentResources.FindAsync(DependentResourcesId))
                .ReturnsAsync(DependentResources);

            // Act
            var result = await _DependentResourcesQueryService.FindDependentResourcesById(DependentResourcesId);

            // Assert
            Assert.NotNull(result);
        }

        [Fact]
        public async Task FindDependentResourcesById_DependentResourcesNotFound_ReturnsNull()
        {
            // Arrange
            var DependentResourcesId = 1;
            var DependentResources = new Domain.V1.Entities.UserGroups.DependentResources
            {
                Id = DependentResourcesId,
                DependentResourceID = 1,
                ResourceID = 1,
                DependentResourceName = "test",
                DependentResourceTypeID = 1,
                ParentID = 1,
                ResourceMappingID = 1,
                IsDeleted = false,
                CreatedBy = "Admin",
                CreatedDate = DateTime.UtcNow,
                UpdatedBy = "Admin",  // Adding the missing property
                UpdatedDate = DateTime.UtcNow,// Assuming UpdatedDate is required as well
            };

            // Mock the FindAsync method to return null (DependentResources not found)
            _readOnlyDbContextMock.Setup(db => db.DependentResources.FindAsync(DependentResourcesId))
                .ReturnsAsync(DependentResources);

            // Act
            var result = await _DependentResourcesQueryService.FindDependentResourcesById(DependentResourcesId);

            // Assert
            Assert.NotNull(result);
        }

        [Fact]
        public void GetDependentResourcesList_ReturnsCorrectDependentResourcesList()
        {
            // Act
            var result = _DependentResourcesQueryService.GetDependentResourcesList();

            // Assert
            Assert.NotNull(result);
            Assert.Equal(2, result.Count); // Verifying that 3 items are returned

            // Verifying that the returned items are mapped correctly
            Assert.Contains(result, r => r.Id == 1 && r.DependentResourceName == "test");
            Assert.Contains(result, r => r.Id == 2 && r.DependentResourceName == "test");
        }

        [Fact]
        public async Task IsDependentResourcesAlreadyExist_ShouldReturnTrue_WhenDependentResourcesExists()
        {
            // Arrange
            var DependentResourcesId = 1;
            var DependentResources = new Domain.V1.Entities.UserGroups.DependentResources
            {
                Id = 1,
                DependentResourceID = 1,
                ResourceID = 1,
                DependentResourceName = "test",
                DependentResourceTypeID = 1,
                ParentID = 1,
                ResourceMappingID = 1,
                IsDeleted = false,
                CreatedBy = "Admin",
                CreatedDate = DateTime.UtcNow,
                UpdatedBy = "Admin",  // Adding the missing property
                UpdatedDate = DateTime.UtcNow,// Assuming UpdatedDate is required as well
            };

            // Mock the FindAsync method to return the DependentResources
            _readOnlyDbContextMock.Setup(db => db.DependentResources.FindAsync(DependentResourcesId))
                .ReturnsAsync(DependentResources);

            // Act
            var result = await _DependentResourcesQueryService.IsDependentResourcesAlreadyExist(DependentResourcesId);

            // Assert
            Assert.True(result.result);
            Assert.Equal(ResponseMessage.STATUS_DATA_FOUND, result.message);
        }

        [Fact]
        public async Task IsDependentResourcesAlreadyExist_ShouldReturnFalse_WhenDependentResourcesDoesNotExist()
        {
            // Arrange
            var DependentResourcesId = 3;

            // Act
            var result = await _DependentResourcesQueryService.IsDependentResourcesAlreadyExist(DependentResourcesId);

            // Assert
            Assert.False(result.result);
            Assert.Equal(ResponseMessage.STATUS_NODATA, result.message);
        }
    }
}
