﻿using Aurora.AdministrationService.API.Models.Dto.UserGroups.ResourceType;
using Aurora.AdministrationService.API.Services.Service.UserGroups.ResourceType;
using Aurora.AdministrationService.CrossCutting.CommonModels;
using Aurora.AdministrationService.Infrastructure;
using AutoMapper;
using Microsoft.EntityFrameworkCore;
using Moq;

namespace Aurora.AdministrationService.Tests.API.Services.UserGroups.ResourceTypes
{
    public class ResourceTypeQueryServiceTests
    {
        private readonly Mock<ReadOnlyDbContext> _readOnlyDbContextMock;
        private readonly Mock<IMapper> _mapperMock;
        private readonly ResourceTypeQueryService _resourceTypeQueryService;
        private Mock<DbSet<Domain.V1.Entities.UserGroups.ResourceType>> _mockDbSet;

        public ResourceTypeQueryServiceTests()
        {
            //Initialize mock
            _readOnlyDbContextMock = new Mock<ReadOnlyDbContext>();
            _mapperMock = new Mock<IMapper>();

            // Setup in-memory ready only database for testing
            DbContextOptions<ReadOnlyDbContext> options = new DbContextOptionsBuilder<ReadOnlyDbContext>()
              .UseInMemoryDatabase(databaseName: "ResourceTypeTestDB").Options;

            _readOnlyDbContextMock = new(options);

            _mockDbSet = new Mock<DbSet<Domain.V1.Entities.UserGroups.ResourceType>>();

            var data = new List<Domain.V1.Entities.UserGroups.ResourceType>
            {
               new Domain.V1.Entities.UserGroups.ResourceType {
                Id = 1,
                Code = "test",
                ResourceTypeName ="test",
                Definition="test",
                Display="test",
                Source = "test",
                IsDeleted = false,
                CreatedBy = "Admin",
                CreatedDate = DateTime.UtcNow,
                UpdatedBy = "Admin",  // Adding the missing property
                UpdatedDate = DateTime.UtcNow,// Assuming UpdatedDate is required as well
            },
               new Domain.V1.Entities.UserGroups.ResourceType {
                Id = 2,
                Code = "test",
                ResourceTypeName ="test",
                Definition="test",
                Display="test",
                Source = "test",
                IsDeleted = false,
                CreatedBy = "Admin",
                CreatedDate = DateTime.UtcNow,
                UpdatedBy = "Admin",  // Adding the missing property
                UpdatedDate = DateTime.UtcNow,// Assuming UpdatedDate is required as well
            }

            }.AsQueryable();


            //Setup
            _mockDbSet.As<IQueryable<Domain.V1.Entities.UserGroups.ResourceType>>().Setup(m => m.Provider).Returns(data.Provider);
            _mockDbSet.As<IQueryable<Domain.V1.Entities.UserGroups.ResourceType>>().Setup(m => m.Expression).Returns(data.Expression);
            _mockDbSet.As<IQueryable<Domain.V1.Entities.UserGroups.ResourceType>>().Setup(m => m.ElementType).Returns(data.ElementType);
            _mockDbSet.As<IQueryable<Domain.V1.Entities.UserGroups.ResourceType>>().Setup(m => m.GetEnumerator()).Returns(data.GetEnumerator());
            _readOnlyDbContextMock.Setup(c => c.ResourceTypes).Returns(_mockDbSet.Object);

            // Create the service instance
            _resourceTypeQueryService = new ResourceTypeQueryService(_readOnlyDbContextMock.Object, _mapperMock.Object);
        }

        [Fact]
        public async Task GetResourceTypeById_LogoExists_ReturnsLogoDetailDto()
        {
            // Arrange
            var resourceTypeId = 1;
            var resourceType = new Domain.V1.Entities.UserGroups.ResourceType
            {
                Id = 1,
                Code = "test",
                ResourceTypeName = "test",
                Definition = "test",
                Display = "test",
                Source = "test",
                IsDeleted = false,
                CreatedBy = "Admin",
                CreatedDate = DateTime.UtcNow,
                UpdatedBy = "Admin",  // Adding the missing property
                UpdatedDate = DateTime.UtcNow,// Assuming UpdatedDate is required as well
            };

            var resourceTypeDto = new GetResourceTypeDetailDto
            {
                Id = 1,
                Code = "test",
                ResourceTypeName = "test",
                Definition = "test",
                Display = "test",
                Source = "test",
            };

            _readOnlyDbContextMock.Setup(db => db.ResourceTypes.FindAsync(resourceTypeId))
                .ReturnsAsync(resourceType);

            _mapperMock.Setup(m => m.Map<GetResourceTypeDetailDto>(resourceType))
                .Returns(resourceTypeDto);

            // Act
            var result = await _resourceTypeQueryService.GetResourceTypeById(resourceTypeId);

            // Assert
            Assert.NotNull(result);
            Assert.Equal(resourceTypeId, result.Id);
            Assert.Equal("test", result.Code);
        }

        [Fact]
        public async Task GetResourceTypeById_resourceTypeNotFound_ReturnsNull()
        {
            //Arrange
            var resourceTypeId = 1;
            var resourceType = new Domain.V1.Entities.UserGroups.ResourceType
            {
                Id = 1,
                Code = "test",
                ResourceTypeName = "test",
                Definition = "test",
                Display = "test",
                Source = "test",
                IsDeleted = false,
                CreatedBy = "Admin",
                CreatedDate = DateTime.UtcNow,
                UpdatedBy = "Admin",  // Adding the missing property
                UpdatedDate = DateTime.UtcNow,// Assuming UpdatedDate is required as well
            };

            _readOnlyDbContextMock.Setup(db => db.ResourceTypes.FindAsync(resourceTypeId))
                .ReturnsAsync(resourceType);

            //Act
            var result = await _resourceTypeQueryService.GetResourceTypeById(resourceTypeId);

            //Assert
            Assert.Null(result);
        }

        [Fact]
        public async Task GetResourceTypeById_resourceTypeExists_BindingError_ReturnsNull()
        {
            // Arrange
            byte[] concurrencyToken = new byte[8] { byte.MinValue, byte.MinValue, byte.MinValue, byte.MinValue, byte.MinValue, byte.MinValue, byte.MinValue, byte.MaxValue };
            var resourceTypeId = 1;
            var resourceType = new Domain.V1.Entities.UserGroups.ResourceType
            {
                Id = 1,
                Code = "test",
                ResourceTypeName = "test",
                Definition = "test",
                Display = "test",
                Source = "test",
                IsDeleted = false,
                CreatedBy = "Admin",
                CreatedDate = DateTime.UtcNow,
                UpdatedBy = "Admin",  // Adding the missing property
                UpdatedDate = DateTime.UtcNow,// Assuming UpdatedDate is required as well
            };

            _readOnlyDbContextMock.Setup(db => db.ResourceTypes.FindAsync(resourceTypeId))
                .ReturnsAsync(resourceType);

            _mapperMock.Setup(m => m.Map<GetResourceTypeDetailDto>(resourceType))
                .Throws(new AutoMapperMappingException("Error mapping entity to DTO"));

            // Act & Assert
            var exception = await Assert.ThrowsAsync<AutoMapperMappingException>(
                () => _resourceTypeQueryService.GetResourceTypeById(resourceTypeId)
            );

            Assert.Equal("Error mapping entity to DTO", exception.Message);
        }

        [Fact]
        public async Task FindResourceTypeById_resourceTypeExists_ReturnsresourceType()
        {
            // Arrange
            byte[] concurrencyToken = new byte[8] { byte.MinValue, byte.MinValue, byte.MinValue, byte.MinValue, byte.MinValue, byte.MinValue, byte.MinValue, byte.MaxValue };
            int resourceTypeId = 1;
            var resourceType = new Domain.V1.Entities.UserGroups.ResourceType
            {
                Id = resourceTypeId,
                Code = "test",
                ResourceTypeName = "test",
                Definition = "test",
                Display = "test",
                Source = "test",
                IsDeleted = false,
                CreatedBy = "Admin",
                CreatedDate = DateTime.UtcNow,
                UpdatedBy = "Admin",  // Adding the missing property
                UpdatedDate = DateTime.UtcNow,// Assuming UpdatedDate is required as well
            };

            // Mock the FindAsync method to return the resourceType
            _readOnlyDbContextMock.Setup(db => db.ResourceTypes.FindAsync(resourceTypeId))
                .ReturnsAsync(resourceType);

            // Act
            var result = await _resourceTypeQueryService.FindResourceTypeById(resourceTypeId);

            // Assert
            Assert.NotNull(result);
        }

        [Fact]
        public async Task FindResourceTypeById_resourceTypeNotFound_ReturnsNull()
        {
            // Arrange
            var resourceTypeId = 1;
            var resourceType = new Domain.V1.Entities.UserGroups.ResourceType
            {
                Id = resourceTypeId,
                Code = "test",
                ResourceTypeName = "test",
                Definition = "test",
                Display = "test",
                Source = "test",
                IsDeleted = false,
                CreatedBy = "Admin",
                CreatedDate = DateTime.UtcNow,
                UpdatedBy = "Admin",  // Adding the missing property
                UpdatedDate = DateTime.UtcNow,// Assuming UpdatedDate is required as well
            };

            // Mock the FindAsync method to return null (resourceType not found)
            _readOnlyDbContextMock.Setup(db => db.ResourceTypes.FindAsync(resourceTypeId))
                .ReturnsAsync(resourceType);

            // Act
            var result = await _resourceTypeQueryService.FindResourceTypeById(resourceTypeId);

            // Assert
            Assert.NotNull(result);
        }

        [Fact]
        public void GetResourceTypeList_ReturnsCorrectResourceTypeList()
        {
            // Act
            var result = _resourceTypeQueryService.GetResourceTypeList();

            // Assert
            Assert.NotNull(result);
            Assert.Equal(2, result.Count); // Verifying that 3 items are returned

            // Verifying that the returned items are mapped correctly
            Assert.Contains(result, r => r.Id == 1 && r.Code == "test");
            Assert.Contains(result, r => r.Id == 2 && r.Code == "test");
        }

        [Fact]
        public async Task IsResourceTypeAlreadyExist_ShouldReturnTrue_WhenresourceTypeExists()
        {
            // Arrange
            var resourceTypeId = 1;
            var resourceType = new Domain.V1.Entities.UserGroups.ResourceType
            {
                Id = 1,
                Code = "test",
                ResourceTypeName = "test",
                Definition = "test",
                Display = "test",
                Source = "test",
                IsDeleted = false,
                CreatedBy = "Admin",
                CreatedDate = DateTime.UtcNow,
                UpdatedBy = "Admin",  // Adding the missing property
                UpdatedDate = DateTime.UtcNow,// Assuming UpdatedDate is required as well
            };

            // Mock the FindAsync method to return the resourceType
            _readOnlyDbContextMock.Setup(db => db.ResourceTypes.FindAsync(resourceTypeId))
                .ReturnsAsync(resourceType);

            // Act
            var result = await _resourceTypeQueryService.IsResourceTypeAlreadyExist(resourceTypeId);

            // Assert
            Assert.True(result.result);
            Assert.Equal(ResponseMessage.STATUS_DATA_FOUND, result.message);
        }

        [Fact]
        public async Task IsResourceTypeAlreadyExist_ShouldReturnFalse_WhenresourceTypeDoesNotExist()
        {
            // Arrange
            var resourceTypeId = 3;

            // Act
            var result = await _resourceTypeQueryService.IsResourceTypeAlreadyExist(resourceTypeId);

            // Assert
            Assert.False(result.result);
            Assert.Equal(ResponseMessage.STATUS_NODATA, result.message);
        }
    }
}
