﻿using Aurora.AdministrationService.API.Models.Dto.UserGroups.ResourceType;
using Aurora.AdministrationService.API.Services.Service.UserGroups.ResourceType;
using Aurora.AdministrationService.Infrastructure;
using AutoMapper;
using Microsoft.EntityFrameworkCore;
using Moq;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Aurora.AdministrationService.Tests.API.Services.UserGroups.ResourceTypes
{
    public class ResourceTypeCommandServiceTests
    {
        private readonly Mock<ReadWriteDbContext> _readWriteDbContextMock;
        private readonly Mock<ReadOnlyDbContext> _readOnlyDbContextMock;
        private readonly Mock<IMapper> _mapperMock;
        private ResourceTypeCommandService _resourceTypeCommandService;
        private readonly Mock<ResourceTypeQueryService> _resourceTypeQueryService;

        public ResourceTypeCommandServiceTests()
        {
            // Initialize the mocks
            _mapperMock = new Mock<IMapper>();
            _readWriteDbContextMock = new Mock<ReadWriteDbContext>();
            _readOnlyDbContextMock = new Mock<ReadOnlyDbContext>();
            _resourceTypeQueryService = new Mock<ResourceTypeQueryService>();


            // Setup in-memory ready only database for testing
            DbContextOptions<ReadWriteDbContext> options = new DbContextOptionsBuilder<ReadWriteDbContext>()
              .UseInMemoryDatabase(databaseName: "AdminResourceTypeTestDB").Options;

            _readWriteDbContextMock = new(options);

            // Initialize the service being tested
            _resourceTypeCommandService = new ResourceTypeCommandService(_readWriteDbContextMock.Object, _mapperMock.Object);
        }

        [Fact]
        public async Task CreateResourceTypeAsync_ShouldReturnTrue_WhenResourceTypeIsCreatedSuccessfully()
        {
            // Arrange
            var newResourceType = new ResourceTypeDto
            {
                Code = "test",
                ResourceTypeName = "test",
                Definition = "test",
                Display = "test",
                Source = "test",
            };

            // Mock AutoMapper to return a ResourceType entity
            var resourceTypeEntity = new Domain.V1.Entities.UserGroups.ResourceType
            {
                Code = "test",
                ResourceTypeName = "test",
                Definition = "test",
                Display = "test",
                Source = "test",
                IsDeleted = false,
                CreatedBy = "Admin",
                CreatedDate = DateTime.UtcNow,
                UpdatedBy = "Admin",  // Adding the missing property
                UpdatedDate = DateTime.UtcNow,// Assuming UpdatedDate is required as well
            };


            // Mock AutoMapper to return the ResourceType entity
            _mapperMock.Setup(m => m.Map<Domain.V1.Entities.UserGroups.ResourceType>(newResourceType)).Returns(resourceTypeEntity);

            // Mock DbContext to simulate saving the entity without actually hitting the database
            _readWriteDbContextMock.Setup(db => db.ResourceTypes.Add(It.IsAny<Domain.V1.Entities.UserGroups.ResourceType>()));

            // Act
            var result = await _resourceTypeCommandService.CreateResourceTypeAsync(newResourceType);

            // Assert
            Assert.True(result);
            _readWriteDbContextMock.Verify(db => db.ResourceTypes.Add(It.Is<Domain.V1.Entities.UserGroups.ResourceType>(l => l.Source == "test")), Times.Once);
        }


        [Fact]
        public async Task CreateResourceTypeAsync_ShouldReturnFalse_WhenExceptionOccurs()
        {
            // Arrange
            var newResourceType = new ResourceTypeDto
            {
                Code = "test",
                ResourceTypeName = "test",
                Definition = "test",
                Display = "test",
                Source = "test",
            };

            // Mock AutoMapper to return a ResourceType entity
            var resourceTypeId = 1;
            var resourceTypeEntity = new Domain.V1.Entities.UserGroups.ResourceType
            {
                Id = resourceTypeId,
                Code = "test",
                ResourceTypeName = "test",
                Definition = "test",
                Display = "test",
                Source = "test",
                IsDeleted = false,
                CreatedBy = "Admin",
                CreatedDate = DateTime.UtcNow,
                UpdatedBy = "Admin",  // Adding the missing property
                UpdatedDate = DateTime.UtcNow,// Assuming UpdatedDate is required as well
            };

            //Setup
            _mapperMock.Setup(m => m.Map<Domain.V1.Entities.UserGroups.ResourceType>(newResourceType)).Returns(resourceTypeEntity);

            // Act
            var result = await _resourceTypeCommandService.CreateResourceTypeAsync(newResourceType);

            // Assert
            Assert.False(result);
        }
        [Fact]
        public async Task Test_UpdateResourceType_Returns_Success()
        {
            //Arrange
            DbContextOptions<ReadWriteDbContext> options = new DbContextOptionsBuilder<ReadWriteDbContext>()
               .UseInMemoryDatabase(databaseName: "UpdateResourceType").Options;

            byte[] concurrencyToken = new byte[8] { byte.MinValue, byte.MinValue, byte.MinValue, byte.MinValue, byte.MinValue, byte.MinValue, byte.MinValue, byte.MaxValue };
            var resourceType = new Domain.V1.Entities.UserGroups.ResourceType
            {
                Id = 1,
                Code = "test",
                ResourceTypeName = "test",
                Definition = "test",
                Display = "test",
                Source = "test",
                IsDeleted = false,
                CreatedBy = "Admin",
                CreatedDate = DateTime.UtcNow,
                UpdatedBy = "Admin",  // Adding the missing property
                UpdatedDate = DateTime.UtcNow,// Assuming UpdatedDate is required as well
            };


            //Arrange
            using ReadWriteDbContext dbContext = new(options);
            dbContext.ResourceTypes.Add(resourceType);
            await dbContext.SaveChangesAsync();


            UpdateResourceTypeRequest updateModel = new UpdateResourceTypeRequest
            {
                Id = 1,
                Code = "test",
                ResourceTypeName = "test",
                Definition = "test",
                Display = "test",
                Source = "test",
            };

            _resourceTypeCommandService = new ResourceTypeCommandService(dbContext, _mapperMock.Object);

            // Act
            bool result = await _resourceTypeCommandService.UpdateResourceTypeAsync(updateModel, resourceType);

            Assert.True(result);
        }
        [Fact]
        public async Task Test_DeleteResourceType_Returns_Success()
        {
            //Arrange
            DbContextOptions<ReadWriteDbContext> options = new DbContextOptionsBuilder<ReadWriteDbContext>()
               .UseInMemoryDatabase(databaseName: "DeleteResourceType").Options;

            var resourceType = new Domain.V1.Entities.UserGroups.ResourceType
            {
                Id = 1,
                Code = "test",
                ResourceTypeName = "test",
                Definition = "test",
                Display = "test",
                Source = "test",
                IsDeleted = false,
                CreatedBy = "Admin",
                CreatedDate = DateTime.UtcNow,
                UpdatedBy = "Admin",  // Adding the missing property
                UpdatedDate = DateTime.UtcNow,// Assuming UpdatedDate is required as well
            };



            //Arrange
            using ReadWriteDbContext dbContext = new(options);
            dbContext.ResourceTypes.Add(resourceType);
            await dbContext.SaveChangesAsync();

            _resourceTypeCommandService = new ResourceTypeCommandService(dbContext, _mapperMock.Object);

            // Act
            bool result = await _resourceTypeCommandService.DeleteResourceTypeByIdAsync(resourceType);

            Assert.True(result);
        }
    }
}
