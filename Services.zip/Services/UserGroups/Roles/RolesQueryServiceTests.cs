﻿using Aurora.AdministrationService.API.Models.Dto.UserGroups.Roles;
using Aurora.AdministrationService.API.Services.Service.UserGroups.Roles;
using Aurora.AdministrationService.CrossCutting.CommonModels;
using Aurora.AdministrationService.Infrastructure;
using AutoMapper;
using Microsoft.EntityFrameworkCore;
using Moq;

namespace Aurora.AdministrationService.Tests.API.Services.UserGroups.Roles
{
    public class RolesQueryServiceTests
    {
        private readonly Mock<ReadOnlyDbContext> _readOnlyDbContextMock;
        private readonly Mock<IMapper> _mapperMock;
        private readonly RolesQueryService _rolesQueryService;
        private Mock<DbSet<Domain.V1.Entities.UserGroups.Roles>> _mockDbSet;

        public RolesQueryServiceTests()
        {
            //Initialize mock
            _readOnlyDbContextMock = new Mock<ReadOnlyDbContext>();
            _mapperMock = new Mock<IMapper>();

            // Setup in-memory ready only database for testing
            DbContextOptions<ReadOnlyDbContext> options = new DbContextOptionsBuilder<ReadOnlyDbContext>()
              .UseInMemoryDatabase(databaseName: "RolesTestDB").Options;

            _readOnlyDbContextMock = new(options);

            _mockDbSet = new Mock<DbSet<Domain.V1.Entities.UserGroups.Roles>>();

            var data = new List<Domain.V1.Entities.UserGroups.Roles>
            {
               new Domain.V1.Entities.UserGroups.Roles {
                Id = 1,
                Code = "test",
                Location="BRIM",
                IsObsolete = true,
                RoleName ="test",
                MenuID = 1,
                RoleDescription = "test",
                Source = "test",
                IsDeleted = false,
                CreatedBy = "Admin",
                CreatedDate = DateTime.UtcNow,
                UpdatedBy = "Admin",  // Adding the missing property
                UpdatedDate = DateTime.UtcNow,// Assuming UpdatedDate is required as well
            },
               new Domain.V1.Entities.UserGroups.Roles {
                Id = 2,
                Code = "test",
                Location="BRIM",
                IsObsolete = true,
                RoleName ="test",
                MenuID = 1,
                RoleDescription = "test",
                Source = "test",
                IsDeleted = false,
                CreatedBy = "Admin",
                CreatedDate = DateTime.UtcNow,
                UpdatedBy = "Admin",  // Adding the missing property
                UpdatedDate = DateTime.UtcNow,// Assuming UpdatedDate is required as well
            }

            }.AsQueryable();


            //Setup
            _mockDbSet.As<IQueryable<Domain.V1.Entities.UserGroups.Roles>>().Setup(m => m.Provider).Returns(data.Provider);
            _mockDbSet.As<IQueryable<Domain.V1.Entities.UserGroups.Roles>>().Setup(m => m.Expression).Returns(data.Expression);
            _mockDbSet.As<IQueryable<Domain.V1.Entities.UserGroups.Roles>>().Setup(m => m.ElementType).Returns(data.ElementType);
            _mockDbSet.As<IQueryable<Domain.V1.Entities.UserGroups.Roles>>().Setup(m => m.GetEnumerator()).Returns(data.GetEnumerator());
            _readOnlyDbContextMock.Setup(c => c.Roles).Returns(_mockDbSet.Object);

            // Create the service instance
            _rolesQueryService = new RolesQueryService(_readOnlyDbContextMock.Object, _mapperMock.Object);
        }

        [Fact]
        public async Task GetRolesById_LogoExists_ReturnsLogoDetailDto()
        {
            // Arrange
            var rolesId = 1;
            var roles = new Domain.V1.Entities.UserGroups.Roles
            {
                Id = 1,
                Code = "test",
                Location = "BRIM",
                IsObsolete = true,
                RoleName = "test",
                MenuID = 1,
                RoleDescription = "test",
                Source = "test",
                IsDeleted = false,
                CreatedBy = "Admin",
                CreatedDate = DateTime.UtcNow,
                UpdatedBy = "Admin",  // Adding the missing property
                UpdatedDate = DateTime.UtcNow,// Assuming UpdatedDate is required as well
            };

            var rolesDto = new GetRolesDetailDto
            {
                Id = 1,
                Code = "test",
                Location = "BRIM",
                IsObsolete = true,
                RoleName = "test",
                MenuID = 1,
                RoleDescription = "test",
                Source = "test",
            };

            _readOnlyDbContextMock.Setup(db => db.Roles.FindAsync(rolesId))
                .ReturnsAsync(roles);

            _mapperMock.Setup(m => m.Map<GetRolesDetailDto>(roles))
                .Returns(rolesDto);

            // Act
            var result = await _rolesQueryService.GetRolesById(rolesId);

            // Assert
            Assert.NotNull(result);
            Assert.Equal(rolesId, result.Id);
            Assert.Equal("test", result.Code);
        }

        [Fact]
        public async Task GetRolesById_rolesNotFound_ReturnsNull()
        {
            //Arrange
            var rolesId = 1;
            var roles = new Domain.V1.Entities.UserGroups.Roles
            {
                Id = 1,
                Code = "test",
                Location = "BRIM",
                IsObsolete = true,
                RoleName = "test",
                MenuID = 1,
                RoleDescription = "test",
                Source = "test",
                IsDeleted = false,
                CreatedBy = "Admin",
                CreatedDate = DateTime.UtcNow,
                UpdatedBy = "Admin",  // Adding the missing property
                UpdatedDate = DateTime.UtcNow,// Assuming UpdatedDate is required as well
            };

            _readOnlyDbContextMock.Setup(db => db.Roles.FindAsync(rolesId))
                .ReturnsAsync(roles);

            //Act
            var result = await _rolesQueryService.GetRolesById(rolesId);

            //Assert
            Assert.Null(result);
        }

        [Fact]
        public async Task GetRolesById_rolesExists_BindingError_ReturnsNull()
        {
            // Arrange
            byte[] concurrencyToken = new byte[8] { byte.MinValue, byte.MinValue, byte.MinValue, byte.MinValue, byte.MinValue, byte.MinValue, byte.MinValue, byte.MaxValue };
            var rolesId = 1;
            var roles = new Domain.V1.Entities.UserGroups.Roles
            {
                Id = 1,
                Code = "test",
                Location = "BRIM",
                IsObsolete = true,
                RoleName = "test",
                MenuID = 1,
                RoleDescription = "test",
                Source = "test",
                IsDeleted = false,
                CreatedBy = "Admin",
                CreatedDate = DateTime.UtcNow,
                UpdatedBy = "Admin",  // Adding the missing property
                UpdatedDate = DateTime.UtcNow,// Assuming UpdatedDate is required as well
            };

            _readOnlyDbContextMock.Setup(db => db.Roles.FindAsync(rolesId))
                .ReturnsAsync(roles);

            _mapperMock.Setup(m => m.Map<GetRolesDetailDto>(roles))
                .Throws(new AutoMapperMappingException("Error mapping entity to DTO"));

            // Act & Assert
            var exception = await Assert.ThrowsAsync<AutoMapperMappingException>(
                () => _rolesQueryService.GetRolesById(rolesId)
            );

            Assert.Equal("Error mapping entity to DTO", exception.Message);
        }

        [Fact]
        public async Task FindRolesById_rolesExists_Returnsroles()
        {
            // Arrange
            byte[] concurrencyToken = new byte[8] { byte.MinValue, byte.MinValue, byte.MinValue, byte.MinValue, byte.MinValue, byte.MinValue, byte.MinValue, byte.MaxValue };
            int rolesId = 1;
            var roles = new Domain.V1.Entities.UserGroups.Roles
            {
                Id = rolesId,
                Code = "test",
                Location = "BRIM",
                IsObsolete = true,
                RoleName = "test",
                MenuID = 1,
                RoleDescription = "test",
                Source = "test",
                IsDeleted = false,
                CreatedBy = "Admin",
                CreatedDate = DateTime.UtcNow,
                UpdatedBy = "Admin",  // Adding the missing property
                UpdatedDate = DateTime.UtcNow,// Assuming UpdatedDate is required as well
            };

            // Mock the FindAsync method to return the roles
            _readOnlyDbContextMock.Setup(db => db.Roles.FindAsync(rolesId))
                .ReturnsAsync(roles);

            // Act
            var result = await _rolesQueryService.FindRolesById(rolesId);

            // Assert
            Assert.NotNull(result);
        }

        [Fact]
        public async Task FindRolesById_rolesNotFound_ReturnsNull()
        {
            // Arrange
            var rolesId = 1;
            var roles = new Domain.V1.Entities.UserGroups.Roles
            {
                Id = rolesId,
                Code = "test",
                Location = "BRIM",
                IsObsolete = true,
                RoleName = "test",
                MenuID = 1,
                RoleDescription = "test",
                Source = "test",
                IsDeleted = false,
                CreatedBy = "Admin",
                CreatedDate = DateTime.UtcNow,
                UpdatedBy = "Admin",  // Adding the missing property
                UpdatedDate = DateTime.UtcNow,// Assuming UpdatedDate is required as well
            };

            // Mock the FindAsync method to return null (roles not found)
            _readOnlyDbContextMock.Setup(db => db.Roles.FindAsync(rolesId))
                .ReturnsAsync(roles);

            // Act
            var result = await _rolesQueryService.FindRolesById(rolesId);

            // Assert
            Assert.NotNull(result);
        }

        [Fact]
        public void GetRolesList_ReturnsCorrectRolesList()
        {
            // Act
            var result = _rolesQueryService.GetRolesList();

            // Assert
            Assert.NotNull(result);
            Assert.Equal(2, result.Count); // Verifying that 3 items are returned

            // Verifying that the returned items are mapped correctly
            Assert.Contains(result, r => r.Id == 1 && r.Code == "test");
            Assert.Contains(result, r => r.Id == 2 && r.Code == "test");
        }

        [Fact]
        public async Task IsRolesAlreadyExist_ShouldReturnTrue_WhenrolesExists()
        {
            // Arrange
            var rolesId = 1;
            var roles = new Domain.V1.Entities.UserGroups.Roles
            {
                Id = 1,
                Code = "test",
                Location = "BRIM",
                IsObsolete = true,
                RoleName = "test",
                MenuID = 1,
                RoleDescription = "test",
                Source = "test",
                IsDeleted = false,
                CreatedBy = "Admin",
                CreatedDate = DateTime.UtcNow,
                UpdatedBy = "Admin",  // Adding the missing property
                UpdatedDate = DateTime.UtcNow,// Assuming UpdatedDate is required as well
            };

            // Mock the FindAsync method to return the roles
            _readOnlyDbContextMock.Setup(db => db.Roles.FindAsync(rolesId))
                .ReturnsAsync(roles);

            // Act
            var result = await _rolesQueryService.IsRolesAlreadyExist(rolesId);

            // Assert
            Assert.True(result.result);
            Assert.Equal(ResponseMessage.STATUS_DATA_FOUND, result.message);
        }

        [Fact]
        public async Task IsRolesAlreadyExist_ShouldReturnFalse_WhenrolesDoesNotExist()
        {
            // Arrange
            var rolesId = 3;

            // Act
            var result = await _rolesQueryService.IsRolesAlreadyExist(rolesId);

            // Assert
            Assert.False(result.result);
            Assert.Equal(ResponseMessage.STATUS_NODATA, result.message);
        }
    }
}
