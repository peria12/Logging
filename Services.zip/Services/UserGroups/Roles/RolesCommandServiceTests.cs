﻿using Aurora.AdministrationService.API.Models.Dto.UserGroups.Roles;
using Aurora.AdministrationService.API.Services.Service.UserGroups.Roles;
using Aurora.AdministrationService.Infrastructure;
using AutoMapper;
using Microsoft.EntityFrameworkCore;
using Moq;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Aurora.AdministrationService.Tests.API.Services.UserGroups.Roles
{
    public class RolesCommandServiceTests
    {
        private readonly Mock<ReadWriteDbContext> _readWriteDbContextMock;
        private readonly Mock<ReadOnlyDbContext> _readOnlyDbContextMock;
        private readonly Mock<IMapper> _mapperMock;
        private RolesCommandService _rolesCommandService;
        private readonly Mock<RolesQueryService> _rolesQueryService;

        public RolesCommandServiceTests()
        {
            // Initialize the mocks
            _mapperMock = new Mock<IMapper>();
            _readWriteDbContextMock = new Mock<ReadWriteDbContext>();
            _readOnlyDbContextMock = new Mock<ReadOnlyDbContext>();
            _rolesQueryService = new Mock<RolesQueryService>();


            // Setup in-memory ready only database for testing
            DbContextOptions<ReadWriteDbContext> options = new DbContextOptionsBuilder<ReadWriteDbContext>()
              .UseInMemoryDatabase(databaseName: "AdminRolesTestDB").Options;

            _readWriteDbContextMock = new(options);

            // Initialize the service being tested
            _rolesCommandService = new RolesCommandService(_readWriteDbContextMock.Object, _mapperMock.Object);
        }

        [Fact]
        public async Task CreateRolesAsync_ShouldReturnTrue_WhenRolesIsCreatedSuccessfully()
        {
            // Arrange
            var newRoles = new RolesDto
            {
                Code = "test",
                Location = "BRIM",
                IsObsolete = true,
                RoleName = "test",
                MenuID = 1,
                RoleDescription = "test",
                Source = "test",
            };

            // Mock AutoMapper to return a Roles entity
            var rolesEntity = new Domain.V1.Entities.UserGroups.Roles
            {
                Code = "test",
                Location = "BRIM",
                IsObsolete = true,
                RoleName = "test",
                MenuID = 1,
                RoleDescription = "test",
                Source = "test",
                IsDeleted = false,
                CreatedBy = "Admin",
                CreatedDate = DateTime.UtcNow,
                UpdatedBy = "Admin",  // Adding the missing property
                UpdatedDate = DateTime.UtcNow,// Assuming UpdatedDate is required as well
            };


            // Mock AutoMapper to return the Roles entity
            _mapperMock.Setup(m => m.Map<Domain.V1.Entities.UserGroups.Roles>(newRoles)).Returns(rolesEntity);

            // Mock DbContext to simulate saving the entity without actually hitting the database
            _readWriteDbContextMock.Setup(db => db.Roles.Add(It.IsAny<Domain.V1.Entities.UserGroups.Roles>()));

            // Act
            var result = await _rolesCommandService.CreateRolesAsync(newRoles);

            // Assert
            Assert.True(result);
            _readWriteDbContextMock.Verify(db => db.Roles.Add(It.Is<Domain.V1.Entities.UserGroups.Roles>(l => l.Source == "test")), Times.Once);
        }


        [Fact]
        public async Task CreateRolesAsync_ShouldReturnFalse_WhenExceptionOccurs()
        {
            // Arrange
            var newRoles = new RolesDto
            {
                Code = "test",
                Location = "BRIM",
                IsObsolete = true,
                RoleName = "test",
                MenuID = 1,
                RoleDescription = "test",
                Source = "test",
            };

            // Mock AutoMapper to return a Roles entity
            var rolesId = 1;
            var rolesEntity = new Domain.V1.Entities.UserGroups.Roles
            {
                Id = rolesId,
                Code = "test",
                Location = "BRIM",
                IsObsolete = true,
                RoleName = "test",
                MenuID = 1,
                RoleDescription = "test",
                Source = "test",
                IsDeleted = false,
                CreatedBy = "Admin",
                CreatedDate = DateTime.UtcNow,
                UpdatedBy = "Admin",  // Adding the missing property
                UpdatedDate = DateTime.UtcNow,// Assuming UpdatedDate is required as well
            };

            //Setup
            _mapperMock.Setup(m => m.Map<Domain.V1.Entities.UserGroups.Roles>(newRoles)).Returns(rolesEntity);

            // Act
            var result = await _rolesCommandService.CreateRolesAsync(newRoles);

            // Assert
            Assert.False(result);
        }
        [Fact]
        public async Task Test_UpdateRoles_Returns_Success()
        {
            //Arrange
            DbContextOptions<ReadWriteDbContext> options = new DbContextOptionsBuilder<ReadWriteDbContext>()
               .UseInMemoryDatabase(databaseName: "UpdateRoles").Options;

            byte[] concurrencyToken = new byte[8] { byte.MinValue, byte.MinValue, byte.MinValue, byte.MinValue, byte.MinValue, byte.MinValue, byte.MinValue, byte.MaxValue };
            var roles = new Domain.V1.Entities.UserGroups.Roles
            {
                Id = 1,
                Code = "test",
                Location = "BRIM",
                IsObsolete = true,
                RoleName = "test",
                MenuID = 1,
                RoleDescription = "test",
                Source = "test",
                IsDeleted = false,
                CreatedBy = "Admin",
                CreatedDate = DateTime.UtcNow,
                UpdatedBy = "Admin",  // Adding the missing property
                UpdatedDate = DateTime.UtcNow,// Assuming UpdatedDate is required as well
            };


            //Arrange
            using ReadWriteDbContext dbContext = new(options);
            dbContext.Roles.Add(roles);
            await dbContext.SaveChangesAsync();


            UpdateRolesRequest updateModel = new UpdateRolesRequest
            {
                Id = 1,
                Code = "test",
                Location = "BRIM",
                IsObsolete = true,
                RoleName = "test",
                MenuID = 1,
                RoleDescription = "test",
                Source = "test",
            };

            _rolesCommandService = new RolesCommandService(dbContext, _mapperMock.Object);

            // Act
            bool result = await _rolesCommandService.UpdateRolesAsync(updateModel, roles);

            Assert.True(result);
        }
        [Fact]
        public async Task Test_DeleteRoles_Returns_Success()
        {
            //Arrange
            DbContextOptions<ReadWriteDbContext> options = new DbContextOptionsBuilder<ReadWriteDbContext>()
               .UseInMemoryDatabase(databaseName: "DeleteRoles").Options;

            var roles = new Domain.V1.Entities.UserGroups.Roles
            {
                Id = 1,
                Code = "test",
                Location = "BRIM",
                IsObsolete = true,
                RoleName = "test",
                MenuID = 1,
                RoleDescription = "test",
                Source = "test",
                IsDeleted = false,
                CreatedBy = "Admin",
                CreatedDate = DateTime.UtcNow,
                UpdatedBy = "Admin",  // Adding the missing property
                UpdatedDate = DateTime.UtcNow,// Assuming UpdatedDate is required as well
            };



            //Arrange
            using ReadWriteDbContext dbContext = new(options);
            dbContext.Roles.Add(roles);
            await dbContext.SaveChangesAsync();

            _rolesCommandService = new RolesCommandService(dbContext, _mapperMock.Object);

            // Act
            bool result = await _rolesCommandService.DeleteRolesByIdAsync(roles);

            Assert.True(result);
        }
    }
}
