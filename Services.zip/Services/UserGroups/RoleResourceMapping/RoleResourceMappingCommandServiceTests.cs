﻿using Aurora.AdministrationService.API.Models.Dto.UserGroups.RoleResourceMapping;
using Aurora.AdministrationService.API.Services.Service.RBAUserGroupsC.RoleResourceMapping;
using Aurora.AdministrationService.API.Services.Service.UserGroups.RoleResourceMapping;
using Aurora.AdministrationService.Infrastructure;
using AutoMapper;
using Microsoft.EntityFrameworkCore;
using Moq;

namespace Aurora.AdministrationService.Tests.API.Services.UserGroups.RoleResourceMapping
{
    public class RoleResourceMappingCommandServiceTests
    {
        private readonly Mock<ReadWriteDbContext> _readWriteDbContextMock;
        private readonly Mock<ReadOnlyDbContext> _readOnlyDbContextMock;
        private readonly Mock<IMapper> _mapperMock;
        private RoleResourceMappingCommandService _roleResourceMappingCommandService;
        private readonly Mock<RoleResourceMappingQueryService> _roleResourceMappingQueryService;

        public RoleResourceMappingCommandServiceTests()
        {
            // Initialize the mocks
            _mapperMock = new Mock<IMapper>();
            _readWriteDbContextMock = new Mock<ReadWriteDbContext>();
            _readOnlyDbContextMock = new Mock<ReadOnlyDbContext>();
            _roleResourceMappingQueryService = new Mock<RoleResourceMappingQueryService>();


            // Setup in-memory ready only database for testing
            DbContextOptions<ReadWriteDbContext> options = new DbContextOptionsBuilder<ReadWriteDbContext>()
              .UseInMemoryDatabase(databaseName: "AdminRoleResourceMappingTestDB").Options;

            _readWriteDbContextMock = new(options);

            // Initialize the service being tested
            _roleResourceMappingCommandService = new RoleResourceMappingCommandService(_readWriteDbContextMock.Object, _mapperMock.Object);
        }

        [Fact]
        public async Task CreateRoleResourceMappingAsync_ShouldReturnTrue_WhenRoleResourceMappingIsCreatedSuccessfully()
        {
            // Arrange
            var newRoleResourceMapping = new RoleResourceMappingDto
            {
                Code = "test",
                ResourceID = 1,
                RoleID = 1,
                Definition = "test",
                Display = "test",
                IsEditAccess = true,
                Source = "test",
            };

            // Mock AutoMapper to return a RoleResourceMapping entity
            var roleResourceMappingEntity = new Domain.V1.Entities.UserGroups.RoleResourceMapping
            {
                Code = "test",
                ResourceID = 1,
                RoleID = 1,
                Definition = "test",
                Display = "test",
                IsEditAccess = true,
                Source = "test",
                IsDeleted = false,
                CreatedBy = "Admin",
                CreatedDate = DateTime.UtcNow,
                UpdatedBy = "Admin",  // Adding the missing property
                UpdatedDate = DateTime.UtcNow,// Assuming UpdatedDate is required as well
            };


            // Mock AutoMapper to return the RoleResourceMapping entity
            _mapperMock.Setup(m => m.Map<Domain.V1.Entities.UserGroups.RoleResourceMapping>(newRoleResourceMapping)).Returns(roleResourceMappingEntity);

            // Mock DbContext to simulate saving the entity without actually hitting the database
            _readWriteDbContextMock.Setup(db => db.RoleResourceMappings.Add(It.IsAny<Domain.V1.Entities.UserGroups.RoleResourceMapping>()));

            // Act
            var result = await _roleResourceMappingCommandService.CreateRoleResourceMappingAsync(newRoleResourceMapping);

            // Assert
            Assert.True(result);
            _readWriteDbContextMock.Verify(db => db.RoleResourceMappings.Add(It.Is<Domain.V1.Entities.UserGroups.RoleResourceMapping>(l => l.Source == "test")), Times.Once);
        }


        [Fact]
        public async Task CreateRoleResourceMappingAsync_ShouldReturnFalse_WhenExceptionOccurs()
        {
            // Arrange
            var newRoleResourceMapping = new RoleResourceMappingDto
            {
                Code = "test",
                ResourceID = 1,
                RoleID = 1,
                Definition = "test",
                Display = "test",
                IsEditAccess = true,
                Source = "test",
            };

            // Mock AutoMapper to return a RoleResourceMapping entity
            var roleResourceMappingId = 1;
            var roleResourceMappingEntity = new Domain.V1.Entities.UserGroups.RoleResourceMapping
            {
                Id = roleResourceMappingId,
                Code = "test",
                ResourceID = 1,
                RoleID = 1,
                Definition = "test",
                Display = "test",
                IsEditAccess = true,
                Source = "test",
                IsDeleted = false,
                CreatedBy = "Admin",
                CreatedDate = DateTime.UtcNow,
                UpdatedBy = "Admin",  // Adding the missing property
                UpdatedDate = DateTime.UtcNow,// Assuming UpdatedDate is required as well
            };

            //Setup
            _mapperMock.Setup(m => m.Map<Domain.V1.Entities.UserGroups.RoleResourceMapping>(newRoleResourceMapping)).Returns(roleResourceMappingEntity);

            // Act
            var result = await _roleResourceMappingCommandService.CreateRoleResourceMappingAsync(newRoleResourceMapping);

            // Assert
            Assert.False(result);
        }
        [Fact]
        public async Task Test_UpdateRoleResourceMapping_Returns_Success()
        {
            //Arrange
            DbContextOptions<ReadWriteDbContext> options = new DbContextOptionsBuilder<ReadWriteDbContext>()
               .UseInMemoryDatabase(databaseName: "UpdateRoleResourceMapping").Options;

            byte[] concurrencyToken = new byte[8] { byte.MinValue, byte.MinValue, byte.MinValue, byte.MinValue, byte.MinValue, byte.MinValue, byte.MinValue, byte.MaxValue };
            var roleResourceMapping = new Domain.V1.Entities.UserGroups.RoleResourceMapping
            {
                Id = 1,
                Code = "test",
                ResourceID = 1,
                RoleID = 1,
                Definition = "test",
                Display = "test",
                IsEditAccess = true,
                Source = "test",
                IsDeleted = false,
                CreatedBy = "Admin",
                CreatedDate = DateTime.UtcNow,
                UpdatedBy = "Admin",  // Adding the missing property
                UpdatedDate = DateTime.UtcNow,// Assuming UpdatedDate is required as well
            };


            //Arrange
            using ReadWriteDbContext dbContext = new(options);
            dbContext.RoleResourceMappings.Add(roleResourceMapping);
            await dbContext.SaveChangesAsync();


            UpdateRoleResourceMappingRequest updateModel = new UpdateRoleResourceMappingRequest
            {
                Id = 1,
                Code = "test",
                ResourceID = 1,
                RoleID = 1,
                Definition = "test",
                Display = "test",
                IsEditAccess = true,
                Source = "test",
            };

            _roleResourceMappingCommandService = new RoleResourceMappingCommandService(dbContext, _mapperMock.Object);

            // Act
            bool result = await _roleResourceMappingCommandService.UpdateRoleResourceMappingAsync(updateModel, roleResourceMapping);

            Assert.True(result);
        }
        [Fact]
        public async Task Test_DeleteRoleResourceMapping_Returns_Success()
        {
            //Arrange
            DbContextOptions<ReadWriteDbContext> options = new DbContextOptionsBuilder<ReadWriteDbContext>()
               .UseInMemoryDatabase(databaseName: "DeleteRoleResourceMapping").Options;

            var roleResourceMapping = new Domain.V1.Entities.UserGroups.RoleResourceMapping
            {
                Id = 1,
                Code = "test",
                ResourceID = 1,
                RoleID = 1,
                Definition = "test",
                Display = "test",
                IsEditAccess = true,
                Source = "test",
                IsDeleted = false,
                CreatedBy = "Admin",
                CreatedDate = DateTime.UtcNow,
                UpdatedBy = "Admin",  // Adding the missing property
                UpdatedDate = DateTime.UtcNow,// Assuming UpdatedDate is required as well
            };



            //Arrange
            using ReadWriteDbContext dbContext = new(options);
            dbContext.RoleResourceMappings.Add(roleResourceMapping);
            await dbContext.SaveChangesAsync();

            _roleResourceMappingCommandService = new RoleResourceMappingCommandService(dbContext, _mapperMock.Object);

            // Act
            bool result = await _roleResourceMappingCommandService.DeleteRoleResourceMappingByIdAsync(roleResourceMapping);

            Assert.True(result);
        }
    }
}
