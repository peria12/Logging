﻿using Aurora.AdministrationService.API.Models.Dto.UserGroups.RoleResourceMapping;
using Aurora.AdministrationService.API.Services.Service.RBAUserGroupsC.RoleResourceMapping;
using Aurora.AdministrationService.CrossCutting.CommonModels;
using Aurora.AdministrationService.Infrastructure;
using AutoMapper;
using Microsoft.EntityFrameworkCore;
using Moq;

namespace Aurora.AdministrationService.Tests.API.Services.UserGroups.RoleResourceMapping
{
    public class RoleResourceMappingQueryServiceTests
    {
        private readonly Mock<ReadOnlyDbContext> _readOnlyDbContextMock;
        private readonly Mock<IMapper> _mapperMock;
        private readonly RoleResourceMappingQueryService _roleResourceMappingQueryService;
        private Mock<DbSet<Domain.V1.Entities.UserGroups.RoleResourceMapping>> _mockDbSet;

        public RoleResourceMappingQueryServiceTests()
        {
            //Initialize mock
            _readOnlyDbContextMock = new Mock<ReadOnlyDbContext>();
            _mapperMock = new Mock<IMapper>();

            // Setup in-memory ready only database for testing
            DbContextOptions<ReadOnlyDbContext> options = new DbContextOptionsBuilder<ReadOnlyDbContext>()
              .UseInMemoryDatabase(databaseName: "RoleResourceMappingTestDB").Options;

            _readOnlyDbContextMock = new(options);

            _mockDbSet = new Mock<DbSet<Domain.V1.Entities.UserGroups.RoleResourceMapping>>();

            var data = new List<Domain.V1.Entities.UserGroups.RoleResourceMapping>
            {
               new Domain.V1.Entities.UserGroups.RoleResourceMapping {
                Id = 1,
                Code = "test",
                ResourceID = 1,
                RoleID = 1,
                Definition="test",
                Display="test",
                IsEditAccess=true,
                Source = "test",
                IsDeleted = false,
                CreatedBy = "Admin",
                CreatedDate = DateTime.UtcNow,
                UpdatedBy = "Admin",  // Adding the missing property
                UpdatedDate = DateTime.UtcNow,// Assuming UpdatedDate is required as well
            },
               new Domain.V1.Entities.UserGroups.RoleResourceMapping {
                Id = 2,
                Code = "test",
                ResourceID = 1,
                RoleID = 1,
                Definition="test",
                Display="test",
                IsEditAccess=true,
                Source = "test",
                IsDeleted = false,
                CreatedBy = "Admin",
                CreatedDate = DateTime.UtcNow,
                UpdatedBy = "Admin",  // Adding the missing property
                UpdatedDate = DateTime.UtcNow,// Assuming UpdatedDate is required as well
            }

            }.AsQueryable();


            //Setup
            _mockDbSet.As<IQueryable<Domain.V1.Entities.UserGroups.RoleResourceMapping>>().Setup(m => m.Provider).Returns(data.Provider);
            _mockDbSet.As<IQueryable<Domain.V1.Entities.UserGroups.RoleResourceMapping>>().Setup(m => m.Expression).Returns(data.Expression);
            _mockDbSet.As<IQueryable<Domain.V1.Entities.UserGroups.RoleResourceMapping>>().Setup(m => m.ElementType).Returns(data.ElementType);
            _mockDbSet.As<IQueryable<Domain.V1.Entities.UserGroups.RoleResourceMapping>>().Setup(m => m.GetEnumerator()).Returns(data.GetEnumerator());
            _readOnlyDbContextMock.Setup(c => c.RoleResourceMappings).Returns(_mockDbSet.Object);

            // Create the service instance
            _roleResourceMappingQueryService = new RoleResourceMappingQueryService(_readOnlyDbContextMock.Object, _mapperMock.Object);
        }

        [Fact]
        public async Task GetRoleResourceMappingById_LogoExists_ReturnsLogoDetailDto()
        {
            // Arrange
            var roleResourceMappingId = 1;
            var roleResourceMapping = new Domain.V1.Entities.UserGroups.RoleResourceMapping
            {
                Id = 1,
                Code = "test",
                ResourceID = 1,
                RoleID = 1,
                Definition = "test",
                Display = "test",
                IsEditAccess = true,
                Source = "test",
                IsDeleted = false,
                CreatedBy = "Admin",
                CreatedDate = DateTime.UtcNow,
                UpdatedBy = "Admin",  // Adding the missing property
                UpdatedDate = DateTime.UtcNow,// Assuming UpdatedDate is required as well
            };

            var roleResourceMappingDto = new GetRoleResourceMappingDetailDto
            {
                Id = 1,
                Code = "test",
                ResourceID = 1,
                RoleID = 1,
                Definition = "test",
                Display = "test",
                IsEditAccess = true,
                Source = "test",
            };

            _readOnlyDbContextMock.Setup(db => db.RoleResourceMappings.FindAsync(roleResourceMappingId))
                .ReturnsAsync(roleResourceMapping);

            _mapperMock.Setup(m => m.Map<GetRoleResourceMappingDetailDto>(roleResourceMapping))
                .Returns(roleResourceMappingDto);

            // Act
            var result = await _roleResourceMappingQueryService.GetRoleResourceMappingById(roleResourceMappingId);

            // Assert
            Assert.NotNull(result);
            Assert.Equal(roleResourceMappingId, result.Id);
            Assert.Equal("test", result.Code);
        }

        [Fact]
        public async Task GetRoleResourceMappingById_roleResourceMappingNotFound_ReturnsNull()
        {
            //Arrange
            var roleResourceMappingId = 1;
            var roleResourceMapping = new Domain.V1.Entities.UserGroups.RoleResourceMapping
            {
                Id = 1,
                Code = "test",
                ResourceID = 1,
                RoleID = 1,
                Definition = "test",
                Display = "test",
                IsEditAccess = true,
                Source = "test",
                IsDeleted = false,
                CreatedBy = "Admin",
                CreatedDate = DateTime.UtcNow,
                UpdatedBy = "Admin",  // Adding the missing property
                UpdatedDate = DateTime.UtcNow,// Assuming UpdatedDate is required as well
            };

            _readOnlyDbContextMock.Setup(db => db.RoleResourceMappings.FindAsync(roleResourceMappingId))
                .ReturnsAsync(roleResourceMapping);

            //Act
            var result = await _roleResourceMappingQueryService.GetRoleResourceMappingById(roleResourceMappingId);

            //Assert
            Assert.Null(result);
        }

        [Fact]
        public async Task GetRoleResourceMappingById_roleResourceMappingExists_BindingError_ReturnsNull()
        {
            // Arrange
            byte[] concurrencyToken = new byte[8] { byte.MinValue, byte.MinValue, byte.MinValue, byte.MinValue, byte.MinValue, byte.MinValue, byte.MinValue, byte.MaxValue };
            var roleResourceMappingId = 1;
            var roleResourceMapping = new Domain.V1.Entities.UserGroups.RoleResourceMapping
            {
                Id = 1,
                Code = "test",
                ResourceID = 1,
                RoleID = 1,
                Definition = "test",
                Display = "test",
                IsEditAccess = true,
                Source = "test",
                IsDeleted = false,
                CreatedBy = "Admin",
                CreatedDate = DateTime.UtcNow,
                UpdatedBy = "Admin",  // Adding the missing property
                UpdatedDate = DateTime.UtcNow,// Assuming UpdatedDate is required as well
            };

            _readOnlyDbContextMock.Setup(db => db.RoleResourceMappings.FindAsync(roleResourceMappingId))
                .ReturnsAsync(roleResourceMapping);

            _mapperMock.Setup(m => m.Map<GetRoleResourceMappingDetailDto>(roleResourceMapping))
                .Throws(new AutoMapperMappingException("Error mapping entity to DTO"));

            // Act & Assert
            var exception = await Assert.ThrowsAsync<AutoMapperMappingException>(
                () => _roleResourceMappingQueryService.GetRoleResourceMappingById(roleResourceMappingId)
            );

            Assert.Equal("Error mapping entity to DTO", exception.Message);
        }

        [Fact]
        public async Task FindRoleResourceMappingById_roleResourceMappingExists_ReturnsroleResourceMapping()
        {
            // Arrange
            byte[] concurrencyToken = new byte[8] { byte.MinValue, byte.MinValue, byte.MinValue, byte.MinValue, byte.MinValue, byte.MinValue, byte.MinValue, byte.MaxValue };
            int roleResourceMappingId = 1;
            var roleResourceMapping = new Domain.V1.Entities.UserGroups.RoleResourceMapping
            {
                Id = roleResourceMappingId,
                Code = "test",
                ResourceID = 1,
                RoleID = 1,
                Definition = "test",
                Display = "test",
                IsEditAccess = true,
                Source = "test",
                IsDeleted = false,
                CreatedBy = "Admin",
                CreatedDate = DateTime.UtcNow,
                UpdatedBy = "Admin",  // Adding the missing property
                UpdatedDate = DateTime.UtcNow,// Assuming UpdatedDate is required as well
            };

            // Mock the FindAsync method to return the roleResourceMapping
            _readOnlyDbContextMock.Setup(db => db.RoleResourceMappings.FindAsync(roleResourceMappingId))
                .ReturnsAsync(roleResourceMapping);

            // Act
            var result = await _roleResourceMappingQueryService.FindRoleResourceMappingById(roleResourceMappingId);

            // Assert
            Assert.NotNull(result);
        }

        [Fact]
        public async Task FindRoleResourceMappingById_roleResourceMappingNotFound_ReturnsNull()
        {
            // Arrange
            var roleResourceMappingId = 1;
            var roleResourceMapping = new Domain.V1.Entities.UserGroups.RoleResourceMapping
            {
                Id = roleResourceMappingId,
                Code = "test",
                ResourceID = 1,
                RoleID = 1,
                Definition = "test",
                Display = "test",
                IsEditAccess = true,
                Source = "test",
                IsDeleted = false,
                CreatedBy = "Admin",
                CreatedDate = DateTime.UtcNow,
                UpdatedBy = "Admin",  // Adding the missing property
                UpdatedDate = DateTime.UtcNow,// Assuming UpdatedDate is required as well
            };

            // Mock the FindAsync method to return null (roleResourceMapping not found)
            _readOnlyDbContextMock.Setup(db => db.RoleResourceMappings.FindAsync(roleResourceMappingId))
                .ReturnsAsync(roleResourceMapping);

            // Act
            var result = await _roleResourceMappingQueryService.FindRoleResourceMappingById(roleResourceMappingId);

            // Assert
            Assert.NotNull(result);
        }

        [Fact]
        public void GetRoleResourceMappingList_ReturnsCorrectRoleResourceMappingList()
        {
            // Act
            var result = _roleResourceMappingQueryService.GetRoleResourceMappingList();

            // Assert
            Assert.NotNull(result);
            Assert.Equal(2, result.Count); // Verifying that 3 items are returned

            // Verifying that the returned items are mapped correctly
            Assert.Contains(result, r => r.Id == 1 && r.Code == "test");
            Assert.Contains(result, r => r.Id == 2 && r.Code == "test");
        }

        [Fact]
        public async Task IsRoleResourceMappingAlreadyExist_ShouldReturnTrue_WhenroleResourceMappingExists()
        {
            // Arrange
            var roleResourceMappingId = 1;
            var roleResourceMapping = new Domain.V1.Entities.UserGroups.RoleResourceMapping
            {
                Id = 1,
                Code = "test",
                ResourceID = 1,
                RoleID = 1,
                Definition = "test",
                Display = "test",
                IsEditAccess = true,
                Source = "test",
                IsDeleted = false,
                CreatedBy = "Admin",
                CreatedDate = DateTime.UtcNow,
                UpdatedBy = "Admin",  // Adding the missing property
                UpdatedDate = DateTime.UtcNow,// Assuming UpdatedDate is required as well
            };

            // Mock the FindAsync method to return the roleResourceMapping
            _readOnlyDbContextMock.Setup(db => db.RoleResourceMappings.FindAsync(roleResourceMappingId))
                .ReturnsAsync(roleResourceMapping);

            // Act
            var result = await _roleResourceMappingQueryService.IsRoleResourceMappingAlreadyExist(roleResourceMappingId);

            // Assert
            Assert.True(result.result);
            Assert.Equal(ResponseMessage.STATUS_DATA_FOUND, result.message);
        }

        [Fact]
        public async Task IsRoleResourceMappingAlreadyExist_ShouldReturnFalse_WhenroleResourceMappingDoesNotExist()
        {
            // Arrange
            var roleResourceMappingId = 3;

            // Act
            var result = await _roleResourceMappingQueryService.IsRoleResourceMappingAlreadyExist(roleResourceMappingId);

            // Assert
            Assert.False(result.result);
            Assert.Equal(ResponseMessage.STATUS_NODATA, result.message);
        }
    }
}
