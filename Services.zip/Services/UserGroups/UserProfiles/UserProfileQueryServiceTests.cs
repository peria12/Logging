﻿using Aurora.AdministrationService.API.Models.Dto.UserGroups.UserProfiles;
using Aurora.AdministrationService.API.Services.Service.UserGroups.UserProfiles;
using Aurora.AdministrationService.CrossCutting.CommonModels;
using Aurora.AdministrationService.Infrastructure;
using AutoMapper;
using Microsoft.EntityFrameworkCore;
using Moq;

namespace Aurora.AdministrationService.Tests.API.Services.UserGroups.UserProfiles
{
    public class UserProfileQueryServiceTests
    {
        private readonly Mock<ReadOnlyDbContext> _readOnlyDbContextMock;
        private readonly Mock<IMapper> _mapperMock;
        private readonly UserProfileQueryService _userProfileQueryService;
        private Mock<DbSet<Domain.V1.Entities.UserGroups.UserProfile>> _mockDbSet;

        public UserProfileQueryServiceTests()
        {
            //Initialize mock
            _readOnlyDbContextMock = new Mock<ReadOnlyDbContext>();
            _mapperMock = new Mock<IMapper>();

            // Setup in-memory ready only database for testing
            DbContextOptions<ReadOnlyDbContext> options = new DbContextOptionsBuilder<ReadOnlyDbContext>()
              .UseInMemoryDatabase(databaseName: "UserProfileTestDB").Options;

            _readOnlyDbContextMock = new(options);

            _mockDbSet = new Mock<DbSet<Domain.V1.Entities.UserGroups.UserProfile>>();
            var data = new List<Domain.V1.Entities.UserGroups.UserProfile>
            {
               new Domain.V1.Entities.UserGroups.UserProfile {
                Id = 1,
                MenuID = 1,
                EmployeeTypeID = 1,
                EmployeeID = 1,
                DepartmentID = 1,
                GroupID = 1,
                Birthdate = DateTime.UtcNow,
                CityCode = "BAL",
                CountryCode = "MYS",
                FirstName = "John",
                HomePage = 1,
                HouseNo = "test",
                HouseNoCode = 1001,
                LastName = "test",
                Mobile = "test",
                MobileCode = 1,
                OfficeNo = "test",
                OfficeNoCode = 1,
                PostCode = "test",
                PrimaryEmailID = "test",
                ReportingManagerID = 1,
                SecondaryEmailID = "test",
                SignatureFileName = "test",
                StateCode = "test",
                Street1 = "5th Avenue",
                Street2 = "test",
                Street3 = "test",
                Street4 = "test",
                UserID = 1,
                UserProfileCode = "test",
                IsDeleted = false,
                CreatedBy = "Admin",
                CreatedDate = DateTime.UtcNow,
                UpdatedBy = "Admin",  // Adding the missing property
                UpdatedDate = DateTime.UtcNow,// Assuming UpdatedDate is required as well
            },
               new Domain.V1.Entities.UserGroups.UserProfile {
                Id = 2,
                MenuID = 1,
                EmployeeTypeID = 1,
                EmployeeID = 1,
                DepartmentID = 1,
                GroupID = 1,
                Birthdate = DateTime.UtcNow,
                CityCode = "BAL",
                CountryCode = "MYS",
                FirstName = "John",
                HomePage = 1,
                HouseNo = "test",
                HouseNoCode = 1001,
                LastName = "test",
                Mobile = "test",
                MobileCode = 1,
                OfficeNo = "test",
                OfficeNoCode = 1,
                PostCode = "test",
                PrimaryEmailID = "test",
                ReportingManagerID = 1,
                SecondaryEmailID = "test",
                SignatureFileName = "test",
                StateCode = "test",
                Street1 = "5th Avenue",
                Street2 = "test",
                Street3 = "test",
                Street4 = "test",
                UserID = 1,
                UserProfileCode = "test",
                IsDeleted = false,
                CreatedBy = "Admin",
                CreatedDate = DateTime.UtcNow,
                UpdatedBy = "Admin",  // Adding the missing property
                UpdatedDate = DateTime.UtcNow,// Assuming UpdatedDate is required as well
            }

            }.AsQueryable();


            //Setup
            _mockDbSet.As<IQueryable<Domain.V1.Entities.UserGroups.UserProfile>>().Setup(m => m.Provider).Returns(data.Provider);
            _mockDbSet.As<IQueryable<Domain.V1.Entities.UserGroups.UserProfile>>().Setup(m => m.Expression).Returns(data.Expression);
            _mockDbSet.As<IQueryable<Domain.V1.Entities.UserGroups.UserProfile>>().Setup(m => m.ElementType).Returns(data.ElementType);
            _mockDbSet.As<IQueryable<Domain.V1.Entities.UserGroups.UserProfile>>().Setup(m => m.GetEnumerator()).Returns(data.GetEnumerator());
            _readOnlyDbContextMock.Setup(c => c.UserProfiles).Returns(_mockDbSet.Object);

            // Create the service instance
            _userProfileQueryService = new UserProfileQueryService(_readOnlyDbContextMock.Object, _mapperMock.Object);
        }

        [Fact]
        public async Task GetUserProfileById_LogoExists_ReturnsLogoDetailDto()
        {
            // Arrange
            var userProfileId = 1;
            var userProfile = new Domain.V1.Entities.UserGroups.UserProfile
            {
                Id = 1,
                MenuID = 1,
                EmployeeTypeID = 1,
                EmployeeID = 1,
                DepartmentID = 1,
                GroupID = 1,
                Birthdate = DateTime.UtcNow,
                CityCode = "BAL",
                CountryCode = "MYS",
                FirstName = "John",
                HomePage = 1,
                HouseNo = "test",
                HouseNoCode = 1001,
                LastName = "test",
                Mobile = "test",
                MobileCode = 1,
                OfficeNo = "test",
                OfficeNoCode = 1,
                PostCode = "test",
                PrimaryEmailID = "test",
                ReportingManagerID = 1,
                SecondaryEmailID = "test",
                SignatureFileName = "test",
                StateCode = "test",
                Street1 = "5th Avenue",
                Street2 = "test",
                Street3 = "test",
                Street4 = "test",
                UserID = 1,
                UserProfileCode = "test",
                IsDeleted = false,
                CreatedBy = "Admin",
                CreatedDate = DateTime.UtcNow,
                UpdatedBy = "Admin",  // Adding the missing property
                UpdatedDate = DateTime.UtcNow,// Assuming UpdatedDate is required as well
            };

            var userProfileDto = new GetUserProfileDetailDto
            {
                Id = 1,
                MenuID = 1,
                EmployeeTypeID = 1,
                EmployeeID = 1,
                DepartmentID = 1,
                GroupID = 1,
                Birthdate = DateTime.UtcNow,
                CityCode = "BAL",
                CountryCode = "MYS",
                FirstName = "John",
                HomePage = 1,
                HouseNo = "test",
                HouseNoCode = 1001,
                LastName = "test",
                Mobile = "test",
                MobileCode = 1,
                OfficeNo = "test",
                OfficeNoCode = 1,
                PostCode = "test",
                PrimaryEmailID = "test",
                ReportingManagerID = 1,
                SecondaryEmailID = "test",
                SignatureFileName = "test",
                StateCode = "test",
                Street1 = "5th Avenue",
                Street2 = "test",
                Street3 = "test",
                Street4 = "test",
                UserID = 1,
                UserProfileCode = "test",
            };

            _readOnlyDbContextMock.Setup(db => db.UserProfiles.FindAsync(userProfileId))
                .ReturnsAsync(userProfile);

            _mapperMock.Setup(m => m.Map<GetUserProfileDetailDto>(userProfile))
                .Returns(userProfileDto);

            // Act
            var result = await _userProfileQueryService.GetUserProfileById(userProfileId);

            // Assert
            Assert.NotNull(result);
            Assert.Equal(userProfileId, result.Id);
            Assert.Equal("test", result.Street2);
        }

        [Fact]
        public async Task GetUserProfileById_userProfileNotFound_ReturnsNull()
        {
            //Arrange
            var userProfileId = 1;
            var userProfile = new Domain.V1.Entities.UserGroups.UserProfile
            {
                Id = 1,
                MenuID = 1,
                EmployeeTypeID = 1,
                EmployeeID = 1,
                DepartmentID = 1,
                GroupID = 1,
                Birthdate = DateTime.UtcNow,
                CityCode = "BAL",
                CountryCode = "MYS",
                FirstName = "John",
                HomePage = 1,
                HouseNo = "test",
                HouseNoCode = 1001,
                LastName = "test",
                Mobile = "test",
                MobileCode = 1,
                OfficeNo = "test",
                OfficeNoCode = 1,
                PostCode = "test",
                PrimaryEmailID = "test",
                ReportingManagerID = 1,
                SecondaryEmailID = "test",
                SignatureFileName = "test",
                StateCode = "test",
                Street1 = "5th Avenue",
                Street2 = "test",
                Street3 = "test",
                Street4 = "test",
                UserID = 1,
                UserProfileCode = "test",
                IsDeleted = false,
                CreatedBy = "Admin",
                CreatedDate = DateTime.UtcNow,
                UpdatedBy = "Admin",  // Adding the missing property
                UpdatedDate = DateTime.UtcNow,// Assuming UpdatedDate is required as well
            };

            _readOnlyDbContextMock.Setup(db => db.UserProfiles.FindAsync(userProfileId))
                .ReturnsAsync(userProfile);

            //Act
            var result = await _userProfileQueryService.GetUserProfileById(userProfileId);

            //Assert
            Assert.Null(result);
        }

        [Fact]
        public async Task GetUserProfileById_userProfileExists_BindingError_ReturnsNull()
        {
            // Arrange
            byte[] concurrencyToken = new byte[8] { byte.MinValue, byte.MinValue, byte.MinValue, byte.MinValue, byte.MinValue, byte.MinValue, byte.MinValue, byte.MaxValue };
            var userProfileId = 1;
            var userProfile = new Domain.V1.Entities.UserGroups.UserProfile
            {
                Id = 1,
                MenuID = 1,
                EmployeeTypeID = 1,
                EmployeeID = 1,
                DepartmentID = 1,
                GroupID = 1,
                Birthdate = DateTime.UtcNow,
                CityCode = "BAL",
                CountryCode = "MYS",
                FirstName = "John",
                HomePage = 1,
                HouseNo = "test",
                HouseNoCode = 1001,
                LastName = "test",
                Mobile = "test",
                MobileCode = 1,
                OfficeNo = "test",
                OfficeNoCode = 1,
                PostCode = "test",
                PrimaryEmailID = "test",
                ReportingManagerID = 1,
                SecondaryEmailID = "test",
                SignatureFileName = "test",
                StateCode = "test",
                Street1 = "5th Avenue",
                Street2 = "test",
                Street3 = "test",
                Street4 = "test",
                UserID = 1,
                UserProfileCode = "test",
                IsDeleted = false,
                CreatedBy = "Admin",
                CreatedDate = DateTime.UtcNow,
                UpdatedBy = "Admin",  // Adding the missing property
                UpdatedDate = DateTime.UtcNow,// Assuming UpdatedDate is required as well
            };

            _readOnlyDbContextMock.Setup(db => db.UserProfiles.FindAsync(userProfileId))
                .ReturnsAsync(userProfile);

            _mapperMock.Setup(m => m.Map<GetUserProfileDetailDto>(userProfile))
                .Throws(new AutoMapperMappingException("Error mapping entity to DTO"));

            // Act & Assert
            var exception = await Assert.ThrowsAsync<AutoMapperMappingException>(
                () => _userProfileQueryService.GetUserProfileById(userProfileId)
            );

            Assert.Equal("Error mapping entity to DTO", exception.Message);
        }

        [Fact]
        public async Task FindUserProfileById_userProfileExists_ReturnsuserProfile()
        {
            // Arrange
            byte[] concurrencyToken = new byte[8] { byte.MinValue, byte.MinValue, byte.MinValue, byte.MinValue, byte.MinValue, byte.MinValue, byte.MinValue, byte.MaxValue };
            int userProfileId = 1;
            var userProfile = new Domain.V1.Entities.UserGroups.UserProfile
            {
                Id = userProfileId,
                MenuID = 1,
                EmployeeTypeID = 1,
                EmployeeID = 1,
                DepartmentID = 1,
                GroupID = 1,
                Birthdate = DateTime.UtcNow,
                CityCode = "BAL",
                CountryCode = "MYS",
                FirstName = "John",
                HomePage = 1,
                HouseNo = "test",
                HouseNoCode = 1001,
                LastName = "test",
                Mobile = "test",
                MobileCode = 1,
                OfficeNo = "test",
                OfficeNoCode = 1,
                PostCode = "test",
                PrimaryEmailID = "test",
                ReportingManagerID = 1,
                SecondaryEmailID = "test",
                SignatureFileName = "test",
                StateCode = "test",
                Street1 = "5th Avenue",
                Street2 = "test",
                Street3 = "test",
                Street4 = "test",
                UserID = 1,
                UserProfileCode = "test",
                IsDeleted = false,
                CreatedBy = "Admin",
                CreatedDate = DateTime.UtcNow,
                UpdatedBy = "Admin",  // Adding the missing property
                UpdatedDate = DateTime.UtcNow,// Assuming UpdatedDate is required as well
            };

            // Mock the FindAsync method to return the userProfile
            _readOnlyDbContextMock.Setup(db => db.UserProfiles.FindAsync(userProfileId))
                .ReturnsAsync(userProfile);

            // Act
            var result = await _userProfileQueryService.FindUserProfileById(userProfileId);

            // Assert
            Assert.NotNull(result);
        }

        [Fact]
        public async Task FindUserProfileById_userProfileNotFound_ReturnsNull()
        {
            // Arrange
            var userProfileId = 1;
            var userProfile = new Domain.V1.Entities.UserGroups.UserProfile
            {
                Id = userProfileId,
                MenuID = 1,
                EmployeeTypeID = 1,
                EmployeeID = 1,
                DepartmentID = 1,
                GroupID = 1,
                Birthdate = DateTime.UtcNow,
                CityCode = "BAL",
                CountryCode = "MYS",
                FirstName = "John",
                HomePage = 1,
                HouseNo = "test",
                HouseNoCode = 1001,
                LastName = "test",
                Mobile = "test",
                MobileCode = 1,
                OfficeNo = "test",
                OfficeNoCode = 1,
                PostCode = "test",
                PrimaryEmailID = "test",
                ReportingManagerID = 1,
                SecondaryEmailID = "test",
                SignatureFileName = "test",
                StateCode = "test",
                Street1 = "5th Avenue",
                Street2 = "test",
                Street3 = "test",
                Street4 = "test",
                UserID = 1,
                UserProfileCode = "test",
                IsDeleted = false,
                CreatedBy = "Admin",
                CreatedDate = DateTime.UtcNow,
                UpdatedBy = "Admin",  // Adding the missing property
                UpdatedDate = DateTime.UtcNow,// Assuming UpdatedDate is required as well
            };

            // Mock the FindAsync method to return null (userProfile not found)
            _readOnlyDbContextMock.Setup(db => db.UserProfiles.FindAsync(userProfileId))
                .ReturnsAsync(userProfile);

            // Act
            var result = await _userProfileQueryService.FindUserProfileById(userProfileId);

            // Assert
            Assert.NotNull(result);
        }

        [Fact]
        public void GetUserProfileList_ReturnsCorrectUserProfileList()
        {
            // Act
            var result = _userProfileQueryService.GetUserProfileList();

            // Assert
            Assert.NotNull(result);
            Assert.Equal(2, result.Count); // Verifying that 3 items are returned

            // Verifying that the returned items are mapped correctly
            Assert.Contains(result, r => r.Id == 1 && r.Street2 == "test");
            Assert.Contains(result, r => r.Id == 2 && r.Street2 == "test");
        }

        [Fact]
        public async Task IsUserProfileAlreadyExist_ShouldReturnTrue_WhenuserProfileExists()
        {
            // Arrange
            var userProfileId = 1;
            var userProfile = new Domain.V1.Entities.UserGroups.UserProfile
            {
                Id = 1,
                MenuID = 1,
                EmployeeTypeID = 1,
                EmployeeID = 1,
                DepartmentID = 1,
                GroupID = 1,
                Birthdate = DateTime.UtcNow,
                CityCode = "BAL",
                CountryCode = "MYS",
                FirstName = "John",
                HomePage = 1,
                HouseNo = "test",
                HouseNoCode = 1001,
                LastName = "test",
                Mobile = "test",
                MobileCode = 1,
                OfficeNo = "test",
                OfficeNoCode = 1,
                PostCode = "test",
                PrimaryEmailID = "test",
                ReportingManagerID = 1,
                SecondaryEmailID = "test",
                SignatureFileName = "test",
                StateCode = "test",
                Street1 = "5th Avenue",
                Street2 = "test",
                Street3 = "test",
                Street4 = "test",
                UserID = 1,
                UserProfileCode = "test",
                IsDeleted = false,
                CreatedBy = "Admin",
                CreatedDate = DateTime.UtcNow,
                UpdatedBy = "Admin",  // Adding the missing property
                UpdatedDate = DateTime.UtcNow,// Assuming UpdatedDate is required as well
            };

            // Mock the FindAsync method to return the userProfile
            _readOnlyDbContextMock.Setup(db => db.UserProfiles.FindAsync(userProfileId))
                .ReturnsAsync(userProfile);

            // Act
            var result = await _userProfileQueryService.IsUserProfileAlreadyExist(userProfileId);

            // Assert
            Assert.True(result.result);
            Assert.Equal(ResponseMessage.STATUS_DATA_FOUND, result.message);
        }

        [Fact]
        public async Task IsUserProfileAlreadyExist_ShouldReturnFalse_WhenuserProfileDoesNotExist()
        {
            // Arrange
            var userProfileId = 3;

            // Act
            var result = await _userProfileQueryService.IsUserProfileAlreadyExist(userProfileId);

            // Assert
            Assert.False(result.result);
            Assert.Equal(ResponseMessage.STATUS_NODATA, result.message);
        }
    }
}
