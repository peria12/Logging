﻿using Aurora.AdministrationService.API.Models.Dto.UserGroups.UserProfiles;
using Aurora.AdministrationService.API.Services.Service.UserGroups.UserProfiles;
using Aurora.AdministrationService.Infrastructure;
using AutoMapper;
using Microsoft.EntityFrameworkCore;
using Moq;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Aurora.AdministrationService.Tests.API.Services.UserGroups.UserProfiles
{
    public class UserProfileCommandServiceTests
    {
        private readonly Mock<ReadWriteDbContext> _readWriteDbContextMock;
        private readonly Mock<ReadOnlyDbContext> _readOnlyDbContextMock;
        private readonly Mock<IMapper> _mapperMock;
        private UserProfileCommandService _userProfileCommandService;
        private readonly Mock<UserProfileQueryService> _userProfileQueryService;

        public UserProfileCommandServiceTests()
        {
            // Initialize the mocks
            _mapperMock = new Mock<IMapper>();
            _readWriteDbContextMock = new Mock<ReadWriteDbContext>();
            _readOnlyDbContextMock = new Mock<ReadOnlyDbContext>();
            _userProfileQueryService = new Mock<UserProfileQueryService>();


            // Setup in-memory ready only database for testing
            DbContextOptions<ReadWriteDbContext> options = new DbContextOptionsBuilder<ReadWriteDbContext>()
              .UseInMemoryDatabase(databaseName: "AdminUserProfileTestDB").Options;

            _readWriteDbContextMock = new(options);

            // Initialize the service being tested
            _userProfileCommandService = new UserProfileCommandService(_readWriteDbContextMock.Object, _mapperMock.Object);
        }

        [Fact]
        public async Task CreateUserProfileAsync_ShouldReturnTrue_WhenUserProfileIsCreatedSuccessfully()
        {
            // Arrange
            var newUserProfile = new UserProfileDto
            {
                MenuID = 1,
                EmployeeTypeID = 1,
                EmployeeID = 1,
                DepartmentID = 1,
                GroupID = 1,
                Birthdate = DateTime.UtcNow,
                CityCode = "BAL",
                CountryCode = "MYS",
                FirstName = "John",
                HomePage = 1,
                HouseNo = "test",
                HouseNoCode = 1001,
                LastName = "test",
                Mobile = "test",
                MobileCode = 1,
                OfficeNo = "test",
                OfficeNoCode = 1,
                PostCode = "test",
                PrimaryEmailID = "test",
                ReportingManagerID = 1,
                SecondaryEmailID = "test",
                SignatureFileName = "test",
                StateCode = "test",
                Street1 = "5th Avenue",
                Street2 = "test",
                Street3 = "test",
                Street4 = "test",
                UserID = 1,
                UserProfileCode = "test",
            };

            // Mock AutoMapper to return a UserProfile entity
            var userProfileEntity = new Domain.V1.Entities.UserGroups.UserProfile
            {
                MenuID = 1,
                EmployeeTypeID = 1,
                EmployeeID = 1,
                DepartmentID = 1,
                GroupID = 1,
                Birthdate = DateTime.UtcNow,
                CityCode = "BAL",
                CountryCode = "MYS",
                FirstName = "John",
                HomePage = 1,
                HouseNo = "test",
                HouseNoCode = 1001,
                LastName = "test",
                Mobile = "test",
                MobileCode = 1,
                OfficeNo = "test",
                OfficeNoCode = 1,
                PostCode = "test",
                PrimaryEmailID = "test",
                ReportingManagerID = 1,
                SecondaryEmailID = "test",
                SignatureFileName = "test",
                StateCode = "test",
                Street1 = "5th Avenue",
                Street2 = "test",
                Street3 = "test",
                Street4 = "test",
                UserID = 1,
                UserProfileCode = "test",
                IsDeleted = false,
                CreatedBy = "Admin",
                CreatedDate = DateTime.UtcNow,
                UpdatedBy = "Admin",  // Adding the missing property
                UpdatedDate = DateTime.UtcNow,// Assuming UpdatedDate is required as well
            };


            // Mock AutoMapper to return the UserProfile entity
            _mapperMock.Setup(m => m.Map<Domain.V1.Entities.UserGroups.UserProfile>(newUserProfile)).Returns(userProfileEntity);

            // Mock DbContext to simulate saving the entity without actually hitting the database
            _readWriteDbContextMock.Setup(db => db.UserProfiles.Add(It.IsAny<Domain.V1.Entities.UserGroups.UserProfile>()));

            // Act
            var result = await _userProfileCommandService.CreateUserProfileAsync(newUserProfile);

            // Assert
            Assert.True(result);
            _readWriteDbContextMock.Verify(db => db.UserProfiles.Add(It.Is<Domain.V1.Entities.UserGroups.UserProfile>(l => l.Street2 == "test")), Times.Once);
        }


        [Fact]
        public async Task CreateUserProfileAsync_ShouldReturnFalse_WhenExceptionOccurs()
        {
            // Arrange
            var newUserProfile = new UserProfileDto
            {
                MenuID = 1,
                EmployeeTypeID = 1,
                EmployeeID = 1,
                DepartmentID = 1,
                GroupID = 1,
                Birthdate = DateTime.UtcNow,
                CityCode = "BAL",
                CountryCode = "MYS",
                FirstName = "John",
                HomePage = 1,
                HouseNo = "test",
                HouseNoCode = 1001,
                LastName = "test",
                Mobile = "test",
                MobileCode = 1,
                OfficeNo = "test",
                OfficeNoCode = 1,
                PostCode = "test",
                PrimaryEmailID = "test",
                ReportingManagerID = 1,
                SecondaryEmailID = "test",
                SignatureFileName = "test",
                StateCode = "test",
                Street1 = "5th Avenue",
                Street2 = "test",
                Street3 = "test",
                Street4 = "test",
                UserID = 1,
                UserProfileCode = "test",
            };

            // Mock AutoMapper to return a UserProfile entity
            var userProfileId = 1;
            var userProfileEntity = new Domain.V1.Entities.UserGroups.UserProfile
            {
                Id = userProfileId,
                MenuID = 1,
                EmployeeTypeID = 1,
                EmployeeID = 1,
                DepartmentID = 1,
                GroupID = 1,
                Birthdate = DateTime.UtcNow,
                CityCode = "BAL",
                CountryCode = "MYS",
                FirstName = "John",
                HomePage = 1,
                HouseNo = "test",
                HouseNoCode = 1001,
                LastName = "test",
                Mobile = "test",
                MobileCode = 1,
                OfficeNo = "test",
                OfficeNoCode = 1,
                PostCode = "test",
                PrimaryEmailID = "test",
                ReportingManagerID = 1,
                SecondaryEmailID = "test",
                SignatureFileName = "test",
                StateCode = "test",
                Street1 = "5th Avenue",
                Street2 = "test",
                Street3 = "test",
                Street4 = "test",
                UserID = 1,
                UserProfileCode = "test",
                IsDeleted = false,
                CreatedBy = "Admin",
                CreatedDate = DateTime.UtcNow,
                UpdatedBy = "Admin",  // Adding the missing property
                UpdatedDate = DateTime.UtcNow,// Assuming UpdatedDate is required as well
            };

            //Setup
            _mapperMock.Setup(m => m.Map<Domain.V1.Entities.UserGroups.UserProfile>(newUserProfile)).Returns(userProfileEntity);

            // Act
            var result = await _userProfileCommandService.CreateUserProfileAsync(newUserProfile);

            // Assert
            Assert.False(result);
        }
        [Fact]
        public async Task Test_UpdateUserProfile_Returns_Success()
        {
            //Arrange
            DbContextOptions<ReadWriteDbContext> options = new DbContextOptionsBuilder<ReadWriteDbContext>()
               .UseInMemoryDatabase(databaseName: "UpdateUserProfile").Options;

            byte[] concurrencyToken = new byte[8] { byte.MinValue, byte.MinValue, byte.MinValue, byte.MinValue, byte.MinValue, byte.MinValue, byte.MinValue, byte.MaxValue };
            var userProfile = new Domain.V1.Entities.UserGroups.UserProfile
            {
                Id = 1,
                MenuID = 1,
                EmployeeTypeID = 1,
                EmployeeID = 1,
                DepartmentID = 1,
                GroupID = 1,
                Birthdate = DateTime.UtcNow,
                CityCode = "BAL",
                CountryCode = "MYS",
                FirstName = "John",
                HomePage = 1,
                HouseNo = "test",
                HouseNoCode = 1001,
                LastName = "test",
                Mobile = "test",
                MobileCode = 1,
                OfficeNo = "test",
                OfficeNoCode = 1,
                PostCode = "test",
                PrimaryEmailID = "test",
                ReportingManagerID = 1,
                SecondaryEmailID = "test",
                SignatureFileName = "test",
                StateCode = "test",
                Street1 = "5th Avenue",
                Street2 = "test",
                Street3 = "test",
                Street4 = "test",
                UserID = 1,
                UserProfileCode = "test",
                IsDeleted = false,
                CreatedBy = "Admin",
                CreatedDate = DateTime.UtcNow,
                UpdatedBy = "Admin",  // Adding the missing property
                UpdatedDate = DateTime.UtcNow,// Assuming UpdatedDate is required as well
            };


            //Arrange
            using ReadWriteDbContext dbContext = new(options);
            dbContext.UserProfiles.Add(userProfile);
            await dbContext.SaveChangesAsync();


            UpdateUserProfileRequest updateModel = new UpdateUserProfileRequest
            {
                Id = 1,
                MenuID = 1,
                EmployeeTypeID = 1,
                EmployeeID = 1,
                DepartmentID = 1,
                GroupID = 1,
                Birthdate = DateTime.UtcNow,
                CityCode = "BAL",
                CountryCode = "MYS",
                FirstName = "John",
                HomePage = 1,
                HouseNo = "test",
                HouseNoCode = 1001,
                LastName = "test",
                Mobile = "test",
                MobileCode = 1,
                OfficeNo = "test",
                OfficeNoCode = 1,
                PostCode = "test",
                PrimaryEmailID = "test",
                ReportingManagerID = 1,
                SecondaryEmailID = "test",
                SignatureFileName = "test",
                StateCode = "test",
                Street1 = "5th Avenue",
                Street2 = "test",
                Street3 = "test",
                Street4 = "test",
                UserID = 1,
                UserProfileCode = "test",
            };

            _userProfileCommandService = new UserProfileCommandService(dbContext, _mapperMock.Object);

            // Act
            bool result = await _userProfileCommandService.UpdateUserProfileAsync(updateModel, userProfile);

            Assert.True(result);
        }
        [Fact]
        public async Task Test_DeleteUserProfile_Returns_Success()
        {
            //Arrange
            DbContextOptions<ReadWriteDbContext> options = new DbContextOptionsBuilder<ReadWriteDbContext>()
               .UseInMemoryDatabase(databaseName: "DeleteUserProfile").Options;

            var userProfile = new Domain.V1.Entities.UserGroups.UserProfile
            {
                Id = 1,
                MenuID = 1,
                EmployeeTypeID = 1,
                EmployeeID = 1,
                DepartmentID = 1,
                GroupID = 1,
                Birthdate = DateTime.UtcNow,
                CityCode = "BAL",
                CountryCode = "MYS",
                FirstName = "John",
                HomePage = 1,
                HouseNo = "test",
                HouseNoCode = 1001,
                LastName = "test",
                Mobile = "test",
                MobileCode = 1,
                OfficeNo = "test",
                OfficeNoCode = 1,
                PostCode = "test",
                PrimaryEmailID = "test",
                ReportingManagerID = 1,
                SecondaryEmailID = "test",
                SignatureFileName = "test",
                StateCode = "test",
                Street1 = "5th Avenue",
                Street2 = "test",
                Street3 = "test",
                Street4 = "test",
                UserID = 1,
                UserProfileCode = "test",
                IsDeleted = false,
                CreatedBy = "Admin",
                CreatedDate = DateTime.UtcNow,
                UpdatedBy = "Admin",  // Adding the missing property
                UpdatedDate = DateTime.UtcNow,// Assuming UpdatedDate is required as well
            };



            //Arrange
            using ReadWriteDbContext dbContext = new(options);
            dbContext.UserProfiles.Add(userProfile);
            await dbContext.SaveChangesAsync();

            _userProfileCommandService = new UserProfileCommandService(dbContext, _mapperMock.Object);

            // Act
            bool result = await _userProfileCommandService.DeleteUserProfileByIdAsync(userProfile);

            Assert.True(result);
        }
    }
}
