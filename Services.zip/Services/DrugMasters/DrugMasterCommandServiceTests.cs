﻿using Aurora.AdministrationService.API.Models.Dto.DrugMasters;
using Aurora.AdministrationService.API.Services.Service.DrugMasters;
using Aurora.AdministrationService.Domain.V1.Entities.DrugMasters;
using Aurora.AdministrationService.Infrastructure;
using Aurora.AdministrationService.Tests.API.Controllers.DrugMasters;
using AutoMapper;
using FluentAssertions;
using Microsoft.EntityFrameworkCore;
using Moq;
using System.Text;

namespace Aurora.AdministrationService.Tests.API.Services.DrugMasters
{
    public class DrugMasterCommandServiceTests
    {
        private readonly DrugMasterCommandService _service;
        private readonly ReadWriteDbContext _dbContext;
        private readonly IMapper _mapper;

        public DrugMasterCommandServiceTests()
        {
            var options = new DbContextOptionsBuilder<ReadWriteDbContext>()
                .UseInMemoryDatabase(databaseName: "TestDatabase")
                .Options;

            _dbContext = new ReadWriteDbContext(options);

            var mapperConfig = new MapperConfiguration(cfg =>
            {
                cfg.CreateMap<CreateDrugMasterRequest, DrugMaster>();
                cfg.CreateMap<UpdateDrugMasterRequest, DrugMaster>()
                    .ForMember(dest => dest.ID, opt => opt.Ignore()); // Ignore the ID property
            });
            _mapper = mapperConfig.CreateMapper();

            _service = new DrugMasterCommandService(_dbContext, _mapper);
        }


        [Fact]
        public async Task AddDrugMasterAsync_ShouldAddDrugMasterSuccessfully()
        {
            // Arrange
            var request = CommonMockData.GetMockCreateDrugMasterRequest();

            // Act
            var result = await _service.AddDrugMasterAsync(request);
            var drug = await _dbContext.DrugMasters.FirstOrDefaultAsync(d => d.ItemCode == request.ItemCode);

            // Assert
            drug.Should().NotBeNull();
            drug?.CreatedBy.Should().Be("Admin");
            result.Should().NotBeNull();
        }

        [Fact]
        public async Task UpdateDrugMasterAsync_ShouldUpdateDrugMasterSuccessfully()
        {
            // Arrange
            await ClearDatabaseAsync(); 

            var drug = CommonMockData.GetMockDrugMaster2(id: 4);

            _dbContext.DrugMasters.Add(drug);
            await _dbContext.SaveChangesAsync();

            var existingDrug = await _dbContext.DrugMasters
                .FirstOrDefaultAsync(d => d.ItemCode == drug.ItemCode);

            existingDrug.Should().NotBeNull();

            var request = CommonMockData.GetMockUpdateDrugMasterRequest(
                drug.ItemCode,
                existingDrug?.RecordVersion
            );

            // Act
            var result = await _service.UpdateDrugMasterAsync(request, existingDrug!);

            // Assert
            var updatedDrug = await _dbContext.DrugMasters
                .AsNoTracking().FirstOrDefaultAsync(d => d.ItemCode == drug.ItemCode);

            updatedDrug.Should().NotBeNull();
            updatedDrug?.UpdatedBy.Should().Be("Admin"); 
            updatedDrug?.UpdatedDate.Should().BeCloseTo(DateTime.UtcNow, TimeSpan.FromSeconds(1));

            // Verify the result
            result.Should().NotBeNull();
            result.ItemCode.Should().Be(drug.ItemCode); 
        }

        [Fact]
        public async Task DeleteDrugMasterAsync_ShouldSoftDelete_WhenRecordExists()
        {
            // Arrange
            var drug = new DrugMaster
            {
                ItemCode = "DRUG123",
                CreatedDate = DateTime.UtcNow,
                IsDeleted = false,
                MasterType = "General",
                MedicationCode = "MED123",
                ResourceID = "RESOURCE001",
                RecordVersion = Encoding.UTF8.GetBytes("1"),
                UpdatedBy = null,
                UpdatedDate = null
            };

            await _dbContext.DrugMasters.AddAsync(drug);
            await _dbContext.SaveChangesAsync();

            var existingDrug = await _dbContext.DrugMasters.FirstOrDefaultAsync(d => d.ItemCode == drug.ItemCode);
            existingDrug.Should().NotBeNull();
            var originalRecordVersion = existingDrug?.RecordVersion;

            // Act
            var result = await _service.DeleteDrugMasterAsync(originalRecordVersion!, existingDrug!);

            // Assert
            result.Should().BeTrue();

            var deletedDrug = await _dbContext.DrugMasters.FirstOrDefaultAsync(d => d.ItemCode == drug.ItemCode);
            deletedDrug.Should().NotBeNull();
            deletedDrug?.IsDeleted.Should().BeTrue();
            deletedDrug?.UpdatedBy.Should().Be("Admin");
            deletedDrug?.UpdatedDate.Should().BeCloseTo(DateTime.UtcNow, TimeSpan.FromSeconds(1));
        }

        [Fact]
        public async Task DeleteDrugMasterAsync_ShouldThrowException_WhenRecordVersionMismatch()
        {
            // Arrange
            var drug = new DrugMaster
            {
                ItemCode = "DRUG123",
                CreatedDate = DateTime.UtcNow,
                IsDeleted = false,
                MasterType = "General",
                MedicationCode = "MED123",
                ResourceID = "RESOURCE001",
                RecordVersion = Encoding.UTF8.GetBytes("1"),
            };

            await _dbContext.DrugMasters.AddAsync(drug);
            await _dbContext.SaveChangesAsync();

            var existingDrug = await _dbContext.DrugMasters.FirstOrDefaultAsync(d => d.ItemCode == drug.ItemCode);

            // Explicit null check to satisfy compiler
            existingDrug.Should().NotBeNull();
            if (existingDrug is null)
            {
                throw new InvalidOperationException("Expected existingDrug to be non-null, but it was null.");
            }

            // Act
            Func<Task> act = async () => await _service.DeleteDrugMasterAsync(Encoding.UTF8.GetBytes("2"), existingDrug);

            // Assert
            await act.Should().ThrowAsync<DbUpdateConcurrencyException>();
        }


        private static async Task ClearDatabaseAsync()
        {
            var options = new DbContextOptionsBuilder<ReadWriteDbContext>()
                .UseInMemoryDatabase(databaseName: Guid.NewGuid().ToString())
                .Options;

            using var dbContext = new ReadWriteDbContext(options);
            dbContext.DrugMasters.RemoveRange(dbContext.DrugMasters);
            await dbContext.SaveChangesAsync();
        }
    }
}
