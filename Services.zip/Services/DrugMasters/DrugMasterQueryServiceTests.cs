﻿using Aurora.AdministrationService.API.Models.Dto.DrugMasters;
using Aurora.AdministrationService.API.Services.Service.DrugMasters;
using Aurora.AdministrationService.Domain.V1.Entities.DrugMasters;
using Aurora.AdministrationService.Infrastructure;
using Aurora.AdministrationService.Tests.API.Controllers.DrugMasters;
using AutoMapper;
using FluentAssertions;
using Microsoft.EntityFrameworkCore;
using Moq;

namespace Aurora.AdministrationService.Tests.API.Services.DrugMasters
{
    public class DrugMasterQueryServiceTests
    {
        private readonly ReadOnlyDbContext _dbContext;
        private readonly Mock<IMapper> _mockMapper;
        private readonly DrugMasterQueryService _service;

        public DrugMasterQueryServiceTests()
        {
            var options = new DbContextOptionsBuilder<ReadOnlyDbContext>()
                .UseInMemoryDatabase(databaseName: Guid.NewGuid().ToString()) // Use a unique DB per test
                .Options;

            _dbContext = new ReadOnlyDbContext(options);
            _mockMapper = new Mock<IMapper>();
            _service = new DrugMasterQueryService(_dbContext, _mockMapper.Object);
        }

        [Fact]
        public async Task CheckExistingDrugMasterAsync_ReturnsDrugMaster_WhenItemCodeExists()
        {
            // Arrange
            var mockDrugMaster = CommonMockData.GetMockDrugMaster();
            _dbContext.DrugMasters.Add(mockDrugMaster);
            await _dbContext.SaveChangesAsync();

            // Act
            var result = await _service.CheckExistingDrugMasterAsync("Item001");

            // Assert
            result.Should().NotBeNull();
            result?.ItemCode.Should().Be("Item001");
        }

        [Fact]
        public async Task GetDrugMasterById_ReturnsDrugMasterDto_WhenIdExists()
        {
            // Arrange
            var mockDrugMaster = CommonMockData.GetMockDrugMaster();
            mockDrugMaster.ID = 1; // Explicitly set the ID

            _dbContext.DrugMasters.Add(mockDrugMaster);
            await _dbContext.SaveChangesAsync();

            var savedDrugMaster = await _dbContext.DrugMasters.FirstOrDefaultAsync(d => d.ID == 1);
            savedDrugMaster.Should().NotBeNull(); // Sanity check

            var mockDrugMasterDto = new GetDrugMasterDto { ResourceID = "R123", MasterType = "DrugMaster", ItemCode = "Item001", MedicationCode = "Medi001" };
            _mockMapper.Setup(m => m.Map<GetDrugMasterDto>(It.IsAny<DrugMaster>())).Returns(mockDrugMasterDto);

            // Act
            var result = await _service.GetDrugMasterById(1);

            // Assert
            result.Should().NotBeNull();
            result.ItemCode.Should().Be("Item001");
        }

        [Fact]
        public async Task GetDrugMasterList_ReturnsListOfDrugMasterDto()
        {
            var mockDrugMasters = new List<DrugMaster>
             {
                 CommonMockData.GetMockDrugMaster(),
                 CommonMockData.GetMockDrugMaster2()
            };

            await _dbContext.DrugMasters.AddRangeAsync(mockDrugMasters);
            await _dbContext.SaveChangesAsync();

            var count = await _dbContext.DrugMasters.CountAsync();
            count.Should().Be(2, "Database should contain exactly two DrugMaster records.");

            _mockMapper.Setup(m => m.Map<List<GetDrugMasterDto>>(It.IsAny<List<DrugMaster>>()))
                       .Returns((List<DrugMaster> dms) => dms.Select(dm => new GetDrugMasterDto
                       {
                           ResourceID = dm.ResourceID,
                           MasterType = dm.MasterType,
                           ItemCode = dm.ItemCode,
                           ItemDescription = dm.ItemDescription,
                           MedicationCode = dm.MedicationCode,
                           MedicationDescription = dm.MedicationDescription,
                           Strength = dm.Strength,
                           DrugForm = dm.DrugForm,
                           Caution = dm.Caution,
                           Instructions = dm.Instructions
                       }).ToList());

            // Act
            var result = await _service.GetDrugMasterList();

            // Assert
            result.Should().NotBeNull();
            result.Should().HaveCount(2, "The service should return exactly two DrugMasterDto records.");

            result[0].ItemCode.Should().Be(mockDrugMasters[0].ItemCode);
            result[1].ItemCode.Should().Be(mockDrugMasters[1].ItemCode);
        }
    }
}