﻿using Aurora.AdministrationService.API.Models.RequestModels.AdminUser;
using Aurora.AdministrationService.Domain.Old.Entities;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Aurora.AdministrationService.Tests.API.Services.User
{
    public static class MockData
    {
        public static UserToken GetUserToken()
        {
            return new UserToken
            {
                TokenId = 1,
                UserId = "user123",
                Token = "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9",
                IssuedAt = DateTime.UtcNow.AddMinutes(-10),
                ExpiresAt = DateTime.UtcNow.AddMinutes(50),
                IsRevoked = false,
                RevokedAt = null,
                CreatedAt = DateTime.UtcNow.AddMinutes(-10),
                ModifiedAt = DateTime.UtcNow
            };
        }

        public static AdminLoginRequest GetAdminLoginRequest()
        {
            return new AdminLoginRequest { Password = "Test@122#", Username = "jdoe" };
        }

        public static AdminUser GetAdminUser()
        {
            return new AdminUser { Password = "Test@122#", Username = "user123", AdminId = 1, Active = true };
        }

        public static Domain.Old.Entities.User GetRetryFaileduser()
        {
            return new Domain.Old.Entities.User
            {
                UserId = "user1234",
                RetryAttempt = 5,
                LastLoginFailedTime = DateTime.Now.AddDays(-1)

            };
        }

        public static Domain.Old.Entities.User GetUser()
        {
            return new Domain.Old.Entities.User
            {
                UserId = "user1234",
                RetryAttempt = 0,
                Password = "password"
            };
        }
    }
}