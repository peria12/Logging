﻿using Aurora.AdministrationService.API.Services.IService.Old.User;
using Aurora.AdministrationService.API.Services.IService.OTP.Token;
using Aurora.AdministrationService.API.Services.Service.Old.User;
using Aurora.AdministrationService.CrossCutting.CommonModels;
using Aurora.AdministrationService.Domain.Old.Entities;
using Aurora.AdministrationService.Infrastructure.IRepository;
using AutoMapper;
using FluentAssertions;
using Microsoft.Extensions.Configuration;

using Moq;

namespace Aurora.AdministrationService.Tests.API.Services.User
{
    public class UserServiceTests
    {
        private readonly Mock<IConfiguration> _configurationMock;
        private readonly Mock<IUserRepository> _userRepositoryMock;
        private readonly Mock<ITokenQueryService> _tokenServiceMock;
        private readonly UserService _userService;
        private readonly Mock<IMapper> _mapperMock;

        /// <summary>
        /// Initializing required services for ImageMaintenanceService
        /// </summary>
        public UserServiceTests()
        {
            _configurationMock = new Mock<IConfiguration>();
            _userRepositoryMock = new Mock<IUserRepository>();
            _mapperMock = new Mock<IMapper>();
            _tokenServiceMock = new Mock<ITokenQueryService>();
            _userService = new UserService(_configurationMock.Object, _mapperMock.Object, _userRepositoryMock.Object, _tokenServiceMock.Object);
        }

        #region Logout Service unit tests

        /// <summary>
        /// Logout method to verify that it returns a null response
        /// </summary>
        [Fact]
        public async Task Logout_ShouldReturnNull_WhenUserTokenGotNull()
        {
            // Arrange
            string token = "dummytoken";

            _userRepositoryMock.Setup(repo => repo.GetToken(token))
                .ReturnsAsync((UserToken)null);

            // Act
            var result = await _userService.Logout(token);

            // Assert
            result.Should().NotBeNull();
            result.IsSuccess.Should().BeFalse();
            result.HasError.Should().BeTrue();
            result.StatusCode.Should().Be(ResponseStatus.STATUS_NotFound);
        }

        /// <summary>
        /// Logout method to verify that it successfully revokes a valid token and returns a success response.
        /// </summary>
        [Fact]
        public async Task Logout_ShouldReturnToken_WhenUserTokenSucessfulLogOut()
        {
            // Arrange
            string token = "dummytoken";
            var response = MockData.GetUserToken();

            _userRepositoryMock.Setup(repo => repo.GetToken(token))
                .ReturnsAsync(response);
            _userRepositoryMock.Setup(repo => repo.RevokeToken(response));


            // Act
            var result = await _userService.Logout(token);

            // Assert
            result.Should().NotBeNull();
            result.IsSuccess.Should().BeFalse();
            result.HasError.Should().BeTrue();
            result.StatusCode.Should().Be(ResponseStatus.STATUS_SUCCESS);
        }

        /// <summary>
        /// Logout method to verify that it returns a 500 status code
        /// </summary>
        [Fact]
        public async Task Logout_ShouldReturn500_WhenExceptionOccurs()
        {
            // Arrange
            string token = "dummytoken";
            var response = MockData.GetUserToken();

            _userRepositoryMock.Setup(repo => repo.GetToken(token))
                .ThrowsAsync(new Exception("Database Exception"));

            // Act
            var result = await _userService.Logout(token);

            // Assert
            result.Should().NotBeNull();
            result.IsSuccess.Should().BeFalse();
            result.HasError.Should().BeTrue();
            result.StatusCode.Should().Be(ResponseStatus.STATUS_InternalServerError);
        }

        #endregion

        #region LoginWithCredentials service unit tests

        /// <summary>
        /// LoginWithCredentials method returns  BadRequest when invalid credentials are provided.
        /// </summary>
        [Fact]
        public async Task LoginWithCredentials_ShouldReturnBadRequest_Wheninvalidcredentialspassed()
        {
            // Arrange
            var request = MockData.GetAdminLoginRequest();
            var mappedresult = MockData.GetAdminUser();

            _mapperMock.Setup(m => m.Map<AdminUser>(request)).Returns(mappedresult);

            _userRepositoryMock.Setup(repo => repo.GetUser(mappedresult))
                .ReturnsAsync((AdminUser)null);

            // Act
            var result = await _userService.LoginWithCredentials(request);

            // Assert
            result.Should().NotBeNull();
            result.IsSuccess.Should().BeFalse();
            result.HasError.Should().BeTrue();
            result.StatusCode.Should().Be(ResponseStatus.STATUS_BadRequest);
        }

        /// <summary>
        /// LoginWithCredentials method returns BadRequest response when an invalid password is provided
        /// </summary>
        [Fact]
        public async Task LoginWithCredentials_ShouldReturnBadRequest_Wheninvalidpasswordpassed()
        {
            // Arrange
            var request = MockData.GetAdminLoginRequest();
            var mappedresult = MockData.GetAdminUser();
            mappedresult.Password = "Invalid";
            _mapperMock.Setup(m => m.Map<AdminUser>(request)).Returns(mappedresult);

            _userRepositoryMock.Setup(repo => repo.GetUser(mappedresult))
                .ReturnsAsync(mappedresult);

            // Act
            var result = await _userService.LoginWithCredentials(request);

            // Assert
            result.Should().NotBeNull();
            result.IsSuccess.Should().BeFalse();
            result.HasError.Should().BeTrue();
            result.StatusCode.Should().Be(ResponseStatus.STATUS_BadRequest);
        }

        /// <summary>
        /// LoginWithCredentials  returns StatusProblem when  users account is inactive.
        /// </summary>
        [Fact]
        public async Task LoginWithCredentials_ShouldReturnStatusProblem_WhenUserInActive()
        {
            // Arrange
            var request = MockData.GetAdminLoginRequest();
            var mappedresult = MockData.GetAdminUser();
            
            mappedresult.Active = false;
            _mapperMock.Setup(m => m.Map<AdminUser>(request)).Returns(mappedresult);

            _userRepositoryMock.Setup(repo => repo.GetUser(mappedresult))
                .ReturnsAsync(mappedresult);

            // Act
            var result = await _userService.LoginWithCredentials(request);

            // Assert
            result.Should().NotBeNull();
            result.IsSuccess.Should().BeFalse();
            result.HasError.Should().BeTrue();
            result.StatusCode.Should().Be(ResponseStatus.STATUS_Problem);
        }

        /// <summary>
        /// LoginWithCredentials returns 200 StatusCode when the user logs in successful
        /// </summary>
        [Fact]
        public async Task LoginWithCredentials_ShouldReturn200_WhenUserSucessfulLogin()
        {
            // Arrange
            var request = MockData.GetAdminLoginRequest();
            var mappedresult = MockData.GetAdminUser();
            _mapperMock.Setup(m => m.Map<AdminUser>(request)).Returns(mappedresult);

            _userRepositoryMock.Setup(repo => repo.GetUser(mappedresult))
                .ReturnsAsync(mappedresult);

            // Act
            var result = await _userService.LoginWithCredentials(request);

            // Assert
            result.Should().NotBeNull();
            result.IsSuccess.Should().BeTrue();
            result.HasError.Should().BeFalse();
            result.StatusCode.Should().Be(ResponseStatus.STATUS_SUCCESS);
        }

        /// <summary>
        /// LoginWithCredentials method 500 StatusCode when an exception occurs during the user login process
        /// </summary>
        [Fact]
        public async Task LoginWithCredentials_ShouldReturn500_WhenExcpetionOccurs()
        {
            // Arrange
            var request = MockData.GetAdminLoginRequest();
            var mappedresult = MockData.GetAdminUser();
            _mapperMock.Setup(m => m.Map<AdminUser>(request)).Returns(mappedresult);

            _userRepositoryMock.Setup(repo => repo.GetUser(mappedresult))
                .ThrowsAsync(new Exception("Database Error"));

            // Act
            var result = await _userService.LoginWithCredentials(request);

            // Assert
            result.Should().NotBeNull();
            result.IsSuccess.Should().BeFalse();
            result.HasError.Should().BeTrue();
            result.StatusCode.Should().Be(ResponseStatus.STATUS_InternalServerError);
        }

        #endregion

        #region Login Service unit tests

        /// <summary>
        /// Login method returns a 500 StatusCode when an exception occurs during the login process
        /// </summary>
        [Fact]
        public async Task Login_ShouldReturn500_WhenExcpetionOccurs()
        {
            // Arrange
            var request = MockData.GetAdminLoginRequest();

            // Act
            var result = await _userService.Login(request);

            // Assert
            result.Should().NotBeNull();
            result.IsSuccess.Should().BeFalse();
            result.HasError.Should().BeTrue();
            result.StatusCode.Should().Be(ResponseStatus.STATUS_InternalServerError);
        }
        #endregion

        #region SignInPassportAsync service unit tests

        /// <summary>
        /// when a user's account is locked due to multiple login attempts response returns a BadRequest status
        /// </summary>
        [Fact]
        public async Task SignInPassportAsync_ShouldReturnBadRequest_WhenAccountLockedCase()
        {
            // Arrange
            string identifier = "MY_KID_PR";
            string password = "213213";
            var response = MockData.GetRetryFaileduser();
            response.LastLoginFailedTime = DateTime.UtcNow.AddMinutes(-2);
            _userRepositoryMock.Setup(repo => repo.SignInUserByIdPassportAsync(identifier, password))
                          .ReturnsAsync(response);

            // Act
            var result = await _userService.SignInPassportAsync(identifier, password);

            // Assert
            result.Should().NotBeNull();
            result.IsSuccess.Should().BeFalse();
            result.HasError.Should().BeTrue();
            result.StatusCode.Should().Be(ResponseStatus.STATUS_BadRequest);
        }

        /// <summary>
        /// when invalid credentials are provided returns a BadRequest status due to incorrect credentials
        /// </summary>
        [Fact]
        public async Task SignInPassportAsync_ShouldReturnBadRequest_WhenInvalidCredentials()
        {
            // Arrange
            string identifier = "MY_KID_PR";
            string password = "213213";
            var response = MockData.GetRetryFaileduser();
            response.LastLoginFailedTime = DateTime.UtcNow.AddMinutes(-2);
            _userRepositoryMock.Setup(repo => repo.SignInUserByIdPassportAsync(identifier, password))
                          .ReturnsAsync((Domain.Old.Entities.User)null);

            // Act
            var result = await _userService.SignInPassportAsync(identifier, password);

            // Assert
            result.Should().NotBeNull();
            result.IsSuccess.Should().BeFalse();
            result.HasError.Should().BeTrue();
            result.StatusCode.Should().Be(ResponseStatus.STATUS_BadRequest);
        }

        /// <summary>
        /// when an invalid password is provided.It ensures that the response returns a BadRequest status due to incorrect password
        /// </summary>
        [Fact]
        public async Task SignInPassportAsync_ShouldReturnBadRequest_WhenInvalidPassword()
        {
            // Arrange
            string identifier = "MY_KID_PR";
            string password = "213213";
            var response = MockData.GetRetryFaileduser();
            var user = MockData.GetUser();

            _userRepositoryMock.Setup(repo => repo.SignInUserByIdPassportAsync(identifier, password))
                         .ReturnsAsync(user);

            // Act
            var result = await _userService.SignInPassportAsync(identifier, password);

            // Assert
            result.Should().NotBeNull();
            result.IsSuccess.Should().BeFalse();
            result.HasError.Should().BeTrue();
            result.StatusCode.Should().Be(ResponseStatus.STATUS_BadRequest);
        }

        /// <summary>
        /// returns a success status indicating the login attempt is successful
        /// </summary>
        [Fact]
        public async Task SignInPassportAsync_ShouldReturn200_WhenValidDataPassed()
        {
            // Arrange
            string identifier = "MY_KID_PR";
            var response = MockData.GetRetryFaileduser();
            var user = MockData.GetUser();

            _userRepositoryMock.Setup(repo => repo.SignInUserByIdPassportAsync(identifier, user.Password))
                         .ReturnsAsync(user);

            // Act
            var result = await _userService.SignInPassportAsync(identifier, user.Password);

            // Assert
            result.Should().NotBeNull();
            result.IsSuccess.Should().BeTrue();
            result.HasError.Should().BeFalse();
            result.StatusCode.Should().Be(ResponseStatus.STATUS_SUCCESS);
        }

        #endregion
    }
}
