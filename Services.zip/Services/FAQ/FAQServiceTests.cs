﻿using Aurora.AdministrationService.API.Enum;
using Aurora.AdministrationService.API.Helper;
using Aurora.AdministrationService.API.Models.RequestModels.FAQ;
using Aurora.AdministrationService.API.Models.RequestModels.NewFolder;
using Aurora.AdministrationService.API.Models.ResponseModels.FAQ;
using Aurora.AdministrationService.API.Services.Service.Old.FAQ;
using Aurora.AdministrationService.CrossCutting.CommonModels;
using Aurora.AdministrationService.CrossCutting.Extensions;
using Aurora.AdministrationService.Domain.Entities;
using Aurora.AdministrationService.Domain.Old.Entities;
using Aurora.AdministrationService.Infrastructure.IRepository;
using AutoMapper;
using FluentAssertions;
using Moq;

namespace Aurora.AdministrationService.Tests.API.Services.FAQ
{
    /// <summary>
    /// Unit tests for the Admin_adminFAQService class
    /// Verifies the behavior of the service using mocked dependencies 
    /// </summary>
    public class AdminFAQServiceTests
    {
        private readonly Mock<IAdmin_FAQRepository> _faqRepositoryMock;
        private readonly Mock<IMapper> _mapperMock;
        private readonly Mock<IResponseMessageHelper> _responseMessageHelperMock;
        private readonly Mock<IResponseMessageHelper<FAQDetailResponseDTO>> _listResponseMessageHelperMock;
        private readonly Admin_FAQService _adminFAQService;

        /// <summary>
        /// Initializes a new instance of the <see cref="AdminFAQServiceTests"/> class.
        /// Sets up mocked dependencies for testing the Admin_adminFAQService class.
        /// </summary>
        public AdminFAQServiceTests()
        {
            _faqRepositoryMock = new Mock<IAdmin_FAQRepository>();
            _mapperMock = new Mock<IMapper>();
            _responseMessageHelperMock = new Mock<IResponseMessageHelper>();
            _listResponseMessageHelperMock = new Mock<IResponseMessageHelper<FAQDetailResponseDTO>>();

            _adminFAQService = new Admin_FAQService(
                _faqRepositoryMock.Object,
                _mapperMock.Object,
                _responseMessageHelperMock.Object,
                _listResponseMessageHelperMock.Object);
        }

        /// <summary>
        /// Tests that GetAdmin_FAQByIdAsync returns FAQ details when the FAQ exists.
        /// </summary>
        [Fact]
        public async Task GetAdmin_FAQByIdAsync_ShouldReturnFAQDetails_WhenFAQExists()
        {
            // Arrange
            var faqId = 1;
            var existingFAQ = new AdminFaq
            {
                Id = faqId,
                Header = "Test Header",
                Description = "Test Description",
                IsActive = true,
                Platforms = "Web",
                Users = "Admin"
            };

            _faqRepositoryMock
                .Setup(repo => repo.GetAdmin_FAQByIdAsync(faqId))
                .ReturnsAsync(existingFAQ);

            _listResponseMessageHelperMock
                .Setup(helper => helper.GetRecordDetailSuccessResponseMessage(It.IsAny<FAQDetailResponseDTO>(), It.IsAny<string>()))
                .Returns(new GenericResponse<FAQDetailResponseDTO>
                {
                    HasError = false,
                    IsSuccess = true,
                    StatusCode = ResponseStatus.STATUS_SUCCESS
                });

            // Act
            var result = await _adminFAQService.GetAdmin_FAQByIdAsync(faqId);

            // Assert
            result.Should().NotBeNull();
            result.IsSuccess.Should().BeTrue();
            result.StatusCode.Should().Be(ResponseStatus.STATUS_SUCCESS);

            _faqRepositoryMock.Verify(repo => repo.GetAdmin_FAQByIdAsync(faqId), Times.Once);
            _listResponseMessageHelperMock.Verify(helper => helper.GetRecordDetailSuccessResponseMessage(It.IsAny<FAQDetailResponseDTO>(), It.IsAny<string>()), Times.Once);
        }

        /// <summary>
        /// Tests that GetAdmin_FAQByIdAsync returns a not-found response when the FAQ does not exist.
        /// </summary>
        [Fact]
        public async Task GetAdmin_FAQByIdAsync_ShouldReturnNotFound_WhenFAQDoesNotExist()
        {
            // Arrange
            var faqId = 1;

            _faqRepositoryMock
                .Setup(repo => repo.GetAdmin_FAQByIdAsync(faqId))
                .ReturnsAsync((AdminFaq)null!);

            _listResponseMessageHelperMock.Setup(helper => helper.GetRecordNotFoundResponseMessage(It.IsAny<string>()))
                .Returns(new GenericResponse<FAQDetailResponseDTO>()
                {
                    StatusCode = ResponceStatusCode.RecordNotFound.ToString(),
                    Message = ResponseMessage.STATUS_NODATA
                });

            // Act
            var result = await _adminFAQService.GetAdmin_FAQByIdAsync(faqId);

            // Assert
            result.Should().NotBeNull();
            result.IsSuccess.Should().BeFalse();
            result.StatusCode.Should().Be(ResponceStatusCode.RecordNotFound.ToString());

            _faqRepositoryMock.Verify(repo => repo.GetAdmin_FAQByIdAsync(faqId), Times.Once);
            _listResponseMessageHelperMock.Verify(helper => helper.GetRecordNotFoundResponseMessage(It.IsAny<string>()), Times.Once);
        }

        /// <summary>
        /// Tests that CreateAdmin_FAQAsync returns a success response when the FAQ is created successfully.
        /// </summary>
        [Fact]
        public async Task CreateAdmin_FAQAsync_ShouldReturnSuccessResponse_WhenFAQCreatedSuccessfully()
        {
            // Arrange
            var userId = "1";
            var createFAQRequest = new CreateAdmin_FAQRequestDTO
            {
                Header = "Test Header",
                Description = "Test Description",
                IsActive = true,
                Platforms = "Web",
                Users = "Admin"
            };

            _faqRepositoryMock
                .Setup(repo => repo.AddAdmin_FAQAsync(It.IsAny<AdminFaq>()))
                .ReturnsAsync(1);

            // Act
            var result = await _adminFAQService.CreateAdmin_FAQAsync(userId, createFAQRequest);

            // Assert
            result.Should().NotBeNull();
            result.IsSuccess.Should().BeTrue();
            result.StatusCode.Should().Be(ResponseStatus.STATUS_SUCCESS_Create);
            result.Result.Should().BeEquivalentTo(createFAQRequest);

            _faqRepositoryMock.Verify(repo => repo.AddAdmin_FAQAsync(It.IsAny<AdminFaq>()), Times.Once);
        }

        /// <summary>
        /// Tests that CreateAdmin_FAQAsync returns an error response when an exception occurs.
        /// </summary>
        [Fact]
        public async Task CreateAdmin_FAQAsync_ShouldReturnErrorResponse_WhenExceptionOccurs()
        {
            // Arrange
            var userId = "1";
            var createFAQRequest = new CreateAdmin_FAQRequestDTO
            {
                Header = "Test Header",
                Description = "Test Description",
                IsActive = true,
                Platforms = "Web",
                Users = "Admin"
            };

            _faqRepositoryMock
                .Setup(repo => repo.AddAdmin_FAQAsync(It.IsAny<AdminFaq>()))
                .ThrowsAsync(new Exception("Test Exception"));

            // Act
            var result = await _adminFAQService.CreateAdmin_FAQAsync(userId, createFAQRequest);

            // Assert
            result.Should().NotBeNull();
            result.IsSuccess.Should().BeFalse();
            result.StatusCode.Should().Be(ResponseStatus.STATUS_InternalServerError);
            result.Result.Should().BeNull();

            _faqRepositoryMock.Verify(repo => repo.AddAdmin_FAQAsync(It.IsAny<AdminFaq>()), Times.Once);
        }

        [Fact]
        public async Task UpdateFAQByIdAsync_ShouldReturnSuccess_WhenFAQExists()
        {
            // Arrange
            int faqId = 1;
            string userId = "123";
            var updateFAQRequest = new UpdateFAQRequest
            {
                Header = "Updated Header",
                Description = "Updated Description",
                IsActive = true,
                Platforms = "Web,Mobile",
                Users = "Admin"
            };

            var existingFAQ = new AdminFaq
            {
                Id = faqId,
                Header = "Old Header",
                Description = "Old Description",
                IsActive = false,
                Platforms = "Web",
                Users = "User",
                UpdatedBy = 0,
                CreatedByNavigation = new AdminUser { FirstName = "Test", LastName = "User" }
            };

            _faqRepositoryMock.Setup(repo => repo.GetAdmin_FAQByIdAsync(faqId)).ReturnsAsync(existingFAQ);
            _responseMessageHelperMock.Setup(helper => helper.GetSuccessUpdationResponseMessage(It.IsAny<string>())).Returns(new GenericResponse<string> { IsSuccess = true, Message = "Updated successfully" });

            // Act
            var result = await _adminFAQService.UpdateFAQByIdAsync(faqId, userId, updateFAQRequest);

            // Assert
            result.IsSuccess.Should().BeTrue();
            result.Message.Should().Be("Updated successfully");
            existingFAQ.Header.Should().Be(updateFAQRequest.Header);
            existingFAQ.Description.Should().Be(updateFAQRequest.Description);
            existingFAQ.Platforms.Should().Be(updateFAQRequest.Platforms);
            existingFAQ.Users.Should().Be(updateFAQRequest.Users);
            existingFAQ.UpdatedBy.Should().Be(123); // Parsed userId
        }

        [Fact]
        public async Task UpdateFAQByIdAsync_ShouldReturnRecordNotFound_WhenFAQDoesNotExist()
        {
            // Arrange
            int faqId = 1;
            string userId = "123";
            var updateFAQRequest = new UpdateFAQRequest
            {
                Header = "Updated Header",
                Description = "Updated Description",
                IsActive = true,
                Platforms = "Web,Mobile",
                Users = "Admin"
            };

            _faqRepositoryMock.Setup(repo => repo.GetAdmin_FAQByIdAsync(faqId)).ReturnsAsync((AdminFaq)null!);
            _responseMessageHelperMock.Setup(helper => helper.GetRecordNotFoundResponseMessage("")).Returns(new GenericResponse<string> { IsSuccess = false, Message = "FAQ not found" });

            // Act
            var result = await _adminFAQService.UpdateFAQByIdAsync(faqId, userId, updateFAQRequest);

            // Assert
            result.IsSuccess.Should().BeFalse();
            result.Message.Should().Be("FAQ not found");
        }
        [Fact]
        public async Task DeleteAdmin_FAQAsync_ShouldReturnSuccess_WhenFAQIsDeleted()
        {
            // Arrange
            int faqId = 1;
            _faqRepositoryMock.Setup(repo => repo.DeleteAdmin_FAQAsync(faqId)).ReturnsAsync(1);
            _responseMessageHelperMock.Setup(helper => helper.GetSuccessDeletionResponseMessage(It.IsAny<string>())).Returns(new GenericResponse<string> { IsSuccess = true, Message = "Deleted successfully" });

            // Act
            var result = await _adminFAQService.DeleteAdmin_FAQAsync(faqId);

            // Assert
            result.IsSuccess.Should().BeTrue();
            result.Message.Should().Be("Deleted successfully");
        }

        [Fact]
        public async Task DeleteAdmin_FAQAsync_ShouldReturnRecordDeletionFailed_WhenFAQNotDeleted()
        {
            // Arrange
            int faqId = 1;
            _faqRepositoryMock.Setup(repo => repo.DeleteAdmin_FAQAsync(faqId)).ReturnsAsync(0);
            _responseMessageHelperMock.Setup(helper => helper.GetRecordDeletionFailedResponseMessage(It.IsAny<string>())).Returns(new GenericResponse<string> { IsSuccess = false, Message = "Deletion failed" });

            // Act
            var result = await _adminFAQService.DeleteAdmin_FAQAsync(faqId);

            // Assert
            result.IsSuccess.Should().BeFalse();
            result.Message.Should().Be("Deletion failed");
        }

        [Fact]
        public async Task GetFAQsAsync_ShouldReturnFAQs_WhenFAQsExist()
        {
            // Arrange
            var paginationQuery = new PaginationQuery { PageNumber = 1, PageSize = 10 };
            var faqList = new List<AdminFaq>
    {
        new AdminFaq { Id = 1, Header = "Header1", Description = "Description1", IsActive = true, Platforms = "Web", Users = "User1", UpdatedAt = DateTime.UtcNow },
        new AdminFaq { Id = 2, Header = "Header2", Description = "Description2", IsActive = false, Platforms = "Mobile", Users = "User2", UpdatedAt = DateTime.UtcNow }
    };

            _faqRepositoryMock.Setup(repo => repo.GetFaqsAsync(paginationQuery)).ReturnsAsync(faqList);
            _responseMessageHelperMock.Setup(helper => helper.GetSuccessUpdationResponseMessage(It.IsAny<string>())).Returns(new GenericResponse<string> { IsSuccess = true, Message = "Fetched successfully" });

            // Act
            var result = await _adminFAQService.GetFAQsAsync(paginationQuery);

            // Assert
            result.IsSuccess.Should().BeTrue();
            result.Results.Should().HaveCount(2);
            result.Results?.First().Header.Should().Be("Header1");
        }

        [Fact]
        public async Task GetFAQsBySearchAsync_ShouldReturnValidResults_WhenSearchIsValid()
        {
            // Arrange
            var searchRequest = new FAQSearchRequest
            {
                SelectedPlatforms = new List<string> { "Patient App" },
                SelectedUsers = new List<string> { "User1" },
                HeaderText = "Header",
                SelectedStatus = true
            };

            var faqList = new List<AdminFaq>
    {
        new AdminFaq { Id = 1, Header = "Header1", Description = "Description1", IsActive = true, Platforms = "Web", Users = "User1", UpdatedAt = DateTime.UtcNow }
    };

            _faqRepositoryMock.Setup(repo => repo.GetFaqsBySearchAsync(searchRequest.SelectedPlatforms, searchRequest.SelectedUsers, searchRequest.HeaderText, searchRequest.SelectedStatus))
                              .ReturnsAsync(faqList);

            // Act
            var result = await _adminFAQService.GetFAQsBySearchAsync(searchRequest);

            // Assert
            result.IsSuccess.Should().BeTrue();
            result.Results.Should().HaveCount(1);
            result.Results?.First().Header.Should().Be("Header1");
        }

        [Fact]
        public async Task GetFAQsBySearchAsync_ShouldReturnBadRequest_WhenInvalidPlatformSelected()
        {
            // Arrange
            var searchRequest = new FAQSearchRequest
            {
                SelectedPlatforms = new List<string> { "InvalidPlatform" },
                SelectedUsers = new List<string> { "User1" },
                HeaderText = "Header",
                SelectedStatus = true
            };

            // Act
            var result = await _adminFAQService.GetFAQsBySearchAsync(searchRequest);

            // Assert
            result.IsSuccess.Should().BeFalse();
            result.Message.Should().Be(ValidationMessage.INVALID_SELECTED_PLATFORM);
        }
    }
}
