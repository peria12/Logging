﻿using Aurora.AdministrationService.API.Models.RequestModels.FAQ;
using Aurora.AdministrationService.API.Models.RequestModels.NewFolder;
using Aurora.AdministrationService.Domain.Old.Entities;

namespace Aurora.AdministrationService.Tests.API.Services.FAQ;


/// <summary>
/// Mock data for <see cref="Admin_FAQServiceTests"/> class.
/// </summary>
/// <remarks>
/// Mock data includes data for following classes AdminFaq, CreateAdmin_FAQRequestDTO, UpdateFAQRequest, FAQSearchRequest
/// </remarks>
public static class MockData
{
    public static AdminFaq GetAdminFaq()
    {
        return new AdminFaq
        {
            Id = 1,
            Header = "Test Header",
            Description = "Test Description",
            IsActive = true,
            Platforms = "Platform1",
            Users = "User1"
        };
    }

    public static CreateAdmin_FAQRequestDTO GetCreateAdmin_FAQRequestDTO()
    {
        return new CreateAdmin_FAQRequestDTO
        {
            Header = "Header",
            Description = "Description",
            IsActive = true,
            Platforms = "Platform1",
            Users = "User1"
        };
    }

    public static UpdateFAQRequest GetUpdateFAQRequest()
    {
        return new UpdateFAQRequest
        {
            Header = "Updated Header",
            Description = "Updated Description",
            IsActive = true,
            Platforms = "Platform1",
            Users = "User1"
        };
    }

    public static FAQSearchRequest GetFAQSearchRequest()
    {
        return new FAQSearchRequest
        {
            SelectedPlatforms = new List<string> { "Platform1" },
            HeaderText = "Header",
            SelectedUsers = new List<string>()
            {
                "user1"
            },
            SelectedStatus = true
        };
    }
}
