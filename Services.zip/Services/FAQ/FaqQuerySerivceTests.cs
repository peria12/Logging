﻿using Aurora.AdministrationService.API.Models.ResponseModels.V1.Faq;
using Aurora.AdministrationService.API.Services.Service.Faq;
using Aurora.AdministrationService.Infrastructure;
using FluentAssertions;
using Microsoft.EntityFrameworkCore;

namespace Aurora.AdministrationService.Tests.API.Services.FAQ
{
    public class FaqQueryServiceTests
    {
        private readonly ReadOnlyDbContext _dbContext;
        private readonly FaqQuerySerivce _faqQueryService;

        public FaqQueryServiceTests()
        {
            var options = new DbContextOptionsBuilder<ReadOnlyDbContext>()
                .UseInMemoryDatabase(databaseName: "FaqDatabase") 
                .Options;

            _dbContext = new ReadOnlyDbContext(options);

            SeedDatabase();

            _faqQueryService = new FaqQuerySerivce(_dbContext);
        }

        private void SeedDatabase()
        {
            _dbContext.FAQNew.RemoveRange(_dbContext.FAQNew);
            _dbContext.FAQLanguages.RemoveRange(_dbContext.FAQLanguages);
            _dbContext.FAQUserTypes.RemoveRange(_dbContext.FAQUserTypes);
            _dbContext.SaveChanges();

            _dbContext.FAQNew.AddRange(new List<Domain.V1.Entities.FAQ>
            {
                new() { ID = 1, Platforms = "Web", IsDeleted = false, Status = true, CreatedDate = DateTime.UtcNow },
                new() { ID = 2, Platforms = "Mobile", IsDeleted = false, Status = false, CreatedDate = DateTime.UtcNow },
                new() { ID = 3, Platforms = "Patient App", IsDeleted = true, Status = true, CreatedDate = DateTime.UtcNow }, // Deleted
                new() { ID = 4, Platforms = "Patient App", IsDeleted = false, Status = true, CreatedDate = DateTime.UtcNow } // Inactive
            });

            _dbContext.FAQLanguages.AddRange(new List<Domain.V1.Entities.FAQLanguage>
            {
                new() { Id =1, CreatedDate = DateTime.UtcNow, Status =true, IsDeleted =false, LanguageID = 1, FAQID = 1, Header = "FAQ 1 Header", Description = "FAQ 1 Description" },
                new() { Id = 3, FAQID = 3, Header = "Deleted FAQ", Description = "Should not appear", Status = true, IsDeleted = true, CreatedDate = DateTime.UtcNow },
                new() { Id = 4, FAQID = 4, Header = "Inactive FAQ", Description = "Should not appear", Status = true, IsDeleted = false, CreatedDate     = DateTime.UtcNow }
            });

            _dbContext.FAQUserTypes.AddRange(new List<Domain.V1.Entities.FAQUserTypes>
            {
                new() { Id =1, CreatedDate = DateTime.UtcNow, IsDeleted =false, FAQID = 1, UserType = "Admin" }
            });

            _dbContext.SaveChanges();
        }

        [Fact]
        public async Task GetFaqs_Should_Return_FilteredList()
        {
            var result = await _faqQueryService.GetFaqs(1, 10, "Web", null, null, null);

            result.Should().NotBeNull();
            result.Results.Should().HaveCount(1);
            result.Results?.First().Platforms.Should().Be("Web");
        }

        [Fact]
        public async Task GetFaqByIdAsync_Should_Return_Faq_WhenExists()
        {
            var result = await _faqQueryService.GetFaqByIdAsync(1);

            result.Should().NotBeNull();
            result?.ID.Should().Be(1);
        }

        [Fact]
        public async Task GetFaqByIdAsync_Should_Return_Null_When_NotExists()
        {
            var result = await _faqQueryService.GetFaqByIdAsync(99);

            result.Should().BeNull();
        }

        [Fact]
        public async Task GetFaqLanguageAsync_Should_Return_Language_WhenExists()
        {
            var result = await _faqQueryService.GetFaqLanguageAsync(1);

            result.Should().NotBeNull();
            result?.Header.Should().Be("FAQ 1 Header");
        }

        [Fact]
        public async Task GetFaqLanguageAsync_Should_Return_Null_When_NotExists()
        {
            var result = await _faqQueryService.GetFaqLanguageAsync(99);

            result.Should().BeNull();
        }

        [Fact]
        public async Task GetFaqUserTypesAsync_Should_Return_UserType_WhenExists()
        {
            var result = await _faqQueryService.GetFaqUserTypesAsync(1);

            result.Should().NotBeNull();
            result?.UserType.Should().Be("Admin");
        }

        [Fact]
        public async Task GetFaqUserTypesAsync_Should_Return_Null_When_NotExists()
        {
            var result = await _faqQueryService.GetFaqUserTypesAsync(99);

            result.Should().BeNull();
        }

        [Fact]
        public async Task GetFaqLanguageByIdAsync_Should_Return_Language_WhenExists()
        {
            var result = await _faqQueryService.GetFaqLanguageByIdAsync(1);

            result.Should().NotBeNull();
            result?.LanguageID.Should().Be(1);
        }

        [Fact]
        public async Task GetFaqLanguageByIdAsync_Should_Return_Null_When_NotExists()
        {
            var result = await _faqQueryService.GetFaqLanguageByIdAsync(99);

            result.Should().BeNull();
        }

        [Fact]
        public async Task GetFaqDetailById_Should_Return_FaqDetail_WhenExists()
        {
            var result = await _faqQueryService.GetFaqDetailById(1);

            result.Should().NotBeNull();
            result.IsSuccess.Should().BeTrue();
            result.Result.Should().NotBeNull();
            result.Result?.Header.Should().Be("FAQ 1 Header");
        }

        [Fact]
        public async Task GetFaqDetailById_Should_Return_Null_When_NotExists()
        {
            var result = await _faqQueryService.GetFaqDetailById(99);

            result.Should().NotBeNull();
            result.IsSuccess.Should().BeFalse();
            result.Result.Should().BeNull();
        }

        [Fact]
        public async Task GetFaqs_Should_Return_Empty_When_No_Match()
        {
            var result = await _faqQueryService.GetFaqs(1, 10, "UnknownPlatform", null, null, null);

            result.Results ??= new List<GetFaqResponse>(); // Ensure not null
            result.Results.Should().BeEmpty();
            result.IsSuccess.Should().BeFalse();
        }

        [Fact]
        public async Task GetFaqs_Should_Return_PagedResults()
        {
            var result = await _faqQueryService.GetFaqs(1, 1, null, null, null, null);

            result.Should().NotBeNull();
            result.Results.Should().HaveCount(1);
            result.CurrentPage.Should().Be(1);
            result.PageSize.Should().Be(1);
        }

        [Fact]
        public async Task GetFaqs_Should_Filter_By_Active_Status()
        {
            var result = await _faqQueryService.GetFaqs(1, 10, null, null, null, "Active");

            result.Should().NotBeNull();
            result.Results.Should().HaveCount(2);
            result.Results?.First().Status.Should().BeTrue();
        }

        [Fact]
        public async Task GetFaqs_Should_Filter_By_Inactive_Status()
        {
            var result = await _faqQueryService.GetFaqs(1, 10, null, null, null, "Inactive");

            result.Should().NotBeNull();
            result.Results.Should().HaveCount(1);
            result.Results?.First().Status.Should().BeFalse();
        }
 
        [Theory]
        [InlineData(null, null, null, null)]
        [InlineData("Web", null, null, null)]
        [InlineData(null, "Admin", null, null)]
        [InlineData(null, null, "FAQ", null)]
        [InlineData(null, null, null, "Active")]
        public async Task GetFaqs_Should_Handle_Null_Or_Single_Filter_Values(string platforms, string users, string header, string status)
        {
            var result = await _faqQueryService.GetFaqs(1, 10, platforms, users, header, status);
            result.Should().NotBeNull();
        }

        [Fact]
        public async Task GetFaqs_Should_Be_Case_Insensitive_For_Status()
        {
            var resultActive = await _faqQueryService.GetFaqs(1, 10, null, null, null, "ACTIVE");
            var resultInactive = await _faqQueryService.GetFaqs(1, 10, null, null, null, "inactive");

            resultActive.Should().NotBeNull();
            resultActive.Results.Should().NotBeNull();

            resultInactive.Should().NotBeNull();
            resultInactive.Results.Should().NotBeNull();
        }

        #region Dashboard FAQ test cases

        [Fact]
        public async Task GetDashboardpreLoginFAQs_ShouldReturnOnlyPatientAppActiveNonDeletedFaqs()
        {
            // Act
            var result = await _faqQueryService.GetDashboardpreLoginFAQs();

            // Assert
            result.Should().NotBeNull();
            result.Should().HaveCount(1);
        }

        [Fact]
        public async Task GetDashboardpreLoginFAQs_ShouldReturnEmptyList_WhenNoFaqsExist()
        {
            // Arrange
            // Clear all existing data
            _dbContext.FAQNew.RemoveRange(_dbContext.FAQNew);
            _dbContext.FAQLanguages.RemoveRange(_dbContext.FAQLanguages);
            await _dbContext.SaveChangesAsync();

            // Act
            var result = await _faqQueryService.GetDashboardpreLoginFAQs();

            // Assert
            result.Should().NotBeNull();
            result.Should().BeEmpty();
        }

        [Fact]
        public async Task GetDashboardpreLoginFAQs_ShouldReturnFaqsSortedAccordingToKeywordPriority()
        {
            // Arrange
            _dbContext.FAQNew.AddRange(new List<Domain.V1.Entities.FAQ>
            {
                new() { ID = 5, Platforms = "Patient App", IsDeleted = false, Status = true, CreatedDate = DateTime.UtcNow },
                new() { ID = 6, Platforms = "Patient App", IsDeleted = false, Status = true, CreatedDate = DateTime.UtcNow }
            });

            _dbContext.FAQLanguages.AddRange(new List<Domain.V1.Entities.FAQLanguage>
            {
                new() { Id = 5, FAQID = 5, Header = "Signing In to App", Description = "How to sign in?", Status = true, IsDeleted = false,     CreatedDate = DateTime.UtcNow },
                new() { Id = 6, FAQID = 6, Header = "Logging Out", Description = "How to logout?", Status = true, IsDeleted = false, CreatedDate =  DateTime.UtcNow }
            });

            await _dbContext.SaveChangesAsync();

            // Act
            var result = await _faqQueryService.GetDashboardpreLoginFAQs();

            // Assert
            result.Should().NotBeNull();
            result.Should().HaveCount(3);

            result[0].Title.Should().StartWith("Signing");   // Signing In to App
            result[1].Title.Should().StartWith("Logging");    // Logging Out
        }

        #endregion
    }
}
