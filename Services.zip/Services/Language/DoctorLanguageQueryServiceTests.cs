﻿using Aurora.AdministrationService.API.Services.IService.DoctorLanguage;
using Aurora.AdministrationService.API.Services.Service.DoctorLanguage;
using Aurora.AdministrationService.API.Services.Service.InsurancePanels;
using Aurora.AdministrationService.CrossCutting.CommonModels;
using Aurora.AdministrationService.CrossCutting.Constants;
using Aurora.AdministrationService.Infrastructure;
using Microsoft.EntityFrameworkCore;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Aurora.AdministrationService.API.Enum;
using Aurora.AdministrationService.Domain.V1.Entities.Languade;
using Aurora.AdministrationService.Domain.V1.Entities.Practitioners;
using Moq;
using Aurora.AdministrationService.API.Resources;
using Azure;
using Microsoft.Extensions.Options;

namespace Aurora.AdministrationService.Tests.API.Services.Language
{
    public class DoctorLanguageQueryServiceTests
    {
        private readonly ReadOnlyDbContext _dbContext;
        private readonly DoctorLanguageQueryService _service;
        private readonly DbContextOptions<ReadOnlyDbContext> options;
        public DoctorLanguageQueryServiceTests()
        {
            options = new DbContextOptionsBuilder<ReadOnlyDbContext>()
                .UseInMemoryDatabase(databaseName: Guid.NewGuid().ToString()) // In-memory DB for testing
                .Options;

            _dbContext = new ReadOnlyDbContext(options);
            _service = new DoctorLanguageQueryService(_dbContext);
        }
        [Fact]
        public async Task GetDoctorLanguageList_ReturnsSuccessWithLanguages()
        {
            // Act 
            using(var context = new ReadOnlyDbContext(options))
            {
                context.PractitionerCommunications.AddRange(
                   new Domain.V1.Entities.Practitioners.PractitionerCommunication {
                       Id = 1,
                       Status = true,
                       IsDeleted = false,
                       CreatedDate = DateTime.UtcNow,
                       CreatedBy = "Seeder",
                       PractitionerID = 14,
                       Language = "English"},                   
                   new Domain.V1.Entities.Practitioners.PractitionerCommunication {
                       Id = 2,
                       Status = true,
                       IsDeleted = false,
                       CreatedDate = DateTime.UtcNow,
                       CreatedBy = "Seeder",
                       PractitionerID = 15,
                       Language = "Hindi"
                   }

                );
                await context.SaveChangesAsync();
            }
            var result = await _service.GetDoctorLanguageList();

            // Assert
            Assert.False(result.HasError);
            Assert.True(result.IsSuccess);
            Assert.Equal(((int)ResponceStatusCode.Success).ToString(), result.StatusCode);
            Assert.Equal(ResponseMessage.STATUS_SUCCESS, result.Message);
            Assert.NotNull(result.Results);

        }
        [Fact]
        public async Task GetDoctorLanguageList_ReturnsNullWithNoLanguages()
        {
            // Act
            var result = await _service.GetDoctorLanguageList();

            // Assert
            Assert.False(result.HasError);
            Assert.True(result.IsSuccess);
            Assert.Equal(ResponseStatusCode.STATUS_NOTFOUND, result.StatusCode);
            Assert.Equal(Resource.RecordNotFound, result.Message);
            Assert.Null(result.Results);
        }
    }
}
