﻿using Aurora.AdministrationService.API.Enum;
using Aurora.AdministrationService.API.Helper;
using Aurora.AdministrationService.API.Models.RequestModels.Agreement;
using Aurora.AdministrationService.API.Models.ResponseModels.Agreement;
using Aurora.AdministrationService.API.Services.Service.Old.Agreement;
using Aurora.AdministrationService.CrossCutting.CommonModels;
using Aurora.AdministrationService.Infrastructure.IRepository;
using AutoMapper;
using FluentAssertions;
using Moq;

namespace Aurora.AdministrationService.Tests.API.Services.Agreement
{
    public class AgreementServiceTests
    {
        private readonly Mock<IAgreementRepository> _mockAgreementRepository;
        private readonly Mock<IMapper> _mockMapper;
        private readonly Mock<IResponseMessageHelper> _mockResponseMessageHelper;
        private readonly AgreementService _agreementService;
        private readonly Mock<IResponseMessageHelper<AgreementDTO>> _mocklistResponseMessageHelper;
        public AgreementServiceTests()
        {
            _mockAgreementRepository = new Mock<IAgreementRepository>();
            _mockMapper = new Mock<IMapper>();
            _mockResponseMessageHelper = new Mock<IResponseMessageHelper>();
            _mocklistResponseMessageHelper = new Mock<IResponseMessageHelper<AgreementDTO>>();
            _agreementService = new AgreementService(
                _mockAgreementRepository.Object,
                _mockMapper.Object,
                _mockResponseMessageHelper.Object,
                _mocklistResponseMessageHelper.Object
            );
        }

        [Fact]
        public async Task AddAgreementAsync_ShouldReturnSuccess_WhenAgreementIsAdded()
        {
            // Arrange
            var newAgreement = new CreateAgreementRequest
            {
                AgreementUniqueId = "123",
                Language = "EN"
            };

            _mockAgreementRepository.Setup(repo => repo.GetAgreementByLanguageAsync(newAgreement.AgreementUniqueId, newAgreement.Language))
                                     .ReturnsAsync((Domain.Old.Entities.Agreement)null!);

            _mockAgreementRepository.Setup(repo => repo.AddAgreementAsync(It.IsAny<Domain.Old.Entities.Agreement>()))
                                     .ReturnsAsync((int)AddNewRecordStatus.Added);

            _mockResponseMessageHelper.Setup(helper => helper.GetSuccessCreateResponseMessage(""))
                                      .Returns(new GenericResponse<string> { IsSuccess = true, Message = ResponseMessage.STATUS_DATA_ADDED });

            // Act
            var result = await _agreementService.AddAgreementAsync("1", newAgreement);

            // Assert
            result.Should().NotBeNull();
            result.IsSuccess.Should().BeTrue();
            result.Message.Should().Be(ResponseMessage.STATUS_DATA_ADDED);
        }

        [Fact]
        public async Task AddAgreementAsync_ShouldReturnRecordExistResponse_WhenAgreementAlreadyExists()
        {
            // Arrange
            var newAgreement = new CreateAgreementRequest
            {
                AgreementUniqueId = "123",
                Language = "EN"
            };

            var existingAgreement = new Domain.Old.Entities.Agreement();
            _mockAgreementRepository.Setup(repo => repo.GetAgreementByLanguageAsync(newAgreement.AgreementUniqueId, newAgreement.Language))
                                     .ReturnsAsync(existingAgreement);

            _mockResponseMessageHelper.Setup(helper => helper.GetRecordAlreadyExistResponseMessage(""))
                                      .Returns(new GenericResponse<string> { IsSuccess = false, Message = ResponseMessage.ALREADY_EXISTS });

            // Act
            var result = await _agreementService.AddAgreementAsync("1", newAgreement);

            // Assert
            result.Should().NotBeNull();
            result.IsSuccess.Should().BeFalse();
            result.Message.Should().Be(ResponseMessage.ALREADY_EXISTS);
        }

        [Fact]
        public async Task DeleteAgreementAsync_ShouldReturnSuccess_WhenAgreementIsDeleted()
        {
            // Arrange
            int agreementId = 1;
            _mockAgreementRepository.Setup(repo => repo.DeleteAgreementAsync(agreementId))
                                     .ReturnsAsync((int)DeleteRecordStatus.Deleted);

            _mockResponseMessageHelper.Setup(helper => helper.GetSuccessDeletionResponseMessage(""))
                                      .Returns(new GenericResponse<string> { IsSuccess = true, Message = ResponseMessage.STATUS_DATA_DELETED });

            // Act
            var result = await _agreementService.DeleteAgreementAsync(agreementId);

            // Assert
            result.Should().NotBeNull();
            result.IsSuccess.Should().BeTrue();
            result.Message.Should().Be(ResponseMessage.STATUS_DATA_DELETED);
        }

        [Fact]
        public async Task DeleteAgreementAsync_ShouldReturnFailedMessage_WhenDeletionFails()
        {
            // Arrange
            int agreementId = 1;
            _mockAgreementRepository.Setup(repo => repo.DeleteAgreementAsync(agreementId))
                                     .ReturnsAsync((int)DeleteRecordStatus.NotDeleted);

            _mockResponseMessageHelper.Setup(helper => helper.GetRecordDeletionFailedResponseMessage(""))
                                      .Returns(new GenericResponse<string> { IsSuccess = false, Message = ResponseMessage.STATUS_DATA_DELETE_FAIL });

            // Act
            var result = await _agreementService.DeleteAgreementAsync(agreementId);

            // Assert
            result.Should().NotBeNull();
            result.IsSuccess.Should().BeFalse();
            result.Message.Should().Be(ResponseMessage.STATUS_DATA_DELETE_FAIL);
        }

        [Fact]
        public async Task GetAgreementById_ShouldReturnAgreement_WhenExists()
        {
            // Arrange
            int agreementId = 1;
            var agreement = new Domain.Old.Entities.Agreement { AgreementUniqueId = "123", Language = "EN" };
            _mockAgreementRepository.Setup(repo => repo.GetAgreementByIdAsync(agreementId))
                                     .ReturnsAsync(agreement);

            var agreementDTO = new AgreementDTO { AgreementUniqueId = "123", Language = "EN" };
            _mockMapper.Setup(mapper => mapper.Map<AgreementDTO>(agreement))
                       .Returns(agreementDTO);

            _mocklistResponseMessageHelper.Setup(helper => helper.GetRecordDetailSuccessResponseMessage(agreementDTO,""))
                                      .Returns(new GenericResponse<AgreementDTO> { IsSuccess = true, Result = agreementDTO  });

            // Act
            var result = await _agreementService.GetAgreementById(agreementId);

            // Assert
            result.Should().NotBeNull();
            result.IsSuccess.Should().BeTrue();
            result.Result.Should().NotBeNull();
        }

        [Fact]
        public async Task GetAgreementById_ShouldReturnNotFound_WhenAgreementDoesNotExist()
        {
            // Arrange
            int agreementId = 1;
            _mockAgreementRepository.Setup(repo => repo.GetAgreementByIdAsync(agreementId))
                                     .ReturnsAsync((Domain.Old.Entities.Agreement)null!);

            _mockResponseMessageHelper.Setup(helper => helper.GetRecordNotFoundResponseMessage(""))
                                      .Returns(new GenericResponse<string> { IsSuccess = false});

            // Act
            var result = await _agreementService.GetAgreementById(agreementId);

            // Assert
            result.Should().BeNull();
        }

        [Fact]
        public async Task UpdateAgreementByLanguageAsync_ShouldReturnSuccess_WhenAgreementUpdated()
        {
            // Arrange
            var updateRequest = new UpdateAgreementRequest
            {
                AgreementUniqueId = "123",
                Language = "EN"
            };

            var existingAgreement = new Domain.Old.Entities.Agreement();
            _mockAgreementRepository.Setup(repo => repo.GetAgreementByLanguageAsync(updateRequest.AgreementUniqueId, updateRequest.Language))
                                     .ReturnsAsync(existingAgreement);

            _mockAgreementRepository.Setup(repo => repo.UpdateAgreementAsync(existingAgreement))
                                     .ReturnsAsync((int)UpdateRecordStatus.Updated);

            _mockResponseMessageHelper.Setup(helper => helper.GetSuccessUpdationResponseMessage(""))
                                      .Returns(new GenericResponse<string> { IsSuccess = true, Message = ResponseMessage.STATUS_DATA_UPDATED });

            // Act
            var result = await _agreementService.UpdateAgreementByLanguageAsync("1", updateRequest);

            // Assert
            result.Should().NotBeNull();
            result.IsSuccess.Should().BeTrue();
            result.Message.Should().Be(ResponseMessage.STATUS_DATA_UPDATED);
        }
    }

}
