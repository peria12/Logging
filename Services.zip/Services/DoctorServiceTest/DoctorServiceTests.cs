﻿using Aurora.AdministrationService.API.Helper;
using Aurora.AdministrationService.API.Models.RequestModels.Doctors;
using Aurora.AdministrationService.API.Models.ResponseModels.Doctors;
using Aurora.AdministrationService.API.Models.ResponseModels.Location;
using Aurora.AdministrationService.API.Services.Service.Old.Doctor;
using Aurora.AdministrationService.CrossCutting.Constants;
using Aurora.AdministrationService.CrossCutting.Extensions;
using Aurora.AdministrationService.Domain.Entities;
using Aurora.AdministrationService.Domain.Old.Entities;
using Aurora.AdministrationService.Infrastructure.IRepository;
using AutoMapper;
using FluentAssertions;
using Moq;

namespace Aurora.AdministrationService.Tests.API.Services.DoctorServiceTest
{
    /// <summary>
    /// Unit tests for the DoctorService class.
    /// Validates the behavior and logic of methods interacting with the doctor repository.
    /// </summary>
    public class DoctorServiceTests
    {
        // Mock objects for dependencies of the DoctorService.
        private readonly Mock<IDoctorRepository> _doctorRepositoryMock;
        private readonly Mock<IMapper> _mapperMock;

        // Instance of the service being tested.
        private readonly DoctorService _doctorService;

        private readonly Mock<IResponseMessageHelper> _responseMessageHelper;
        /// <summary>
        /// Initializes a new instance of the DoctorServiceTests class.
        /// Sets up mocks and the service instance.
        /// </summary>
        public DoctorServiceTests()
        {
            _doctorRepositoryMock = new Mock<IDoctorRepository>();
            _responseMessageHelper = new Mock<IResponseMessageHelper>();
            _mapperMock = new Mock<IMapper>();
            _doctorService = new DoctorService(_doctorRepositoryMock.Object, _mapperMock.Object, _responseMessageHelper.Object);
        }

        /// <summary>
        /// Verifies that the GetDoctors method returns mapped doctor data when repository returns valid data.
        /// </summary>
        [Fact]
        public async Task GetDoctors_ShouldReturnMappedDoctors_WhenRepositoryReturnsData()
        {
            // Arrange
            var paginationQuery = new PaginationQuery();
            var doctorEntities = new List<AdminDoctorProfile>();
            var mappedDoctors = new List<AdminDoctorProfileDTO> { new AdminDoctorProfileDTO() };

            _doctorRepositoryMock
                .Setup(repo => repo.GetDoctors(paginationQuery))
                .ReturnsAsync(doctorEntities);

            _mapperMock
                .Setup(mapper => mapper.Map<List<AdminDoctorProfileDTO>>(doctorEntities))
                .Returns(mappedDoctors);

            // Act
            var result = await _doctorService.GetDoctors(paginationQuery);

            // Assert
            result.IsSuccess.Should().BeTrue();
            result.Results.Should().BeEquivalentTo(mappedDoctors);
            _doctorRepositoryMock.Verify(repo => repo.GetDoctors(paginationQuery), Times.Once);
        }

        [Fact]
        public async Task GetLocations_ShouldReturnMappedLocations_WhenRepositoryReturnsData()
        {
            // Arrange
            var locationEntities = new List<AdminLocation>();
            var mappedLocations = new List<AdminLocationsDTO> 
            { 
                new AdminLocationsDTO

                {
                    ResourceId = "KLAN"
                }
                
                };
            
            _doctorRepositoryMock
                .Setup(repo => repo.GetLocations())
                .ReturnsAsync(locationEntities);

            _mapperMock
                .Setup(mapper => mapper.Map<List<AdminLocationsDTO>>(locationEntities))
                .Returns(mappedLocations);

            // Act
            var result = await _doctorService.GetLocations();

            // Assert
            result.IsSuccess.Should().BeTrue();
            result.Results.Should().BeEquivalentTo(mappedLocations);
            _doctorRepositoryMock.Verify(repo => repo.GetLocations(), Times.Once);
        }

        /// <summary>
        /// Validates that UpdateDoctorProfileAsync returns a "Not Found" response when no doctor profile is found.
        /// </summary>
        [Fact]
        public async Task UpdateDoctorProfileAsync_ShouldReturnNotFound_WhenDoctorProfileIsNull()
        {
            // Arrange
            var doctorRequest = new AdminDoctorProfileRequest { DoctorProfileId = 1 };

            _doctorRepositoryMock
                .Setup(repo => repo.GetDoctorProfileByIdAsync(doctorRequest.DoctorProfileId)).ReturnsAsync(default(AdminDoctorProfile));

            // Act
            var result = await _doctorService.UpdateDoctorProfileAsync(doctorRequest);

            // Assert
            result.IsSuccess.Should().BeFalse();
            result.StatusCode.Should().Be("404");
            result.Message.Should().Be("Profile Not Found");
        }

        [Fact]
        public async Task SearchDoctors_ShouldReturnMappedDoctors_WhenRepositoryReturnsData()
        {
            // Arrange
            var paginationQuery = new PaginationQuery();
            var doctorEntities = new List<AdminDoctorProfile>();
            var mappedDoctors = new List<AdminDoctorProfileDTO> { new AdminDoctorProfileDTO() };

            _doctorRepositoryMock
                .Setup(repo => repo.SearchDoctor(paginationQuery))
                .ReturnsAsync(doctorEntities);

            _mapperMock
                .Setup(mapper => mapper.Map<IEnumerable<AdminDoctorProfileDTO>>(doctorEntities))
                .Returns(mappedDoctors);

            // Act
            var result = await _doctorService.SearchDoctors(paginationQuery);

            // Assert
            result.IsSuccess.Should().BeTrue();
            result.Results.Should().BeEquivalentTo(mappedDoctors);
            _doctorRepositoryMock.Verify(repo => repo.SearchDoctor(paginationQuery), Times.Once);
        }

        [Fact]
        public async Task GetDoctorSearchByPagination_ShouldReturnDoctorList_WhenDoctorsExist()
        {
            // Arrange
            var paginationQuery = new PaginationQuery { PageNumber = 1, PageSize = 10 };
            var doctorList = new List<AdminDoctorProfile>
        {
            new AdminDoctorProfile
            {
                DoctorProfileId = 1,
                FirstName = "John",
                LastName = "Doe",
                ImageUrl = "imageurl.com/avatar.jpg",
                Gender = "Male",
                Organization = new AdminOrganization { Name = "Hospital", City = "CityName" },
                AdminDoctorSpecialities = new List<AdminDoctorSpeciality> { new AdminDoctorSpeciality { Speciality = "Cardiology" } }
            }
        };

            _doctorRepositoryMock.Setup(repo => repo.GetDoctorSearchByPagination(paginationQuery))
                                 .ReturnsAsync(doctorList);

            // Act
            var result = await _doctorService.GetDoctorSearchByPagination(paginationQuery);

            // Assert
            result.Should().NotBeNull();
            result.IsSuccess.Should().BeTrue();
            result.Results.Should().HaveCount(1);
        }

        // Test for GetDoctors method
        [Fact]
        public async Task GetDoctors_ShouldReturnDoctorList_WhenDoctorsExist()
        {
            // Arrange
            var doctorList = new List<AdminDoctorProfile>
        {
            new AdminDoctorProfile
            {
                DoctorProfileId = 1,
                FirstName = "Jane",
                LastName = "Smith",
                ImageUrl = "imageurl.com/avatar2.jpg",
                Gender = "Female",
                Organization = new AdminOrganization { Name = "Clinic", City = "CityName" },
                AdminDoctorSpecialities = new List<AdminDoctorSpeciality> { new AdminDoctorSpeciality { Speciality = "Dermatology" } }
            }
        };

            _doctorRepositoryMock.Setup(repo => repo.GetAllDoctors())
                                 .ReturnsAsync(doctorList);

            // Act
            var result = await _doctorService.GetDoctors();

            // Assert
            result.Should().NotBeNull();
            result.IsSuccess.Should().BeTrue();
            result.Results.Should().HaveCount(1);
        }

        // Test for GetDoctorSearchByPagination with no doctors
        [Fact]
        public async Task GetDoctorSearchByPagination_ShouldReturnEmptyList_WhenNoDoctorsExist()
        {
            // Arrange
            var paginationQuery = new PaginationQuery { PageNumber = 1, PageSize = 10 };
            _doctorRepositoryMock.Setup(repo => repo.GetDoctorSearchByPagination(paginationQuery))
                                 .ReturnsAsync(new List<AdminDoctorProfile>());

            // Act
            var result = await _doctorService.GetDoctorSearchByPagination(paginationQuery);

            // Assert
            result.Should().NotBeNull();
            result.IsSuccess.Should().BeTrue();
            result.Results.Should().BeEmpty();
        }

        // Test for GetDoctors with no doctors
        [Fact]
        public async Task GetDoctors_ShouldReturnEmptyList_WhenNoDoctorsExist()
        {
            // Arrange
            _doctorRepositoryMock.Setup(repo => repo.GetAllDoctors())
                                 .ReturnsAsync(new List<AdminDoctorProfile>());

            // Act
            var result = await _doctorService.GetDoctors();

            // Assert
            result.Should().NotBeNull();
            result.IsSuccess.Should().BeTrue();
            result.Results.Should().BeEmpty();
        }



        // Test for GetSchedulesByDoctorProfileIdAsync with valid data
        [Fact]
        public async Task GetSchedulesByDoctorProfileIdAsync_ShouldReturnSchedules_WhenValidDoctorProfileIdIsGiven()
        {
            // Arrange
            int doctorProfileId = 1;
            DateTime? startDate = DateTime.Now.AddDays(-1);
            DateTime? endDate = DateTime.Now.AddDays(1);

            var schedule = new AdminDoctorSchedule
            {
                ScheduleId = 1,
                DoctorProfileId = doctorProfileId,
                // Add other properties as needed
            };

            var scheduleDTO = new AdminDoctorScheduleDTO
            {
                ScheduleId = 1,
                DoctorProfileId = doctorProfileId,
                // Add other properties as needed
            };

            _doctorRepositoryMock.Setup(repo => repo.GetSchedulesByDoctorProfileIdAsync(doctorProfileId, startDate, endDate))
                                 .ReturnsAsync(new List<AdminDoctorSchedule> { schedule });

            _mapperMock.Setup(mapper => mapper.Map<AdminDoctorScheduleDTO>(schedule))
                       .Returns(scheduleDTO);

            // Act
            var result = await _doctorService.GetSchedulesByDoctorProfileIdAsync(doctorProfileId, startDate, endDate);

            // Assert
            result.Should().NotBeNull();
            result.IsSuccess.Should().BeTrue();
            result.HasError.Should().BeFalse();
            result.StatusCode.Should().Be(ResponseStatusCode.STATUS_SUCCESS);

        }

        // Test for GetSchedulesByDoctorProfileIdAsync with no schedules found
        [Fact]
        public async Task GetSchedulesByDoctorProfileIdAsync_ShouldReturnEmptyResult_WhenNoSchedulesFound()
        {
            // Arrange
            int doctorProfileId = 1;
            DateTime? startDate = DateTime.Now.AddDays(-1);
            DateTime? endDate = DateTime.Now.AddDays(1);

            _doctorRepositoryMock.Setup(repo => repo.GetSchedulesByDoctorProfileIdAsync(doctorProfileId, startDate, endDate))
                                 .ReturnsAsync(new List<AdminDoctorSchedule>());

            // Act
            var result = await _doctorService.GetSchedulesByDoctorProfileIdAsync(doctorProfileId, startDate, endDate);

            // Assert
            result.Should().NotBeNull();
            result.IsSuccess.Should().BeTrue();
            result.HasError.Should().BeFalse();
            result.StatusCode.Should().Be(ResponseStatusCode.STATUS_SUCCESS);
            result.Result.Should().BeNull();
        }
    }
}

