﻿using System.Net;
using Aurora.AdministrationService.API.Models.Dto.Holiday;
using Aurora.AdministrationService.API.Services.Service.Holiday;
using Aurora.AdministrationService.CrossCutting.CommonModels;
using Aurora.AdministrationService.CrossCutting.Constants;
using Aurora.AdministrationService.CrossCutting.HttpService;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.Logging;
using Moq;
using Newtonsoft.Json;

namespace Aurora.AdministrationService.Tests.API.Services.Holiday
{
    public class HolidayCommandServiceTests
    {
        private readonly byte[] concurrencyToken = [byte.MinValue, byte.MinValue, byte.MinValue, byte.MinValue, byte.MinValue, byte.MinValue, byte.MinValue, byte.MaxValue];
        private readonly Mock<ILogger<HolidayCommandService>> _mockLogger;
        private readonly Mock<IHttpClientService> _mockHttpClientService;
        private readonly Mock<IConfiguration> _mockConfiguration;
        private readonly HolidayCommandService _holidayCommandService;
        private readonly UpdateHolidayDto updateHolidayRequest;
        public HolidayCommandServiceTests()
        {
            _mockLogger = new Mock<ILogger<HolidayCommandService>>();
            _mockHttpClientService = new Mock<IHttpClientService>();
            _mockConfiguration = new Mock<IConfiguration>();
            var mockSection = new Mock<IConfigurationSection>();
            _mockConfiguration.Setup(config => config[CommonConstants.AuroraAppointmentServiceAPIURL])
             .Returns("test-client-id");
            mockSection.Setup(x => x.Value).Returns("http://test-Appt-service-url");
            _mockConfiguration.Setup(x => x.GetSection("Aurora-AppointmentServiceURL"))
                              .Returns(mockSection.Object);

            _holidayCommandService = new HolidayCommandService(
                _mockLogger.Object,
                _mockHttpClientService.Object,
                _mockConfiguration.Object
            );
            updateHolidayRequest = new UpdateHolidayDto()
            {
                Id = 1,
                Date = DateTime.Now,
                HolidayType = "National",
                HolidayDetails = "NewYear",
                LocationIds = new List<string> { "1" },
                Status = true,
                HolidayName = "NewYear",
                RecordVersion = concurrencyToken,
            };
        }

        //Test Case 1: Successful API Call
        [Fact]
        public async Task UpdateHoliday_ValidResponse_ReturnsSuccessResponse()
        {
            // Arrange
           
            int id = 1;

            var apiResponse = new GenericResponse<string>
            {
                IsSuccess = true,
                Message = "Holiday updated successfully",
                Result = "Success",
                StatusCode = ResponseStatusCode.STATUS_SUCCESS
            };

            var jsonResponse = JsonConvert.SerializeObject(apiResponse);
            var httpResponse = new HttpResponseMessage
            {
                StatusCode = HttpStatusCode.OK,
                Content = new StringContent(jsonResponse)
            };

            _mockHttpClientService
                .Setup(h => h.PutAsyncCall(It.IsAny<string>(), updateHolidayRequest, It.IsAny<string>()))
                .ReturnsAsync(httpResponse);

            // Act
            var result = await _holidayCommandService.UpdateHoliday(updateHolidayRequest, id);

            // Assert
            Assert.NotNull(result);
            Assert.True(result.IsSuccess);
            Assert.Equal("Holiday updated successfully", result.Message);
            Assert.Equal("Success", result.Result);
        }

        //Test Case 2: API Call Failure (HTTP Error Response)
        [Fact]
        public async Task UpdateHoliday_ApiError_ReturnsErrorResponse()
        {
            // Arrange
            int id = 2;

            var httpResponse = new HttpResponseMessage
            {
                StatusCode = HttpStatusCode.InternalServerError,
                Content = new StringContent("Internal Server Error")
            };

            _mockHttpClientService
                .Setup(h => h.PutAsyncCall(It.IsAny<string>(), updateHolidayRequest, It.IsAny<string>()))
                .ReturnsAsync(httpResponse);

            // Act
            var result = await _holidayCommandService.UpdateHoliday(updateHolidayRequest, id);

            // Assert
            Assert.NotNull(result);
            Assert.False(result.IsSuccess);
            Assert.Null(result.Result);
            Assert.Equal(ResponseStatusCode.STATUS_INTERNAL_SERVER_ERROR, result.StatusCode);
        }

        //Test Case 3: Deserialization Failure (Invalid JSON)
        [Fact]
        public async Task UpdateHoliday_InvalidJson_ReturnsDeserializationError()
        {
            // Arrange
            int id = 3;

            var httpResponse = new HttpResponseMessage
            {
                StatusCode = HttpStatusCode.OK,
                Content = new StringContent("")
            };

            _mockHttpClientService
                .Setup(h => h.PutAsyncCall(It.IsAny<string>(), updateHolidayRequest, It.IsAny<string>()))
                .ReturnsAsync(httpResponse);

            // Act
            var result = await _holidayCommandService.UpdateHoliday(updateHolidayRequest, id);

            // Assert
            Assert.NotNull(result);
            Assert.False(result.IsSuccess);
            Assert.Equal(ResponseMessage.API_DESERIALIZATION_FAILED, result.Message);
            Assert.Null(result.Result);
            Assert.Equal(ResponseStatusCode.STATUS_INTERNAL_SERVER_ERROR, result.StatusCode);
            _mockLogger.Verify(
            logger => logger.Log(
                It.Is<LogLevel>(logLevel => logLevel == LogLevel.Warning),
                It.IsAny<EventId>(),
                It.Is<It.IsAnyType>((v, t) => v.ToString().Contains("API response deserialization failed.")),
                It.IsAny<Exception>(),
                It.Is<Func<It.IsAnyType, Exception, string>>((v, t) => true)),
            Times.Never);

        }

        // Test Case 4: Exception During API Call
        [Fact]
        public async Task UpdateHoliday_ApiException_ReturnsExceptionResponse()
        {
            // Arrange
            int id = 4;

            _mockHttpClientService
                .Setup(h => h.PutAsyncCall(It.IsAny<string>(), updateHolidayRequest, It.IsAny<string>()))
                .ThrowsAsync(new Exception("API Exception"));

            // Act
            var result = await _holidayCommandService.UpdateHoliday(updateHolidayRequest, id);

            // Assert
            Assert.NotNull(result);
            Assert.False(result.IsSuccess);
            Assert.Equal("API Exception", result.Message);
            Assert.Null(result.Result);
            Assert.Equal(ResponseStatusCode.STATUS_INTERNAL_SERVER_ERROR, result.StatusCode);

            _mockLogger.Verify(
             logger => logger.Log(
                 It.Is<LogLevel>(logLevel => logLevel == LogLevel.Warning),
                 It.IsAny<EventId>(),
                 It.Is<It.IsAnyType>((v, t) => v.ToString().Contains("UpdateHoliday API call failed.")),
                 It.IsAny<Exception>(),
                 It.Is<Func<It.IsAnyType, Exception, string>>((v, t) => true)),
             Times.Never);
        }

        [Fact]
        public async Task DeleteHolidayByIdAsync_ValidId_ReturnsNull()
        {
            // Arrange
            int holidayId = 1;
            var fakeResponse = new HttpResponseMessage
            {
                StatusCode = HttpStatusCode.OK,
                Content = new StringContent("{\"status\":\"success\"}"),
              
            };

            _mockHttpClientService
           .Setup(s => s.DeleteAsyncCall(It.IsAny<string>(), It.IsAny<string>()))
           .ReturnsAsync(fakeResponse);
            // Act
            var result = await _holidayCommandService.DeleteHolidayByIdAsync(holidayId);

            // Assert
            Assert.Null(result.Result);
          
        }
        [Fact]
        public async Task DeleteHolidayByIdAsync_ApiThrowsException_LogsErrorAndReturnsFailure()
        {
            // Arrange
            int holidayId = 2;

            _mockHttpClientService
                .Setup(s => s.DeleteAsyncCall(It.IsAny<string>(), It.IsAny<string>()))
                .ThrowsAsync(new Exception("API failure"));

            // Act
            var result = await _holidayCommandService.DeleteHolidayByIdAsync(holidayId);

            // Assert
            Assert.NotNull(result);
            Assert.False(result.IsSuccess);
            Assert.Equal("API failure", result.Message);
         _mockLogger.Verify(
         logger => logger.Log(
             It.Is<LogLevel>(logLevel => logLevel == LogLevel.Warning),
             It.IsAny<EventId>(),
             It.Is<It.IsAnyType>((v, t) => v.ToString().Contains("\"Error deleting holiday from external service.")),
             It.IsAny<Exception>(),
             It.Is<Func<It.IsAnyType, Exception, string>>((v, t) => true)),
            Times.Never);
        }

        [Fact]
        public async Task CreateHolidayAsync_ShouldReturnSuccessResponse_WhenApiCallIsSuccessful()
        {
            // Arrange
            var createHolidayRequest = new CreateHolidayRequest
            {
                LocationIds = new List<string> { "PUCH", "MIRI" },
                Date = DateTime.Now,
                HolidayName = "New Year",
                HolidayType = "Public",
                HolidayDetails = "New Year Celebration",
                Status = true
            };

            var apiResponse = new GenericResponse<string>
            {
                IsSuccess = true,
                Message = "Holiday Created Successfully"
            };

            var httpResponseMessage = new HttpResponseMessage
            {
                StatusCode = HttpStatusCode.OK,
                Content = new StringContent(JsonConvert.SerializeObject(apiResponse))
            };

            _mockConfiguration.Setup(c => c[It.IsAny<string>()]).Returns("test");
            _mockHttpClientService
                .Setup(h => h.PostAsyncCall(It.IsAny<string>(), It.IsAny<object>(), It.IsAny<string>()))
                .ReturnsAsync(httpResponseMessage);

            // Act
            var result = await _holidayCommandService.CreateHolidayAsync(createHolidayRequest);

            // Assert
            Assert.True(result.IsSuccess);
            Assert.Equal("Holiday Created Successfully", result.Message);
        }
       
        [Fact]
        public async Task CreateHolidayAsync_ShouldHandleException_WhenApiCallFails()
        {
            // Arrange
            var createHolidayRequest = new CreateHolidayRequest
            {
                LocationIds = new List<string> { "PUCH", "MIRI" },
                Date = DateTime.Now,
                HolidayName = "New Year",
                HolidayType = "Public",
                HolidayDetails = "New Year Celebration",
                Status = true
            };

            _mockHttpClientService
                .Setup(h => h.PostAsyncCall(It.IsAny<string>(), It.IsAny<object>(), It.IsAny<string>()))
                .ThrowsAsync(new Exception("API call failed"));

            // Act
            var result = await _holidayCommandService.CreateHolidayAsync(createHolidayRequest);

            // Assert
            Assert.False(result.IsSuccess);
            Assert.Equal("API call failed", result.Message);
        }
    }
}
