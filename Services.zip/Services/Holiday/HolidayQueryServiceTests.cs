﻿using System.Collections.Specialized;
using System.Net;
using System.Reflection;
using Aurora.AdministrationService.API.Models.Dto.Holiday;
using Aurora.AdministrationService.API.Services.Service.Holiday;
using Aurora.AdministrationService.CrossCutting.CommonModels;
using Aurora.AdministrationService.CrossCutting.Constants;
using Aurora.AdministrationService.CrossCutting.Extensions;
using Aurora.AdministrationService.CrossCutting.HttpService;
using Aurora.AdministrationService.Domain.V1.Entities.Locations;
using Aurora.AdministrationService.Infrastructure;
using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.Logging;
using Moq;
using Newtonsoft.Json;

namespace Aurora.AdministrationService.Tests.API.Services.Holiday
{
    public class HolidayQueryServiceTests
    {
        private readonly Mock<IHttpClientService> _httpClientServiceMock;
        private readonly Mock<ILogger<HolidayQueryService>> _loggerMock;
        private readonly Mock<IConfiguration> _configurationMock;
        private readonly Mock<ReadOnlyDbContext> _contextMock; // Replace with actual DbContext
        private readonly HolidayQueryService _service;

        public HolidayQueryServiceTests()
        {
            _httpClientServiceMock = new Mock<IHttpClientService>();
            _loggerMock = new Mock<ILogger<HolidayQueryService>>();
            _configurationMock = new Mock<IConfiguration>();
            

            var options = new DbContextOptionsBuilder<ReadOnlyDbContext>()
              .UseInMemoryDatabase(databaseName: Guid.NewGuid().ToString())
            .Options;

            _contextMock = new Mock<ReadOnlyDbContext>(options);

            _service = new HolidayQueryService(
                _httpClientServiceMock.Object,
                _configurationMock.Object,
                _loggerMock.Object,
                _contextMock.Object
            );
        }

        [Fact]
        public async Task GetHolidaySearch_ReturnsSuccessResponse_WhenApiCallIsSuccessful()
        {
            // Arrange
            var pagination = new PaginationQuery { PageNumber = 1, PageSize = 10 };
            var selectedLocationId = "NYC";
            var apiResponse = new GenericResponsePagedList<GetHolidaySearchResponse>
            {
                IsSuccess = true,
                Results = new List<GetHolidaySearchResponse>
            {
                    new GetHolidaySearchResponse
                {
                    Id = 1,
                    Date = DateTime.UtcNow,
                    HolidayName = "Christmas",
                    HolidayType = "Public",
                    HolidayDetails = "Celebration of the birth of Jesus Christ",
                    Status = true,
                    Locations = new List<LocationDto>
                    {
                        new LocationDto { LocationID = "NYC" },
                        new LocationDto { LocationID = "LA" }
                    }
                },
                new GetHolidaySearchResponse
                {
                    Id = 2,
                    Date = DateTime.UtcNow,
                    HolidayName = "New Year",
                    HolidayType = "Public",
                    HolidayDetails = "Welcoming the New Year",
                    Status = true,
                    Locations = new List<LocationDto>
                    {
                        new LocationDto { LocationID = "Chicago" }
                    }
                },
                new GetHolidaySearchResponse
                {
                    Id = 3,
                    Date = DateTime.UtcNow,
                    HolidayName = "Easter",
                    HolidayType = "Religious",
                    HolidayDetails = "Celebration of Jesus Christ's resurrection",
                    Status = false,
                    Locations = new List<LocationDto>
                    {
                        new LocationDto { LocationID = "Test" }
                    }
                }
            },
                StatusCode = ResponseStatusCode.STATUS_SUCCESS
            };

            _configurationMock.Setup(c => c[It.IsAny<string>()]).Returns("http://fakeurl.com");
            _httpClientServiceMock
                .Setup(x => x.GetAsyncCall(It.IsAny<string>(), It.IsAny<string>()))
                .ReturnsAsync(new HttpResponseMessage
                {
                    StatusCode = HttpStatusCode.OK,
                    Content = new StringContent(JsonConvert.SerializeObject(apiResponse))
                });

            var dbLocations = new List<Aurora.AdministrationService.Domain.V1.Entities.Locations.Location>
             {
               new Location
               {
                Id = 1,
                ResourceID = "NYC",
                Status = true,
                OperationalStatus = "Active",
                Name = "New York Office",
                Alias = "NYC Office",
                Description = "Headquarters for North America operations.",
                Mode = "Hybrid",
                Longitude = -74.0060m,
                Latitude = 40.7128m,
                Altitude = 33.0m,
                PhysicalType = "Office",
                ManagingOrganization = Guid.NewGuid(),
                PartOf = "North America",
                AvailabilityExceptions = "Closed on Public Holidays",
                Source = "Internal",
                URL = "https://nyc.office.example.com",
                CreatedBy = "admin",
                CreatedDate = DateTime.UtcNow
            },
              new Location
            {
                Id = 2,
                ResourceID = "LOC002",
                Status = false,
                OperationalStatus = "Inactive",
                Name = "Los Angeles Warehouse",
                Alias = "LA Warehouse",
                Description = "Distribution center for west coast logistics.",
                Mode = "Remote",
                Longitude = -118.2437m,
                Latitude = 34.0522m,
                Altitude = 89.0m,
                PhysicalType = "Warehouse",
                ManagingOrganization = Guid.NewGuid(),
                PartOf = "West Coast",
                AvailabilityExceptions = "Maintenance every first Monday",
                Source = "External",
                URL = "https://la.warehouse.example.com",
                CreatedBy = "warehouse_manager",
                CreatedDate = DateTime.UtcNow.AddDays(-30)
            },
                new Location
            {
                Id = 3,
                ResourceID = "LOC003",
                Status = true,
                OperationalStatus = "Active",
                Name = "Chicago Data Center",
                Alias = "CHI Data Center",
                Description = "Critical infrastructure for data hosting.",
                Mode = "On-site",
                Longitude = -87.6298m,
                Latitude = 41.8781m,
                Altitude = 181.0m,
                PhysicalType = "Data Center",
                ManagingOrganization = Guid.NewGuid(),
                PartOf = "Midwest",
                AvailabilityExceptions = "Annual system upgrade in July",
                Source = "Internal",
                URL = "https://chi.datacenter.example.com",
                CreatedBy = "it_admin",
                CreatedDate = DateTime.UtcNow.AddMonths(-3)
            }
            }.AsQueryable();

            var mockSet = new Mock<DbSet<Location>>();
            mockSet.As<IQueryable<Location>>().Setup(m => m.Provider).Returns(dbLocations.Provider);
            mockSet.As<IQueryable<Location>>().Setup(m => m.Expression).Returns(dbLocations.Expression);
            mockSet.As<IQueryable<Location>>().Setup(m => m.ElementType).Returns(dbLocations.ElementType);
            mockSet.As<IQueryable<Location>>().Setup(m => m.GetEnumerator()).Returns(dbLocations.GetEnumerator());

            _contextMock.Setup(c => c.Locations).Returns(mockSet.Object);


            // Act
            var result = await _service.GetHolidaySearch(pagination, selectedLocationId);

            // Assert
            Assert.NotNull(result);
            Assert.True(result.IsSuccess);
        }

        [Fact]
        public async Task GetHolidaySearch_ReturnsErrorResponse_WhenApiCallFails()
        {
            // Arrange
            var pagination = new PaginationQuery { PageNumber = 1, PageSize = 10 };

            _httpClientServiceMock
                .Setup(x => x.GetAsyncCall(It.IsAny<string>(), It.IsAny<string>()))
                .ReturnsAsync(new HttpResponseMessage
                {
                    StatusCode = HttpStatusCode.BadRequest,
                    ReasonPhrase = "Bad Request"
                });

            // Act
            var result = await _service.GetHolidaySearch(pagination, null);

            // Assert
            Assert.NotNull(result);
            Assert.False(result.IsSuccess);
            Assert.Equal(ResponseStatusCode.STATUS_NOTFOUND, result.StatusCode);
        }

        [Fact]
        public async Task GetHolidaySearch_ReturnsErrorResponse_WhenExceptionIsThrown()
        {
            // Arrange
            var pagination = new PaginationQuery { PageNumber = 1, PageSize = 10 };

            _httpClientServiceMock
                .Setup(x => x.GetAsyncCall(It.IsAny<string>(), It.IsAny<string>()))
                .ThrowsAsync(new Exception("API error"));

            // Act
            var result = await _service.GetHolidaySearch(pagination, null);

            // Assert
            Assert.NotNull(result);
            Assert.False(result.IsSuccess);
            Assert.Equal(ResponseStatusCode.STATUS_NOTFOUND, result.StatusCode);
        }
        [Fact]
        public async Task GetHolidayById_ShouldReturnHolidayDetailDto_WhenApiCallIsNotSuccessful()
        {
            // Arrange
            var mockSection = new Mock<IConfigurationSection>();
            int holidayId = 1;
            var holidayDetail = new GetHolidayDetailDto
            {
                LocationIds = new List<string> { "Chicago" },
                HolidayName = "New Year",
                HolidayType = "Public",
                HolidayDetails = "New Year Celebration",
                Status = true,
                Date =DateTime.UtcNow
            };

            var apiResponse = new GenericResponse<GetHolidayDetailDto>
            {
                IsSuccess = true,
                Result = holidayDetail
            };

            var jsonResponse = JsonConvert.SerializeObject(apiResponse);
            var httpResponse = new HttpResponseMessage
            {
                StatusCode = HttpStatusCode.OK,
                Content = new StringContent(jsonResponse)
            };

            _httpClientServiceMock
                .Setup(x => x.GetAsyncCall(It.IsAny<string>(), It.IsAny<string>()))
                .ReturnsAsync(httpResponse);

            _configurationMock.Setup(config => config[CommonConstants.AuroraAppointmentServiceAPIURL])
                .Returns("test-client-id");

            mockSection.Setup(x => x.Value).Returns("http://test-Appt-service-url");
            _configurationMock.Setup(x => x.GetSection("Aurora-AppointmentServiceURL"))
                              .Returns(mockSection.Object);
            var dbLocations = new List<Aurora.AdministrationService.Domain.V1.Entities.Locations.Location>
             {
               new Location
            {
                Id = 1,
                ResourceID = "NYC",
                Status = true,
                OperationalStatus = "Active",
                Name = "New York Office",
                Alias = "NYC Office",
                Description = "Headquarters for North America operations.",
                Mode = "Hybrid",
                Longitude = -74.0060m,
                Latitude = 40.7128m,
                Altitude = 33.0m,
                PhysicalType = "Office",
                ManagingOrganization = Guid.NewGuid(),
                PartOf = "North America",
                AvailabilityExceptions = "Closed on Public Holidays",
                Source = "Internal",
                URL = "https://nyc.office.example.com",
                CreatedBy = "admin",
                CreatedDate = DateTime.UtcNow
            },
              new Location
            {
                Id = 2,
                ResourceID = "LOC002",
                Status = false,
                OperationalStatus = "Inactive",
                Name = "Los Angeles Warehouse",
                Alias = "LA Warehouse",
                Description = "Distribution center for west coast logistics.",
                Mode = "Remote",
                Longitude = -118.2437m,
                Latitude = 34.0522m,
                Altitude = 89.0m,
                PhysicalType = "Warehouse",
                ManagingOrganization = Guid.NewGuid(),
                PartOf = "West Coast",
                AvailabilityExceptions = "Maintenance every first Monday",
                Source = "External",
                URL = "https://la.warehouse.example.com",
                CreatedBy = "warehouse_manager",
                CreatedDate = DateTime.UtcNow.AddDays(-30)
            },
                new Location
            {
                Id = 3,
                ResourceID = "LOC003",
                Status = true,
                OperationalStatus = "Active",
                Name = "Chicago Data Center",
                Alias = "CHI Data Center",
                Description = "Critical infrastructure for data hosting.",
                Mode = "On-site",
                Longitude = -87.6298m,
                Latitude = 41.8781m,
                Altitude = 181.0m,
                PhysicalType = "Data Center",
                ManagingOrganization = Guid.NewGuid(),
                PartOf = "Midwest",
                AvailabilityExceptions = "Annual system upgrade in July",
                Source = "Internal",
                URL = "https://chi.datacenter.example.com",
                CreatedBy = "it_admin",
                CreatedDate = DateTime.UtcNow.AddMonths(-3)
            }
             }.AsQueryable();

            //Arranget
            var mockSet = new Mock<DbSet<Location>>();
            mockSet.As<IQueryable<Location>>().Setup(m => m.Provider).Returns(dbLocations.Provider);
            mockSet.As<IQueryable<Location>>().Setup(m => m.Expression).Returns(dbLocations.Expression);
            mockSet.As<IQueryable<Location>>().Setup(m => m.ElementType).Returns(dbLocations.ElementType);
            mockSet.As<IQueryable<Location>>().Setup(m => m.GetEnumerator()).Returns(dbLocations.GetEnumerator());

            _contextMock.Setup(c => c.Locations).Returns(mockSet.Object);
            // Act
            var result = await _service.GetHolidayById(holidayId);

            // Assert
            Assert.Null(result.Result);
        }

        [Fact]
        public async Task GetHolidayById_ShouldLogError_WhenApiCallFails()
        {
            // Arrange
            var mockSection = new Mock<IConfigurationSection>();
            int holidayId = 1;
            var httpResponse = new HttpResponseMessage
            {
                StatusCode = HttpStatusCode.InternalServerError
            };



            _httpClientServiceMock
                .Setup(x => x.GetAsyncCall(It.IsAny<string>(), It.IsAny<string>()))
                .ReturnsAsync(httpResponse);
            _configurationMock.Setup(config => config[CommonConstants.AuroraAppointmentServiceAPIURL])
       .Returns("test-client-id");
            mockSection.Setup(x => x.Value).Returns("http://test-Appt-service-url");
            _configurationMock.Setup(x => x.GetSection("Aurora-AppointmentServiceURL"))
                              .Returns(mockSection.Object);

            // Act
            var result = await _service.GetHolidayById(holidayId);

            // Assert
            _loggerMock.Verify(
        logger => logger.Log(
            It.Is<LogLevel>(logLevel => logLevel == LogLevel.Warning),
            It.IsAny<EventId>(),
            It.Is<It.IsAnyType>((v, t) => v.ToString().Contains("Holiday API call failed\"")),
            It.IsAny<Exception>(),
            It.Is<Func<It.IsAnyType, Exception, string>>((v, t) => true)),
           Times.Never);
            Assert.Null(result.Result); // Since the API failed, the result should be null
        }

        [Fact]
        public void GetLocationName_ShouldReturnUpdatedLocationIds_WhenApiResponseIsValid()
        {
            // Arrange
            var locationList = new List<Aurora.AdministrationService.Domain.V1.Entities.Locations.Location>
             {
               new Location
            {
                Id = 1,
                ResourceID = "NYC",
                Status = true,
                OperationalStatus = "Active",
                Name = "New York Office",
                Alias = "NYC Office",
                Description = "Headquarters for North America operations.",
                Mode = "Hybrid",
                Longitude = -74.0060m,
                Latitude = 40.7128m,
                Altitude = 33.0m,
                PhysicalType = "Office",
                ManagingOrganization = Guid.NewGuid(),
                PartOf = "North America",
                AvailabilityExceptions = "Closed on Public Holidays",
                Source = "Internal",
                URL = "https://nyc.office.example.com",
                CreatedBy = "admin",
                CreatedDate = DateTime.UtcNow
            },
              new Location
            {
                Id = 2,
                ResourceID = "LOC002",
                Status = false,
                OperationalStatus = "Inactive",
                Name = "Los Angeles Warehouse",
                Alias = "LA Warehouse",
                Description = "Distribution center for west coast logistics.",
                Mode = "Remote",
                Longitude = -118.2437m,
                Latitude = 34.0522m,
                Altitude = 89.0m,
                PhysicalType = "Warehouse",
                ManagingOrganization = Guid.NewGuid(),
                PartOf = "West Coast",
                AvailabilityExceptions = "Maintenance every first Monday",
                Source = "External",
                URL = "https://la.warehouse.example.com",
                CreatedBy = "warehouse_manager",
                CreatedDate = DateTime.UtcNow.AddDays(-30)
            },
                new Location
            {
                Id = 3,
                ResourceID = "LOC003",
                Status = true,
                OperationalStatus = "Active",
                Name = "Chicago Data Center",
                Alias = "CHI Data Center",
                Description = "Critical infrastructure for data hosting.",
                Mode = "On-site",
                Longitude = -87.6298m,
                Latitude = 41.8781m,
                Altitude = 181.0m,
                PhysicalType = "Data Center",
                ManagingOrganization = Guid.NewGuid(),
                PartOf = "Midwest",
                AvailabilityExceptions = "Annual system upgrade in July",
                Source = "Internal",
                URL = "https://chi.datacenter.example.com",
                CreatedBy = "it_admin",
                CreatedDate = DateTime.UtcNow.AddMonths(-3)
            }
             }.AsQueryable();

            var mockSet = new Mock<DbSet<Location>>();
            mockSet.As<IQueryable<Location>>().Setup(m => m.Provider).Returns(locationList.Provider);
            mockSet.As<IQueryable<Location>>().Setup(m => m.Expression).Returns(locationList.Expression);
            mockSet.As<IQueryable<Location>>().Setup(m => m.ElementType).Returns(locationList.ElementType);
            mockSet.As<IQueryable<Location>>().Setup(m => m.GetEnumerator()).Returns(locationList.GetEnumerator());

            _contextMock.Setup(c => c.Locations).Returns(mockSet.Object);

            var apiResponse = new GenericResponse<GetHolidayDetailDto>
            {
                IsSuccess = true,
                Result = new GetHolidayDetailDto
                {
                    LocationIds = new List<string> { "LOC003", "LOC002" },
                    Date = DateTime.UtcNow,
                    HolidayType = "Test",
                    Status = true
                }
            };

            // Act: Use Reflection to invoke the private method
            var methodInfo = typeof(HolidayQueryService).GetMethod("GetLocationName", BindingFlags.NonPublic | BindingFlags.Instance);
            methodInfo.Invoke(_service, new object[] { apiResponse });

            // Assert
            Assert.NotNull(apiResponse);
        }

        [Fact]
        public void GetLocationName_ShouldLogErrorAndReturnNull_WhenApiResponseIsNotSuccess()
        {
            // Arrange
            var apiResponse = new GenericResponse<GetHolidayDetailDto>
            {
                IsSuccess = false,
                Message = "API call failed"
            };

            // Act
            var methodInfo = typeof(HolidayQueryService).GetMethod("GetLocationName", BindingFlags.NonPublic | BindingFlags.Instance);
            methodInfo.Invoke(_service, new object[] { apiResponse });

            // Assert
            Assert.Null(apiResponse.Result);

            _loggerMock.Verify(
                        logger => logger.Log(
           It.Is<LogLevel>(logLevel => logLevel == LogLevel.Warning),
           It.IsAny<EventId>(),
           It.Is<It.IsAnyType>((v, t) => v.ToString().Contains("API call failed")),
           It.IsAny<Exception>(),
           It.Is<Func<It.IsAnyType, Exception, string>>((v, t) => true)),
          Times.Never);
           
        }

        [Fact]
        public void AddLocation_ShouldMergeLocationsCorrectly()
        {
            // Arrange
          
            _configurationMock.Setup(c => c[It.IsAny<string>()]).Returns("http://fakeurl.com");
            

            var apiResponse = new GenericResponsePagedList<GetHolidaySearchResponse>
            {
                Results = new List<GetHolidaySearchResponse>
            {
                new GetHolidaySearchResponse
                {
                    Id = 1,
                    Date = DateTime.UtcNow,
                    HolidayName = "New Year",
                    HolidayType = "Public",
                    HolidayDetails = "New Year celebration",
                    Status = true,
                    Locations = new List<LocationDto>
                    {
                        new LocationDto { LocationID = "101" },
                        new LocationDto { LocationID = "102" }
                    }
                }
            }
            };

            _httpClientServiceMock
                .Setup(x => x.GetAsyncCall(It.IsAny<string>(), It.IsAny<string>()))
                .ReturnsAsync(new HttpResponseMessage
                {
                    StatusCode = HttpStatusCode.OK,
                    Content = new StringContent(JsonConvert.SerializeObject(apiResponse))
                });
            var dbLocations = new List<Aurora.AdministrationService.Domain.V1.Entities.Locations.Location>
             {
               new Location
            {
                Id = 1,
                ResourceID = "NYC",
                Status = true,
                OperationalStatus = "Active",
                Name = "New York Office",
                Alias = "NYC Office",
                Description = "Headquarters for North America operations.",
                Mode = "Hybrid",
                Longitude = -74.0060m,
                Latitude = 40.7128m,
                Altitude = 33.0m,
                PhysicalType = "Office",
                ManagingOrganization = Guid.NewGuid(),
                PartOf = "North America",
                AvailabilityExceptions = "Closed on Public Holidays",
                Source = "Internal",
                URL = "https://nyc.office.example.com",
                CreatedBy = "admin",
                CreatedDate = DateTime.UtcNow
            },
              new Location
            {
                Id = 2,
                ResourceID = "LOC002",
                Status = false,
                OperationalStatus = "Inactive",
                Name = "Los Angeles Warehouse",
                Alias = "LA Warehouse",
                Description = "Distribution center for west coast logistics.",
                Mode = "Remote",
                Longitude = -118.2437m,
                Latitude = 34.0522m,
                Altitude = 89.0m,
                PhysicalType = "Warehouse",
                ManagingOrganization = Guid.NewGuid(),
                PartOf = "West Coast",
                AvailabilityExceptions = "Maintenance every first Monday",
                Source = "External",
                URL = "https://la.warehouse.example.com",
                CreatedBy = "warehouse_manager",
                CreatedDate = DateTime.UtcNow.AddDays(-30)
            },
                new Location
            {
                Id = 3,
                ResourceID = "LOC003",
                Status = true,
                OperationalStatus = "Active",
                Name = "Chicago Data Center",
                Alias = "CHI Data Center",
                Description = "Critical infrastructure for data hosting.",
                Mode = "On-site",
                Longitude = -87.6298m,
                Latitude = 41.8781m,
                Altitude = 181.0m,
                PhysicalType = "Data Center",
                ManagingOrganization = Guid.NewGuid(),
                PartOf = "Midwest",
                AvailabilityExceptions = "Annual system upgrade in July",
                Source = "Internal",
                URL = "https://chi.datacenter.example.com",
                CreatedBy = "it_admin",
                CreatedDate = DateTime.UtcNow.AddMonths(-3)
            }
             }.AsQueryable();

            //Arranget
            var mockSet = new Mock<DbSet<Location>>();
            mockSet.As<IQueryable<Location>>().Setup(m => m.Provider).Returns(dbLocations.Provider);
            mockSet.As<IQueryable<Location>>().Setup(m => m.Expression).Returns(dbLocations.Expression);
            mockSet.As<IQueryable<Location>>().Setup(m => m.ElementType).Returns(dbLocations.ElementType);
            mockSet.As<IQueryable<Location>>().Setup(m => m.GetEnumerator()).Returns(dbLocations.GetEnumerator());

            _contextMock.Setup(c => c.Locations).Returns(mockSet.Object);

            
            // Act: Use Reflection to invoke the private method
            var methodInfo = typeof(HolidayQueryService).GetMethod("AddLocation", BindingFlags.NonPublic | BindingFlags.Instance);
            methodInfo.Invoke(_service, new object[] { apiResponse });

            // Assert
            Assert.Single(apiResponse.Results);
            var result = apiResponse.Results.First();
            Assert.NotNull(result.Locations);
        }

        [Fact]
        public void AddHolidayParameter_ShouldReturnCorrectQueryParams()
        {
            // Arrange
            var pagination = new PaginationQuery
            {
                PageNumber = 2,
                PageSize = 20,
                GlobalFilterString = "Holiday",
                Filters = new Dictionary<string, string>
            {
                { "Type", "Public" },
                { "Status", "Active" }
            },
                SortString = "Date",
                SortOrder = "asc"
            };
            var selectedLocationId = "LOC123";

            // Act: Use Reflection to invoke the private static method
            var methodInfo = typeof(HolidayQueryService).GetMethod(
                "AddHolidayParameter",
                System.Reflection.BindingFlags.NonPublic | System.Reflection.BindingFlags.Static
            );

            var result = (NameValueCollection)methodInfo.Invoke(null, new object[] { pagination, selectedLocationId });

            // Assert
            Assert.NotNull(result);
            Assert.Equal("2", result["pageNumber"]);
            Assert.Equal("20", result["pageSize"]);
            Assert.Equal("LOC123", result["selectedLocationId"]);
            Assert.Equal("Holiday", result["globalFilterString"]);
            Assert.Equal("Public", result["filters[Type]"]);
            Assert.Equal("Active", result["filters[Status]"]);
            Assert.Equal("Date", result["sortString"]);
            Assert.Equal("asc", result["sortOrder"]);
        }

        [Fact]
        public void AddHolidayParameter_ShouldHandleNullSelectedLocationId()
        {
            // Arrange
            var pagination = new PaginationQuery
            {
                PageNumber = 1,
                PageSize = 10
            };

            // Act
            var methodInfo = typeof(HolidayQueryService).GetMethod(
                "AddHolidayParameter",
                System.Reflection.BindingFlags.NonPublic | System.Reflection.BindingFlags.Static
            );

            var result = (NameValueCollection)methodInfo.Invoke(null, new object[] { pagination, null });

            // Assert
            Assert.NotNull(result);
            Assert.Equal("1", result["pageNumber"]);
            Assert.Equal("10", result["pageSize"]);
            Assert.Equal(string.Empty, result["selectedLocationId"]);
        }
   
        [Fact]
        public void GetHolidayWithLocationNames_ReturnsSuccess()
        {
            // Arrange
            var apiResponse = new GenericResponse<GetHolidayDetailDto>
            {
                IsSuccess = true,
                Result = new GetHolidayDetailDto
                {
                    LocationIds = new List<string> { "LOC003", "LOC002" },
                    Date = DateTime.UtcNow,
                    HolidayType = "Test",
                    Status = true
                }
            };

            // Act
            var methodInfo = typeof(HolidayQueryService).GetMethod("GetLocationName", BindingFlags.NonPublic | BindingFlags.Instance);
            methodInfo.Invoke(_service, new object[] { apiResponse });

          

            // Assert
            Assert.NotNull(apiResponse.Result);
            Assert.True(apiResponse.IsSuccess);
             
        }

    }
}
